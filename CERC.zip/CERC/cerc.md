Documentação de integração com a CERC

