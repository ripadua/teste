export class UserSIUSR {
  deMatricula: string;
  noUsuario: string;
  coUnidade: number;
  noUnidade : string;
  sgUF: string;
  perfil: any;
  token: string;
  sessionid: string;
}
