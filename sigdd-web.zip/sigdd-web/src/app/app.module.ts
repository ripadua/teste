import { TemplateModule } from './template/template.module';
import { ModalModule } from './template/modal/modal.module';
import { BrowserModule } from '@angular/platform-browser';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { NgModule, ErrorHandler } from '@angular/core';
import { HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { AppComponent } from './app.component';
import { AppRoutingModule } from './app.routing.module';
import { PaeContratacaoModule} from './pae/contratacao/pae-contratacao.module';
import { AuthGuard } from './guards';
import { AuthenticationService, ApplicationService, HttpInterceptorService, EventService, LoaderService } from './services';
import { SharedModule, OverlayPanelModule, SliderModule, CardModule} from 'primeng';
import { InfoComponent } from './info/info.component';
import { RadioButtonModule } from 'primeng/radiobutton';
import { GlobalErrorHandlerService } from './global-error/global-erro-handle.service';
import { GlobalErrorComponent } from './global-error/view/global-error.component';
import { AnalyticsModule } from './shared/analytics.module';
import { ShareModule } from './shared/share.module';
import { RouterService } from './services/router-service';
import { LoaderRelativoModule } from './services/loader-relativo/loader-relativo.module';
import { NgxMaskModule } from 'ngx-mask'
import { GlobalErrorComponentPresenter } from './global-error/presenter/global-error.component.presenter';
import { DataService } from './services/data-service';
import { DeviceDetectorModule } from 'ngx-device-detector';
import { PagesModule } from './pages/pages.modules';
import { APP_BASE_HREF } from '@angular/common';
import { SimpleModalModule } from 'ngx-simple-modal'; 


@NgModule({
  declarations: [
    AppComponent,
    InfoComponent,
    GlobalErrorComponent
  ],
  imports: [
    BrowserModule,
    FormsModule,
    ReactiveFormsModule,
    BrowserAnimationsModule,
    AppRoutingModule,
    HttpClientModule,
    SharedModule,
    NgxMaskModule.forRoot(),
    ModalModule,
    TemplateModule,
    PaeContratacaoModule,
    RadioButtonModule,
    SliderModule,
    OverlayPanelModule,
    CardModule,
    ShareModule,
    AnalyticsModule,
    LoaderRelativoModule,
    DeviceDetectorModule.forRoot(),
    PagesModule, 
    SimpleModalModule.forRoot({container: document.body})
  ],
  providers: [
    {
      provide: HTTP_INTERCEPTORS,
      useClass: HttpInterceptorService,
      multi: true
    },
    {
      provide: ErrorHandler,
      useClass: GlobalErrorHandlerService
    },
    { provide: APP_BASE_HREF, useValue: '/'},
    GlobalErrorHandlerService,
    GlobalErrorComponentPresenter,
    AuthenticationService,
    AuthGuard,
    ApplicationService,
    EventService,
    LoaderService,
    RouterService,
    DataService
  ],
  bootstrap: [AppComponent],
})
export class AppModule { }
