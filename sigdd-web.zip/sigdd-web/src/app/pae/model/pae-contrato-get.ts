export class PaeContratoGet  {
    processo_administrativo?: {};
    numero_contrato?: string = null;
    ano_contrato: string = null;
    descricao_contrato?: string = null;
    data_hora_inclusao?: string = null;
    matricula_inclusao?: string = null;
    cpf_fornecedor?: string = null;
    cnpj_fornecedor?: string = null;
    apensos?: any[];
    documentos?: any[];
}