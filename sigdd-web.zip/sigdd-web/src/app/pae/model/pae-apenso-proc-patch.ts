export class PaeApensoProcPatch  {
    
    id_processo_vinculado?: string = null;
    cpf_fornecedor?: string = null;
    cnpj_fornecedor?: string = null;
    tipo_apenso?: string = null;
    descricao_apenso?: string = null;
    protocolo_siclg?: string = null;
    titulo_apenso?: string = null;

}