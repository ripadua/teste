export class PaeContratacaoPost {
    numero_processo?: string  = null;
    ano_processo?: string = null;
    numero_pregao?: string  = null;
    unidade_demandante?: string = null;
    ano_pregao?: string  = null;
    unidade_contratacao?: string  = null;
    objeto_contratacao?: string = null;
    protocolo_siclg?: string = null;
}
