export class Combo {
    label?: string;
    value?: string;
}