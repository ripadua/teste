export class PaeContratacaoPatch {
    numero_pregao?: string  = null;
    ano_pregao?: string  = null;
    unidade_contratacao?: string  = null;
    unidade_demandante?: string = null;
    protocolo_siclg?: string = null;
    objeto_contratacao?: string = null
    data_hora_finalizacao?: string  = null;
    matricula_finalizacao?: string  = null;
}
