export class PaeDocumentoPatch  {
    tipo_documento?: string = null
    origem_documento?: string = null
    descricao_documento?: string = null
    justificativa_substituicao?: string = null;
    confidencial? = true
    valido? = true;
    atributos_documento?: any
}