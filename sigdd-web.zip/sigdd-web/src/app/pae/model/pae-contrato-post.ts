export class PaeContratoPost  {
    numero_contrato?: string = null
    ano_contrato?: string = null
    descricao_contrato?: string = null
    matricula_inclusao?: string
    cpf_fornecedor?: string  = null
    cnpj_fornecedor?: string  = null
    //gestor_operacional?: string = null
}