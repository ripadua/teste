export class PaeContratoPatch  {
    id_processo_vinculado?: string = null
    numero_contrato?: string = null
    ano_contrato?: string = null
    descricao_contrato?: string = null
    cpf_fornecedor?: string = null
    cnpj_fornecedor?: string = null
    unidade_operacional?: string = null
}