import { ZerosEsquerda } from './zeros-esquerda.pipe';

describe('FormataMimePipe', () => {
  it('create an instance', () => {
    const pipe = new ZerosEsquerda();
    expect(pipe).toBeTruthy();
  });
});
