import { FormataMimePipe } from './formata-mime.pipe';

describe('FormataMimePipe', () => {
  it('create an instance', () => {
    const pipe = new FormataMimePipe();
    expect(pipe).toBeTruthy();
  });
});
