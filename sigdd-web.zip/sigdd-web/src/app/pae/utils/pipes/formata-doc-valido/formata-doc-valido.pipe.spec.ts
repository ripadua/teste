import { FormataDocValido } from './formata-doc-valido.pipe';

describe('FormataMimePipe', () => {
  it('create an instance', () => {
    const pipe = new FormataDocValido();
    expect(pipe).toBeTruthy();
  });
});
