import { FormataTituloApenso } from './formata-titulo-apenso.pipe';

describe('FormataMimePipe', () => {
  it('create an instance', () => {
    const pipe = new FormataTituloApenso();
    expect(pipe).toBeTruthy();
  });
});
