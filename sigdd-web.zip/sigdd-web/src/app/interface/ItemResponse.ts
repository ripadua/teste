
export interface ItemResponse {
  results: string[];
}