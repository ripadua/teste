import { CxOnlyNumberDirective } from './cx-only-number.directive';

describe('CxOnlyNumberDirective', () => {
  it('should create an instance', () => {
    const directive = new CxOnlyNumberDirective();
    expect(directive).toBeTruthy();
  });
});
