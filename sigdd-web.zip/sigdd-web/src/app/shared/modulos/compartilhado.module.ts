import { NgModule } from '@angular/core';

import { CommonModule } from '../../../../node_modules/@angular/common';


@NgModule({
    imports:      [ CommonModule ],
    declarations: [ ],
    exports: [ ]
  })
  
  export class CompartilhadodModule {}