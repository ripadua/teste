export const ARQUITETURA_SERVICOS = {
  processoAdministrativo : '/processoadministrativo/v1',
  cadastro : '/cadastro/v1'
}

export const LOCAL_STORAGE_CONSTANTS = {
  token: 'token',
  userSSO: 'userSSO',
  userSiusr : 'userSiusr',
  userImage: 'imagem-usuario-',
  idToken: 'idToken',
  userUrl: 'userUrl',
  rolesInMemory: 'rls',
  logout: 'logout',
  marcaTodos: 'marcaTodos',
  textPlain: 'text-plain'
}


export const EVENTS = {
  authorization: 'authorization',
  cleanHeaderSearch: 'cleanHeaderSearch',
  headerSearch: 'headerSearch',
  alertMessage: 'alertMessage',
  finishSaveDossieCliente : 'finishSaveDossieCliente',
  QTD_IMAGEM_VISUALIZACAO: "QTD_IMAGEM_VISUALIZACAO",
  INIT_CEP_ONLINE_DADOS_DECLARADOS: "INIT_CEP_ONLINE_DADOS_DECLARADOS",
  INIT_CEP_ONLINE_FORMULARIO_DINAMICO: "INIT_CEP_ONLINE_FORMULARIO_DINAMICO",
  eventFontUp: "eventFontUp",
  eventFontDown: 'eventFontDown',
  eventContrast: 'eventContrast'
}

export const STATUS_ALERT = {
  SUCESSO: 'SUCESSO',
  INFOR: 'INFOR',
  WARNING: 'WARNING',
  ERROR: 'ERROR'
}

export const MESSAGE_ALERT_MENU = {
  MSG_ERRO_SEM_PERFIL: "Acesso não permitido. Solicitação de perfil via acessologico.caixa",
  MSG_ALERTA_TROCA_PERFIL: "Você tem certeza que deseja trocar sua sessão para o perfil [0] ?"
}

export const PERFIL_ACESSO = {
  SET_SERVICO: 'SET_SERVICO',
  ECM_USER: 'ecm_user',
  UMA_AUTHORIZATION: 'uma_authorization'
}

export const PRETTY_PROFILE = {
  SET_SERVICO: { profile: PERFIL_ACESSO.SET_SERVICO, presentation: false },
  ECM_USER: { profile: PERFIL_ACESSO.ECM_USER, presentation: false },
  UMA_AUTHORIZATION: { profile: PERFIL_ACESSO.UMA_AUTHORIZATION, presentation: false },
}

export const GRUPO_PERFIL = {
  ADMIN: 'Admin'
}

export const TIPO_PERFIL = {
  ROLE_ADMIN: [PERFIL_ACESSO.UMA_AUTHORIZATION]
}

export const MSG_HEADER = {
  LABEL_PERFIL: 'Selecione o Perfil:',
  LABEL_PERFIS: 'Perfis do Usuário:',
}

export const PROPERTY = {
  CO_UNIDADE: "co-unidade",
  CGC: "cgc",
  VINCULADAS: "vinculadas",
  USER: "user",
  APIKEY: "apikey",
  LOTACAO_FISICA: "nu-lotacaofisica"
}

export const EXTERNAL_RESOURCE = {
  searchAddress: '/informacoes-corporativas-publicas/v1/localidades/ceps/'
}

export const ALERT_MESSAGE_SUCCESS = 1;
export const ALERT_MESSAGE_INFO = 2;
export const ALERT_MESSAGE_ERROR = 3;
export const ALERT_MESSAGE_WARNING = 4;
export const DATA_HORA_VALIDADE = '12/12/2018';
export const ROLES = "roles";
export const PERFIL = "perfil";
export const INTERCEPTOR_SKIP_HEADER = 'X-Skip-Interceptor';

export const BROWSERS_NAME = {
  CHROME: "chrome",
  FIREFOX: "firefox"
}
export const PATH_NOT_SUPPORTED_PAGE = '/assets/browsers/not_supported.html';
export const MIN_FIREFOX_VERSION = 60;

