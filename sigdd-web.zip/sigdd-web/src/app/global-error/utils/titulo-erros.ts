export const TitulosError = {
    ERROR_JAVA_SCRIPT : "Error Javascript",
    ERROR_0 : { tipo : 0, descrica : "Servido não encontrado ", detalhe : "Verificar com suporte o motivo!", menssage: "Url não encontrada"}
}