import { Injectable, ErrorHandler } from '@angular/core';
import { ApplicationService } from '../services';
import { GlobalErrorComponentPresenter } from './presenter/global-error.component.presenter';

@Injectable()
export class GlobalErrorHandlerService implements ErrorHandler {

    constructor(private globalErrorPresenter: GlobalErrorComponentPresenter, private appService: ApplicationService) {}
    
    handleError(error: any) {
        this.globalErrorPresenter.montarListaDeErros(error, this.appService);  
    }
}