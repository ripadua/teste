export class Profile {
    profile: string;
    description: string;
    nickname: string;
    presentation: boolean;
}