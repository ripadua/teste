import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AuthGuard } from './guards';
import { LoginComponent } from './login';
import { TemplateComponent } from './template';


import {PaeContratacaoComponent} from './pae/contratacao/pae-contratacao.component';

const routes: Routes = [
  {
    path: '', component: TemplateComponent, canActivate: [AuthGuard], canActivateChild: [AuthGuard], children:
    [
      { path: 'inicio', component : PaeContratacaoComponent},

      { path: 'principal', component: PaeContratacaoComponent },

      { path: 'paeContratacao', component: PaeContratacaoComponent }
      
    ]
  },
  { path: 'login', component: LoginComponent },
  
    // otherwise redirect to home
  { path: '**', redirectTo: '' }
];


@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }