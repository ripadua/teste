import { MenuFilterPipe } from './menu-filter.pipe';

describe('MenuFilterPipe', () => {
  it('create an instance', () => {
    const pipe = new MenuFilterPipe();
    expect(pipe).toBeTruthy();
  });
});
