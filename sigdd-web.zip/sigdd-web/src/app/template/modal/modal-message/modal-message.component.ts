import { Component, OnInit } from '@angular/core';
import { SimpleModalComponent, SimpleModalService } from 'ngx-simple-modal';

export interface MessageModel {
  title:string;
  msgs:string[];
}

@Component({
  selector: 'cx-modal-message',
  templateUrl: './modal-message.component.html',
  styleUrls: ['./modal-message.component.css']
})
export class ModalMessageComponent extends SimpleModalComponent<MessageModel, boolean> implements MessageModel {
  title: string;
  msgs: string[];
  constructor(private simpleModalService: SimpleModalService) {
    super();
  }
  confirm() {
    // we set dialog result as true on click on confirm button, 
    // then we can get dialog result from caller code 
    this.result = true;
    this.close();
  }

}
