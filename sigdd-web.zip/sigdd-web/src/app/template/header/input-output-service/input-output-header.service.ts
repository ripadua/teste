import { Output, EventEmitter, Directive } from "@angular/core";

@Directive()
export abstract class InputOutputHeaderService {
    @Output() onChangeRoleChanged = new EventEmitter<any[]>();
    @Output() toogleSideBarEvent: EventEmitter<boolean> = new EventEmitter();
}