import { UserSIUSR } from "../../../model/user-siusr";
import { UserSSO } from '../../../model/user-sso';
import { MSG_HEADER, GRUPO_PERFIL, PERFIL_ACESSO } from "../../../constants/constants";
import { Profile } from "../../../services/model/profile.model";
export class Header {
    app: any = {};
    userSIUSR: UserSIUSR;
    userSSO: UserSSO;
    role : string;
    filtrosvalor: any = {};
    notificacoes: any[] = [];
    listaErroGlobal: any[] = [];
    userImage: any;
    userImageDefault: any;
    hasImage: boolean = false;
    currentView: any;
    toogleSidebar: boolean = false;
    labelPerfis: string = MSG_HEADER.LABEL_PERFIS;
    labelPerfil: string = MSG_HEADER.LABEL_PERFIL;
    labelAdmin: string = GRUPO_PERFIL.ADMIN;
    selectedRole: string;
    isMockRole: boolean;
    changeSelectedRole: string;
    presentationProfiles: Array<Profile>;
    withoutPresentationProfiles: Array<Profile>;
    cepModel: string;
    manuais: any[] = [
        { nome: 'Manual de Operação', url: '../../../assets/manual/operacao/site/index.html', roles: PERFIL_ACESSO.UMA_AUTHORIZATION },
        { nome: 'Manual de Integracao', url: '../../../assets/manual/integracao/site/index.html', roles: PERFIL_ACESSO.UMA_AUTHORIZATION }
    ];
}