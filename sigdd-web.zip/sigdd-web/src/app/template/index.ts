export * from './template.component';
export * from './header/view/header.component';
export * from './footer/footer.component';
export * from './menu/menu.component';
export * from './menu/menu-filter/menu-filter.pipe';
export * from './caixa-header-widget/caixa-header-widget.component';