/*
 * Copyright (c) 2019 Caixa Econômica Federal. Todos os direitos
 * reservados.
 *
 * Caixa Econômica Federal - SIACG - Sistema de Crédito Rural
 *
 * Este software foi desenvolvido sob demanda da CAIXA e está
 * protegido por leis de direitos autorais e tratados internacionais. As
 * condições de cópia e utilização do todo ou partes dependem de autorização da
 * empresa. Cópias não são permitidas sem expressa autorização. Não pode ser
 * comercializado ou utilizado para propósitos particulares.
 *
 * Uso exclusivo da Caixa Econômica Federal. A reprodução ou distribuição não
 * autorizada deste programa ou de parte dele, resultará em punições civis e
 * criminais e os infratores incorrem em sanções previstas na legislação em
 * vigor.
 *
 * Histórico do TFS:
 *
 * LastChangedRevision: $Revision$
 * LastChangedBy: $Author$
 * LastChangedDate: $Date$
 *
 * HeadURL: $HeadURL$
 *
 */	
package br.gov.caixa.siacg.view.form;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

import br.gov.caixa.pedesgo.arquitetura.util.UtilObjeto;
import br.gov.caixa.pedesgo.arquitetura.visao.ManutencaoVisao;
import br.gov.caixa.siacg.model.domain.Fornecedor;
import br.gov.caixa.siacg.model.domain.InstituicaoBancaria;
import br.gov.caixa.siacg.model.domain.TipoFornecedor;

/**
 * <p>FornecedorVisao</p>
 *
 * <p>Descrição: Descrição do tipo</p>
 *
 * <br><b>Empresa:</b> Cef - Caixa Econômica Federal
 *
 *
 * @author f799837
 *
 * @version 1.0
*/
public class FornecedorVisao  extends ManutencaoVisao<Fornecedor>{

    /** Atributo serialVersionUID. */
    private static final long serialVersionUID = 1L;
    
    /** Atributo de Fornecedor */
    private Fornecedor fornecedor; 
    
    private Fornecedor fornecedorParaInativar; 
    
    /** Atributo restricao abangencia. */
    private boolean restricaoAbangencia;
    
    /** Atributo lista Tipo Fornecedor */
    private Collection<TipoFornecedor> listaTipoFornecedor; 
    
    /** Atributo lista instituição Bancaria */
    private List<InstituicaoBancaria> listaInstituicaoBancaria;
    
    /** Atributo lista de Fornecedores */
    private List<Fornecedor>listaFornecedores;
    
    private boolean mostraDadosFornecedor;
    
    private TipoFornecedor tipoFornecedor;
    
    private TipoFornecedor tipoFornecedorParaInativar;
    

    /**
     * <p>Retorna o valor do atributo restricaoAbangencia</p>.
     *
     * @return restricaoAbangencia
    */
    public boolean isRestricaoAbangencia() {
	return this.restricaoAbangencia;
    }

    /**
     * <p>Define o valor do atributo restricaoAbangencia</p>.
     *
     * @param restricaoAbangencia valor a ser atribuído
    */
    public void setRestricaoAbangencia(boolean restricaoAbangencia) {
	this.restricaoAbangencia = restricaoAbangencia;
    }

    /**
     * <p>Retorna o valor do atributo listaTipoFornecedor</p>.
     *
     * @return listaTipoFornecedor
    */
    public Collection<TipoFornecedor> getListaTipoFornecedor() {
	if(!UtilObjeto.isReferencia(listaTipoFornecedor)) {
	    this.listaTipoFornecedor = new ArrayList<>();
	}
	return this.listaTipoFornecedor;
    }

    /**
     * <p>Define o valor do atributo listaTipoFornecedor</p>.
     *
     * @param listaTipoFornecedor valor a ser atribuído
    */
    public void setListaTipoFornecedor(Collection<TipoFornecedor> listaTipoFornecedor) {
	this.listaTipoFornecedor = listaTipoFornecedor;
    }

    /**
     * <p>Retorna o valor do atributo fornecedor</p>.
     *
     * @return fornecedor
    */
    public Fornecedor getFornecedor() {
	if(!UtilObjeto.isReferencia(this.fornecedor)) {
	    this.fornecedor = new Fornecedor();
	}
	return this.fornecedor;
    }

    /**
     * <p>Define o valor do atributo fornecedor</p>.
     *
     * @param fornecedor valor a ser atribuído
    */
    public void setFornecedor(Fornecedor fornecedor) {
	this.fornecedor = fornecedor;
    }

    /**
     * <p>Retorna o valor do atributo listaInstituicaoBancaria</p>.
     *
     * @return listaInstituicaoBancaria
    */
    public List<InstituicaoBancaria> getListaInstituicaoBancaria() {
	if(!UtilObjeto.isReferencia(listaInstituicaoBancaria)) {
	    this.listaInstituicaoBancaria = new ArrayList<>();
	}
	return this.listaInstituicaoBancaria;
    }

    /**
     * <p>Define o valor do atributo listaInstituicaoBancaria</p>.
     *
     * @param listaInstituicaoBancaria valor a ser atribuído
    */
    public void setListaInstituicaoBancaria(List<InstituicaoBancaria> listaInstituicaoBancaria) {
	this.listaInstituicaoBancaria = listaInstituicaoBancaria;
    }

    /**
     * <p>Retorna o valor do atributo listaFornecedores</p>.
     *
     * @return listaFornecedores
    */
    public List<Fornecedor> getListaFornecedores() {
	if(this.listaFornecedores == null) {
	    this.listaFornecedores = new ArrayList<>();
	}
	return this.listaFornecedores;
    }

    /**
     * <p>Define o valor do atributo listaFornecedores</p>.
     *
     * @param listaFornecedores valor a ser atribuído
    */
    public void setListaFornecedores(List<Fornecedor> listaFornecedores) {
	this.listaFornecedores = listaFornecedores;
    }

    /**
     * <p>Retorna o valor do atributo fornecedorParaInativar</p>.
     *
     * @return fornecedorParaInativar
    */
    public Fornecedor getFornecedorParaInativar() {
	if(this.fornecedorParaInativar == null) {
	    this.fornecedorParaInativar = new Fornecedor();
	}
	return this.fornecedorParaInativar;
    }

    /**
     * <p>Define o valor do atributo fornecedorParaInativar</p>.
     *
     * @param fornecedorParaInativar valor a ser atribuído
    */
    public void setFornecedorParaInativar(Fornecedor fornecedorParaInativar) {
	this.fornecedorParaInativar = fornecedorParaInativar;
    }

	public boolean isMostraDadosFornecedor() {
		return mostraDadosFornecedor;
	}

	public void setMostraDadosFornecedor(boolean mostraDadosFornecedor) {
		this.mostraDadosFornecedor = mostraDadosFornecedor;
	}

	public TipoFornecedor getTipoFornecedor() {
		if(this.tipoFornecedor == null) {
		    this.tipoFornecedor = new TipoFornecedor();
		    this.tipoFornecedor.setIcSituacao(true);
		}
		return tipoFornecedor;
	}

	public void setTipoFornecedor(TipoFornecedor tipoFornecedor) {
		this.tipoFornecedor = tipoFornecedor;
	}

	public TipoFornecedor getTipoFornecedorParaInativar() {
		if(this.tipoFornecedorParaInativar == null) {
		    this.tipoFornecedorParaInativar = new TipoFornecedor();
		}
		return tipoFornecedorParaInativar;
	}

	public void setTipoFornecedorParaInativar(TipoFornecedor tipoFornecedorParaInativar) {
		this.tipoFornecedorParaInativar = tipoFornecedorParaInativar;
	}

}
