/*
 * Copyright (c) 2016 Caixa Econômica Federal. Todos os direitos
 * reservados.
 *
 * Caixa Econômica Federal - SIACG_dev
 *
 * Este software foi desenvolvido sob demanda da CAIXA e está
 * protegido por leis de direitos autorais e tratados internacionais. As
 * condições de cópia e utilização do todo ou partes dependem de autorização da
 * pessoa. Cópias não são permitidas sem expressa autorização. Não pode ser
 * comercializado ou utilizado para propósitos particulares.
 *
 * Uso exclusivo da Caixa Econômica Federal. A reprodução ou distribuição não
 * autorizada deste programa ou de parte dele, resultará em punições civis e
 * criminais e os infratores incorrem em sanções previstas na legislação em
 * vigor.
 *
 * Histórico do Subversion:
 *
 * LastChangedRevision: $Revision$
 * LastChangedBy: $Author$
 * LastChangedDate: $Date$
 *
 * HeadURL: $HeadURL$
 *
 */
package br.gov.caixa.siacg.view.form;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

import javax.faces.component.UIComponent;
import javax.faces.component.html.HtmlPanelGrid;

import br.gov.caixa.pedesgo.arquitetura.util.UtilObjeto;
import br.gov.caixa.pedesgo.arquitetura.visao.ManutencaoVisao;
import br.gov.caixa.siacg.comum.to.PainelGarantiaTO;
import br.gov.caixa.siacg.model.domain.DWAnaliseContrato;
import br.gov.caixa.siacg.model.domain.Segmento;
import br.gov.caixa.siacg.model.vo.SrVO;
import br.gov.caixa.siacg.model.vo.UnidadeVO;
import br.gov.caixa.siacg.view.mb.PainelGarantiaMB;

/**
 * <p>
 * PainelGarantiaVisao.
 * </p>
 * <p>
 * Descrição: Classe de visao auxiliar da classe bean {@link PainelGarantiaMB}
 * responsável por armazenar os objetos utilizados em tela.
 * </p>
 * <br>
 * <b>Empresa:</b> Cef - Caixa Econômica Federal
 *
 * @author Bruno Martins de Carvalho
 * @version 1.0
 */
public class PainelGarantiaVisao extends ManutencaoVisao<DWAnaliseContrato> {

    /** serialVersionUID. */
    private static final long serialVersionUID = -3448719543882161088L;

    /** contratosNoventaCincoMaisConstituido. */
    private List<PainelGarantiaTO> contratosNoventaCincoMaisConstituido;
    /** contratosNoventaCincoMenosSeteDiasConstituido. */
    private List<PainelGarantiaTO> contratosNoventaCincoMenosSeteDiasConstituido;
    /** contratosNoventaCincoMaisSeteDiasConstituido. */
    private List<PainelGarantiaTO> contratosNoventaCincoMaisSeteDiasConstituido;
    /** contratosGarantiasNaoConstituidas. */
    private List<PainelGarantiaTO> contratosGarantiasNaoConstituidas;
    /** contratosNaoParametrizados. */
    private List<PainelGarantiaTO> contratosNaoParametrizados;
    /** contratosNaoAcompanhados. */
    private List<PainelGarantiaTO> contratosNaoAcompanhados;

    /** Atributo segmento list. */
    private Collection<Segmento> segmentoList;

    /** Atributo suat list. */
    private Collection<UnidadeVO> suatList;

    /** Atributo sr list. */
    private Collection<SrVO> srList;

    /** Atributo unidade list. */
    private Collection<UnidadeVO> unidadeList;

    /** listaColunas. */
    private transient List<UIComponent> listaColunas = new ArrayList<>(0);
    /** panelGrid. */
    private transient HtmlPanelGrid panelGrid;

    /** Atributo filtro. */
    private PainelGarantiaTO filtro;

    /** Atributo exibir gestor caixa. */
    private boolean exibeGestorCaixa;

    /** Atributo nivel de consulta. **/
    private String nivelConsulta;

    /** Atributo código identificador. */
    private String coIdentificador;

    /** Atributo tituloGrid. */
    private String tituloGrid;

    /** Atributo nu segmento. */
    private Integer nuSegmento;

    /** totalContratos. */
    private BigDecimal vrTotalConstituido;

    /**
     * Retorna o valor do atributo contratosNoventaCincoMaisConstituido.
     *
     * @return contratosNoventaCincoMaisConstituido
     */
    public List<PainelGarantiaTO> getContratosNoventaCincoMaisConstituido() {
        if (!UtilObjeto.isReferencia(this.contratosNoventaCincoMaisConstituido)) {
            this.contratosNoventaCincoMaisConstituido = new ArrayList<>();
        }
        return this.contratosNoventaCincoMaisConstituido;
    }

    /**
     * Define o valor do atributo contratosNoventaCincoMaisConstituido.
     *
     * @param contratosNoventaCincoMaisConstituido
     *            valor a ser atribuído
     */
    public void setContratosNoventaCincoMaisConstituido(final List<PainelGarantiaTO> contratosNoventaCincoMaisConstituido) {
        this.contratosNoventaCincoMaisConstituido = contratosNoventaCincoMaisConstituido;
    }

    /**
     * Retorna o valor do atributo
     * contratosNoventaCincoMenosSeteDiasConstituido.
     *
     * @return contratosNoventaCincoMenosSeteDiasConstituido
     */
    public List<PainelGarantiaTO> getContratosNoventaCincoMenosSeteDiasConstituido() {
        if (!UtilObjeto.isReferencia(this.contratosNoventaCincoMenosSeteDiasConstituido)) {
            this.contratosNoventaCincoMenosSeteDiasConstituido = new ArrayList<>();
        }
        return this.contratosNoventaCincoMenosSeteDiasConstituido;
    }

    /**
     * Define o valor do atributo contratosNoventaCincoMenosSeteDiasConstituido.
     *
     * @param contratosNoventaCincoMenosSeteDiasConstituido
     *            valor a ser atribuído
     */
    public void setContratosNoventaCincoMenosSeteDiasConstituido(final List<PainelGarantiaTO> contratosNoventaCincoMenosSeteDiasConstituido) {
        this.contratosNoventaCincoMenosSeteDiasConstituido = contratosNoventaCincoMenosSeteDiasConstituido;
    }

    /**
     * Retorna o valor do atributo contratosNoventaCincoMaisSeteDiasConstituido.
     *
     * @return contratosNoventaCincoMaisSeteDiasConstituido
     */
    public List<PainelGarantiaTO> getContratosNoventaCincoMaisSeteDiasConstituido() {
        if (!UtilObjeto.isReferencia(this.contratosNoventaCincoMaisSeteDiasConstituido)) {
            this.contratosNoventaCincoMaisSeteDiasConstituido = new ArrayList<>();
        }
        return this.contratosNoventaCincoMaisSeteDiasConstituido;
    }

    /**
     * Define o valor do atributo contratosNoventaCincoMaisSeteDiasConstituido.
     *
     * @param contratosNoventaCincoMaisSeteDiasConstituido
     *            valor a ser atribuído
     */
    public void setContratosNoventaCincoMaisSeteDiasConstituido(final List<PainelGarantiaTO> contratosNoventaCincoMaisSeteDiasConstituido) {
        this.contratosNoventaCincoMaisSeteDiasConstituido = contratosNoventaCincoMaisSeteDiasConstituido;
    }

    /**
     * Retorna o valor do atributo contratosNaoAcompanhados.
     *
     * @return contratosNaoAcompanhados
     */
    public List<PainelGarantiaTO> getContratosNaoAcompanhados() {
        if (!UtilObjeto.isReferencia(this.contratosNaoAcompanhados)) {
            this.contratosNaoAcompanhados = new ArrayList<>();
        }
        return this.contratosNaoAcompanhados;
    }

    /**
     * Define o valor do atributo contratosNaoAcompanhados.
     *
     * @param contratosNaoAcompanhados
     *            valor a ser atribuído
     */
    public void setContratosNaoAcompanhados(final List<PainelGarantiaTO> contratosNaoAcompanhados) {
        this.contratosNaoAcompanhados = contratosNaoAcompanhados;
    }

    /**
     * Retorna o valor do atributo contratosNaoParametrizados.
     *
     * @return contratosNaoParametrizados
     */
    public List<PainelGarantiaTO> getContratosNaoParametrizados() {
        if (!UtilObjeto.isReferencia(this.contratosNaoParametrizados)) {
            this.contratosNaoParametrizados = new ArrayList<>();
        }
        return this.contratosNaoParametrizados;
    }

    /**
     * Define o valor do atributo contratosNaoParametrizados.
     *
     * @param contratosNaoParametrizados
     *            valor a ser atribuído
     */
    public void setContratosNaoParametrizados(final List<PainelGarantiaTO> contratosNaoParametrizados) {
        this.contratosNaoParametrizados = contratosNaoParametrizados;
    }

    /**
     * Retorna o valor do atributo suatList.
     *
     * @return suatList
     */
    public Collection<UnidadeVO> getSuatList() {
        return this.suatList;
    }

    /**
     * Define o valor do atributo suatList.
     *
     * @param suatList
     *            valor a ser atribuído
     */
    public void setSuatList(final Collection<UnidadeVO> suatList) {
        this.suatList = suatList;
    }

    /**
     * Retorna o valor do atributo exibeGestorCaixa.
     *
     * @return exibeGestorCaixa
     */
    public boolean isExibeGestorCaixa() {
        return this.exibeGestorCaixa;
    }

    /**
     * Define o valor do atributo exibeGestorCaixa.
     *
     * @param exibeGestorCaixa
     *            valor a ser atribuído
     */
    public void setExibeGestorCaixa(final boolean exibeGestorCaixa) {
        this.exibeGestorCaixa = exibeGestorCaixa;
    }

    /**
     * Retorna o valor do atributo nivelConsulta.
     *
     * @return nivelConsulta
     */
    public String getNivelConsulta() {
        return this.nivelConsulta;
    }

    /**
     * Define o valor do atributo nivelConsulta.
     *
     * @param nivelConsulta
     *            valor a ser atribuído
     */
    public void setNivelConsulta(final String nivelConsulta) {
        this.nivelConsulta = nivelConsulta;
    }

    /**
     * Retorna o valor do atributo nuSegmento.
     *
     * @return nuSegmento
     */
    public Integer getNuSegmento() {
        return this.nuSegmento;
    }

    /**
     * Define o valor do atributo nuSegmento.
     *
     * @param nuSegmento
     *            valor a ser atribuído
     */
    public void setNuSegmento(final Integer nuSegmento) {
        this.nuSegmento = nuSegmento;
    }

    /**
     * Retorna o valor do atributo coIdentificador.
     *
     * @return coIdentificador
     */
    public String getCoIdentificador() {
        return this.coIdentificador;
    }

    /**
     * Define o valor do atributo coIdentificador.
     *
     * @param coIdentificador
     *            valor a ser atribuído
     */
    public void setCoIdentificador(final String coIdentificador) {
        this.coIdentificador = coIdentificador;
    }

    /**
     * Retorna o valor do atributo listaColunas.
     *
     * @return listaColunas
     */
    public List<UIComponent> getListaColunas() {
        if (this.listaColunas.isEmpty()) {
            this.listaColunas = this.getPanelGrid().getChildren();
        }
        return this.listaColunas;
    }

    /**
     * Define o valor do atributo listaColunas.
     *
     * @param listaColunas
     *            valor a ser atribuído
     */
    public void setListaColunas(final List<UIComponent> listaColunas) {
        this.listaColunas = listaColunas;
    }

    /**
     * Retorna o valor do atributo panelGrid.
     *
     * @return panelGrid
     */
    public HtmlPanelGrid getPanelGrid() {
        return this.panelGrid;
    }

    /**
     * Define o valor do atributo panelGrid.
     *
     * @param panelGrid
     *            valor a ser atribuído
     */
    public void setPanelGrid(final HtmlPanelGrid panelGrid) {
        this.panelGrid = panelGrid;
    }

    /**
     * Retorna o valor do atributo filtro.
     *
     * @return filtro
     */
    public PainelGarantiaTO getFiltro() {
        if (!UtilObjeto.isReferencia(this.filtro)) {
            this.filtro = new PainelGarantiaTO();
        }
        return this.filtro;
    }

    /**
     * Define o valor do atributo filtro.
     *
     * @param filtro
     *            valor a ser atribuído
     */
    public void setFiltro(final PainelGarantiaTO filtro) {
        this.filtro = filtro;
    }

    /**
     * Retorna o valor do atributo tituloGrid.
     *
     * @return tituloGrid
     */
    public String getTituloGrid() {
        return this.tituloGrid;
    }

    /**
     * Define o valor do atributo tituloGrid.
     *
     * @param tituloGrid
     *            valor a ser atribuído
     */
    public void setTituloGrid(final String tituloGrid) {
        this.tituloGrid = tituloGrid;
    }

    /**
     * Retorna o valor do atributo srList.
     *
     * @return srList
     */
    public Collection<SrVO> getSrList() {
        return this.srList;
    }

    /**
     * Define o valor do atributo srList.
     *
     * @param srList
     *            valor a ser atribuído
     */
    public void setSrList(final Collection<SrVO> srList) {
        this.srList = srList;
    }

    /**
     * Retorna o valor do atributo unidadeList.
     *
     * @return unidadeList
     */
    public Collection<UnidadeVO> getUnidadeList() {
        return this.unidadeList;
    }

    /**
     * Define o valor do atributo unidadeList.
     *
     * @param unidadeList
     *            valor a ser atribuído
     */
    public void setUnidadeList(final Collection<UnidadeVO> unidadeList) {
        this.unidadeList = unidadeList;
    }

    /**
     * Retorna o valor do atributo segmentoList.
     *
     * @return segmentoList
     */
    public Collection<Segmento> getSegmentoList() {
        return this.segmentoList;
    }

    /**
     * Define o valor do atributo segmentoList.
     *
     * @param segmentoList
     *            valor a ser atribuído
     */
    public void setSegmentoList(final Collection<Segmento> segmentoList) {
        this.segmentoList = segmentoList;
    }

    /**
     * Retorna o valor do atributo vrTotalConstituido.
     *
     * @return vrTotalConstituido
     */
    public BigDecimal getVrTotalConstituido() {
        return this.vrTotalConstituido;
    }

    /**
     * Define o valor do atributo vrTotalConstituido.
     *
     * @param vrTotalConstituido
     *            valor a ser atribuído
     */
    public void setVrTotalConstituido(final BigDecimal vrTotalConstituido) {
        this.vrTotalConstituido = vrTotalConstituido;
    }

    /**
     * Retorna o valor do atributo contratosGarantiasNaoConstituidas.
     *
     * @return contratosGarantiasNaoConstituidas
     */
    public List<PainelGarantiaTO> getContratosGarantiasNaoConstituidas() {
        if (!UtilObjeto.isReferencia(this.contratosGarantiasNaoConstituidas)) {
            this.contratosGarantiasNaoConstituidas = new ArrayList<>();
        }
        return this.contratosGarantiasNaoConstituidas;
    }

    /**
     * Define o valor do atributo contratosGarantiasNaoConstituidas.
     *
     * @param contratosGarantiasNaoConstituidas
     *            valor a ser atribuído
     */
    public void setContratosGarantiasNaoConstituidas(final List<PainelGarantiaTO> contratosGarantiasNaoConstituidas) {
        this.contratosGarantiasNaoConstituidas = contratosGarantiasNaoConstituidas;
    }
}
