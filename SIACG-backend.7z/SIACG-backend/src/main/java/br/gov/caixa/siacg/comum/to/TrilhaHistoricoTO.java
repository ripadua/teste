package br.gov.caixa.siacg.comum.to;

import java.io.Serializable;
import java.util.Date;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

/**
 * <p>
 * TrilhaHistoricoTO.
 * </p>
 * <p>
 * Descrição: TrilhaHistoricoTO
 * </p>
 * <br>
 * <b>Empresa:</b> Cef - Caixa Econômica Federal
 *
 * @version 1.0
 */
@JsonIgnoreProperties(ignoreUnknown = true)
public class TrilhaHistoricoTO implements Serializable{

    /** Atributo serialVersionUID. */
    private static final long serialVersionUID = 3848085767584663810L;
    /** Atributo tabela. */
    private String tabela;
    /** Atributo operacao. */
    private String operacao;
    /** Atributo respOperacao. */
    private String respOperacao;
    /** Atributo dataInicioConsulta. */
    private Date dataInicioConsulta;
    /** Atributo dataFimConsulta. */
    private Date dataFimConsulta;
    /** Atributo deItem. */
    private String deItem;

    /**
     *
     * Construtor.
     *
     */
    public TrilhaHistoricoTO() {
        super();
    }

    /**
     *
     * <p>
     * Método responsável por retornar atributo.
     * <p>
     *
     * @return tabela
     * @author robson.oliveira
     */
    public String getTabela() {
        if (this.tabela == null) {
            this.tabela = "";
        }
        return this.tabela;
    }

    /**
     *
     * <p>
     * Método responsável por atribuir.
     * <p>
     *
     * @param tabela
     *            valor a ser atribuido
     * @author robson.oliveira
     */
    public void setTabela(final String tabela) {
        this.tabela = tabela;
    }

    /**
     *
     * <p>
     * Método responsável por retornar atributo.
     * <p>
     *
     * @return operacao
     * @author robson.oliveira
     */
    public String getOperacao() {
        if (this.operacao == null) {
            this.operacao = "";
        }
        return this.operacao;
    }

    /**
     *
     * <p>
     * Método responsável por atribuir.
     * <p>
     *
     * @param operacao
     *            valor a ser atribuido
     * @author robson.oliveira
     */
    public void setOperacao(final String operacao) {
        this.operacao = operacao;
    }

    /**
     *
     * <p>
     * Método responsável por retornar atributo.
     * <p>
     *
     * @return respOperacao
     * @author robson.oliveira
     */
    public String getRespOperacao() {
        if (this.respOperacao == null) {
            this.respOperacao = "";
        }
        return this.respOperacao;
    }

    /**
     *
     * <p>
     * Método responsável por atribuir.
     * <p>
     *
     * @param respOperacao
     *            valor a ser atribuido
     * @author robson.oliveira
     */
    public void setRespOperacao(final String respOperacao) {
        this.respOperacao = respOperacao;
    }

    /**
     *
     * <p>
     * Método responsável por retornar atributo.
     * <p>
     *
     * @return dataInicioConsulta
     * @author robson.oliveira
     */
    public Date getDataInicioConsulta() {
        return this.dataInicioConsulta;
    }

    /**
     *
     * <p>
     * Método responsável por atribuir.
     * <p>
     *
     * @param dataInicioConsulta
     *            valor a ser atribuido
     * @author robson.oliveira
     */
    public void setDataInicioConsulta(final Date dataInicioConsulta) {
        this.dataInicioConsulta = dataInicioConsulta;
    }

    /**
     *
     * <p>
     * Método responsável por retornar atributo.
     * <p>
     *
     * @return dataFimConsulta
     * @author robson.oliveira
     */
    public Date getDataFimConsulta() {
        return this.dataFimConsulta;
    }

    /**
     *
     * <p>
     * Método responsável por atribuir.
     * <p>
     *
     * @param dataFimConsulta
     *            valor a ser atribuido
     * @author robson.oliveira
     */
    public void setDataFimConsulta(final Date dataFimConsulta) {
        this.dataFimConsulta = dataFimConsulta;
    }

    /**
     *
     * <p>
     * Método responsável por verificar o atributo.
     * <p>
     *
     * @param atributo
     *            valor a ser atribuido
     * @return String
     * @author robson.oliveira
     */
    public String verificarAtributo(final String atributo) {
        return atributo == null || atributo.contentEquals("") ? null : atributo;
    }

    /**
     * <p>Retorna o valor do atributo deItem</p>.
     *
     * @return deItem
    */
    public String getDeItem() {
        return this.deItem;
    }

    /**
     * <p>Define o valor do atributo deItem</p>.
     *
     * @param deItem valor a ser atribuído
    */
    public void setDeItem(String deItem) {
        this.deItem = deItem;
    }
    
}
