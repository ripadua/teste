package br.gov.caixa.siacg.view.form;

import java.util.Collection;

import br.gov.caixa.siacg.model.domain.Cedente;
import br.gov.caixa.siacg.model.domain.Sacado;
import br.gov.caixa.siacg.model.enums.AbrangenciaSacadoEnum;
import br.gov.caixa.siacg.model.enums.TipoPessoaEnum;

/**
 * <p>
 * AnaliseVisao
 * </p>
 * <p>
 * Descrição: Classe responsável por armazenar os dados da visão do caso de uso
 * <code>Sacado</code>.
 * </p>
 * <br>
 * <b>Empresa:</b> Cef - Caixa Econômica Federal
 *
 * @author Waltenes Junior
 * @version 1.0
 */
public class SacadoVisao extends TemplateVisao<Sacado> {

    private static final long serialVersionUID = -5489453417047177890L;

    private Collection<TipoPessoaEnum> listaTipoPessoa;

    private Collection<AbrangenciaSacadoEnum> listaAbrangenciaSacadoEnum;

    private boolean edicao;

    private boolean renderizaBotaoEdita;

    private boolean renderizaBotaoInclui;

    private Cedente cedente;

    private Cedente cedenteParaRemover;

    private Sacado sacadoParaExcluir;

    /**
     * Retorna o valor do atributo listaTipoPessoa.
     *
     * @return <code>listaTipoPessoa</code>
     */
    public Collection<TipoPessoaEnum> getListaTipoPessoa() {
        return this.listaTipoPessoa;
    }

    /**
     * Define o valor do atributo listaTipoPessoa.
     *
     * @param listaTipoPessoa
     *            valor a ser atribuído
     */
    public void setListaTipoPessoa(final Collection<TipoPessoaEnum> listaTipoPessoa) {
        this.listaTipoPessoa = listaTipoPessoa;
    }

    /**
     * Retorna o valor do atributo edicao.
     *
     * @return <code>edicao</code>
     */
    public boolean isEdicao() {
        return this.edicao;
    }

    /**
     * Define o valor do atributo edicao.
     *
     * @param edicao
     *            valor a ser atribuído
     */
    public void setEdicao(final boolean edicao) {
        this.edicao = edicao;
    }

    /**
     * Retorna o valor do atributo renderizaBotaoEdita.
     *
     * @return renderizaBotaoEdita
     */
    public boolean isRenderizaBotaoEdita() {
        return this.renderizaBotaoEdita;
    }

    /**
     * Define o valor do atributo renderizaBotaoEdita.
     *
     * @param renderizaBotaoEdita
     *            valor a ser atribuído
     */
    public void setRenderizaBotaoEdita(final boolean renderizaBotaoEdita) {
        this.renderizaBotaoEdita = renderizaBotaoEdita;
    }

    /**
     * Retorna o valor do atributo renderizaBotaoInclui.
     *
     * @return renderizaBotaoInclui
     */
    public boolean isRenderizaBotaoInclui() {
        return this.renderizaBotaoInclui;
    }

    /**
     * Define o valor do atributo renderizaBotaoInclui.
     *
     * @param renderizaBotaoInclui
     *            valor a ser atribuído
     */
    public void setRenderizaBotaoInclui(final boolean renderizaBotaoInclui) {
        this.renderizaBotaoInclui = renderizaBotaoInclui;
    }

    /**
     * Retorna o valor do atributo listaAbrangenciaSacadoEnum.
     *
     * @return listaAbrangenciaSacadoEnum
     */
    public Collection<AbrangenciaSacadoEnum> getListaAbrangenciaSacadoEnum() {

        return this.listaAbrangenciaSacadoEnum;
    }

    /**
     * Define o valor do atributo listaAbrangenciaSacadoEnum.
     *
     * @param listaAbrangenciaSacadoEnum
     *            valor a ser atribuído
     */
    public void setListaAbrangenciaSacadoEnum(final Collection<AbrangenciaSacadoEnum> listaAbrangenciaSacadoEnum) {

        this.listaAbrangenciaSacadoEnum = listaAbrangenciaSacadoEnum;
    }

    /**
     * Retorna o valor do atributo cedente.
     *
     * @return cedente
     */
    public Cedente getCedente() {

        return this.cedente;
    }

    /**
     * Define o valor do atributo cedente.
     *
     * @param cedente
     *            valor a ser atribuído
     */
    public void setCedente(final Cedente cedente) {

        this.cedente = cedente;
    }

    /**
     * Retorna o valor do atributo cedenteParaRemover.
     *
     * @return cedenteParaRemover
     */
    public Cedente getCedenteParaRemover() {

        return this.cedenteParaRemover;
    }

    /**
     * Define o valor do atributo cedenteParaRemover.
     *
     * @param cedenteParaRemover
     *            valor a ser atribuído
     */
    public void setCedenteParaRemover(final Cedente cedenteParaRemover) {

        this.cedenteParaRemover = cedenteParaRemover;
    }

    /**
     * Retorna o valor do atributo sacadoParaExcluir.
     *
     * @return sacadoParaExcluir
     */
    public Sacado getSacadoParaExcluir() {

        return this.sacadoParaExcluir;
    }

    /**
     * Define o valor do atributo sacadoParaExcluir.
     *
     * @param sacadoParaExcluir
     *            valor a ser atribuído
     */
    public void setSacadoParaExcluir(final Sacado sacadoParaExcluir) {

        this.sacadoParaExcluir = sacadoParaExcluir;
    }
}
