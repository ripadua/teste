/**
 * reservados. Copyright (c) 2009-2011 Caixa Econômica Federal. Todos os direitos
 *
 * Caixa Econômica Federal - SIACG – Sistema de Acompanhamento de Carteiras de Cobrança
 *
 * Este programa de computador foi desenvolvido sob demanda da CAIXA e está protegido por leis de direitos autorais e
 * tratados internacionais. As condições de cópia e utilização do todo ou partes dependem de autorização da pessoa.
 * Cópias não são permitidas sem expressa autorização. Não pode ser comercializado ou utilizado para propósitos
 * particulares.
 *
 * Uso exclusivo da Caixa Econômica Federal. A reprodução ou distribuição não autorizada deste programa ou de parte
 * dele, resultará em punições civis e criminais e os infratores incorrem em sanções previstas na legislação em vigor.
 *
 * Histórico do Subversion:
 *
 * LastChangedRevision: LastChangedBy: LastChangedDate:
 *
 * HeadURL:
 *
 */
package br.gov.caixa.siacg.view.mb;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import javax.annotation.PostConstruct;
import javax.ejb.EJB;
import javax.enterprise.context.SessionScoped;
import javax.faces.context.FacesContext;
import javax.inject.Inject;
import javax.inject.Named;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang.StringUtils;
import org.primefaces.component.datatable.DataTable;
import org.primefaces.context.RequestContext;

import br.gov.caixa.pedesgo.arquitetura.controlador.ManutencaoBean;
import br.gov.caixa.pedesgo.arquitetura.enumerador.EnumAcao;
import br.gov.caixa.pedesgo.arquitetura.enumerador.EnumNomeAbrangenciaRestritaUnidade;
import br.gov.caixa.pedesgo.arquitetura.enumerador.EnumTipoAbrangencia;
import br.gov.caixa.pedesgo.arquitetura.enums.EnumExtensaoArquivo;
import br.gov.caixa.pedesgo.arquitetura.relatorio.UtilRelatorio;
import br.gov.caixa.pedesgo.arquitetura.util.LogCefUtil;
import br.gov.caixa.pedesgo.arquitetura.util.ScopoUtil;
import br.gov.caixa.pedesgo.arquitetura.util.UsuarioUtil;
import br.gov.caixa.pedesgo.arquitetura.util.UtilNumero;
import br.gov.caixa.pedesgo.arquitetura.util.UtilObjeto;
import br.gov.caixa.pedesgo.arquitetura.util.UtilString;
import br.gov.caixa.siacg.exception.ParametrosInvalidosException;
import br.gov.caixa.siacg.model.domain.Contrato;
import br.gov.caixa.siacg.model.domain.DWAnaliseContrato;
import br.gov.caixa.siacg.model.domain.OperacaoSistema;
import br.gov.caixa.siacg.model.domain.Segmento;
import br.gov.caixa.siacg.model.enums.NoFuncionalidadeEnum;
import br.gov.caixa.siacg.model.enums.SituacaoContratoEnum;
import br.gov.caixa.siacg.model.enums.StatusGarantiaSuficienteEnum;
import br.gov.caixa.siacg.model.vo.ContratoParametrizadoVO;
import br.gov.caixa.siacg.model.vo.FiltroAnaliseCarteiraVO;
import br.gov.caixa.siacg.model.vo.SrEUnidadeVO;
import br.gov.caixa.siacg.model.vo.SrVO;
import br.gov.caixa.siacg.model.vo.UnidadeVO;
import br.gov.caixa.siacg.pagination.ContratoParametrizadoLazyModel;
import br.gov.caixa.siacg.service.ContratoService;
import br.gov.caixa.siacg.service.DWAnaliseContratoService;
import br.gov.caixa.siacg.service.GrupoGarantiaService;
import br.gov.caixa.siacg.service.OperacaoSistemaService;
import br.gov.caixa.siacg.service.PropriedadeService;
import br.gov.caixa.siacg.service.SegmentoService;
import br.gov.caixa.siacg.service.SuatService;
import br.gov.caixa.siacg.service.UnidadeService;
import br.gov.caixa.siacg.service.UnidadeVinculadaSuatService;
import br.gov.caixa.siacg.util.CalculadoraInadimplenciaUtil;
import br.gov.caixa.siacg.util.ContratoUtil;
import br.gov.caixa.siacg.util.LogCEF;
import br.gov.caixa.siacg.view.form.AnaliseVisao;
import br.gov.caixa.siacg.view.form.RelatorioAnaliseVisao;

/**
 * <p>
 * AnaliseMB
 * </p>
 * <p>
 * Descrição: Managed bean do caso de uso <code>Análise de carteira</code>.
 * </p>
 * <br>
 * <b>Empresa:</b> Cef - Caixa Econômica Federal
 *
 * @author joseroberto@gsgroup.com.br
 * @version 1.0
 */
@Named
@SessionScoped
public class AnaliseMB extends ManutencaoBean<Contrato> {

	private static final long serialVersionUID = 509553705294132803L;

	/** Atributo NOME_MANAGED_BEAN. */
	public static final String NOME_MANAGED_BEAN = "analiseMB";

	/** Atributo EL_MANAGED_BEAN. */
	public static final String EL_MANAGED_BEAN = "#{analiseMB}";

	/** Atributo PAGINA_INICIAL. */
	private static final String PAGINA_INICIAL = "/pages/index.xhtml";

	/** Atributo PAGINA_ANALISE_GARANTIA. */
	private static final String PAGINA_ANALISE_GARANTIA = "/pages/analise/analiseGarantia.xhtml?faces-redirect=true";

	/** Atributo RELATORIO_CONTRATOS_PARAM. */
	private static final String RELATORIO_CONTRATOS_PARAM = "Contratos-Parametrizados";

	/** Atributo IMAGEM_CAIXA_LOGO. */
	private static final String IMAGEM_CAIXA_LOGO = "/resources/img/caixa_logo.jpg";

	/** Atributo CAMINHO_RELATORIO. */
	private static final String CAMINHO_RELATORIO = "/reports/";

	/** Atributo NOME_JASPER_CONTRATO_PARAMETRIZADO. */
	private static final String NOME_JASPER_CONTRATO_PARAMETRIZADO = "contrato_parametrizado.jasper";

	/** Atributo MAPA_OPERACAO_SISTEMA. */
	private static final String MAPA_OPERACAO_SISTEMA = "mapaOperacaoSistema";

	/** Atributo Lista de Seguimento */
	private static final String LISTA_SEGUIMENTO = "listaSegmento";
	
	private static final String UNIDADE = "unidade";	

	private static final Integer HIERARQUIA=1;

	@Inject
	private ContratoService service;

	/** Atributo unidadeService. */
	@EJB
	private transient UnidadeService unidadeService;

	/** Atributo unidadeVinculadaSuatService. */
	@EJB
	private transient UnidadeVinculadaSuatService unidadeVinculadaSuatService;
	
	@Inject
	private DWAnaliseContratoService dwAnaliseContratoService;

	/** Atributo suatService. */
	@EJB
	private transient SuatService suatService;

	/** Atributo visao. */
	private AnaliseVisao visao;
	
	@EJB
	private transient PropriedadeService propriedadeService;
	
	/** Atributo paginacaoContratoParametrizado. */
	@Inject
	private ContratoParametrizadoLazyModel paginacaoContratoParametrizado;

	/** Atributo parametrizacaoContratoMB. */
	@Inject
	private ParametrizacaoContratoMB parametrizacaoContratoMB;

	/** Atributo relatorioAnaliseMB. */
	@Inject
	private RelatorioAnaliseMB relatorioAnaliseMB;
	
	@Inject
	private GrupoGarantiaService grupoGarantiaService;
	
	@Inject
	private OperacaoSistemaService operacaoSistemaService;
	
	@Inject
	private SegmentoService segmentoService;

	/**
	 * <p>
	 * Método responsável por construir o bread crumb para usuário e configurar
	 * valor do filtro usado na aplicação.
	 * </p>
	 *
	 * @author joseroberto@gsgroup.com.br
	 * @author Waltenes Junior
	 */
	@PostConstruct
	public void inicializar() {

		final FacesContext contexto = FacesContext.getCurrentInstance();

		if (UtilObjeto.isReferencia(contexto) && this.possuiPeloMenosUmaPermissaoDePainel()) {

			final String unidadeUsuario = super.getUnidadeUsuario();

			if (!UtilString.isVazio(unidadeUsuario)) {

				final Integer nuUnidadeusuarioLogado = Integer.valueOf(unidadeUsuario);

				if (UtilObjeto.isReferencia(nuUnidadeusuarioLogado)) {

					if (UsuarioUtil.contemPermissao(NoFuncionalidadeEnum.CONSULTA_UNIDADE.getNoFuncionalidade(), EnumAcao.CONSULTAR.getNoAcao(),
							EnumTipoAbrangencia.RESTRITA_UNIDADE.getTipoAbrangencia(),
							EnumNomeAbrangenciaRestritaUnidade.TODAS.getNomeAbrangencia())) {

						this.getVisao().setSuatList(this.unidadeVinculadaSuatService.listarSuats());
						this.visao.setExibirGestorCaixa(true);
						this.visao.setExibirBotaoXLS(Boolean.TRUE);
						this.visao.setNivelConsulta("CAIXA");

					} else if (UsuarioUtil.contemPermissao(NoFuncionalidadeEnum.CONSULTA_UNIDADE.getNoFuncionalidade(),
							EnumAcao.CONSULTAR.getNoAcao(), EnumTipoAbrangencia.RESTRITA_UNIDADE.getTipoAbrangencia(),
							EnumNomeAbrangenciaRestritaUnidade.VINCULADAS.getNomeAbrangencia())) {

						this.construirBreadCrumbGestorRegional(nuUnidadeusuarioLogado);
						this.visao.setExibirGestorRegional(true);
						this.visao.setExibirColunaSR(true);
						this.visao.setExibirColunaSUAT(true);

					} else if (UsuarioUtil.contemPermissao(NoFuncionalidadeEnum.CONSULTA_UNIDADE.getNoFuncionalidade(),
							EnumAcao.CONSULTAR.getNoAcao(), EnumTipoAbrangencia.RESTRITA_UNIDADE.getTipoAbrangencia(),
							EnumNomeAbrangenciaRestritaUnidade.UNIDADE.getNomeAbrangencia())) {

						this.construirBreadCrumbGestorUnidade(nuUnidadeusuarioLogado);
						this.visao.setExibirGestorUnidade(true);
						this.visao.setExibirColunaUnidade(true);
						this.visao.setExibirColunaSR(true);
						this.visao.setExibirColunaSUAT(true);
					}
				}
			}
		}

		this.getSession().setAttribute("nuUnidade", null);
		this.getSession().setAttribute("nuSr", null);
		this.getSession().setAttribute("nuSuat", null);

		this.carregarListaOperacaoSessao();
		this.restricaoAbrangencia();
		this.getPaginacaoContratoParametrizado().getFiltro().setBreadCrumb(false);

		// Carregar lista de garantias na sessão
		this.carregarListaGarantiaSessao();

		// Verificar permissões do usuario logado
		this.verificarPermissoes();

		// inicializa a lista de situação de contrato
		this.tratarComboSituacaoContrato();

		this.paginacaoContratoParametrizado.getFiltro().setIcSomenteAcompanhadas(true);
		this.carregarListaUnidadeDire();
	}

	public Collection<SrEUnidadeVO> autoCompleteUnidadeSr(final String noSuat) {
		visao.setSrUnidadesList(new ArrayList<SrEUnidadeVO>());
		Integer nuSuat = getIntValue(noSuat);

		final String unidadeUsuario = super.getUnidadeUsuario();
		Integer nuUnidade = null;
		if (!UtilString.isVazio(unidadeUsuario)) {
			nuUnidade = Integer.valueOf(unidadeUsuario);
		}

		if (getVisao().isExibirGestorRegional() || getVisao().isExibirGestorNacional() && !getVisao().isExibirGestorCaixa()) {

			final Collection<UnidadeVO> unidadeSrList = unidadeVinculadaSuatService.listarUnidadesPorNuSr(nuUnidade);
			for (final UnidadeVO unidadeVo : unidadeSrList) {
				if (unidadeVo.getCoUnidadeVO().toString().contains(noSuat)) {
					visao.getSrUnidadesList().add(new SrEUnidadeVO(unidadeVo));
				}
			}

		} else {
			Collection<UnidadeVO> suatsList = unidadeVinculadaSuatService.listarDiresPorNome(noSuat, nuSuat);
			for (final UnidadeVO unidadeVo : suatsList) {
				visao.getSrUnidadesList().add(new SrEUnidadeVO(unidadeVo, true));
			}

			Collection<SrVO> srsList = unidadeVinculadaSuatService.listarSrsPorNoSuat(noSuat, nuSuat);
			for (final SrVO snidadeVo : srsList) {
				visao.getSrUnidadesList().add(new SrEUnidadeVO(snidadeVo));
			}

			Collection<UnidadeVO> unidadeList = unidadeVinculadaSuatService.listarUnidadesPorNoSr(noSuat, nuSuat);
			for (final UnidadeVO unidadeVo : unidadeList) {
				visao.getSrUnidadesList().add(new SrEUnidadeVO(unidadeVo));
			}
		}

		return visao.getSrUnidadesList();
	}

	/**
	 * Retorna um {@link Integer} de uma {@link String}
	 * 
	 * @param nomeSuat
	 * @return
	 */
	private Integer getIntValue(String nomeSuat) {

		String numero = nomeSuat.replaceAll("[^0-9]", "");
		if (StringUtils.isNotEmpty(numero)) {
			return Integer.valueOf(numero);
		}

		return null;
	}

	/**
	 * <p>
	 * Método responsável por guardar o filtro anterior em um historico.
	 * <p>
	 *
	 * @author Caio Graco
	 */
	public void guardarHistoricoFiltro() {
		this.getVisao().setFiltroHistorico(UtilObjeto.clone(this.paginacaoContratoParametrizado.getFiltro()));
	}

	/**
	 * <p>
	 * Método responsável por validar a permissão de cada situação do contrato para
	 * adicionar na lista para filtro.
	 * <p>
	 *
	 * @author Caio Graco
	 */
	private void tratarComboSituacaoContrato() {
		final Collection<SituacaoContratoEnum> listaSituacaoContrato = new ArrayList<>();

		if (this.getVisao().isPermissaoCheckContratosParametrizados()) {
			listaSituacaoContrato.add(SituacaoContratoEnum.PARAMETRIZADO);
		}

		if (this.getVisao().isPermissaoCheckContratosNaoParametrizadosManualmente()) {
			listaSituacaoContrato.add(SituacaoContratoEnum.NAO_PARAMETRIZADO_MANUALMENTE);
		}

		if (this.getVisao().isPermissaoCheckContratosNaoParametrizados()) {
			listaSituacaoContrato.add(SituacaoContratoEnum.NAO_PARAMETRIZADO);
		}

		this.getVisao().setListaSituacaoContratoEnum(listaSituacaoContrato);
	}

	/**
	 * <p>
	 * Método responsável por getListaSegmento.
	 * <p>
	 *
	 * @return Collection<Segmento>
	 * @author Caio Graco
	 */
	@SuppressWarnings("unchecked")
	public Collection<Segmento> getListaSegmento() {
		// Consultar lista de Segmentos
		if (ScopoUtil.getInstancia().getValueSession(LISTA_SEGUIMENTO) == null) {
			ScopoUtil.getInstancia().setValueSession(LISTA_SEGUIMENTO, segmentoService.listarSegmentos());
		}

		this.getVisao().setListaSegmento((Collection<Segmento>) ScopoUtil.getInstancia().getValueSession(LISTA_SEGUIMENTO));

		return this.getVisao().getListaSegmento();
	}

	/**
	 * <p>
	 * Método responsável por retornar quantidade de contratos parametrizados.
	 * <p>
	 *
	 * @return Integer
	 */
	public Integer getQuantidadeResgistroContratoParametrizado() {
		return this.paginacaoContratoParametrizado.getRowCount();
	}

	/**
	 * <p>
	 * Método responsável por carregar a lista de operação sistema na sessão.
	 * <p>
	 *
	 * @author Waltenes Junior
	 */
	private void carregarListaOperacaoSessao() {
		if (super.getHttpSession().getAttribute(AnaliseMB.MAPA_OPERACAO_SISTEMA) == null) {

			final HashMap<String, String> mapaOperacaoSistema = new HashMap<>();

			for (final OperacaoSistema operacaoSistema : operacaoSistemaService.listar()) {
				mapaOperacaoSistema.put(operacaoSistema.getNuOperacao(), operacaoSistema.getDeMascara());
			}

			super.getSession().setAttribute(AnaliseMB.MAPA_OPERACAO_SISTEMA, mapaOperacaoSistema);
		}
	}

	/**
	 * <p>
	 * Método responsável por carregar a lista de garantias na sessão, caso já não
	 * exista.
	 * <p>
	 *
	 * @author guilherme.santos
	 */
	private void carregarListaGarantiaSessao() {
		this.popularComboGarantia();
		if (super.getRequest().getAttribute("listaGarantias") == null) {
			super.getRequest().setAttribute("listaGarantias", this.getVisao().getGarantias());
		}
	}

	/**
	 * <p>
	 * Método responsável por contruir o breadcrumb do gestor regional.
	 * </p>
	 *
	 * @param numeroUnidadeUsuarioLogado
	 *            valor a ser atribuído
	 * @author Waltenes Junior
	 */
	private void construirBreadCrumbGestorRegional(final Integer numeroUnidadeUsuarioLogado) {
		final AnaliseVisao visao = this.getVisao();
		final UnidadeVinculadaSuatService servicoUnidadeVinculada = this.unidadeVinculadaSuatService;

		final Integer numeroSuatUnidadeUsuarioLogado = servicoUnidadeVinculada.getNuSuatPorSR(numeroUnidadeUsuarioLogado);
		visao.setNomeSuat(this.suatService.getNomeSuat(numeroSuatUnidadeUsuarioLogado));

		visao.setNomeSr(this.unidadeService.getNomeSRPorNuUnidade(numeroUnidadeUsuarioLogado));

		if (UtilObjeto.isReferencia(numeroUnidadeUsuarioLogado)) {
			final Collection<UnidadeVO> unidadeSrList = servicoUnidadeVinculada.listarUnidadesPorNuSr(numeroUnidadeUsuarioLogado);
			visao.setUnidadeList(unidadeSrList);
		}
	}

	/**
	 * <p>
	 * Método responsável por contruir o breadcrumb do gestor de uma unidade.
	 * </p>
	 *
	 * @param numeroUnidadeUsuarioLogado
	 *            valor a ser atribuído
	 * @author joseroberto@gsgroup.com.br
	 * @author Waltenes Junior
	 */
	private void construirBreadCrumbGestorUnidade(final Integer numeroUnidadeUsuarioLogado) {
		final AnaliseVisao visao = this.getVisao();
		final Integer numeroSuatUnidadeUsuarioLogado = this.unidadeVinculadaSuatService.getNuSuatPorUnidade(numeroUnidadeUsuarioLogado);
		visao.setNomeUnidade(this.unidadeService.getNomeUnidade(numeroUnidadeUsuarioLogado));
		visao.setNomeSuat(this.suatService.getNomeSuat(numeroSuatUnidadeUsuarioLogado));
		visao.setNomeSr(this.unidadeService.getNomeSRPorNuUnidade(numeroUnidadeUsuarioLogado));
	}

	/**
	 * <p>
	 * Ação executada quando a combobox de DIRE - anteriormente chamada de SUAT - for selecionada.
	 * </p>
	 *
	 * @author joseroberto@gsgroup.com.br
	 * @author Waltenes Junior
	 * @author gerusa.soares
	 */
	public void selecionarDire() {		
		this.limparSuvSelecionada();
		this.limparNuUnidadeSelecionada();
		this.limparListaUnidadeFiltro();
		this.visao.setListaUnidade(null);
		
		this.visao.setNuSuat(this.visao.getCodSuatSelecionada());
		
		if (UtilObjeto.isReferencia(visao) && visao.getNuSuat() != null && !visao.getNuSuat().equals(0)) {
		    
			this.visao.setUnidadeSelecionada(null);
			this.visao.setNivelConsulta("SUAT");
			this.visao.setTituloGrid("SUAT");
			
			// Consulta as SR baseado na SUAT selecionada.
		        final Collection<SrVO> lista = dwAnaliseContratoService.listarSrsPorNuSuat(getVisao().getNuSuat());
			this.visao.setSrList(lista);
			
			final ArrayList<Integer> listaUnidadeVinculadasSrs = new ArrayList<>();
			for(SrVO l : lista) {
				listaUnidadeVinculadasSrs.add(l.getNuSrVO());
			}
			
			final Collection<Integer> nuUnidadesVinculadasSR = unidadeVinculadaSuatService.getNuUnidadesVinculadasSR(listaUnidadeVinculadasSrs);
			
			final FiltroAnaliseCarteiraVO consultaContratoParametrizado = this.getPaginacaoContratoParametrizado().getFiltro();
			consultaContratoParametrizado.setBreadCrumb(true);
			
			final Collection<Integer> listaUnidadeFiltro = this.getListaNuUnidade(nuUnidadesVinculadasSR, listaUnidadeVinculadasSrs, visao.getNuSuat());
			
			consultaContratoParametrizado.setListaUnidades(listaUnidadeFiltro);
			
			this.getRelatorioAnaliseMB().getVisao().setNuSuat(visao.getNuSuat());
			
		} else {
			this.visao.setSrList(new LinkedList<SrVO>());
			this.visao.setUnidadeList(new LinkedList<UnidadeVO>());
			this.visao.setNivelConsulta("CAIXA");
			this.visao.setTituloGrid("CAIXA");

			this.getRelatorioAnaliseMB().getVisao().setNuSuat(null);
		}
	}

        /**
         * <p>
         * Método responsável por limpar a unidade SUV - anteriormente chamada de SR
         * - selecionada.
         * </p>
         *
         * @author gerusa.soares
         *
         */
        private void limparSuvSelecionada() {
        	visao.setNuSr(null);
        	visao.setCodSuvSelecionado(null);
        	this.getRelatorioAnaliseMB().getVisao().setNuSr(null);
        }

	/**
	 * <p>Método responsável por retornar uma lista com números de unidades.</p>
	 *
	 * @author gerusa.soares
	 *
	 * @param listUnidadePrioridadeUm
	 * @param listUnidadePrioridadeDois
	 * @param nuUnidade
	 * @return
	 */
	private Collection<Integer> getListaNuUnidade(Collection<Integer> listUnidadePrioridadeUm, ArrayList<Integer> listUnidadePrioridadeDois, Integer nuUnidade) {
	    
	    final Collection<Integer> listaUnidadeFiltro = CollectionUtils.isNotEmpty(listUnidadePrioridadeUm) ? listUnidadePrioridadeUm : listUnidadePrioridadeDois;
	    
	    return CollectionUtils.isNotEmpty(listaUnidadeFiltro) ? listaUnidadeFiltro : Arrays.asList(nuUnidade);
	}

	/**
	 * <p>
	 * Ação executada quando a combobox de SR for selecionada.
	 * </p>
	 *
	 * @author joseroberto@gsgroup.com.br
	 * @author Waltenes Junior
	 * @author gerusa.soares
	 */
	public void selecionarSr() {
		this.limparListaUnidadeFiltro();
		this.limparNuUnidadeSelecionada();
		
		getVisao().setNuSr(this.visao.getCodSuvSelecionado());
		
		if (UtilObjeto.isReferencia(visao) && visao.getNuSr() != null && !visao.getNuSr().equals(0)) {
		    
			final Collection<UnidadeVO> lista = unidadeVinculadaSuatService.listarUnidadesPorNuSr(visao.getNuSr());
			visao.setListaUnidade(lista);
			
			final ArrayList<Integer> listaUnidadeVinculada = new ArrayList<>();
			
			if(CollectionUtils.isNotEmpty(lista)) {
			    for (final UnidadeVO unidadeVO : lista) {
				listaUnidadeVinculada.add(unidadeVO.getCoUnidadeVO());
			    }
			}
			
			this.getPaginacaoContratoParametrizado().getFiltro().setListaUnidades(this.getListaNuUnidade(listaUnidadeVinculada, null, visao.getNuSr()));
			this.getRelatorioAnaliseMB().getVisao().setNuSr(visao.getNuSr());			
			this.visao.setNivelConsulta("SR");
			this.visao.setTituloGrid("SR");
			
		} else {
			this.selecionarDire();
		}
	}

	/**
	 * <p>
	 * Ação executada quando a combobox de Unidade for selecionada.
	 * <p>
	 *
	 * @author Ricardo Crispim
	 * @author gerusa.soares
	 */
	public void selecionarUnidade() {
		final AnaliseVisao visao = this.getVisao();
		this.limparListaUnidadeFiltro();

		if (UtilObjeto.isReferencia(visao) && visao.getUnidadeSelecionada()  != null && !visao.getUnidadeSelecionada().equals(0)) {
			final Integer unidadeSelecionada = visao.getUnidadeSelecionada();
			this.getRelatorioAnaliseMB().getVisao().setNuUnidade(unidadeSelecionada);
			
			final FiltroAnaliseCarteiraVO consultaContratoParametrizado = this.getPaginacaoContratoParametrizado().getFiltro();
			consultaContratoParametrizado.setBreadCrumb(true);
			consultaContratoParametrizado.setListaUnidades(Arrays.asList(unidadeSelecionada));
		} else {
			this.limparNuUnidadeSelecionada();
			this.selecionarSr();
		}
	}

	/**
	 * <p>Método responsável por limpar a nuUnidade selecionada.</p>
	 *
	 * @author gerusa.soares
	 *
	 * @param visao
	 */
	private void limparNuUnidadeSelecionada() {
	    this.getVisao().setUnidadeSelecionada(null);
	    this.getRelatorioAnaliseMB().getVisao().setNuUnidade(null);
	}

	/**
	 * <p>
	 * Método responsável por limpar a lista de unidades do filtro.
	 * <p>
	 *
	 * @author Waltenes Junior
	 */
	public void limparlistaUnidadesSr() {
		final ContratoParametrizadoLazyModel consultaContratoParametrizado = this.getPaginacaoContratoParametrizado();
		consultaContratoParametrizado.getFiltro().setNuUnidade(this.getVisao().getNuUnidade());
		consultaContratoParametrizado.getFiltro().getListaUnidades().clear();
		consultaContratoParametrizado.getFiltro().setBreadCrumb(true);

		this.getRelatorioAnaliseMB().getVisao().setNuUnidade(this.getVisao().getNuUnidade());
	}

	/**
	 * <p>
	 * Método responsável por atribuir a restrição sobre a abrangência do usuário
	 * logado.
	 * <p>
	 *
	 * @author Waltenes Junior
	 */
	private void restricaoAbrangencia() {
		if (UsuarioUtil.contemPermissao(NoFuncionalidadeEnum.PARAMETRIZA_CONTRATO.getNoFuncionalidade(), EnumAcao.INCLUIR.getNoAcao(), null, null)) {
			this.getVisao().setRestricaoAbangencia(true);
		}
	}

	/**
	 * <p>
	 * Método responsável por exportar xls.
	 * <p>
	 */
	public void exportarXLSContratoParametrizado() {
		try {
			final Map<String, Object> parametros = new LinkedHashMap<>();
			parametros.put("LOGO_CAIXA", super.getExternalContext().getResourceAsStream(AnaliseMB.IMAGEM_CAIXA_LOGO));
			parametros.put("MATRICULA_USUARIO", super.getMatriculaUsuario());

			final FiltroAnaliseCarteiraVO filtro = this.paginacaoContratoParametrizado.getFiltro();

			final Collection<ContratoParametrizadoVO> listaRelatorio = this.service.listarContratoParametrizadoPorFiltroSelecionado(filtro);

			for (final ContratoParametrizadoVO vo : listaRelatorio) {
				vo.setIcAcompanha(filtro.getIcSomenteAcompanhadas());
			}

			UtilRelatorio.getInstancia().addCaminhoRelatorio(AnaliseMB.CAMINHO_RELATORIO + AnaliseMB.NOME_JASPER_CONTRATO_PARAMETRIZADO)
					.addColecao(listaRelatorio).addExtensaoArquivo(EnumExtensaoArquivo.XLS).addNomeRelatorio(AnaliseMB.RELATORIO_CONTRATOS_PARAM)
					.addParametros(parametros).addResposta(super.getResponse()).gerarRelatorio();

		} catch (final Exception e) {
			LogCefUtil.error("Não foi possivel gerar o XLS: " + e.getCause());
			LogCefUtil.error(e);
		}
	}

	/**
	 *
	 * <p>
	 * Método responsável por retornar o nome da Suat de acordo com o número.
	 * <p>
	 *
	 * @param nuSuat
	 *            valor a ser atribuído
	 * @return String
	 * @author Caio Graco
	 */
	public String noSuat(final int nuSuat) {
		return this.suatService.getNomeSuat(nuSuat);
	}

	/**
	 * <p>
	 * Método responsável por retornar o nome da SR.
	 * <p>
	 *
	 * @param nuSr
	 *            valor a ser atribuído
	 * @return String
	 * @author Caio Graco
	 */
	public String noSr(final int nuSr) {
		return this.unidadeVinculadaSuatService.getNoSr(nuSr);
	}

	/**
	 * <p>
	 * Método responsável por retornar o nome da unidade.
	 * <p>
	 *
	 * @param nuUnidade
	 *            valor a ser atribuído
	 * @return String
	 * @author Caio Graco
	 */
	public String noUnidade(final int nuUnidade) {
		return this.unidadeService.getNomeUnidade(nuUnidade);
	}

	/**
	 * <p>
	 * Método responsável por limpar a lista de unidades do filtro da consulta.
	 * <p>
	 *
	 * @author Waltenes Junior
	 */
	private void limparListaUnidadeFiltro() {
		this.getPaginacaoContratoParametrizado().getFiltro().setListaUnidades(new ArrayList<Integer>());
	}

	/**
	 * <p>
	 * Método responsável por navegar para a página de analise de carteira.
	 * </p>
	 *
	 * @return String
	 * @author joseroberto@gsgroup.com.br
	 */
	public String navegarParaAnaliseCarteira() {
		this.inicializar();

		if (this.getVisao().getFiltroHistorico() != null) {
			this.paginacaoContratoParametrizado.setFiltro(this.getVisao().getFiltroHistorico());
		}

		return AnaliseMB.PAGINA_ANALISE_GARANTIA;
	}

	/**
	 * <p>
	 * Método responsável por abrir a tela inicial.
	 * <p>
	 *
	 * @return String
	 * @author guilherme.santos
	 */
	public String abrirTelaInicial() {
		this.visao = new AnaliseVisao();
		this.carregarDadosTelaInicial();
		this.getVisao().setBreadCrumbAnaliseGarantia(false);
		return AnaliseMB.PAGINA_INICIAL;
	}

	/**
	 * <p>
	 * Método responsável por abrir a tela análise garantia pelo gráfico de
	 * contratos não parametrizados, se usuario tiver credencial de visualizar
	 * contratos não parametrizados.
	 * <p>
	 *
	 * @return String
	 * @author guilherme.santos
	 */
	public String abrirTelaAnaliseGarantiaPeloGraficoContratosNaoParametrizados() {
		final Collection<String> listaSituacaoContratoEnum = new ArrayList<>();
		listaSituacaoContratoEnum.add(SituacaoContratoEnum.NAO_PARAMETRIZADO_MANUALMENTE.name());
		this.paginacaoContratoParametrizado.getFiltro().setListaSituacaoContratoEnum(listaSituacaoContratoEnum);

		return this.abrirTelaAnaliseGarantiaPeloGrafico();
	}

	/**
	 * <p>
	 * Método responsável por abrir a tela análise garantia pelo gráfico de
	 * contratos não parametrizados, se usuario tiver credencial de visualizar
	 * contratos não parametrizados.
	 * <p>
	 *
	 * @return String
	 * @author guilherme.santos
	 */
	public String abrirTelaAnaliseGarantiaPeloGraficoContratosNovos() {
		final Collection<String> listaSituacaoContratoEnum = new ArrayList<>();
		listaSituacaoContratoEnum.add(SituacaoContratoEnum.NAO_PARAMETRIZADO_MANUALMENTE.name());
		this.paginacaoContratoParametrizado.getFiltro().setListaSituacaoContratoEnum(listaSituacaoContratoEnum);

		return this.abrirTelaAnaliseGarantiaPeloGrafico();
	}

	/**
	 * <p>
	 * Método responsável por abrir a tela análise garantia pelo gráfico na tela
	 * inicial.
	 * <p>
	 *
	 * @return AnaliseMB.PAGINA_ANALISE_GARANTIA
	 * @author Charles Júnior
	 *
	 */
	public String abrirTelaAnaliseGarantiaPeloGrafico() {
		this.selecionarNivelDoGrafico();
		this.selecionarSuatPeloGrafico();
		this.selecionarSrPeloGrafico();
		this.selecionarUnidadePeloGrafico();
		this.ajustarFiltroContratoPeloGrafico();

		this.getVisao().setBreadCrumbAnaliseGarantia(true);

		return AnaliseMB.PAGINA_ANALISE_GARANTIA;
	}

	/**
	 * <p>
	 * Método responsável por atualizar o nivel hierárquico do gráfico.
	 * <p>
	 *
	 * @author guilherme.santos
	 */
	private void selecionarNivelDoGrafico() {
		if (this.getSession().getAttribute("nuUnidade") != null) {
			this.getVisao().setNuUnidade(Integer.valueOf(this.getSession().getAttribute("nuUnidade").toString()));
		}
		if (this.getSession().getAttribute("nuSr") != null) {
			this.getVisao().setNuSr(Integer.valueOf(this.getSession().getAttribute("nuSr").toString()));
		}
		if (this.getSession().getAttribute("nuSuat") != null) {
			this.getVisao().setNuSuat(Integer.valueOf(this.getSession().getAttribute("nuSuat").toString()));
		}
	}

	/**
	 * <p>
	 * Método responsável por selecionar as Suats para o combo, pelo gráfico da tela
	 * inicial.
	 * <p>
	 *
	 * @author Charles Junior
	 */
	public void selecionarSuatPeloGrafico() {
		if (this.visao.getNuSuat() != null && this.visao.getNuSuat() != 0) {
			final FiltroAnaliseCarteiraVO consultaContratoParametrizado = this.getPaginacaoContratoParametrizado().getFiltro();
			this.limparListaUnidadeFiltro();

			if (UtilObjeto.isReferencia(this.visao) && this.visao.getNuSuat() != null && !this.visao.getNuSuat().equals(0)) {
				this.visao.setSrList(unidadeVinculadaSuatService.listarSrsPorNuSuat(this.visao.getNuSuat()));
				final Collection<Integer> listaSrs = new ArrayList<>();
				for (final SrVO srVO : this.visao.getSrList()) {
					listaSrs.add(srVO.getNuSrVO());
				}
				final Collection<Integer> listaUnidadeVinculadasSrs = this.unidadeVinculadaSuatService.getNuUnidadesVinculadasSR(listaSrs);
				consultaContratoParametrizado.setListaUnidades(listaUnidadeVinculadasSrs);
				this.visao.setUnidadeList(new LinkedList<UnidadeVO>());

				this.getRelatorioAnaliseMB().getVisao().setNuSuat(this.visao.getNuSuat());
			} else {
				this.visao.setSrList(new LinkedList<SrVO>());
				this.visao.setUnidadeList(new LinkedList<UnidadeVO>());
				this.getRelatorioAnaliseMB().getVisao().setNuSuat(null);
			}
		}
	}

	/**
	 * <p>
	 * Método responsável por selecionar as Sr para o combo, pelo gráfico da tela
	 * inicial.
	 * <p>
	 *
	 * @author Charles Junior
	 */
	public void selecionarSrPeloGrafico() {
		if (this.visao.getNuSr() != null && this.visao.getNuSr() != 0) {
			this.limparListaUnidadeFiltro();

			if (UtilObjeto.isReferencia(this.visao) && this.visao.getNuSr() != null && !this.visao.getNuSr().equals(0)) {
				this.visao.setUnidadeList(unidadeVinculadaSuatService.listarUnidadesPorNuSr(this.visao.getNuSr()));
				for (final UnidadeVO unidadeVO : this.visao.getUnidadeList()) {
					final Integer unidade = unidadeVO.getCoUnidadeVO();
					this.getPaginacaoContratoParametrizado().getFiltro().getListaUnidades().add(unidade);
				}
				this.getRelatorioAnaliseMB().getVisao().setNuSr(this.visao.getNuSr());
			} else {
				this.visao.setNuSr(null);
				this.visao.setNuUnidade(null);
				this.getRelatorioAnaliseMB().getVisao().setNuSr(null);
				this.getRelatorioAnaliseMB().getVisao().setNuUnidade(null);
			}
		}
	}

	/**
	 * <p>
	 * Método responsável por selecionar as Unidade para o combo, pelo gráfico da
	 * tela inicial.
	 * <p>
	 *
	 * @author Charles Junior
	 */
	public void selecionarUnidadePeloGrafico() {
		if (UtilObjeto.isReferencia(this.visao) && this.visao.getNuUnidade() != null && !this.visao.getNuUnidade().equals(0)) {
			this.limparListaUnidadeFiltro();
			this.getPaginacaoContratoParametrizado().getFiltro().getListaUnidades().add(this.visao.getNuUnidade());
			this.getRelatorioAnaliseMB().getVisao().setNuUnidade(this.visao.getNuUnidade());
		} else {
			this.visao.setNuUnidade(null);
			this.getRelatorioAnaliseMB().getVisao().setNuUnidade(null);
		}
	}

	/**
	 * <p>
	 * Método responsável por ajustar os campos do filtro de contrato, com o número
	 * de contrato do gráfico da tela inicial.
	 * <p>
	 *
	 * @author Charles Junior
	 */
	public void ajustarFiltroContratoPeloGrafico() {
		if (this.visao.getNuUnidade() != null && this.visao.getNuUnidade() != 0 && UtilNumero.validarSomenteNumero(this.visao.getCoIdentificador())) {
			String coIdentificador = this.visao.getCoIdentificador();
			final Integer nuOperacao = this.visao.getNuOperacao();
			String contratoParte1 = "";
			String contratoParte2 = "";
			String contratoParte3 = "";
			String contratoParte4 = "";

			String contratoFormatado = ContratoUtil.formatarContratoComMascaraSessao(nuOperacao, coIdentificador);
			if (contratoFormatado != null) {

				String[] contratoSplit = contratoFormatado.split("\\.");

				if (contratoSplit.length >= 2) {
					contratoParte1 = contratoSplit[0];
					contratoParte2 = contratoSplit[1];

					String[] contratoSplitNumero = contratoSplit[2].split("-");
					contratoParte3 = contratoSplitNumero[0];
					if (contratoSplitNumero.length > 1) {
						contratoParte4 = contratoSplitNumero[1];
					}

					// Filtro de origem do DIFERENTE do gráfico Contratos não
					// parametrizados
					this.paginacaoContratoParametrizado.getFiltro().setNuContratoParte1(contratoParte1);
					this.paginacaoContratoParametrizado.getFiltro().setNuContratoParte2(contratoParte2);
					this.paginacaoContratoParametrizado.getFiltro().setNuContratoParte3(contratoParte3);
					this.paginacaoContratoParametrizado.getFiltro().setNuContratoParte4(contratoParte4);
				}
			}

			// this.selecionarUnidadePeloGrafico();

		}

		// Filtro de origem do gráfico Garantias insuficientes
		if (this.getVisao().isOrigemGarantiasInsuficiente()) {
			this.paginacaoContratoParametrizado.getFiltro().setStatusGarantiaSuficienteEnum(StatusGarantiaSuficienteEnum.INSUFICIENTE);
		}
		// Filtro de origem do gráfico Novos contratos
		if (this.getVisao().isOrigemNovosContratos()) {
			this.paginacaoContratoParametrizado.getFiltro().setNovosContratos(Boolean.TRUE);
		}
	}

	/**
	 * <p>
	 * Método responsável por abrir a tela de analise de garantia.
	 * <p>
	 *
	 * @return String
	 * @author guilherme.santos
	 */
	public String abrirTelaAnaliseGarantia() {
		this.visao = new AnaliseVisao();
		this.carregarDadosTelaInicial();
		this.getVisao().setBreadCrumbAnaliseGarantia(true);
		return AnaliseMB.PAGINA_ANALISE_GARANTIA;
	}

	/**
	 * <p>
	 * Método responsável por carrega os dados da tela inicio.
	 * <p>
	 *
	 * @author guilherme.santos
	 */
	private void carregarDadosTelaInicial() {
		this.getRelatorioAnaliseMB().setVisao(new RelatorioAnaliseVisao());
		this.paginacaoContratoParametrizado.setFiltro(new FiltroAnaliseCarteiraVO());

		final Collection<String> listaSituacaoContratoEnum = new ArrayList<>();

		listaSituacaoContratoEnum.add(SituacaoContratoEnum.PARAMETRIZADO.name());

		this.paginacaoContratoParametrizado.getFiltro().setListaSituacaoContratoEnum(listaSituacaoContratoEnum);
		this.inicializar();
	}

	/**
	 * @see br.gov.caixa.pedesgo.arquitetura.controlador.AbstractBean#getService()
	 */
	@SuppressWarnings("unchecked")
	@Override
	public ContratoService getService() {
		return this.service;
	}

	/**
	 * @see br.gov.caixa.pedesgo.arquitetura.controlador.AbstractBean#getVisao()
	 */
	@Override
	public AnaliseVisao getVisao() {
		if (!UtilObjeto.isReferencia(this.visao)) {
			this.visao = new AnaliseVisao();
		}
		return this.visao;
	}

	/**
	 * Define o valor do atributo AnaliseVisao.
	 *
	 * @param visao
	 *            valor a ser atribuído
	 */
	public void setVisao(final AnaliseVisao visao) {
		this.visao = visao;
	}

	/**
	 * Retorna o valor do atributo paginacaoContratoParametrizado.
	 *
	 * @return paginacaoContratoParametrizado
	 */
	public ContratoParametrizadoLazyModel getPaginacaoContratoParametrizado() {

		return this.paginacaoContratoParametrizado;
	}

	/**
	 * <p>
	 * Método responsável por pesquisar e atribuir a primeira pagina da paginação da
	 * DataTable de contrato parametrizado.
	 * <p>
	 *
	 * @author guilherme.santos
	 */
	public void pesquisar() {
		final DataTable dataTable = (DataTable) FacesContext.getCurrentInstance().getViewRoot()
				.findComponent("formularioAnaliseCarteira:gridContratosParametrizados");

		if (UtilObjeto.isReferencia(dataTable)) {
			dataTable.setFirst(0);
		}
		this.paginacaoContratoParametrizado.getFiltro().setBotaoConsulta(true);
	}

	/**
	 * Define o valor do atributo paginacaoContratoParametrizado.
	 *
	 * @param paginacaoContratoParametrizado
	 *            valor a ser atribuído
	 */
	public void setPaginacaoContratoParametrizado(final ContratoParametrizadoLazyModel paginacaoContratoParametrizado) {
		this.paginacaoContratoParametrizado = paginacaoContratoParametrizado;
	}

	/**
	 * Retorna o valor do atributo parametrizacaoContratoMB.
	 *
	 * @return <code>parametrizacaoContratoMB</code>
	 */
	public ParametrizacaoContratoMB getParametrizacaoContratoMB() {
		return this.parametrizacaoContratoMB;
	}

	/**
	 * Define o valor do atributo parametrizacaoContratoMB.
	 *
	 * @param parametrizacaoContratoMB
	 *            valor a ser atribuído
	 */
	public void setParametrizacaoContratoMB(final ParametrizacaoContratoMB parametrizacaoContratoMB) {
		this.parametrizacaoContratoMB = parametrizacaoContratoMB;
	}

	/**
	 * Retorna o valor do atributo paginaInicialAnaliseCarteira.
	 *
	 * @return <code>paginaInicialAnaliseCarteira</code>
	 */
	public static String abrirPaginaAnaliseGarantia() {
		return AnaliseMB.PAGINA_ANALISE_GARANTIA;
	}

	/**
	 * @see br.gov.caixa.pedesgo.arquitetura.controlador.AbstractBean#getNomeVarResourceBundle()
	 */
	@Override
	public String getNomeVarResourceBundle() {
		return null;
	}

	/**
	 * @see br.gov.caixa.pedesgo.arquitetura.controlador.AbstractBean#getPrefixoCasoDeUso()
	 */
	@Override
	public String getPrefixoCasoDeUso() {
		return null;
	}

	/**
	 * Retorna o valor do atributo relatorioAnaliseMB.
	 *
	 * @return relatorioAnaliseMB
	 */
	public RelatorioAnaliseMB getRelatorioAnaliseMB() {
		return this.relatorioAnaliseMB;
	}

	/**
	 * Define o valor do atributo relatorioAnaliseMB.
	 *
	 * @param relatorioAnaliseMB
	 *            valor a ser atribuído
	 */
	public void setRelatorioAnaliseMB(final RelatorioAnaliseMB relatorioAnaliseMB) {
		this.relatorioAnaliseMB = relatorioAnaliseMB;
	}

	/**
	 * <p>
	 * Método responsável por popular a grid de garantias.
	 * <p>
	 *
	 * @author guilherme.santos
	 */
	public void popularComboGarantia() {
		if (this.getVisao().getGarantias() == null) {
			this.getVisao().setGarantias(grupoGarantiaService.listar());
		}
	}

	/**
	 * <p>
	 * Método responsável por verificar permissões do usuario logado.
	 * <p>
	 *
	 * @author guilherme.santos
	 */
	private void verificarPermissoes() {
		this.getVisao().setExibirPesquisaContrato(UsuarioUtil.contemPermissao(NoFuncionalidadeEnum.PESQUISA_CONTRATO.getNoFuncionalidade(),
				EnumAcao.CONSULTAR.getNoAcao(), null, null));
		this.getVisao().setExibirBotaoXLS(UsuarioUtil.contemPermissao(
				NoFuncionalidadeEnum.EMITE_RELATORIO_ANALISE_GARANTIA_EXPORTAR.getNoFuncionalidade(), EnumAcao.CONSULTAR.getNoAcao(), null, null));
		// Atributo responsavel por habilitar/desabilitar botão para abrir tela
		// de Parametrização
		this.getVisao().setExibirBotaoAbrirParametrizacao(UsuarioUtil.contemPermissao(NoFuncionalidadeEnum.PARAMETRIZA_CONTRATO.getNoFuncionalidade(),
				EnumAcao.CONSULTAR.getNoAcao(), null, null));

		// permissões dos filtros por situação do contrato
		this.getVisao().setPermissaoCheckContratosParametrizados(UsuarioUtil.contemPermissao(
				NoFuncionalidadeEnum.CONSULTA_CONTRATO_PARAMETRIZADO.getNoFuncionalidade(), EnumAcao.CONSULTAR.getNoAcao(), null, null));
		this.getVisao().setPermissaoCheckContratosNaoParametrizados(UsuarioUtil.contemPermissao(
				NoFuncionalidadeEnum.CONSULTA_CONTRATO_NAO_PARAMETRIZADO.getNoFuncionalidade(), EnumAcao.CONSULTAR.getNoAcao(), null, null));
		this.getVisao().setPermissaoCheckContratosNaoParametrizadosManualmente(UsuarioUtil.contemPermissao(
				NoFuncionalidadeEnum.CONSULTA_CONTRATO_NAO_PARAMETRIZADO_MANUAL.getNoFuncionalidade(), EnumAcao.CONSULTAR.getNoAcao(), null, null));
	}

	/**
	 * <p>
	 * Método responsável por limpar BreadCrumb.
	 * <p>
	 *
	 * @author guilherme.santos
	 */
	public void limparBreadCrumb() {
		this.visao.setCodSuatSelecionada(null);
		this.visao.setCodSuvSelecionado(null);
		this.visao.setUnidadeSelecionada(null);
		this.visao.setNuSuat(null);
		this.visao.setNuSr(null);
		this.visao.setNuUnidade(null);
		this.visao.setSrList(new LinkedList<SrVO>());
		this.visao.setUnidadeList(new LinkedList<UnidadeVO>());
		this.visao.setListaUnidade(null);

		getVisao().setSrUnidade(new SrEUnidadeVO());
		final Collection<String> listaSituacaoContratoEnum = new ArrayList<>();
		listaSituacaoContratoEnum.add(SituacaoContratoEnum.PARAMETRIZADO.name());
		RequestContext.getCurrentInstance().execute("$('#inputPessoaContratoParametrizado').val('');");
		this.paginacaoContratoParametrizado.getFiltro().setListaSituacaoContratoEnum(listaSituacaoContratoEnum);

		this.getRelatorioAnaliseMB().getVisao().setNuSuat(null);
	}

	public boolean isSuficienteTelaAnalise(ContratoParametrizadoVO itemVO) {
		return !itemVO.isIcTratamentoEspecial() && itemVO.getDtUltParametrizacaoManualVO() != null && itemVO.isIcParametrizado()
				&& itemVO.isIcSaldoSuficiente();
	}

	public boolean isInSuficienteTelaAnalise(ContratoParametrizadoVO itemVO) {
		return !itemVO.isIcTratamentoEspecial() && itemVO.getDtUltParametrizacaoManualVO() != null && itemVO.isIcParametrizado()
				&& !itemVO.isIcSaldoSuficiente();
	}

	/**
	 * Verifica se o contrato informado está definido com "Não parametrizado
	 * manualmente" e possui suficiência.
	 * 
	 * @param itemVO
	 * @return se está definido com "Não parametrizado manualmente" e possui
	 *         suficiência.
	 */
	public boolean isNaoParametrizadoManualmenteSuficiente(ContratoParametrizadoVO itemVO) {
		return !itemVO.isIcTratamentoEspecial() && itemVO.isIcParametrizado() && itemVO.getDtUltParametrizacaoManualVO() == null
				&& itemVO.isIcSaldoSuficiente();
	}

	/**
	 * Verifica se o contrato informado está definido com "Não parametrizado
	 * manualmente" e possui insuficiência.
	 * 
	 * @param itemVO
	 * @return se está definido com "Não parametrizado manualmente" e possui
	 *         insuficiência.
	 */
	public boolean isNaoParametrizadoManualmenteInsuficiente(ContratoParametrizadoVO itemVO) {
		return !itemVO.isIcTratamentoEspecial() && itemVO.isIcParametrizado() && itemVO.getDtUltParametrizacaoManualVO() == null
				&& !itemVO.isIcSaldoSuficiente();
	}

	/**
	 * Retorna a descrição do tooltip (hint) segundo o status do contrato.
	 * 
	 * @return
	 */
	public String getTooltipStatusContrato(ContratoParametrizadoVO contrato) {
		String tooltip = getTooltipInsuficiente(contrato);
		if (isSuficienteTelaAnalise(contrato) || isNaoParametrizadoManualmenteSuficiente(contrato)) {
			tooltip = isNaoParametrizadoManualmenteSuficiente(contrato) ? "Garantia suficiente. Contrato ainda não parametrizado manualmente"
					: "Garantia suficiente";
		}

		if (isNaoParametrizadoManualmenteInsuficiente(contrato)) {
			tooltip = tooltip.concat(" Contrato ainda não parametrizado manualmente.");
		}

		return tooltip;
	}

	private String getTooltipInsuficiente(ContratoParametrizadoVO contrato) {
		return contrato.getDtMaiorInadimplencia() == null ? "Garantia insuficiente."
				: String.format("Garantia insuficiente há %s.",
						CalculadoraInadimplenciaUtil.getDescricaoInicioInadimplencia(contrato.getDtMaiorInadimplencia()));
	}

	/**
	 * <p>
	 * Método responsável por formatar o identificador do contrato com a mascara da
	 * operacao
	 * </p>
	 * .
	 *
	 * @author p541915
	 *
	 * @param identificadorContrato
	 * @return
	 */
	public String formatarIdentificadorContrato(DWAnaliseContrato analiseContrato) {
		return ContratoUtil.formatarContratoComMascaraSessao(analiseContrato.getNuOperacao(), analiseContrato.getNoIdentificador());
	}

	/**
	 * <p>
	 * Método responsável por verificar se o usuário contém permissão de
	 * visualização de pelo menos um painel.
	 * <p>
	 *
	 * @return boolean
	 * @author Bruno Martins de Carvalho
	 */
	private boolean possuiPeloMenosUmaPermissaoDePainel() {
		return UsuarioUtil.contemFuncionalidade(NoFuncionalidadeEnum.PAINEL_GARANTIA_INSUFICIENTE.getNoFuncionalidade())
				|| UsuarioUtil.contemFuncionalidade(NoFuncionalidadeEnum.PAINEL_CONTRATO_NAO_PARAMETRIZADO.getNoFuncionalidade())
				|| UsuarioUtil.contemFuncionalidade(NoFuncionalidadeEnum.PAINEL_NOVO_CONTRATO.getNoFuncionalidade());
	}
	
	/**
	 * <p>
	 * Método responsável por verificar o nivel da consulta.
	 * <p>
	 *
	 * @param valor
	 *            valor a ser atribuído
	 * @return boolean
	 * @author Charles Júnior
	 */
	public boolean isNivelConsultaIgual(final String valor) {
		return this.visao.getNivelConsulta().equals(valor);
	}
	
	/**
	 * <p>
	 * Ação executada quando a linha da grid por clicada. Será atutalizado o combo
	 * de acordo com o nível em que se encontram as informações na grid.
	 * <p>
	 *
	 * @param nivelConsulta
	 *            valor a ser atribuído
	 * @param nuIdentificador
	 *            valor a ser atribuído
	 * @author Charles Júnior
	 */
	public void preencherComboPelaGrid(final String nivelConsulta, final Integer nuIdentificador) {
		if (nivelConsulta.equals("SUAT")) {
			if (UtilObjeto.isReferencia(visao) && visao.getNuSuat() != null && !visao.getNuSuat().equals(0)) {
				visao.setSrList(unidadeVinculadaSuatService.listarSrsPorNuSuat(visao.getNuSuat()));
				final Collection<Integer> listaSrs = new ArrayList<>();
				for (final SrVO srVO : visao.getSrList()) {
					listaSrs.add(srVO.getNuSrVO());
				}
				this.unidadeVinculadaSuatService.getNuUnidadesVinculadasSR(listaSrs);
				visao.setUnidadeList(new LinkedList<UnidadeVO>());
			}
		} else if (nivelConsulta.equals("SR") && UtilObjeto.isReferencia(visao) && visao.getNuSr() != null
				&& !visao.getNuSr().equals(0)) {
			visao.setUnidadeList(unidadeVinculadaSuatService.listarUnidadesPorNuSr(visao.getNuSr()));
		}
	}
	
	private void carregarListaUnidadeDire() {
		List<UnidadeVO> listaDires = new ArrayList<>();
		
		Integer tipoConfig = HIERARQUIA; 
		Integer unidadeGestora = null; 
		try {
			List<Integer> codigos = new ArrayList<>();
			String dados = this.propriedadeService.getPropriedadeBanco("unidade.lista", "unidade");
			tipoConfig = Integer.parseInt(this.propriedadeService.getPropriedadeBanco("unidade.tipoconfig", "unidade"));
			unidadeGestora = Integer.parseInt(this.propriedadeService.getPropriedadeBanco("unidade.unidadeGestora", UNIDADE));
			String[] lista = dados.split(";");
			for (String item : lista) {
				codigos.add(Integer.parseInt(item));
			}
			listaDires = new ArrayList<>(this.unidadeVinculadaSuatService.listarDiresPorCodigo(codigos));
		} catch (ParametrosInvalidosException e) {
			LogCEF.error("Erro ao carregar propriedades de unidades. Detalhes: ");
			LogCEF.error(e);
		}
			
		this.getVisao().setListaDires(listaDires);
		this.getVisao().setTipoConfig(tipoConfig);
		this.getVisao().setUnidadeGestoraProcesso(unidadeGestora);
	}
	
	public Boolean getApresentarContratosInativos() {
        if (this.paginacaoContratoParametrizado != null) {
        	return !UtilString.isVazio(this.paginacaoContratoParametrizado.getFiltro().getCpfCnpjPessoa());
        }
        return false;
    }
	
	public void atualizaApresentacaoGridContratos() {
	    this.getVisao().setApresentarGridContratos(Boolean.TRUE);
	}
}