/**
 * reservados. Copyright (c) 2009-2011 Caixa Econômica Federal. Todos os direitos
 *
 * Caixa Econômica Federal - SIACG – Sistema de Acompanhamento de Carteiras de Cobrança
 *
 * Este programa de computador foi desenvolvido sob demanda da CAIXA e está protegido por leis de direitos autorais e
 * tratados internacionais. As condições de cópia e utilização do todo ou partes dependem de autorização da pessoa.
 * Cópias não são permitidas sem expressa autorização. Não pode ser comercializado ou utilizado para propósitos
 * particulares.
 *
 * Uso exclusivo da Caixa Econômica Federal. A reprodução ou distribuição não autorizada deste programa ou de parte
 * dele, resultará em punições civis e criminais e os infratores incorrem em sanções previstas na legislação em vigor.
 *
 * Histórico do Subversion:
 *
 * LastChangedRevision: LastChangedBy: LastChangedDate:
 *
 * HeadURL:
 *
 */
package br.gov.caixa.siacg.view.mb;

import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;
import javax.inject.Inject;

import br.gov.caixa.pedesgo.arquitetura.controlador.ManutencaoBean;
import br.gov.caixa.pedesgo.arquitetura.util.MensagensUtil;
import br.gov.caixa.pedesgo.arquitetura.util.UtilObjeto;
import br.gov.caixa.siacg.commons.AppConstant;
import br.gov.caixa.siacg.commons.MsgConstant;
import br.gov.caixa.siacg.model.domain.Segmento;
import br.gov.caixa.siacg.service.SegmentoService;
import br.gov.caixa.siacg.view.form.PorteVisao;

/**
 * <p>
 * PorteMB
 * </p>
 * <p>
 * Descrição: Managed bean do caso de uso de Portes.
 * </p>
 * <br>
 * <b>Empresa:</b> Cef - Caixa Econômica Federal
 *
 * @author ludemeula.sa
 * @version 1.0
 */
@ManagedBean
@SessionScoped
public class PorteMB extends ManutencaoBean<Segmento> {

	private static final long serialVersionUID = 403091172928554585L;

	private static final String PAGINA_CONSULTA = "/pages/porte/consulta.xhtml?faces-redirect=true";
	private static final String PAGINA_INCLUSAO = "/pages/porte/edicao.xhtml?faces-redirect=true";
	private static final String NOME_MANAGED_BEAN = "porteMB";

	@Inject
	private SegmentoService service;
	
	private PorteVisao visao;
	
	public String abrir() {
		limparVisao();
		
		return PAGINA_CONSULTA;
	}

	private void limparVisao() {
		visao = new PorteVisao();
		getVisao().setFiltro(new Segmento());
		
		pesquisar();
	}
	
	public String novo() {
		limparVisao();
		
		return PAGINA_INCLUSAO;
	}
	
	public String editar(Segmento segmento) {
		getVisao().setEntidade(segmento);
		
		return PAGINA_INCLUSAO;
	}
	
	public void excluir() {
		if (getService().isPossuiVinculo(getVisao().getEntidade())) {
			super.adicionaMensagemDeAlerta(MensagensUtil.getMensagem(AppConstant.RESOURCE_BUNDLE, MsgConstant.EXLUSAO_NAO_PERMITIDA_PORTE));
		} else {
			getService().remover(getVisao().getEntidade());
			limparVisao();
		}
	}
	
	public void pesquisar() {
		getVisao().setLista(getService().pesquisar(getVisao().getFiltro()));
	}
	
	public void salvar() {
		getService().persistir(getVisao().getEntidade());

		if (getVisao().getEntidade().hasMensagens()) {
			adicionaListaMensagemDeAlerta(getVisao().getEntidade().getMensagens());
		} else {
			getVisao().setMensagemModal(MensagensUtil.getMensagem(getNomeVarResourceBundle(), MsgConstant.OPERACAO_COM_SUCESSO));
		}
	}
	
	/*******************************************************************
	 * GETTERS && SETTERS
	 ******************************************************************/
	@Override
	protected String getNomeVarResourceBundle() {
		return AppConstant.RESOURCE_BUNDLE;
	}
	
	@Override
	protected String getPrefixoCasoDeUso() {
		return NOME_MANAGED_BEAN;
	}
	
	@SuppressWarnings("unchecked")
	@Override
	public SegmentoService getService() {
		return this.service;
	}

	@Override
	public PorteVisao getVisao() {
		if (!UtilObjeto.isReferencia(visao)) {
			this.visao = new PorteVisao();
		}

		return visao;
	}
}