/**
 * Copyright (c) 2015 Caixa Econômica Federal. Todos os direitos
 * reservados.
 *
 * Caixa Econômica Federal - SIACG - Sistema de Crédito Rural
 *
 * Este software foi desenvolvido sob demanda da CAIXA e está
 * protegido por leis de direitos autorais e tratados internacionais. As
 * condições de cópia e utilização do todo ou partes dependem de autorização da
 * pessoa. Cópias não são permitidas sem expressa autorização. Não pode ser
 * comercializado ou utilizado para propósitos particulares.
 *
 * Uso exclusivo da Caixa Econômica Federal. A reprodução ou distribuição não
 * autorizada deste programa ou de parte dele, resultará em punições civis e
 * criminais e os infratores incorrem em sanções previstas na legislação em
 * vigor.
 *
 * Histórico do Subversion:
 *
 * LastChangedRevision: $Revision$
 * LastChangedBy: $Author$
 * LastChangedDate: $Date$
 *
 * HeadURL: $HeadURL$
 *
 */
package br.gov.caixa.siacg.view.mb;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

import javax.ejb.EJB;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;

import org.primefaces.event.FileUploadEvent;

import br.gov.caixa.pedesgo.arquitetura.controlador.AbstractBean;
import br.gov.caixa.pedesgo.arquitetura.controlador.ManutencaoBean;
import br.gov.caixa.siacg.model.domain.SinalizadorLiquidez;
import br.gov.caixa.siacg.service.SinalizadorLiquidezService;
import br.gov.caixa.siacg.view.form.SinalizadorLiquidezVisao;

/**
 * <p>
 * SinalizadorLiquidezMB.
 * </p>
 * <p>
 * Descrição: Managed bean do caso de uso <code> Mantém Índice Liquidez </code>
 * </p>
 * <br>
 * <b>Empresa:</b> Cef - Caixa Econômica Federal
 *
 * @author gerusa.soares
 * @version 1.0
 */
@SessionScoped
@ManagedBean
public class SinalizadorLiquidezMB extends ManutencaoBean<SinalizadorLiquidez> {

    /** Atributo serialVersionUID. */
    private static final long serialVersionUID = 4617104820337665444L;

    /** Atributo DIRETORIO_PAGINAS. */
    private static final String DIRETORIO_PAGINAS = "/pages/";

    /** Atributo PREFIXO_CASO_USO. */
    private static final String PREFIXO_CASO_USO = "sinalizadorLiquidez";

    /** Atributo VAR_RESOURCE_BUNDLE. */
    private static final String VAR_RESOURCE_BUNDLE = "msgApp";

    /** Atributo OPERACAO_REALIZADA_SUCESSO. */
    public static final String OPERACAO_REALIZADA_SUCESSO = "MA002";

    /** Atributo coSinalizadorLiquidez. */
    private Integer coSinalizadorLiquidez;

    /** Atributo servico. */
    @EJB
    private SinalizadorLiquidezService servico;

    /** Atributo visao. */
    private SinalizadorLiquidezVisao visao;

    /**
     *
     * @see br.gov.caixa.pedesgo.arquitetura.controlador.AbstractBean#carregar()
     */
    @Override
    public void carregar() {
        
	this.visao = new SinalizadorLiquidezVisao();
        this.visao.setLista(this.getService().listarSinalizadoresLiquidez());
        this.visao.setTamanhoListaSL(this.visao.getLista().size());

        this.coSinalizadorLiquidez = 0;
    }

    /**
     * @see br.gov.caixa.pedesgo.arquitetura.controlador.AbstractBean#getTelaConsulta()
     */
    @Override
    public String getTelaConsulta() {
        return SinalizadorLiquidezMB.DIRETORIO_PAGINAS + this.getPrefixoCasoDeUso() + AbstractBean.SUFIXO_TELA_CONSULTA;
    }

    /**
     * @see br.gov.caixa.pedesgo.arquitetura.controlador.AbstractBean#getNomeVarResourceBundle()
     */
    @Override
    protected String getNomeVarResourceBundle() {
        return SinalizadorLiquidezMB.VAR_RESOURCE_BUNDLE;
    }

    /**
     * @see br.gov.caixa.pedesgo.arquitetura.controlador.AbstractBean#getPrefixoCasoDeUso()
     */
    @Override
    protected String getPrefixoCasoDeUso() {
        return SinalizadorLiquidezMB.PREFIXO_CASO_USO;
    }

    /**
     * @see br.gov.caixa.pedesgo.arquitetura.controlador.AbstractBean#getService()
     */
    @SuppressWarnings("unchecked")
    @Override
    public SinalizadorLiquidezService getService() {
        return this.servico;
    }

    /**
     * @see br.gov.caixa.pedesgo.arquitetura.controlador.AbstractBean#getVisao()
     */
    @Override
    public SinalizadorLiquidezVisao getVisao() {
        if (this.visao == null) {
            this.visao = new SinalizadorLiquidezVisao();
        }

        return this.visao;
    }

    /**
     * <p>
     * Método responsável por salvar a lista de sinalizadores de liquidez.
     * <p>
     *
     * @author gerusa.soares
     */
    public void salvarSinalizadoresLiquidez() {
        final SinalizadorLiquidez sinalizador = this.visao.getEntidade();

        final Collection<SinalizadorLiquidez> listaSinalizadores = this.visao.getLista();

        this.getService().validarSinalizadores((List<SinalizadorLiquidez>) listaSinalizadores, sinalizador);

        if (sinalizador.hasMensagens()) {

            super.adicionaListaMensagemDeErro(sinalizador.getMensagens());

        } else {

            final Collection<SinalizadorLiquidez> listaSinalizadoresRemovidos = this.visao.getListaSinalizadoresRemovidos();

            if (!listaSinalizadoresRemovidos.isEmpty()) {

                this.getService().removerSinalizadoresLiquidez(listaSinalizadoresRemovidos);

                this.visao.setListaSinalizadoresRemovidos(new ArrayList<SinalizadorLiquidez>());
            }

            this.getService().salvarSinalizadoresLiquidez(listaSinalizadores);

            super.adicionaMensagemDeSucesso(SinalizadorLiquidezMB.OPERACAO_REALIZADA_SUCESSO);
        }
    }

    /**
     * <p>
     * Método responsável por adicionar um sinalizador de liquidez na lista de
     * sinalizadores.
     * <p>
     *
     * @author gerusa.soares
     */
    public void adicionarSinalizadorLiquidez() {
        this.coSinalizadorLiquidez++;

        final SinalizadorLiquidez sinalizador = new SinalizadorLiquidez();
        sinalizador.setCoSinalizadorLiquidez(this.coSinalizadorLiquidez);
        sinalizador.setPcInicial(new BigDecimal("0.00"));
        sinalizador.setPcFinal(new BigDecimal("100.00"));

        this.visao.getLista().add(sinalizador);
    }

    /**
     * <p>
     * Método responsável por remover um sinalizador de liquidez da lista de
     * sinalizadores.
     * <p>
     *
     * @author gerusa.soares
     */
    public void removerSinalizadorLiquidez() {
        final SinalizadorLiquidez visao = this.visao.getEntidade();

        this.visao.getListaSinalizadoresRemovidos().add(visao);

        final Collection<SinalizadorLiquidez> lista = this.visao.getLista();

        final Boolean isRemovido = lista.remove(visao);

        // remove sinalizador adicionado
        if (!isRemovido) {
            final Collection<SinalizadorLiquidez> novaLista = new ArrayList<>();

            for (final SinalizadorLiquidez sinalizadorLista : lista) {
                if (sinalizadorLista.getCoSinalizadorLiquidez() == null || (sinalizadorLista.getCoSinalizadorLiquidez() != null
                        && !sinalizadorLista.getCoSinalizadorLiquidez().equals(visao.getCoSinalizadorLiquidez()))) {

                    novaLista.add(sinalizadorLista);
                }
            }

            this.visao.setLista(novaLista);

        }
    }

    /**
     * <p>
     * Método responsável por recuperar o conteúdo do arquivo selecionado e
     * atribuir à entidade.
     * <p>
     *
     * @param fileUploadEvent
     *            valor a ser atribuído
     * @author gerusa.soares
     */
    public void uploadArquivo(final FileUploadEvent fileUploadEvent) {
        final SinalizadorLiquidez sinalizador = this.visao.getEntidade();

        String nomeArquivo = fileUploadEvent.getFile().getFileName();

        if (nomeArquivo.trim().length() > 20) {

            nomeArquivo = nomeArquivo.substring(0, 20);
        }

        sinalizador.setNoArquivoImagem(nomeArquivo);
        sinalizador.setImSinalizadorLiquidez(fileUploadEvent.getFile().getContents());
    }
}
