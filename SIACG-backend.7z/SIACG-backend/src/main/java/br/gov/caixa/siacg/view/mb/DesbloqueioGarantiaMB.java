package br.gov.caixa.siacg.view.mb;

import java.util.List;

import javax.ejb.EJB;
import javax.enterprise.context.SessionScoped;
import javax.inject.Named;

import org.apache.commons.collections.CollectionUtils;

import br.gov.caixa.pedesgo.arquitetura.controlador.ManutencaoBean;
import br.gov.caixa.pedesgo.arquitetura.util.MensagensUtil;
import br.gov.caixa.pedesgo.arquitetura.util.UtilObjeto;
import br.gov.caixa.siacg.commons.AppConstant;
import br.gov.caixa.siacg.commons.MsgConstant;
import br.gov.caixa.siacg.exception.ParametrosInvalidosException;
import br.gov.caixa.siacg.model.domain.Contrato;
import br.gov.caixa.siacg.model.domain.GarantiaContrato;
import br.gov.caixa.siacg.model.vo.ContratoParametrizadoVO;
import br.gov.caixa.siacg.service.ContratoService;
import br.gov.caixa.siacg.service.GarantiaContratoService;
import br.gov.caixa.siacg.util.LogCEF;
import br.gov.caixa.siacg.view.form.DesbloqueioGarantiaVisao;

/**
 * <p>
 * DesbloqueioGarantia
 * </p>
 *
 * <p>
 * Descrição: Bean gerenciável para a entidade GarantiaContrato.
 * </p>
 *
 * <br>
 * <b>Empresa:</b> Cef - Caixa Econômica Federal
 *
 *
 * @author f734546
 *
 * @version 1.0
 */
@Named
@SessionScoped
public class DesbloqueioGarantiaMB extends ManutencaoBean<GarantiaContrato> {

    /** Atributo serialVersionUID. */
    private static final long serialVersionUID = -1392567555832316749L;

    /** Atributo NOME_MANAGED_BEAN. */
    public static final String NOME_MANAGED_BEAN = "desbloqueioGarantiaMB";

    /** Atributo EL_MANAGED_BEAN. */
    public static final String EL_MANAGED_BEAN = "#{desbloqueioGarantiaMB}";

    @EJB
    private transient ContratoService contratoService;

    @EJB
    private GarantiaContratoService service;

    private DesbloqueioGarantiaVisao visao;

    @Override
    protected String getPrefixoCasoDeUso() {
	return null;
    }

    @SuppressWarnings("unchecked")
    @Override
    public GarantiaContratoService getService() {
	return this.service;
    }

    @Override
    public DesbloqueioGarantiaVisao getVisao() {
	if (!UtilObjeto.isReferencia(this.visao)) {
	    this.visao = new DesbloqueioGarantiaVisao();
	}

	return this.visao;
    }

    /**
     * <p>
     * Método responsável por listar as garantias bloqueadas de um determinado
     * contrato. Tela cadastro >> contrato.
     * <p>
     *
     * @param contrato
     * @author f734546
     */
    public void listarGarantiasBloqueadas(final Contrato contratoSelecionado) {
		final Contrato contrato = new Contrato();
		contrato.setNuContrato(contratoSelecionado.getNuContrato());
		formatarNumContrato(contratoSelecionado.getCoContrato(), contrato);	
		this.carregarVisao(contrato);
    }

	private void formatarNumContrato(final String coContrato, final Contrato contrato) {
		String strContrato = this.contratoService.formatarCodigoContrato(coContrato);
		if (strContrato == null || strContrato.isEmpty()) {
			contrato.setCoContratoFormatado(coContrato);
		} else {
			contrato.setCoContratoFormatado(strContrato);
		}
	}

    /**
     * <p>
     * Método responsável por preencher o objeto visao com os dados necessários
     * para a apresentação em tela.
     * </p>
     *
     * @author f734546
     *
     * @param contrato
     */
    private void carregarVisao(final Contrato contrato) {
	this.getVisao().setContrato(contrato);

	final List<GarantiaContrato> lista = this.getService().listarGarantiaContratoBloqueada(contrato.getNuContrato());
	this.getVisao().setListaGarantia(lista);

	if (CollectionUtils.isNotEmpty(lista)) {
	    this.getVisao().setQuantidadeItens(lista.size());
	} else {
	    this.getVisao().setQuantidadeItens(0);
	}
    }

    /**
     * <p>
     * Método responsável por listar as garantias bloqueadas de um determinado
     * contrato. Tela Analise de Garantia.
     * <p>
     *
     * @param contrato
     * @author f734546
     */
    public void listarGarantiasBloqueadas(final ContratoParametrizadoVO contratoSelecionado) {
		final Contrato contrato = new Contrato();
		contrato.setNuContrato(contratoSelecionado.getNuContrato());	
		formatarNumContrato(contratoSelecionado.getCodigoContratoVO(), contrato);
		this.carregarVisao(contrato);
    }

    /**
     * <p>
     * Método responsável por solicitar o desbloqueio de uma garantia de um contrato.
     * </p>
     *
     * @return
     */
    public void solicitarDesbloqueio() {
	    // objeto selecionado
	    GarantiaContrato garantia = this.getVisao().getGarantiaParaDesbloqueio();
		try {
			 this.service.desbloqueio(pegarMatriculaUsuarioLogado(), garantia);
			super.adicionaMensagemDeSucesso(MensagensUtil.getMensagem(AppConstant.RESOURCE_BUNDLE, MsgConstant.OPERACAO_COM_SUCESSO));
		} catch (IllegalArgumentException e) {
			MensagensUtil.adicionaMensagemDeAlerta(AppConstant.RESOURCE_BUNDLE, e.getMessage(), "");
		} catch (ParametrosInvalidosException e) {
			LogCEF.debug("Erro ao realizar desbloqueio de garantias do contrato: [" + garantia.getNuGarantia() + "]. Detalhes: ");
			LogCEF.debug(e);
			MensagensUtil.adicionaMensagemDeAlerta(AppConstant.RESOURCE_BUNDLE, e.getDescricao(), "");
		} catch (Exception e) {
			LogCEF.debug("Erro ao realizar desbloqueio de garantias do contrato: [" + garantia.getNuGarantia() + "]. Detalhes: ");
			LogCEF.debug(e);
			MensagensUtil.adicionaMensagemDeAlerta(AppConstant.RESOURCE_BUNDLE, "Não foi possível realizar o desbloqueio do contrato.", "");
		}
    }

	private String pegarMatriculaUsuarioLogado() {
		return System.getProperty(AppConstant.USUARIO_DESBLOQUEIO_MATRICULA, this.getMatriculaUsuario());
	}

}
