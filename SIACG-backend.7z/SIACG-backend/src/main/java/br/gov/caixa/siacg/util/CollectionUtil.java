/**
 * Copyright (c) 2020 Caixa Econômica Federal. Todos os direitos
 * reservados.
 *
 * Caixa Econômica Federal - SIACG - Sistema de Crédito Rural
 *
 * Este software foi desenvolvido sob demanda da CAIXA e está
 * protegido por leis de direitos autorais e tratados internacionais. As
 * condições de cópia e utilização do total ou partes dependem de autorização da
 * empresa. Cópias não são permitidas sem expressa autorização. Não pode ser
 * comercializado ou utilizado para propósitos particulares.
 *
 * Uso exclusivo da Caixa Econômica Federal. A reprodução ou distribuição não
 * autorizada deste programa ou de parte dele, resultará em punições civis e
 * criminais e os infratores incorrem em sanções previstas na legislação em
 * vigor.
 *
 * Histórico do TFS:
 *
 * LastChangedRevision: $Revision$
 * LastChangedBy: $Author$
 * LastChangedDate: $Date$
 *
 * HeadURL: $HeadURL$
 *
 */
package br.gov.caixa.siacg.util;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.stream.Collectors;

import org.apache.commons.collections.CollectionUtils;
import org.hibernate.criterion.Criterion;
import org.hibernate.criterion.Restrictions;

/**
 * <p>
 * CollectionUtil
 * </p>
 *
 * <p>
 * Descrição: Descrição do tipo
 * </p>
 *
 * <br>
 * <b>Empresa:</b> Cef - Caixa Econômica Federal
 *
 *
 * @author f725905
 *
 * @version 1.0
 */
public final class CollectionUtil {

    private static final int QUANTIDADE_MAXIMA = 1000;

    private CollectionUtil() {

    }

    public static String particionarComandoIn(final String campo, final Collection<?> parametros) {
	final StringBuilder sql = new StringBuilder();

	if (CollectionUtils.isNotEmpty(parametros)) {

	    List<?> partList = parametros.stream().collect(Collectors.toList());

	    int contador = 0;

	    for (final List<?> list : PartitionListUtil.of(partList, QUANTIDADE_MAXIMA)) {
		if (contador > 0) {
		    sql.append(" OR ");
		} else {
		    sql.append(" AND (");
		}
		sql.append(campo).append(" IN (").append(list.toString().replace("[", "").replace("]", "")).append(")");

		contador++;
	    }

	    sql.append(" ) ");
	}

	return sql.toString();
    }

    public static String particionarComandoNotIn(final String campo, final Collection<?> parametros) {

	final StringBuilder sql = new StringBuilder();

	if (CollectionUtils.isNotEmpty(parametros)) {
	    List<?> partList = parametros.stream().collect(Collectors.toList());

	    for (final List<?> cargos : PartitionListUtil.of(partList, QUANTIDADE_MAXIMA)) {
		sql.append(" AND (").append(campo).append(" NOT IN (").append(cargos.toString().replace("[", "").replace("]", "")).append(") )");
	    }
	}

	return sql.toString();
    }

    public static Criterion particionarComandoRestrictionIn(final String campo, final Collection<?> parametros) {
	final List<Criterion> predicates = new ArrayList<>();
	final List<List<?>> itensListList = new ArrayList<>();
	List<Object> listaAtual = new ArrayList<>();

	if (CollectionUtils.isNotEmpty(parametros)) {

	    List<?> partList = parametros.stream().collect(Collectors.toList());

	    for (int i = 0; i < partList.size(); i++) {
		if (i % QUANTIDADE_MAXIMA == 0) {
		    listaAtual = new ArrayList<>();
		    itensListList.add(listaAtual);
		}
		listaAtual.add(partList.get(i));
	    }

	    for (final List<?> itensList : itensListList) {
		final Criterion predicateItensCodigo = Restrictions.in(campo, itensList);
		predicates.add(predicateItensCodigo);
	    }
	}

	return Restrictions.and(Restrictions.or(predicates.toArray(new Criterion[0])));
    }

    public static Criterion particionarComandoRestrictionNotIn(final String campo, final Collection<?> parametros) {
	final List<Criterion> predicates = new ArrayList<>();

	final List<List<?>> itensListList = new ArrayList<>();
	List<Object> listaAtual = new ArrayList<>();

	if (CollectionUtils.isNotEmpty(parametros)) {

	    List<?> partList = parametros.stream().collect(Collectors.toList());

	    for (int i = 0; i < partList.size(); i++) {
		if (i % QUANTIDADE_MAXIMA == 0) {
		    listaAtual = new ArrayList<>();
		    itensListList.add(listaAtual);
		}
		listaAtual.add(partList.get(i));
	    }

	    for (final List<?> itensList : itensListList) {
		final Criterion predicateItensCodigo = Restrictions.not(Restrictions.in(campo, itensList));
		predicates.add(predicateItensCodigo);
	    }
	}

	return Restrictions.and(Restrictions.and(predicates.toArray(new Criterion[0])));
    }

    public static String transformaListaParaClausulaIn(Collection<Integer> lista) {

	final StringBuilder sb = new StringBuilder();
	lista.forEach(item -> sb.append(item).append(","));
	sb.deleteCharAt(sb.length() - 1);
	return sb.toString();
    }

}
