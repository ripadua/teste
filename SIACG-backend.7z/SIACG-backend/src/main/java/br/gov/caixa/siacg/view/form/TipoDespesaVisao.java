/*
 * Copyright (c) 2019 Caixa Econômica Federal. Todos os direitos
 * reservados.
 *
 * Caixa Econômica Federal - SIACG - Sistema de Crédito Rural
 *
 * Este software foi desenvolvido sob demanda da CAIXA e está
 * protegido por leis de direitos autorais e tratados internacionais. As
 * condições de cópia e utilização do todo ou partes dependem de autorização da
 * empresa. Cópias não são permitidas sem expressa autorização. Não pode ser
 * comercializado ou utilizado para propósitos particulares.
 *
 * Uso exclusivo da Caixa Econômica Federal. A reprodução ou distribuição não
 * autorizada deste programa ou de parte dele, resultará em punições civis e
 * criminais e os infratores incorrem em sanções previstas na legislação em
 * vigor.
 *
 * Histórico do TFS:
 *
 * LastChangedRevision: $Revision$
 * LastChangedBy: $Author$
 * LastChangedDate: $Date$
 *
 * HeadURL: $HeadURL$
 *
 */	
package br.gov.caixa.siacg.view.form;

import java.util.ArrayList;
import java.util.List;

import br.gov.caixa.pedesgo.arquitetura.visao.ManutencaoVisao;
import br.gov.caixa.siacg.model.domain.TipoDespesa;
import br.gov.caixa.siacg.model.domain.TipoFornecedor;

/**
 * <p>TipoDespesaVisao</p>
 *
 * <p>Descrição: Descrição do tipo</p>
 *
 * <br><b>Empresa:</b> Cef - Caixa Econômica Federal
 *
 *
 * @author Wisnton
 *
 * @version 1.0
*/
public class TipoDespesaVisao extends ManutencaoVisao<TipoDespesa>{

    /** Atributo serialVersionUID. */
    private static final long serialVersionUID = 1L;

    /** Atributo tipoDespesa */
    private TipoDespesa tipoDespesa;
    
    /** Atributo tipoDespesaInativar*/
    private TipoDespesa tipoDespesaInativar;
    
    /** Atributo tipoDespesaFiltro*/
    private TipoDespesa tipoDespesaFiltro;
    
    /** Atributo restricaoAbrangencia*/
    private Boolean restricaoAbrangencia;
    
    /** Atributo lista de Nomes  tipoDespesa */
    private List<TipoDespesa>listaNomesTipoDespesa;
    
    private List<TipoFornecedor>listaTipoFornecedor;
  
    /**
     * <p>Retorna o valor do atributo tipoDespesa</p>.
     *
     * @return tipoDespesa
    */
    public TipoDespesa getTipoDespesa() {
	
	if(this.tipoDespesa == null) {
	
	    this.tipoDespesa = new TipoDespesa();
	}
	
	return this.tipoDespesa;
    }

    /**
     * <p>Define o valor do atributo tipoDespesa</p>.
     *
     * @param tipoDespesa valor a ser atribuído
    */
    public void setTipoDespesa(TipoDespesa tipoDespesa) {
    	this.tipoDespesa = tipoDespesa;
    }

    /**
     * <p>Retorna o valor do atributo tipoDespesaInativar</p>.
     *
     * @return tipoDespesaInativar
    */
    public TipoDespesa getTipoDespesaInativar() {
        
	if(this.tipoDespesaInativar == null) {
        
	    this.tipoDespesaInativar = new TipoDespesa();
        }
	
	return this.tipoDespesaInativar;
    }

    /**
     * <p>Define o valor do atributo tipoDespesaInativar</p>.
     *
     * @param tipoDespesaInativar valor a ser atribuído
    */
    public void setTipoDespesaInativar(TipoDespesa tipoDespesaInativar) {
    this.tipoDespesaInativar = tipoDespesaInativar;}

    /**
     * <p>Retorna o valor do atributo tipoDespesaFiltro</p>.
     *
     * @return tipoDespesaFiltro
    */
    public TipoDespesa getTipoDespesaFiltro() {
        
	if(this.tipoDespesaFiltro == null) {
        
	    this.tipoDespesaFiltro = new TipoDespesa();
        }
	
	return this.tipoDespesaFiltro;
    }

    /**
     * <p>Define o valor do atributo tipoDespesaFiltro</p>.
     *
     * @param tipoDespesaFiltro valor a ser atribuído
    */
    public void setTipoDespesaFiltro(TipoDespesa tipoDespesaFiltro) {
    this.tipoDespesaFiltro = tipoDespesaFiltro;}

    /**
     * <p>Retorna o valor do atributo restricaoAbrangencia</p>.
     *
     * @return restricaoAbrangencia
    */
    public Boolean getRestricaoAbrangencia() {
        return this.restricaoAbrangencia;
    }

    /**
     * <p>Define o valor do atributo restricaoAbrangencia</p>.
     *
     * @param restricaoAbrangencia valor a ser atribuído
    */
    public void setRestricaoAbrangencia(Boolean restricaoAbrangencia) {
    this.restricaoAbrangencia = restricaoAbrangencia;}

    /**
     * <p>Retorna o valor do atributo listaNomesTipoDespesa</p>.
     *
     * @return listaNomesTipoDespesa
    */
    public List<TipoDespesa> getListaNomesTipoDespesa() {
    	if (listaNomesTipoDespesa == null) {
    		this.listaNomesTipoDespesa = new ArrayList<>();
    	}
        return this.listaNomesTipoDespesa;
    }

    /**
     * <p>Define o valor do atributo listaNomesTipoDespesa</p>.
     *
     * @param listaNomesTipoDespesa valor a ser atribuído
    */
    public void setListaNomesTipoDespesa(List<TipoDespesa> listaNomesTipoDespesa) {
    	this.listaNomesTipoDespesa = listaNomesTipoDespesa;
    }

	public List<TipoFornecedor> getListaTipoFornecedor() {
		if (listaTipoFornecedor == null) {
			this.listaNomesTipoDespesa = new ArrayList<>();
		}
		return listaTipoFornecedor;
	}

	public void setListaTipoFornecedor(List<TipoFornecedor> listaTipoFornecedor) {
		this.listaTipoFornecedor = listaTipoFornecedor;
	}
    
    


    
}
