package br.gov.caixa.siacg.util;

import static javax.ws.rs.core.Response.Status.BAD_REQUEST;

/**
 * Copyright (c) 2017 Caixa Econômica Federal. Todos os direitos
 * reservados.
 *
 * Caixa Econômica Federal - arquiteturajee7
 *
 * Este software foi desenvolvido sob demanda da CAIXA e está
 * protegido por leis de direitos autorais e tratados internacionais. As
 * condições de cópia e utilização do total ou partes dependem de autorização da
 * empresa. Cópias não são permitidas sem expressa autorização. Não pode ser
 * comercializado ou utilizado para propósitos particulares.
 *
 * Uso exclusivo da Caixa Econômica Federal. A reprodução ou distribuição não
 * autorizada deste programa ou de parte dele, resultará em punições civis e
 * criminais e os infratores incorrem em sanções previstas na legislação em
 * vigor.
 *
 * Histórico do TFS:
 *
 * LastChangedRevision: $Revision$
 * LastChangedBy: $Author$
 * LastChangedDate: $Date$
 *
 * HeadURL: $HeadURL$
 *
 */

import javax.xml.bind.annotation.XmlRootElement;

import br.gov.caixa.siacg.exception.ParametrosInvalidosException;
import br.gov.caixa.siacg.exception.SaldoWSexception;

/**
 * <p>
 * RecursoErro
 * </p>
 *
 * <p>
 * Descrição: Classe responsável por mapear os dados que retornarão em caso de
 * erro.
 * </p>
 *
 * <br>
 * <b>Empresa:</b> Cef - Caixa Econômica Federal
 *
 *
 * @author ricardo.crispim
 *
 * @version 1.0
 */
@XmlRootElement
public class RecursoErro {

    /** Atributo codigo. */
    private int codigo;

    /** Atributo mensagem. */
    private String mensagem;

    /** Atributo detalhe. */
    private String detalhe;

    /**
     * Responsável pela criação de novas instâncias desta classe.
     */
    public RecursoErro() {
	super();
    }
    
    /**
     * Responsável pela criação de novas instâncias desta classe.
     *
     * @param exception
     *            SaldoWSexception
     *
     */
    public RecursoErro(SaldoWSexception exception) {
	setCodigo(NumeroUtil.parseInt(exception.getCodigo()));
	setMensagem(exception.getDescricao());
	setDetalhe(exception.getSistemaConsultado());
    }

    public RecursoErro(Exception exception) {
	if (exception instanceof SaldoWSexception) {
	    SaldoWSexception ws = (SaldoWSexception) exception;
	    setCodigo(NumeroUtil.parseInt(ws.getCodigo()));
	    setMensagem(ws.getDescricao());
	    setDetalhe(ws.getSistemaConsultado());
	} else if (exception instanceof ParametrosInvalidosException) {
	    ParametrosInvalidosException ws = (ParametrosInvalidosException) exception;
	    setCodigo(NumeroUtil.parseInt(ws.getCodigo()));
	    setMensagem(ws.getDescricao());
	    setDetalhe(ws.getParametro());
	} else {
	    setCodigo(BAD_REQUEST.getStatusCode());
	    setMensagem(exception.getMessage());
	    setDetalhe(null);
	}
    }

    /**
     * <p>
     * Retorna o valor do atributo codigo
     * </p>
     * .
     *
     * @return codigo
     */
    public int getCodigo() {
	return codigo;
    }

    /**
     * <p>
     * Define o valor do atributo codigo
     * </p>
     * .
     *
     * @param codigo
     *            valor a ser atribuído
     */
    public void setCodigo(int codigo) {
	this.codigo = codigo;
    }

    /**
     * <p>
     * Retorna o valor do atributo mensagem
     * </p>
     * .
     *
     * @return mensagem
     */
    public String getMensagem() {
	return mensagem;
    }

    /**
     * <p>
     * Define o valor do atributo mensagem
     * </p>
     * .
     *
     * @param mensagem
     *            valor a ser atribuído
     */
    public void setMensagem(String mensagem) {
	this.mensagem = mensagem;
    }

    /**
     * <p>
     * Retorna o valor do atributo detalhe
     * </p>
     * .
     *
     * @return detalhe
     */
    public String getDetalhe() {
	return detalhe;
    }

    /**
     * <p>
     * Define o valor do atributo detalhe
     * </p>
     * .
     *
     * @param detalhe
     *            valor a ser atribuído
     */
    public void setDetalhe(String detalhe) {
	this.detalhe = detalhe;
    }

}