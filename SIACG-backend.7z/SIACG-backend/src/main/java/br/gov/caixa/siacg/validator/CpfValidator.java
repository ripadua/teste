package br.gov.caixa.siacg.validator;

import javax.faces.application.FacesMessage;
import javax.faces.component.UIComponent;
import javax.faces.context.FacesContext;
import javax.faces.validator.FacesValidator;
import javax.faces.validator.Validator;
import javax.faces.validator.ValidatorException;

import br.gov.caixa.pedesgo.arquitetura.util.UtilObjeto;
import br.gov.caixa.pedesgo.arquitetura.util.UtilCpf;

/**
 * <p>
 * CpfValidator
 * </p>
 * <p>
 * Descrição: Classe CpfValidator
 * </p>
 * <br>
 * <b>Empresa:</b> Cef - Caixa Econômica Federal.
 *
 * @author Bruno Martins de Carvalho
 * @version 1.0
 */
@FacesValidator(value = "cpfValidator")
public class CpfValidator implements Validator {

    /**
     * @see javax.faces.validator.Validator#validate(javax.faces.context.FacesContext,
     *      javax.faces.component.UIComponent, java.lang.Object)
     */
    @Override
    public void validate(final FacesContext context, final UIComponent component, final Object value) throws ValidatorException {

        if (UtilObjeto.isReferencia(value)) {

            final String cpf = String.valueOf(value);

            if (!UtilCpf.isCPF(cpf)) {
                final FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_ERROR, "O cpf é inválido", "MN023");
                throw new ValidatorException(message);
            }
        }

    }
}
