package br.gov.caixa.siacg.view.form;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Date;
import java.util.EnumSet;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.faces.model.SelectItem;

import org.apache.commons.collections.CollectionUtils;
import org.primefaces.model.DefaultTreeNode;
import org.primefaces.model.TreeNode;

import br.gov.caixa.pedesgo.arquitetura.util.UtilObjeto;
import br.gov.caixa.siacg.model.domain.BandeiraCartao;
import br.gov.caixa.siacg.model.domain.BemCliente;
import br.gov.caixa.siacg.model.domain.Cedente;
import br.gov.caixa.siacg.model.domain.ChequeExcepcionado;
import br.gov.caixa.siacg.model.domain.ContaContrato;
import br.gov.caixa.siacg.model.domain.ContaCorrente;
import br.gov.caixa.siacg.model.domain.Contrato;
import br.gov.caixa.siacg.model.domain.DuplicataExcepcionada;
import br.gov.caixa.siacg.model.domain.Garantia;
import br.gov.caixa.siacg.model.domain.GarantiaAplicacao;
import br.gov.caixa.siacg.model.domain.GarantiaCartaoCredito;
import br.gov.caixa.siacg.model.domain.GarantiaContrato;
import br.gov.caixa.siacg.model.domain.HistoricoFaturamentoPessoa;
import br.gov.caixa.siacg.model.domain.ParametroCalculo;
import br.gov.caixa.siacg.model.domain.ParametroComercializacao;
import br.gov.caixa.siacg.model.domain.Pessoa;
import br.gov.caixa.siacg.model.domain.ProponenteHabitacional;
import br.gov.caixa.siacg.model.domain.ProspectoTipoParcela;
import br.gov.caixa.siacg.model.domain.Recebido;
import br.gov.caixa.siacg.model.domain.SacadoExcepcionado;
import br.gov.caixa.siacg.model.domain.Tipologia;
import br.gov.caixa.siacg.model.domain.UnidadeHabitacional;
import br.gov.caixa.siacg.model.domain.UnidadeHabitacionalComercializacao;
import br.gov.caixa.siacg.model.enums.CaracteristicaEnum;
import br.gov.caixa.siacg.model.enums.ContaEnum;
import br.gov.caixa.siacg.model.enums.FormaGarantiaEnum;
import br.gov.caixa.siacg.model.enums.IndicadorReajusteEnum;
import br.gov.caixa.siacg.model.enums.OrigemParametrizacaoEnum;
import br.gov.caixa.siacg.model.enums.ParametroCalculoAgrupamentoEnum;
import br.gov.caixa.siacg.model.enums.PeriodicidadePrevistaEnum;
import br.gov.caixa.siacg.model.enums.SituacaoComercializacaoUnidadeHabitacionalEnum;
import br.gov.caixa.siacg.model.enums.SituacaoUnidadeHabitacionalEnum;
import br.gov.caixa.siacg.model.enums.TipoLogradouroEnum;
import br.gov.caixa.siacg.model.enums.TipoOrigemContaContratoEnum;
import br.gov.caixa.siacg.model.enums.TipoParcelaEnum;
import br.gov.caixa.siacg.model.enums.TipoPessoaEnum;
import br.gov.caixa.siacg.model.vo.ChequeExcepcionadoVO;
import br.gov.caixa.siacg.model.vo.ContaCorrenteBandeirasVO;
import br.gov.caixa.siacg.model.vo.DuplicataVO;
import br.gov.caixa.siacg.model.vo.ParametrizacaoContratoVO;
import br.gov.caixa.siacg.model.vo.RelatorioHistoricoUnidadeHabitacionalVO;
import br.gov.caixa.siacg.model.vo.SacadoExcepcionadoVO;
import br.gov.caixa.siacg.model.vo.UnidadeVO;

/**
 * <p>
 * ParametrizacaoContratoVisao
 * </p>
 * <p>
 * Descrição: Classe responsável por armazenar os dados da visão do caso de uso
 * <code>Parametrização do contrato</code>.
 * </p>
 * <br>
 * <b>Empresa:</b> Cef - Caixa Econômica Federal
 *
 * @author joseroberto@gsgroup.com.br
 * @author Leandro Severino - lseverino@gmail.com
 * @version 1.24
 */
public class ParametrizacaoContratoVisao extends TemplateVisao<GarantiaContrato> {

	private static final long serialVersionUID = 1L;

	public static final String NOME_MANAGED_BEAN = "parametrizacaoContratoVisao";

	private Contrato contratoSelecionadoParaParametrizacao;

	private boolean contratoSelecionadoHabitacional;

	private ContaCorrente contaCorrente;

	private DuplicataExcepcionada duplicataExcepcionada;

	private ChequeExcepcionado chequeExcepcionado;

	private SacadoExcepcionadoVO sacadoExcepcionado;

	private DuplicataVO duplicataVO;

	private ChequeExcepcionadoVO chequeVO;

	private Cedente cedenteIncluido;

	private ContaContrato contaContrato;

	private ContaContrato contaContratoAplicacaoFinanceira;

	private ContaContrato contaContratoCheque;

	private ContaContrato contaContratoCartao;

	private transient TreeNode contaCorrenteDaArvore;

	private transient TreeNode contaCorrenteCartaoCredito;
	
	private transient List<ContaCorrenteBandeirasVO> listaContaCorrenteBandeiras;

	private transient TreeNode[] aplicacoesSelecionadas;

	private transient TreeNode[] cartoesSelecionados;

	private ParametrizacaoContratoVO parametrizacaoContratoVOTemp;

	private ParametrizacaoContratoVO parametrizacaoEdicao;

	private boolean editing;

	private boolean editingTipologia;

	private TipoPessoaEnum tipoPessoaEnum;

	private Collection<Garantia> garantiaList;

	private Collection<FormaGarantiaEnum> formaGarantiaList;

	private Collection<FormaGarantiaEnum> formaGarantia2List;

	private Collection<String> listaTipoParcelaConsulta = new ArrayList<>();

	private Collection<CaracteristicaEnum> caracteristicaList;

	private Collection<Cedente> listaCedentes = new ArrayList<>();

	private Collection<ParametrizacaoContratoVO> parametrizacaoList;

	private Collection<ParametrizacaoContratoVO> listaExclusaoParametrizacao;

	private List<ContaContrato> listaContaContrato;

	private List<ContaContrato> listaContaContratoDasAplicacoes;

	private List<ContaContrato> listaContaContratoCheque;

	private List<ContaContrato> listaContaContratoCartao;

	private Collection<GarantiaAplicacao> listaAplicacaoSelecionadas;

	private Collection<SacadoExcepcionadoVO> sacadosParaExcepcionar;

	private Collection<SacadoExcepcionadoVO> sacadosExcepcionadosIncluir;

	private Collection<SacadoExcepcionadoVO> sacadosExcepcionadosRemover;

	private Collection<SacadoExcepcionadoVO> sacadosExcepcionadosRemoverTemporaria;

	private Collection<DuplicataVO> duplicatasEncontradas;

	private Collection<DuplicataVO> duplicatasParaExcepcionar;

	private Collection<ChequeExcepcionadoVO> chequesExcepcionadosEncontrados;

	private Collection<ChequeExcepcionadoVO> chequesParaExcepcionar;

	private Collection<ParametroCalculo> listaParametroCalculo;

	private Collection<Garantia> garantias;

	private Collection<ContaContrato> contaContratoList;

	private Collection<TipoPessoaEnum> listaTipoPessoa;

	private Collection<HistoricoFaturamentoPessoa> listaHistoricoFaturamentoPessoa;

	private List<UnidadeHabitacional> listUnidadeHabitacional;

	private Map<String, List<GarantiaCartaoCredito>> mapaContaCartoes = new HashMap<>();

	private boolean desabilitarComboGarantia;

	private boolean exibirNovaFormaGarantia;

	private boolean exibirBtnOu;

	private boolean exibirModalOperacaoRealizadaComSucesso;

	private boolean exibirModalValidacao;

	private boolean desabilitarCampos;

	private boolean desabilitarTipoGarantia;

	private boolean desabilitarFormaGarantia;

	private boolean exibirModalExclusao;

	private boolean exibirModalExcepcionar;

	private boolean ocultarPrazoMaximo;

	private boolean ocultarValorMaximo;

	private boolean ocultarPercentualMaximo;

	private boolean ocultarValor;

	private boolean ocultarInstrucaoProtesto;

	private boolean ocultarTipoGarantia;

	private boolean ocultarFormaGarantia;

	private boolean exibirAplicacaoFinanceira;

	private boolean exibirCheque;

	private boolean exibirCartaoCredito;

	private boolean contemAplicacaoFinanceira;

	private boolean exibirCamposEdicao = false;

	private boolean mesmoSegmentoPessoa = false;

	private String mensagemSalvarParametrizacao;

	private String identificadorRemocao;

	private String identificadorExcepcionar;

	private String identificadorEdicao;

	private String nuContaContrato;

	private String identificadorGarantia;

	private String nuContaCorrenteNaoLivreMovimentacao;
	private boolean exibirBotaoIncluirContaNLMContrato;

	private boolean exibirBotaoMarcarContaNLMContrato;

	private boolean exibirBotaoExcluirContaNLMContrato;

	private boolean exibirBotaoConsultarContaNLMContrato;
	private boolean exibirBotaoIncluirGarantia;

	private boolean exibirBotaoEditarGarantia;

	private boolean exibirBotaoExcluirGarantia;
	private boolean exibirBotaoEditarParametrosCalculo;
	private boolean exibirBotaoDuplicataExcepcionadaGarantia;

	private boolean exibirBotaoExcepcionarSacado;

	private boolean exibirBotaoIncluirDuplicataExcepcionadaGarantia;

	private boolean exibirBotaoExcluirDuplicataExcepcionadaGarantia;
	private boolean exibirBotaoChequeExcepcionadoGarantia;
	private boolean exibirBotaoIncluirChequeExcepcionadoGarantia;
	private boolean exibirBotaoExcluirChequeExcepcionadoGarantia;

	private boolean exibirBotaoSalvarSacado;

	private boolean exibirBotaoIncluirSacado;

	private boolean exibirBotaoExcepcionarSacadoDetalheVoltar;

	private boolean exibirBotaoLimparSacadoExcepcionado;

	private BigDecimal vrFaturamentoApurado;

	private String identificacaoSacadoRemover;

	private SacadoExcepcionadoVO sacadoExcepcionadoVOBackup;

	private Garantia garantia;

	private boolean listaSacadosAExcepcionarAlterada;

	private GarantiaContrato garantiaContrato;

	private Collection<SacadoExcepcionado> listaSacadosAlterados;

	private Integer qtdDias;

	private Collection<Tipologia> listaTipologia;
	
	private Collection<UnidadeHabitacional> listaUnidadeHabitacional;

	private Boolean podeSalvarTipologias = Boolean.FALSE;

	private Boolean podeSalvarUnidadesHabitacionais = Boolean.FALSE;

	private Boolean podeIncluirUnidadesHabitacionais = Boolean.FALSE;

	private Boolean filtroTabelaAcionado = Boolean.FALSE;

	private boolean campoComErro;

	private boolean campoComErroUnidadeHabitacional;

	private String mensagemDeErroNaValidacaoCampo;

	private UnidadeHabitacional unidadeHabitacionalEmEdicao = new UnidadeHabitacional();

	private Collection<SelectItem> listaHipotecadaContratacaoSN = new ArrayList<>();

	private Collection<SelectItem> listaMantidaHipotecaSN = new ArrayList<>();

	private SelectItem[] listaSituacaoUnidadeHabitacional;

	private Boolean estaEmEdicaoUnidadeHabitacional = Boolean.FALSE;

	private Boolean estaEmInclusaoOuEdicaoUnidadeHabitacional = Boolean.FALSE;
	
	private String filtroPorNoTipologia;

	private String idLinhaClicada;

	private Collection<ProponenteHabitacional> listaProponentesHabitacionais;

	private ProponenteHabitacional proponenteEmEdicao;

	private UnidadeHabitacionalComercializacao unidadeHabitacionalComercializacao;

	private boolean teveSucessoAoSalvarUnidadeHabitacional;

	private SelectItem[] listaIndiceReajusteUnidadeHabitacional;

	private SelectItem[] listaSituacaoContratoUnidadeHabitacional;

	private String tituloJanelaUnidadeHabitacional;

	private SelectItem[] listaTipoParcela;

	private SelectItem[] listaPeriodicidade;

	private ProspectoTipoParcela prospectoTipoParcelaEmEdicao;
	
	private ParametroComercializacao parametroComercializacaoEmEdicao;
	
	private ParametroComercializacao parametroComercializacaoEmExclusao;

	private Boolean podeIncluirPropectosGerados = Boolean.FALSE;

	private Boolean podeGerarPropectosIncluidos = Boolean.FALSE;

	private Collection<ProspectoTipoParcela> listaProspectoTipoParcela;

	private Collection<ParametroComercializacao> listaParametroComercializacao;

	private Collection<ParametroComercializacao> listaParametroComercializacaoOriginal;

	private String valorTotalCalculadoLinhasProspecto;

	private String valorTotalCalculadoLinhasProspectoComFiltroAtivo;

	private String filtroPorTipoParcela;

	private Integer filtroPorPeriodicidade;

	private Integer filtroPorQuantidadeParcelas;

	private Date filtroPorDtInicio;

	private Boolean temFiltroProspectoAtivo = Boolean.FALSE;

	private Boolean estaCarregandoModalProspectos = Boolean.FALSE;

	private Collection<Recebido> listaRecebidos;

	private Boolean icRegistrosInativos = Boolean.FALSE;

	private String filtroPorTipoParcelaRecebidos;

	private Date filtroPorDtVencimentoRecebidos;

	private Integer filtroPorNDocumentoRecebidos;

	private String filtroPorNossoNumeroRecebidos;

	private BigDecimal filtroPorValorTituloRecebidos;

	private BigDecimal filtroPorValorPagoRecebidos;

	private Integer filtroPorNCedenteRecebidos;

	private String filtroPorNProponenteRecebidos;

	private Collection<Recebido> listaAmortizacoes;

	private Boolean icAmortizacoesInativos = Boolean.FALSE;

	private Date filtroPorDtPagamentoAmortizacao;

	private BigDecimal filtroPorValorPagoAmortizacao;

	private String filtroPorMatriculaUsuarioResponsavelAmortizacao;

	private String idLinhaClicadaAmortizacao;

	private List<BandeiraCartao> listaBandeiraCartao;

	private Boolean podeAlterarValorCV = Boolean.FALSE;

	private Long codUHselecionada;

	private Integer nuRecebidoSelecionado;

	private BigDecimal indiceHipotecario;

	private BigDecimal indiceRecebiveis;

	private String cpfCnpjSacadoSelecionado;

	private String nomeSacadoSelecionado;

	private boolean segmentoMPE;

	private List<TipoLogradouroEnum> listaTipoLogradouro;

	private Boolean garantiaContratoImoveis;

	private boolean garantiaPassouSerAcompanhada;

	private Integer nuMaquinaEquipamento;

	private Pessoa pessoaTerceiro;

	private Long nuVeiculoAcompanhado;

	private List<BemCliente> listaBemCliente;
	
	private OrigemParametrizacaoEnum origemParametrizacao;
	
	private Integer tipoConfig;
	
	private List<UnidadeVO> unidadesSelecionadas =  new ArrayList<>();
	
	private List<UnidadeVO> unidadesRemocao;

	private List<UnidadeVO> unidadesTemp;
	
	private Integer unidadeGestoraSeleciona;
	
	private List<UnidadeVO> listaDires;
	
	private List<RelatorioHistoricoUnidadeHabitacionalVO> historicosProspecto;
	
	private Map<Integer, BigDecimal> valorUtilizadoOutrasGarantias;
	
	private GarantiaContrato garantiaContratoClone;

	/**
	 * Retorna o valor do atributo listaSacadosAExcepcionarAlterada.
	 *
	 * @return listaSacadosAExcepcionarAlterada
	 */
	public boolean isListaSacadosAExcepcionarAlterada() {

		return this.listaSacadosAExcepcionarAlterada;
	}

	/**
	 * Define o valor do atributo listaSacadosAExcepcionarAlterada.
	 *
	 * @param listaSacadosAExcepcionarAlterada
	 *            valor a ser atribuído
	 */
	public void setListaSacadosAExcepcionarAlterada(final boolean listaSacadosAExcepcionarAlterada) {

		this.listaSacadosAExcepcionarAlterada = listaSacadosAExcepcionarAlterada;
	}

	/**
	 * Retorna o valor do atributo contratoSelecionadoParaParametrizacao.
	 *
	 * @return contratoSelecionadoParaParametrizacao
	 */
	public final Contrato getContratoSelecionadoParaParametrizacao() {

		if (this.contratoSelecionadoParaParametrizacao != null && this.contratoSelecionadoParaParametrizacao.getIcCategoria() == '2') {
			this.contratoSelecionadoHabitacional = true;
		}
		return this.contratoSelecionadoParaParametrizacao;
	}

	/**
	 * Define o valor do atributo contratoSelecionadoParaParametrizacao.
	 *
	 * @param contratoSelecionadoParaParametrizacao
	 *            valor a ser atribuído
	 */
	public final void setContratoSelecionadoParaParametrizacao(final Contrato contratoSelecionadoParaParametrizacao) {
		this.contratoSelecionadoParaParametrizacao = contratoSelecionadoParaParametrizacao;
		this.atribuirVrFaturamento();
	}

	/**
	 * <p>
	 * Método responsável por atribuir o valor do faturamento.
	 * <p>
	 *
	 * @author guilherme.santos
	 */
	private void atribuirVrFaturamento() {
		if (this.contratoSelecionadoParaParametrizacao.getNuPessoa().getIcTipoEndividamento() != null) {
			this.setVrFaturamentoApurado(this.contratoSelecionadoParaParametrizacao.getNuPessoa().getVrFaturamentoApurado());
		} else {
			if (this.verificarExistenciaEndividamento()) {
				this.setVrFaturamentoApurado(
						this.contratoSelecionadoParaParametrizacao.getNuPessoa().getEndividamentoList().iterator().next().getVrFaturamento());
			} else {
				this.setVrFaturamentoApurado(BigDecimal.ZERO);
			}
		}
	}

	/**
	 * <p>
	 * Método responsável por verificar se existe endividamento a Pessoa.
	 * <p>
	 *
	 * @return boolean
	 * @author guilherme.santos
	 */
	private boolean verificarExistenciaEndividamento() {
		return this.contratoSelecionadoParaParametrizacao.getNuPessoa().getEndividamentoList() != null
				&& !this.contratoSelecionadoParaParametrizacao.getNuPessoa().getEndividamentoList().isEmpty();
	}

	/**
	 * Retorna o valor do atributo tipoGarantiaList.
	 *
	 * @return garantiaList
	 */
	public final Collection<Garantia> getGarantiaList() {
		return this.garantiaList;
	}

	/**
	 * Define o valor do atributo tipoGarantiaList.
	 *
	 * @param garantiaList
	 *            valor a ser atribuído
	 */
	public final void setGarantiaList(final Collection<Garantia> garantiaList) {
		this.garantiaList = garantiaList;
	}

	/**
	 * Retorna o valor do atributo formaGarantiaList.
	 *
	 * @return formaGarantiaList
	 */
	public final Collection<FormaGarantiaEnum> getFormaGarantiaList() {
		return this.formaGarantiaList;
	}

	/**
	 * Define o valor do atributo formaGarantiaList.
	 *
	 * @param formaGarantiaList
	 *            valor a ser atribuído
	 */
	public final void setFormaGarantiaList(final Collection<FormaGarantiaEnum> formaGarantiaList) {
		this.formaGarantiaList = formaGarantiaList;
	}

	/**
	 * Retorna o valor do atributo formaGarantia2List.
	 *
	 * @return formaGarantia2List
	 */
	public final Collection<FormaGarantiaEnum> getFormaGarantia2List() {
		return this.formaGarantia2List;
	}

	/**
	 * Define o valor do atributo formaGarantia2List.
	 *
	 * @param formaGarantia2List
	 *            valor a ser atribuído
	 */
	public final void setFormaGarantia2List(final Collection<FormaGarantiaEnum> formaGarantia2List) {
		this.formaGarantia2List = formaGarantia2List;
	}

	/**
	 * Retorna o valor do atributo caracteristicaList.
	 *
	 * @return caracteristicaList
	 */
	public final Collection<CaracteristicaEnum> getCaracteristicaList() {
		return this.caracteristicaList;
	}

	/**
	 * Define o valor do atributo caracteristicaList.
	 *
	 * @param caracteristicaList
	 *            valor a ser atribuído
	 */
	public final void setCaracteristicaList(final Collection<CaracteristicaEnum> caracteristicaList) {
		this.caracteristicaList = caracteristicaList;
	}

	/**
	 * Retorna o valor do atributo listaCedentes.
	 *
	 * @return listaCedentes
	 */
	public final Collection<Cedente> getListaCedentes() {
		if (this.listaCedentes == null) {
			this.listaCedentes = new ArrayList<>();
		}
		return this.listaCedentes;
	}

	/**
	 * Define o valor do atributo listaCedentes.
	 *
	 * @param listaCedentes
	 *            valor a ser atribuído
	 */
	public final void setListaCedentes(final Collection<Cedente> listaCedentes) {
		this.listaCedentes = listaCedentes;
	}

	/**
	 * Retorna o valor do atributo cedentesSelecionados.
	 *
	 * @return cedentesSelecionados
	 */
	public final List<Cedente> getCedentesSelecionados() {
		final List<Cedente> cedentesSelecionados = new ArrayList<>();

		if (UtilObjeto.isReferencia(this.listaCedentes)) {
			for (final Cedente cedente : this.listaCedentes) {
				if (cedente.isUtilizado()) {
					cedentesSelecionados.add(cedente);
				}
			}
		}
		return cedentesSelecionados;
	}

	/**
	 * Retorna o valor do atributo exibirNovaFormaGarantia.
	 *
	 * @return exibirNovaFormaGarantia
	 */
	public final boolean isExibirNovaFormaGarantia() {
		return this.exibirNovaFormaGarantia;
	}

	/**
	 * Define o valor do atributo exibirNovaFormaGarantia.
	 *
	 * @param exibirNovaFormaGarantia
	 *            valor a ser atribuído
	 */
	public final void setExibirNovaFormaGarantia(final boolean exibirNovaFormaGarantia) {
		this.exibirNovaFormaGarantia = exibirNovaFormaGarantia;
	}

	/**
	 * Retorna o valor do atributo exibirBtnOu.
	 *
	 * @return exibirBtnOu
	 */
	public final boolean isExibirBtnOu() {
		return this.exibirBtnOu;
	}

	/**
	 * Define o valor do atributo exibirBtnOu.
	 *
	 * @param exibirBtnOu
	 *            valor a ser atribuído
	 */
	public final void setExibirBtnOu(final boolean exibirBtnOu) {
		this.exibirBtnOu = exibirBtnOu;
	}

	/**
	 * Retorna o valor do atributo parametrizacaoList.
	 *
	 * @return parametrizacaoList
	 */
	public final Collection<ParametrizacaoContratoVO> getParametrizacaoList() {
		if (this.parametrizacaoList == null) {
			this.parametrizacaoList = new ArrayList<>();
		}
		return this.parametrizacaoList;
	}

	/**
	 * Define o valor do atributo parametrizacaoList.
	 *
	 * @param parametrizacaoList
	 *            valor a ser atribuído
	 */
	public final void setParametrizacaoList(final Collection<ParametrizacaoContratoVO> parametrizacaoList) {
		this.parametrizacaoList = parametrizacaoList;
	}

	/**
	 * Retorna o valor do atributo exibirModalOperacaoRealizadaComSucesso.
	 *
	 * @return exibirModalOperacaoRealizadaComSucesso
	 */
	public final boolean isExibirModalOperacaoRealizadaComSucesso() {
		return this.exibirModalOperacaoRealizadaComSucesso;
	}

	/**
	 * Define o valor do atributo exibirModalOperacaoRealizadaComSucesso.
	 *
	 * @param exibirModalOperacaoRealizadaComSucesso
	 *            valor a ser atribuído
	 */
	public final void setExibirModalOperacaoRealizadaComSucesso(final boolean exibirModalOperacaoRealizadaComSucesso) {
		this.exibirModalOperacaoRealizadaComSucesso = exibirModalOperacaoRealizadaComSucesso;
	}

	/**
	 * Retorna o valor do atributo mensagemSalvarParametrizacao.
	 *
	 * @return mensagemSalvarParametrizacao
	 */
	public final String getMensagemSalvarParametrizacao() {
		return this.mensagemSalvarParametrizacao;
	}

	/**
	 * Define o valor do atributo mensagemSalvarParametrizacao.
	 *
	 * @param mensagemSalvarParametrizacao
	 *            valor a ser atribuído
	 */
	public final void setMensagemSalvarParametrizacao(final String mensagemSalvarParametrizacao) {
		this.mensagemSalvarParametrizacao = mensagemSalvarParametrizacao;
	}

	/**
	 * Retorna o valor do atributo identificadorRemocao.
	 *
	 * @return identificadorRemocao
	 */
	public final String getIdentificadorRemocao() {
		return this.identificadorRemocao;
	}

	/**
	 * Define o valor do atributo identificadorRemocao.
	 *
	 * @param identificadorRemocao
	 *            valor a ser atribuído
	 */
	public final void setIdentificadorRemocao(final String identificadorRemocao) {
		this.identificadorRemocao = identificadorRemocao;
	}

	/**
	 * Retorna o valor do atributo identificadorEdicao.
	 *
	 * @return identificadorEdicao
	 */
	public final String getIdentificadorEdicao() {
		return this.identificadorEdicao;
	}

	/**
	 * Define o valor do atributo identificadorEdicao.
	 *
	 * @param identificadorEdicao
	 *            valor a ser atribuído
	 */
	public final void setIdentificadorEdicao(final String identificadorEdicao) {
		this.identificadorEdicao = identificadorEdicao;
	}

	/**
	 * Retorna o valor do atributo exibirModalValidacao.
	 *
	 * @return exibirModalValidacao
	 */
	public final boolean isExibirModalValidacao() {
		return this.exibirModalValidacao;
	}

	/**
	 * Define o valor do atributo exibirModalValidacao.
	 *
	 * @param exibirModalValidacao
	 *            valor a ser atribuído
	 */
	public final void setExibirModalValidacao(final boolean exibirModalValidacao) {
		this.exibirModalValidacao = exibirModalValidacao;
	}

	/**
	 * Retorna o valor do atributo desabilitarCampos.
	 *
	 * @return desabilitarCampos
	 */
	public final boolean isDesabilitarCampos() {
		return this.desabilitarCampos;
	}

	/**
	 * Define o valor do atributo desabilitarCampos.
	 *
	 * @param desabilitarCampos
	 *            valor a ser atribuído
	 */
	public final void setDesabilitarCampos(final boolean desabilitarCampos) {
		this.desabilitarCampos = desabilitarCampos;
	}

	/**
	 * Retorna o valor do atributo exibirModalExclusao.
	 *
	 * @return exibirModalExclusao
	 */
	public final boolean isExibirModalExclusao() {
		return this.exibirModalExclusao;
	}

	/**
	 * Define o valor do atributo exibirModalExclusao.
	 *
	 * @param exibirModalExclusao
	 *            valor a ser atribuído
	 */
	public final void setExibirModalExclusao(final boolean exibirModalExclusao) {
		this.exibirModalExclusao = exibirModalExclusao;
	}

	/**
	 * Retorna o valor do atributo nuContaContrato.
	 *
	 * @return nuContaContrato
	 */
	public final String getNuContaContrato() {
		return this.nuContaContrato;
	}

	/**
	 * Define o valor do atributo nuContaContrato.
	 *
	 * @param nuContaContrato
	 *            valor a ser atribuído
	 */
	public final void setNuContaContrato(final String nuContaContrato) {
		this.nuContaContrato = nuContaContrato;
	}

	/**
	 * Retorna o valor do atributo listaExclusaoParametrizacao.
	 *
	 * @return listaExclusaoParametrizacao
	 */
	public Collection<ParametrizacaoContratoVO> getListaExclusaoParametrizacao() {

		return this.listaExclusaoParametrizacao;
	}

	/**
	 * Define o valor do atributo listaExclusaoParametrizacao.
	 *
	 * @param listaExclusaoParametrizacao
	 *            valor a ser atribuído
	 */
	public void setListaExclusaoParametrizacao(final Collection<ParametrizacaoContratoVO> listaExclusaoParametrizacao) {

		this.listaExclusaoParametrizacao = listaExclusaoParametrizacao;
	}

	/**
	 * Retorna o valor do atributo.
	 *
	 * @return parametrizacao contrato vo temp
	 */
	public ParametrizacaoContratoVO getParametrizacaoContratoVOTemp() {

		return this.parametrizacaoContratoVOTemp;
	}

	/**
	 * Define o valor do atributo.
	 *
	 * @param parametrizacaoContratoVOTemp
	 *            the parametrizacao contrato vo temp
	 */
	public void setParametrizacaoContratoVOTemp(final ParametrizacaoContratoVO parametrizacaoContratoVOTemp) {

		this.parametrizacaoContratoVOTemp = parametrizacaoContratoVOTemp;
	}

	/**
	 * Retorna o valor do atributo contaCorrente.
	 *
	 * @return contaCorrente
	 */
	public ContaCorrente getContaCorrente() {
		return this.contaCorrente;
	}

	/**
	 * Define o valor do atributo contaCorrente.
	 *
	 * @param contaCorrente
	 *            valor a ser atribuído
	 */
	public void setContaCorrente(final ContaCorrente contaCorrente) {

		this.contaCorrente = contaCorrente;
	}

	/**
	 * Retorna o valor do atributo exibirModalExcepcionar.
	 *
	 * @return exibirModalExcepcionar
	 */
	public boolean isExibirModalExcepcionar() {

		return this.exibirModalExcepcionar;
	}

	/**
	 * Define o valor do atributo exibirModalExcepcionar.
	 *
	 * @param exibirModalExcepcionar
	 *            valor a ser atribuído
	 */
	public void setExibirModalExcepcionar(final boolean exibirModalExcepcionar) {

		this.exibirModalExcepcionar = exibirModalExcepcionar;
	}

	/**
	 * Retorna o valor do atributo identificadorExcepcionar.
	 *
	 * @return identificadorExcepcionar
	 */
	public String getIdentificadorExcepcionar() {

		return this.identificadorExcepcionar;
	}

	/**
	 * Define o valor do atributo identificadorExcepcionar.
	 *
	 * @param identificadorExcepcionar
	 *            valor a ser atribuído
	 */
	public void setIdentificadorExcepcionar(final String identificadorExcepcionar) {

		this.identificadorExcepcionar = identificadorExcepcionar;
	}

	/**
	 * Retorna o valor do atributo duplicataExcepcionada.
	 *
	 * @return duplicataExcepcionada
	 */
	public DuplicataExcepcionada getDuplicataExcepcionada() {

		return this.duplicataExcepcionada;
	}

	/**
	 * Define o valor do atributo duplicataExcepcionada.
	 *
	 * @param duplicataExcepcionada
	 *            valor a ser atribuído
	 */
	public void setDuplicataExcepcionada(final DuplicataExcepcionada duplicataExcepcionada) {

		this.duplicataExcepcionada = duplicataExcepcionada;
	}

	/**
	 * Retorna o valor do atributo duplicatasEncontradas.
	 *
	 * @return duplicatasEncontradas
	 */
	public Collection<DuplicataVO> getDuplicatasEncontradas() {

		return this.duplicatasEncontradas;
	}

	/**
	 * Define o valor do atributo duplicatasEncontradas.
	 *
	 * @param duplicatasEncontradas
	 *            valor a ser atribuído
	 */
	public void setDuplicatasEncontradas(final Collection<DuplicataVO> duplicatasEncontradas) {

		this.duplicatasEncontradas = duplicatasEncontradas;
	}

	/**
	 * Retorna o valor do atributo duplicatasParaExcepcionar.
	 *
	 * @return duplicatasParaExcepcionar
	 */
	public Collection<DuplicataVO> getDuplicatasParaExcepcionar() {
		if (this.duplicatasParaExcepcionar == null) {
			this.duplicatasParaExcepcionar = new ArrayList<>();
		}
		return this.duplicatasParaExcepcionar;
	}

	/**
	 * Define o valor do atributo duplicatasParaExcepcionar.
	 *
	 * @param duplicatasParaExcepcionar
	 *            valor a ser atribuído
	 */
	public void setDuplicatasParaExcepcionar(final Collection<DuplicataVO> duplicatasParaExcepcionar) {

		this.duplicatasParaExcepcionar = duplicatasParaExcepcionar;
	}

	/**
	 * Retorna o valor do atributo listaParametroCalculo.
	 *
	 * @return listaParametroCalculo
	 */
	public Collection<ParametroCalculo> getListaParametroCalculo() {
		if (this.listaParametroCalculo == null) {
			this.listaParametroCalculo = new ArrayList<>();
		}
		return this.listaParametroCalculo;

	}

	/**
	 * <p>
	 * Método responsável por listar os parametros de calcuo para Cheque.
	 * <p>
	 *
	 * @return Collection<ParametroCalculo>
	 * @author guilherme.santos
	 */
	public Collection<ParametroCalculo> getListaParametroCalculoCheque() {
		final List<ParametroCalculo> listaFiltrada = new ArrayList<>();
		for (final ParametroCalculo parametro : this.listaParametroCalculo) {
			if (parametro.getIcAgrupamento().equals(ParametroCalculoAgrupamentoEnum.CHEQUE.getDescricao())) {
				listaFiltrada.add(parametro);
			}
		}
		return listaFiltrada;

	}

	/**
	 * <p>
	 * Método responsável por listar os parametros de calcuo para Aplicação
	 * Financeira.
	 * <p>
	 *
	 * @return Collection<ParametroCalculo>
	 * @author Caio Graco
	 */
	public Collection<ParametroCalculo> getListaParametroCalculoAplicacaoFinanceira() {

		final List<ParametroCalculo> listaFiltrada = new ArrayList<>();

		for (final ParametroCalculo parametro : this.listaParametroCalculo) {
			if (parametro.getIcAgrupamento().equals(ParametroCalculoAgrupamentoEnum.APLICACAO_FINANCEIRA.getDescricao())) {
				listaFiltrada.add(parametro);
			}
		}

		return listaFiltrada;
	}

	/**
	 * <p>
	 * Método responsável por listar os parametros de calcuo para Duplicata.
	 * <p>
	 *
	 * @return Collection<ParametroCalculo>
	 * @author guilherme.santos
	 */
	public Collection<ParametroCalculo> getListaParametroCalculoDuplicata() {
		final List<ParametroCalculo> listaFiltrada = new ArrayList<>();

		for (final ParametroCalculo parametro : this.getListaParametroCalculo()) {
			if (parametro.getIcAgrupamento().equals(ParametroCalculoAgrupamentoEnum.DUPLICATA.getDescricao())) {
				listaFiltrada.add(parametro);
			}
		}
		return listaFiltrada;

	}

	/**
	 * Define o valor do atributo listaParametroCalculo.
	 *
	 * @param listaParametroCalculo
	 *            valor a ser atribuído
	 */
	public void setListaParametroCalculo(final Collection<ParametroCalculo> listaParametroCalculo) {

		this.listaParametroCalculo = listaParametroCalculo;

	}

	/**
	 * Retorna o valor do atributo duplicataVO.
	 *
	 * @return duplicataVO
	 */
	public DuplicataVO getDuplicataVO() {

		return this.duplicataVO;
	}

	/**
	 * Define o valor do atributo duplicataVO.
	 *
	 * @param duplicataVO
	 *            valor a ser atribuído
	 */
	public void setDuplicataVO(final DuplicataVO duplicataVO) {

		this.duplicataVO = duplicataVO;
	}

	/**
	 * Retorna o valor do atributo garantias.
	 *
	 * @return garantias
	 */
	public Collection<Garantia> getGarantias() {

		return this.garantias;
	}

	/**
	 * Define o valor do atributo garantias.
	 *
	 * @param garantias
	 *            valor a ser atribuído
	 */
	public void setGarantias(final Collection<Garantia> garantias) {

		this.garantias = garantias;
	}

	/**
	 * Retorna o valor do atributo identificadorGarantia.
	 *
	 * @return identificadorGarantia
	 */
	public String getIdentificadorGarantia() {

		return this.identificadorGarantia;
	}

	/**
	 * Define o valor do atributo identificadorGarantia.
	 *
	 * @param identificadorGarantia
	 *            valor a ser atribuído
	 */
	public void setIdentificadorGarantia(final String identificadorGarantia) {

		this.identificadorGarantia = identificadorGarantia;
	}

	/**
	 * Retorna o valor do atributo desabilitarTipoGarantia.
	 *
	 * @return desabilitarTipoGarantia
	 */
	public boolean isDesabilitarTipoGarantia() {

		return this.desabilitarTipoGarantia;
	}

	/**
	 * Define o valor do atributo desabilitarTipoGarantia.
	 *
	 * @param desabilitarTipoGarantia
	 *            valor a ser atribuído
	 */
	public void setDesabilitarTipoGarantia(final boolean desabilitarTipoGarantia) {

		this.desabilitarTipoGarantia = desabilitarTipoGarantia;
	}

	/**
	 * Retorna o valor do atributo desabilitarFormaGarantia.
	 *
	 * @return desabilitarFormaGarantia
	 */
	public boolean isDesabilitarFormaGarantia() {

		return this.desabilitarFormaGarantia;
	}

	/**
	 * Define o valor do atributo desabilitarFormaGarantia.
	 *
	 * @param desabilitarFormaGarantia
	 *            valor a ser atribuído
	 */
	public void setDesabilitarFormaGarantia(final boolean desabilitarFormaGarantia) {

		this.desabilitarFormaGarantia = desabilitarFormaGarantia;
	}

	/**
	 * Retorna o valor do atributo ocultarPrazoMaximo.
	 *
	 * @return ocultarPrazoMaximo
	 */
	public boolean isOcultarPrazoMaximo() {

		return this.ocultarPrazoMaximo;
	}

	/**
	 * Define o valor do atributo ocultarPrazoMaximo.
	 *
	 * @param ocultarPrazoMaximo
	 *            valor a ser atribuído
	 */
	public void setOcultarPrazoMaximo(final boolean ocultarPrazoMaximo) {

		this.ocultarPrazoMaximo = ocultarPrazoMaximo;
	}

	/**
	 * Retorna o valor do atributo ocultarValorMaximo.
	 *
	 * @return ocultarValorMaximo
	 */
	public boolean isOcultarValorMaximo() {

		return this.ocultarValorMaximo;
	}

	/**
	 * Define o valor do atributo ocultarValorMaximo.
	 *
	 * @param ocultarValorMaximo
	 *            valor a ser atribuído
	 */
	public void setOcultarValorMaximo(final boolean ocultarValorMaximo) {

		this.ocultarValorMaximo = ocultarValorMaximo;
	}

	/**
	 * Retorna o valor do atributo ocultarPercentualMaximo.
	 *
	 * @return ocultarPercentualMaximo
	 */
	public boolean isOcultarPercentualMaximo() {

		return this.ocultarPercentualMaximo;
	}

	/**
	 * Define o valor do atributo ocultarPercentualMaximo.
	 *
	 * @param ocultarPercentualMaximo
	 *            valor a ser atribuído
	 */
	public void setOcultarPercentualMaximo(final boolean ocultarPercentualMaximo) {

		this.ocultarPercentualMaximo = ocultarPercentualMaximo;
	}

	/**
	 * Retorna o valor do atributo ocultarValor.
	 *
	 * @return ocultarValor
	 */
	public boolean isOcultarValor() {

		return this.ocultarValor;
	}

	/**
	 * Define o valor do atributo ocultarValor.
	 *
	 * @param ocultarValor
	 *            valor a ser atribuído
	 */
	public void setOcultarValor(final boolean ocultarValor) {

		this.ocultarValor = ocultarValor;
	}

	/**
	 * Retorna o valor do atributo ocultarInstrucaoProtesto.
	 *
	 * @return ocultarInstrucaoProtesto
	 */
	public boolean isOcultarInstrucaoProtesto() {

		return this.ocultarInstrucaoProtesto;
	}

	/**
	 * Define o valor do atributo ocultarInstrucaoProtesto.
	 *
	 * @param ocultarInstrucaoProtesto
	 *            valor a ser atribuído
	 */
	public void setOcultarInstrucaoProtesto(final boolean ocultarInstrucaoProtesto) {

		this.ocultarInstrucaoProtesto = ocultarInstrucaoProtesto;
	}

	/**
	 * Retorna o valor do atributo contemAplicacaoFinanceira.
	 *
	 * @return contemAplicacaoFinanceira
	 */
	public boolean isContemAplicacaoFinanceira() {

		return this.contemAplicacaoFinanceira;
	}

	/**
	 * Define o valor do atributo contemAplicacaoFinanceira.
	 *
	 * @param contemAplicacaoFinanceira
	 *            valor a ser atribuído
	 */
	public void setContemAplicacaoFinanceira(final boolean contemAplicacaoFinanceira) {

		this.contemAplicacaoFinanceira = contemAplicacaoFinanceira;
	}

	/**
	 * Retorna o valor do atributo cedenteIncluido.
	 *
	 * @return cedenteIncluido
	 */
	public Cedente getCedenteIncluido() {

		return this.cedenteIncluido;
	}

	/**
	 * Define o valor do atributo cedenteIncluido.
	 *
	 * @param cedenteIncluido
	 *            valor a ser atribuído
	 */
	public void setCedenteIncluido(final Cedente cedenteIncluido) {

		this.cedenteIncluido = cedenteIncluido;
	}

	/**
	 * Retorna o valor do atributo exibirAplicacaoFinanceira.
	 *
	 * @return exibirAplicacaoFinanceira
	 */
	public boolean isExibirAplicacaoFinanceira() {

		return this.exibirAplicacaoFinanceira;
	}

	/**
	 * Define o valor do atributo exibirAplicacaoFinanceira.
	 *
	 * @param exibirAplicacaoFinanceira
	 *            valor a ser atribuído
	 */
	public void setExibirAplicacaoFinanceira(final boolean exibirAplicacaoFinanceira) {

		this.exibirAplicacaoFinanceira = exibirAplicacaoFinanceira;
	}

	/**
	 * Retorna o valor do atributo contaCorrenteDaArvore.
	 *
	 * @return contaCorrenteDaArvore
	 */
	public TreeNode getContaCorrenteDaArvore() {

		return this.contaCorrenteDaArvore;
	}

	/**
	 * Define o valor do atributo contaCorrenteDaArvore.
	 *
	 * @param contaCorrenteDaArvore
	 *            valor a ser atribuído
	 */
	public void setContaCorrenteDaArvore(final TreeNode contaCorrenteDaArvore) {

		this.contaCorrenteDaArvore = contaCorrenteDaArvore;
	}

	/**
	 * Retorna o valor do atributo aplicacoesSelecionadas.
	 *
	 * @return aplicacoesSelecionadas
	 */
	public TreeNode[] getAplicacoesSelecionadas() {

		return this.aplicacoesSelecionadas;
	}

	/**
	 * Define o valor do atributo aplicacoesSelecionadas.
	 *
	 * @param aplicacoesSelecionadas
	 *            valor a ser atribuído
	 */
	public void setAplicacoesSelecionadas(final TreeNode[] aplicacoesSelecionadas) {

		this.aplicacoesSelecionadas = aplicacoesSelecionadas;
	}

	/**
	 * Retorna o valor do atributo contaContratoList.
	 *
	 * @return contaContratoList
	 */
	public Collection<ContaContrato> getContaContratoList() {

		return this.contaContratoList;

	}

	/**
	 * Define o valor do atributo contaContratoList.
	 *
	 * @param contaContratoList
	 *            valor a ser atribuído
	 */
	public void setContaContratoList(final Collection<ContaContrato> contaContratoList) {

		this.contaContratoList = contaContratoList;

	}

	/**
	 * Retorna o valor do atributo contaContrato.
	 *
	 * @return contaContrato
	 */
	public ContaContrato getContaContrato() {

		return this.contaContrato;

	}

	/**
	 * Define o valor do atributo contaContrato.
	 *
	 * @param contaContrato
	 *            valor a ser atribuído
	 */
	public void setContaContrato(final ContaContrato contaContrato) {

		this.contaContrato = contaContrato;

	}

	/**
	 * Retorna o valor do atributo listaContaContrato.
	 *
	 * @return listaContaContrato
	 */
	public List<ContaContrato> getListaContaContrato() {
		if (this.listaContaContrato == null) {
			this.listaContaContrato = new ArrayList<>();
		}

		return this.listaContaContrato;
	}

	/**
	 * Define o valor do atributo listaContaContrato.
	 *
	 * @param listaContaContrato
	 *            valor a ser atribuído
	 */
	public void setListaContaContrato(final List<ContaContrato> listaContaContrato) {

		this.listaContaContrato = listaContaContrato;
	}

	/**
	 * Retorna o valor do atributo listaContaContratoDasAplicacoes.
	 *
	 * @return listaContaContratoDasAplicacoes
	 */
	public List<ContaContrato> getListaContaContratoDasAplicacoes() {
		if (this.listaContaContratoDasAplicacoes == null) {
			this.listaContaContratoDasAplicacoes = new ArrayList<>();
		}
		return this.listaContaContratoDasAplicacoes;
	}

	/**
	 * Define o valor do atributo listaContaContratoDasAplicacoes.
	 *
	 * @param listaContaContratoDasAplicacoes
	 *            valor a ser atribuído
	 */
	public void setListaContaContratoDasAplicacoes(final List<ContaContrato> listaContaContratoDasAplicacoes) {

		this.listaContaContratoDasAplicacoes = listaContaContratoDasAplicacoes;
	}

	/**
	 * Retorna o valor do atributo contaContratoAplicacaoFinanceira.
	 *
	 * @return contaContratoAplicacaoFinanceira
	 */
	public ContaContrato getContaContratoAplicacaoFinanceira() {

		return this.contaContratoAplicacaoFinanceira;
	}

	/**
	 * Define o valor do atributo contaContratoAplicacaoFinanceira.
	 *
	 * @param contaContratoAplicacaoFinanceira
	 *            valor a ser atribuído
	 */
	public void setContaContratoAplicacaoFinanceira(final ContaContrato contaContratoAplicacaoFinanceira) {

		this.contaContratoAplicacaoFinanceira = contaContratoAplicacaoFinanceira;
	}

	/**
	 * Retorna o valor do atributo listaAplicacaoSelecionadas.
	 *
	 * @return listaAplicacaoSelecionadas
	 */
	public Collection<GarantiaAplicacao> getListaAplicacaoSelecionadas() {

		if (this.listaAplicacaoSelecionadas == null) {
			this.listaAplicacaoSelecionadas = new ArrayList<>();
		}
		return this.listaAplicacaoSelecionadas;

	}

	/**
	 * Define o valor do atributo listaAplicacaoSelecionadas.
	 *
	 * @param listaAplicacaoSelecionadas
	 *            valor a ser atribuído
	 */
	public void setListaAplicacaoSelecionadas(final Collection<GarantiaAplicacao> listaAplicacaoSelecionadas) {

		this.listaAplicacaoSelecionadas = listaAplicacaoSelecionadas;

	}

	/**
	 * Retorna o valor do atributo parametrizacaoEdicao.
	 *
	 * @return parametrizacaoEdicao
	 */
	public ParametrizacaoContratoVO getParametrizacaoEdicao() {

		return this.parametrizacaoEdicao;

	}

	/**
	 * Define o valor do atributo parametrizacaoEdicao.
	 *
	 * @param parametrizacaoEdicao
	 *            valor a ser atribuído
	 */
	public void setParametrizacaoEdicao(final ParametrizacaoContratoVO parametrizacaoEdicao) {

		this.parametrizacaoEdicao = parametrizacaoEdicao;

	}

	/**
	 * Retorna o valor do atributo nuContaCorrenteNaoLivreMovimentacao.
	 *
	 * @return nuContaCorrenteNaoLivreMovimentacao
	 */
	public String getNuContaCorrenteNaoLivreMovimentacao() {

		return this.nuContaCorrenteNaoLivreMovimentacao;
	}

	/**
	 * Define o valor do atributo nuContaCorrenteNaoLivreMovimentacao.
	 *
	 * @param nuContaCorrenteNaoLivreMovimentacao
	 *            valor a ser atribuído
	 */
	public void setNuContaCorrenteNaoLivreMovimentacao(final String nuContaCorrenteNaoLivreMovimentacao) {

		this.nuContaCorrenteNaoLivreMovimentacao = nuContaCorrenteNaoLivreMovimentacao;
	}

	/**
	 * Retorna o valor do atributo ocultarTipoGarantia.
	 *
	 * @return ocultarTipoGarantia
	 */
	public boolean isOcultarTipoGarantia() {

		return this.ocultarTipoGarantia;
	}

	/**
	 * Define o valor do atributo ocultarTipoGarantia.
	 *
	 * @param ocultarTipoGarantia
	 *            valor a ser atribuído
	 */
	public void setOcultarTipoGarantia(final boolean ocultarTipoGarantia) {

		this.ocultarTipoGarantia = ocultarTipoGarantia;
	}

	/**
	 * Retorna o valor do atributo ocultarFormaGarantia.
	 *
	 * @return ocultarFormaGarantia
	 */
	public boolean isOcultarFormaGarantia() {

		return this.ocultarFormaGarantia;
	}

	/**
	 * Define o valor do atributo ocultarFormaGarantia.
	 *
	 * @param ocultarFormaGarantia
	 *            valor a ser atribuído
	 */
	public void setOcultarFormaGarantia(final boolean ocultarFormaGarantia) {

		this.ocultarFormaGarantia = ocultarFormaGarantia;
	}

	/**
	 * Retorna o valor do atributo exibirCamposEdicao.
	 *
	 * @return exibirCamposEdicao
	 */
	public boolean isExibirCamposEdicao() {

		return this.exibirCamposEdicao;
	}

	/**
	 * Define o valor do atributo exibirCamposEdicao.
	 *
	 * @param exibirCamposEdicao
	 *            valor a ser atribuído
	 */
	public void setExibirCamposEdicao(final boolean exibirCamposEdicao) {

		this.exibirCamposEdicao = exibirCamposEdicao;
	}

	/**
	 * Retorna o valor do atributo exibirBotaoIncluirContaNLMContrato.
	 *
	 * @return exibirBotaoIncluirContaNLMContrato
	 */
	public boolean isExibirBotaoIncluirContaNLMContrato() {

		return this.exibirBotaoIncluirContaNLMContrato;
	}

	/**
	 * Define o valor do atributo exibirBotaoIncluirContaNLMContrato.
	 *
	 * @param exibirBotaoIncluirContaNLMContrato
	 *            valor a ser atribuído
	 */
	public void setExibirBotaoIncluirContaNLMContrato(final boolean exibirBotaoIncluirContaNLMContrato) {

		this.exibirBotaoIncluirContaNLMContrato = exibirBotaoIncluirContaNLMContrato;
	}

	/**
	 * Retorna o valor do atributo exibirBotaoMarcarContaNLMContrato.
	 *
	 * @return exibirBotaoMarcarContaNLMContrato
	 */
	public boolean isExibirBotaoMarcarContaNLMContrato() {

		return this.exibirBotaoMarcarContaNLMContrato;
	}

	/**
	 * Retorna o valor do atributo exibirBotaoMarcarContaNLMContrato.
	 *
	 * @return exibirBotaoMarcarContaNLMContrato
	 */
	public boolean getExibirBotaoMarcarContaNLMContrato() {

		return this.exibirBotaoMarcarContaNLMContrato;
	}

	/**
	 * Define o valor do atributo exibirBotaoMarcarContaNLMContrato.
	 *
	 * @param exibirBotaoMarcarContaNLMContrato
	 *            valor a ser atribuído
	 */
	public void setExibirBotaoMarcarContaNLMContrato(final boolean exibirBotaoMarcarContaNLMContrato) {

		this.exibirBotaoMarcarContaNLMContrato = exibirBotaoMarcarContaNLMContrato;
	}

	/**
	 * Retorna o valor do atributo exibirBotaoExcluirContaNLMContrato.
	 *
	 * @return exibirBotaoExcluirContaNLMContrato
	 */
	public boolean isExibirBotaoExcluirContaNLMContrato() {

		return this.exibirBotaoExcluirContaNLMContrato;
	}

	/**
	 * Define o valor do atributo exibirBotaoExcluirContaNLMContrato.
	 *
	 * @param exibirBotaoExcluirContaNLMContrato
	 *            valor a ser atribuído
	 */
	public void setExibirBotaoExcluirContaNLMContrato(final boolean exibirBotaoExcluirContaNLMContrato) {

		this.exibirBotaoExcluirContaNLMContrato = exibirBotaoExcluirContaNLMContrato;
	}

	/**
	 * Retorna o valor do atributo exibirBotaoIncluirGarantia.
	 *
	 * @return exibirBotaoIncluirGarantia
	 */
	public boolean isExibirBotaoIncluirGarantia() {

		return this.exibirBotaoIncluirGarantia;
	}

	/**
	 * Define o valor do atributo exibirBotaoIncluirGarantia.
	 *
	 * @param exibirBotaoIncluirGarantia
	 *            valor a ser atribuído
	 */
	public void setExibirBotaoIncluirGarantia(final boolean exibirBotaoIncluirGarantia) {

		this.exibirBotaoIncluirGarantia = exibirBotaoIncluirGarantia;
	}

	/**
	 * Retorna o valor do atributo exibirBotaoEditarGarantia.
	 *
	 * @return exibirBotaoEditarGarantia
	 */
	public boolean isExibirBotaoEditarGarantia() {

		return this.exibirBotaoEditarGarantia;
	}

	/**
	 * Retorna o valor do atributo exibirBotaoEditarGarantia.
	 *
	 * @return exibirBotaoEditarGarantia
	 */
	public boolean getExibirBotaoEditarGarantia() {

		return this.exibirBotaoEditarGarantia;
	}

	/**
	 * Define o valor do atributo exibirBotaoEditarGarantia.
	 *
	 * @param exibirBotaoEditarGarantia
	 *            valor a ser atribuído
	 */
	public void setExibirBotaoEditarGarantia(final boolean exibirBotaoEditarGarantia) {

		this.exibirBotaoEditarGarantia = exibirBotaoEditarGarantia;
	}

	/**
	 * Retorna o valor do atributo exibirBotaoExcluirGarantia.
	 *
	 * @return exibirBotaoExcluirGarantia
	 */
	public boolean isExibirBotaoExcluirGarantia() {

		return this.exibirBotaoExcluirGarantia;
	}

	/**
	 * Define o valor do atributo exibirBotaoExcluirGarantia.
	 *
	 * @param exibirBotaoExcluirGarantia
	 *            valor a ser atribuído
	 */
	public void setExibirBotaoExcluirGarantia(final boolean exibirBotaoExcluirGarantia) {

		this.exibirBotaoExcluirGarantia = exibirBotaoExcluirGarantia;
	}

	/**
	 * Retorna o valor do atributo exibirBotaoDuplicataExcepcionadaGarantia.
	 *
	 * @return exibirBotaoDuplicataExcepcionadaGarantia
	 */
	public boolean isExibirBotaoDuplicataExcepcionadaGarantia() {

		return this.exibirBotaoDuplicataExcepcionadaGarantia;
	}

	/**
	 * Define o valor do atributo exibirBotaoDuplicataExcepcionadaGarantia.
	 *
	 * @param exibirBotaoDuplicataExcepcionadaGarantia
	 *            valor a ser atribuído
	 */
	public void setExibirBotaoDuplicataExcepcionadaGarantia(final boolean exibirBotaoDuplicataExcepcionadaGarantia) {

		this.exibirBotaoDuplicataExcepcionadaGarantia = exibirBotaoDuplicataExcepcionadaGarantia;
	}

	/**
	 * Retorna o valor do atributo exibirBotaoEditarParametrosCalculo.
	 *
	 * @return exibirBotaoEditarParametrosCalculo
	 */
	public boolean isExibirBotaoEditarParametrosCalculo() {

		return this.exibirBotaoEditarParametrosCalculo;
	}

	/**
	 * Define o valor do atributo exibirBotaoEditarParametrosCalculo.
	 *
	 * @param exibirBotaoEditarParametrosCalculo
	 *            valor a ser atribuído
	 */
	public void setExibirBotaoEditarParametrosCalculo(final boolean exibirBotaoEditarParametrosCalculo) {

		this.exibirBotaoEditarParametrosCalculo = exibirBotaoEditarParametrosCalculo;
	}

	/**
	 * Retorna o valor do atributo
	 * exibirBotaoIncluirDuplicataExcepcionadaGarantia.
	 *
	 * @return exibirBotaoIncluirDuplicataExcepcionadaGarantia
	 */
	public boolean isExibirBotaoIncluirDuplicataExcepcionadaGarantia() {

		return this.exibirBotaoIncluirDuplicataExcepcionadaGarantia;
	}

	/**
	 * Retorna o valor do atributo
	 * exibirBotaoIncluirDuplicataExcepcionadaGarantia.
	 *
	 * @return exibirBotaoIncluirDuplicataExcepcionadaGarantia
	 */
	public boolean getExibirBotaoIncluirDuplicataExcepcionadaGarantia() {

		return this.exibirBotaoIncluirDuplicataExcepcionadaGarantia;
	}

	/**
	 * Define o valor do atributo
	 * exibirBotaoIncluirDuplicataExcepcionadaGarantia.
	 *
	 * @param exibirBotaoIncluirDuplicataExcepcionadaGarantia
	 *            valor a ser atribuído
	 */
	public void setExibirBotaoIncluirDuplicataExcepcionadaGarantia(final boolean exibirBotaoIncluirDuplicataExcepcionadaGarantia) {

		this.exibirBotaoIncluirDuplicataExcepcionadaGarantia = exibirBotaoIncluirDuplicataExcepcionadaGarantia;
	}

	/**
	 * Retorna o valor do atributo
	 * exibirBotaoExcluirDuplicataExcepcionadaGarantia.
	 *
	 * @return exibirBotaoExcluirDuplicataExcepcionadaGarantia
	 */
	public boolean isExibirBotaoExcluirDuplicataExcepcionadaGarantia() {

		return this.exibirBotaoExcluirDuplicataExcepcionadaGarantia;
	}

	/**
	 * Retorna o valor do atributo
	 * exibirBotaoExcluirDuplicataExcepcionadaGarantia.
	 *
	 * @return exibirBotaoExcluirDuplicataExcepcionadaGarantia
	 */
	public boolean getExibirBotaoExcluirDuplicataExcepcionadaGarantia() {

		return this.exibirBotaoExcluirDuplicataExcepcionadaGarantia;
	}

	/**
	 * Define o valor do atributo
	 * exibirBotaoExcluirDuplicataExcepcionadaGarantia.
	 *
	 * @param exibirBotaoExcluirDuplicataExcepcionadaGarantia
	 *            valor a ser atribuído
	 */
	public void setExibirBotaoExcluirDuplicataExcepcionadaGarantia(final boolean exibirBotaoExcluirDuplicataExcepcionadaGarantia) {

		this.exibirBotaoExcluirDuplicataExcepcionadaGarantia = exibirBotaoExcluirDuplicataExcepcionadaGarantia;
	}

	/**
	 * Retorna o valor do atributo exibirBotaoConsultarContaNLMContrato.
	 *
	 * @return exibirBotaoConsultarContaNLMContrato
	 */
	public boolean isExibirBotaoConsultarContaNLMContrato() {

		return this.exibirBotaoConsultarContaNLMContrato;
	}

	/**
	 * Define o valor do atributo exibirBotaoConsultarContaNLMContrato.
	 *
	 * @param exibirBotaoConsultarContaNLMContrato
	 *            valor a ser atribuído
	 */
	public void setExibirBotaoConsultarContaNLMContrato(final boolean exibirBotaoConsultarContaNLMContrato) {

		this.exibirBotaoConsultarContaNLMContrato = exibirBotaoConsultarContaNLMContrato;
	}

	/**
	 * Retorna o valor do atributo listaContaContratoCheque.
	 *
	 * @return listaContaContratoCheque
	 */
	public List<ContaContrato> getListaContaContratoCheque() {

		if (this.listaContaContratoCheque == null) {
			this.listaContaContratoCheque = new ArrayList<>();
		}
		return this.listaContaContratoCheque;
	}

	/**
	 * Define o valor do atributo listaContaContratoCheque.
	 *
	 * @param listaContaContratoCheque
	 *            valor a ser atribuído
	 */
	public void setListaContaContratoCheque(final List<ContaContrato> listaContaContratoCheque) {

		this.listaContaContratoCheque = listaContaContratoCheque;
	}

	/**
	 * Retorna o valor do atributo contaContratoCheque.
	 *
	 * @return contaContratoCheque
	 */
	public ContaContrato getContaContratoCheque() {

		return this.contaContratoCheque;
	}

	/**
	 * Define o valor do atributo contaContratoCheque.
	 *
	 * @param contaContratoCheque
	 *            valor a ser atribuído
	 */
	public void setContaContratoCheque(final ContaContrato contaContratoCheque) {

		this.contaContratoCheque = contaContratoCheque;
	}

	/**
	 * Retorna o valor do atributo exibirCheque.
	 *
	 * @return exibirCheque
	 */
	public boolean isExibirCheque() {

		return this.exibirCheque;
	}

	/**
	 * Define o valor do atributo exibirCheque.
	 *
	 * @param exibirCheque
	 *            valor a ser atribuído
	 */
	public void setExibirCheque(final boolean exibirCheque) {

		this.exibirCheque = exibirCheque;
	}

	/**
	 * Retorna o valor do atributo chequeExcepcionado.
	 *
	 * @return chequeExcepcionado
	 */
	public ChequeExcepcionado getChequeExcepcionado() {
		if (this.chequeExcepcionado == null) {
			this.chequeExcepcionado = new ChequeExcepcionado();
		}

		return this.chequeExcepcionado;
	}

	/**
	 * Define o valor do atributo chequeExcepcionado.
	 *
	 * @param chequeExcepcionado
	 *            valor a ser atribuído
	 */
	public void setChequeExcepcionado(final ChequeExcepcionado chequeExcepcionado) {

		this.chequeExcepcionado = chequeExcepcionado;
	}

	/**
	 * Retorna o valor do atributo chequeVO.
	 *
	 * @return chequeVO
	 */
	public ChequeExcepcionadoVO getChequeVO() {

		return this.chequeVO;
	}

	/**
	 * Define o valor do atributo chequeVO.
	 *
	 * @param chequeVO
	 *            valor a ser atribuído
	 */
	public void setChequeVO(final ChequeExcepcionadoVO chequeVO) {

		this.chequeVO = chequeVO;
	}

	/**
	 * Retorna o valor do atributo chequesParaExcepcionar.
	 *
	 * @return chequesParaExcepcionar
	 */
	public Collection<ChequeExcepcionadoVO> getChequesParaExcepcionar() {

		return this.chequesParaExcepcionar;
	}

	/**
	 * Define o valor do atributo chequesParaExcepcionar.
	 *
	 * @param chequesParaExcepcionar
	 *            valor a ser atribuído
	 */
	public void setChequesParaExcepcionar(final Collection<ChequeExcepcionadoVO> chequesParaExcepcionar) {

		this.chequesParaExcepcionar = chequesParaExcepcionar;
	}

	/**
	 * Retorna o valor do atributo chequesExcepcionadosEncontrados.
	 *
	 * @return chequesExcepcionadosEncontrados
	 */
	public Collection<ChequeExcepcionadoVO> getChequesExcepcionadosEncontrados() {

		return this.chequesExcepcionadosEncontrados;
	}

	/**
	 * Define o valor do atributo chequesExcepcionadosEncontrados.
	 *
	 * @param chequesExcepcionadosEncontrados
	 *            valor a ser atribuído
	 */
	public void setChequesExcepcionadosEncontrados(final Collection<ChequeExcepcionadoVO> chequesExcepcionadosEncontrados) {

		this.chequesExcepcionadosEncontrados = chequesExcepcionadosEncontrados;
	}

	/**
	 * Retorna o valor do atributo listaContaContratoCartao.
	 *
	 * @return listaContaContratoCartao
	 */
	public List<ContaContrato> getListaContaContratoCartao() {
		if (this.listaContaContratoCartao == null) {
			this.listaContaContratoCartao = new ArrayList<>();
		}

		return this.listaContaContratoCartao;
	}

	/**
	 * Define o valor do atributo listaContaContratoCartao.
	 *
	 * @param listaContaContratoCartao
	 *            valor a ser atribuído
	 */
	public void setListaContaContratoCartao(final List<ContaContrato> listaContaContratoCartao) {

		this.listaContaContratoCartao = listaContaContratoCartao;
	}

	/**
	 * Retorna o valor do atributo contaCorrenteCartaoCredito.
	 *
	 * @return contaCorrenteCartaoCredito
	 */
	public TreeNode getContaCorrenteCartaoCredito() {
		if (this.contaCorrenteCartaoCredito == null) {
			this.contaCorrenteCartaoCredito = new DefaultTreeNode("", null);
		}

		return this.contaCorrenteCartaoCredito;
	}

	/**
	 * Define o valor do atributo contaCorrenteCartaoCredito.
	 *
	 * @param contaCorrenteCartaoCredito
	 *            valor a ser atribuído
	 */
	public void setContaCorrenteCartaoCredito(final TreeNode contaCorrenteCartaoCredito) {

		this.contaCorrenteCartaoCredito = contaCorrenteCartaoCredito;
	}

	/**
	 * Retorna o valor do atributo contaContratoCartao.
	 *
	 * @return contaContratoCartao
	 */
	public ContaContrato getContaContratoCartao() {

		return this.contaContratoCartao;
	}

	/**
	 * Define o valor do atributo contaContratoCartao.
	 *
	 * @param contaContratoCartao
	 *            valor a ser atribuído
	 */
	public void setContaContratoCartao(final ContaContrato contaContratoCartao) {

		this.contaContratoCartao = contaContratoCartao;
	}

	/**
	 * Retorna o valor do atributo cartoesSelecionados.
	 *
	 * @return cartoesSelecionados
	 */
	public TreeNode[] getCartoesSelecionados() {

		return this.cartoesSelecionados;
	}

	/**
	 * Define o valor do atributo cartoesSelecionados.
	 *
	 * @param cartoesSelecionados
	 *            valor a ser atribuído
	 */
	public void setCartoesSelecionados(final TreeNode[] cartoesSelecionados) {

		this.cartoesSelecionados = cartoesSelecionados;
	}

	/**
	 * Retorna o valor do atributo exibirCartaoCredito.
	 *
	 * @return exibirCartaoCredito
	 */
	public boolean isExibirCartaoCredito() {

		return this.exibirCartaoCredito;
	}

	/**
	 * Define o valor do atributo exibirCartaoCredito.
	 *
	 * @param exibirCartaoCredito
	 *            valor a ser atribuído
	 */
	public void setExibirCartaoCredito(final boolean exibirCartaoCredito) {

		this.exibirCartaoCredito = exibirCartaoCredito;
	}

	/**
	 * Retorna o valor do atributo desabilitarComboGarantia.
	 *
	 * @return desabilitarComboGarantia
	 */
	public boolean isDesabilitarComboGarantia() {

		return this.desabilitarComboGarantia;
	}

	/**
	 * Define o valor do atributo desabilitarComboGarantia.
	 *
	 * @param desabilitarComboGarantia
	 *            valor a ser atribuído
	 */
	public void setDesabilitarComboGarantia(final boolean desabilitarComboGarantia) {

		this.desabilitarComboGarantia = desabilitarComboGarantia;
	}

	/**
	 * Retorna o valor do atributo exibirBotaoIncluirChequeExcepcionadoGarantia.
	 *
	 * @return exibirBotaoIncluirChequeExcepcionadoGarantia
	 */
	public boolean isExibirBotaoIncluirChequeExcepcionadoGarantia() {

		return this.exibirBotaoIncluirChequeExcepcionadoGarantia;

	}

	/**
	 * Define o valor do atributo exibirBotaoIncluirChequeExcepcionadoGarantia.
	 *
	 * @param exibirBotaoIncluirChequeExcepcionadoGarantia
	 *            valor a ser atribuído
	 */
	public void setExibirBotaoIncluirChequeExcepcionadoGarantia(final boolean exibirBotaoIncluirChequeExcepcionadoGarantia) {

		this.exibirBotaoIncluirChequeExcepcionadoGarantia = exibirBotaoIncluirChequeExcepcionadoGarantia;

	}

	/**
	 * Retorna o valor do atributo exibirBotaoChequeExcepcionadoGarantia.
	 *
	 * @return exibirBotaoChequeExcepcionadoGarantia
	 */
	public boolean isExibirBotaoChequeExcepcionadoGarantia() {

		return this.exibirBotaoChequeExcepcionadoGarantia;

	}

	/**
	 * Define o valor do atributo exibirBotaoChequeExcepcionadoGarantia.
	 *
	 * @param exibirBotaoChequeExcepcionadoGarantia
	 *            valor a ser atribuído
	 */
	public void setExibirBotaoChequeExcepcionadoGarantia(final boolean exibirBotaoChequeExcepcionadoGarantia) {

		this.exibirBotaoChequeExcepcionadoGarantia = exibirBotaoChequeExcepcionadoGarantia;

	}

	/**
	 * Retorna o valor do atributo exibirBotaoExcluirChequeExcepcionadoGarantia.
	 *
	 * @return exibirBotaoExcluirChequeExcepcionadoGarantia
	 */
	public boolean isExibirBotaoExcluirChequeExcepcionadoGarantia() {

		return this.exibirBotaoExcluirChequeExcepcionadoGarantia;

	}

	/**
	 * Define o valor do atributo exibirBotaoExcluirChequeExcepcionadoGarantia.
	 *
	 * @param exibirBotaoExcluirChequeExcepcionadoGarantia
	 *            valor a ser atribuído
	 */
	public void setExibirBotaoExcluirChequeExcepcionadoGarantia(final boolean exibirBotaoExcluirChequeExcepcionadoGarantia) {

		this.exibirBotaoExcluirChequeExcepcionadoGarantia = exibirBotaoExcluirChequeExcepcionadoGarantia;

	}

	/**
	 * Retorna o valor do atributo garantia.
	 *
	 * @return garantia
	 */
	public Garantia getGarantia() {

		return this.garantia;
	}

	/**
	 * Define o valor do atributo garantia.
	 *
	 * @param garantia
	 *            valor a ser atribuído
	 */
	public void setGarantia(final Garantia garantia) {

		this.garantia = garantia;
	}

	/**
	 * Retorna o valor do atributo mesmoSegmentoPessoa.
	 *
	 * @return mesmoSegmentoPessoa
	 */
	public boolean isMesmoSegmentoPessoa() {

		return this.mesmoSegmentoPessoa;
	}

	/**
	 * Define o valor do atributo mesmoSegmentoPessoa.
	 *
	 * @param mesmoSegmentoPessoa
	 *            valor a ser atribuído
	 */
	public void setMesmoSegmentoPessoa(final boolean mesmoSegmentoPessoa) {

		this.mesmoSegmentoPessoa = mesmoSegmentoPessoa;
	}

	/**
	 * Retorna o valor do atributo filtroPorNoTipologia.
	 *
	 * @return filtroPorNoTipologia
	 */
	public String getFiltroPorNoTipologia() {

		return this.filtroPorNoTipologia;
	}

	/**
	 * Define o valor do atributo filtroPorNoTipologia.
	 *
	 * @param filtroPorNoTipologia
	 *            valor a ser atribuído
	 */
	public void setFiltroPorNoTipologia(final String filtroPorNoTipologia) {

		this.filtroPorNoTipologia = filtroPorNoTipologia;
	}
	
	/**
	 * <p>
	 * Método responsável por retornar as contas correntes, caso a
	 * GarantiaContrato possua.
	 * <p>
	 *
	 * @param garantiaContrato
	 *            valor a ser atribuido
	 * @return String
	 * @author guilherme.santos
	 */
	public String getContasCorrentes(final GarantiaContrato garantiaContrato) {
		String contas = "";
		if (garantiaContrato.isGarantiaAplicacaoFinanceira()) {
			contas = this.consultarContasCorrentesAplicacao(garantiaContrato, contas);
		} else if (garantiaContrato.isGarantiaCartaoCredito()) {
			contas = this.consultarContasCorrentes(garantiaContrato, contas);
		} else if (garantiaContrato.isGarantiaCheque()) {
			contas = this.consultarContasCorrentesCheque(this.getListaContaContratoCheque(), TipoOrigemContaContratoEnum.CHEQUE, contas);
		}
		return contas;
	}

	/**
	 * <p>
	 * Método responsável por consultar as contas correntes selecionadas de
	 * cartão de credito.
	 * <p>
	 *
	 * @param garantiaContrato
	 *            valor a ser atribuido
	 * @param contas
	 *            valor a ser atribuido
	 * @return String
	 * @author guilherme.santos
	 */
	private String consultarContasCorrentes(final GarantiaContrato garantiaContrato, String contas) {
		if (garantiaContrato.getListaGarantiaCartaoCredito() != null) {
			for (final GarantiaCartaoCredito garantiaCartaoCredito : garantiaContrato.getListaGarantiaCartaoCredito()) {
				if (!contas.contains(garantiaCartaoCredito.getNuConta().getNumeroContaFormatado())) {
					contas = contas.concat(garantiaCartaoCredito.getNuConta().getNumeroContaFormatado()).concat(" ");
				}
			}
		}
		return contas;
	}

	/**
	 * <p>
	 * Método responsável por consultar as contas correntes selecionadas para
	 * aplicação financeira.
	 * <p>
	 *
	 * @param garantiaContrato
	 *            valor a ser atribuido
	 * @param contas
	 *            valor a ser atribuido
	 * @return String
	 * @author guilherme.santos
	 */
	private String consultarContasCorrentesAplicacao(final GarantiaContrato garantiaContrato, String contas) {
		if (garantiaContrato.getListGarantiaAplicacao() != null) {
			for (final GarantiaAplicacao garantiaAplicacao : garantiaContrato.getListGarantiaAplicacao()) {
				contas = contas.concat(garantiaAplicacao.getId().getAplicacaoFinanceira().getNuConta().getNumeroContaFormatado()).concat(" ");

			}
		}
		return contas;
	}

	/**
	 * <p>
	 * Método responsável por obter o numero das contas correntes selecionadas
	 * da lista de conta contrato de Cheques.
	 * <p>
	 *
	 * @param listaContaContrato
	 *            valor a ser atribuido
	 * @param tipoOrigem
	 *            valor a ser atribuido
	 * @param contas
	 *            valor a ser atribuido
	 * @return String
	 * @author guilherme.santos
	 */
	private String consultarContasCorrentesCheque(final List<ContaContrato> listaContaContrato, final TipoOrigemContaContratoEnum tipoOrigem,
			String contas) {
		for (final ContaContrato cc : listaContaContrato) {
			if (cc.getIcUtilizarSaldoCheque() && (cc.getIcOrigem() == tipoOrigem || cc.getIcOrigem() == TipoOrigemContaContratoEnum.IMPORTADO)) {
				contas = contas.concat(cc.getNuConta().getNumeroContaFormatado()).concat(" ");
			}
		}
		return contas;
	}

	/**
	 * Retorna o valor do atributo vrFaturamentoApurado.
	 *
	 * @return vrFaturamentoApurado
	 */
	public BigDecimal getVrFaturamentoApurado() {
		if (this.vrFaturamentoApurado == null) {
			this.vrFaturamentoApurado = BigDecimal.ZERO;
		}

		return this.vrFaturamentoApurado;
	}

	/**
	 * Define o valor do atributo vrFaturamentoApurado.
	 *
	 * @param vrFaturamentoApurado
	 *            valor a ser atribuído
	 */
	public void setVrFaturamentoApurado(final BigDecimal vrFaturamentoApurado) {

		this.vrFaturamentoApurado = vrFaturamentoApurado;
	}

	/**
	 * Retorna o valor do atributo listaTipoPessoa.
	 *
	 * @return listaTipoPessoa
	 */
	public Collection<TipoPessoaEnum> getListaTipoPessoa() {
		if (this.listaTipoPessoa == null) {
			this.setListaTipoPessoa(EnumSet.allOf(TipoPessoaEnum.class));
		}

		return this.listaTipoPessoa;
	}

	/**
	 * Define o valor do atributo listaTipoPessoa.
	 *
	 * @param listaTipoPessoa
	 *            valor a ser atribuído
	 */
	public void setListaTipoPessoa(final Collection<TipoPessoaEnum> listaTipoPessoa) {

		this.listaTipoPessoa = listaTipoPessoa;
	}

	/**
	 * Retorna o valor do atributo tipoPessoaEnum.
	 *
	 * @return tipoPessoaEnum
	 */
	public TipoPessoaEnum getTipoPessoaEnum() {
		if (this.tipoPessoaEnum == null) {
			this.tipoPessoaEnum = TipoPessoaEnum.F;
		}

		return this.tipoPessoaEnum;
	}

	/**
	 * Define o valor do atributo tipoPessoaEnum.
	 *
	 * @param tipoPessoaEnum
	 *            valor a ser atribuído
	 */
	public void setTipoPessoaEnum(final TipoPessoaEnum tipoPessoaEnum) {

		this.tipoPessoaEnum = tipoPessoaEnum;
	}

	/**
	 * Retorna o valor do atributo listaTipoPreponente.
	 *
	 * @return listaTipoPreponente
	 */
	public List<TipoPessoaEnum> getListaTiposPessoa() {
		return Arrays.asList(TipoPessoaEnum.values());
	}

	/**
	 * Retorna o valor do atributo sacadosParaExcepcionar.
	 *
	 * @return sacadosParaExcepcionar
	 */
	public Collection<SacadoExcepcionadoVO> getSacadosParaExcepcionar() {
		if (!UtilObjeto.isReferencia(this.sacadosParaExcepcionar)) {
			this.sacadosParaExcepcionar = new ArrayList<>();
		}
		return this.sacadosParaExcepcionar;
	}

	/**
	 * Define o valor do atributo sacadosParaExcepcionar.
	 *
	 * @param sacadosParaExcepcionar
	 *            valor a ser atribuído
	 */
	public void setSacadosParaExcepcionar(final Collection<SacadoExcepcionadoVO> sacadosParaExcepcionar) {

		this.sacadosParaExcepcionar = sacadosParaExcepcionar;
	}

	/**
	 * Retorna o valor do atributo sacadoExcepcionado.
	 *
	 * @return sacadoExcepcionado
	 */
	public SacadoExcepcionadoVO getSacadoExcepcionado() {
		if (!UtilObjeto.isReferencia(this.sacadoExcepcionado)) {
			this.sacadoExcepcionado = new SacadoExcepcionadoVO();
		}

		return this.sacadoExcepcionado;
	}

	/**
	 * Define o valor do atributo sacadoExcepcionado.
	 *
	 * @param sacadoExcepcionado
	 *            valor a ser atribuído
	 */
	public void setSacadoExcepcionado(final SacadoExcepcionadoVO sacadoExcepcionado) {

		this.sacadoExcepcionado = sacadoExcepcionado;
	}

	/**
	 * Retorna o valor do atributo exibirBotaoSalvarSacado.
	 *
	 * @return exibirBotaoSalvarSacado
	 */
	public boolean isExibirBotaoSalvarSacado() {

		return this.exibirBotaoSalvarSacado;
	}

	/**
	 * Retorna o valor do atributo exibirBotaoIncluirSacado.
	 *
	 * @return exibirBotaoIncluirSacado
	 */
	public boolean isExibirBotaoIncluirSacado() {

		return this.exibirBotaoIncluirSacado;
	}

	/**
	 * Define o valor do atributo exibirBotaoSalvarSacado.
	 *
	 * @param exibirBotaoSalvarSacado
	 *            valor a ser atribuído
	 */
	public void setExibirBotaoSalvarSacado(final boolean exibirBotaoSalvarSacado) {

		this.exibirBotaoSalvarSacado = exibirBotaoSalvarSacado;
	}

	/**
	 * Define o valor do atributo exibirBotaoIncluirSacado.
	 *
	 * @param exibirBotaoIncluirSacado
	 *            valor a ser atribuído
	 */
	public void setExibirBotaoIncluirSacado(final boolean exibirBotaoIncluirSacado) {

		this.exibirBotaoIncluirSacado = exibirBotaoIncluirSacado;
	}

	/**
	 * Retorna o valor do atributo sacadosExcepcionadorIncluir.
	 *
	 * @return sacadosExcepcionadorIncluir
	 */
	public Collection<SacadoExcepcionadoVO> getSacadosExcepcionadosIncluir() {
		if (!UtilObjeto.isReferencia(this.sacadosExcepcionadosIncluir)) {
			this.sacadosExcepcionadosIncluir = new ArrayList<>();
		}
		return this.sacadosExcepcionadosIncluir;
	}

	/**
	 * Retorna o valor do atributo sacadosExcepcionadorRemover.
	 *
	 * @return sacadosExcepcionadorRemover
	 */
	public Collection<SacadoExcepcionadoVO> getSacadosExcepcionadosRemoverTemporaria() {
		if (!UtilObjeto.isReferencia(this.sacadosExcepcionadosRemoverTemporaria)) {
			this.sacadosExcepcionadosRemoverTemporaria = new ArrayList<>();
		}
		return this.sacadosExcepcionadosRemoverTemporaria;
	}

	/**
	 * Define o valor do atributo sacadosExcepcionadorIncluir.
	 *
	 * @param sacadosExcepcionadosIncluir
	 *            valor a ser atribuído
	 */
	public void setSacadosExcepcionadosIncluir(final Collection<SacadoExcepcionadoVO> sacadosExcepcionadosIncluir) {

		this.sacadosExcepcionadosIncluir = sacadosExcepcionadosIncluir;
	}

	/**
	 * Define o valor do atributo sacadosExcepcionadorRemover.
	 *
	 * @param sacadosExcepcionadosRemoverTemporaria
	 *            valor a ser atribuído
	 */
	public void setSacadosExcepcionadorRemover(final Collection<SacadoExcepcionadoVO> sacadosExcepcionadosRemover) {

		this.sacadosExcepcionadosRemoverTemporaria = sacadosExcepcionadosRemover;
	}

	/**
	 * Define o valor do atributo sacadosExcepcionadosRemoverTemporaria.
	 *
	 * @param sacadosExcepcionadosRemoverTemporaria
	 *            valor a ser atribuído
	 */
	public void setSacadosExcepcionadosRemoverTemporaria(final Collection<SacadoExcepcionadoVO> sacadosExcepcionadosRemover) {

		this.sacadosExcepcionadosRemoverTemporaria = sacadosExcepcionadosRemover;
	}

	/**
	 * Retorna o valor do atributo identificacaoSacadoRemover.
	 *
	 * @return identificacaoSacadoRemover
	 */
	public String getIdentificacaoSacadoRemover() {
		if (!UtilObjeto.isReferencia(this.identificacaoSacadoRemover)) {
			this.identificacaoSacadoRemover = "";
		}

		return this.identificacaoSacadoRemover;
	}

	/**
	 * Define o valor do atributo identificacaoSacadoRemover.
	 *
	 * @param identificacaoSacadoRemover
	 *            valor a ser atribuído
	 */
	public void setIdentificacaoSacadoRemover(final String identificacaoSacadoRemover) {

		this.identificacaoSacadoRemover = identificacaoSacadoRemover;
	}

	/**
	 * Retorna o valor do atributo sacadoExcepcionadoVOBackup.
	 *
	 * @return sacadoExcepcionadoVOBackup
	 */
	public SacadoExcepcionadoVO getSacadoExcepcionadoVOBackup() {
		if (!UtilObjeto.isReferencia(this.sacadoExcepcionadoVOBackup)) {
			this.sacadoExcepcionadoVOBackup = new SacadoExcepcionadoVO();
		}

		return this.sacadoExcepcionadoVOBackup;
	}

	/**
	 * Define o valor do atributo sacadoExcepcionadoVOBackup.
	 *
	 * @param sacadoExcepcionadoVOBackup
	 *            valor a ser atribuído
	 */
	public void setSacadoExcepcionadoVOBackup(final SacadoExcepcionadoVO sacadoExcepcionadoVOBackup) {

		this.sacadoExcepcionadoVOBackup = sacadoExcepcionadoVOBackup;
	}

	/**
	 * Retorna o valor do atributo exibirBotaoExcepcionarSacado.
	 *
	 * @return exibirBotaoExcepcionarSacado
	 */
	public boolean isExibirBotaoExcepcionarSacadoDetalheVoltar() {

		return this.exibirBotaoExcepcionarSacadoDetalheVoltar;
	}

	/**
	 * Define o valor do atributo exibirBotaoExcepcionarSacado.
	 *
	 * @param exibirBotaoExcepcionarSacadoDetalheVoltar
	 *            valor a ser atribuído
	 */
	public void setExibirBotaoExcepcionarSacadoDetalheVoltar(final boolean exibirBotaoExcepcionarSacadoDetalheVoltar) {

		this.exibirBotaoExcepcionarSacadoDetalheVoltar = exibirBotaoExcepcionarSacadoDetalheVoltar;
	}

	/**
	 * Retorna o valor do atributo exibirBotaoLimparSacadoExcepcionado.
	 *
	 * @return exibirBotaoLimparSacadoExcepcionado
	 */
	public boolean isExibirBotaoLimparSacadoExcepcionado() {

		return this.exibirBotaoLimparSacadoExcepcionado;
	}

	/**
	 * Define o valor do atributo exibirBotaoLimparSacadoExcepcionado.
	 *
	 * @param exibirBotaoLimparSacadoExcepcionado
	 *            valor a ser atribuído
	 */
	public void setExibirBotaoLimparSacadoExcepcionado(final boolean exibirBotaoLimparSacadoExcepcionado) {

		this.exibirBotaoLimparSacadoExcepcionado = exibirBotaoLimparSacadoExcepcionado;
	}

	/**
	 * Retorna o valor do atributo exibirBotaoExcepcionarSacado.
	 *
	 * @return exibirBotaoExcepcionarSacado
	 */
	public boolean isExibirBotaoExcepcionarSacado() {

		return this.exibirBotaoExcepcionarSacado;
	}

	/**
	 * Define o valor do atributo exibirBotaoExcepcionarSacado.
	 *
	 * @param exibirBotaoExcepcionarSacado
	 *            valor a ser atribuído
	 */
	public void setExibirBotaoExcepcionarSacado(final boolean exibirBotaoExcepcionarSacado) {

		this.exibirBotaoExcepcionarSacado = exibirBotaoExcepcionarSacado;
	}

	/**
	 * Retorna o valor do atributo garantiaContrato.
	 *
	 * @return garantiaContrato
	 */
	public GarantiaContrato getGarantiaContrato() {
		if (!UtilObjeto.isReferencia(this.garantiaContrato)) {
			this.garantiaContrato = new GarantiaContrato();
		}
		return this.garantiaContrato;
	}

	/**
	 * Define o valor do atributo garantiaContrato.
	 *
	 * @param garantiaContrato
	 *            valor a ser atribuído
	 */
	public void setGarantiaContrato(final GarantiaContrato garantiaContrato) {

		this.garantiaContrato = garantiaContrato;
	}

	/**
	 * Retorna o valor do atributo listaSacadosAlterados.
	 *
	 * @return listaSacadosAlterados
	 */
	public Collection<SacadoExcepcionado> getListaSacadosAlterados() {
		if (!UtilObjeto.isReferencia(this.listaSacadosAlterados)) {
			this.listaSacadosAlterados = new ArrayList<>();
		}

		return this.listaSacadosAlterados;
	}

	/**
	 * Define o valor do atributo listaSacadosAlterados.
	 *
	 * @param listaSacadosAlterados
	 *            valor a ser atribuído
	 */
	public void setListaSacadosAlterados(final Collection<SacadoExcepcionado> listaSacadosAlterados) {

		this.listaSacadosAlterados = listaSacadosAlterados;
	}

	/**
	 * Retorna o valor do atributo listaTipologia.
	 *
	 * @return listaTipologia
	 */
	public Collection<Tipologia> getListaTipologia() {
		if (!UtilObjeto.isReferencia(this.listaTipologia)) {
			this.listaTipologia = new ArrayList<>();
		}

		return this.listaTipologia;
	}

	/**
	 * Define o valor do atributo listaTipologia.
	 *
	 * @param listaTipologia
	 *            valor a ser atribuído
	 */
	public void setListaTipologia(final Collection<Tipologia> listaTipologia) {

		this.listaTipologia = listaTipologia;
	}

	/**
	 * Retorna o valor do atributo podeSalvarTipologias.
	 *
	 * @return podeSalvarTipologias
	 */
	public Boolean getPodeSalvarTipologias() {
		return this.podeSalvarTipologias;
	}

	/**
	 * Define o valor do atributo podeSalvarTipologias.
	 *
	 * @param podeSalvarTipologias
	 *            valor a ser atribuído
	 */
	public void setPodeSalvarTipologias(final Boolean podeSalvarTipologias) {
		this.podeSalvarTipologias = podeSalvarTipologias;
	}

	/**
	 * <p>
	 * Método responsável por retornar se retornar se existe um campo com erro
	 * na tela.
	 * </p>
	 * 
	 * @return Boolean campoComErro
	 */
	public boolean isCampoComErro() {
		return this.campoComErro;
	}

	/**
	 * <p>
	 * Método responsável por setar se existe um campo com erro na tela.
	 * </p>
	 * 
	 * @param Boolean
	 *            campoComErro
	 */
	public void setCampoComErro(final boolean campoComErro) {
		this.campoComErro = campoComErro;
	}

	/**
	 * <p>
	 * Método responsável por retornar a mensagem de erro de validação.
	 * </p>
	 * 
	 * @return String mensagemDeErroNaValidacaoCampo
	 */
	public String getMensagemDeErroNaValidacaoCampo() {
		return this.mensagemDeErroNaValidacaoCampo;
	}

	/**
	 * <p>
	 * Método responsável por setar a mensagem de erro na validação.
	 * </p>
	 * 
	 * @param String
	 *            mensagemDeErroNaValidacaoCampo
	 */
	public void setMensagemDeErroNaValidacaoCampo(final String mensagemDeErroNaValidacaoCampo) {
		this.mensagemDeErroNaValidacaoCampo = mensagemDeErroNaValidacaoCampo;
	}

	/**
	 * Retorna o valor do atributo podeSalvarUnidadesHabitacionais.
	 *
	 * @return podeSalvarUnidadesHabitacionais
	 */
	public Boolean getPodeSalvarUnidadesHabitacionais() {
		return this.podeSalvarUnidadesHabitacionais;
	}

	/**
	 * Define o valor do atributo podeSalvarUnidadesHabitacionais.
	 *
	 * @param podeSalvarUnidadesHabitacionais
	 *            valor a ser atribuído
	 */
	public void setPodeSalvarUnidadesHabitacionais(final Boolean podeSalvarUnidadesHabitacionais) {
		this.podeSalvarUnidadesHabitacionais = podeSalvarUnidadesHabitacionais;
	}

	/**
	 * <p>
	 * Retorna o valor do atributo filtroTabelaAcionado
	 * </p>
	 * .
	 *
	 * @return filtroTabelaAcionado
	 */
	public Boolean getFiltroTabelaAcionado() {
		return this.filtroTabelaAcionado;
	}

	/**
	 * <p>
	 * Define o valor do atributo filtroTabelaAcionado
	 * </p>
	 * .
	 *
	 * @param filtroTabelaAcionado
	 *            valor a ser atribuído
	 */
	public void setFiltroTabelaAcionado(final Boolean filtroTabelaAcionado) {
		this.filtroTabelaAcionado = filtroTabelaAcionado;
	}

	/**
	 * Retorna o valor do atributo podeIncluirUnidadesHabitacionais.
	 *
	 * @return podeIncluirUnidadesHabitacionais
	 */
	public Boolean getPodeIncluirUnidadesHabitacionais() {
		return this.podeIncluirUnidadesHabitacionais;
	}

	/**
	 * Define o valor do atributo podeIncluirUnidadesHabitacionais.
	 *
	 * @param podeIncluirUnidadesHabitacionais
	 *            valor a ser atribuído
	 */
	public void setPodeIncluirUnidadesHabitacionais(final Boolean podeIncluirUnidadesHabitacionais) {
		this.podeIncluirUnidadesHabitacionais = podeIncluirUnidadesHabitacionais;
	}

	/**
	 * <p>
	 * Método responsável por retornar se retornar se existe um campo com erro
	 * na tela.
	 * </p>
	 * 
	 * @return Boolean campoComErroUnidadeHabitacional
	 */
	public boolean isCampoComErroUnidadeHabitacional() {
		return this.campoComErroUnidadeHabitacional;
	}

	/**
	 * <p>
	 * Método responsável por setar se existe um campo com erro na tela.
	 * </p>
	 * 
	 * @param Boolean
	 *            campoComErroUnidadeHabitacional
	 */
	public void setCampoComErroUnidadeHabitacional(final boolean campoComErroUnidadeHabitacional) {
		this.campoComErroUnidadeHabitacional = campoComErroUnidadeHabitacional;
	}

	/**
	 * Retorna o valor do atributo unidadeHabitacionalEmEdicao.
	 *
	 * @return unidadeHabitacionalEmEdicao
	 */
	public UnidadeHabitacional getUnidadeHabitacionalEmEdicao() {
		return this.unidadeHabitacionalEmEdicao;
	}

	/**
	 * <p>
	 * Método responsável por setar a Unidade Habitacional em Edição.
	 * </p>
	 * 
	 * @param unidadeHabitacionalEmEdicao
	 *            - UnidadeHabitacional
	 */
	public void setUnidadeHabitacionalEmEdicao(final UnidadeHabitacional unidadeHabitacionalEmEdicao) {
		this.unidadeHabitacionalEmEdicao = unidadeHabitacionalEmEdicao;
	}

	/**
	 * Retorna o valor do atributo listaHipotecadaContratacaoSN.
	 *
	 * @return listaHipotecadaContratacaoSN
	 */
	public Collection<SelectItem> getListaHipotecadaContratacaoSN() {
		final List<SelectItem> itensSN = new ArrayList<>();

		itensSN.add(new SelectItem("true", "Sim"));
		itensSN.add(new SelectItem("false", "Não"));

		this.listaHipotecadaContratacaoSN = itensSN;
		return this.listaHipotecadaContratacaoSN;
	}

	/**
	 * Retorna o valor do atributo listaMantidaHipotecaSN.
	 *
	 * @return listaMantidaHipotecaSN
	 */
	public Collection<SelectItem> getListaMantidaHipotecaSN() {
		final List<SelectItem> itensSN = new ArrayList<>();

		itensSN.add(new SelectItem("true", "Sim"));
		itensSN.add(new SelectItem("false", "Não"));

		this.listaMantidaHipotecaSN = itensSN;

		return this.listaMantidaHipotecaSN;
	}

	/**
	 * Retorna o valor do atributo listaSituacaoUnidadeHabitacional.
	 *
	 * @return listaSituacaoUnidadeHabitacional
	 */
	public SelectItem[] getListaSituacaoUnidadeHabitacional() {

		final SelectItem[] items = new SelectItem[SituacaoUnidadeHabitacionalEnum.values().length];
		int i = 0;
		for (final SituacaoUnidadeHabitacionalEnum sit : SituacaoUnidadeHabitacionalEnum.values()) {
			items[i++] = new SelectItem(sit.getCodigo(), sit.getNome());
		}
		this.listaSituacaoUnidadeHabitacional = items;
		return this.listaSituacaoUnidadeHabitacional;
	}

	/**
	 * <p>
	 * Método responsável por obter a quantidade de dias.
	 * <p>
	 *
	 * @return Integer
	 */
	public Integer getQtdDias() {

		return this.qtdDias;
	}

	/**
	 * <p>
	 * Método responsável por atribuir a quantidade de dias.
	 * <p>
	 *
	 * @param qtdDias
	 *            valor a ser atribuido
	 */
	public void setQtdDias(final Integer qtdDias) {

		this.qtdDias = qtdDias;
	}

	/**
	 * Retorna o valor do atributo listaHistoricoFaturamentoPessoa.
	 *
	 * @return listaHistoricoFaturamentoPessoa
	 */
	public Collection<HistoricoFaturamentoPessoa> getListaHistoricoFaturamentoPessoa() {
		if (this.listaHistoricoFaturamentoPessoa == null) {
			this.listaHistoricoFaturamentoPessoa = new ArrayList<>();
		}

		return this.listaHistoricoFaturamentoPessoa;
	}

	/**
	 * Define o valor do atributo listaHistoricoFaturamentoPessoa.
	 *
	 * @param listaHistoricoFaturamentoPessoa
	 *            valor a ser atribuído
	 */
	public void setListaHistoricoFaturamentoPessoa(final Collection<HistoricoFaturamentoPessoa> listaHistoricoFaturamentoPessoa) {
		this.listaHistoricoFaturamentoPessoa = listaHistoricoFaturamentoPessoa;
	}

	/**
	 * <p>
	 * Retorna o valor do atributo sacadosExcepcionadosRemover
	 * </p>
	 * .
	 *
	 * @return sacadosExcepcionadosRemover
	 */
	public Collection<SacadoExcepcionadoVO> getSacadosExcepcionadosRemover() {
		if (!UtilObjeto.isReferencia(this.sacadosExcepcionadosRemover)) {
			this.sacadosExcepcionadosRemover = new ArrayList<>();
		}
		return this.sacadosExcepcionadosRemover;
	}

	/**
	 * <p>
	 * Define o valor do atributo sacadosExcepcionadosRemover
	 * </p>
	 * .
	 *
	 * @param sacadosExcepcionadosRemover
	 *            valor a ser atribuído
	 */
	public void setSacadosExcepcionadosRemover(final Collection<SacadoExcepcionadoVO> sacadosExcepcionadosRemover) {
		this.sacadosExcepcionadosRemover = sacadosExcepcionadosRemover;
	}

	/**
	 * Retorna o valor do atributo estaEmEdicaoUnidadeHabitacional.
	 *
	 * @return estaEmEdicaoUnidadeHabitacional
	 */
	public Boolean getEstaEmEdicaoUnidadeHabitacional() {
		return this.estaEmEdicaoUnidadeHabitacional;
	}

	/**
	 * Define o valor do atributo estaEmEdicaoUnidadeHabitacional.
	 *
	 * @param estaEmEdicaoUnidadeHabitacional
	 *            valor a ser atribuído
	 */
	public void setEstaEmEdicaoUnidadeHabitacional(final Boolean estaEmEdicaoUnidadeHabitacional) {
		this.estaEmEdicaoUnidadeHabitacional = estaEmEdicaoUnidadeHabitacional;
	}

	/**
	 * Retorna o valor do atributo estaEmInclusaoOuEdicaoUnidadeHabitacional.
	 *
	 * @return estaEmInclusaoOuEdicaoUnidadeHabitacional
	 */
	public Boolean getEstaEmInclusaoOuEdicaoUnidadeHabitacional() {
		return this.estaEmInclusaoOuEdicaoUnidadeHabitacional;
	}

	/**
	 * Define o valor do atributo estaEmInclusaoOuEdicaoUnidadeHabitacional.
	 *
	 * @param estaEmInclusaoOuEdicaoUnidadeHabitacional
	 *            valor a ser atribuído
	 */
	public void setEstaEmInclusaoOuEdicaoUnidadeHabitacional(final Boolean estaEmInclusaoOuEdicaoUnidadeHabitacional) {
		this.estaEmInclusaoOuEdicaoUnidadeHabitacional = estaEmInclusaoOuEdicaoUnidadeHabitacional;
	}

	/**
	 * <p>
	 * Retorna o valor do atributo idLinhaClicada
	 * </p>
	 * .
	 *
	 * @return idLinhaClicada
	 */
	public String getIdLinhaClicada() {
		return this.idLinhaClicada;
	}

	/**
	 * <p>
	 * Define o valor do atributo idLinhaClicada
	 * </p>
	 * .
	 *
	 * @param idLinhaClicada
	 *            valor a ser atribuído
	 */
	public void setIdLinhaClicada(final String idLinhaClicada) {
		this.idLinhaClicada = idLinhaClicada;
	}

	/**
	 * Retorna o valor do atributo listaProponentesHabitacionais.
	 *
	 * @return listaProponentesHabitacionais
	 */
	public Collection<ProponenteHabitacional> getListaProponentesHabitacionais() {
		return this.listaProponentesHabitacionais;
	}

	/**
	 * Define o valor do atributo listaProponentesHabitacionais.
	 *
	 * @param listaProponentesHabitacionais
	 *            valor a ser atribuído
	 */
	public void setListaProponentesHabitacionais(final Collection<ProponenteHabitacional> listaProponentesHabitacionais) {
		this.listaProponentesHabitacionais = listaProponentesHabitacionais;
	}

	/**
	 * Retorna o valor do atributo unidadeHabitacionalComercializacao.
	 *
	 * @return unidadeHabitacionalComercializacao
	 */
	public UnidadeHabitacionalComercializacao getUnidadeHabitacionalComercializacao() {
		return this.unidadeHabitacionalComercializacao;
	}

	/**
	 * Define o valor do atributo unidadeHabitacionalComercializacao.
	 *
	 * @param unidadeHabitacionalComercializacao
	 *            valor a ser atribuído
	 */
	public void setUnidadeHabitacionalComercializacao(final UnidadeHabitacionalComercializacao unidadeHabitacionalComercializacao) {
		this.unidadeHabitacionalComercializacao = unidadeHabitacionalComercializacao;
	}

	/**
	 * Retorna o valor do atributo teveSucessoAoSalvarUnidadeHabitacional.
	 *
	 * @return teveSucessoAoSalvarUnidadeHabitacional
	 */
	public final boolean getTeveSucessoAoSalvarUnidadeHabitacional() {
		return this.teveSucessoAoSalvarUnidadeHabitacional;
	}

	/**
	 * Define o valor do atributo teveSucessoAoSalvarUnidadeHabitacional.
	 *
	 * @param teveSucessoAoSalvarUnidadeHabitacional
	 *            valor a ser atribuído
	 */
	public final void setTeveSucessoAoSalvarUnidadeHabitacional(final boolean teveSucessoAoSalvarUnidadeHabitacional) {
		this.teveSucessoAoSalvarUnidadeHabitacional = teveSucessoAoSalvarUnidadeHabitacional;
	}

	/**
	 * Retorna o valor do atributo listaIndiceReajusteUnidadeHabitacional.
	 *
	 * @return listaIndiceReajusteUnidadeHabitacional
	 */
	public SelectItem[] getListaIndiceReajusteUnidadeHabitacional() {

		final SelectItem[] items = new SelectItem[IndicadorReajusteEnum.values().length];
		int i = 0;
		for (final IndicadorReajusteEnum sit : IndicadorReajusteEnum.values()) {
			items[i++] = new SelectItem(sit.getValor(), sit.getChave());
		}
		this.listaIndiceReajusteUnidadeHabitacional = items;
		return this.listaIndiceReajusteUnidadeHabitacional;
	}

	/**
	 * <p>
	 * Método responsável por retornar o Nome do Indice de Reajuste da
	 * Comercialização da Unidade Habitacional.
	 * </p>
	 * 
	 * @param String
	 *            codigo - Código do Índice de Reajuste da Comercialização da
	 *            Unidade Habitacional procurada.
	 * @return String - Nome do Índice de Reajuste da Comercialização da Unidade
	 *         Habitacional.
	 */
	public String indiceReajusteUnidadeHabitacionalNome(final String codigo) {
		if (codigo != null && codigo.trim().length() == 2 && !codigo.equals("0")) {
			return IndicadorReajusteEnum.obterDeValor(codigo).getChave();
		} else {
			this.setCampoComErro(true);
			this.setMensagemDeErroNaValidacaoCampo("Índice de Reajustes da Comercialização da Unidade Habitacional inválido !");
			return "";
		}
	}

	/**
	 * Retorna o valor do atributo listaSituacaoContratoUnidadeHabitacional.
	 *
	 * @return listaSituacaoContratoUnidadeHabitacional
	 */
	public SelectItem[] getListaSituacaoContratoUnidadeHabitacional() {

		final SelectItem[] items = new SelectItem[SituacaoComercializacaoUnidadeHabitacionalEnum.values().length];
		int i = 0;
		for (final SituacaoComercializacaoUnidadeHabitacionalEnum sit : SituacaoComercializacaoUnidadeHabitacionalEnum.values()) {
			items[i++] = new SelectItem(sit.getCodigo(), sit.getNome());
		}
		this.listaSituacaoContratoUnidadeHabitacional = items;
		return this.listaSituacaoContratoUnidadeHabitacional;
	}

	/**
	 * <p>
	 * Método responsável por retornar o Nome da Situação do Contrato da Unidade
	 * Habitacional.
	 * </p>
	 * 
	 * @param String
	 *            codigo - Código da Situação do Contrato da Comercialização da
	 *            Unidade Habitacional procurada.
	 * @return String - Nome da Situação do Contrato da Comercialização da
	 *         Unidade Habitacional.
	 */
	public String situacaoContratoUnidadeHabitacionalNome(final String codigo) {
		if (codigo != null && codigo.trim().length() == 2 && !codigo.equals("0")) {
			return SituacaoComercializacaoUnidadeHabitacionalEnum.obterEnumPorCodigo(codigo).getNome();
		} else {
			this.setCampoComErro(true);
			this.setMensagemDeErroNaValidacaoCampo("Situação Contrato da Comercialização da Unidade Habitacional inválida !");
			return "";
		}
	}

	/**
	 * Define o valor do atributo proponenteEmEdicao.
	 *
	 * @param proponenteEmEdicao
	 *            valor a ser atribuído
	 */
	public void setProponenteEmEdicao(final ProponenteHabitacional proponenteEmEdicao) {
		this.proponenteEmEdicao = proponenteEmEdicao;
	}

	/**
	 * Retorna o valor do atributo proponenteEmEdicao.
	 *
	 * @return proponenteEmEdicao
	 */
	public ProponenteHabitacional getProponenteEmEdicao() {
		return this.proponenteEmEdicao;
	}

	/**
	 * Retorna o valor do atributo tituloJanelaUnidadeHabitacional.
	 *
	 * @return tituloJanelaUnidadeHabitacional
	 */
	public String getTituloJanelaUnidadeHabitacional() {
		return this.tituloJanelaUnidadeHabitacional;
	}

	/**
	 * Define o valor do atributo tituloJanelaUnidadeHabitacional.
	 *
	 * @param tituloJanelaUnidadeHabitacional
	 *            valor a ser atribuído
	 */
	public void setTituloJanelaUnidadeHabitacional(final String tituloJanelaUnidadeHabitacional) {
		this.tituloJanelaUnidadeHabitacional = tituloJanelaUnidadeHabitacional;
	}

	/**
	 * Retorna o valor do atributo listaTipoParcela.
	 *
	 * @return listaTipoParcela
	 */
	public SelectItem[] getListaTipoParcela() {

		final SelectItem[] items = new SelectItem[TipoParcelaEnum.values().length];
		int i = 0;
		for (final String sit : this.getListaTipoParcelaConsulta()) {
			items[i++] = new SelectItem(sit, sit);
		}
		this.listaTipoParcela = items;
		return this.listaTipoParcela;

	}

	/**
	 * Retorna o valor do atributo listaPeriodicidade.
	 *
	 * @return listaTipoParcela
	 */
	public SelectItem[] getListaPeriodicidade() {

		final SelectItem[] items = new SelectItem[PeriodicidadePrevistaEnum.values().length];
		int i = 0;
		for (final PeriodicidadePrevistaEnum sit : PeriodicidadePrevistaEnum.values()) {
			items[i++] = new SelectItem(sit.getValor(), sit.getDescricao());
		}
		this.listaPeriodicidade = items;
		return this.listaPeriodicidade;
	}

	/**
	 * Define o valor do atributo prospectoTipoParcelaEmEdicao.
	 *
	 * @param prospectoTipoParcelaEmEdicao
	 *            valor a ser atribuído
	 */
	public void setProspectoTipoParcelaEmEdicao(final ProspectoTipoParcela prospectoTipoParcelaEmEdicao) {
		this.prospectoTipoParcelaEmEdicao = prospectoTipoParcelaEmEdicao;
	}

	/**
	 * Retorna o valor do atributo prospectoTipoParcelaEmEdicao.
	 *
	 * @return prospectoTipoParcelaEmEdicao
	 */
	public ProspectoTipoParcela getProspectoTipoParcelaEmEdicao() {
		return this.prospectoTipoParcelaEmEdicao;
	}
	
	/**
	 * <p>Retorna o valor do atributo parametroComercializacaoEmEdicao</p>.
	 *
	 * @return parametroComercializacaoEmEdicao
	*/
	public ParametroComercializacao getParametroComercializacaoEmEdicao() {
		return this.parametroComercializacaoEmEdicao;
	}

	/**
	 * <p>Define o valor do atributo parametroComercializacaoEmEdicao</p>.
	 *
	 * @param parametroComercializacaoEmEdicao valor a ser atribuído
	*/
	public void setParametroComercializacaoEmEdicao(ParametroComercializacao parametroComercializacaoEmEdicao) {
		this.parametroComercializacaoEmEdicao = parametroComercializacaoEmEdicao;
	}

	/**
	 * Retorna o valor do atributo podeIncluirPropectosGerados.
	 *
	 * @return podeIncluirPropectosGerados
	 */
	public Boolean getPodeIncluirPropectosGerados() {
		return this.podeIncluirPropectosGerados;
	}

	/**
	 * Define o valor do atributo podeIncluirPropectosGerados.
	 *
	 * @param podeIncluirPropectosGerados
	 *            valor a ser atribuído
	 */
	public void setPodeIncluirPropectosGerados(final Boolean podeIncluirPropectosGerados) {
		this.podeIncluirPropectosGerados = podeIncluirPropectosGerados;
	}

	/**
	 * Retorna o valor do atributo podeGerarPropectosIncluidos.
	 *
	 * @return podeGerarPropectosIncluidos
	 */
	public Boolean getPodeGerarPropectosIncluidos() {
		return this.podeGerarPropectosIncluidos;
	}

	/**
	 * Define o valor do atributo podeGerarPropectosIncluidos.
	 *
	 * @param podeGerarPropectosIncluidos
	 *            valor a ser atribuído
	 */
	public void setPodeGerarPropectosIncluidos(final Boolean podeGerarPropectosIncluidos) {
		this.podeGerarPropectosIncluidos = podeGerarPropectosIncluidos;
	}

	/**
	 * Retorna o valor do atributo listaParametroComercializacao.
	 *
	 * @return listaParametroComercializacao
	 */
	public Collection<ParametroComercializacao> getListaParametroComercializacao() {
		return this.listaParametroComercializacao;
	}

	/**
	 * Define o valor do atributo listaParametroComercializacao.
	 *
	 * @param listaParametroComercializacao
	 *            valor a ser atribuído
	 */
	public void setListaParametroComercializacao(final Collection<ParametroComercializacao> listaParametroComercializacao) {
		this.listaParametroComercializacao = listaParametroComercializacao;
	}

	/**
	 * Retorna o valor do atributo listaParametroComercializacaoOriginal
	 *
	 * @return listaParametroComercializacaoOriginal
	 */
	public Collection<ParametroComercializacao> getListaParametroComercializacaoOriginal() {
		return this.listaParametroComercializacaoOriginal;
	}

	/**
	 * Define o valor do atributo listaParametroComercializacaoOriginal.
	 *
	 * @param listaParametroComercializacaoOriginal
	 *            valor a ser atribuído
	 */
	public void setListaParametroComercializacaoOriginal(final Collection<ParametroComercializacao> listaParametroComercializacaoOriginal) {
		this.listaParametroComercializacaoOriginal = listaParametroComercializacaoOriginal;
	}

	/**
	 * Retorna o valor do atributo listaProspectoTipoParcela.
	 *
	 * @return listaProspectoTipoParcela
	 */
	public Collection<ProspectoTipoParcela> getListaProspectoTipoParcela() {
		return this.listaProspectoTipoParcela;
	}

	/**
	 * Define o valor do atributo listaProspectoTipoParcela.
	 *
	 * @param listaProspectoTipoParcela
	 *            valor a ser atribuído
	 */
	public void setListaProspectoTipoParcela(final Collection<ProspectoTipoParcela> listaProspectoTipoParcela) {
		this.listaProspectoTipoParcela = listaProspectoTipoParcela;
	}

	/**
	 * <p>
	 * Método responsável por retornar o Nome da uma Periodicidade do Tipo de
	 * Parcela da Unidade Habitacional.
	 * </p>
	 * 
	 * @param String
	 *            codigo - Código da Periodicidade da Unidade Habitacional
	 *            procurada.
	 * @return String - Nome da Periodicidade da Parcela da Unidade
	 *         Habitacional.
	 */
	public String obterPeriodicidadePorCodigo(final Integer codigo) {
		if (codigo != null) {
			return PeriodicidadePrevistaEnum.obterDeValor(codigo).getDescricao();
		} else {
			return "";
		}
	}

	/**
	 * Retorna o valor do atributo valorTotalCalculadoLinhasProspecto.
	 *
	 * @return valorTotalCalculadoLinhasProspecto
	 */
	public String getValorTotalCalculadoLinhasProspecto() {

		return this.valorTotalCalculadoLinhasProspecto;
	}

	/**
	 * Define o valor do atributo valorTotalCalculadoLinhasProspecto.
	 *
	 * @param valorTotalCalculadoLinhasProspecto
	 *            valor a ser atribuído
	 */
	public void setValorTotalCalculadoLinhasProspecto(final String valorTotalCalculadoLinhasProspecto) {

		this.valorTotalCalculadoLinhasProspecto = valorTotalCalculadoLinhasProspecto;
	}

	/**
	 * Retorna o valor do atributo
	 * valorTotalCalculadoLinhasProspectoComFiltroAtivo.
	 *
	 * @return valorTotalCalculadoLinhasProspectoComFiltroAtivo
	 */
	public String getValorTotalCalculadoLinhasProspectoComFiltroAtivo() {

		return this.valorTotalCalculadoLinhasProspectoComFiltroAtivo;
	}

	/**
	 * Define o valor do atributo
	 * valorTotalCalculadoLinhasProspectoComFiltroAtivo.
	 *
	 * @param valorTotalCalculadoLinhasProspectoComFiltroAtivo
	 *            valor a ser atribuído
	 */
	public void setValorTotalCalculadoLinhasProspectoComFiltroAtivo(final String valorTotalCalculadoLinhasProspectoComFiltroAtivo) {

		this.valorTotalCalculadoLinhasProspectoComFiltroAtivo = valorTotalCalculadoLinhasProspectoComFiltroAtivo;
	}

	/**
	 * Retorna o valor do atributo filtroPorTipoParcela.
	 *
	 * @return filtroPorTipoParcela
	 */
	public String getFiltroPorTipoParcela() {

		return this.filtroPorTipoParcela;
	}

	/**
	 * Define o valor do atributo filtroPorTipoParcela.
	 *
	 * @param filtroPorTipoParcela
	 *            valor a ser atribuído
	 */
	public void setFiltroPorTipoParcela(final String filtroPorTipoParcela) {

		this.filtroPorTipoParcela = filtroPorTipoParcela;
	}

	/**
	 * Retorna o valor do atributo filtroPorPeriodicidade.
	 *
	 * @return filtroPorPeriodicidade
	 */
	public Integer getFiltroPorPeriodicidade() {
		return this.filtroPorPeriodicidade;
	}

	/**
	 * Define o valor do atributo filtroPorPeriodicidade.
	 *
	 * @param filtroPorPeriodicidade
	 *            valor a ser atribuído
	 */
	public void setFiltroPorPeriodicidade(final Integer filtroPorPeriodicidade) {
		this.filtroPorPeriodicidade = filtroPorPeriodicidade;
	}

	/**
	 * Retorna o valor do atributo filtroPorQuantidadeParcelas.
	 *
	 * @return filtroPorQuantidadeParcelas
	 */
	public Integer getFiltroPorQuantidadeParcelas() {
		return this.filtroPorQuantidadeParcelas;
	}

	/**
	 * Define o valor do atributo filtroPorQuantidadeParcelas.
	 *
	 * @param filtroPorQuantidadeParcelas
	 *            valor a ser atribuído
	 */
	public void setFiltroPorQuantidadeParcelas(final Integer filtroPorQuantidadeParcelas) {
		this.filtroPorQuantidadeParcelas = filtroPorQuantidadeParcelas;
	}

	/**
	 * Retorna o valor do atributo filtroPorDtInicio.
	 *
	 * @return filtroPorDtInicio
	 */
	public Date getFiltroPorDtInicio() {
		return this.filtroPorDtInicio;
	}

	/**
	 * Define o valor do atributo filtroPorDtInicio.
	 *
	 * @param filtroPorDtInicio
	 *            valor a ser atribuído
	 */
	public void setFiltroPorDtInicio(final Date filtroPorDtInicio) {
		this.filtroPorDtInicio = filtroPorDtInicio;
	}

	/**
	 * Retorna o valor do atributo temFiltroProspectoAtivo.
	 *
	 * @return temFiltroProspectoAtivo
	 */
	public Boolean getTemFiltroProspectoAtivo() {
		return this.temFiltroProspectoAtivo;
	}

	/**
	 * Define o valor do atributo temFiltroProspectoAtivo.
	 *
	 * @param temFiltroProspectoAtivo
	 *            valor a ser atribuído
	 */
	public void setTemFiltroProspectoAtivo(final Boolean temFiltroProspectoAtivo) {
		this.temFiltroProspectoAtivo = temFiltroProspectoAtivo;
	}

	/**
	 * Retorna o valor do atributo estaCarregandoModalProspectos.
	 *
	 * @return estaCarregandoModalProspectos
	 */
	public Boolean getEstaCarregandoModalProspectos() {
		return this.estaCarregandoModalProspectos;

	}

	/**
	 * Define o valor do atributo estaCarregandoModalProspectos.
	 *
	 * @param estaCarregandoModalProspectos
	 *            valor a ser atribuído
	 */
	public void setEstaCarregandoModalProspectos(final Boolean estaCarregandoModalProspectos) {
		this.estaCarregandoModalProspectos = estaCarregandoModalProspectos;
	}

	public Collection<String> getListaTipoParcelaConsulta() {
		return this.listaTipoParcelaConsulta;
	}

	public void setListaTipoParcelaConsulta(final Collection<String> listaTipoParcelaConsulta) {
		this.listaTipoParcelaConsulta = listaTipoParcelaConsulta;
	}

	public boolean isContratoSelecionadoHabitacional() {
		return this.contratoSelecionadoHabitacional;
	}

	public void setContratoSelecionadoHabitacional(final boolean contratoSelecionadoHabitacional) {
		this.contratoSelecionadoHabitacional = contratoSelecionadoHabitacional;
	}

	/**
	 * @return the editing
	 */
	public boolean isEditing() {
		return this.editing;
	}

	/**
	 * @param editing
	 *            the editing to set
	 */
	public void setEditing(final boolean editing) {
		this.editing = editing;
	}

	/**
	 * Retorna o valor do atributo listaRecebidos.
	 *
	 * @return listaRecebidos
	 */
	public Collection<Recebido> getListaRecebidos() {
		return this.listaRecebidos;
	}

	/**
	 * Define o valor do atributo listaRecebidos.
	 *
	 * @param listaRecebidos
	 *            valor a ser atribuído
	 */
	public void setListaRecebidos(final Collection<Recebido> listaRecebidos) {
		this.listaRecebidos = listaRecebidos;
	}

	/**
	 * Retorna o valor do atributo icRegistrosInativos.
	 *
	 * @return icRegistrosInativos
	 */
	public Boolean getIcRegistrosInativos() {
		return this.icRegistrosInativos;

	}

	/**
	 * Define o valor do atributo icRegistrosInativos.
	 *
	 * @param icRegistrosInativos
	 *            valor a ser atribuído
	 */
	public void setIcRegistrosInativos(final Boolean icRegistrosInativos) {
		this.icRegistrosInativos = icRegistrosInativos;
	}

	/**
	 * Retorna o valor do atributo filtroPorTipoParcelaRecebidos.
	 *
	 * @return filtroPorTipoParcelaRecebidos
	 */
	public String getFiltroPorTipoParcelaRecebidos() {

		return this.filtroPorTipoParcelaRecebidos;
	}

	/**
	 * Define o valor do atributo filtroPorTipoParcelaRecebidos.
	 *
	 * @param filtroPorTipoParcelaRecebidos
	 *            valor a ser atribuído
	 */
	public void setFiltroPorTipoParcelaRecebidos(final String filtroPorTipoParcelaRecebidos) {

		this.filtroPorTipoParcelaRecebidos = filtroPorTipoParcelaRecebidos;
	}

	/**
	 * Retorna o valor do atributo filtroPorDtVencimentoRecebidos.
	 *
	 * @return filtroPorDtVencimentoRecebidos
	 */
	public Date getFiltroPorDtVencimentoRecebidos() {
		return this.filtroPorDtVencimentoRecebidos;
	}

	/**
	 * Define o valor do atributo filtroPorDtVencimentoRecebidos.
	 *
	 * @param filtroPorDtVencimentoRecebidos
	 *            valor a ser atribuído
	 */
	public void setFiltroPorDtVencimentoRecebidos(final Date filtroPorDtVencimentoRecebidos) {
		this.filtroPorDtVencimentoRecebidos = filtroPorDtVencimentoRecebidos;
	}

	/**
	 * Retorna o valor do atributo filtroPorNDocumentoRecebidos.
	 *
	 * @return filtroPorNDocumentoRecebidos
	 */
	public Integer getFiltroPorNDocumentoRecebidos() {
		return this.filtroPorNDocumentoRecebidos;
	}

	/**
	 * Define o valor do atributo filtroPorNDocumentoRecebidos.
	 *
	 * @param filtroPorNDocumentoRecebidos
	 *            valor a ser atribuído
	 */
	public void setFiltroPorNDocumentoRecebidos(final Integer filtroPorNDocumentoRecebidos) {
		this.filtroPorNDocumentoRecebidos = filtroPorNDocumentoRecebidos;
	}

	/**
	 * Retorna o valor do atributo filtroPorNossoNumeroRecebidos.
	 *
	 * @return filtroPorNossoNumeroRecebidos
	 */
	public String getFiltroPorNossoNumeroRecebidos() {

		return this.filtroPorNossoNumeroRecebidos;
	}

	/**
	 * Define o valor do atributo filtroPorNossoNumeroRecebidos.
	 *
	 * @param filtroPorNossoNumeroRecebidos
	 *            valor a ser atribuído
	 */
	public void setFiltroPorNossoNumeroRecebidos(final String filtroPorNossoNumeroRecebidos) {

		this.filtroPorNossoNumeroRecebidos = filtroPorNossoNumeroRecebidos;
	}

	/**
	 * Retorna o valor do atributo filtroPorValorTituloRecebidos.
	 *
	 * @return filtroPorValorTituloRecebidos
	 */
	public BigDecimal getFiltroPorValorTituloRecebidos() {

		return this.filtroPorValorTituloRecebidos;
	}

	/**
	 * Define o valor do atributo filtroPorValorTituloRecebidos.
	 *
	 * @param filtroPorValorTituloRecebidos
	 *            valor a ser atribuído
	 */
	public void setFiltroPorValorTituloRecebidos(final BigDecimal filtroPorValorTituloRecebidos) {

		this.filtroPorValorTituloRecebidos = filtroPorValorTituloRecebidos;
	}

	/**
	 * Retorna o valor do atributo filtroPorValorPagoRecebidos.
	 *
	 * @return filtroPorValorPagoRecebidos
	 */
	public BigDecimal getFiltroPorValorPagoRecebidos() {

		return this.filtroPorValorPagoRecebidos;
	}

	/**
	 * Define o valor do atributo filtroPorValorPagoRecebidos.
	 *
	 * @param filtroPorValorPagoRecebidos
	 *            valor a ser atribuído
	 */
	public void setFiltroPorValorPagoRecebidos(final BigDecimal filtroPorValorPagoRecebidos) {

		this.filtroPorValorPagoRecebidos = filtroPorValorPagoRecebidos;
	}

	/**
	 * Retorna o valor do atributo filtroPorNCedenteRecebidos.
	 *
	 * @return filtroPorNCedenteRecebidos
	 */
	public Integer getFiltroPorNCedenteRecebidos() {
		return this.filtroPorNCedenteRecebidos;
	}

	/**
	 * Define o valor do atributo filtroPorNCedenteRecebidos.
	 *
	 * @param filtroPorNCedenteRecebidos
	 *            valor a ser atribuído
	 */
	public void setFiltroPorNCedenteRecebidos(final Integer filtroPorNCedenteRecebidos) {
		this.filtroPorNCedenteRecebidos = filtroPorNCedenteRecebidos;
	}

	/**
	 * Retorna o valor do atributo filtroPorNProponenteRecebidos.
	 *
	 * @return filtroPorNProponenteRecebidos
	 */
	public String getFiltroPorNProponenteRecebidos() {

		return this.filtroPorNProponenteRecebidos;
	}

	/**
	 * Define o valor do atributo filtroPorNProponenteRecebidos.
	 *
	 * @param filtroPorNProponenteRecebidos
	 *            valor a ser atribuído
	 */
	public void setFiltroPorNProponenteRecebidos(final String filtroPorNProponenteRecebidos) {

		this.filtroPorNProponenteRecebidos = filtroPorNProponenteRecebidos;
	}

	/**
	 * Retorna o valor do atributo listaAmortizacoes.
	 *
	 * @return listaAmortizacoes
	 */
	public Collection<Recebido> getListaAmortizacoes() {
		return this.listaAmortizacoes;
	}

	/**
	 * Define o valor do atributo listaAmortizacoes.
	 *
	 * @param listaAmortizacoes
	 *            valor a ser atribuído
	 */
	public void setListaAmortizacoes(final Collection<Recebido> listaAmortizacoes) {
		this.listaAmortizacoes = listaAmortizacoes;
	}

	/**
	 * Retorna o valor do atributo icAmortizacoesInativos.
	 *
	 * @return icAmortizacoesInativos
	 */
	public Boolean getIcAmortizacoesInativos() {
		return this.icAmortizacoesInativos;

	}

	/**
	 * Define o valor do atributo icAmortizacoesInativos.
	 *
	 * @param icAmortizacoesInativos
	 *            valor a ser atribuído
	 */
	public void setIcAmortizacoesInativos(final Boolean icAmortizacoesInativos) {
		this.icAmortizacoesInativos = icAmortizacoesInativos;
	}

	/**
	 * Retorna o valor do atributo filtroPorDtPagamentoAmortizacao.
	 *
	 * @return filtroPorDtPagamentoAmortizacao
	 */
	public Date getFiltroPorDtPagamentoAmortizacao() {
		return this.filtroPorDtPagamentoAmortizacao;
	}

	/**
	 * Define o valor do atributo filtroPorDtPagamentoAmortizacao.
	 *
	 * @param filtroPorDtPagamentoAmortizacao
	 *            valor a ser atribuído
	 */
	public void setFiltroPorDtPagamentoAmortizacao(final Date filtroPorDtPagamentoAmortizacao) {
		this.filtroPorDtPagamentoAmortizacao = filtroPorDtPagamentoAmortizacao;
	}

	/**
	 * Retorna o valor do atributo filtroPorValorPagoAmortizacao.
	 *
	 * @return filtroPorValorPagoAmortizacao
	 */
	public BigDecimal getFiltroPorValorPagoAmortizacao() {

		return this.filtroPorValorPagoAmortizacao;
	}

	/**
	 * Define o valor do atributo filtroPorValorPagoAmortizacao.
	 *
	 * @param filtroPorValorPagoAmortizacao
	 *            valor a ser atribuído
	 */
	public void setFiltroPorValorPagoAmortizacao(final BigDecimal filtroPorValorPagoAmortizacao) {

		this.filtroPorValorPagoAmortizacao = filtroPorValorPagoAmortizacao;
	}

	/**
	 * Retorna o valor do atributo
	 * filtroPorMatriculaUsuarioResponsavelAmortizacao.
	 *
	 * @return filtroPorMatriculaUsuarioResponsavelAmortizacao
	 */
	public String getFiltroPorMatriculaUsuarioResponsavelAmortizacao() {

		return this.filtroPorMatriculaUsuarioResponsavelAmortizacao;
	}

	/**
	 * Define o valor do atributo
	 * filtroPorMatriculaUsuarioResponsavelAmortizacao.
	 *
	 * @param filtroPorMatriculaUsuarioResponsavelAmortizacao
	 *            valor a ser atribuído
	 */
	public void setFiltroPorMatriculaUsuarioResponsavelAmortizacao(final String filtroPorMatriculaUsuarioResponsavelAmortizacao) {

		this.filtroPorMatriculaUsuarioResponsavelAmortizacao = filtroPorMatriculaUsuarioResponsavelAmortizacao;
	}

	/**
	 * <p>
	 * Retorna o valor do atributo idLinhaClicadaAmortizacao
	 * </p>
	 * .
	 *
	 * @return idLinhaClicadaAmortizacao
	 */
	public String getIdLinhaClicadaAmortizacao() {
		return this.idLinhaClicadaAmortizacao;
	}

	/**
	 * <p>
	 * Define o valor do atributo idLinhaClicadaAmortizacao
	 * </p>
	 * .
	 *
	 * @param idLinhaClicadaAmortizacao
	 *            valor a ser atribuído
	 */
	public void setIdLinhaClicadaAmortizacao(final String idLinhaClicadaAmortizacao) {
		this.idLinhaClicadaAmortizacao = idLinhaClicadaAmortizacao;
	}

	public boolean isEditingTipologia() {
		return this.editingTipologia;
	}

	public void setEditingTipologia(final boolean editingTipologia) {
		this.editingTipologia = editingTipologia;
	}

	/**
	 * <p>
	 * Retorna o valor do atributo listaBandeiraCartao
	 * </p>
	 * .
	 *
	 * @return listaBandeiraCartao
	 */
	public List<BandeiraCartao> getListaBandeiraCartao() {
		if (this.listaBandeiraCartao == null) {
			this.listaBandeiraCartao = new ArrayList<>();
		}
		return this.listaBandeiraCartao;
	}

	/**
	 * <p>
	 * Define o valor do atributo listaBandeiraCartao
	 * </p>
	 * .
	 *
	 * @param listaBandeiraCartao
	 *            valor a ser atribuído
	 */
	public void setListaBandeiraCartao(final List<BandeiraCartao> listaBandeiraCartao) {
		this.listaBandeiraCartao = listaBandeiraCartao;
	}

	/**
	 * <p>
	 * Retorna o valor do atributo podeAlterarValorCV
	 * </p>
	 * .
	 *
	 * @return podeAlterarValorCV
	 */
	public Boolean getPodeAlterarValorCV() {
		return this.podeAlterarValorCV;
	}

	/**
	 * <p>
	 * Define o valor do atributo podeAlterarValorCV
	 * </p>
	 * .
	 *
	 * @param podeAlterarValorCV
	 *            valor a ser atribuído
	 */
	public void setPodeAlterarValorCV(final Boolean podeAlterarValorCV) {
		this.podeAlterarValorCV = podeAlterarValorCV;
	}

	/**
	 * <p>
	 * Retorna o valor do atributo listUnidadeHabitacional
	 * </p>
	 * .
	 *
	 * @return listUnidadeHabitacional
	 */
	public List<UnidadeHabitacional> getListUnidadeHabitacional() {
		if (this.listUnidadeHabitacional == null) {
			this.listUnidadeHabitacional = new ArrayList<>();
		}
		return this.listUnidadeHabitacional;
	}

	/**
	 * <p>
	 * Define o valor do atributo listUnidadeHabitacional
	 * </p>
	 * .
	 *
	 * @param listUnidadeHabitacional
	 *            valor a ser atribuído
	 */
	public void setListUnidadeHabitacional(final List<UnidadeHabitacional> listUnidadeHabitacional) {
		this.listUnidadeHabitacional = listUnidadeHabitacional;
	}

	/**
	 * <p>
	 * Retorna o valor do atributo codUHselecionada
	 * </p>
	 * .
	 *
	 * @return codUHselecionada
	 */
	public Long getCodUHselecionada() {
		return this.codUHselecionada;
	}

	/**
	 * <p>
	 * Define o valor do atributo codUHselecionada
	 * </p>
	 * .
	 *
	 * @param codUHselecionada
	 *            valor a ser atribuído
	 */
	public void setCodUHselecionada(final Long codUHselecionada) {
		this.codUHselecionada = codUHselecionada;
	}

	/**
	 * <p>
	 * Retorna o valor do atributo nuRecebidoSelecionado
	 * </p>
	 * .
	 *
	 * @return nuRecebidoSelecionado
	 */
	public Integer getNuRecebidoSelecionado() {
		return this.nuRecebidoSelecionado;
	}

	/**
	 * <p>
	 * Define o valor do atributo nuRecebidoSelecionado
	 * </p>
	 * .
	 *
	 * @param nuRecebidoSelecionado
	 *            valor a ser atribuído
	 */
	public void setNuRecebidoSelecionado(final Integer nuRecebidoSelecionado) {
		this.nuRecebidoSelecionado = nuRecebidoSelecionado;
	}

	/**
	 * 
	 * <p>
	 * Retorna o valor do atributo indiceHipotecario
	 * </p>
	 * .
	 *
	 * @return indiceHipotecario
	 */
	public BigDecimal getIndiceHipotecario() {
		return this.indiceHipotecario;
	}

	/**
	 * 
	 * <p>
	 * Define o valor do atributo indiceHipotecario
	 * </p>
	 * .
	 *
	 * @param indiceHipotecario
	 *            valor a ser atribuído
	 */
	public void setIndiceHipotecario(final BigDecimal indiceHipotecario) {
		this.indiceHipotecario = indiceHipotecario;
	}

	/**
	 * <p>
	 * Retorna o valor do atributo indiceRecebiveis
	 * </p>
	 * .
	 *
	 * @return indiceRecebiveis
	 */
	public BigDecimal getIndiceRecebiveis() {
		return this.indiceRecebiveis;
	}

	/**
	 * <p>
	 * Define o valor do atributo indiceRecebiveis
	 * </p>
	 * .
	 *
	 * @param indiceRecebiveis
	 *            valor a ser atribuído
	 */
	public void setIndiceRecebiveis(final BigDecimal indiceRecebiveis) {
		this.indiceRecebiveis = indiceRecebiveis;
	}

	/**
	 * <p>
	 * Retorna o valor do atributo cpfCnpjSacadoSelecionado
	 * </p>
	 * .
	 *
	 * @return cpfCnpjSacadoSelecionado
	 */
	public String getCpfCnpjSacadoSelecionado() {
		return this.cpfCnpjSacadoSelecionado;
	}

	/**
	 * <p>
	 * Define o valor do atributo cpfCnpjSacadoSelecionado
	 * </p>
	 * .
	 *
	 * @param cpfCnpjSacadoSelecionado
	 *            valor a ser atribuído
	 */
	public void setCpfCnpjSacadoSelecionado(final String cpfCnpjSacadoSelecionado) {
		this.cpfCnpjSacadoSelecionado = cpfCnpjSacadoSelecionado;
	}

	/**
	 * <p>
	 * Retorna o valor do atributo nomeSacadoSelecionado
	 * </p>
	 * .
	 *
	 * @return nomeSacadoSelecionado
	 */
	public String getNomeSacadoSelecionado() {
		return this.nomeSacadoSelecionado;
	}

	/**
	 * <p>
	 * Define o valor do atributo nomeSacadoSelecionado
	 * </p>
	 * .
	 *
	 * @param nomeSacadoSelecionado
	 *            valor a ser atribuído
	 */
	public void setNomeSacadoSelecionado(final String nomeSacadoSelecionado) {
		this.nomeSacadoSelecionado = nomeSacadoSelecionado;
	}

	/**
	 * <p>
	 * Retorna o valor do atributo segmentoMPE
	 * </p>
	 * .
	 *
	 * @return segmentoMPE
	 */
	public boolean isSegmentoMPE() {
		return this.segmentoMPE;
	}

	/**
	 * <p>
	 * Define o valor do atributo segmentoMPE
	 * </p>
	 * .
	 *
	 * @param segmentoMPE
	 *            valor a ser atribuído
	 */
	public void setSegmentoMPE(final boolean segmentoMPE) {
		this.segmentoMPE = segmentoMPE;
	}

	/**
	 * <p>
	 * Retorna o valor do atributo listaTiposContas
	 * </p>
	 * .
	 *
	 * @return listaTiposContas
	 */
	public List<ContaEnum> getListaTiposContas() {
		return Arrays.asList(ContaEnum.CONTA_NAO_LIVRE_MOVIMENTACAO, ContaEnum.NORMAL);
	}

	/**
	 * @return the listaTipoLogradouro
	 */
	public List<TipoLogradouroEnum> getListaTipoLogradouro() {
		if (this.listaTipoLogradouro == null) {
			this.listaTipoLogradouro = Arrays.asList(TipoLogradouroEnum.values());
		}
		return this.listaTipoLogradouro;
	}
	
	/**
	 * @return the garantiaContratoImoveis
	 */
	public Boolean getGarantiaContratoImoveis() {
		return this.garantiaContratoImoveis;
	}

	/**
	 * @param garantiaContratoImoveis
	 *            the garantiaContratoImoveis to set
	 */
	public void setGarantiaContratoImoveis(final Boolean garantiaContratoImoveis) {
		this.garantiaContratoImoveis = garantiaContratoImoveis;
	}

	/**
	 * <p>
	 * Retorna o valor do atributo garantiaPassouSerAcompanhada
	 * </p>
	 * .
	 *
	 * @return garantiaPassouSerAcompanhada
	 */
	public boolean isGarantiaPassouSerAcompanhada() {
		return this.garantiaPassouSerAcompanhada;
	}

	/**
	 * <p>
	 * Define o valor do atributo garantiaPassouSerAcompanhada
	 * </p>
	 * .
	 *
	 * @param garantiaPassouSerAcompanhada
	 *            valor a ser atribuído
	 */
	public void setGarantiaPassouSerAcompanhada(boolean garantiaPassouSerAcompanhada) {
		this.garantiaPassouSerAcompanhada = garantiaPassouSerAcompanhada;
	}

	/**
	 * <p>
	 * Método responsável por retornar o valor do nuMaquinaEquipamento
	 * </p>
	 * .
	 *
	 * @author narcieliton.lopes
	 *
	 * @return
	 */
	public Integer getNuMaquinaEquipamento() {
		return nuMaquinaEquipamento;
	}

	/**
	 * <p>
	 * Define o valor do atributo nuImovel
	 * </p>
	 * .
	 *
	 * @author narcieliton
	 *
	 * @param nuImovel
	 *            valor a ser atribuído
	 */
	public void setNuMaquinaEquipamento(Integer nuMaquinaEquipamento) {
		this.nuMaquinaEquipamento = nuMaquinaEquipamento;
	}

	public Pessoa getPessoaTerceiro() {
		if (pessoaTerceiro == null) {
			pessoaTerceiro = new Pessoa();
		}
		return pessoaTerceiro;
	}

	public void setPessoaTerceiro(Pessoa pessoaTerceiro) {
		this.pessoaTerceiro = pessoaTerceiro;
	}

	public Map<String, List<GarantiaCartaoCredito>> getMapaContaCartoes() {
		if (mapaContaCartoes == null) {
			mapaContaCartoes = new HashMap<>();
		}
		return mapaContaCartoes;
	}

	public void setMapaContaCartoes(Map<String, List<GarantiaCartaoCredito>> mapaContaCartoes) {
		this.mapaContaCartoes = mapaContaCartoes;
	}

	public Long getNuVeiculoAcompanhado() {
		return nuVeiculoAcompanhado;
	}

	public void setNuVeiculoAcompanhado(Long nuVeiculoAcompanhado) {
		this.nuVeiculoAcompanhado = nuVeiculoAcompanhado;
	}

	public List<BemCliente> getListaBemCliente() {
		if (listaBemCliente == null) {
			listaBemCliente = new ArrayList<>();
		}
		return listaBemCliente;
	}

	public void setListaBemCliente(List<BemCliente> listaBemCliente) {
		this.listaBemCliente = listaBemCliente;
	}
	
	/**
	 * <p>Retorna o valor do atributo origemParametrizacao</p>.
	 *
	 * @return origemParametrizacao
	*/
	public OrigemParametrizacaoEnum getOrigemParametrizacao() {
		return this.origemParametrizacao;
	}

	/**
	 * <p>Define o valor do atributo origemParametrizacao</p>.
	 *
	 * @param origemParametrizacao valor a ser atribuído
	*/
	public void setOrigemParametrizacao(OrigemParametrizacaoEnum origemParametrizacao) {
		this.origemParametrizacao = origemParametrizacao;
	}

	public List<ContaCorrenteBandeirasVO> getListaContaCorrenteBandeiras() {
		if (CollectionUtils.isEmpty(this.listaContaCorrenteBandeiras)) {
		    this.listaContaCorrenteBandeiras = new ArrayList<>();
		}
	
		return this.listaContaCorrenteBandeiras;
    }

	public void setListaContaCorrenteBandeiras(List<ContaCorrenteBandeirasVO> listaContaCorrenteBandeiras) {
		this.listaContaCorrenteBandeiras = listaContaCorrenteBandeiras;
	}

/**
	 * <p>Retorna o valor do atributo parametroComercializacaoEmExclusao</p>.
	 *
	 * @return parametroComercializacaoEmExclusao
	*/
	public ParametroComercializacao getParametroComercializacaoEmExclusao() {
		return this.parametroComercializacaoEmExclusao;
	}

	/**
	 * <p>Define o valor do atributo parametroComercializacaoEmExclusao</p>.
	 *
	 * @param parametroComercializacaoEmExclusao valor a ser atribuído
	*/
	public void setParametroComercializacaoEmExclusao(ParametroComercializacao parametroComercializacaoEmExclusao) {
		this.parametroComercializacaoEmExclusao = parametroComercializacaoEmExclusao;
	}

	public Integer getTipoConfig() {
		return tipoConfig;
	}

	public void setTipoConfig(Integer tipoConfig) {
		this.tipoConfig = tipoConfig;
	}

	public List<UnidadeVO> getUnidadesSelecionadas() {
		return unidadesSelecionadas;
	}

	public void setUnidadesSelecionadas(List<UnidadeVO> unidadesSelecionadas) {
		this.unidadesSelecionadas = unidadesSelecionadas;
	}

	public List<UnidadeVO> getUnidadesRemocao() {
		if(unidadesRemocao == null) {
			this.unidadesRemocao = new ArrayList<>();
		}
		return unidadesRemocao;
	}

	public void setUnidadesRemocao(List<UnidadeVO> unidadesRemocao) {
		this.unidadesRemocao = unidadesRemocao;
	}

	public void setUnidadesTemp(List<UnidadeVO> unidadesTemp) {
		this.unidadesTemp = unidadesTemp;
	}

	public List<UnidadeVO> getUnidadesTemp() {
		return unidadesTemp;
	}

	public Integer getUnidadeGestoraSeleciona() {
		return unidadeGestoraSeleciona;
	}

	public void setUnidadeGestoraSeleciona(Integer unidadeGestoraSeleciona) {
		this.unidadeGestoraSeleciona = unidadeGestoraSeleciona;
	}

	public List<UnidadeVO> getListaDires() {
		return listaDires;
	}

	public void setListaDires(List<UnidadeVO> listaDires) {
		this.listaDires = listaDires;
	}
	
	
	
	
	/**
	 * Retorna o valor do atributo listaUnidadeHabitacional.
	 *
	 * @return listaUnidadeHabitacional
	 */
	public Collection<UnidadeHabitacional> getListaUnidadeHabitacional() {
		if (!UtilObjeto.isReferencia(this.listaUnidadeHabitacional)) {
			this.listaUnidadeHabitacional = new ArrayList<>();
		}

		return this.listaUnidadeHabitacional;
	}

	/**
	 * Define o valor do atributo listaUnidadeHabitacional.
	 *
	 * @param listaUnidadeHabitacional
	 *            valor a ser atribuído
	 */
	public void setListaUnidadeHabitacional(final Collection<UnidadeHabitacional> listaUnidadeHabitacional) {

		this.listaUnidadeHabitacional = listaUnidadeHabitacional;
	}
	
	/**
	 * <p>Retorna o valor do atributo historicosProspecto</p>.
	 *
	 * @return historicosProspecto
	*/
	public List<RelatorioHistoricoUnidadeHabitacionalVO> getHistoricosProspecto() {
		if (historicosProspecto == null) {
			setHistoricosProspecto(new ArrayList<RelatorioHistoricoUnidadeHabitacionalVO>());
		}
		
		return this.historicosProspecto;
	}

	/**
	 * <p>Define o valor do atributo historicosProspecto</p>.
	 *
	 * @param historicosProspecto valor a ser atribuído
	*/
	public void setHistoricosProspecto(List<RelatorioHistoricoUnidadeHabitacionalVO> historicosProspecto) {
		this.historicosProspecto = historicosProspecto;
	}

	/**
	 * <p>Retorna o valor do atributo valorUtilizadoOutrasGarantias</p>.
	 *
	 * @return valorUtilizadoOutrasGarantias
	*/
	public Map<Integer, BigDecimal> getValorUtilizadoOutrasGarantias() {
		if (valorUtilizadoOutrasGarantias == null) {
			setValorUtilizadoOutrasGarantias(new HashMap<Integer, BigDecimal>());
		}
		
		return this.valorUtilizadoOutrasGarantias;
	}

	/**
	 * <p>Define o valor do atributo valorUtilizadoOutrasGarantias</p>.
	 *
	 * @param valorUtilizadoOutrasGarantias valor a ser atribuído
	*/
	public void setValorUtilizadoOutrasGarantias(Map<Integer,BigDecimal> valorUtilizadoOutrasGarantias) {
		this.valorUtilizadoOutrasGarantias = valorUtilizadoOutrasGarantias;
	}

	/**
	 * <p>Retorna o valor do atributo garantiaContratoClone</p>.
	 *
	 * @return garantiaContratoClone
	*/
	public GarantiaContrato getGarantiaContratoClone() {
		return this.garantiaContratoClone;
	}

	/**
	 * <p>Define o valor do atributo garantiaContratoClone</p>.
	 *
	 * @param garantiaContratoClone valor a ser atribuído
	*/
	public void setGarantiaContratoClone(GarantiaContrato garantiaContratoClone) {
		this.garantiaContratoClone = garantiaContratoClone;
	}
}