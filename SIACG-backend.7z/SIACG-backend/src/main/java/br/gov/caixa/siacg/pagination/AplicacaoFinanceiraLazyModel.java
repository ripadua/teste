/*
 * Copyright (c) 2019 Caixa Econômica Federal. Todos os direitos
 * reservados.
 *
 * Caixa Econômica Federal - SIACG - Sistema de Crédito Rural
 *
 * Este software foi desenvolvido sob demanda da CAIXA e está
 * protegido por leis de direitos autorais e tratados internacionais. As
 * condições de cópia e utilização do todo ou partes dependem de autorização da
 * empresa. Cópias não são permitidas sem expressa autorização. Não pode ser
 * comercializado ou utilizado para propósitos particulares.
 *
 * Uso exclusivo da Caixa Econômica Federal. A reprodução ou distribuição não
 * autorizada deste programa ou de parte dele, resultará em punições civis e
 * criminais e os infratores incorrem em sanções previstas na legislação em
 * vigor.
 *
 * Histórico do TFS:
 *
 * LastChangedRevision: $Revision$
 * LastChangedBy: $Author$
 * LastChangedDate: $Date$
 *
 * HeadURL: $HeadURL$
 *
 */
package br.gov.caixa.siacg.pagination;

import java.util.List;
import java.util.Map;

import javax.ejb.EJB;
import javax.enterprise.context.SessionScoped;
import javax.inject.Named;

import org.primefaces.model.SortOrder;

import br.gov.caixa.pedesgo.arquitetura.paginacao.Paginacao;
import br.gov.caixa.pedesgo.arquitetura.paginacao.PaginacaoDemanda;
import br.gov.caixa.pedesgo.arquitetura.util.UtilObjeto;
import br.gov.caixa.siacg.model.domain.AplicacaoFinanceira;
import br.gov.caixa.siacg.model.vo.FiltroAplicacaoFinanceiraVO;
import br.gov.caixa.siacg.service.AplicacaoFinanceiraService;

/**
 * <p>
 * AplicacaoFinanceiraLazyModel
 * </p>
 *
 * <p>
 * Descrição: Descrição do tipo
 * </p>
 *
 * <br>
 * <b>Empresa:</b> Cef - Caixa Econômica Federal
 *
 *
 * @author f575368
 *
 * @version 1.0
 */
@Named
@SessionScoped
public class AplicacaoFinanceiraLazyModel extends Paginacao<AplicacaoFinanceira> {

    /** Atributo serialVersionUID. */
    private static final long serialVersionUID = 1L;

    /** Atributo NOME_MANAGED_BEAN. */
    public static final String NOME_MANAGED_BEAN = "aplicacaoFinanceiraLazyModel";

    /** Atributo EL_MANAGED_BEAN. */
    public static final String EL_MANAGED_BEAN = "#{aplicacaoFinanceiraLazyModel}";

    /** Atributo de Serviço */
    @EJB
    private transient AplicacaoFinanceiraService service;

    /** Atributo Filtro Tela */
    private transient FiltroAplicacaoFinanceiraVO filtro;

    @Override
    public List<AplicacaoFinanceira> load(int inicio, int fim, String campoOrdenacao, SortOrder ordenacao, Map<String, String> parametros) {

	filtro.setCampoOrdenacao(campoOrdenacao);
	filtro.setTipoOrdenacao(ordenacao.name());
	final PaginacaoDemanda<AplicacaoFinanceira> resultado = this.service.listarAplicacaoFinanceira(this.filtro, inicio, fim);

	super.setWrappedData(resultado.getLista());
	super.setRowCount(resultado.getQuantidadeRegistros());

	return resultado.getLista();

    }

    /**
     * @see br.gov.caixa.pedesgo.arquitetura.integracao.componente.paginacao.Paginacao#getServico()
     */
    @Override
    @SuppressWarnings("unchecked")
    public AplicacaoFinanceiraService getServico() {
	return this.service;

    }

    public void limparFiltro() {
	this.getFiltro().setIdentificadorPessoa(null);
	this.getFiltro().setNota(null);
    }

    /**
     * <p>
     * Retorna o valor do atributo filtro
     * </p>
     * .
     *
     * @return filtro
     */
    public FiltroAplicacaoFinanceiraVO getFiltro() {
	if (!UtilObjeto.isReferencia(this.filtro)) {
	    this.filtro = new FiltroAplicacaoFinanceiraVO();
	}

	return this.filtro;
    }

    /**
     * <p>
     * Define o valor do atributo filtro
     * </p>
     * .
     *
     * @param filtro
     *            valor a ser atribuído
     */
    public void setFiltro(FiltroAplicacaoFinanceiraVO filtro) {
	this.filtro = filtro;
    }

}
