/**
 * Copyright (c) 2018 Caixa Econômica Federal. Todos os direitos
 * reservados.
 *
 * Caixa Econômica Federal - SIACG
 *
 * Este software foi desenvolvido sob demanda da CAIXA e está
 * protegido por leis de direitos autorais e tratados internacionais. As
 * condições de cópia e utilização total ou partes dependem de autorização da
 * empresa. Cópias não são permitidas sem expressa autorização. Não pode ser
 * comercializado ou utilizado para propósitos particulares.
 *
 * Uso exclusivo da Caixa Econômica Federal. A reprodução ou distribuição não
 * autorizada deste programa ou de parte dele, resultará em punições civis e
 * criminais e os infratores incorrem em sanções previstas na legislação em
 * vigor.
 *
 * Histórico do TFS:
 *
 * LastChangedRevision: $Revision$
 * LastChangedBy: $Author$
 * LastChangedDate: $Date$
 *
 * HeadURL: $HeadURL$
 *
 */	
package br.gov.caixa.siacg.strategy.impl.titulo;

import java.util.Calendar;
import java.util.Date;

import br.gov.caixa.siacg.model.domain.Titulo;
import br.gov.caixa.siacg.model.vo.DadosAnaliseFluxoVO;
import br.gov.caixa.siacg.model.vo.DadosComposicaoCarteiraVO;

/**
 * <p>ConjuntoTituloLiquidado</p>
 *
 * <p>Descrição: Classe que representa um conjunto de titulos liquidados</p>
 *
 * <br><b>Empresa:</b> Cef - Caixa Econômica Federal
 *
 *
 * @author p541915
 *
 * @version 1.0
*/
public class ConjuntoTituloComposicaoCarteira extends ConjuntoTitulo {

	/** Atributo CANAL_RECEBEDOR_COMPENSACAO. */
    private static final String CANAL_RECEBEDOR_COMPENSACAO = "8575";
    
	/** Atributo dadosAnaliseFluxo. */
	private DadosAnaliseFluxoVO dadosAnaliseFluxo;
	
	/** Atributo dataProcessamento. */
	private Date dataProcessamento;
	
	/** Atributo dataLimite30Dias. */
	private Date dataLimite30Dias;
	
	/** Atributo dataLimite60Dias. */
	private Date dataLimite60Dias;
	
	/** Atributo dadosComposicao. */
	private DadosComposicaoCarteiraVO dadosComposicao;
	
	/**
	 * Responsável pela criação de novas instâncias desta classe.
	 *
	 *
	 */
	public ConjuntoTituloComposicaoCarteira(DadosAnaliseFluxoVO dadosAnaliseFluxo, DadosComposicaoCarteiraVO dadosComposicao) {
		this.dadosAnaliseFluxo = dadosAnaliseFluxo;
		this.dadosComposicao = dadosComposicao;
		
		final Calendar calendar = Calendar.getInstance();
        calendar.add(Calendar.DATE, -1);
        
		this.dataProcessamento = calendar.getTime();
		
		 calendar.add(Calendar.DATE, -30);
		
		this.dataLimite30Dias = calendar.getTime();
		
		calendar.add(Calendar.DATE, -30);

        this.dataLimite60Dias = calendar.getTime();
	}
	
	/**
	 * @see br.gov.caixa.siacg.strategy.impl.titulo.ConjuntoTitulo#adicionarTitulo(br.gov.caixa.siacg.model.domain.Titulo)
	*/
	@Override
	public void adicionarTitulo(Titulo titulo) {
		super.adicionarTitulo(titulo);
		
		this.dadosComposicao.addQtdDuplicatasCarteira();
		this.dadosComposicao.addValorDuplicatasCarteira(titulo.getVrTitulo());
		
		if (titulo.isTituloLiquidado()) {
        	
        	if (CANAL_RECEBEDOR_COMPENSACAO.equals(titulo.getNuCanalRecebedor())) {
                this.dadosComposicao.addValorPagoCompensacao(titulo.getVrTitulo());
                this.dadosComposicao.addQtdPagoCompensacao();
            } else {
            	this.dadosComposicao.addValorPagoCaixa(titulo.getVrTitulo());
                this.dadosComposicao.addQtdPagoCaixa();
            }
        	
        	if (titulo.getDtLiquidacao().compareTo(this.dataLimite30Dias) >= 0 && titulo.getDtLiquidacao().compareTo(this.dataProcessamento) <= 0) {
                this.dadosAnaliseFluxo.addUltimos30Dias(titulo.getVrTitulo());
            }

            if (titulo.getDtLiquidacao().compareTo(this.dataLimite60Dias) >= 0 && titulo.getDtLiquidacao().compareTo(this.dataLimite30Dias) <= 0) {
                this.dadosAnaliseFluxo.addUltimos60Dias(titulo.getVrTitulo());
            }
        	
        } else if (titulo.isTituloProtestado()) {
        	this.dadosComposicao.addValorDuplicatasProtestadas(titulo.getVrTitulo());
            this.dadosComposicao.addQtdDuplicatasProtestadas();
        	
        } else if (titulo.isTituloBaixado()) {
        	this.dadosComposicao.addValorDuplicatasBaixadas(titulo.getVrTitulo());
            this.dadosComposicao.addQtdDuplicatasBaixadas();
        	
        } else if (titulo.isTituloVencido()) {
        	this.dadosComposicao.addValorDuplicatasVencidas(titulo.getVrTitulo());
            this.dadosComposicao.addQtdDuplicatasVencidas();
        	
        } else {
        	this.dadosComposicao.addValorDuplicatasAVencer(titulo.getVrTitulo());
            this.dadosComposicao.addQtdDuplicatasVencer();
        }
	}
}
