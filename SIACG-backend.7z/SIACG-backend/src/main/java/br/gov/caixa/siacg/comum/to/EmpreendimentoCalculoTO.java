/**
 * Copyright (c) 2020 Caixa Econômica Federal. Todos os direitos
 * reservados.
 *
 * Caixa Econômica Federal - SIACG
 *
 * Este software foi desenvolvido sob demanda da CAIXA e está
 * protegido por leis de direitos autorais e tratados internacionais. As
 * condições de cópia e utilização total ou partes dependem de autorização da
 * empresa. Cópias não são permitidas sem expressa autorização. Não pode ser
 * comercializado ou utilizado para propósitos particulares.
 *
 * Uso exclusivo da Caixa Econômica Federal. A reprodução ou distribuição não
 * autorizada deste programa ou de parte dele, resultará em punições civis e
 * criminais e os infratores incorrem em sanções previstas na legislação em
 * vigor.
 *
 * Histórico do TFS:
 *
 * LastChangedRevision: $Revision$
 * LastChangedBy: $Author$
 * LastChangedDate: $Date$
 *
 * HeadURL: $HeadURL$
 *
 */	
package br.gov.caixa.siacg.comum.to;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * <p>EmpreendimentoCalculoTO</p>
 *
 * <p>Descrição: Representa um empreendimento para o calculo do contrato</p>
 *
 * <br><b>Empresa:</b> Cef - Caixa Econômica Federal
 *
 *
 * @author f541915
 *
 * @version 1.0
*/
public class EmpreendimentoCalculoTO implements Serializable {

    /** Atributo serialVersionUID. */
    private static final long serialVersionUID = 1L;
    
    @JsonProperty("nu_empreendimento")
    private Long nuEmpreendimento;
    
    /** Atributo contrato. */
    private ContratoCalculoTO contrato;
    
    /**
     * Responsável pela criação de novas instâncias desta classe.
     *
     *
     */
    public EmpreendimentoCalculoTO() {
	super();
	
    }

    /**
     * Responsável pela criação de novas instâncias desta classe.
     *
     * @param nuEmpreendimento
     * @param contrato
     *
     */
    public EmpreendimentoCalculoTO(final Long nuEmpreendimento, final ContratoCalculoTO contrato) {
	super();
	this.nuEmpreendimento = nuEmpreendimento;
	this.contrato = contrato;
    }


    /**
     * <p>Retorna o valor do atributo nuEmpreendimento</p>.
     *
     * @return nuEmpreendimento
    */
    public Long getNuEmpreendimento() {
	return this.nuEmpreendimento;
    }

    /**
     * <p>Define o valor do atributo nuEmpreendimento</p>.
     *
     * @param nuEmpreendimento valor a ser atribuído
    */
    public void setNuEmpreendimento(Long nuEmpreendimento) {
	this.nuEmpreendimento = nuEmpreendimento;
    }

    /**
     * <p>Retorna o valor do atributo contrato</p>.
     *
     * @return contrato
    */
    public ContratoCalculoTO getContrato() {
	return this.contrato;
    }

    /**
     * <p>Define o valor do atributo contrato</p>.
     *
     * @param contrato valor a ser atribuído
    */
    public void setContrato(ContratoCalculoTO contrato) {
	this.contrato = contrato;
    }

}
