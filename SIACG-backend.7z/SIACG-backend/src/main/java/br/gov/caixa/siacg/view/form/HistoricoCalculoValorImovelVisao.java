/*
 * Copyright (c) 2021 Caixa Econômica Federal. Todos os direitos
 * reservados.
 *
 * Caixa Econômica Federal - SIACG - Sistema de Crédito Rural
 *
 * Este software foi desenvolvido sob demanda da CAIXA e está
 * protegido por leis de direitos autorais e tratados internacionais. As
 * condições de cópia e utilização do todo ou partes dependem de autorização da
 * empresa. Cópias não são permitidas sem expressa autorização. Não pode ser
 * comercializado ou utilizado para propósitos particulares.
 *
 * Uso exclusivo da Caixa Econômica Federal. A reprodução ou distribuição não
 * autorizada deste programa ou de parte dele, resultará em punições civis e
 * criminais e os infratores incorrem em sanções previstas na legislação em
 * vigor.
 *
 * Histórico do TFS:
 *
 * LastChangedRevision: $Revision$
 * LastChangedBy: $Author$
 * LastChangedDate: $Date$
 *
 * HeadURL: $HeadURL$
 *
 */
package br.gov.caixa.siacg.view.form;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;

import br.gov.caixa.pedesgo.arquitetura.util.UtilObjeto;
import br.gov.caixa.pedesgo.arquitetura.visao.ManutencaoVisao;
import br.gov.caixa.siacg.comum.to.AvaliacaoTO;
import br.gov.caixa.siacg.model.domain.HistoricoCalculoValorImovel;
import br.gov.caixa.siacg.model.domain.Imovel;
import br.gov.caixa.siacg.model.enums.EstadoOcupacaoImovelEnum;
import br.gov.caixa.siacg.model.enums.OrigemContratoHabitacionalEnum;

/**
 * <p>
 * HistoricoCalculoValorImovelVisao
 * </p>
 *
 * <p>
 * Descrição: Descrição do tipo
 * </p>
 *
 * <br>
 * <b>Empresa:</b> Cef - Caixa Econômica Federal
 *
 *
 * @author gerusa.soares
 *
 * @version 1.0
 */
public class HistoricoCalculoValorImovelVisao extends ManutencaoVisao<HistoricoCalculoValorImovel> {

    /** Atributo serialVersionUID. */
    private static final long serialVersionUID = 1L;

    private String coSequencial = "000";
    private String coIdentificadorContrato;
    private String matriculaResp;
    private String ordemServico;
    private Date dhCalculo;
    private BigDecimal vrDesagioImovel;
    private BigDecimal vrJusto;
    private OrigemContratoHabitacionalEnum origemEnumSelecionada;
    private OrigemContratoHabitacionalEnum origemContratoHabitacionalComercial = OrigemContratoHabitacionalEnum.COMERCIAL;
    
    private List<OrigemContratoHabitacionalEnum> listaOrigemContratoHabitacional;
    private List<EstadoOcupacaoImovelEnum> listaEstadoOcupacao;
    private List<Imovel> listaImoveisContrato;
    
    private boolean desabilitaBotaoNovo = true;
    
    private List<AvaliacaoTO> listaAvaliacaoImovel;
    private AvaliacaoTO avaliacaoImovelSelecionada;
    
    private String idCalculo;

    /**
     * Responsável pela criação de novas instâncias desta classe.
     *
     *
     */
    public HistoricoCalculoValorImovelVisao() {
	super();
    }

    public String getCoSequencial() {
	return this.coSequencial;
    }

    public void setCoSequencial(final String coSequencial) {
	this.coSequencial = coSequencial;
    }

    public String getCoIdentificadorContrato() {
	return this.coIdentificadorContrato;
    }

    public void setCoIdentificadorContrato(final String coIdentificadorContrato) {
	this.coIdentificadorContrato = coIdentificadorContrato;
    }

    public String getMatriculaResp() {
	return this.matriculaResp;
    }

    public void setMatriculaResp(final String matriculaResp) {
	this.matriculaResp = matriculaResp;
    }

    public String getOrdemServico() {
        return this.ordemServico;
    }

    public void setOrdemServico(final String ordemServico) {
        this.ordemServico = ordemServico;
    }

    public Date getDhCalculo() {
	return this.dhCalculo;
    }

    public void setDhCalculo(final Date dhCalculo) {
	this.dhCalculo = dhCalculo;
    }

    public BigDecimal getVrDesagioImovel() {
        return this.vrDesagioImovel;
    }

    public void setVrDesagioImovel(final BigDecimal vrDesagioImovel) {
        this.vrDesagioImovel = vrDesagioImovel;
    }

    public BigDecimal getVrJusto() {
	return this.vrJusto;
    }

    public void setVrJusto(final BigDecimal vrJusto) {
	this.vrJusto = vrJusto;
    }

    public OrigemContratoHabitacionalEnum getOrigemEnumSelecionada() {
        return this.origemEnumSelecionada;
    }

    public void setOrigemEnumSelecionada(final OrigemContratoHabitacionalEnum origemEnumSelecionada) {
        this.origemEnumSelecionada = origemEnumSelecionada;
    }

    public List<EstadoOcupacaoImovelEnum> getListaEstadoOcupacao() {
	if (UtilObjeto.isVazio(this.listaEstadoOcupacao)) {
	    this.listaEstadoOcupacao = new ArrayList<>();
	    this.listaEstadoOcupacao.addAll(Arrays.asList(EstadoOcupacaoImovelEnum.values()));
	}
	return this.listaEstadoOcupacao;
    }

    public void setListaEstadoOcupacao(final List<EstadoOcupacaoImovelEnum> listaEstadoOcupacao) {
	this.listaEstadoOcupacao = listaEstadoOcupacao;
    }

    public OrigemContratoHabitacionalEnum getOrigemContratoHabitacionalComercial() {
        return this.origemContratoHabitacionalComercial;
    }

    public void setOrigemContratoHabitacionalComercial(final OrigemContratoHabitacionalEnum origemContratoHabitacionalComercial) {
        this.origemContratoHabitacionalComercial = origemContratoHabitacionalComercial;
    }

    public List<OrigemContratoHabitacionalEnum> getListaOrigemContratoHabitacional() {
	if (UtilObjeto.isVazio(this.listaOrigemContratoHabitacional)) {
	    this.listaOrigemContratoHabitacional = new ArrayList<>();
	    this.listaOrigemContratoHabitacional.addAll(Arrays.asList(OrigemContratoHabitacionalEnum.values()));
	}
	return this.listaOrigemContratoHabitacional;
    }

    public void setListaOrigemContratoHabitacional(final List<OrigemContratoHabitacionalEnum> listaOrigemContratoHabitacional) {
	this.listaOrigemContratoHabitacional = listaOrigemContratoHabitacional;
    }

    public List<Imovel> getListaImoveisContrato() {
        return this.listaImoveisContrato;
    }

    public void setListaImoveisContrato(final List<Imovel> listaImoveisContrato) {
        this.listaImoveisContrato = listaImoveisContrato;
    }

    public boolean isDesabilitaBotaoNovo() {
        return this.desabilitaBotaoNovo;
    }

    public void setDesabilitaBotaoNovo(final boolean desabilitaBotaoNovo) {
        this.desabilitaBotaoNovo = desabilitaBotaoNovo;
    }

    public List<AvaliacaoTO> getListaAvaliacaoImovel() {
        return this.listaAvaliacaoImovel;
    }

    public void setListaAvaliacaoImovel(final List<AvaliacaoTO> listaAvaliacaoImovel) {
        this.listaAvaliacaoImovel = listaAvaliacaoImovel;
    }

    public AvaliacaoTO getAvaliacaoImovelSelecionada() {
        return this.avaliacaoImovelSelecionada;
    }

    public void setAvaliacaoImovelSelecionada(final AvaliacaoTO avaliacaoImovelSelecionada) {
        this.avaliacaoImovelSelecionada = avaliacaoImovelSelecionada;
    }

    public String getIdCalculo() {
        return this.idCalculo;
    }

    public void setIdCalculo(final String idCalculo) {
        this.idCalculo = idCalculo;
    }
   
}
