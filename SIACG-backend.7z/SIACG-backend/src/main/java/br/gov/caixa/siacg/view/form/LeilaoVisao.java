package br.gov.caixa.siacg.view.form;

import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import br.gov.caixa.siacg.comum.to.sicli.RespostaSicliTO;
import br.gov.caixa.siacg.model.domain.BemCliente;
import br.gov.caixa.siacg.model.domain.Contrato;
import br.gov.caixa.siacg.model.domain.leilao.HistoricoLeilao;
import br.gov.caixa.siacg.model.domain.leilao.Leilao;
import br.gov.caixa.siacg.model.enums.leilao.OpcoesLancamentoEnum;

public class LeilaoVisao extends TemplateVisao<Leilao> {

    private static final long serialVersionUID = 1L;

    private BemCliente bemCliente;

    private Contrato contrato;

    private RespostaSicliTO empreendimento;
    
    private List<HistoricoLeilao> listaHistoricoLeilao;

    private OpcoesLancamentoEnum opcaoLancamento;

    public BemCliente getBemCliente() {
	return this.bemCliente;
    }

    public void setBemCliente(BemCliente bemCliente) {
	this.bemCliente = bemCliente;
    }

    public Contrato getContrato() {
	return this.contrato;
    }

    public void setContrato(Contrato contrato) {
	this.contrato = contrato;
    }

    public RespostaSicliTO getEmpreendimento() {
	return this.empreendimento;
    }

    public void setEmpreendimento(RespostaSicliTO empreendimento) {
	this.empreendimento = empreendimento;
    }

    public OpcoesLancamentoEnum getOpcaoLancamento() {
	return this.opcaoLancamento;
    }

    public void setOpcaoLancamento(OpcoesLancamentoEnum opcaoLancamento) {
	this.opcaoLancamento = opcaoLancamento;
    }

    public List<OpcoesLancamentoEnum> getListaOpcoesLancamentoEnum() {
	return Stream.of(OpcoesLancamentoEnum.values()).collect(Collectors.toList());
    }

    public List<HistoricoLeilao> getListaHistoricoLeilao() {
        return this.listaHistoricoLeilao;
    }

    public void setListaHistoricoLeilao(final List<HistoricoLeilao> listaHistoricoLeilao) {
        this.listaHistoricoLeilao = listaHistoricoLeilao;
    }

}
