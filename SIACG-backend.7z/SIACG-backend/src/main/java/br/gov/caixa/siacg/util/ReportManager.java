/**
 * reservados.
 * Copyright (c) 2009-2011 Caixa Econômica Federal. Todos os direitos
 *
 * Caixa Econômica Federal - SIACG – Sistema de Acompanhamento de Carteiras de Cobrança
 *
 * Este programa de computador foi desenvolvido sob demanda da CAIXA e está
 * protegido por leis de direitos autorais e tratados internacionais. As
 * condições de cópia e utilização do total ou partes dependem de autorização da
 * pessoa. Cópias não são permitidas sem expressa autorização. Não pode ser
 * comercializado ou utilizado para propósitos particulares.
 *
 * Uso exclusivo da Caixa Econômica Federal. A reprodução ou distribuição não
 * autorizada deste programa ou de parte dele, resultará em punições civis e
 * criminais e os infratores incorrem em sanções previstas na legislação em
 * vigor.
 *
 * Histórico do Subversion:
 *
 * LastChangedRevision:
 * LastChangedBy:
 * LastChangedDate:
 *
 * HeadURL:
 *
 */
package br.gov.caixa.siacg.util;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.sql.Connection;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.logging.Logger;

import br.gov.caixa.siacg.commons.ReportErrorCreateDatasourceException;
import br.gov.caixa.siacg.commons.ReportFinalNullException;
import br.gov.caixa.siacg.commons.ReportInvalidPathException;
import net.sf.jasperreports.engine.JRException;
import net.sf.jasperreports.engine.JRExporterParameter;
import net.sf.jasperreports.engine.JRPrintPage;
import net.sf.jasperreports.engine.JasperExportManager;
import net.sf.jasperreports.engine.JasperFillManager;
import net.sf.jasperreports.engine.JasperPrint;
import net.sf.jasperreports.engine.JasperReport;
import net.sf.jasperreports.engine.data.JRBeanArrayDataSource;
import net.sf.jasperreports.engine.data.JRBeanCollectionDataSource;
import net.sf.jasperreports.engine.export.JRXlsAbstractExporterParameter;
import net.sf.jasperreports.engine.export.JRXlsExporter;
import net.sf.jasperreports.engine.fill.JRTemplatePrintText;
import net.sf.jasperreports.engine.util.JRLoader;

/**
 * Classe responsável por manipular relatórios (baseado na API JasperReport).
 * <br/>
 * Abstrai a complexidade da API JasperReport na criação e manipulação de
 * relatórios.<br/>
 * Possui uma lista interna de relatórios processados. Cada elemento desta lista
 * é um objeto do tipo JasperPrint. <br/>
 * Uma fonte de dados associada com uma arquivo .jasper, após processados
 * resulta em um objeto JasperPrint, que representa um relatório.<br/>
 * <br/>
 * Um objeto da classe ReportManager permite adicionar um par Fonte de
 * Dados/Arquivo .Jasper, na lista de interna de relatórios. <br/>
 * Este par é processado e transformado em um objeto do tipo JasperPrint, onde
 * este é armazenado na lista interna de relatórios. <br/>
 * A fonte de dados (Lista de Beans) já deve conter os dados desejados (dados
 * filtrados), não havendo necessidade de passagem de parâmetros.<br/>
 * <br/>
 * Um objeto desta classe possui a funcionalidade de unir vários relatórios,
 * pois em relatórios complexos nem sempre é possível compor em um único<br/>
 * relatório os dados da forma desejada. Assim, criamos individualmente cada
 * relatório, adicionando-os na lista interna, em seguida<br/>
 * gerando um único relatório resultado da união de todos. <br/>
 * <br/>
 * O relatório final unificado, pode ser obtido em formato PDF (array de bytes)
 * ou pode ser salvo em um caminho especificado. <br/>
 * <br/>
 * Exemplo de utilização desta classe: <br>
 * ReportManager rpm=new ReportManager();<br/>
 * <br/>
 * //Repita a rotina abaixo para quantos relatório deseje criar List
 * <Cliente> list=getListClientes();<br/>
 * String pathFileJasper=getFileJasper();<br/>
 * rpm.addReport(pathFileJasper,list);<br/>
 * <br/>
 * byte[] pdfBytes= rpm.exportToPDF();<br/>
 */
public class ReportManager {

    /** Atributo LOG. */
    private static final Logger LOG = Logger.getLogger(ReportManager.class.getName());

    /** Atributo CAMINHO_INVALIDO. */
    private static final String CAMINHO_INVALIDO = "O caminho informado para o relatório é inválido: ";
    /** Atributo RAWTYPES. */
    private static final String RAWTYPES = "rawtypes";

    /** Lista que armazena os relatórios processados. */
    private List<JasperPrint> list = null;

    /**
     * Armazena o relatório final, resultado da união da lista de relatórios.
     */
    private JasperPrint finalReport = null;

    /**
     * Constrói um ReportManager.
     */
    public ReportManager() {
        this.list = new ArrayList<>();
    }

    /**
     * Adiciona um relatório a lista de relatórios.<br/>
     * Recebe um arquivo .jasper com o layout do relatório desejado, juntamente
     * com uma lista de objetos (Beans) que <br/>
     * preencherá o arquivo .jasper. <br/>
     * Este beans deve conter atributos com os mesmos nomes usados na criação do
     * arquivo .jasper, encapsulados em gets/sets <br/>
     * <br/>
     *
     * @param pathReport
     *            : Caminho do arquivo .jasper que contêm o relatório desejado.
     * @param listBeans
     *            : Lista de objetos (Beans) que preencherá o relatório
     *            informado em pathReport.
     * @throws ReportInvalidPathException
     *             : Exception que ocorre quando pathReport for nulo, vazio ou o
     *             caminho for inválido.
     * @throws ReportErrorCreateDatasourceException
     *             : Exception que ocorre quando listBeans for nulo, vazio ou
     *             não pode ser processado para geração do relatório.
     */
    @SuppressWarnings(ReportManager.RAWTYPES)
    public void addReport(final String pathReport, final List listBeans) throws ReportInvalidPathException, ReportErrorCreateDatasourceException {
        this.addReport(pathReport, null, listBeans);
    }

    /**
     * Adiciona um relatório a lista de relatórios.<br/>
     * Recebe um arquivo .jasper com o layout do relatório desejado, juntamente
     * com uma lista de objetos (Beans) que <br/>
     * preencherá o arquivo .jasper. <br/>
     * Este beans deve conter atributos com os mesmos nomes usados na criação do
     * arquivo .jasper, encapsulados em gets/sets <br/>
     * <br/>
     *
     * @param pathReport
     *            : Caminho do arquivo .jasper que contêm o relatório desejado.
     * @param parameters
     *            : Lista de parametros a serem passados para o relatório.
     * @param listBeans
     *            : Lista de objetos (Beans) que preencherá o relatório
     *            informado em pathReport.
     * @throws ReportInvalidPathException
     *             : Exception que ocorre quando pathReport for nulo, vazio ou o
     *             caminho for inválido.
     * @throws ReportErrorCreateDatasourceException
     *             : Exception que ocorre quando listBeans for nulo, vazio ou
     *             não pode ser processado para geração do relatório.
     */
    @SuppressWarnings(ReportManager.RAWTYPES)
    public void addReport(final String pathReport, final Map parameters, final List listBeans)
            throws ReportInvalidPathException, ReportErrorCreateDatasourceException {
        if (pathReport == null || pathReport.isEmpty()) {
            throw new ReportInvalidPathException(ReportManager.CAMINHO_INVALIDO + pathReport);
        }

        final File file = new File(pathReport);

        if (!file.exists()) {
            throw new ReportInvalidPathException(ReportManager.CAMINHO_INVALIDO + pathReport);
        }

        if (listBeans == null || listBeans.isEmpty()) {
            throw new ReportErrorCreateDatasourceException("A fonte de dados para criação do relatório é inválida ou esta vazia.");
        }

        JRBeanCollectionDataSource jrBean = null;
        try {
            jrBean = new JRBeanCollectionDataSource(listBeans);
        } catch (final RuntimeException erro) {
            throw new ReportErrorCreateDatasourceException("Erro ao processar fonte de dados", erro);
        }

        JasperReport jasper = null;
        JasperPrint print = null;

        try {
            jasper = (JasperReport) JRLoader.loadObject(file);
            print = JasperFillManager.fillReport(jasper, parameters, jrBean);

        } catch (final JRException e) {
            ReportManager.LOG.fine(e.getMessage());
            throw new ReportErrorCreateDatasourceException("Erro ao criar relatório com os parâmetros informados.", e);
        }

        if (print == null) {
            throw new ReportErrorCreateDatasourceException("O relatório gerado para ser adicionado na lista é nulo. ");
        }

        this.list.add(print);
    }

    /**
     * <p>
     * Método responsável por adicionar relatorio.
     * <p>
     *
     * @param pathReport
     *            valor a ser atribuido
     * @param parameters
     *            valor a ser atribuido
     * @param bean
     *            valor a ser atribuido
     * @throws ReportErrorCreateDatasourceException
     *             lanca excecao
     * @throws ReportInvalidPathException
     *             lanca excecao
     */
    @SuppressWarnings(ReportManager.RAWTYPES)
    public void addReport(final String pathReport, final Map parameters, final Object[] bean)
            throws ReportErrorCreateDatasourceException, ReportInvalidPathException {
        if (pathReport == null || pathReport.isEmpty()) {
            throw new ReportInvalidPathException(ReportManager.CAMINHO_INVALIDO + pathReport);
        }

        final File file = new File(pathReport);

        if (!file.exists()) {
            throw new ReportInvalidPathException(ReportManager.CAMINHO_INVALIDO + pathReport);
        }

        if (bean == null || bean.length == 0) {
            throw new ReportErrorCreateDatasourceException("A fonte de dados para criação do relatório é inválida ou esta vazia.");
        }

        JRBeanArrayDataSource jrBean = null;
        try {
            jrBean = new JRBeanArrayDataSource(bean);
        } catch (final RuntimeException erro) {
            throw new ReportErrorCreateDatasourceException("Erro ao processar fonte de dados", erro);
        }

        JasperReport jasper = null;
        JasperPrint print = null;

        try {
            jasper = (JasperReport) JRLoader.loadObject(file);
            print = JasperFillManager.fillReport(jasper, parameters, jrBean);

        } catch (final JRException e) {
            ReportManager.LOG.fine(e.getMessage());
            throw new ReportErrorCreateDatasourceException("Erro ao criar relatório com os parâmetros informados", e);
        }

        if (print == null) {
            throw new ReportErrorCreateDatasourceException("O relatório gerado para ser adicionado na lista é nulo.");
        }

        this.list.add(print);
    }

    /**
     * Adiciona um relatório a lista de relatórios.<br/>
     * Recebe um arquivo .jasper com o layout do relatório desejado, juntamente
     * com uma lista de objetos (Beans) que <br/>
     * preencherá o arquivo .jasper. <br/>
     * Este beans deve conter atributos com os mesmos nomes usados na criação do
     * arquivo .jasper, encapsulados em gets/sets <br/>
     * <br/>
     *
     * @param pathReport
     *            : Caminho do arquivo .jasper que contêm o relatório desejado.
     * @param parametros
     *            valor a ser atribuido
     * @param con
     *            valor a ser atribuido
     * @throws ReportInvalidPathException
     *             : Exception que ocorre quando pathReport for nulo, vazio ou o
     *             caminho for inválido.
     * @throws ReportErrorCreateDatasourceException
     *             : Exception que ocorre quando listBeans for nulo, vazio ou
     *             não pode ser processado para geração do relatório.
     */
    @SuppressWarnings(ReportManager.RAWTYPES)
    public void addReport(final String pathReport, final Map parametros, final Connection con)
            throws ReportInvalidPathException, ReportErrorCreateDatasourceException {
        if (pathReport == null || pathReport.isEmpty()) {
            throw new ReportInvalidPathException(ReportManager.CAMINHO_INVALIDO + pathReport);
        }

        final File file = new File(pathReport);

        if (!file.exists()) {
            throw new ReportInvalidPathException(ReportManager.CAMINHO_INVALIDO + pathReport);
        }

        JasperReport jasper = null;
        JasperPrint print = null;

        try {
            jasper = (JasperReport) JRLoader.loadObject(file);
            print = JasperFillManager.fillReport(jasper, parametros, con);

        } catch (final JRException e) {
            ReportManager.LOG.fine(e.getMessage()); // coloquei isso para ajudar
                                                    // a ver
            // os erros da relação de
            // parametros
            // java/ireport
            throw new ReportErrorCreateDatasourceException("Erro ao criar relatório com os parâmetros informados", e);
        }

        if (print == null) {
            throw new ReportErrorCreateDatasourceException("O relatório gerado para ser adicionado na lista é nulo.");
        }

        this.list.add(print);
    }

    /**
     * Varre a lista interna de relatórios, realizando a união dos mesmos.
     *
     * @throws ReportFinalNullException
     *             : Ocorre quando
     */
    private void mergeReports() throws ReportFinalNullException {
        if (this.list == null || this.list.isEmpty()) {
            throw new ReportFinalNullException(
                    "não é possível realizar a união dos relatórios da lista. A lista de relatórios é nula ou esta vazia.");
        }

        this.finalReport = this.list.get(0);

        for (int i = 1; i < this.list.size(); i++) {
            final List<JRPrintPage> listP = this.list.get(i).getPages();

            for (int j = 0; j < listP.size(); j++) {
                this.finalReport.addPage(listP.get(j));
            }
        }
    }

    /**
     * @return array de bytes contendo o PDF exportado.
     * @throws ReportFinalNullException
     *             : ocorre quando o PDF não pode ser gerado
     */
    public byte[] exportToPDF() throws ReportFinalNullException {
        this.mergeReports();
        this.correctPageNumbers(this.finalReport);

        if (this.finalReport == null || this.finalReport.getPages().isEmpty()) {
            throw new ReportFinalNullException("O relatório final é nulo ou vazio, ocorrreu erro na união da lista de relatórios.");
        }

        try {
            final byte[] bytes = JasperExportManager.exportReportToPdf(this.finalReport);

            if (bytes == null || bytes.length == 0) {
                throw new ReportFinalNullException("Erro na exportação do relatório para o formato PDF. O conteúdo exportado é vazio.");
            }

            return bytes;
        } catch (final JRException e) {
            throw new ReportFinalNullException("Erro na exportação do relatório para o formato PDF.", e);
        }
    }

    /**
     * @return array de bytes contendo o xls exportado.
     * @throws ReportFinalNullException
     *             : ocorre quando o xls não pode ser gerado
     */
    public byte[] exportToXLS() throws ReportFinalNullException {
        this.mergeReports();
        this.correctPageNumbers(this.finalReport);

        if (this.finalReport == null || this.finalReport.getPages().isEmpty()) {
            throw new ReportFinalNullException("O relatório final é nulo ou vazio, ocorrreu erro na união da lista de relatórios.");
        }

        try {
            final ByteArrayOutputStream output = new ByteArrayOutputStream();
            final JRXlsExporter xls = new JRXlsExporter();

            xls.setParameter(JRExporterParameter.JASPER_PRINT, this.finalReport);
            xls.setParameter(JRExporterParameter.OUTPUT_STREAM, output);
            xls.setParameter(JRXlsAbstractExporterParameter.IS_DETECT_CELL_TYPE, Boolean.TRUE);
            xls.setParameter(JRXlsAbstractExporterParameter.IS_REMOVE_EMPTY_SPACE_BETWEEN_ROWS, Boolean.TRUE);
            // xls.setParameter(JRXlsExporterParameter.IS_ONE_PAGE_PER_SHEET,
            // Boolean.TRUE);
            xls.setParameter(JRXlsAbstractExporterParameter.MAXIMUM_ROWS_PER_SHEET, Integer.decode("65000"));
            xls.setParameter(JRXlsAbstractExporterParameter.IS_IMAGE_BORDER_FIX_ENABLED, Boolean.TRUE);
            xls.setParameter(JRExporterParameter.IGNORE_PAGE_MARGINS, Boolean.TRUE);
            xls.setParameter(JRXlsAbstractExporterParameter.IS_REMOVE_EMPTY_SPACE_BETWEEN_COLUMNS, Boolean.TRUE);
            xls.setParameter(JRXlsAbstractExporterParameter.IS_WHITE_PAGE_BACKGROUND, Boolean.FALSE);

            xls.exportReport();
            final byte[] bytes = output.toByteArray();

            if (bytes == null || bytes.length == 0) {
                throw new ReportFinalNullException("Erro na exportação do relatório para o formato XSL. O conteúdo exportado é vazio.");
            }

            return bytes;
	} catch (final JRException | UnsupportedOperationException | ClassCastException | IllegalArgumentException e) {
            throw new ReportFinalNullException("Erro na exportação do relatório para o formato XSL.", e);
        }

    }

    /**
     * Faz a atualização das páginas do relatório, deixando as páginas na
     * sequencia correta, pois se <br/>
     * este ajuste não fosse feito, para cada relatório da lista, a contagem de
     * páginas seria reiniciada.
     *
     * @param jasperPrintMain
     *            : representa o relatório final, resultado da união da lista de
     *            relatórios.
     */
    @SuppressWarnings({ "unchecked", ReportManager.RAWTYPES })
    private void correctPageNumbers(final JasperPrint jasperPrintMain) {

        final List<JRPrintPage> listPages = jasperPrintMain.getPages();

        int currentPageIndex = 1;
        for (final JRPrintPage currentPage : listPages) {
            final List listElements = currentPage.getElements();

            for (final Object element : listElements) {
                if (element instanceof JRTemplatePrintText) {
                    final JRTemplatePrintText templatePrintText = (JRTemplatePrintText) element;

                    // set currrent page
                    if (templatePrintText.getKey() != null && "pageNumber".equalsIgnoreCase(templatePrintText.getKey())) {
                        templatePrintText.setText("página - " + currentPageIndex);
                    }
                }
            }

            currentPageIndex++;
        }
    }
}
