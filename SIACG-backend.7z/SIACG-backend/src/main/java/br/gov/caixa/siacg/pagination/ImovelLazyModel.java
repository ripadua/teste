package br.gov.caixa.siacg.pagination;

import java.util.List;
import java.util.Map;

import javax.ejb.EJB;
import javax.enterprise.context.SessionScoped;
import javax.inject.Named;

import org.primefaces.model.SortOrder;

import br.gov.caixa.pedesgo.arquitetura.paginacao.Paginacao;
import br.gov.caixa.pedesgo.arquitetura.paginacao.PaginacaoDemanda;
import br.gov.caixa.siacg.model.domain.Imovel;
import br.gov.caixa.siacg.model.vo.FiltroImovelVO;
import br.gov.caixa.siacg.service.ImovelService;

/**
 * <p>
 * ImovelLazyModel.
 * </p>
 * <p>
 * Descrição: Classe de paginação sob demanda do contrato
 * </p>
 * <br>
 * <b>Empresa:</b> Cef - Caixa Econômica Federal
 *
 * @author Waltenes Junior
 * @version 1.0
 */
@Named
@SessionScoped
public class ImovelLazyModel extends Paginacao<Imovel> {

    private static final long serialVersionUID = -6038965454195521432L;

    /** Atributo NOME_MANAGED_BEAN. */
    public static final String NOME_MANAGED_BEAN = "imovelLazyModel";
    /** Atributo EL_MANAGED_BEAN. */
    public static final String EL_MANAGED_BEAN = "#{imovelLazyModel}";

    /** Atributo service. */
    @EJB
    private transient ImovelService service;

    /** Atributo filtro. */
    private transient FiltroImovelVO filtro;

    /**
     * @see br.gov.caixa.pedesgo.arquitetura.integracao.componente.paginacao.Paginacao#getServico()
     */
    @Override
    @SuppressWarnings("unchecked")
    public ImovelService getServico() {
	return this.service;
    }

    /**
     * @see br.gov.caixa.pedesgo.arquitetura.integracao.componente.paginacao.Paginacao#load(int,
     *      int, java.lang.String, org.primefaces.model.SortOrder,
     *      java.util.Map)
     */
    @Override
    public List<Imovel> load(final int inicio, final int fim, final String campoOrdenacao, final SortOrder ordenacao,
	    final Map<String, String> parametros) {

	final PaginacaoDemanda<Imovel> resultado = this.service.listaImovelPaginado(this.filtro, inicio, fim);
	super.setWrappedData(resultado.getLista());
	super.setRowCount(resultado.getQuantidadeRegistros() == 0 ? resultado.getLista().size() : resultado.getQuantidadeRegistros());

	return resultado.getLista();
    }

    /**
     * <p>
     * Método responsável por limpar filtro da consulta.
     * <p>
     *
     * @author narcieliton.lopes
     */
    public void limparFiltro() {
	this.filtro = new FiltroImovelVO();
    }

    /**
     * Retorna o valor do atributo filtro.
     *
     * @return filtro
     */
    public FiltroImovelVO getFiltro() {
	if (this.filtro == null) {
	    this.filtro = new FiltroImovelVO();
	}
	return this.filtro;
    }

    /**
     * Define o valor do atributo filtro.
     *
     * @param filtro
     *            valor a ser atribuído
     */
    public void setFiltro(final FiltroImovelVO filtro) {
	this.filtro = filtro;
    }
}
