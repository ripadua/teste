/**
 * Copyright (c) 2018 Caixa Econômica Federal. Todos os direitos
 * reservados.
 *
 * Caixa Econômica Federal - SIACG
 *
 * Este software foi desenvolvido sob demanda da CAIXA e está
 * protegido por leis de direitos autorais e tratados internacionais. As
 * condições de cópia e utilização total ou partes dependem de autorização da
 * empresa. Cópias não são permitidas sem expressa autorização. Não pode ser
 * comercializado ou utilizado para propósitos particulares.
 *
 * Uso exclusivo da Caixa Econômica Federal. A reprodução ou distribuição não
 * autorizada deste programa ou de parte dele, resultará em punições civis e
 * criminais e os infratores incorrem em sanções previstas na legislação em
 * vigor.
 *
 * Histórico do TFS:
 *
 * LastChangedRevision: $Revision$
 * LastChangedBy: $Author$
 * LastChangedDate: $Date$
 *
 * HeadURL: $HeadURL$
 *
 */
package br.gov.caixa.siacg.strategy.impl.titulo;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.collections.CollectionUtils;
import org.jboss.ejb3.annotation.TransactionTimeout;

import br.gov.caixa.pedesgo.arquitetura.to.FeriadoTO;
import br.gov.caixa.pedesgo.arquitetura.util.UtilData;
import br.gov.caixa.pedesgo.arquitetura.util.UtilFeriado;
import br.gov.caixa.siacg.comparator.TituloComparator;
import br.gov.caixa.siacg.comum.to.ContratoCalculoTO;
import br.gov.caixa.siacg.dao.SacadoExcepcionadoDAO;
import br.gov.caixa.siacg.dao.TituloDAO;
import br.gov.caixa.siacg.model.domain.Cedente;
import br.gov.caixa.siacg.model.domain.Contrato;
import br.gov.caixa.siacg.model.domain.DuplicataExcepcionada;
import br.gov.caixa.siacg.model.domain.Sacado;
import br.gov.caixa.siacg.model.domain.SacadoExcepcionado;
import br.gov.caixa.siacg.model.domain.Titulo;
import br.gov.caixa.siacg.model.enums.UtilizacaoTituloEnum;

/**
 * <p>
 * ConjuntoTituloAVencer
 * </p>
 *
 * <p>
 * Descrição: Classe que representa um conjunto de titulos a vencer
 * </p>
 *
 * <br>
 * <b>Empresa:</b> Cef - Caixa Econômica Federal
 *
 *
 * @author p541915
 *
 * @version 1.0
 */
public class ConjuntoTituloAVencer extends ConjuntoTitulo {

    /** Atributo tituloDao. */
    private TituloDAO tituloDao;

    /** Atributo sacadoExcepcionadoDao. */
    private SacadoExcepcionadoDAO sacadoExcepcionadoDao;

    /** Atributo mapaDuplicatasSacado. */
    private Map<Integer, SacadoValorQuantidade> mapaDuplicatasSacado = new HashMap<>();

    /** Atributo vrTituloSacadoNaoAceito. */
    private BigDecimal vrTituloSacadoNaoAceito = BigDecimal.ZERO;

    /** Atributo qtdTituloSacadoNaoAceito. */
    private Integer qtdTituloSacadoNaoAceito = 0;

    /** Atributo vrTituloForaPrazoMaximoPermitido. */
    private BigDecimal vrTituloForaPrazoMaximoPermitido = BigDecimal.ZERO;

    /** Atributo qtdTituloForaPrazoMaximoPermitido. */
    private Integer qtdTituloForaPrazoMaximoPermitido = 0;

    /** Atributo vrTituloForaValorMaximoPermitido. */
    private BigDecimal vrTituloForaValorMaximoPermitido = BigDecimal.ZERO;

    /** Atributo qtdTituloForaValorMaximoPermitido. */
    private Integer qtdTituloForaValorMaximoPermitido = 0;

    /** Atributo vrTituloForaPercentualMaximoConcentracao. */
    private BigDecimal vrTituloForaPercentualMaximoConcentracao = BigDecimal.ZERO;

    /** Atributo qtdTituloForaPercentualMaximoConcentracao. */
    private Integer qtdTituloForaPercentualMaximoConcentracao = 0;

    /** Atributo vrTituloForaParametros. */
    private BigDecimal vrTituloForaParametros = BigDecimal.ZERO;

    /** Atributo listaTituloForaParametros. */
    private Collection<Titulo> listaTituloForaParametros = new ArrayList<>();

    /** Atributo listaTituloASalvar. */
    private Collection<Titulo> listaTituloASalvar = new ArrayList<>();

    /** Atributo vrTituloDentroParametros. */
    private BigDecimal vrTituloDentroParametros = BigDecimal.ZERO;

    /** Atributo listaTituloDentroParametros. */
    private Collection<Titulo> listaTituloDentroParametros = new ArrayList<>();

    /** Atributo parametros. */
    private ParametrosCalculoTitulo parametros;

    /**
     * Responsável pela criação de novas instâncias desta classe.
     *
     * @param parametros
     * @param tituloDao
     * @param sacadoExcepcionadoDao
     *
     */
    public ConjuntoTituloAVencer(final ParametrosCalculoTitulo parametros, final TituloDAO tituloDao,
	    final SacadoExcepcionadoDAO sacadoExcepcionadoDao) {
	this.parametros = parametros;
	this.tituloDao = tituloDao;
	this.sacadoExcepcionadoDao = sacadoExcepcionadoDao;
    }

    /**
     * <p>
     * Método responsável por realizar os calculos de titulos a vencer
     * </p>
     * .
     *
     * @author p541915
     *
     */
    public void calcular() {
	for (Titulo titulo : getTitulos()) {
	    SacadoValorQuantidade sacado = mapaDuplicatasSacado.containsKey(titulo.getIdentificadorSacado())
		    ? mapaDuplicatasSacado.get(titulo.getIdentificadorSacado())
		    : new SacadoValorQuantidade();
		    
	    boolean isSomarTituloForaParametros = Boolean.FALSE;
	    
	    if (this.verificarTituloSacadoNaoAceito(titulo)) {
		// Sacados não aceitos
		vrTituloSacadoNaoAceito = vrTituloSacadoNaoAceito.add(titulo.getVrTitulo());
		isSomarTituloForaParametros = Boolean.TRUE;
		qtdTituloSacadoNaoAceito++;

	    } else if (this.verificarTituloForaPrazoMaximoPermitido(parametros.getListaFeriado(), parametros.getContrato(), titulo,
		    parametros.getPrazoMaximo(), parametros.getUfContrato())) {
		// Duplicata fora do prazo máximo
		vrTituloForaPrazoMaximoPermitido = vrTituloForaPrazoMaximoPermitido.add(titulo.getVrTitulo());
		isSomarTituloForaParametros = Boolean.TRUE;
		qtdTituloForaPrazoMaximoPermitido++;

	    } else if (this.verificarTituloForaValorMaximoPermitido(titulo, parametros.getValorMaximo())) {
		// Duplicata fora do valor máximo permitido
		vrTituloForaValorMaximoPermitido = vrTituloForaValorMaximoPermitido.add(titulo.getVrTitulo());
		isSomarTituloForaParametros = Boolean.TRUE;
		qtdTituloForaValorMaximoPermitido++;

	    } else if (this.verificarTituloForaPercentualMaximoConcentracao(sacado, titulo.getVrTitulo())) {
		// Duplicata fora do percentual
		vrTituloForaPercentualMaximoConcentracao = vrTituloForaPercentualMaximoConcentracao.add(titulo.getVrTitulo());
		isSomarTituloForaParametros = Boolean.TRUE;
		qtdTituloForaPercentualMaximoConcentracao++;
	    }

	    mapaDuplicatasSacado.put(titulo.getIdentificadorSacado(), sacado);

	    if (isSomarTituloForaParametros) {
		vrTituloForaParametros = vrTituloForaParametros.add(titulo.getVrTitulo());
		listaTituloForaParametros.add(titulo);
	    } else {
		if (!parametros.getContrato().isPreAnalise()
			&& parametros.getRelatorio().getValorApurado().compareTo(parametros.getVrEsperado()) < 0) {
		    titulo.setContrato(new Contrato(parametros.getContrato().getNuContrato()));
		    titulo.setIcUtilizacaoTituloEnum(UtilizacaoTituloEnum.GN);
		    listaTituloASalvar.add(titulo);
		    parametros.getRelatorio().setValorApurado(parametros.getRelatorio().getValorApurado().add(titulo.getVrTitulo()));
		    sacado.setValor(sacado.getValor().add(titulo.getVrTitulo()));
		    sacado.incrementarQuantidade();
		}
		listaTituloDentroParametros.add(titulo);
		vrTituloDentroParametros = vrTituloDentroParametros.add(titulo.getVrTitulo());
	    }
	    }
	
    }

    /**
     * <p>
     * Método responsável por verifica se o titulo é um sacado não aceito.
     * <p>
     *
     * @param titulo
     *            valor a ser atribuido
     * @return boolean
     * @author Charles Junior, guilherme.santos
     */
    public boolean verificarTituloSacadoNaoAceito(final Titulo titulo) {
	final Sacado sacadoTitulo = titulo.getNuSacado();

	if (sacadoTitulo != null && sacadoTitulo.getIcNaoAceito()
		&& (sacadoTitulo.isAbrangenciaTodaCaixa() || this.verificarAbrangenciaCendenteTitulo(sacadoTitulo, titulo))) {
	    return titulo.getIcNaoAceito().equals(true);
	}

	return false;
    }

    /**
     * <p>
     * Método responsável por verificar se a abrangencia de sacado não aceito é
     * para o cedente do titulo informado.
     * <p>
     *
     * @param sacado
     *            valor a ser atribuido
     * @param titulo
     *            valor a ser atribuido
     * @return boolean
     * @author guilherme.santos
     */
    private boolean verificarAbrangenciaCendenteTitulo(final Sacado sacado, final Titulo titulo) {
	if (sacado.getListaCedenteNaoAceito() != null) {
	    for (final Cedente cedente : sacado.getListaCedenteNaoAceito()) {
		if (cedente.getNuCedente().equals(titulo.getIdentificadorSacado())) {
		    return Boolean.TRUE;
		}
	    }
	}

	return Boolean.FALSE;
    }

    /**
     * Verifica se o titulo está fora do prazo máximo.
     *
     * @param listaFeriado
     *            valor a ser atribuido
     * @param contrato
     *            valor a ser atribuido
     * @param titulo
     *            valor a ser atribuido
     * @param prazoMaximo
     *            valor a ser atribuido
     * @param ufContrato
     *            valor a ser atribuido
     * @return boolean
     * @author Ricardo Crispim
     */
    private boolean verificarTituloForaPrazoMaximoPermitido(final Collection<FeriadoTO> listaFeriado, final ContratoCalculoTO contrato, final Titulo titulo,
	    final Integer prazoMaximo, final String ufContrato) {
	Date dataVencimentoUtil = titulo.getDtVencimentoTitulo();

	if (CollectionUtils.isNotEmpty(listaFeriado)) {
	    dataVencimentoUtil = UtilFeriado.proximoDiaUtil(listaFeriado, contrato.getNuUnidade(), contrato.getNuNatural(), ufContrato,
		    UtilData.converterDataSemHoras(dataVencimentoUtil));
	}

	final long diferenca = UtilData.diferencaEmDiasEntreDatas(new Date(), dataVencimentoUtil);
	return diferenca > prazoMaximo;
    }

    /**
     * Verifica se o titulo está fora do prazo máximo.
     *
     * @param titulo
     *            valor a ser atribuido
     * @param valorMaximo
     *            valor a ser atribuido
     * @return boolean
     * @author Ricardo Crispim
     */
    private boolean verificarTituloForaValorMaximoPermitido(final Titulo titulo, final BigDecimal valorMaximo) {
	return titulo.getVrTitulo().compareTo(valorMaximo) > 0;
    }
    
    /**
     * <p>Método responsável por verificar se o contrato NÃO é de Pré Análise e se o titulo está fora do percentual máximo de concentração</p>.
     *
     * @param sacado
     * @return TRUE caso esteja fora do percentual máximo de concentração, FALSE caso contrário.
     */
    private boolean verificarTituloForaPercentualMaximoConcentracao(SacadoValorQuantidade sacado, BigDecimal valorTitulo) {
	return !parametros.getContrato().isPreAnalise() && sacado.getValor().add(valorTitulo).compareTo(parametros.getValorTotalPermitido()) > 0;
    }

    /**
     * Retorna o valor do atributo listaTituloASalvar.
     *
     * @return valor
     */
    public Collection<Titulo> getListaTituloASalvar() {
	return this.listaTituloASalvar;
    }

    /**
     * Retorna o valor do atributo listaTituloForaParametros.
     *
     * @return valor
     */
    public Collection<Titulo> getListaTituloForaParametros() {
	return this.listaTituloForaParametros;
    }

    /**
     * Retorna o valor do atributo vrTituloForaParametros.
     *
     * @return valor
     */
    public BigDecimal getVrTituloForaParametros() {
	return this.vrTituloForaParametros;
    }

    /**
     * <p>
     * Retorna o valor do atributo qtdTituloForaPrazoMaximoPermitido
     * </p>
     * .
     *
     * @return qtdTituloForaPrazoMaximoPermitido
     */
    public Integer getQtdTituloForaPrazoMaximoPermitido() {
	return this.qtdTituloForaPrazoMaximoPermitido;
    }

    /**
     * <p>
     * Retorna o valor do atributo qtdTituloSacadoNaoAceito
     * </p>
     * .
     *
     * @return qtdTituloSacadoNaoAceito
     */
    public Integer getQtdTituloSacadoNaoAceito() {
	return this.qtdTituloSacadoNaoAceito;
    }

    /**
     * <p>
     * Retorna o valor do atributo qtdTituloForaValorMaximoPermitido
     * </p>
     * .
     *
     * @return qtdTituloForaValorMaximoPermitido
     */
    public Integer getQtdTituloForaValorMaximoPermitido() {
	return this.qtdTituloForaValorMaximoPermitido;
    }

    /**
     * <p>
     * Retorna o valor do atributo qtdTituloForaPercentualMaximoConcentracao
     * </p>
     * .
     *
     * @return qtdTituloForaPercentualMaximoConcentracao
     */
    public Integer getQtdTituloForaPercentualMaximoConcentracao() {
	return this.qtdTituloForaPercentualMaximoConcentracao;
    }

    /**
     * <p>
     * Retorna o valor do atributo vrTituloSacadoNaoAceito
     * </p>
     * .
     *
     * @return vrTituloSacadoNaoAceito
     */
    public BigDecimal getVrTituloSacadoNaoAceito() {
	return this.vrTituloSacadoNaoAceito;
    }

    /**
     * <p>
     * Retorna o valor do atributo vrTituloForaPrazoMaximoPermitido
     * </p>
     * .
     *
     * @return vrTituloForaPrazoMaximoPermitido
     */
    public BigDecimal getVrTituloForaPrazoMaximoPermitido() {
	return this.vrTituloForaPrazoMaximoPermitido;
    }

    /**
     * <p>
     * Retorna o valor do atributo vrTituloForaValorMaximoPermitido
     * </p>
     * .
     *
     * @return vrTituloForaValorMaximoPermitido
     */
    public BigDecimal getVrTituloForaValorMaximoPermitido() {
	return this.vrTituloForaValorMaximoPermitido;
    }

    /**
     * <p>
     * Retorna o valor do atributo vrTituloForaPercentualMaximoConcentracao
     * </p>
     * .
     *
     * @return vrTituloForaPercentualMaximoConcentracao
     */
    public BigDecimal getVrTituloForaPercentualMaximoConcentracao() {
	return this.vrTituloForaPercentualMaximoConcentracao;
    }

    /**
     * <p>
     * Método responsável por obter o valor liquido da carteira
     * </p>
     * .
     *
     * @author p541915
     *
     * @return
     */
    public BigDecimal getVrLiquidoCarteira() {
	BigDecimal vrLiquidoCarteira = this.getVrTotal().subtract(vrTituloForaParametros);

	// Calcula o valor das Duplicatas Excepcionadas
	vrLiquidoCarteira = this.calcularDuplicataExcepcionada(vrLiquidoCarteira);

	vrLiquidoCarteira = this.calcularSacadoExcepcionado(vrLiquidoCarteira);

	return vrLiquidoCarteira;
    }

    /**
     * 
     * <p>
     * Método responsável por calcular o valor de duplicatas excepcionadas.
     * <p>
     *
     * @author guilherme.santos
     *
     * @param valorLiquidoCarteira
     *            valor a ser atribuido
     * @return BigDecimal
     */
    private BigDecimal calcularDuplicataExcepcionada(BigDecimal valorLiquidoCarteira) {

	BigDecimal valorDuplicataExcepcionada = BigDecimal.ZERO;

	if (valorLiquidoCarteira.compareTo(this.parametros.getVrEsperado()) < 0) {

	    final List<Titulo> listaTitulosSacadoExcepcionado = this.consultarDuplicataExcepcionada(this.listaTituloForaParametros,
		    this.parametros.getListaDuplicataExcepcionada(), this.parametros.getVrEsperado(),
		    this.parametros.getRelatorio().getValorApurado());

	    this.salvarTitulos(listaTitulosSacadoExcepcionado, this.parametros.getContrato(), UtilizacaoTituloEnum.DE);

	    valorDuplicataExcepcionada = this.somarTitulo(listaTitulosSacadoExcepcionado, valorDuplicataExcepcionada);

	    // Atualiza Total líquido da carteira
	    valorLiquidoCarteira = valorLiquidoCarteira.add(valorDuplicataExcepcionada);
	    this.parametros.getRelatorio().getAnaliseContrato().setValorDuplicatasExcepcionadas(
		    this.parametros.getRelatorio().getAnaliseContrato().getValorDuplicatasExcepcionadas().add(valorDuplicataExcepcionada));
	    this.parametros.getRelatorio().setValorApurado(this.parametros.getRelatorio().getValorApurado().add(valorDuplicataExcepcionada));
	}

	return valorLiquidoCarteira;
    }

    /**
     * <p>
     * Método responsável por consultar titulos excepcionados dentro os titulos
     * fora de parametros.
     * <p>
     *
     * @param listaTitulosForaParametro
     *            valor a ser atribuido
     * @param listaDuplicataExcepcionada
     *            valor a ser atribuido
     * @param vrEsperado
     *            valor a ser atribuido
     * @param vrJaApurado
     *            valor a ser atribuido
     * @return List<Titulo>
     * @author guilherme.santos
     */
    private List<Titulo> consultarDuplicataExcepcionada(final Collection<Titulo> colecaoTitulosForaParametro,
	    final Collection<DuplicataExcepcionada> listaDuplicataExcepcionada, final BigDecimal vrEsperado, BigDecimal vrJaApurado) {
	final List<Titulo> listaTitulosExcepcionadosPorDuplicataExcepcionada = new ArrayList<>();
	boolean vrApuradoSuficiente = false;
	BigDecimal vrExcepcionado = BigDecimal.ZERO;

	List<Titulo> listaTitulosForaParametro = new ArrayList<>(colecaoTitulosForaParametro);

	Collections.sort(listaTitulosForaParametro, new TituloComparator());

	for (final Titulo titulo : listaTitulosForaParametro) {

	    for (final DuplicataExcepcionada duplicataExcepcionada : listaDuplicataExcepcionada) {
		if (titulo.getCoNossoNumero() != null && titulo.getCoNossoNumero().equals(duplicataExcepcionada.getCoNossoNumero())) {
		    if (vrEsperado.compareTo(vrJaApurado) > 0) {
			vrExcepcionado = vrExcepcionado.add(titulo.getVrTitulo());
			listaTitulosExcepcionadosPorDuplicataExcepcionada.add(titulo);
			vrJaApurado = vrJaApurado.add(titulo.getVrTitulo());
		    } else {
			vrApuradoSuficiente = true;
		    }
		    break;
		}
	    }

	    if (vrApuradoSuficiente) {
		break;
	    }
	}
	// Remove da lista de titulos fora do parametros, os titulos
	// excepcionados
	listaTitulosForaParametro.removeAll(listaTitulosExcepcionadosPorDuplicataExcepcionada);

	return listaTitulosExcepcionadosPorDuplicataExcepcionada;
    }

    /**
     * <p>
     * Método responsável por somar os valores dos titulos informados.
     * <p>
     *
     * @param listaTitulo
     *            valor a ser atribuido
     * @param valorSomatoria
     *            valor a ser atribuido
     * @return BigDecimal
     * @author guilherme.santos
     */
    private BigDecimal somarTitulo(final Collection<Titulo> listaTitulo, BigDecimal valorSomatoria) {

	for (final Titulo titulo : listaTitulo) {
	    valorSomatoria = valorSomatoria.add(titulo.getVrTitulo());
	}

	return valorSomatoria;
    }

    /**
     * <p>
     * Método responsável por salvar lista de titulos.
     * <p>
     *
     * @param listaTituloASalvar
     *            valor a ser atribuido
     * @param contrato
     *            valor a ser atribuido
     * @param icUtilizacaoEnum
     *            valor a ser atribuido
     * @author guilherme.santos
     * @param contrato
     */
    @TransactionTimeout(7200)
    private void salvarTitulos(final Collection<Titulo> listaTituloASalvar, final ContratoCalculoTO contrato, final UtilizacaoTituloEnum icUtilizacaoEnum) {
	if (!listaTituloASalvar.isEmpty()) {
	    final List<Integer> listaNuTitulos = new ArrayList<>();

	    for (final Titulo titulo : listaTituloASalvar) {
		listaNuTitulos.add(titulo.getNuTitulo());
	    }

	    if (!contrato.isPreAnalise()) {
		this.tituloDao.salvarContratoNaListaTitulo(listaNuTitulos, contrato, icUtilizacaoEnum);
	    }
	}
    }

    /**
     * <p>
     * Método responsável por calcular o valor de sacado excepcionado
     * </p>
     * .
     *
     * @author p541915
     *
     * @param valorLiquidoCarteira
     * @return valorLiquidoCarteira
     */
    private BigDecimal calcularSacadoExcepcionado(BigDecimal valorLiquidoCarteira) {

	BigDecimal valorSacadoExcepcionado = BigDecimal.ZERO;

	if (valorLiquidoCarteira.compareTo(this.parametros.getVrEsperado()) < 0) {
	    final List<SacadoExcepcionado> listaSacadoExcepcionado = this.sacadoExcepcionadoDao.listarSacadoExcepcionadoPorGarantia(this.parametros.getGarantiaContrato());
	       
	    final List<Titulo> listaTitulosSacadoExcepcionado = 
	    		this.consultarTitulosSacadoExcepcionado(this.parametros.getListaFeriado(),
		    new ArrayList<>(this.listaTituloForaParametros), listaSacadoExcepcionado, this.parametros.getContrato(),
		    this.parametros.getVrEsperado(), this.parametros.getRelatorio().getValorApurado(), this.parametros.getUfContrato());

	    this.salvarTitulos(listaTitulosSacadoExcepcionado, this.parametros.getContrato(), UtilizacaoTituloEnum.SE);

	    valorSacadoExcepcionado = this.somarTitulo(listaTitulosSacadoExcepcionado, valorSacadoExcepcionado);

	    // Atualiza Total líquido da carteira
	    valorLiquidoCarteira = valorLiquidoCarteira.add(valorSacadoExcepcionado);
	    this.parametros.getRelatorio().getAnaliseContrato().setVrSacadoExcepcionado(valorSacadoExcepcionado);
	    this.parametros.getRelatorio().setValorApurado(this.parametros.getRelatorio().getValorApurado().add(valorSacadoExcepcionado));
	}

	return valorLiquidoCarteira;
    }

    /**
     * <p>
     * Método responsável por consultar {@link Titulo}'s que podem ser
     * utilizados por sacados excepcionados.
     * <p>
     *
     * @param listaFeriado
     *            valor a ser atribuido
     * @param listaTitulosForaParametro
     *            valor a ser atribuido
     * @param listaSacadosExcepcionado
     *            valor a ser atribuido
     * @param contrato
     *            valor a ser atribuido
     * @param vrEsperado
     *            valor a ser atribuido
     * @param vrJaApurado
     *            valor a ser atribuido
     * @param ufContrato
     *            valor a ser atribuido
     * @return List<Titulo>
     * @author guilherme.santos
     */
	private List<Titulo> consultarTitulosSacadoExcepcionado(final Collection<FeriadoTO> listaFeriado,
			final List<Titulo> listaTitulosForaParametro, final Collection<SacadoExcepcionado> listaSacadosExcepcionado,
			final ContratoCalculoTO contrato, final BigDecimal vrEsperado, BigDecimal vrJaApurado, final String ufContrato) {
		final List<Titulo> listaTitulosExcepcionadoPorSacado = new ArrayList<>();
		final Map<Integer, BigDecimal> mapPercentualConcentracao = new HashMap<>();
		BigDecimal vrMaximoConcentracaoPermitido = BigDecimal.ZERO;
		BigDecimal vrExcepcionado = BigDecimal.ZERO;

		Collections.sort(listaTitulosForaParametro, new TituloComparator());

		for (final Titulo titulo : listaTitulosForaParametro) {
			final SacadoExcepcionado sacadoExcepcionado = this.consultarSacadoExcepcionado(listaSacadosExcepcionado,
					titulo);
			BigDecimal valorConcentracaoSacado = BigDecimal.ZERO;
			final Integer nuSacado = titulo.getIdentificadorSacado();

			if (sacadoExcepcionado == null) {
				continue;
			}

			if (this.isNumeroValido(sacadoExcepcionado.getPercentualMaximo())) {

				vrMaximoConcentracaoPermitido = this.calcularValorMaximoSobrePercentualPermitido(
						sacadoExcepcionado.getPercentualMaximo(), vrEsperado);

				if (mapPercentualConcentracao.containsKey(titulo.getIdentificadorSacado())) {
					valorConcentracaoSacado = mapPercentualConcentracao.get(nuSacado);
				}
				valorConcentracaoSacado = valorConcentracaoSacado.add(titulo.getVrTitulo());
				mapPercentualConcentracao.put(nuSacado, titulo.getVrTitulo());
			}

			if (titulo.getIcNaoAceito() != null && titulo.getIcNaoAceito()) {
				continue;
			} else if (sacadoExcepcionado.getPrazoMaximoTitulo() != null
					&& sacadoExcepcionado.getPrazoMaximoTitulo() > 0 && this.verificarTituloForaPrazoMaximoPermitido(
							listaFeriado, contrato, titulo, sacadoExcepcionado.getPrazoMaximoTitulo(), ufContrato)) {
				continue;
			} else if (this.isNumeroValido(sacadoExcepcionado.getVrMaximoTitulo())
					&& this.verificarTituloForaValorMaximoPermitido(titulo, sacadoExcepcionado.getVrMaximoTitulo())) {
				continue;
			} else if (this.isNumeroValido(vrMaximoConcentracaoPermitido)
					&& valorConcentracaoSacado.compareTo(vrMaximoConcentracaoPermitido) > 0) {
				continue;
			} else if (titulo.getIcInstrucaoProtesto() != null && titulo.getIcInstrucaoProtesto()
					&& sacadoExcepcionado.isIcInstrucaoProtesto()
					&& titulo.getIcInstrucaoProtesto().equals(sacadoExcepcionado.isIcInstrucaoProtesto())) {
				continue;
			} else {
				if (vrEsperado.compareTo(vrJaApurado) > 0) {
					vrExcepcionado = vrExcepcionado.add(titulo.getVrTitulo());
					listaTitulosExcepcionadoPorSacado.add(titulo);
					vrJaApurado = vrJaApurado.add(titulo.getVrTitulo());
				} else {
					break;
				}
			}
		}
		return listaTitulosExcepcionadoPorSacado;
	}

    /**
     * <p>
     * Método responsável por consultar o {@link SacadoExcepcionado} do
     * {@link Titulo} informado.
     * <p>
     *
     * @param listaSacadosExcepcionado
     *            valor a ser atribuido
     * @param titulo
     *            valor a ser atribuido
     * @return SacadoExcepcionado
     * @author guilherme.santos
     */
    private SacadoExcepcionado consultarSacadoExcepcionado(final Collection<SacadoExcepcionado> listaSacadosExcepcionado, final Titulo titulo) {
	for (final SacadoExcepcionado sacado : listaSacadosExcepcionado) {
	    if (sacado.getNuSacado().getNuSacado().equals(titulo.getIdentificadorSacado())) {
		return sacado;
	    }
	}

	return null;
    }

    /**
     * <p>
     * Método responsável por calcular o valor máximo permitido sobre o
     * percentual máximo permitido.
     * <p>
     *
     * @param percentualMaximo
     *            valor a ser atribuido
     * @param vrEsperado
     *            valor a ser atribuido
     * @return BigDecimal
     * @author guilherme.santos
     */
    private BigDecimal calcularValorMaximoSobrePercentualPermitido(final BigDecimal percentualMaximo, final BigDecimal vrEsperado) {
	return percentualMaximo.divide(BigDecimal.valueOf(100)).multiply(vrEsperado);
    }

    /**
     * <p>
     * Método responsável por verifica se o BigDecimal é valido, ou seja, não é
     * nulo e maior que zero.
     * <p>
     *
     * @param numero
     *            valor a ser atribuido
     * @return boolean
     * @author guilherme.santos
     */
    private boolean isNumeroValido(final BigDecimal numero) {
	if (numero == null || numero.compareTo(BigDecimal.ZERO) <= 0) {
	    return Boolean.FALSE;
	}
	return Boolean.TRUE;
    }

    /**
     * <p>
     * SacadoValorQuantidade.
     * </p>
     * <p>
     * Descrição: SacadoValorQuantidade
     * </p>
     * <br>
     * <b>Empresa:</b> Cef - Caixa Econômica Federal
     *
     * @version 1.0
     */
    private class SacadoValorQuantidade {

	/** Atributo valor. */
	private BigDecimal valor;
	/** Atributo quantidade. */
	private Integer quantidade;

	/**
	 * Construtor.
	 *
	 */
	SacadoValorQuantidade() {
	    this.valor = BigDecimal.ZERO;
	    this.quantidade = 0;
	}

	/**
	 * Retorna o valor do atributo valor.
	 *
	 * @return valor
	 */
	public BigDecimal getValor() {
	    return this.valor;
	}

	/**
	 * Define o valor do atributo valor.
	 *
	 * @param valor
	 *            valor a ser atribuído
	 */
	public void setValor(final BigDecimal valor) {
	    this.valor = valor;
	}

	/**
	 * <p>
	 * Método responsável por incrementar a quantidade.
	 * <p>
	 */
	public void incrementarQuantidade() {
	    this.quantidade++;
	}
    }
}
