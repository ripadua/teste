/**
 * Copyright (c) 2018 Caixa Econômica Federal. Todos os direitos
 * reservados.
 *
 * Caixa Econômica Federal - SIACG
 *
 * Este software foi desenvolvido sob demanda da CAIXA e está
 * protegido por leis de direitos autorais e tratados internacionais. As
 * condições de cópia e utilização total ou partes dependem de autorização da
 * empresa. Cópias não são permitidas sem expressa autorização. Não pode ser
 * comercializado ou utilizado para propósitos particulares.
 *
 * Uso exclusivo da Caixa Econômica Federal. A reprodução ou distribuição não
 * autorizada deste programa ou de parte dele, resultará em punições civis e
 * criminais e os infratores incorrem em sanções previstas na legislação em
 * vigor.
 *
 * Histórico do TFS:
 *
 * LastChangedRevision: $Revision$
 * LastChangedBy: $Author$
 * LastChangedDate: $Date$
 *
 * HeadURL: $HeadURL$
 *
 */	
package br.gov.caixa.siacg.strategy.impl.titulo;

import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;

import br.gov.caixa.pedesgo.arquitetura.util.UtilData;
import br.gov.caixa.siacg.model.domain.Titulo;

/**
 * <p>ConjuntoTituloFabrica</p>
 *
 * <p>Descrição: Classe que identifica qual conjunto um titulo deve pertencer e adiciona titulo ao conjunto</p>
 *
 * <br><b>Empresa:</b> Cef - Caixa Econômica Federal
 *
 *
 * @author p541915
 *
 * @version 1.0
*/
public class ConjuntoTituloFabrica {
	
	/**
	 * Responsável pela criação de novas instâncias desta classe.
	 *
	 */
	private ConjuntoTituloFabrica() {}
	
	/**
	 * <p>Método responsável por identificar o conjunto do titulo</p>.
	 *
	 * @author p541915
	 *
	 * @param totalizador
	 * @param titulo
	 */
	public static void identificarConjuntoTitulo(TotalizadorTituloAnaliseContrato totalizador, Titulo titulo) {
		
		//Verifica se o titulo é de fluxo
		if (verificarTituloFluxo(totalizador, titulo)) {
        	totalizador.getTitulosFluxo().adicionarTitulo(titulo, true);
        }
		
		//Verifica exclusao por parametro de instrucao de protesto
		if (verificarExclusaoInstrucaoProtesto(totalizador, titulo)) {
			return;
		}
		
        if (verificarTituloOutroContrato(totalizador, titulo)) {
        	totalizador.getTitulosOutrosContratos().adicionarTitulo(titulo);
        	
        } else if (titulo.isTituloLiquidado()) {
        	totalizador.getTitulosLiquidados().adicionarTitulo(titulo);
        	
        } else if (titulo.isTituloProtestado()) {
        	totalizador.getTitulosProtestados().adicionarTitulo(titulo);
        	
        } else if (titulo.isTituloBaixado()) {
        	totalizador.getTitulosBaixados().adicionarTitulo(titulo);
        	
        } else if (titulo.isTituloVencido()) {
        	totalizador.getTitulosVencidos().adicionarTitulo(titulo);
        	
        } else {
        	totalizador.getTitulosAVencer().adicionarTitulo(titulo, true);
        }
        
        //Verifica se titulo entra para o calculo de indice de liquidez
        if (verificarTituloCalculoIndiceLiquidez(titulo)) {
        	totalizador.getTitulosIndiceLiquidez().adicionarTitulo(titulo);
        }
        
        //Adiciona titulo para composicao da carteira
        totalizador.getTitulosComposicaoCarteira().adicionarTitulo(titulo);
	}
	
	/**
	 * <p>Método responsável por verificar se o título é de outro contrato</p>.
	 *
	 * @author p541915
	 *
	 * @param totalizador
	 * @param titulo
	 * @return
	 */
	private static boolean verificarTituloOutroContrato(TotalizadorTituloAnaliseContrato totalizador, Titulo titulo) {
		return titulo.getNuContrato() != null 
				&& !titulo.getNuContrato().equals(totalizador.getParametros().getContrato().getNuContrato());
	}
	
	/**
	 * <p>Método responsável por verificar se o título é de fluxo</p>.
	 *
	 * @author p541915
	 *
	 * @param totalizador
	 * @param titulo
	 * @return
	 */
	private static boolean verificarTituloFluxo(TotalizadorTituloAnaliseContrato totalizador, Titulo titulo) {
		Integer qtdDiasFluxo = totalizador.getParametros().getQtdDiasFluxo();
		
		final Date dataFim = UtilData.converterDataSemHoras(new Date());

        final GregorianCalendar dataInicio = new GregorianCalendar();
        dataInicio.add(Calendar.DAY_OF_MONTH, qtdDiasFluxo * (-1));
        
        return UtilData.verificarSeDataEhIgual(titulo.getDtVencimentoTitulo(), dataInicio.getTime())
                || (UtilData.verificarSeDataEhMaior(titulo.getDtVencimentoTitulo(), dataInicio.getTime()) && UtilData.verificarSeDataEhMenor(titulo.getDtVencimentoTitulo(), dataFim));
	}
	
	/**
	 * <p>Método responsável por verificar se a garantia possui o parametro de instrucao de protesto e se o título também possui</p>.
	 *
	 * @author p541915
	 *
	 * @param totalizador
	 * @param titulo
	 * @return
	 */
	private static boolean verificarExclusaoInstrucaoProtesto(TotalizadorTituloAnaliseContrato totalizador, Titulo titulo) {
		final Boolean icInstrucaoProtestoGarantia = totalizador.getParametros().getGarantiaContrato().getInstrucaoProtesto();
		
		//Se a garantia estiver com o parametro icInstrucaoProtesto como TRUE e o título não tiver, desconsidera o título
		//Este filtro estava sendo realizado na consulta, mas para ajustar com a consulta de fluxo a validação foi removida 
		//da consulta e está sendo realizada aqui
		if (icInstrucaoProtestoGarantia != null && icInstrucaoProtestoGarantia) {
			return icInstrucaoProtestoGarantia != titulo.getIcInstrucaoProtesto();
		}
		
		return false;
	}
	
	/**
	 * <p>Método responsável por verificar se o titulo entra para o calculo de indice de liquidez</p>.
	 *
	 * @author p541915
	 *
	 * @param titulo
	 * @return
	 */
	private static boolean verificarTituloCalculoIndiceLiquidez(Titulo titulo) {
		final Date dataDMenosTrinta = UtilData.somarSubtrairDias(new Date(), -33);
        // Verifica se Titulo é de 30 dias atras para calculo de Percentual Liquidez
        return (titulo.getDtVencimentoTitulo() != null && UtilData.verificarSeDataEhMaior(titulo.getDtVencimentoTitulo(), dataDMenosTrinta)
                && UtilData.verificarSeDataEhMenor(titulo.getDtVencimentoTitulo(), UtilData.somarSubtrairDias(new Date(), -1)));
	}
	
}
