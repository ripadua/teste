package br.gov.caixa.siacg.view.mb;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.Map;

import javax.annotation.PostConstruct;
import javax.ejb.EJB;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ManagedProperty;
import javax.faces.bean.SessionScoped;
import javax.inject.Inject;

import br.gov.caixa.pedesgo.arquitetura.controlador.AbstractBean;
import br.gov.caixa.pedesgo.arquitetura.controlador.ManutencaoBean;
import br.gov.caixa.pedesgo.arquitetura.enums.EnumExtensaoArquivo;
import br.gov.caixa.pedesgo.arquitetura.paginacao.PaginacaoDemanda;
import br.gov.caixa.pedesgo.arquitetura.relatorio.UtilRelatorio;
import br.gov.caixa.pedesgo.arquitetura.util.LogCefUtil;
import br.gov.caixa.pedesgo.arquitetura.util.UtilObjeto;
import br.gov.caixa.siacg.comum.to.TrilhaHistoricoTO;
import br.gov.caixa.siacg.pagination.TrilhaHistoricoLazyModel;
import br.gov.caixa.siacg.service.TrilhaHistoricoService;
import br.gov.caixa.siacg.trilha.TrilhaHistorico;
import br.gov.caixa.siacg.view.form.TrilhaHistoricoVisao;

/**
 * <p>
 * TrilhaHistoricoMB.
 * </p>
 * <p>
 * Descrição: Managed bean do caso de uso <code> Trilha Historico </code>
 * </p>
 * <br>
 * <b>Empresa:</b> Cef - Caixa Econômica Federal
 *
 * @author robson.oliveira
 * @version 1.0
 */
@ManagedBean
@SessionScoped
public class TrilhaHistoricoMB extends ManutencaoBean<TrilhaHistorico> {

    private static final long serialVersionUID = -2988753241738332120L;

    /** Atributo PREFIXO_CASO_USO. */
    private static final String PREFIXO_CASO_USO = "trilhaAuditoria";

    /** Atributo DIRETORIO_PAGINAS. */
    private static final String DIRETORIO_PAGINAS = "/pages/";

    /** Atributo CAMINHO_RELATORIO. */
    private static final String CAMINHO_RELATORIO = "/reports/";

    /** Atributo JASPER_AUDITORIA. */
    private static final String JASPER_AUDITORIA = "trilha_auditoria.jasper";

    /** Atributo REL_TR_AUDITORIA. */
    private static final String REL_TR_AUDITORIA = "log_auditoria";

    /** Atributo service. */
    @Inject
    private TrilhaHistoricoService service;
    
    @EJB
    private SiacgMB siacgMB;

    /** Atributo trilhaHistoricoVisao. */
    @Inject
    private transient TrilhaHistoricoVisao trilhaHistoricoVisao;

    /** Atributo consult. */
    @ManagedProperty(value = TrilhaHistoricoLazyModel.EL_MANAGED_BEAN)
    private TrilhaHistoricoLazyModel consulta;

    /**
     * @see br.gov.caixa.pedesgo.arquitetura.controlador.AbstractBean#carregar()
     */
    @Override
    @PostConstruct
    public void carregar() {
        final TrilhaHistoricoVisao visao = this.getVisao();
        visao.setListaTabela(this.siacgMB.getNoAcaoList());
        visao.setListaOperacao(this.siacgMB.getIcAcaoList());
    }

    /**
     * <p>
     * Método responsável por executar a consulta dos dados de auditória após as
     * validações dos campos de data serem realizados.
     * <p>
     *
     * @author Robson Oliveira
     */
    public void validaFiltrosTela() {

        if (!this.service.validarFiltroData(this.getConsulta().getTrilhaHistoricoTO())) {
            super.adicionaMensagemInformativa("MA005");

        } else {
            if (!this.validaIntervaloDataPesquisa()) {
                super.adicionaMensagemDeAlerta("MN037", this.getService().obterQtdDiasParametro());

            } else {
                this.getConsulta().setValido(true);
            }
        }

        if (!this.service.validarFiltroFuncionalidadeOuResponsavel(this.getConsulta().getTrilhaHistoricoTO())) {
            super.adicionaMensagemInformativa("MN039");
        }
    }

    /**
     * <p>
     * Método responsável por verificar se o intervalo entre o período inicial e
     * final está dentro do intervalo cadastrado no parametro do sistema.
     * <p>
     *
     * @return Boolean
     * @author Robson.Oliveira
     */
    public Boolean validaIntervaloDataPesquisa() {
        return this.service.validaIntervaloDataPesquisa(this.consulta.getTrilhaHistoricoTO());
    }

    /**
     * <p>
     * Método responsável por exportar xls.
     * <p>
     *
     * @author robson.oliveira
     */
    public void gerarRelatorio() {

        final Map<String, Object> parametros = new LinkedHashMap<>();

        try {
            if (this.validaListaTrilhaHistorico()) {
                super.adicionaMensagemDeAlerta("MN038");

            } else {
                UtilRelatorio.getInstancia().addCaminhoRelatorio(TrilhaHistoricoMB.CAMINHO_RELATORIO + TrilhaHistoricoMB.JASPER_AUDITORIA)
                        .addColecao(this.service.listarTrilhasHistorico(this.consulta.getTrilhaHistoricoTO()))
                        .addExtensaoArquivo(EnumExtensaoArquivo.XLS).addNomeRelatorio(TrilhaHistoricoMB.REL_TR_AUDITORIA).addParametros(parametros)
                        .addResposta(super.getResponse()).gerarRelatorio();
            }

        } catch (final Exception e) {
            LogCefUtil.error("Não foi possivel gerar o XLS" + e.getCause());
            LogCefUtil.error(e);
        }
    }

    /**
     * <p>
     * Método responsável por gerar o relatório csv.
     * <p>
     *
     * @author robson.oliveira
     */
    public void geraRelatorioCSV() {

        this.service.gerarRelatorioCSV(this.consulta.getTrilhaHistoricoTO());
    }

    /**
     * <p>
     * Método responsável por validar se os relatórios serão gerados.
     * <p>
     *
     * @return Boolean
     * @author Robson.Oliveira
     */
    private Boolean validaListaTrilhaHistorico() {
        Boolean retorno = false;
        if (this.consulta.getResultado().getLista().isEmpty()) {
            retorno = true;
        }

        return retorno;

    }

    /**
     * @see br.gov.caixa.pedesgo.arquitetura.controlador.AbstractBean#getVisao()
     */
    @Override
    public TrilhaHistoricoVisao getVisao() {
        if (!UtilObjeto.isReferencia(this.trilhaHistoricoVisao)) {
            this.trilhaHistoricoVisao = new TrilhaHistoricoVisao();
        }

        return this.trilhaHistoricoVisao;
    }

    /**
     * <p>
     * Método responsável por limpar os dados de filtro da tela.
     * <p>
     *
     * @author Robson.Oliveira
     */
    public void limparFiltrosTrilhaAuditoria() {
        this.getConsulta().setResultado(new PaginacaoDemanda<TrilhaHistorico>(new ArrayList<TrilhaHistorico>(), 0));
        this.getConsulta().setRowCount(0);
        this.getConsulta().setTrilhaHistoricoTO(new TrilhaHistoricoTO());
    }

    /**
     * @see br.gov.caixa.pedesgo.arquitetura.controlador.AbstractBean#getPrefixoCasoDeUso()
     */
    @Override
    protected String getPrefixoCasoDeUso() {
        return TrilhaHistoricoMB.PREFIXO_CASO_USO;
    }

    /**
     *
     * @see br.gov.caixa.pedesgo.arquitetura.controlador.AbstractBean#getTelaConsulta()
     */
    @Override
    public String getTelaConsulta() {
        return TrilhaHistoricoMB.DIRETORIO_PAGINAS + this.getPrefixoCasoDeUso() + AbstractBean.SUFIXO_TELA_CONSULTA;
    }

    /**
     *
     * @see br.gov.caixa.pedesgo.arquitetura.controlador.AbstractBean#getService()
     */
    @Override
    @SuppressWarnings("unchecked")
    public TrilhaHistoricoService getService() {
        return this.service;
    }

    /**
     *
     * <p>
     * Retorna o valor do atributo consulta.
     * <p>
     *
     * @return consulta
     * @author Robson Oliveira
     */
    public TrilhaHistoricoLazyModel getConsulta() {
        return this.consulta;
    }

    /**
     * <p>
     * Define o valor do atributo consulta.
     * <p>
     *
     * @param consulta
     *            valor a ser atribuído
     * @author Robson.Oliveira
     */
    public void setConsulta(final TrilhaHistoricoLazyModel consulta) {
        this.consulta = consulta;
    }

    /**
     *
     * @see br.gov.caixa.pedesgo.arquitetura.controlador.AbstractBean#getNomeVarResourceBundle()
     */
    @Override
    protected String getNomeVarResourceBundle() {
        return "msgApp";
    }
}
