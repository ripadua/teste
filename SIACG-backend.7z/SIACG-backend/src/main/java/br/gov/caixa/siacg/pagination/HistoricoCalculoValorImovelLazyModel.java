/*
 * Copyright (c) 2021 Caixa Econômica Federal. Todos os direitos
 * reservados.
 *
 * Caixa Econômica Federal - SIACG - Sistema de Crédito Rural
 *
 * Este software foi desenvolvido sob demanda da CAIXA e está
 * protegido por leis de direitos autorais e tratados internacionais. As
 * condições de cópia e utilização do todo ou partes dependem de autorização da
 * empresa. Cópias não são permitidas sem expressa autorização. Não pode ser
 * comercializado ou utilizado para propósitos particulares.
 *
 * Uso exclusivo da Caixa Econômica Federal. A reprodução ou distribuição não
 * autorizada deste programa ou de parte dele, resultará em punições civis e
 * criminais e os infratores incorrem em sanções previstas na legislação em
 * vigor.
 *
 * Histórico do TFS:
 *
 * LastChangedRevision: $Revision$
 * LastChangedBy: $Author$
 * LastChangedDate: $Date$
 *
 * HeadURL: $HeadURL$
 *
 */
package br.gov.caixa.siacg.pagination;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.enterprise.context.SessionScoped;
import javax.inject.Inject;
import javax.inject.Named;

import org.primefaces.model.SortOrder;

import br.gov.caixa.pedesgo.arquitetura.paginacao.Paginacao;
import br.gov.caixa.pedesgo.arquitetura.paginacao.PaginacaoDemanda;
import br.gov.caixa.pedesgo.arquitetura.siico.util.UtilString;
import br.gov.caixa.pedesgo.arquitetura.util.UtilObjeto;
import br.gov.caixa.siacg.model.domain.HistoricoCalculoValorImovel;
import br.gov.caixa.siacg.model.vo.HistoricoCalculoValorImoveFiltroVO;
import br.gov.caixa.siacg.service.HistoricoCalculoValorImovelService;

/**
 * <p>
 * HistoricoCalculoValorImovelLazyModel
 * </p>
 *
 * <p>
 * Descrição: Classe de paginação sob demanda de histórico de cálculo do valor
 * do imóvel.
 * </p>
 *
 * <br>
 * <b>Empresa:</b> Cef - Caixa Econômica Federal
 *
 *
 * @author gerusa.soares
 *
 * @version 1.0
 */
@Named
@SessionScoped
public class HistoricoCalculoValorImovelLazyModel extends Paginacao<HistoricoCalculoValorImovel> {

    /** Atributo serialVersionUID. */
    private static final long serialVersionUID = 1L;

    private HistoricoCalculoValorImoveFiltroVO filtroPesquisa;

    @Inject
    private HistoricoCalculoValorImovelService service;

    /**
     * @see br.gov.caixa.pedesgo.arquitetura.paginacao.Paginacao#getServico()
     */
    @SuppressWarnings("unchecked")
    @Override
    public HistoricoCalculoValorImovelService getServico() {
	return this.service;
    }

    /**
     * @see br.gov.caixa.pedesgo.arquitetura.paginacao.Paginacao#load(int, int,
     *      java.lang.String, org.primefaces.model.SortOrder, java.util.Map)
     */
    @Override
    public List<HistoricoCalculoValorImovel> load(final int inicio, final int fim, final String campoOrdenacao, final SortOrder ordenacao,
	    final Map<String, String> parametros) {
	
	List<HistoricoCalculoValorImovel> lista = new ArrayList<>();
	int quantidadeRegistros = 0;
	
	if(this.isExisteFiltro(this.filtroPesquisa)) {
	    final PaginacaoDemanda<HistoricoCalculoValorImovel> resultado = this.service.listarHistoricoPaginado(this.filtroPesquisa, inicio, fim);
	    lista = resultado.getLista();
	    quantidadeRegistros = resultado.getQuantidadeRegistros() == 0 ? resultado.getLista().size() : resultado.getQuantidadeRegistros();
	}

	this.setWrappedData(lista);
	this.setRowCount(quantidadeRegistros);

	return lista;
    }

    public HistoricoCalculoValorImoveFiltroVO getFiltroPesquisa() {
	if(!UtilObjeto.isReferencia(this.filtroPesquisa)) {
	    this.filtroPesquisa = new HistoricoCalculoValorImoveFiltroVO();
	}
	return this.filtroPesquisa;
    }

    public void setFiltroPesquisa(final HistoricoCalculoValorImoveFiltroVO filtroPesquisa) {
	this.filtroPesquisa = filtroPesquisa;
    }
    
    /**
     * <p>
     * Método responsável por verificar se ao menos um filtro foi informado.
     * </p>
     *
     * @author gerusa.soares
     *
     * @param filtroPesquisa
     * @return
     */
    public boolean isExisteFiltro(final HistoricoCalculoValorImoveFiltroVO filtroPesquisa) {
	if (UtilObjeto.isReferencia(filtroPesquisa)) {

	    if (!UtilString.isVazio(filtroPesquisa.getCoIdentificadorContrato())) {
		return true;
	    }

	    if (UtilObjeto.isReferencia(filtroPesquisa.getMatriculaImovel())) {
		return true;
	    }

	    if (!UtilString.isVazio(filtroPesquisa.getIcEstadoOcupacao())) {
		return true;
	    }

	    if (UtilObjeto.isReferencia(filtroPesquisa.getDtCalculoInicio())) {
		return true;
	    }

	    if (UtilObjeto.isReferencia(filtroPesquisa.getDtCalculoFim())) {
		return true;
	    }
	}

	return false;
    }

}
