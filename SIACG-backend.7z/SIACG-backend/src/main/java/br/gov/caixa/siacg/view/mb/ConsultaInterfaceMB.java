package br.gov.caixa.siacg.view.mb;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStreamWriter;
import java.util.ArrayList;
import java.util.List;

import javax.ejb.EJB;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;

import org.apache.commons.collections.CollectionUtils;

import br.gov.caixa.pedesgo.arquitetura.controlador.AbstractBean;
import br.gov.caixa.pedesgo.arquitetura.controlador.ManutencaoBean;
import br.gov.caixa.pedesgo.arquitetura.dao.DAO;
import br.gov.caixa.pedesgo.arquitetura.enums.EnumExtensaoArquivo;
import br.gov.caixa.pedesgo.arquitetura.relatorio.UtilRelatorio;
import br.gov.caixa.pedesgo.arquitetura.servico.Servico;
import br.gov.caixa.pedesgo.arquitetura.util.LogCefUtil;
import br.gov.caixa.pedesgo.arquitetura.visao.ManutencaoVisao;
import br.gov.caixa.siacg.model.domain.AplicacaoFinanceira;
import br.gov.caixa.siacg.model.domain.BandeiraCartao;
import br.gov.caixa.siacg.model.domain.BemCliente;
import br.gov.caixa.siacg.model.domain.CartaoCredito;
import br.gov.caixa.siacg.model.domain.Cedente;
import br.gov.caixa.siacg.model.domain.ContaCorrente;
import br.gov.caixa.siacg.model.domain.Contrato;
import br.gov.caixa.siacg.model.domain.CustodiaCheque;
import br.gov.caixa.siacg.model.domain.Imovel;
import br.gov.caixa.siacg.model.domain.MaquinaEquipamento;
import br.gov.caixa.siacg.model.domain.Sacado;
import br.gov.caixa.siacg.model.domain.Titulo;
import br.gov.caixa.siacg.model.domain.Veiculo;
import br.gov.caixa.siacg.model.enums.TipoConsultaEnum;
import br.gov.caixa.siacg.model.vo.FiltroConsultaInterfaceVO;
import br.gov.caixa.siacg.service.AplicacaoFinanceiraService;
import br.gov.caixa.siacg.service.BandeiraCartaoService;
import br.gov.caixa.siacg.service.CartaoCreditoService;
import br.gov.caixa.siacg.service.CedenteService;
import br.gov.caixa.siacg.service.ContaCorrenteService;
import br.gov.caixa.siacg.service.ContratoService;
import br.gov.caixa.siacg.service.CustodiaChequeService;
import br.gov.caixa.siacg.service.ImovelService;
import br.gov.caixa.siacg.service.MaquinaEquipamentoService;
import br.gov.caixa.siacg.service.SacadoService;
import br.gov.caixa.siacg.service.TituloService;
import br.gov.caixa.siacg.service.VeiculoService;

/**
 * <p>
 * ConsultaInterfaceMB.
 * </p>
 * <p>
 * Descrição: Bean Gerenciável para a tela de export dados CSV.
 * </p>
 * <br>
 * <b>Empresa:</b> Cef - Caixa Econômica Federal
 *
 * @author Marco Isecke
 * @version 1.0
 */

@ManagedBean
@SessionScoped
public class ConsultaInterfaceMB extends ManutencaoBean<Contrato> {

	private static final String CONSULTANO_SIACG = "ConsultanoSIACG";
	private static final int SCHEMA_1 = 1;

	private static final long serialVersionUID = -4248095391849635745L;

	private static final String DIRETORIO_PAGINAS = "/pages/";

	public static final String NOME_MANAGED_BEAN = "ConsultaInterfaceMB";

	public static final String EL_MANAGED_BEAN = "#{consultaInterfaceMB}";

	private static final String PAGINA_CONSULTA_TITULO = "/pages/consultaInterface/consulta.xhtml?faces-redirect=true";

	private List<BandeiraCartao> listaCartoes;
	
	private transient FiltroConsultaInterfaceVO filtros;

	@EJB
	private ContratoService contratoService;

	@EJB
	private TituloService tituloService;

	@EJB
	private CedenteService cedenteService;

	@EJB
	private SacadoService sacadoService;

	@EJB
	private ContaCorrenteService contaCorrenteService;

	@EJB
	private AplicacaoFinanceiraService aplicacaoFinanceiraService;

	@EJB
	private CustodiaChequeService custodiaChequeService;

	@EJB
	private MaquinaEquipamentoService maquinaEquipamentoService;

	@EJB
	private ImovelService imovelService;

	@EJB
	private VeiculoService veiculoService;

	@EJB
	private CartaoCreditoService cartaoCreditoService;
	
	@EJB
	private BandeiraCartaoService bandeiraCartaoService;
	

	public void limparFiltros() {
		if (this.filtros == null) {
			filtros = new FiltroConsultaInterfaceVO();
		}
		setListaCartoes((List<BandeiraCartao>) bandeiraCartaoService.listar());
	}

	public List<TipoConsultaEnum> getTipoConsulta() {
		return TipoConsultaEnum.valuesPorSchema(filtros.getSchemaConsulta());
	}

	public void limpaFiltro() {
		filtros.setTabelaConsulta(null);
	}
	
	public void limpaCampos() {
		filtros.limpaCampos();
	}

	/**
	 * <p>
	 * Método responsável por abrir a tela de consutla do sacado.
	 * <p>
	 *
	 * @param filtro
	 * @return <code>String</code>
	 * @author Waltenes Junior
	 */
	public String abrirConsulta() {
		this.filtros = new FiltroConsultaInterfaceVO();
		return ConsultaInterfaceMB.PAGINA_CONSULTA_TITULO;
	}

	/**
	 * @see br.gov.caixa.pedesgo.arquitetura.controlador.AbstractBean#getTelaConsulta()
	 */
	@Override
	public String getTelaConsulta() {
		return ConsultaInterfaceMB.DIRETORIO_PAGINAS.concat(this.getPrefixoCasoDeUso()).concat(AbstractBean.SUFIXO_TELA_CONSULTA);
	}

	/**
	 * <p>M
	 * Método responsável por filtrar a lista de titulos.
	 * <p>
	 *
	 * @author Marco Isecke
	 */
	public String filtrar() {
		return ConsultaInterfaceMB.PAGINA_CONSULTA_TITULO;
	}

	/**
	 * Método resposnsavel pela criação das SQL e Exportação do arquivo CSV
	 */
	public void exportarCSV() {
		if(filtros.getSchemaConsulta() == SCHEMA_1) {
			if (filtros.getTabelaConsulta().equals(TipoConsultaEnum.CONTRATO_1)) {
				List<Contrato> contratos = contratoService.getContratosCpfCnpj(filtros.getCpfCnpj());
				montarCSVContratos(contratoService.criaArquivoCSV(contratos),CONSULTANO_SIACG);
			} else if (filtros.getTabelaConsulta().equals(TipoConsultaEnum.TITULO)) {
				List<Titulo> titulos = tituloService.listarContratoFiltroInterface(filtros);
				montarCSVContratos(tituloService.criaArquivoCSV(titulos),CONSULTANO_SIACG);
			} else if (filtros.getTabelaConsulta().equals(TipoConsultaEnum.CEDENTE)) {
				List<Cedente> cedentes = cedenteService.listarCedenteCpfCnpj(filtros.getCpfCnpj());
				montarCSVContratos(cedenteService.criaArquivoCSV(cedentes),CONSULTANO_SIACG);
			} else if (filtros.getTabelaConsulta().equals(TipoConsultaEnum.SACADO)) {
				List<Sacado> sacados = sacadoService.listarSacadoCpfCnpj(filtros.getCpfCnpj());
				montarCSVContratos(sacadoService.criaArquivoCSV(sacados),CONSULTANO_SIACG);
			} else if (filtros.getTabelaConsulta().equals(TipoConsultaEnum.CONTA_CORRENTE)) {
				List<ContaCorrente> contas = contaCorrenteService.listarContasCpfCnpj(filtros.getCpfCnpj());
				montarCSVContratos(contaCorrenteService.criaArquivoCSV(contas),CONSULTANO_SIACG);
			} else if (filtros.getTabelaConsulta().equals(TipoConsultaEnum.APLICACAO_FINANCEIRA)) {
				List<AplicacaoFinanceira> aplicacoes = aplicacaoFinanceiraService.listarAplicacoesCpfCnpj(filtros.getCpfCnpj());
				montarCSVContratos(aplicacaoFinanceiraService.criaArquivoCSV(aplicacoes),CONSULTANO_SIACG);
			} else if (filtros.getTabelaConsulta().equals(TipoConsultaEnum.CUSTODIA_CHEQUE)) {
				List<CustodiaCheque> custodias = custodiaChequeService.listarCustodiasCpfCnpj(filtros.getCpfCnpj());
				montarCSVContratos(custodiaChequeService.criaArquivoCSV(custodias),CONSULTANO_SIACG);
			} else if (filtros.getTabelaConsulta().equals(TipoConsultaEnum.MAQUINA_EQUIPAMENTO)) {
				List<BemCliente> bens = maquinaEquipamentoService.listarMaquinasCpfCnpj(filtros.getCpfCnpj());
				List<MaquinaEquipamento> maquinas = new ArrayList<MaquinaEquipamento>();
				if(CollectionUtils.isNotEmpty(bens)) {
					for(BemCliente bem : bens) {
						maquinas.add(bem.getMaquinaEquipamento());
					}
				}
				montarCSVContratos(maquinaEquipamentoService.criaArquivoCSV(maquinas),CONSULTANO_SIACG);
			} else if (filtros.getTabelaConsulta().equals(TipoConsultaEnum.IMOVEL)) {
				List<Imovel> imoveis = imovelService.listarImovelFiltro(filtros);
				montarCSVContratos(imovelService.criaArquivoCSV(imoveis),CONSULTANO_SIACG);
			} else if (filtros.getTabelaConsulta().equals(TipoConsultaEnum.VEICULO)) {
				List<Veiculo> veiculos = veiculoService.listarVeiculoFiltro(filtros);
				montarCSVContratos(veiculoService.criaArquivoCSV(veiculos),CONSULTANO_SIACG);
			} else if (filtros.getTabelaConsulta().equals(TipoConsultaEnum.CARTAO_CREDITO)) {
				List<CartaoCredito> cartoes = cartaoCreditoService.listarCartoesFiltro(filtros);
				montarCSVContratos(cartaoCreditoService.criaArquivoCSV(cartoes),CONSULTANO_SIACG);
			}
		}	
	}

	/**
	 * Habilita o campo de CPF/CNPJ
	 * 
	 * @return
	 */
	public boolean isHabilitaCpf() {
		if (filtros.getTabelaConsulta() != null) {
			if (filtros.getTabelaConsulta().equals(TipoConsultaEnum.CONTRATO_1) || filtros.getTabelaConsulta().equals(TipoConsultaEnum.CHEQUE)
					|| filtros.getTabelaConsulta().equals(TipoConsultaEnum.APLICACAO) || filtros.getTabelaConsulta().equals(TipoConsultaEnum.CEDENTE)
					|| filtros.getTabelaConsulta().equals(TipoConsultaEnum.SACADO)
					|| filtros.getTabelaConsulta().equals(TipoConsultaEnum.CONTA_CORRENTE)
					|| filtros.getTabelaConsulta().equals(TipoConsultaEnum.APLICACAO_FINANCEIRA)
					|| filtros.getTabelaConsulta().equals(TipoConsultaEnum.CUSTODIA_CHEQUE)
					|| filtros.getTabelaConsulta().equals(TipoConsultaEnum.CONTRATO_2) || filtros.getTabelaConsulta().equals(TipoConsultaEnum.VEICULO)
					|| filtros.getTabelaConsulta().equals(TipoConsultaEnum.MAQUINA_EQUIPAMENTO)
					|| filtros.getTabelaConsulta().equals(TipoConsultaEnum.IMOVEL)) {
				return true;
			}
		}
		return false;
	}
	
	/**
	 * Habilita o campo de CPF/CNPJ
	 * 
	 * @return
	 */
	public boolean isHabilitaMatricula() {
		if (filtros.getTabelaConsulta() != null) {
			if (filtros.getTabelaConsulta().equals(TipoConsultaEnum.IMOVEL)) {
				return true;
			}
		}
		return false;
	}

	/**
	 * Habilita os campos de conta
	 * 
	 * @return
	 */
	public boolean isHabilitaComboConta() {
		if (filtros.getTabelaConsulta() != null) {
			if (filtros.getTabelaConsulta().equals(TipoConsultaEnum.CARTAO_FLUXO)
					|| filtros.getTabelaConsulta().equals(TipoConsultaEnum.CARTAO_ESTOQUE)
					|| filtros.getTabelaConsulta().equals(TipoConsultaEnum.CARTAO_CREDITO)) {
				return true;
			}
		}
		return false;
	}

	/**
	 * Habilita o campo de nome de bandeira de cartão
	 * 
	 * @return
	 */
	public boolean isHabilitaNomeBandeira() {
		return isHabilitaComboConta();
	}

	/**
	 * Habilita o campo de cpf/cnpj de cedente
	 * 
	 * @return
	 */
	public boolean isHabilitaCpfCedente() {
		if (filtros.getTabelaConsulta() != null) {
			if (filtros.getTabelaConsulta().equals(TipoConsultaEnum.DUPLICATA) || filtros.getTabelaConsulta().equals(TipoConsultaEnum.TITULO)
					) {
				return true;
			}
		}
		return false;
	}

	/**
	 * 
	 * @return
	 */
	public boolean isHabilitaChassi() {		
		return (filtros.getTabelaConsulta() != null && filtros.getTabelaConsulta().equals(TipoConsultaEnum.VEICULO));
	}

	/**
	 * 
	 * @param csv
	 */
		public void montarCSVContratos(StringBuilder csv, String nomeArquivo) {
			final File arquivo = this.criarArquivoCsv(csv,nomeArquivo);
			try (InputStream inputStream = new FileInputStream(arquivo);){
				final byte[] arquivo2 = new byte[(int) arquivo.length()];	
				inputStream.read(arquivo2, 0, arquivo2.length);	
				UtilRelatorio.getInstancia().adicionarArquivoCessao(arquivo2, nomeArquivo, EnumExtensaoArquivo.CSV.getExtensao());
			} catch (final IOException e) {
				LogCefUtil.error("Não foi possivel gerar o CSV " + e.getCause());
				LogCefUtil.error(e);
			} 
	}

	/**
	 *
	 * <p>
	 * Método responsável por criar o arquivo csv.
	 * </p>
	 *
	 * @param lista
	 * @return File
	 * @throws IOException
	 * @author marco.isecke
	 */
	private File criarArquivoCsv(StringBuilder csv,String nomeArquivo) {
		File arquivo = new File(nomeArquivo+".csv");
		try (
			 FileOutputStream fos = new FileOutputStream(arquivo);				
			 OutputStreamWriter escrita = new OutputStreamWriter(fos, "UTF-8");
			){

			final byte[] enc = new byte[] { (byte) 0xEF, (byte) 0xBB, (byte) 0xBF };
			fos.write(enc);
			fos.write(enc);

			escrita.write(csv.toString());
			escrita.flush();
		} catch (FileNotFoundException e) {
			LogCefUtil.error("Erro " + e.getCause());
			LogCefUtil.error(e);
		} catch (IOException e) {
			LogCefUtil.error(e.getCause());
			LogCefUtil.error(e);

		}
		return arquivo;
	}

	/*********************************
	 * GETTERS E SETTERS
	 *********************************/
	/**
	 * @param consulta
	 *            the consulta to set
	 */
	public void setFiltros(FiltroConsultaInterfaceVO filtros) {
		this.filtros = filtros;
	}

	@Override
	protected String getPrefixoCasoDeUso() {
		return null;
	}

	@Override
	public <S extends Servico<Contrato, DAO<Contrato>>> S getService() {
		return null;
	}

	@Override
	public ManutencaoVisao<Contrato> getVisao() {
		return null;
	}

	/**
	 * @return the filtros
	 */
	public FiltroConsultaInterfaceVO getFiltros() {
		return filtros;
	}

	/**
	 * @return the listaCartoes
	 */
	public List<BandeiraCartao> getListaCartoes() {
		return listaCartoes;
	}

	/**
	 * @param listaCartoes the listaCartoes to set
	 */
	public void setListaCartoes(List<BandeiraCartao> listaCartoes) {
		this.listaCartoes = listaCartoes;
	}
}
