/**
 * Copyright (c) 2013 Caixa Econômica Federal. Todos os direitos reservados.
 *
 * Caixa Econômica Federal - sisgt - Sistema de Crédito Rural
 *
 * Este software foi desenvolvido sob demanda da CAIXA e está protegido por leis de direitos autorais e tratados
 * internacionais. As condições de cópia e utilização do todo ou partes dependem de autorização da pessoa. Cópias não
 * são permitidas sem expressa autorização. Não pode ser comercializado ou utilizado para propósitos particulares.
 *
 * Uso exclusivo da Caixa Econômica Federal. A reprodução ou distribuição não autorizada deste programa ou de parte
 * dele, resultará em punições civis e criminais e os infratores incorrem em sanções previstas na legislação em vigor.
 *
 * Histórico do Subversion:
 *
 * LastChangedRevision: $Revision$ LastChangedBy: $Author$ LastChangedDate: $Date$
 *
 * HeadURL: $HeadURL$
 *
 */
package br.gov.caixa.siacg.view.mb;

import java.io.IOException;
import java.io.InputStream;
import java.util.Collection;
import java.util.Properties;

import javax.ejb.EJB;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;
import javax.inject.Inject;
import javax.servlet.ServletException;

import br.gov.caixa.pedesgo.arquitetura.controlador.ManutencaoBean;
import br.gov.caixa.pedesgo.arquitetura.dao.DAO;
import br.gov.caixa.pedesgo.arquitetura.entidade.Entidade;
import br.gov.caixa.pedesgo.arquitetura.enums.EnumExtensaoArquivo;
import br.gov.caixa.pedesgo.arquitetura.relatorio.UtilRelatorio;
import br.gov.caixa.pedesgo.arquitetura.servico.Servico;
import br.gov.caixa.pedesgo.arquitetura.util.LogCefUtil;
import br.gov.caixa.pedesgo.arquitetura.util.UsuarioUtil;
import br.gov.caixa.pedesgo.arquitetura.util.UtilString;
import br.gov.caixa.pedesgo.arquitetura.visao.ManutencaoVisao;
import br.gov.caixa.security.CaixaPerfil;
import br.gov.caixa.siacg.model.enums.PropriedadeEnum;
import br.gov.caixa.siacg.service.ManualUsuarioService;
import br.gov.caixa.siacg.service.PropriedadeService;
import br.gov.caixa.siacg.util.LogCEF;

/**
 * <p>
 * UsuarioMB.
 * </p>
 * <p>
 * Descrição: Maneged Bean responsável pelas informações do usuário
 * </p>
 * <br>
 * <b>Empresa:</b> Cef - Caixa Econômica Federal
 *
 * @author Waltenes Junior
 * @version 1.0
 */
@ManagedBean(name = UsuarioMB.NOME_MANAGED_BEAN)
@SessionScoped
public class UsuarioMB extends ManutencaoBean<Entidade> {

    /** Atributo serialVersionUID. */
    private static final long serialVersionUID = -7320187994898364403L;

    /** Atributo NOME_MANAGED_BEAN. */
    public static final String NOME_MANAGED_BEAN = "usuarioMB";

    /** Atributo EL_MANAGED_BEAN. */
    public static final String EL_MANAGED_BEAN = "#{usuarioMB}";

    /** Atributo propriedadeService. */
    @Inject
    private transient PropriedadeService propriedadeService;
    
    @EJB
    private ManualUsuarioService service;

    /** Atributo listaPerfilUsuario. */
    private transient Collection<CaixaPerfil> listaPerfilUsuario = UsuarioUtil.getPerfis();

    /**
     * <p>
     * Método responsável por sair do sitema.
     * <p>
     *
     * @author Waltenes Junior
     */
    public void sair() {
        try {
            super.getExternalContext().invalidateSession();
            super.getSession().invalidate();
            super.getRequest().logout();
            super.getExternalContext().redirect("/pages/index.cef");
	} catch (final IllegalStateException | IOException | IllegalArgumentException | ServletException e) {
            LogCefUtil.error(e.getMessage());
            LogCefUtil.error(e);
        }

    }

    /**
     * <p>
     * Método responsável por obter o ambiente do usuário logado.
     * <p>
     *
     * @return <code>String</code>
     * @author Waltenes Junior
     */
    public String getAmbiente() {
        return this.propriedadeService.getValorPropriedade(PropriedadeEnum.SISTEMA_AMBIENTE.getPropriedade(), "info");
    }

    /**
     * <p>
     * Método responsável por obter a classificação do sistema.
     * <p>
     *
     * @return <code>String</code> com a classificação
     * @author Waltenes Junior
     */
    public String getClassificacao() {
        return this.propriedadeService.getValorPropriedade(PropriedadeEnum.SISTEMA_CLASSIFICACAO.getPropriedade(), "info");
    }

    /**
     * <p>
     * Método responsável por obter a versão do sistema.
     * <p>
     *
     * @return String
     * @author Waltenes Junior
     */
    public String getVersao() {
        final String path = "/version.properties";
        final InputStream stream = this.getClass().getResourceAsStream(path);
        if (stream == null) {
            return "";
        }
        final Properties props = new Properties();
        try {
            props.load(stream);
            stream.close();
            return (String) props.get("version");
        } catch (final IOException e) {
            LogCEF.debug(e);
            return "";
        }
    }

    /**
     * <p>
     * Método responsável por realizar o download do manual do usuário do siacg.
     * </p>
     *
     * @param evento
     * @author José Roberto
     * @author f734546
     */
    public void downloadManualUsuario() {
        final String noManual = this.propriedadeService.getValorPropriedade("manual.usuario", "documento");
        if (!UtilString.isVazio(noManual)) {
            try {
		
		final byte[] byteManual = this.service.getByteManualUsuario(noManual);
		
		if(byteManual == null) {
		    super.adicionaMensagemDeAlerta("Não foi possível localizar o arquivo " + noManual);
		} else {
		    UtilRelatorio.getInstancia().adicionarArquivoCessao(byteManual, noManual, EnumExtensaoArquivo.PDF.getExtensao());
		}


	    } catch (final Exception e) {
		LogCefUtil.error("Nao foi possivel baixar o manual " + noManual + ": " + e.getMessage());
		LogCefUtil.error(e);
	    }
        }
    }

    /**
     * @see br.gov.caixa.pedesgo.arquitetura.controlador.AbstractBean#getService()
     */
    @Override
    public <S extends Servico<Entidade, DAO<Entidade>>> S getService() {
        return null;
    }

    /**
     * @see br.gov.caixa.pedesgo.arquitetura.controlador.AbstractBean#getVisao()
     */
    @Override
    public ManutencaoVisao<Entidade> getVisao() {
        return null;
    }

    /**
     * @see br.gov.caixa.pedesgo.arquitetura.controlador.AbstractBean#getPrefixoCasoDeUso()
     */
    @Override
    public String getPrefixoCasoDeUso() {
        return null;
    }

    /**
     * Retorna o valor do atributo listaPerfilUsuario.
     *
     * @return listaPerfilUsuario
     */
    public Collection<CaixaPerfil> getListaPerfilUsuario() {
        return this.listaPerfilUsuario;
    }
}
