package br.gov.caixa.siacg.view.form;

import br.gov.caixa.siacg.model.domain.Segmento;

/**
 * <p>
 * PorteVisao
 * </p>
 * <p>
 * Descrição: Classe responsável por armazenar os dados da visão do caso de uso
 * <code>Porte</code>.
 * </p>
 * 
 * <b>Empresa:</b> Cef - Caixa Econômica Federal
 *
 * @author ludemeula.sa
 * @version 1.0
 */
public class PorteVisao extends TemplateVisao<Segmento> {

	private static final long serialVersionUID = 6083876872405823661L;

	private Segmento filtro;

	/**
	 * <p>
	 * Retorna o valor do atributo filtro
	 * </p>
	 * .
	 *
	 * @return filtro
	 */
	public Segmento getFiltro() {
		return this.filtro;
	}

	/**
	 * <p>
	 * Define o valor do atributo filtro
	 * </p>
	 * .
	 *
	 * @param filtro
	 *            valor a ser atribuído
	 */
	public void setFiltro(Segmento filtro) {
		this.filtro = filtro;
	}
	
	public boolean isPessoaFisica() {
		return getEntidade().getNuSegmento() != null && getEntidade().getNuSegmento().equals(0);
	}
	
	public String getDescricaoBotao() {
		return getEntidade().getNuSegmento() != null ? "Alterar" : "Incluir";
	}
}
