package br.gov.caixa.siacg.view.form;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;
import java.util.List;
import java.util.Map;

import org.primefaces.model.StreamedContent;
import org.primefaces.model.chart.CartesianChartModel;

import br.gov.caixa.pedesgo.arquitetura.to.ListaTO;
import br.gov.caixa.pedesgo.arquitetura.util.UtilData;
import br.gov.caixa.siacg.model.domain.AnaliseCartaoBandeira;
import br.gov.caixa.siacg.model.domain.AnaliseCartaoCredito;
import br.gov.caixa.siacg.model.domain.AnaliseContrato;
import br.gov.caixa.siacg.model.domain.AnaliseParecer;
import br.gov.caixa.siacg.model.domain.BandeiraCartao;
import br.gov.caixa.siacg.model.domain.Cedente;
import br.gov.caixa.siacg.model.domain.ChequeExcepcionado;
import br.gov.caixa.siacg.model.domain.ContaContrato;
import br.gov.caixa.siacg.model.domain.Contrato;
import br.gov.caixa.siacg.model.domain.DuplicataExcepcionada;
import br.gov.caixa.siacg.model.domain.GarantiaAplicacao;
import br.gov.caixa.siacg.model.domain.GarantiaContrato;
import br.gov.caixa.siacg.model.domain.Saldo;
import br.gov.caixa.siacg.model.domain.SaldoCartaoBandeira;
import br.gov.caixa.siacg.model.domain.Titulo;
import br.gov.caixa.siacg.model.domain.TotalizadorMaiorSacado;
import br.gov.caixa.siacg.model.enums.CaracteristicaEnum;
import br.gov.caixa.siacg.model.vo.DuplicataInadimplenteVO;
import br.gov.caixa.siacg.model.vo.RelatorioAnaliseContratoVO;
import br.gov.caixa.siacg.model.vo.RelatorioHipersuficienciaVO;
import br.gov.caixa.siacg.model.vo.RelatorioPosicaoRecebiveisHabitacionalVO;
import br.gov.caixa.siacg.model.vo.SacadoExcepcionadoVO;
import br.gov.caixa.siacg.model.vo.VariacaoRecebiveisVO;
import br.gov.caixa.siacg.util.CalculadoraInadimplenciaUtil;

/**
 * <p>
 * RelatorioAnaliseVisao
 * </p>
 * <p>
 * Descrição: Classe responsável por armazenar os dados da visão do caso de uso
 * Relatório de Análise de carteira.
 * </p>
 * <br>
 * <b>Empresa:</b> Cef - Caixa Econômica Federal
 *
 * @author ricardocrispim@gsgroup.com.br
 * @version 1.0
 */
public class RelatorioAnaliseVisao extends TemplateVisao<AnaliseContrato> {

    private static final long serialVersionUID = 1L;

    public static final String NOME_MANAGED_BEAN = "relatorioAnaliseVisao";

    private Contrato contratoSelecionado;

    private Collection<GarantiaContrato> listaGarantiaContratoDuplicata;

    private transient RelatorioAnaliseContratoVO relatorio;

    private CartesianChartModel graficoModel;
    
    private CartesianChartModel graficoModelIgr;

    private TotalizadorMaiorSacado totalizadorMaiorSacadoSelecionado;

    private transient DuplicataInadimplenteVO duplicataInadimplenteVO;

    private String resultadoParecer;

    private String resultadoParecerTotal;

    private String corParecer;

    private String corParecerTotal;

    private BigDecimal totalValorSaldoTotalAplicacaoFinanceira;

    private BigDecimal totalValorSaldoGarantiaAplicacaoFinanceira;

    private BigDecimal valorResultadoParecer;

    private BigDecimal saldoTotalContaCorrenteNLM;

    private BigDecimal valorResultadoParecerTotal;

    private boolean mostrarDuplicatasValidas;

    private boolean mostrarDuplicatasSacadoValidas;

    private boolean exibirDialogDuplicatasSacado;

    private Collection<Contrato> listaContratos;

    private Collection<Titulo> listaDuplicatas;

    private Collection<Titulo> listaDuplicatasSacado;

    private Collection<Titulo> titulosHabitacionais;

    private Collection<TotalizadorMaiorSacado> listaMaioresSacados;

    private Collection<DuplicataExcepcionada> listaDuplicatasExcepcionadas;

    private Collection<GarantiaAplicacao> listaGarantiaAplicacao;

    private Collection<Contrato> contratosSelecionados;
    
    private Collection<SacadoExcepcionadoVO> listaSacadoExcepcionadoVO;

    private Collection<ContaContrato> listaContaContratoNaoLivreMovimentacao;

    private Collection<ListaTO> listaCedentesDuplicatas;

    private Cedente cedente;

    private String codigoCedente;

    private String cedentesUtilizadosEstoque;

    private String cedentesUtilizadosFluxo;

    // Utilizado para renderizar ou não elementos da página Análise Relatório
    // Carteira
    private boolean contemGarantiaCaracteristicaFluxo;

    private boolean contemGarantiaCaracteristicaEstoque;

    private boolean contemGarantiaDuplicata;

    private boolean contemGarantiaCheque;

    private boolean contemGarantiaCartaoFluxo;

    private boolean contemGarantiaCartaoEstoque;

    private boolean contemGarantiaCartao;

    private boolean contemGarantiaAlienacaoVeiculo;

    private boolean contemGarantiaAplicacaoFinanceira;

    private boolean contemGarantiaAlienacaoImobiliaria;

    private boolean contemGarantiaMaquinaEquipamento;

    private boolean contemGarantiaOutros;

    private boolean exibirLupaTotalDuplicataCarteira;

    private boolean exibirBotaoDetalharAnaliseGarantia;
    
    private Integer nuSuat;

    private Integer nuSr;

    private Integer nuUnidade;
    
    private Long nuEmpreendimento;

    private String base64ImagemGrafico;

    private String nomeIndiceLiquidez;

    private String descricaoIndiceLiquidez;

    private transient StreamedContent imagemIndiceLiquidez;

    private AnaliseContrato analiseContrato;

    private AnaliseParecer analiseParecerMaiorInadimplencia;

    private Collection<AnaliseContrato> listaUltimasAnalisesContrato;

    private Collection<AnaliseCartaoCredito> listaCartaoCreditoFluxo;

    private Collection<AnaliseCartaoCredito> listaCartaoCreditoEstoque;

    private Collection<ChequeExcepcionado> listaChequeExcepcionados;
    
    private Boolean possuiSaldoCarteiraDisponivel;
    
    private Collection<SaldoCartaoBandeira> listaSaldoCartaoBandeira;
    
    private Map<BandeiraCartao,Collection<AnaliseCartaoBandeira>> mapaCartaoPorBandeiraEstoque;
    
    private Map<BandeiraCartao,Collection<AnaliseCartaoBandeira>> mapaCartaoPorBandeiraFluxo;
    
    private BigDecimal valorTotalPrevisto;

    private BigDecimal valorTotalRealizado;
    
    private BigDecimal diferencaAcumulada;
    
    private transient List<RelatorioPosicaoRecebiveisHabitacionalVO> listVlPrevistoPorUH;
    
    private transient List<RelatorioPosicaoRecebiveisHabitacionalVO> listVlRealizadoPorUH;
    
    private transient List<RelatorioPosicaoRecebiveisHabitacionalVO> listDiferencaAcumuladaPorUH;
    
    private transient List<VariacaoRecebiveisVO> listVariacaoRecebiveis;
    
    private Date dataFiltroTblVariacao;
    
    private boolean segmentoMPE;
    
    private transient Saldo saldo;
    
    private transient RelatorioHipersuficienciaVO relatorioHipersuficienciaVO;
        
    /**
     * Retorna o valor do atributo codigoCedente.
     *
     * @return codigoCedente
     */
    public String getCodigoCedente() {

        return this.codigoCedente;
    }

    /**
     * Define o valor do atributo codigoCedente.
     *
     * @param codigoCedente
     *            valor a ser atribuído
     */
    public void setCodigoCedente(final String codigoCedente) {

        this.codigoCedente = codigoCedente;
    }

    /**
     * Retorna o valor do atributo listaCedentesDuplicatas.
     *
     * @return listaCedentesDuplicatas
     */
    public Collection<ListaTO> getListaCedentesDuplicatas() {

        return this.listaCedentesDuplicatas;
    }

    /**
     * Define o valor do atributo listaCedentesDuplicatas.
     *
     * @param listaCedentesDuplicatas
     *            valor a ser atribuído
     */
    public void setListaCedentesDuplicatas(final Collection<ListaTO> listaCedentesDuplicatas) {

        this.listaCedentesDuplicatas = listaCedentesDuplicatas;
    }

    /**
     * Retorna o valor do atributo contratoSelecionado.
     *
     * @return contratoSelecionado
     */
    public Contrato getContratoSelecionado() {
        return this.contratoSelecionado;
    }

    /**
     * Define o valor do atributo contratoSelecionado.
     *
     * @param contratoSelecionado
     *            valor a ser atribuído
     */
    public void setContratoSelecionado(final Contrato contratoSelecionado) {
        this.contratoSelecionado = contratoSelecionado;
    }

    /**
     * Retorna o valor do atributo listaContratos.
     *
     * @return listaContratos
     */
    public Collection<Contrato> getListaContratos() {
        return this.listaContratos;
    }

    /**
     * Define o valor do atributo listaContratos.
     *
     * @param listaContratos
     *            valor a ser atribuído
     */
    public void setListaContratos(final Collection<Contrato> listaContratos) {
        this.listaContratos = listaContratos;
    }

    /**
     * Retorna o valor do atributo resultadoParecer.
     *
     * @return resultadoParecer
     */
    public String getResultadoParecer() {
        return this.resultadoParecer;
    }

    /**
     * Define o valor do atributo resultadoParecer.
     *
     * @param resultadoParecer
     *            valor a ser atribuído
     */
    public void setResultadoParecer(final String resultadoParecer) {
        this.resultadoParecer = resultadoParecer;
    }

    /**
     * Retorna o valor do atributo corParecer.
     *
     * @return corParecer
     */
    public String getCorParecer() {
        return this.corParecer;
    }

    /**
     * Define o valor do atributo corParecer.
     *
     * @param corParecer
     *            valor a ser atribuído
     */
    public void setCorParecer(final String corParecer) {
        this.corParecer = corParecer;
    }

    /**
     * Retorna o valor do atributo valorResultadoParecer.
     *
     * @return valorResultadoParecer
     */
    public BigDecimal getValorResultadoParecer() {
        return this.valorResultadoParecer;

    }

    /**
     * Define o valor do atributo valorResultadoParecer.
     *
     * @param valorResultadoParecer
     *            valor a ser atribuído
     */
    public void setValorResultadoParecer(final BigDecimal valorResultadoParecer) {
        this.valorResultadoParecer = valorResultadoParecer;

    }

    /**
     * Retorna o valor do atributo listaDuplicatas.
     *
     * @return listaDuplicatas
     */
    public Collection<Titulo> getListaDuplicatas() {
        return this.listaDuplicatas;

    }

    /**
     * Define o valor do atributo listaDuplicatas.
     *
     * @param listaDuplicatas
     *            valor a ser atribuído
     */
    public void setListaDuplicatas(final Collection<Titulo> listaDuplicatas) {
        this.listaDuplicatas = listaDuplicatas;

    }

    /**
     * Retorna o valor do atributo mostrarDuplicatasValidas.
     *
     * @return mostrarDuplicatasValidas
     */
    public boolean isMostrarDuplicatasValidas() {
        return this.mostrarDuplicatasValidas;

    }

    /**
     * Define o valor do atributo mostrarDuplicatasValidas.
     *
     * @param mostrarDuplicatasValidas
     *            valor a ser atribuído
     */
    public void setMostrarDuplicatasValidas(final boolean mostrarDuplicatasValidas) {
        this.mostrarDuplicatasValidas = mostrarDuplicatasValidas;

    }

    /**
     * Retorna o valor do atributo relatorio.
     *
     * @return relatorio
     */
    public RelatorioAnaliseContratoVO getRelatorio() {
        return this.relatorio;

    }

    /**
     * Define o valor do atributo relatorio.
     *
     * @param relatorio
     *            valor a ser atribuído
     */
    public void setRelatorio(final RelatorioAnaliseContratoVO relatorio) {
        this.relatorio = relatorio;

    }

    /**
     * Retorna o valor do atributo graficoModel.
     *
     * @return graficoModel
     */
    public final CartesianChartModel getGraficoModel() {
        return this.graficoModel;
    }

    /**
     * Define o valor do atributo graficoModel.
     *
     * @param graficoModel
     *            valor a ser atribuído
     */
    public final void setGraficoModel(final CartesianChartModel graficoModel) {
        this.graficoModel = graficoModel;
    }

    /**
     * Retorna o valor do atributo mostrarDuplicatasSacadoValidas.
     *
     * @return <code>mostrarDuplicatasSacadoValidas</code>
     */
    public boolean isMostrarDuplicatasSacadoValidas() {
        return this.mostrarDuplicatasSacadoValidas;
    }

    /**
     * Define o valor do atributo mostrarDuplicatasSacadoValidas.
     *
     * @param mostrarDuplicatasSacadoValidas
     *            valor a ser atribuído
     */
    public void setMostrarDuplicatasSacadoValidas(final boolean mostrarDuplicatasSacadoValidas) {
        this.mostrarDuplicatasSacadoValidas = mostrarDuplicatasSacadoValidas;
    }

    /**
     * Retorna o valor do atributo exibirDialogDuplicatasSacado.
     *
     * @return <code>exibirDialogDuplicatasSacado</code>
     */
    public boolean isExibirDialogDuplicatasSacado() {
        return this.exibirDialogDuplicatasSacado;
    }

    /**
     * Define o valor do atributo exibirDialogDuplicatasSacado.
     *
     * @param exibirDialogDuplicatasSacado
     *            valor a ser atribuído
     */
    public void setExibirDialogDuplicatasSacado(final boolean exibirDialogDuplicatasSacado) {
        this.exibirDialogDuplicatasSacado = exibirDialogDuplicatasSacado;
    }

    /**
     * Retorna o valor do atributo listaDuplicatasSacado.
     *
     * @return <code>listaDuplicatasSacado</code>
     */
    public Collection<Titulo> getListaDuplicatasSacado() {
        return this.listaDuplicatasSacado;
    }

    /**
     * Define o valor do atributo listaDuplicatasSacado.
     *
     * @param listaDuplicatasSacado
     *            valor a ser atribuído
     */
    public void setListaDuplicatasSacado(final Collection<Titulo> listaDuplicatasSacado) {
        this.listaDuplicatasSacado = listaDuplicatasSacado;
    }

    /**
     * Retorna o valor do atributo totalizadorMaiorSacadoSelecionado.
     *
     * @return <code>totalizadorMaiorSacadoSelecionado</code>
     */
    public TotalizadorMaiorSacado getTotalizadorMaiorSacadoSelecionado() {
        return this.totalizadorMaiorSacadoSelecionado;
    }

    /**
     * Define o valor do atributo totalizadorMaiorSacadoSelecionado.
     *
     * @param totalizadorMaiorSacadoSelecionado
     *            valor a ser atribuído
     */
    public void setTotalizadorMaiorSacadoSelecionado(final TotalizadorMaiorSacado totalizadorMaiorSacadoSelecionado) {
        this.totalizadorMaiorSacadoSelecionado = totalizadorMaiorSacadoSelecionado;
    }

    /**
     * Retorna o valor do atributo listaMaioresSacados.
     *
     * @return <code>listaMaioresSacados</code>
     */
    public Collection<TotalizadorMaiorSacado> getListaMaioresSacados() {
    	if (listaMaioresSacados == null) {
    		setListaMaioresSacados(new ArrayList<TotalizadorMaiorSacado>());
    	}
    	
        return this.listaMaioresSacados;
    }

    /**
     * Define o valor do atributo listaMaioresSacados.
     *
     * @param listaMaioresSacados
     *            valor a ser atribuído
     */
    public void setListaMaioresSacados(final Collection<TotalizadorMaiorSacado> listaMaioresSacados) {
        this.listaMaioresSacados = listaMaioresSacados;
    }

    /**
     * Retorna o valor do atributo duplicataInadimplenteVO.
     *
     * @return duplicataInadimplenteVO
     */
    public DuplicataInadimplenteVO getDuplicataInadimplenteVO() {
        if (this.duplicataInadimplenteVO == null) {
            this.duplicataInadimplenteVO = new DuplicataInadimplenteVO();
        }
        return this.duplicataInadimplenteVO;
    }

    /**
     * Define o valor do atributo duplicataInadimplenteVO.
     *
     * @param duplicataInadimplenteVO
     *            valor a ser atribuído
     */
    public void setDuplicataInadimplenteVO(final DuplicataInadimplenteVO duplicataInadimplenteVO) {
        this.duplicataInadimplenteVO = duplicataInadimplenteVO;
    }

    /**
     * Retorna o valor do atributo listaGarantiaContratoDuplicata.
     *
     * @return listaGarantiaContratoDuplicata
     */
    public Collection<GarantiaContrato> getListaGarantiaContratoDuplicata() {

        return this.listaGarantiaContratoDuplicata;
    }

    /**
     * Define o valor do atributo listaGarantiaContratoDuplicata.
     *
     * @param listaGarantiaContratoDuplicata
     *            valor a ser atribuído
     */
    public void setListaGarantiaContratoDuplicata(final Collection<GarantiaContrato> listaGarantiaContratoDuplicata) {

        this.listaGarantiaContratoDuplicata = listaGarantiaContratoDuplicata;
    }

    /**
     * Retorna o valor do atributo listaContaContratoNaoLivreMovimentacao.
     *
     * @return listaContaContratoNaoLivreMovimentacao
     */
    public Collection<ContaContrato> getListaContaContratoNaoLivreMovimentacao() {

        return this.listaContaContratoNaoLivreMovimentacao;
    }

    /**
     * Define o valor do atributo listaContaContratoNaoLivreMovimentacao.
     *
     * @param listaContaContratoNaoLivreMovimentacao
     *            valor a ser atribuído
     */
    public void setListaContaContratoNaoLivreMovimentacao(final Collection<ContaContrato> listaContaContratoNaoLivreMovimentacao) {

        this.listaContaContratoNaoLivreMovimentacao = listaContaContratoNaoLivreMovimentacao;
    }

    /**
     * Retorna o valor do atributo cedente.
     *
     * @return cedente
     */
    public Cedente getCedente() {

        return this.cedente;
    }

    /**
     * Define o valor do atributo cedente.
     *
     * @param cedente
     *            valor a ser atribuído
     */
    public void setCedente(final Cedente cedente) {

        this.cedente = cedente;
    }

    /**
     * Retorna o valor do atributo contemCaracteristicaFluxo.
     *
     * @return contemCaracteristicaFluxo
     */
    public boolean isContemGarantiaCaracteristicaFluxo() {

        return this.contemGarantiaCaracteristicaFluxo;
    }

    /**
     * Define o valor do atributo contemCaracteristicaFluxo.
     *
     * @param contemGarantiaCaracteristicaFluxo
     *            valor a ser atribuído
     */
    public void setContemGarantiaCaracteristicaFluxo(final boolean contemGarantiaCaracteristicaFluxo) {

        this.contemGarantiaCaracteristicaFluxo = contemGarantiaCaracteristicaFluxo;
    }

    /**
     * Retorna o valor do atributo contemCaracteristicaEstoque.
     *
     * @return contemCaracteristicaEstoque
     */
    public boolean isContemGarantiaCaracteristicaEstoque() {

        return this.contemGarantiaCaracteristicaEstoque;
    }

    /**
     * Define o valor do atributo contemCaracteristicaEstoque.
     *
     * @param contemGarantiaCaracteristicaEstoque
     *            valor a ser atribuído
     */
    public void setContemGarantiaCaracteristicaEstoque(final boolean contemGarantiaCaracteristicaEstoque) {

        this.contemGarantiaCaracteristicaEstoque = contemGarantiaCaracteristicaEstoque;
    }

    /**
     * Retorna o valor do atributo contemGarantiaDuplicata.
     *
     * @return contemGarantiaDuplicata
     */
    public boolean isContemGarantiaDuplicata() {

        return this.contemGarantiaDuplicata;
    }

    /**
     * Define o valor do atributo contemGarantiaDuplicata.
     *
     * @param contemGarantiaDuplicata
     *            valor a ser atribuído
     */
    public void setContemGarantiaDuplicata(final boolean contemGarantiaDuplicata) {

        this.contemGarantiaDuplicata = contemGarantiaDuplicata;
    }

    /**
     * Retorna o valor do atributo contemGarantiaCheque.
     *
     * @return contemGarantiaCheque
     */
    public boolean isContemGarantiaCheque() {

        return this.contemGarantiaCheque;
    }

    /**
     * Define o valor do atributo contemGarantiaCheque.
     *
     * @param contemGarantiaCheque
     *            valor a ser atribuído
     */
    public void setContemGarantiaCheque(final boolean contemGarantiaCheque) {

        this.contemGarantiaCheque = contemGarantiaCheque;
    }

    /**
     * Retorna o valor do atributo contemGarantiaCartao.
     *
     * @return contemGarantiaCartao
     */
    public boolean isContemGarantiaCartao() {

        return this.contemGarantiaCartao;
    }

    /**
     * Define o valor do atributo contemGarantiaCartao.
     *
     * @param contemGarantiaCartao
     *            valor a ser atribuído
     */
    public void setContemGarantiaCartao(final boolean contemGarantiaCartao) {

        this.contemGarantiaCartao = contemGarantiaCartao;
    }

    /**
     * Retorna o valor do atributo contemGarantiaAlienacaoVeiculo.
     *
     * @return contemGarantiaAlienacaoVeiculo
     */
    public boolean isContemGarantiaAlienacaoVeiculo() {

        return this.contemGarantiaAlienacaoVeiculo;
    }

    /**
     * Define o valor do atributo contemGarantiaAlienacaoVeiculo.
     *
     * @param contemGarantiaAlienacaoVeiculo
     *            valor a ser atribuído
     */
    public void setContemGarantiaAlienacaoVeiculo(final boolean contemGarantiaAlienacaoVeiculo) {

        this.contemGarantiaAlienacaoVeiculo = contemGarantiaAlienacaoVeiculo;
    }

    /**
     * Retorna o valor do atributo contemGarantiaAlienacaoImobiliaria.
     *
     * @return contemGarantiaAlienacaoImobiliaria
     */
    public boolean isContemGarantiaAlienacaoImobiliaria() {

        return this.contemGarantiaAlienacaoImobiliaria;
    }

    /**
     * Define o valor do atributo contemGarantiaAlienacaoImobiliaria.
     *
     * @param contemGarantiaAlienacaoImobiliaria
     *            valor a ser atribuído
     */
    public void setContemGarantiaAlienacaoImobiliaria(final boolean contemGarantiaAlienacaoImobiliaria) {

        this.contemGarantiaAlienacaoImobiliaria = contemGarantiaAlienacaoImobiliaria;
    }

    /**
     * Retorna o valor do atributo contemGarantiaMaquinaEquipamento.
     *
     * @return contemGarantiaMaquinaEquipamento
     */
    public boolean isContemGarantiaMaquinaEquipamento() {

        return this.contemGarantiaMaquinaEquipamento;
    }

    /**
     * Define o valor do atributo contemGarantiaMaquinaEquipamento.
     *
     * @param contemGarantiaMaquinaEquipamento
     *            valor a ser atribuído
     */
    public void setContemGarantiaMaquinaEquipamento(final boolean contemGarantiaMaquinaEquipamento) {

        this.contemGarantiaMaquinaEquipamento = contemGarantiaMaquinaEquipamento;
    }

    /**
     * Retorna o valor do atributo contemGarantiaOutros.
     *
     * @return contemGarantiaOutros
     */
    public boolean isContemGarantiaOutros() {

        return this.contemGarantiaOutros;
    }

    /**
     * Define o valor do atributo contemGarantiaOutros.
     *
     * @param contemGarantiaOutros
     *            valor a ser atribuído
     */
    public void setContemGarantiaOutros(final boolean contemGarantiaOutros) {

        this.contemGarantiaOutros = contemGarantiaOutros;
    }

    /**
     * Retorna o valor do atributo listaUltimasAnalisesContrato.
     *
     * @return listaUltimasAnalisesContrato
     */
    public Collection<AnaliseContrato> getListaUltimasAnalisesContrato() {
        return this.listaUltimasAnalisesContrato;
    }

    /**
     * Define o valor do atributo listaUltimasAnalisesContrato.
     *
     * @param listaUltimasAnalisesContrato
     *            valor a ser atribuído
     */
    public void setListaUltimasAnalisesContrato(final Collection<AnaliseContrato> listaUltimasAnalisesContrato) {
        this.listaUltimasAnalisesContrato = listaUltimasAnalisesContrato;
    }

    /**
     * Retorna o valor do atributo nuSuat.
     *
     * @return nuSuat
     */
    public Integer getNuSuat() {

        return this.nuSuat;
    }

    /**
     * Define o valor do atributo nuSuat.
     *
     * @param nuSuat
     *            valor a ser atribuído
     */
    public void setNuSuat(final Integer nuSuat) {

        this.nuSuat = nuSuat;
    }

    /**
     * Retorna o valor do atributo nuSr.
     *
     * @return nuSr
     */
    public Integer getNuSr() {

        return this.nuSr;
    }

    /**
     * Define o valor do atributo nuSr.
     *
     * @param nuSr
     *            valor a ser atribuído
     */
    public void setNuSr(final Integer nuSr) {

        this.nuSr = nuSr;
    }

    /**
     * Retorna o valor do atributo nuUnidade.
     *
     * @return nuUnidade
     */
    public Integer getNuUnidade() {

        return this.nuUnidade;
    }

    /**
     * Define o valor do atributo nuUnidade.
     *
     * @param nuUnidade
     *            valor a ser atribuído
     */
    public void setNuUnidade(final Integer nuUnidade) {

        this.nuUnidade = nuUnidade;
    }

    /**
     * Retorna o valor do atributo listaDuplicatasExcepcionadas.
     *
     * @return listaDuplicatasExcepcionadas
     */
    public Collection<DuplicataExcepcionada> getListaDuplicatasExcepcionadas() {
        if (this.listaDuplicatasExcepcionadas == null) {
            this.listaDuplicatasExcepcionadas = new ArrayList<>();
        }
        return this.listaDuplicatasExcepcionadas;
    }

    /**
     * Define o valor do atributo listaDuplicatasExcepcionadas.
     *
     * @param listaDuplicatasExcepcionadas
     *            valor a ser atribuído
     */
    public void setListaDuplicatasExcepcionadas(final Collection<DuplicataExcepcionada> listaDuplicatasExcepcionadas) {

        this.listaDuplicatasExcepcionadas = listaDuplicatasExcepcionadas;
    }

    /**
     * Retorna o valor do atributo totalValorSaldoTotalAplicacaoFinanceira.
     *
     * @return totalValorSaldoTotalAplicacaoFinanceira
     */
    public BigDecimal getTotalValorSaldoTotalAplicacaoFinanceira() {

        return this.totalValorSaldoTotalAplicacaoFinanceira;
    }

    /**
     * Define o valor do atributo totalValorSaldoTotalAplicacaoFinanceira.
     *
     * @param totalValorSaldoTotalAplicacaoFinanceira
     *            valor a ser atribuído
     */
    public void setTotalValorSaldoTotalAplicacaoFinanceira(final BigDecimal totalValorSaldoTotalAplicacaoFinanceira) {

        this.totalValorSaldoTotalAplicacaoFinanceira = totalValorSaldoTotalAplicacaoFinanceira;
    }

    /**
     * Retorna o valor do atributo totalValorSaldoGarantiaAplicacaoFinanceira.
     *
     * @return totalValorSaldoGarantiaAplicacaoFinanceira
     */
    public BigDecimal getTotalValorSaldoGarantiaAplicacaoFinanceira() {

        return this.totalValorSaldoGarantiaAplicacaoFinanceira;
    }

    /**
     * Define o valor do atributo totalValorSaldoGarantiaAplicacaoFinanceira.
     *
     * @param totalValorSaldoGarantiaAplicacaoFinanceira
     *            valor a ser atribuído
     */
    public void setTotalValorSaldoGarantiaAplicacaoFinanceira(final BigDecimal totalValorSaldoGarantiaAplicacaoFinanceira) {

        this.totalValorSaldoGarantiaAplicacaoFinanceira = totalValorSaldoGarantiaAplicacaoFinanceira;
    }

    /**
     * Retorna o valor do atributo contemGarantiaAplicacaoFinanceira.
     *
     * @return contemGarantiaAplicacaoFinanceira
     */
    public boolean isContemGarantiaAplicacaoFinanceira() {

        return this.contemGarantiaAplicacaoFinanceira;
    }

    /**
     * Define o valor do atributo contemGarantiaAplicacaoFinanceira.
     *
     * @param contemGarantiaAplicacaoFinanceira
     *            valor a ser atribuído
     */
    public void setContemGarantiaAplicacaoFinanceira(final boolean contemGarantiaAplicacaoFinanceira) {

        this.contemGarantiaAplicacaoFinanceira = contemGarantiaAplicacaoFinanceira;
    }

    /**
     * Retorna o valor do atributo listaGarantiaAplicacao.
     *
     * @return listaGarantiaAplicacao
     */
    public Collection<GarantiaAplicacao> getListaGarantiaAplicacao() {
        if (this.listaGarantiaAplicacao == null) {
            this.listaGarantiaAplicacao = new ArrayList<GarantiaAplicacao>();
        }

        return this.listaGarantiaAplicacao;
    }

    /**
     * Define o valor do atributo listaGarantiaAplicacao.
     *
     * @param listaGarantiaAplicacao
     *            valor a ser atribuído
     */
    public void setListaGarantiaAplicacao(final Collection<GarantiaAplicacao> listaGarantiaAplicacao) {

        this.listaGarantiaAplicacao = listaGarantiaAplicacao;
    }

    /**
     * Retorna o valor do atributo contratosSelecionados.
     *
     * @return contratosSelecionados
     */
    public Collection<Contrato> getContratosSelecionados() {

        if (this.contratosSelecionados == null) {
            this.contratosSelecionados = new ArrayList<Contrato>();
        }

        return this.contratosSelecionados;
    }

    /**
     * Define o valor do atributo contratosSelecionados.
     *
     * @param contratosSelecionados
     *            valor a ser atribuído
     */
    public void setContratosSelecionados(final Collection<Contrato> contratosSelecionados) {

        this.contratosSelecionados = contratosSelecionados;
    }

    /**
     * Retorna o valor do atributo saldoTotalContaCorrenteNLM.
     *
     * @return saldoTotalContaCorrenteNLM
     */
    public BigDecimal getSaldoTotalContaCorrenteNLM() {
        if (this.saldoTotalContaCorrenteNLM == null) {
            this.saldoTotalContaCorrenteNLM = BigDecimal.ZERO;
        }
        return this.saldoTotalContaCorrenteNLM;
    }

    /**
     * Define o valor do atributo saldoTotalContaCorrenteNLM.
     *
     * @param saldoTotalContaCorrenteNLM
     *            valor a ser atribuído
     */
    public void setSaldoTotalContaCorrenteNLM(final BigDecimal saldoTotalContaCorrenteNLM) {

        this.saldoTotalContaCorrenteNLM = saldoTotalContaCorrenteNLM;

    }

    /**
     * Retorna o valor do atributo cedentesUtilizadosEstoque.
     *
     * @return cedentesUtilizadosEstoque
     */
    public String getCedentesUtilizadosEstoque() {
        return this.cedentesUtilizadosEstoque;
    }

    /**
     * Define o valor do atributo cedentesUtilizadosEstoque.
     *
     * @param cedentesUtilizadosEstoque
     *            valor a ser atribuído
     */
    public void setCedentesUtilizadosEstoque(final String cedentesUtilizadosEstoque) {
        this.cedentesUtilizadosEstoque = cedentesUtilizadosEstoque;
    }

    /**
     * Retorna o valor do atributo cedentesUtilizadosFluxo.
     *
     * @return cedentesUtilizadosFluxo
     */
    public String getCedentesUtilizadosFluxo() {
        return this.cedentesUtilizadosFluxo;
    }

    /**
     * Define o valor do atributo cedentesUtilizadosFluxo.
     *
     * @param cedentesUtilizadosFluxo
     *            valor a ser atribuído
     */
    public void setCedentesUtilizadosFluxo(final String cedentesUtilizadosFluxo) {
        this.cedentesUtilizadosFluxo = cedentesUtilizadosFluxo;
    }

    /**
     * Retorna o valor do atributo exibirBotaoDetalharAnaliseGarantia.
     *
     * @return exibirBotaoDetalharAnaliseGarantia
     */
    public boolean isExibirBotaoDetalharAnaliseGarantia() {

        return this.exibirBotaoDetalharAnaliseGarantia;
    }

    /**
     * Define o valor do atributo exibirBotaoDetalharAnaliseGarantia.
     *
     * @param exibirBotaoDetalharAnaliseGarantia
     *            valor a ser atribuído
     */
    public void setExibirBotaoDetalharAnaliseGarantia(final boolean exibirBotaoDetalharAnaliseGarantia) {

        this.exibirBotaoDetalharAnaliseGarantia = exibirBotaoDetalharAnaliseGarantia;
    }

    /**
     * Retorna o valor do atributo exibirLupaTotalDuplicataCarteira.
     *
     * @return exibirLupaTotalDuplicataCarteira
     */
    public boolean isExibirLupaTotalDuplicataCarteira() {

        return this.exibirLupaTotalDuplicataCarteira;
    }

    /**
     * Define o valor do atributo exibirLupaTotalDuplicataCarteira.
     *
     * @param exibirLupaTotalDuplicataCarteira
     *            valor a ser atribuído
     */
    public void setExibirLupaTotalDuplicataCarteira(final boolean exibirLupaTotalDuplicataCarteira) {

        this.exibirLupaTotalDuplicataCarteira = exibirLupaTotalDuplicataCarteira;
    }

    /**
     * Retorna o valor do atributo listaCartaoCreditoFluxo.
     *
     * @return listaCartaoCreditoFluxo
     */
    public Collection<AnaliseCartaoCredito> getListaCartaoCreditoFluxo() {

        return this.listaCartaoCreditoFluxo;
    }

    /**
     * Define o valor do atributo listaCartaoCreditoFluxo.
     *
     * @param listaCartaoCreditoFluxo
     *            valor a ser atribuído
     */
    public void setListaCartaoCreditoFluxo(final Collection<AnaliseCartaoCredito> listaCartaoCreditoFluxo) {

        this.listaCartaoCreditoFluxo = listaCartaoCreditoFluxo;
    }

    /**
     * Retorna o valor do atributo listaCartaoCreditoEstoque.
     *
     * @return listaCartaoCreditoEstoque
     */
    public Collection<AnaliseCartaoCredito> getListaCartaoCreditoEstoque() {

        return this.listaCartaoCreditoEstoque;
    }

    /**
     * Define o valor do atributo listaCartaoCreditoEstoque.
     *
     * @param listaCartaoCreditoEstoque
     *            valor a ser atribuído
     */
    public void setListaCartaoCreditoEstoque(final Collection<AnaliseCartaoCredito> listaCartaoCreditoEstoque) {

        this.listaCartaoCreditoEstoque = listaCartaoCreditoEstoque;
    }

    /**
     * Retorna o valor do atributo listaChequeExcepcionados.
     *
     * @return listaChequeExcepcionados
     */
    public Collection<ChequeExcepcionado> getListaChequeExcepcionados() {
        if (null == this.listaChequeExcepcionados) {
            this.listaChequeExcepcionados = new ArrayList<>();
        }
        return this.listaChequeExcepcionados;
    }

    /**
     * Define o valor do atributo listaChequeExcepcionados.
     *
     * @param listaChequeExcepcionados
     *            valor a ser atribuído
     */
    public void setListaChequeExcepcionados(final Collection<ChequeExcepcionado> listaChequeExcepcionados) {

        this.listaChequeExcepcionados = listaChequeExcepcionados;
    }


    /**
     * Retorna o valor do atributo valorResultadoParecerTotal.
     *
     * @return valorResultadoParecerTotal
     */
    public BigDecimal getValorResultadoParecerTotal() {

        return this.valorResultadoParecerTotal;
    }

    /**
     * Define o valor do atributo valorResultadoParecerTotal.
     *
     * @param valorResultadoParecerTotal
     *            valor a ser atribuído
     */
    public void setValorResultadoParecerTotal(final BigDecimal valorResultadoParecerTotal) {

        this.valorResultadoParecerTotal = valorResultadoParecerTotal;
    }

    /**
     * Retorna o valor do atributo contemGarantiaCartaoFluxo.
     *
     * @return contemGarantiaCartaoFluxo
     */
    public boolean isContemGarantiaCartaoFluxo() {

        return this.contemGarantiaCartaoFluxo;
    }

    /**
     * Define o valor do atributo contemGarantiaCartaoFluxo.
     *
     * @param contemGarantiaCartaoFluxo
     *            valor a ser atribuído
     */
    public void setContemGarantiaCartaoFluxo(final boolean contemGarantiaCartaoFluxo) {

        this.contemGarantiaCartaoFluxo = contemGarantiaCartaoFluxo;
    }

    /**
     * Retorna o valor do atributo contemGarantiaCartaoEstoque.
     *
     * @return contemGarantiaCartaoEstoque
     */
    public boolean isContemGarantiaCartaoEstoque() {

        return this.contemGarantiaCartaoEstoque;
    }

    /**
     * Define o valor do atributo contemGarantiaCartaoEstoque.
     *
     * @param contemGarantiaCartaoEstoque
     *            valor a ser atribuído
     */
    public void setContemGarantiaCartaoEstoque(final boolean contemGarantiaCartaoEstoque) {

        this.contemGarantiaCartaoEstoque = contemGarantiaCartaoEstoque;
    }

    /**
     * Retorna o valor do atributo base64ImagemGrafico.
     *
     * @return base64ImagemGrafico
     */
    public String getBase64ImagemGrafico() {

        return this.base64ImagemGrafico;
    }

    /**
     * Define o valor do atributo base64ImagemGrafico.
     *
     * @param base64ImagemGrafico
     *            valor a ser atribuído
     */
    public void setBase64ImagemGrafico(final String base64ImagemGrafico) {

        this.base64ImagemGrafico = base64ImagemGrafico;
    }

    /**
     * Retorna o valor do atributo corParecerTotal.
     *
     * @return corParecerTotal
     */
    public String getCorParecerTotal() {

        return this.corParecerTotal;
    }

    /**
     * Define o valor do atributo corParecerTotal.
     *
     * @param corParecerTotal
     *            valor a ser atribuído
     */
    public void setCorParecerTotal(final String corParecerTotal) {

        this.corParecerTotal = corParecerTotal;
    }

    /**
     * Retorna o valor do atributo resultadoParecerTotal.
     *
     * @return resultadoParecerTotal
     */
    public String getResultadoParecerTotal() {

        return this.resultadoParecerTotal;
    }

    /**
     * Define o valor do atributo resultadoParecerTotal.
     *
     * @param resultadoParecerTotal
     *            valor a ser atribuído
     */
    public void setResultadoParecerTotal(final String resultadoParecerTotal) {

        this.resultadoParecerTotal = resultadoParecerTotal.concat(this.getDiasInadimplencia());
    }

    /**
     * <p>
     * Método responsável por retornar a diferença em dias da garantia
     * insuficiente mais antiga.
     * <p>
     *
     * @return String
     * @author guilherme.santos
     */
    public String getDiasInadimplencia() {
        String retorno = "";

        if (this.getAnaliseParecerMaiorInadimplencia() != null) {
            retorno = " (" + CalculadoraInadimplenciaUtil
                    .getDescricaoInicioInadimplencia(this.getAnaliseParecerMaiorInadimplencia().getDtInicioInadimplencia()) + ")";
        }

        return retorno;
    }

    /**
     * <p>
     * Método responsável por consultar e registrar a maior inadimplencia.
     * <p>
     *
     * @author guilherme.santos
     */
    public void consultarMaiorInadimplencia() {
        AnaliseParecer maiorInadimplencia = null;

        for (final AnaliseParecer analiseParecer : this.getEntidade().getAnaliseParecerList()) {
            if (analiseParecer.getDtInicioInadimplencia() != null && (maiorInadimplencia == null
                    || UtilData.verificarSeDataEhMenor(analiseParecer.getDtInicioInadimplencia(), maiorInadimplencia.getDtInicioInadimplencia()))) {
                maiorInadimplencia = analiseParecer;
            }
        }

        this.setAnaliseParecerMaiorInadimplencia(maiorInadimplencia);
    }

    /**
     * Retorna o valor do atributo analiseContrato.
     *
     * @return analiseContrato
     */
    public AnaliseContrato getAnaliseContrato() {

        return this.analiseContrato;
    }

    /**
     * Define o valor do atributo analiseContrato.
     *
     * @param analiseContrato
     *            valor a ser atribuído
     */
    public void setAnaliseContrato(final AnaliseContrato analiseContrato) {

        this.analiseContrato = analiseContrato;
    }

    /**
     * Retorna o valor do atributo nomeIndiceLiquidez.
     *
     * @return nomeIndiceLiquidez
     */
    public String getNomeIndiceLiquidez() {

        return this.nomeIndiceLiquidez;
    }

    /**
     * Define o valor do atributo nomeIndiceLiquidez.
     *
     * @param nomeIndiceLiquidez
     *            valor a ser atribuído
     */
    public void setNomeIndiceLiquidez(final String nomeIndiceLiquidez) {

        this.nomeIndiceLiquidez = nomeIndiceLiquidez;
    }

    /**
     * Retorna o valor do atributo descricaoIndiceLiquidez.
     *
     * @return descricaoIndiceLiquidez
     */
    public String getDescricaoIndiceLiquidez() {

        return this.descricaoIndiceLiquidez;
    }

    /**
     * Define o valor do atributo descricaoIndiceLiquidez.
     *
     * @param descricaoIndiceLiquidez
     *            valor a ser atribuído
     */
    public void setDescricaoIndiceLiquidez(final String descricaoIndiceLiquidez) {

        this.descricaoIndiceLiquidez = descricaoIndiceLiquidez;
    }

    /**
     * Retorna o valor do atributo imagemIndiceLiquidez.
     *
     * @return imagemIndiceLiquidez
     */
    public StreamedContent getImagemIndiceLiquidez() {

        return this.imagemIndiceLiquidez;
    }

    /**
     * Define o valor do atributo imagemIndiceLiquidez.
     *
     * @param imagemIndiceLiquidez
     *            valor a ser atribuído
     */
    public void setImagemIndiceLiquidez(final StreamedContent imagemIndiceLiquidez) {

        this.imagemIndiceLiquidez = imagemIndiceLiquidez;
    }

    /**
     * <p>
     * Método responsável por consultar no contrato selecionado GarantiaContrato
     * com caracteristica de Estoque.
     * <p>
     *
     * @return GarantiaContrato
     * @author guilherme.santos
     */
    public GarantiaContrato getGarantiaContratoDuplicataEstoque() {
        GarantiaContrato garantiaDuplicataEstoque = null;

        for (final GarantiaContrato garantiaContrato : this.getListaGarantiaContratoDuplicata()) {
            if (garantiaContrato.isGarantiaDuplicata()
                    && garantiaContrato.getIcCaracteristica().getChave().equals(CaracteristicaEnum.ESTOQUE.getChave())) {
                garantiaDuplicataEstoque = garantiaContrato;
                break;
            }
        }

        return garantiaDuplicataEstoque;
    }

    /**
     * Retorna o valor do atributo listaSacadoExcepcionadoVO.
     *
     * @return listaSacadoExcepcionadoVO
     */
    public Collection<SacadoExcepcionadoVO> getListaSacadoExcepcionadoVO() {
        if (this.listaSacadoExcepcionadoVO == null) {
            this.listaSacadoExcepcionadoVO = new ArrayList<>();
        }

        return this.listaSacadoExcepcionadoVO;
    }

    /**
     * Define o valor do atributo listaSacadoExcepcionadoVO.
     *
     * @param listaSacadoExcepcionadoVO
     *            valor a ser atribuído
     */
    public void setListaSacadoExcepcionadoVO(final Collection<SacadoExcepcionadoVO> listaSacadoExcepcionadoVO) {

        this.listaSacadoExcepcionadoVO = listaSacadoExcepcionadoVO;
    }

    /**
     * Retorna o valor do atributo analiseParecerMaiorInadimplencia.
     *
     * @return analiseParecerMaiorInadimplencia
     */
    public AnaliseParecer getAnaliseParecerMaiorInadimplencia() {

        return this.analiseParecerMaiorInadimplencia;
    }

    /**
     * Define o valor do atributo analiseParecerMaiorInadimplencia.
     *
     * @param analiseParecerMaiorInadimplencia
     *            valor a ser atribuído
     */
    public void setAnaliseParecerMaiorInadimplencia(final AnaliseParecer analiseParecerMaiorInadimplencia) {

        this.analiseParecerMaiorInadimplencia = analiseParecerMaiorInadimplencia;
    }

	/**
	 * <p>Retorna o valor do atributo possuiSaldoCarteiraDisponivel</p>.
	 *
	 * @return possuiSaldoCarteiraDisponivel
	*/
	public Boolean getPossuiSaldoCarteiraDisponivel() {
		return this.possuiSaldoCarteiraDisponivel;
	}

	/**
	 * <p>Define o valor do atributo possuiSaldoCarteiraDisponivel</p>.
	 *
	 * @param possuiSaldoCarteiraDisponivel valor a ser atribuído
	*/
	public void setPossuiSaldoCarteiraDisponivel(Boolean possuiSaldoCarteiraDisponivel) {
		this.possuiSaldoCarteiraDisponivel = possuiSaldoCarteiraDisponivel;
	}

	/**
	 * <p>Retorna o valor do atributo listaSaldoCartaoBandeira</p>.
	 *
	 * @return listaSaldoCartaoBandeira
	*/
	public Collection<SaldoCartaoBandeira> getListaSaldoCartaoBandeira() {
		if (this.listaSaldoCartaoBandeira == null) {
			this.listaSaldoCartaoBandeira = new ArrayList<>();
		}
		return this.listaSaldoCartaoBandeira;
	}

	/**
	 * <p>Define o valor do atributo listaSaldoCartaoBandeira</p>.
	 *
	 * @param listaSaldoCartaoBandeira valor a ser atribuído
	*/
	public void setListaSaldoCartaoBandeira(Collection<SaldoCartaoBandeira> listaSaldoCartaoBandeira) {
		this.listaSaldoCartaoBandeira = listaSaldoCartaoBandeira;
	}

	/**
	 * <p>Retorna o valor do atributo mapaCartaoPorBandeiraEstoque</p>.
	 *
	 * @return mapaCartaoPorBandeiraEstoque
	*/
	public Map<BandeiraCartao, Collection<AnaliseCartaoBandeira>> getMapaCartaoPorBandeiraEstoque() {
		return this.mapaCartaoPorBandeiraEstoque;
	}

	/**
	 * <p>Define o valor do atributo mapaCartaoPorBandeiraEstoque</p>.
	 *
	 * @param mapaCartaoPorBandeiraEstoque valor a ser atribuído
	*/
	public void setMapaCartaoPorBandeiraEstoque(
			Map<BandeiraCartao, Collection<AnaliseCartaoBandeira>> mapaCartaoPorBandeiraEstoque) {
		this.mapaCartaoPorBandeiraEstoque = mapaCartaoPorBandeiraEstoque;
	}

	/**
	 * <p>Retorna o valor do atributo mapaCartaoPorBandeiraFluxo</p>.
	 *
	 * @return mapaCartaoPorBandeiraFluxo
	*/
	public Map<BandeiraCartao, Collection<AnaliseCartaoBandeira>> getMapaCartaoPorBandeiraFluxo() {
		return this.mapaCartaoPorBandeiraFluxo;
	}

	/**
	 * <p>Define o valor do atributo mapaCartaoPorBandeiraFluxo</p>.
	 *
	 * @param mapaCartaoPorBandeiraFluxo valor a ser atribuído
	*/
	public void setMapaCartaoPorBandeiraFluxo(
			Map<BandeiraCartao, Collection<AnaliseCartaoBandeira>> mapaCartaoPorBandeiraFluxo) {
		this.mapaCartaoPorBandeiraFluxo = mapaCartaoPorBandeiraFluxo;
	}

	/**
	 * <p>Retorna o valor do atributo valorTotalPrevisto</p>.
	 *
	 * @return valorTotalPrevisto
	*/
	public BigDecimal getValorTotalPrevisto() {
		return this.valorTotalPrevisto;
	}

	/**
	 * <p>Define o valor do atributo valorTotalPrevisto</p>.
	 *
	 * @param valorTotalPrevisto valor a ser atribuído
	*/
	public void setValorTotalPrevisto(BigDecimal valorTotalPrevisto) {
	this.valorTotalPrevisto = valorTotalPrevisto;}

	/**
	 * <p>Retorna o valor do atributo valorTotalRealizado</p>.
	 *
	 * @return valorTotalRealizado
	*/
	public BigDecimal getValorTotalRealizado() {
		return this.valorTotalRealizado;
	}

	/**
	 * <p>Define o valor do atributo valorTotalRealizado</p>.
	 *
	 * @param valorTotalRealizado valor a ser atribuído
	*/
	public void setValorTotalRealizado(BigDecimal valorTotalRealizado) {
	this.valorTotalRealizado = valorTotalRealizado;}

	/**
	 * <p>Retorna o valor do atributo diferencaAcumulada</p>.
	 *
	 * @return diferencaAcumulada
	*/
	public BigDecimal getDiferencaAcumulada() {
		return this.diferencaAcumulada;
	}

	/**
	 * <p>Define o valor do atributo diferencaAcumulada</p>.
	 *
	 * @param diferencaAcumulada valor a ser atribuído
	*/
	public void setDiferencaAcumulada(BigDecimal diferencaAcumulada) {
	this.diferencaAcumulada = diferencaAcumulada;}

	/**
	 * <p>Retorna o valor do atributo listVlPrevistoPorUH</p>.
	 *
	 * @return listVlPrevistoPorUH
	*/
	public List<RelatorioPosicaoRecebiveisHabitacionalVO> getListVlPrevistoPorUH() {
		return this.listVlPrevistoPorUH;
	}

	/**
	 * <p>Define o valor do atributo listVlPrevistoPorUH</p>.
	 *
	 * @param listVlPrevistoPorUH valor a ser atribuído
	*/
	public void setListVlPrevistoPorUH(List<RelatorioPosicaoRecebiveisHabitacionalVO> listVlPrevistoPorUH) {
	this.listVlPrevistoPorUH = listVlPrevistoPorUH;}

	/**
	 * <p>Retorna o valor do atributo listVlRealizadoPorUH</p>.
	 *
	 * @return listVlRealizadoPorUH
	*/
	public List<RelatorioPosicaoRecebiveisHabitacionalVO> getListVlRealizadoPorUH() {
		return this.listVlRealizadoPorUH;
	}

	/**
	 * <p>Define o valor do atributo listVlRealizadoPorUH</p>.
	 *
	 * @param listVlRealizadoPorUH valor a ser atribuído
	*/
	public void setListVlRealizadoPorUH(List<RelatorioPosicaoRecebiveisHabitacionalVO> listVlRealizadoPorUH) {
	this.listVlRealizadoPorUH = listVlRealizadoPorUH;}

	/**
	 * <p>Retorna o valor do atributo listDiferencaAcumuladaPorUH</p>.
	 *
	 * @return listDiferencaAcumuladaPorUH
	*/
	public List<RelatorioPosicaoRecebiveisHabitacionalVO> getListDiferencaAcumuladaPorUH() {
		return this.listDiferencaAcumuladaPorUH;
	}

	/**
	 * <p>Define o valor do atributo listDiferencaAcumuladaPorUH</p>.
	 *
	 * @param listDiferencaAcumuladaPorUH valor a ser atribuído
	*/
	public void setListDiferencaAcumuladaPorUH(List<RelatorioPosicaoRecebiveisHabitacionalVO> listDiferencaAcumuladaPorUH) {
	this.listDiferencaAcumuladaPorUH = listDiferencaAcumuladaPorUH;}

	/**
	 * <p>Retorna o valor do atributo listVariacaoRecebiveis</p>.
	 *
	 * @return listVariacaoRecebiveis
	*/
	public List<VariacaoRecebiveisVO> getListVariacaoRecebiveis() {
		return this.listVariacaoRecebiveis;
	}

	/**
	 * <p>Define o valor do atributo listVariacaoRecebiveis</p>.
	 *
	 * @param listVariacaoRecebiveis valor a ser atribuído
	*/
	public void setListVariacaoRecebiveis(List<VariacaoRecebiveisVO> listVariacaoRecebiveis) {
	this.listVariacaoRecebiveis = listVariacaoRecebiveis;}

	/**
	 * <p>Retorna o valor do atributo dataFiltroTblVariacao</p>.
	 *
	 * @return dataFiltroTblVariacao
	*/
	public Date getDataFiltroTblVariacao() {
		return this.dataFiltroTblVariacao;
	}

	/**
	 * <p>Define o valor do atributo dataFiltroTblVariacao</p>.
	 *
	 * @param dataFiltroTblVariacao valor a ser atribuído
	*/
	public void setDataFiltroTblVariacao(Date dataFiltroTblVariacao) {
	this.dataFiltroTblVariacao = dataFiltroTblVariacao;}

	/**
	 * <p>Retorna o valor do atributo nuEmpreendimento</p>.
	 *
	 * @return nuEmpreendimento
	*/
	public Long getNuEmpreendimento() {
		return this.nuEmpreendimento;
	}

	/**
	 * <p>Define o valor do atributo nuEmpreendimento</p>.
	 *
	 * @param nuEmpreendimento valor a ser atribuído
	*/
	public void setNuEmpreendimento(Long nuEmpreendimento) {
	this.nuEmpreendimento = nuEmpreendimento;}

	/**
	 * <p>Retorna o valor do atributo graficoModelIgr</p>.
	 *
	 * @return graficoModelIgr
	*/
	public CartesianChartModel getGraficoModelIgr() {
		return this.graficoModelIgr;
	}

	/**
	 * <p>Define o valor do atributo graficoModelIgr</p>.
	 *
	 * @param graficoModelIgr valor a ser atribuído
	*/
	public void setGraficoModelIgr(CartesianChartModel graficoModelIgr) {
	this.graficoModelIgr = graficoModelIgr;}

	/**
	 * <p>Retorna o valor do atributo segmentoMPE</p>.
	 *
	 * @return segmentoMPE
	*/
	public boolean isSegmentoMPE() {
	    return this.segmentoMPE;
	}

	/**
	 * <p>Define o valor do atributo segmentoMPE</p>.
	 *
	 * @param segmentoMPE valor a ser atribuído
	*/
	public void setSegmentoMPE(boolean segmentoMPE) {
	    this.segmentoMPE = segmentoMPE;
	}
		
	/**
	 * <p>Retorna o valor do atributo titulosHabitacionais</p>.
	 *
	 * @return titulosHabitacionais
	*/
	public Collection<Titulo> getTitulosHabitacionais() {
		if (titulosHabitacionais == null) {
			setTitulosHabitacionais(new ArrayList<Titulo>());
		}
		return this.titulosHabitacionais;
	}

	/**
	 * <p>Define o valor do atributo titulosHabitacionais</p>.
	 *
	 * @param titulosHabitacionais valor a ser atribuído
	*/
	public void setTitulosHabitacionais(Collection<Titulo> titulosHabitacionais) {
		this.titulosHabitacionais = titulosHabitacionais;
	}
	
	public BigDecimal getValorDuplicatasHabitacional() {
		BigDecimal valorDuplicatasHabitacional = BigDecimal.ZERO;
		
		for (Titulo titulo : getTitulosHabitacionais()) {
			valorDuplicatasHabitacional = titulo.getVrPago().add(valorDuplicatasHabitacional);
		}

		return valorDuplicatasHabitacional;
	}
	public Saldo getSaldo() {
		return saldo;
	}

	/**
	 * <p>Define o valor do atributo saldo</p>.
	 *
	 * @param saldo valor a ser atribuído
	*/
	public void setSaldo(Saldo saldo) {
		this.saldo = saldo;
	}

	public RelatorioHipersuficienciaVO getRelatorioHipersuficienciaVO() {
		return relatorioHipersuficienciaVO;
	}

	/**
	 * <p>Define o valor do atributo relatorioHipersuficienciaVO</p>.
	 *
	 * @param relatorioHipersuficienciaVO valor a ser atribuído
	*/
	public void setRelatorioHipersuficienciaVO(RelatorioHipersuficienciaVO relatorioHipersuficienciaVO) {
		this.relatorioHipersuficienciaVO = relatorioHipersuficienciaVO;
	}

}