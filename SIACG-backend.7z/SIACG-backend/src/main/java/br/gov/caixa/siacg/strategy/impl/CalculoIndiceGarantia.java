package br.gov.caixa.siacg.strategy.impl;

import java.math.BigDecimal;

import javax.ejb.EJB;
import javax.ejb.Stateless;

import br.gov.caixa.siacg.model.domain.Empreendimento;
import br.gov.caixa.siacg.model.vo.ParametrosCalculoGarantiaVO;
import br.gov.caixa.siacg.model.vo.RelatorioAnaliseContratoVO;
import br.gov.caixa.siacg.service.EmpreendimentoService;
import br.gov.caixa.siacg.service.ProspectoService;
import br.gov.caixa.siacg.service.TipologiaService;
import br.gov.caixa.siacg.strategy.CalculoGarantia;

/**
 * 
 * <p>
 * CalculoIndiceGarantia
 * </p>
 *
 * <p>
 * Descrição: Descrição do tipo
 * </p>
 *
 * <br>
 * <b>Empresa:</b> Cef - Caixa Econômica Federal
 *
 *
 * @author p566506
 *
 * @version 1.0
 */
@Stateless(mappedName = "CalculoIndiceGarantia")
public class CalculoIndiceGarantia implements CalculoGarantia {

    private static final long serialVersionUID = 7170040531431287763L;

    @EJB
    private TipologiaService tipologiaService;

    @EJB
    private EmpreendimentoService empreendimentoService;

    @EJB
    private ProspectoService prospectoService;

    /**
     * 
     * @see br.gov.caixa.siacg.strategy.CalculoGarantia#calcular(br.gov.caixa.siacg.model.vo.ParametrosCalculoGarantiaVO,
     *      br.gov.caixa.siacg.model.vo.RelatorioAnaliseContratoVO)
     */
    @Override
    public RelatorioAnaliseContratoVO calcular(ParametrosCalculoGarantiaVO parametrosCalculo, RelatorioAnaliseContratoVO relatorio) {
	Empreendimento empreendimento = empreendimentoService
		.consultarEmpreendimentoPorNuContrato(parametrosCalculo.getGarantiaContrato().getContrato().getNuContrato());
	BigDecimal vlrAvaliacaoUhHipotecadas = this.tipologiaService.valorAtualizadoTipologiaPorEmpreendimento(empreendimento);
	BigDecimal vlrPenhorRecebiveis = this.prospectoService.valorPenhorRecebiveis(empreendimento);

	relatorio.setValorApurado(realizarCalculo(vlrAvaliacaoUhHipotecadas, vlrPenhorRecebiveis));

	return relatorio;
    }

    /**
     * 
     * <p>
     * Método responsável por
     * </p>
     * .
     *
     * @author p566506
     *
     * @param vlrAvaliacaoUhHipotecadas
     * @param vlrPenhorRecebiveis
     * @return
     */
    private BigDecimal realizarCalculo(BigDecimal vlrAvaliacaoUhHipotecadas, BigDecimal vlrPenhorRecebiveis) {
	return vlrAvaliacaoUhHipotecadas.add(vlrPenhorRecebiveis);
    }

}
