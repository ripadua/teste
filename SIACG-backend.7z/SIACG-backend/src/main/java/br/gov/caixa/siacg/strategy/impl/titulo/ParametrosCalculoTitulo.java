/**
 * Copyright (c) 2018 Caixa Econômica Federal. Todos os direitos
 * reservados.
 *
 * Caixa Econômica Federal - SIACG
 *
 * Este software foi desenvolvido sob demanda da CAIXA e está
 * protegido por leis de direitos autorais e tratados internacionais. As
 * condições de cópia e utilização total ou partes dependem de autorização da
 * empresa. Cópias não são permitidas sem expressa autorização. Não pode ser
 * comercializado ou utilizado para propósitos particulares.
 *
 * Uso exclusivo da Caixa Econômica Federal. A reprodução ou distribuição não
 * autorizada deste programa ou de parte dele, resultará em punições civis e
 * criminais e os infratores incorrem em sanções previstas na legislação em
 * vigor.
 *
 * Histórico do TFS:
 *
 * LastChangedRevision: $Revision$
 * LastChangedBy: $Author$
 * LastChangedDate: $Date$
 *
 * HeadURL: $HeadURL$
 *
 */
package br.gov.caixa.siacg.strategy.impl.titulo;

import java.math.BigDecimal;
import java.util.Collection;

import br.gov.caixa.pedesgo.arquitetura.to.FeriadoTO;
import br.gov.caixa.siacg.comum.to.ContratoCalculoTO;
import br.gov.caixa.siacg.comum.to.GarantiaContratoCalculoTO;
import br.gov.caixa.siacg.model.domain.DuplicataExcepcionada;
import br.gov.caixa.siacg.model.vo.RelatorioAnaliseContratoVO;

/**
 * <p>
 * ParametrosCalculoTituloAVencer
 * </p>
 *
 * <p>
 * Descrição: Parametros a passar para o calculo de titulos a vencer
 * </p>
 *
 * <br>
 * <b>Empresa:</b> Cef - Caixa Econômica Federal
 *
 *
 * @author p541915
 *
 * @version 1.0
 */
public class ParametrosCalculoTitulo {

	/** Atributo relatorio. */
	private RelatorioAnaliseContratoVO relatorio;

	/** Atributo contrato. */
	private ContratoCalculoTO contrato;

	/** Atributo garantiaContrato. */
	private GarantiaContratoCalculoTO garantiaContrato;

	/** Atributo listaFeriado. */
	private Collection<FeriadoTO> listaFeriado;

	/** Atributo prazoMaximo. */
	private Integer prazoMaximo;

	/** Atributo ufContrato. */
	private String ufContrato;

	/** Atributo valorMaximo. */
	private BigDecimal valorMaximo;

	/** Atributo valorTotalPermitido. */
	private BigDecimal valorTotalPermitido;

	/** Atributo vrEsperado. */
	private BigDecimal vrEsperado;

	/** Atributo percentualMaximo. */
	private BigDecimal percentualMaximo;

	/** Atributo listaTituloExcepcionado. */
	private Collection<DuplicataExcepcionada> listaDuplicataExcepcionada;
	
	/** Atributo qtdDiasFluxo. */
	private Integer qtdDiasFluxo;

	/**
	 * Responsável pela criação de novas instâncias desta classe.
	 *
	 * @param contrato
	 * @param analiseContrato
	 * @param garantiaContrato
	 * @param listaFeriado
	 * @param prazoMaximo
	 * @param ufContrato
	 * @param valorMaximo
	 * @param valorTotalPermitido
	 * @param vrApurado
	 * @param vrEsperado
	 * @param percentualMaximo
	 * @param listaDuplicataExcepcionada
	 *
	 */
	public ParametrosCalculoTitulo(RelatorioAnaliseContratoVO relatorio, GarantiaContratoCalculoTO garantiaContrato,
			Collection<FeriadoTO> listaFeriado, Integer prazoMaximo, String ufContrato, BigDecimal valorMaximo,
			BigDecimal valorTotalPermitido, BigDecimal vrEsperado, BigDecimal percentualMaximo,
			Collection<DuplicataExcepcionada> listaDuplicataExcepcionada, Integer qtdDiasFluxo) {
		this.relatorio = relatorio;
		this.contrato = garantiaContrato.getContrato();
		this.garantiaContrato = garantiaContrato;
		this.listaFeriado = listaFeriado;
		this.prazoMaximo = prazoMaximo;
		this.ufContrato = ufContrato;
		this.valorMaximo = valorMaximo;
		this.valorTotalPermitido = valorTotalPermitido;
		this.vrEsperado = vrEsperado;
		this.percentualMaximo = percentualMaximo;
		this.listaDuplicataExcepcionada = listaDuplicataExcepcionada;
		this.qtdDiasFluxo = qtdDiasFluxo;
	}

	/**
	 * <p>
	 * Retorna o valor do atributo relatorio
	 * </p>
	 * .
	 *
	 * @return relatorio
	 */
	public RelatorioAnaliseContratoVO getRelatorio() {
		return this.relatorio;
	}

	/**
	 * <p>
	 * Define o valor do atributo relatorio
	 * </p>
	 * .
	 *
	 * @param relatorio
	 *            valor a ser atribuído
	 */
	public void setRelatorio(RelatorioAnaliseContratoVO relatorio) {
		this.relatorio = relatorio;
	}

	/**
	 * <p>
	 * Retorna o valor do atributo contrato
	 * </p>
	 * .
	 *
	 * @return contrato
	 */
	public ContratoCalculoTO getContrato() {
		return this.contrato;
	}

	/**
	 * <p>
	 * Define o valor do atributo contrato
	 * </p>
	 * .
	 *
	 * @param contrato
	 *            valor a ser atribuído
	 */
	public void setContrato(ContratoCalculoTO contrato) {
		this.contrato = contrato;
	}

	/**
	 * <p>
	 * Retorna o valor do atributo garantiaContrato
	 * </p>
	 * .
	 *
	 * @return garantiaContrato
	 */
	public GarantiaContratoCalculoTO getGarantiaContrato() {
		return this.garantiaContrato;
	}

	/**
	 * <p>
	 * Define o valor do atributo garantiaContrato
	 * </p>
	 * .
	 *
	 * @param garantiaContrato
	 *            valor a ser atribuído
	 */
	public void setGarantiaContrato(GarantiaContratoCalculoTO garantiaContrato) {
		this.garantiaContrato = garantiaContrato;
	}

	/**
	 * <p>
	 * Retorna o valor do atributo listaFeriado
	 * </p>
	 * .
	 *
	 * @return listaFeriado
	 */
	public Collection<FeriadoTO> getListaFeriado() {
		return this.listaFeriado;
	}

	/**
	 * <p>
	 * Define o valor do atributo listaFeriado
	 * </p>
	 * .
	 *
	 * @param listaFeriado
	 *            valor a ser atribuído
	 */
	public void setListaFeriado(Collection<FeriadoTO> listaFeriado) {
		this.listaFeriado = listaFeriado;
	}

	/**
	 * <p>
	 * Retorna o valor do atributo prazoMaximo
	 * </p>
	 * .
	 *
	 * @return prazoMaximo
	 */
	public Integer getPrazoMaximo() {
		return this.prazoMaximo;
	}

	/**
	 * <p>
	 * Define o valor do atributo prazoMaximo
	 * </p>
	 * .
	 *
	 * @param prazoMaximo
	 *            valor a ser atribuído
	 */
	public void setPrazoMaximo(Integer prazoMaximo) {
		this.prazoMaximo = prazoMaximo;
	}

	/**
	 * <p>
	 * Retorna o valor do atributo ufContrato
	 * </p>
	 * .
	 *
	 * @return ufContrato
	 */
	public String getUfContrato() {
		return this.ufContrato;
	}

	/**
	 * <p>
	 * Define o valor do atributo ufContrato
	 * </p>
	 * .
	 *
	 * @param ufContrato
	 *            valor a ser atribuído
	 */
	public void setUfContrato(String ufContrato) {
		this.ufContrato = ufContrato;
	}

	/**
	 * <p>
	 * Retorna o valor do atributo valorMaximo
	 * </p>
	 * .
	 *
	 * @return valorMaximo
	 */
	public BigDecimal getValorMaximo() {
		return this.valorMaximo;
	}

	/**
	 * <p>
	 * Define o valor do atributo valorMaximo
	 * </p>
	 * .
	 *
	 * @param valorMaximo
	 *            valor a ser atribuído
	 */
	public void setValorMaximo(BigDecimal valorMaximo) {
		this.valorMaximo = valorMaximo;
	}

	/**
	 * <p>
	 * Retorna o valor do atributo valorTotalPermitido
	 * </p>
	 * .
	 *
	 * @return valorTotalPermitido
	 */
	public BigDecimal getValorTotalPermitido() {
		return this.valorTotalPermitido;
	}

	/**
	 * <p>
	 * Define o valor do atributo valorTotalPermitido
	 * </p>
	 * .
	 *
	 * @param valorTotalPermitido
	 *            valor a ser atribuído
	 */
	public void setValorTotalPermitido(BigDecimal valorTotalPermitido) {
		this.valorTotalPermitido = valorTotalPermitido;
	}

	/**
	 * <p>
	 * Retorna o valor do atributo vrEsperado
	 * </p>
	 * .
	 *
	 * @return vrEsperado
	 */
	public BigDecimal getVrEsperado() {
		return this.vrEsperado;
	}

	/**
	 * <p>
	 * Define o valor do atributo vrEsperado
	 * </p>
	 * .
	 *
	 * @param vrEsperado
	 *            valor a ser atribuído
	 */
	public void setVrEsperado(BigDecimal vrEsperado) {
		this.vrEsperado = vrEsperado;
	}

	/**
	 * <p>
	 * Retorna o valor do atributo listaDuplicataExcepcionada
	 * </p>
	 * .
	 *
	 * @return listaDuplicataExcepcionada
	 */
	public Collection<DuplicataExcepcionada> getListaDuplicataExcepcionada() {
		return this.listaDuplicataExcepcionada;
	}

	/**
	 * <p>
	 * Define o valor do atributo listaDuplicataExcepcionada
	 * </p>
	 * .
	 *
	 * @param listaDuplicataExcepcionada
	 *            valor a ser atribuído
	 */
	public void setListaDuplicataExcepcionada(Collection<DuplicataExcepcionada> listaDuplicataExcepcionada) {
		this.listaDuplicataExcepcionada = listaDuplicataExcepcionada;
	}

	/**
	 * <p>
	 * Retorna o valor do atributo percentualMaximo
	 * </p>
	 * .
	 *
	 * @return percentualMaximo
	 */
	public BigDecimal getPercentualMaximo() {
		return this.percentualMaximo;
	}

	/**
	 * <p>
	 * Define o valor do atributo percentualMaximo
	 * </p>
	 * .
	 *
	 * @param percentualMaximo
	 *            valor a ser atribuído
	 */
	public void setPercentualMaximo(BigDecimal percentualMaximo) {
		this.percentualMaximo = percentualMaximo;
	}

	/**
	 * <p>Retorna o valor do atributo qtdDiasFluxo</p>.
	 *
	 * @return qtdDiasFluxo
	*/
	public Integer getQtdDiasFluxo() {
		return this.qtdDiasFluxo;
	}

	/**
	 * <p>Define o valor do atributo qtdDiasFluxo</p>.
	 *
	 * @param qtdDiasFluxo valor a ser atribuído
	*/
	public void setQtdDiasFluxo(Integer qtdDiasFluxo) {
		this.qtdDiasFluxo = qtdDiasFluxo;
	}

}