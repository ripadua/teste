/**
 * Copyright (c) 2020 Caixa Econômica Federal. Todos os direitos
 * reservados.
 *
 * Caixa Econômica Federal - SIACG
 *
 * Este software foi desenvolvido sob demanda da CAIXA e está
 * protegido por leis de direitos autorais e tratados internacionais. As
 * condições de cópia e utilização total ou partes dependem de autorização da
 * empresa. Cópias não são permitidas sem expressa autorização. Não pode ser
 * comercializado ou utilizado para propósitos particulares.
 *
 * Uso exclusivo da Caixa Econômica Federal. A reprodução ou distribuição não
 * autorizada deste programa ou de parte dele, resultará em punições civis e
 * criminais e os infratores incorrem em sanções previstas na legislação em
 * vigor.
 *
 * Histórico do TFS:
 *
 * LastChangedRevision: $Revision$
 * LastChangedBy: $Author$
 * LastChangedDate: $Date$
 *
 * HeadURL: $HeadURL$
 *
 */	
package br.gov.caixa.siacg.deserializer;

import java.io.IOException;

import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.DeserializationContext;
import com.fasterxml.jackson.databind.deser.std.StdDeserializer;

import br.gov.caixa.siacg.model.enums.FormaGarantiaEnum;

/**
 * <p>FormaGarantiaDeserializer</p>
 *
 * <p>Descrição: Deserializador para o enumerador de forma de garantia </p>
 *
 * <br><b>Empresa:</b> Cef - Caixa Econômica Federal
 *
 *
 * @author f541915
 *
 * @version 1.0
*/
public class FormaGarantiaDeserializer extends StdDeserializer<FormaGarantiaEnum> {

	/** Atributo serialVersionUID. */
	private static final long serialVersionUID = 1L;

	protected FormaGarantiaDeserializer() {
		super(FormaGarantiaEnum.class);
	}

	@Override
	public FormaGarantiaEnum deserialize(JsonParser p, DeserializationContext ctxt) throws IOException, JsonProcessingException {
		return FormaGarantiaEnum.obterDeValor(p.getText());
	}

}
