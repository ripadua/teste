package br.gov.caixa.siacg.view.form;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;
import java.util.List;

import br.gov.caixa.pedesgo.arquitetura.visao.ManutencaoVisao;
import br.gov.caixa.siacg.model.domain.Contrato;
import br.gov.caixa.siacg.model.domain.DWAnaliseContrato;
import br.gov.caixa.siacg.model.domain.GrupoGarantia;
import br.gov.caixa.siacg.model.domain.Segmento;
import br.gov.caixa.siacg.model.enums.CaracteristicaEnum;
import br.gov.caixa.siacg.model.enums.SegmentacaoEnum;
import br.gov.caixa.siacg.model.enums.SituacaoContratoEnum;
import br.gov.caixa.siacg.model.enums.StatusGarantiaSuficienteEnum;
import br.gov.caixa.siacg.model.vo.FiltroAnaliseCarteiraVO;
import br.gov.caixa.siacg.model.vo.SrEUnidadeVO;
import br.gov.caixa.siacg.model.vo.SrVO;
import br.gov.caixa.siacg.model.vo.UnidadeVO;

/**
 * <p>
 * AnaliseVisao
 * </p>
 * <p>
 * Descrição: Classe responsável por armazenar os dados da visão do caso de uso <code>Análise de carteira</code>.
 * </p>
 * 
 * <b>Empresa:</b> Cef - Caixa Econômica Federal
 *
 * @author joseroberto@gsgroup.com.br
 * @version 1.0
 */
public class AnaliseVisao extends ManutencaoVisao<Contrato> {

    /** Constante serialVersionUID. */
    private static final long serialVersionUID = 1L;

    /** Atributo exibir gestor caixa. */
    private boolean exibirGestorCaixa;

    /** Atributo exibir gestor nacional. */
    private boolean exibirGestorNacional;

    /** Atributo exibir gestor regional. */
    private boolean exibirGestorRegional;

    /** Atributo exibir gestor unidade. */
    private boolean exibirGestorUnidade;

    /** Atributo exibir coluna unidade. */
    private boolean exibirColunaUnidade;

    /** Atributo exibir coluna sr. */
    private boolean exibirColunaSR;

    /** Atributo exibir coluna suat. */
    private boolean exibirColunaSUAT;

    /** Atributo bread crumb analise garantia. */
    private boolean breadCrumbAnaliseGarantia;

    /** Atributo exibir botao xls. */
    private boolean exibirBotaoXLS;

    /** Atributo exibir pesquisa contrato. */
    private boolean exibirPesquisaContrato;

    /** Atributo restricao abangencia. */
    private boolean restricaoAbangencia;

    /** Atributo origemGarantiasInsuficiente. */
    private boolean origemGarantiasInsuficiente;

    /** Atributo origemContratosNaoParametrizados. */
    private boolean origemContratosNaoParametrizados;

    /** Atributo origemNovosContratos. */
    private boolean origemNovosContratos;

    /** Atributo permissão check contratos parametrizados. */
    private boolean permissaoCheckContratosParametrizados;

    /** Atributo permissão check contratos nao parametrizados. */
    private boolean permissaoCheckContratosNaoParametrizados;

    /** Atributo permissão check contratos nao parametrizados manualmente. */
    private boolean permissaoCheckContratosNaoParametrizadosManualmente;

    // Atributo responsavel por habilitar/desabilitar botão para abrir tela de
    // Parametrização
    /** Atributo exibir botao abrir parametrizacao. */
    private boolean exibirBotaoAbrirParametrizacao;

    /** Atributo nome suat. */
    private String nomeSuat;

    /** Atributo nome sr. */
    private String nomeSr;

    /** Atributo nome unidade. */
    private String nomeUnidade;

    /** Atributo identificador garantia. */
    private String identificadorGarantia;

    /** Atributo nu unidade. */
    private Integer nuUnidade;

    /** Atributo nu sr. */
    private Integer nuSr;

    /** Atributo nu suat. */
    private Integer nuSuat;

    /** Atributo un unidade selecionada. */
    private Integer unUnidadeSelecionada;

    /** Atributo coIdentificador. */
    private String coIdentificador;

    /** Atributo nuOperacao. */
    private Integer nuOperacao;

    /** Atributo DWAnaliseContrato. */
    private DWAnaliseContrato dWAnaliseContrato;

    /** Atributo filtro historico. */
    private FiltroAnaliseCarteiraVO filtroHistorico;

    /** Atributo listaCaracteristicaEnum. */
    private Collection<CaracteristicaEnum> listaCaracteristicaEnum;

    /** Atributo listaStatusGarantiaSuficienteEnum. */
    private Collection<StatusGarantiaSuficienteEnum> listaStatusGarantiaSuficienteEnum;

    /** Atributo unidade list. */
    private Collection<UnidadeVO> unidadeList;

    /** Atributo suat list. */
    private Collection<UnidadeVO> suatList;

    /** Atributo sr list. */
    private Collection<SrVO> srList;

    /** Atributo garantias. */
    private Collection<GrupoGarantia> garantias;
    
    private Collection<SrEUnidadeVO> srUnidadesList;

    private SrEUnidadeVO srUnidade;

    /** Atributo listaSegmento. */
    private Collection<Segmento> listaSegmento;

    /** Atributo listaSegmentoSelecionados. */
    private List<SegmentacaoEnum> listaSegmentoSelecionados;

    /** Atributo situacaoContratoEnum. */
    private Collection<SituacaoContratoEnum> listaSituacaoContratoEnum;

	/** Atributo nivel de consulta. **/
	private String nivelConsulta;
	
	/** Atributo dias para data referencia. */
	private Integer diasParaDataReferencia;
	
	/** Atributo data de referência. */
	private Date dataReferencia;

	/** Atributo título da grid. */
	private String tituloGrid;
	
	/** Atributo exibir botao voltar consulta. */
	private boolean exibirBotaoVoltarConsulta;
	
	private List<UnidadeVO> listaDires;
    
    private List<UnidadeVO> listaSuvs;

    private Collection<UnidadeVO> listaUnidade;
    
    private UnidadeVO suatSelecionada;
    
    private Integer codSuatSelecionada;
    
    private Integer codSuvSelecionado;
    
    private Integer tipoConfig;
    
    /** Atributo un unidade selecionada. */
	private Integer unidadeSelecionada;
	
	private Integer unidadeGestoraProcesso;
	
	private Boolean apresentarGridContratos = false;

    /**
     * <p>
     * Método responsável por retornar o valor do atributo coIdentificador.
     * <p>
     *
     * @return coIdentificador
     * @author Charles Junior
     */
    public String getCoIdentificador() {

        return this.coIdentificador;
    }

    /**
     * Retorna o valor do atributo dWAnaliseContrato.
     *
     * @return dWAnaliseContrato
     */
    public DWAnaliseContrato getdWAnaliseContrato() {

        return this.dWAnaliseContrato;
    }

    /**
     * Retorna o valor do atributo filtroHistorico.
     *
     * @return filtroHistorico
     */
    public FiltroAnaliseCarteiraVO getFiltroHistorico() {
        return this.filtroHistorico;
    }

    /**
     * Retorna o valor do atributo garantias.
     *
     * @return garantias
     */
    public Collection<GrupoGarantia> getGarantias() {

        return this.garantias;
    }

    /**
     * Retorna o valor do atributo identificadorGarantia.
     *
     * @return identificadorGarantia
     */
    public String getIdentificadorGarantia() {

        return this.identificadorGarantia;
    }

    /**
     * Retorna o valor do atributo listaCaracteristicaEnum.
     *
     * @return listaCaracteristicaEnum
     */
    public Collection<CaracteristicaEnum> getListaCaracteristicaEnum() {

        if (this.listaCaracteristicaEnum == null) {
            this.listaCaracteristicaEnum = new ArrayList<>();
            this.listaCaracteristicaEnum.add(CaracteristicaEnum.ESTOQUE);
            this.listaCaracteristicaEnum.add(CaracteristicaEnum.FLUXO);
        }

        return this.listaCaracteristicaEnum;
    }

    /**
     * Retorna o valor do atributo listaSegmento.
     *
     * @return listaSegmento
     */
    public Collection<Segmento> getListaSegmento() {

        if (this.listaSegmento == null) {
            this.listaSegmento = new ArrayList<>();
        }

        return this.listaSegmento;
    }

    /**
     * Retorna o valor do atributo listaSegmentoSelecionados.
     *
     * @return listaSegmentoSelecionados
     */
    public List<SegmentacaoEnum> getListaSegmentoSelecionados() {

        return this.listaSegmentoSelecionados;
    }

    /**
     * Retorna o valor do atributo listaSituacaoContratoEnum.
     *
     * @return listaSituacaoContratoEnum
     */
    public Collection<SituacaoContratoEnum> getListaSituacaoContratoEnum() {
        return this.listaSituacaoContratoEnum;
    }

    /**
     * Retorna o valor do atributo listaStatusGarantiaSuficienteEnum.
     *
     * @return listaStatusGarantiaSuficienteEnum
     */
    public Collection<StatusGarantiaSuficienteEnum> getListaStatusGarantiaSuficienteEnum() {
        if (this.listaStatusGarantiaSuficienteEnum == null) {
            this.listaStatusGarantiaSuficienteEnum = new ArrayList<>();
            this.listaStatusGarantiaSuficienteEnum.add(StatusGarantiaSuficienteEnum.SUFICIENTE);
            this.listaStatusGarantiaSuficienteEnum.add(StatusGarantiaSuficienteEnum.INSUFICIENTE);
            this.listaStatusGarantiaSuficienteEnum.add(StatusGarantiaSuficienteEnum.TRATAMENTO_ESPECIAL);
        }
        return this.listaStatusGarantiaSuficienteEnum;
    }

    /**
     * Retorna o valor do atributo nomeSr.
     *
     * @return nomeSr
     */
    public String getNomeSr() {

        return this.nomeSr;
    }

    /**
     * Retorna o valor do atributo nomeSuat.
     *
     * @return nomeSuat
     */
    public String getNomeSuat() {

        return this.nomeSuat;
    }

    /**
     * Retorna o valor do atributo nomeUnidade.
     *
     * @return nomeUnidade
     */
    public String getNomeUnidade() {

        return this.nomeUnidade;
    }

    /**
     * <p>
     * Método responsável por retornar o valor do atributo nuOperacao.
     * <p>
     *
     * @return nuOperacao
     * @author Charles Junior
     */
    public Integer getNuOperacao() {

        return this.nuOperacao;
    }

    /**
     * Retorna o valor do atributo nuSr.
     *
     * @return nuSr
     */
    public Integer getNuSr() {
        return this.nuSr;
    }

    /**
     * Retorna o valor do atributo nuSuat.
     *
     * @return nuSuat
     */
    public Integer getNuSuat() {

        return this.nuSuat;
    }

    /**
     * Retorna o valor do atributo nuUnidade.
     *
     * @return nuUnidade
     */
    public Integer getNuUnidade() {

        return this.nuUnidade;
    }

    /**
     * Retorna o valor do atributo srList.
     *
     * @return srList
     */
    public Collection<SrVO> getSrList() {

        return this.srList;
    }

    /**
     * Retorna o valor do atributo suatList.
     *
     * @return suatList
     */
    public Collection<UnidadeVO> getSuatList() {

        return this.suatList;
    }

    /**
     * Retorna o valor do atributo unidadeList.
     *
     * @return unidadeList
     */
    public Collection<UnidadeVO> getUnidadeList() {

        return this.unidadeList;
    }

    /**
     * Retorna o valor do atributo unUnidadeSelecionada.
     *
     * @return unUnidadeSelecionada
     */
    public Integer getUnUnidadeSelecionada() {

        return this.unUnidadeSelecionada;
    }

    /**
     * Retorna o valor do atributo breadCrumbAnaliseGarantia.
     *
     * @return breadCrumbAnaliseGarantia
     */
    public boolean isBreadCrumbAnaliseGarantia() {

        return this.breadCrumbAnaliseGarantia;
    }

    /**
     * Retorna o valor do atributo exibirBotaoAbrirParametrizacao.
     *
     * @return exibirBotaoAbrirParametrizacao
     */
    public boolean isExibirBotaoAbrirParametrizacao() {

        return this.exibirBotaoAbrirParametrizacao;
    }

    /**
     * Retorna o valor do atributo exibirBotaoXLS.
     *
     * @return exibirBotaoXLS
     */
    public boolean isExibirBotaoXLS() {

        return this.exibirBotaoXLS;
    }

    /**
     * Retorna o valor do atributo exibirColunaSR.
     *
     * @return exibirColunaSR
     */
    public boolean isExibirColunaSR() {

        return this.exibirColunaSR;
    }

    /**
     * Retorna o valor do atributo exibirColunaSUAT.
     *
     * @return exibirColunaSUAT
     */
    public boolean isExibirColunaSUAT() {

        return this.exibirColunaSUAT;
    }

    /**
     * Retorna o valor do atributo exibirColunaUnidade.
     *
     * @return exibirColunaUnidade
     */
    public boolean isExibirColunaUnidade() {

        return this.exibirColunaUnidade;
    }

    /**
     * Retorna o valor do atributo exibirGestorCaixa.
     *
     * @return exibirGestorCaixa
     */
    public boolean isExibirGestorCaixa() {

        return this.exibirGestorCaixa;
    }

    /**
     * Retorna o valor do atributo exibirGestorNacional.
     *
     * @return exibirGestorNacional
     */
    public boolean isExibirGestorNacional() {

        return this.exibirGestorNacional;
    }

    /**
     * Retorna o valor do atributo exibirGestorRegional.
     *
     * @return exibirGestorRegional
     */
    public boolean isExibirGestorRegional() {

        return this.exibirGestorRegional;
    }

    /**
     * Retorna o valor do atributo exibirGestorUnidade.
     *
     * @return exibirGestorUnidade
     */
    public boolean isExibirGestorUnidade() {

        return this.exibirGestorUnidade;
    }

    /**
     * Retorna o valor do atributo exibirPesquisaContrato.
     *
     * @return exibirPesquisaContrato
     */
    public boolean isExibirPesquisaContrato() {

        return this.exibirPesquisaContrato;
    }

    /**
     * Retorna o valor do atributo origemContratosNaoParametrizados.
     *
     * @return origemContratosNaoParametrizados
     */
    public boolean isOrigemContratosNaoParametrizados() {

        return this.origemContratosNaoParametrizados;
    }

    /**
     * Retorna o valor do atributo origemGarantiasInsuficiente.
     *
     * @return origemGarantiasInsuficiente
     */
    public boolean isOrigemGarantiasInsuficiente() {

        return this.origemGarantiasInsuficiente;
    }

    /**
     * Retorna o valor do atributo origemNovosContratos.
     *
     * @return origemNovosContratos
     */
    public boolean isOrigemNovosContratos() {

        return this.origemNovosContratos;
    }

    /**
     * Retorna o valor do atributo permissaoCheckContratosNaoParametrizados.
     *
     * @return permissaoCheckContratosNaoParametrizados
     */
    public boolean isPermissaoCheckContratosNaoParametrizados() {
        return this.permissaoCheckContratosNaoParametrizados;
    }

    /**
     * Retorna o valor do atributo permissaoCheckContratosNaoParametrizadosManualmente.
     *
     * @return permissaoCheckContratosNaoParametrizadosManualmente
     */
    public boolean isPermissaoCheckContratosNaoParametrizadosManualmente() {
        return this.permissaoCheckContratosNaoParametrizadosManualmente;
    }

    /**
     * Retorna o valor do atributo permissaoCheckContratosParametrizados.
     *
     * @return permissaoCheckContratosParametrizados
     */
    public boolean isPermissaoCheckContratosParametrizados() {
        return this.permissaoCheckContratosParametrizados;
    }

    /**
     * Retorna o valor do atributo restricaoAbangencia.
     *
     * @return restricaoAbangencia
     */
    public boolean isRestricaoAbangencia() {

        return this.restricaoAbangencia;
    }

    /**
     * Define o valor do atributo breadCrumbAnaliseGarantia.
     *
     * @param breadCrumbAnaliseGarantia
     *            valor a ser atribuído
     */
    public void setBreadCrumbAnaliseGarantia(final boolean breadCrumbAnaliseGarantia) {

        this.breadCrumbAnaliseGarantia = breadCrumbAnaliseGarantia;
    }

    /**
     * <p>
     * Método responsável por ajustar o valor do atributo coIdentificador.
     * <p>
     *
     * @param coIdentificador
     *            valor a ser atribuido
     * @author Charles Junior
     */
    public void setCoIdentificador(final String coIdentificador) {

        this.coIdentificador = coIdentificador;
    }

    /**
     * Define o valor do atributo dWAnaliseContrato.
     *
     * @param dWAnaliseContrato
     *            valor a ser atribuído
     */
    public void setdWAnaliseContrato(final DWAnaliseContrato dWAnaliseContrato) {

        this.dWAnaliseContrato = dWAnaliseContrato;
    }

    /**
     * Define o valor do atributo exibirBotaoAbrirParametrizacao.
     *
     * @param exibirBotaoAbrirParametrizacao
     *            valor a ser atribuído
     */
    public void setExibirBotaoAbrirParametrizacao(final boolean exibirBotaoAbrirParametrizacao) {

        this.exibirBotaoAbrirParametrizacao = exibirBotaoAbrirParametrizacao;
    }

    /**
     * Define o valor do atributo exibirBotaoXLS.
     *
     * @param exibirBotaoXLS
     *            valor a ser atribuído
     */
    public void setExibirBotaoXLS(final boolean exibirBotaoXLS) {

        this.exibirBotaoXLS = exibirBotaoXLS;
    }

    /**
     * Define o valor do atributo exibirColunaSR.
     *
     * @param exibirColunaSR
     *            valor a ser atribuído
     */
    public void setExibirColunaSR(final boolean exibirColunaSR) {

        this.exibirColunaSR = exibirColunaSR;
    }

    /**
     * Define o valor do atributo exibirColunaSUAT.
     *
     * @param exibirColunaSUAT
     *            valor a ser atribuído
     */
    public void setExibirColunaSUAT(final boolean exibirColunaSUAT) {

        this.exibirColunaSUAT = exibirColunaSUAT;
    }

    /**
     * Define o valor do atributo exibirColunaUnidade.
     *
     * @param exibirColunaUnidade
     *            valor a ser atribuído
     */
    public void setExibirColunaUnidade(final boolean exibirColunaUnidade) {

        this.exibirColunaUnidade = exibirColunaUnidade;
    }

    /**
     * Define o valor do atributo exibirGestorCaixa.
     *
     * @param exibirGestorCaixa
     *            valor a ser atribuído
     */
    public void setExibirGestorCaixa(final boolean exibirGestorCaixa) {

        this.exibirGestorCaixa = exibirGestorCaixa;
    }

    /**
     * Define o valor do atributo exibirGestorNacional.
     *
     * @param exibirGestorNacional
     *            valor a ser atribuído
     */
    public void setExibirGestorNacional(final boolean exibirGestorNacional) {

        this.exibirGestorNacional = exibirGestorNacional;
    }

    /**
     * Define o valor do atributo exibirGestorRegional.
     *
     * @param exibirGestorRegional
     *            valor a ser atribuído
     */
    public void setExibirGestorRegional(final boolean exibirGestorRegional) {

        this.exibirGestorRegional = exibirGestorRegional;
    }

    /**
     * Define o valor do atributo exibirGestorUnidade.
     *
     * @param exibirGestorUnidade
     *            valor a ser atribuído
     */
    public void setExibirGestorUnidade(final boolean exibirGestorUnidade) {

        this.exibirGestorUnidade = exibirGestorUnidade;
    }

    /**
     * Define o valor do atributo exibirPesquisaContrato.
     *
     * @param exibirPesquisaContrato
     *            valor a ser atribuído
     */
    public void setExibirPesquisaContrato(final boolean exibirPesquisaContrato) {

        this.exibirPesquisaContrato = exibirPesquisaContrato;
    }

    /**
     * Define o valor do atributo filtroHistorico.
     *
     * @param filtroHistorico
     *            valor a ser atribuído
     */
    public void setFiltroHistorico(final FiltroAnaliseCarteiraVO filtroHistorico) {
        this.filtroHistorico = filtroHistorico;
    }

    /**
     * Define o valor do atributo garantias.
     *
     * @param garantias
     *            valor a ser atribuído
     */
    public void setGarantias(final Collection<GrupoGarantia> garantias) {

        this.garantias = garantias;
    }

    /**
     * Define o valor do atributo identificadorGarantia.
     *
     * @param identificadorGarantia
     *            valor a ser atribuído
     */
    public void setIdentificadorGarantia(final String identificadorGarantia) {

        this.identificadorGarantia = identificadorGarantia;
    }

    /**
     * Define o valor do atributo listaCaracteristicaEnum.
     *
     * @param listaCaracteristicaEnum
     *            valor a ser atribuído
     */
    public void setListaCaracteristicaEnum(final Collection<CaracteristicaEnum> listaCaracteristicaEnum) {

        this.listaCaracteristicaEnum = listaCaracteristicaEnum;
    }

    /**
     * Define o valor do atributo listaSegmento.
     *
     * @param listaSegmento
     *            valor a ser atribuído
     */
    public void setListaSegmento(final Collection<Segmento> listaSegmento) {

        this.listaSegmento = listaSegmento;
    }

    /**
     * Define o valor do atributo listaSegmentoSelecionados.
     *
     * @param listaSegmentoSelecionados
     *            valor a ser atribuído
     */
    public void setListaSegmentoSelecionados(final List<SegmentacaoEnum> listaSegmentoSelecionados) {

        this.listaSegmentoSelecionados = listaSegmentoSelecionados;
    }

    /**
     * Define o valor do atributo listaSituacaoContratoEnum.
     *
     * @param listaSituacaoContratoEnum
     *            valor a ser atribuído
     */
    public void setListaSituacaoContratoEnum(final Collection<SituacaoContratoEnum> listaSituacaoContratoEnum) {
        this.listaSituacaoContratoEnum = listaSituacaoContratoEnum;
    }

    /**
     * Define o valor do atributo listaStatusGarantiaSuficienteEnum.
     *
     * @param listaStatusGarantiaSuficienteEnum
     *            valor a ser atribuído
     */
    public void setListaStatusGarantiaSuficienteEnum(final Collection<StatusGarantiaSuficienteEnum> listaStatusGarantiaSuficienteEnum) {

        this.listaStatusGarantiaSuficienteEnum = listaStatusGarantiaSuficienteEnum;
    }

    /**
     * Define o valor do atributo nomeSr.
     *
     * @param nomeSr
     *            valor a ser atribuído
     */
    public void setNomeSr(final String nomeSr) {

        this.nomeSr = nomeSr;
    }

    /**
     * Define o valor do atributo nomeSuat.
     *
     * @param nomeSuat
     *            valor a ser atribuído
     */
    public void setNomeSuat(final String nomeSuat) {

        this.nomeSuat = nomeSuat;
    }

    /**
     * Define o valor do atributo nomeUnidade.
     *
     * @param nomeUnidade
     *            valor a ser atribuído
     */
    public void setNomeUnidade(final String nomeUnidade) {

        this.nomeUnidade = nomeUnidade;
    }

    /**
     * <p>
     * Método responsável por ajustar o atributo nuOperacao.
     * <p>
     *
     * @param nuOperacao
     *            valor a ser atribuido
     * @author Charles Junior
     */
    public void setNuOperacao(final Integer nuOperacao) {

        this.nuOperacao = nuOperacao;
    }

    /**
     * Define o valor do atributo nuSr.
     *
     * @param nuSr
     *            valor a ser atribuído
     */
    public void setNuSr(final Integer nuSr) {
        this.nuSr = nuSr;
    }

    /**
     * Define o valor do atributo nuSuat.
     *
     * @param nuSuat
     *            valor a ser atribuído
     */
    public void setNuSuat(final Integer nuSuat) {

        this.nuSuat = nuSuat;
    }

    /**
     * Define o valor do atributo nuUnidade.
     *
     * @param nuUnidade
     *            valor a ser atribuído
     */
    public void setNuUnidade(final Integer nuUnidade) {

        this.nuUnidade = nuUnidade;
    }

    /**
     * Define o valor do atributo origemContratosNaoParametrizados.
     *
     * @param origemContratosNaoParametrizados
     *            valor a ser atribuído
     */
    public void setOrigemContratosNaoParametrizados(final boolean origemContratosNaoParametrizados) {

        this.origemContratosNaoParametrizados = origemContratosNaoParametrizados;
    }

    /**
     * Define o valor do atributo origemGarantiasInsuficiente.
     *
     * @param origemGarantiasInsuficiente
     *            valor a ser atribuído
     */
    public void setOrigemGarantiasInsuficiente(final boolean origemGarantiasInsuficiente) {

        this.origemGarantiasInsuficiente = origemGarantiasInsuficiente;
    }

    /**
     * Define o valor do atributo origemNovosContratos.
     *
     * @param origemNovosContratos
     *            valor a ser atribuído
     */
    public void setOrigemNovosContratos(final boolean origemNovosContratos) {

        this.origemNovosContratos = origemNovosContratos;
    }

    /**
     * Define o valor do atributo permissaoCheckContratosNaoParametrizados.
     *
     * @param permissaoCheckContratosNaoParametrizados
     *            valor a ser atribuído
     */
    public void setPermissaoCheckContratosNaoParametrizados(final boolean permissaoCheckContratosNaoParametrizados) {
        this.permissaoCheckContratosNaoParametrizados = permissaoCheckContratosNaoParametrizados;
    }

    /**
     * Define o valor do atributo permissaoCheckContratosNaoParametrizadosManualmente.
     *
     * @param permissaoCheckContratosNaoParametrizadosManualmente
     *            valor a ser atribuído
     */
    public void setPermissaoCheckContratosNaoParametrizadosManualmente(final boolean permissaoCheckContratosNaoParametrizadosManualmente) {
        this.permissaoCheckContratosNaoParametrizadosManualmente = permissaoCheckContratosNaoParametrizadosManualmente;
    }

    /**
     * Define o valor do atributo permissaoCheckContratosParametrizados.
     *
     * @param permissaoCheckContratosParametrizados
     *            valor a ser atribuído
     */
    public void setPermissaoCheckContratosParametrizados(final boolean permissaoCheckContratosParametrizados) {
        this.permissaoCheckContratosParametrizados = permissaoCheckContratosParametrizados;
    }

    /**
     * Define o valor do atributo restricaoAbangencia.
     *
     * @param restricaoAbangencia
     *            valor a ser atribuído
     */
    public void setRestricaoAbangencia(final boolean restricaoAbangencia) {

        this.restricaoAbangencia = restricaoAbangencia;
    }

    /**
     * Define o valor do atributo srList.
     *
     * @param srList
     *            valor a ser atribuído
     */
    public void setSrList(final Collection<SrVO> srList) {

        this.srList = srList;
    }

    /**
     * Define o valor do atributo suatList.
     *
     * @param suatList
     *            valor a ser atribuído
     */
    public void setSuatList(final Collection<UnidadeVO> suatList) {

        this.suatList = suatList;
    }

    /**
     * Define o valor do atributo unidadeList.
     *
     * @param unidadeList
     *            valor a ser atribuído
     */
    public void setUnidadeList(final Collection<UnidadeVO> unidadeList) {

        this.unidadeList = unidadeList;
    }

    /**
     * Define o valor do atributo unUnidadeSelecionada.
     *
     * @param unUnidadeSelecionada
     *            valor a ser atribuído
     */
    public void setUnUnidadeSelecionada(final Integer unUnidadeSelecionada) {

        this.unUnidadeSelecionada = unUnidadeSelecionada;
    }

	/**
	 * @return the srUnidadesList
	 */
	public Collection<SrEUnidadeVO> getSrUnidadesList() {
		return srUnidadesList;
	}

	/**
	 * @param srUnidadesList the srUnidadesList to set
	 */
	public void setSrUnidadesList(Collection<SrEUnidadeVO> srUnidadesList) {
		this.srUnidadesList = srUnidadesList;
	}

	/**
	 * @return the srUnidade
	 */
	public SrEUnidadeVO getSrUnidade() {
		return srUnidade;
	}

	/**
	 * @param srUnidade the srUnidade to set
	 */
	public void setSrUnidade(SrEUnidadeVO srUnidade) {
		this.srUnidade = srUnidade;
	}

	/**
	 * @return the nivelConsulta
	 */
	public String getNivelConsulta() {
		return nivelConsulta;
	}

	/**
	 * @param nivelConsulta the nivelConsulta to set
	 */
	public void setNivelConsulta(String nivelConsulta) {
		this.nivelConsulta = nivelConsulta;
	}

	/**
	 * @return the diasParaDataReferencia
	 */
	public Integer getDiasParaDataReferencia() {
		return diasParaDataReferencia;
	}

	/**
	 * @param diasParaDataReferencia the diasParaDataReferencia to set
	 */
	public void setDiasParaDataReferencia(Integer diasParaDataReferencia) {
		this.diasParaDataReferencia = diasParaDataReferencia;
	}

	/**
	 * @return the dataReferencia
	 */
	public Date getDataReferencia() {
		return dataReferencia;
	}

	/**
	 * @param dataReferencia the dataReferencia to set
	 */
	public void setDataReferencia(Date dataReferencia) {
		this.dataReferencia = dataReferencia;
	}

	/**
	 * @return the tituloGrid
	 */
	public String getTituloGrid() {
		return tituloGrid;
	}

	/**
	 * @param tituloGrid the tituloGrid to set
	 */
	public void setTituloGrid(String tituloGrid) {
		this.tituloGrid = tituloGrid;
	}

	/**
	 * @return the exibirBotaoVoltarConsulta
	 */
	public boolean isExibirBotaoVoltarConsulta() {
		return exibirBotaoVoltarConsulta;
	}

	/**
	 * @param exibirBotaoVoltarConsulta the exibirBotaoVoltarConsulta to set
	 */
	public void setExibirBotaoVoltarConsulta(boolean exibirBotaoVoltarConsulta) {
		this.exibirBotaoVoltarConsulta = exibirBotaoVoltarConsulta;
	}

	/**
	 * @return the suatSelecionada
	 */
	public UnidadeVO getSuatSelecionada() {
		return suatSelecionada;
	}

	/**
	 * @param suatSelecionada the suatSelecionada to set
	 */
	public void setSuatSelecionada(UnidadeVO suatSelecionada) {
		this.suatSelecionada = suatSelecionada;
	}

	/**
	 * @return the listaDires
	 */
	public List<UnidadeVO> getListaDires() {
		return listaDires;
	}

	/**
	 * @param listaDires the listaDires to set
	 */
	public void setListaDires(List<UnidadeVO> listaDires) {
		this.listaDires = listaDires;
	}

	/**
	 * @return the listaSuvs
	 */
	public List<UnidadeVO> getListaSuvs() {
		return listaSuvs;
	}

	/**
	 * @param listaSuvs the listaSuvs to set
	 */
	public void setListaSuvs(List<UnidadeVO> listaSuvs) {
		this.listaSuvs = listaSuvs;
	}

	/**
	 * @return the listaUnidade
	 */
	public Collection<UnidadeVO> getListaUnidade() {
		return listaUnidade;
	}

	/**
	 * @param listaUnidade the listaUnidade to set
	 */
	public void setListaUnidade(Collection<UnidadeVO> listaUnidade) {
		this.listaUnidade = listaUnidade;
	}

	/**
	 * @return the codSuatSelecionada
	 */
	public Integer getCodSuatSelecionada() {
		return codSuatSelecionada;
	}

	/**
	 * @param codSuatSelecionada the codSuatSelecionada to set
	 */
	public void setCodSuatSelecionada(Integer codSuatSelecionada) {
		this.codSuatSelecionada = codSuatSelecionada;
	}

	/**
	 * @return the codSuvSelecionado
	 */
	public Integer getCodSuvSelecionado() {
		return codSuvSelecionado;
	}

	/**
	 * @param codSuvSelecionado the codSuvSelecionado to set
	 */
	public void setCodSuvSelecionado(Integer codSuvSelecionado) {
		this.codSuvSelecionado = codSuvSelecionado;
	}

	/**
	 * @return the tipoConfig
	 */
	public Integer getTipoConfig() {
		return tipoConfig;
	}

	/**
	 * @param tipoConfig the tipoConfig to set
	 */
	public void setTipoConfig(Integer tipoConfig) {
		this.tipoConfig = tipoConfig;
	}

	/**
	 * @return the unidadeSelecionada
	 */
	public Integer getUnidadeSelecionada() {
		return unidadeSelecionada;
	}

	/**
	 * @param unidadeSelecionada the unidadeSelecionada to set
	 */
	public void setUnidadeSelecionada(Integer unidadeSelecionada) {
		this.unidadeSelecionada = unidadeSelecionada;
	}

	public Integer getUnidadeGestoraProcesso() {
		return unidadeGestoraProcesso;
	}

	public void setUnidadeGestoraProcesso(Integer unidadeGestoraProcesso) {
		this.unidadeGestoraProcesso = unidadeGestoraProcesso;
	}

	public Boolean getApresentarGridContratos() {
	    return this.apresentarGridContratos;
	}

	public void setApresentarGridContratos(Boolean apresentarGridContratos) {
	    this.apresentarGridContratos = apresentarGridContratos;
	}
	
}
