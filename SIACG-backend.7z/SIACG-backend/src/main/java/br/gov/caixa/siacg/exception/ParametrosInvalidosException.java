/*
 * Copyright (c) 2018 Caixa Econômica Federal. Todos os direitos
 * reservados.
 *
 * Caixa Econômica Federal - SIACG
 *
 * Este software foi desenvolvido sob demanda da CAIXA e está
 * protegido por leis de direitos autorais e tratados internacionais. As
 * condições de cópia e utilização do total ou partes dependem de autorização da
 * empresa. Cópias não são permitidas sem expressa autorização. Não pode ser
 * comercializado ou utilizado para propósitos particulares.
 *
 * Uso exclusivo da Caixa Econômica Federal. A reprodução ou distribuição não
 * autorizada deste programa ou de parte dele, resultará em punições civis e
 * criminais e os infratores incorrem em sanções previstas na legislação em
 * vigor.
 *
 * Histórico do Subversion:
 *
 * LastChangedRevision: $Revision$
 * LastChangedBy: $Author$
 * LastChangedDate: $Date$
 *
 * HeadURL: $HeadURL$
 *
 */	
package br.gov.caixa.siacg.exception;

import javax.ejb.ApplicationException;

import br.gov.caixa.siacg.model.enums.RetornoServicoBloqueioEnum;
import br.gov.caixa.siacg.model.enums.RetornoServicoContratoGarantia;
import br.gov.caixa.siacg.model.enums.RetornoServicoSaldoEnum;

/**
 * <p>ParametrosInvalidosException</p>
 * <br><b>Empresa:</b> Cef - Caixa Econômica Federal
 *
 * * @author douglas.lopes
 * @version 1.0
 */
@ApplicationException(rollback=false)
public class ParametrosInvalidosException extends Exception {

    /** Atributo serialVersionUID. */
    private static final long serialVersionUID = 1L;

    /** Atributo codigo. */
    private final String codigo;

    /** Atributo descricao. */
    private final String descricao;

    /** Atributo descricao. */
    private final String parametro;
    
    /** Atributo descricao. */
    private final String sistema;

    /**
     * Construtor
     *
     * @param retornoServicoBloqueioEnum
     */
    public ParametrosInvalidosException(RetornoServicoBloqueioEnum retornoServicoBloqueioEnum) {
	this(retornoServicoBloqueioEnum, "");
    }

	/**
     * Construtor
     *
     * @param retornoServicoBloqueioEnum
     */
    public ParametrosInvalidosException(RetornoServicoSaldoEnum retorno, String sistema) {
	super(retorno.getDeRetorno());
	this.codigo = retorno.getCoRetorno();
	this.descricao = retorno.getDeRetorno();
	this.parametro = "";
	this.sistema = sistema;
    }
    
    public ParametrosInvalidosException(RetornoServicoContratoGarantia retorno, String sistema) {
    	super(retorno.getDeRetorno());
    	this.codigo = retorno.getCoRetorno();
    	this.descricao = retorno.getDeRetorno();
    	this.parametro = "";
    	this.sistema = sistema;
    }

    /**
     * Construtor
     *
     * @param retornoServicoBloqueioEnum RetornoServicoBloqueioEnum
     * @param parametro com erro.
     */
    public ParametrosInvalidosException(RetornoServicoBloqueioEnum retornoServicoBloqueioEnum, String parametro) {
	this(retornoServicoBloqueioEnum, parametro, "");
    }
    
    /**
     * Construtor
     *
     * @param retornoServicoBloqueioEnum RetornoServicoBloqueioEnum
     * @param parametro com erro.
     */
    public ParametrosInvalidosException(RetornoServicoBloqueioEnum retornoServicoBloqueioEnum, String parametro, String sistema) {
	super(retornoServicoBloqueioEnum.getDeRetorno());
	this.codigo = retornoServicoBloqueioEnum.getCoRetorno();
	this.descricao = retornoServicoBloqueioEnum.getDeRetorno()+parametro;
	this.parametro = parametro;
	this.sistema = sistema;
    }
    
    
    /**
     * Responsável pela criação de novas instâncias desta classe.
     *
     * @param codigo
     * @param descricao
     * @param parametro
     *
     */
    public ParametrosInvalidosException(String codigo, String descricao, String parametro, String sistema) {
	super();
	this.codigo = codigo;
	this.descricao = descricao;
	this.parametro = parametro;
	this.sistema = sistema;
    }
    /**
     * Retorna o valor do atributo codigo.
     *
     * @return codigo
     */
    public String getCodigo() {
	return this.codigo;
    }

    /**
     * Retorna o valor do atributo descricao.
     *
     * @return descricao
     */
    public String getDescricao() {
	return this.descricao;
    }

    /**
     * <p>Retorna o valor do atributo parametro</p>.
     *
     * @return parametro
     */
    public String getParametro() {
	return this.parametro;
    }

    /**
     * <p>Retorna o valor do atributo sistema</p>.
     *
     * @return sistema
    */
    public String getSistema() {
        return this.sistema;
    }
}