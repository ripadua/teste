/*
 * Copyright (c) 2020 Caixa Econômica Federal. Todos os direitos
 * reservados.
 *
 * Caixa Econômica Federal - SIACG - Sistema de Crédito Rural
 *
 * Este software foi desenvolvido sob demanda da CAIXA e está
 * protegido por leis de direitos autorais e tratados internacionais. As
 * condições de cópia e utilização do todo ou partes dependem de autorização da
 * empresa. Cópias não são permitidas sem expressa autorização. Não pode ser
 * comercializado ou utilizado para propósitos particulares.
 *
 * Uso exclusivo da Caixa Econômica Federal. A reprodução ou distribuição não
 * autorizada deste programa ou de parte dele, resultará em punições civis e
 * criminais e os infratores incorrem em sanções previstas na legislação em
 * vigor.
 *
 * Histórico do TFS:
 *
 * LastChangedRevision: $Revision$
 * LastChangedBy: $Author$
 * LastChangedDate: $Date$
 *
 * HeadURL: $HeadURL$
 *
 */	
package br.gov.caixa.siacg.view.mb;

import java.util.List;

import javax.ejb.EJB;
import javax.enterprise.context.SessionScoped;
import javax.inject.Named;

import org.apache.commons.collections.CollectionUtils;
import org.primefaces.event.FileUploadEvent;

import br.gov.caixa.pedesgo.arquitetura.controlador.ManutencaoBean;
import br.gov.caixa.pedesgo.arquitetura.enums.EnumExtensaoArquivo;
import br.gov.caixa.pedesgo.arquitetura.relatorio.UtilRelatorio;
import br.gov.caixa.pedesgo.arquitetura.siico.util.UtilObjeto;
import br.gov.caixa.pedesgo.arquitetura.util.LogCefUtil;
import br.gov.caixa.pedesgo.arquitetura.util.UtilData;
import br.gov.caixa.siacg.model.domain.InfoManualUsuario;
import br.gov.caixa.siacg.model.vo.ManualUsuarioVO;
import br.gov.caixa.siacg.service.ManualUsuarioService;
import br.gov.caixa.siacg.view.form.ManualUsuarioVisao;

/**
 * <p>ManualUsuarioMB</p>
 *
 * <p>Descrição: Descrição do tipo</p>
 *
 * <br><b>Empresa:</b> Cef - Caixa Econômica Federal
 *
 *
 * @author f734546
 *
 * @version 1.0
*/
@Named
@SessionScoped
public class ManualUsuarioMB extends ManutencaoBean<InfoManualUsuario> {
    

    /** Atributo NAO_FOI_POSSIVEL_REALIZAR_A_OPERACAO. */
    private static final String NAO_FOI_POSSIVEL_REALIZAR_A_OPERACAO = "MA027";
    
    public static final String ARQUIVO_NAO_LOCALIZADO = "MA028";

    /** Atributo serialVersionUID. */
    private static final long serialVersionUID = 1L;

    /** Atributo NOME_MANAGED_BEAN. */
    public static final String NOME_MANAGED_BEAN = "manualUsuarioMB";

    /** Atributo EL_MANAGED_BEAN. */
    public static final String EL_MANAGED_BEAN = "#{manualUsuarioMB}";
    
    /** Atributo PAGINA_CONSULTA. */
    private static final String PAGINA_CONSULTA = "/pages/manutencao/manualUsuario/consulta.xhtml?faces-redirect=true";
    
    /** Atributo VAR_RESOURCE_BUNDLE. */
    private static final String VAR_RESOURCE_BUNDLE = "msgApp";
    
    /** Atributo OPERACAO_REALIZADA_SUCESSO. */
    private static final String OPERACAO_REALIZADA_SUCESSO = "MA002";
    
    @EJB
    private ManualUsuarioService service;
    
    private ManualUsuarioVisao visao;
    
    /**
     * @see br.gov.caixa.pedesgo.arquitetura.controlador.AbstractBean#getNomeVarResourceBundle()
     */
    @Override
    protected String getNomeVarResourceBundle() {
        return ManualUsuarioMB.VAR_RESOURCE_BUNDLE;
    }

    /**
     * @see br.gov.caixa.pedesgo.arquitetura.controlador.AbstractBean#getPrefixoCasoDeUso()
    */
    @Override
    protected String getPrefixoCasoDeUso() {
	return null;
    }
    
    /**
     * @see br.gov.caixa.pedesgo.arquitetura.controlador.AbstractBean#getService()
    */
    @SuppressWarnings("unchecked")
    @Override
    public ManualUsuarioService getService() {
	return this.service;
    }

    /**
     * @see br.gov.caixa.pedesgo.arquitetura.controlador.AbstractBean#getVisao()
    */
    @Override
    public ManualUsuarioVisao getVisao() {
	if(!UtilObjeto.isReferencia(this.visao)) {
	    this.visao = new ManualUsuarioVisao();
	}
	return this.visao;
    }
    
    @Override
    public String iniciar() {
	this.limparVisao();
	this.pesquisar();
	return ManualUsuarioMB.PAGINA_CONSULTA;
    }
    
    private void limparVisao() {
	this.visao = new ManualUsuarioVisao();
    }
    
    public void pesquisar() {
	
	if(!this.filtrosValidos()) {
	    return;
	}
	
	final List<InfoManualUsuario> lista = this.getService().listar(this.getVisao().getManualUsuarioVO());

	this.getVisao().setListaManual(lista);

	if (CollectionUtils.isNotEmpty(lista)) {
	    this.getVisao().setQuantidadeItens(lista.size());
	} else {
	    this.getVisao().setQuantidadeItens(0);
	}
    }
    
    /**
     * <p>Método responsável por</p>
     *
     * @author f734546
     *
     * @return
     */
    private boolean filtrosValidos() {
	boolean isValido = true;
	
	final ManualUsuarioVO filtro = this.getVisao().getManualUsuarioVO();
	
	if(UtilObjeto.isReferencia(filtro.getDataInicio()) && UtilObjeto.isReferencia(filtro.getDataFim()) && UtilData.verificarSeDataEhMaior(filtro.getDataInicio(), filtro.getDataFim())) {
	    isValido = false;
	    super.adicionaMensagemDeAlerta("Data Inicial deve ser menor que Data Final.");
	}
	
	return isValido;
    }
    
    public void realizarUploadManual(final FileUploadEvent fileUploadEvent) {
	
	final boolean isUpload = this.service.realizarUploadManualUsuario(fileUploadEvent.getFile());
        
	this.pesquisar();
	
	if(isUpload) {
	    super.adicionaMensagemDeSucesso(ManualUsuarioMB.OPERACAO_REALIZADA_SUCESSO);
	    
	} else {
	    super.adicionaMensagemDeAlerta(ManualUsuarioMB.NAO_FOI_POSSIVEL_REALIZAR_A_OPERACAO);
	}
    }
    
    public void realizarDownloadManual(final InfoManualUsuario manual) {

	if (UtilObjeto.isReferencia(manual)) {
	    
	    final String nomeManual = manual.getNoManual();

	    try {
		
		final byte[] byteManual = this.service.getByteManualUsuario(nomeManual);
		
		if (byteManual == null) {
		    super.adicionaMensagemDeAlerta(ManualUsuarioMB.ARQUIVO_NAO_LOCALIZADO, nomeManual);
		} else {
		    UtilRelatorio.getInstancia().adicionarArquivoCessao(byteManual, nomeManual, EnumExtensaoArquivo.PDF.getExtensao());
		}


	    } catch (final Exception e) {
		LogCefUtil.error("Nao foi possivel baixar o manual " + nomeManual + ": " + e.getMessage());
		LogCefUtil.error(e);
	    }
	}
    }

}
