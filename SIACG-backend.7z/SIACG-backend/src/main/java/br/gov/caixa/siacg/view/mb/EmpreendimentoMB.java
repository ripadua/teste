/*
 * Copyright (c) 2019 Caixa Econômica Federal. Todos os direitos
 * reservados.
 *
 * Caixa Econômica Federal - SIACG - Sistema de Crédito Rural
 *
 * Este software foi desenvolvido sob demanda da CAIXA e está
 * protegido por leis de direitos autorais e tratados internacionais. As
 * condições de cópia e utilização do todo ou partes dependem de autorização da
 * empresa. Cópias não são permitidas sem expressa autorização. Não pode ser
 * comercializado ou utilizado para propósitos particulares.
 *
 * Uso exclusivo da Caixa Econômica Federal. A reprodução ou distribuição não
 * autorizada deste programa ou de parte dele, resultará em punições civis e
 * criminais e os infratores incorrem em sanções previstas na legislação em
 * vigor.
 *
 * Histórico do TFS:
 *
 * LastChangedRevision: $Revision$
 * LastChangedBy: $Author$
 * LastChangedDate: $Date$
 *
 * HeadURL: $HeadURL$
 *
 */	
package br.gov.caixa.siacg.view.mb;

import java.util.Collection;

import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;
import javax.inject.Inject;

import br.gov.caixa.pedesgo.arquitetura.controlador.ManutencaoBean;
import br.gov.caixa.siacg.model.domain.Empreendimento;
import br.gov.caixa.siacg.service.EmpreendimentoService;
import br.gov.caixa.siacg.view.form.EmpreendimentoVisao;

/**
 * <p>EmpreendimentoMB</p>
 *
 * <p>Descrição: Bean Gerenciável para a entidade {@link Empreendimento}.</p>
 *
 * <br><b>Empresa:</b> Cef - Caixa Econômica Federal
 *
 *
 * @author Mábio Barbosa
 *
 * @version 1.0
*/
@ManagedBean
@SessionScoped
public class EmpreendimentoMB extends ManutencaoBean<Empreendimento> {
    
    /** Atributo serialVersionUID. */
    private static final long serialVersionUID = -7256025274085055090L;

    /** Atributo PREFIXO_CASO_USO. */
    private static final String PREFIXO_CASO_USO = "empreendimento";
    

    /** Atributo NOME_MANAGED_BEAN. */
    public static final String NOME_MANAGED_BEAN = "empreendimentoMB";

    /** Atributo EL_MANAGED_BEAN. */
    public static final String EL_MANAGED_BEAN = "#{empreendimentoMB}";
    
    /** Atributo visao. */
    private transient EmpreendimentoVisao visao;
    
    /** Atributo empreendimentoService. */
    @Inject
    private transient EmpreendimentoService empreendimentoService;

    @Override
    protected String getPrefixoCasoDeUso() {
	return PREFIXO_CASO_USO;
    }

    @SuppressWarnings("unchecked")
    @Override
    public EmpreendimentoService getService() {
	return this.empreendimentoService;
    }

    @Override
    public EmpreendimentoVisao getVisao() {
	if (this.visao == null) {
	    this.visao = new EmpreendimentoVisao();
	}
	return this.visao;
    }
    
    public Collection<Empreendimento> autoCompleteEmpreendimento(final String noEmpreendimento) {
	return this.empreendimentoService.listarPorNoEmpreendimento(noEmpreendimento);
    }
}
