/*
 * Copyright (c) 2020 Caixa Econômica Federal. Todos os direitos
 * reservados.
 *
 * Caixa Econômica Federal - SIACG - Sistema de Crédito Rural
 *
 * Este software foi desenvolvido sob demanda da CAIXA e está
 * protegido por leis de direitos autorais e tratados internacionais. As
 * condições de cópia e utilização do todo ou partes dependem de autorização da
 * empresa. Cópias não são permitidas sem expressa autorização. Não pode ser
 * comercializado ou utilizado para propósitos particulares.
 *
 * Uso exclusivo da Caixa Econômica Federal. A reprodução ou distribuição não
 * autorizada deste programa ou de parte dele, resultará em punições civis e
 * criminais e os infratores incorrem em sanções previstas na legislação em
 * vigor.
 *
 * Histórico do TFS:
 *
 * LastChangedRevision: $Revision$
 * LastChangedBy: $Author$
 * LastChangedDate: $Date$
 *
 * HeadURL: $HeadURL$
 *
 */
package br.gov.caixa.siacg.view.form;

import java.util.Collection;

import br.gov.caixa.pedesgo.arquitetura.siico.util.UtilObjeto;
import br.gov.caixa.pedesgo.arquitetura.visao.ManutencaoVisao;
import br.gov.caixa.siacg.model.domain.InfoManualUsuario;
import br.gov.caixa.siacg.model.vo.ManualUsuarioVO;

/**
 * <p>
 * ManualUsuarioVisao
 * </p>
 *
 * <p>
 * Descrição: Armazena os dados de visão da funcionalidade responsável por
 * realizar o upload/ download dos manuais do usuário do siacg.
 * </p>
 *
 * <br>
 * <b>Empresa:</b> Cef - Caixa Econômica Federal
 *
 *
 * @author f734546
 *
 * @version 1.0
 */
public class ManualUsuarioVisao extends ManutencaoVisao<InfoManualUsuario> {

    /** Atributo serialVersionUID. */
    private static final long serialVersionUID = 1L;

    private transient ManualUsuarioVO manualUsuarioVO;

    private Integer quantidadeItens;
    private Collection<InfoManualUsuario> listaManual;

    /**
     * <p>
     * Retorna o valor do atributo manualUsuarioVO
     * </p>
     * .
     *
     * @return manualUsuarioVO
     */
    public ManualUsuarioVO getManualUsuarioVO() {
	if (!UtilObjeto.isReferencia(this.manualUsuarioVO)) {
	    this.manualUsuarioVO = new ManualUsuarioVO();
	}
	return this.manualUsuarioVO;
    }

    /**
     * <p>
     * Define o valor do atributo manualUsuarioVO
     * </p>
     * .
     *
     * @param manualUsuarioVO
     *            valor a ser atribuído
     */
    public void setManualUsuarioVO(final ManualUsuarioVO manualUsuarioVO) {
	this.manualUsuarioVO = manualUsuarioVO;
    }

    /**
     * <p>
     * Retorna o valor do atributo quantidadeItens
     * </p>
     * .
     *
     * @return quantidadeItens
     */
    public Integer getQuantidadeItens() {
	return this.quantidadeItens;
    }

    /**
     * <p>
     * Define o valor do atributo quantidadeItens
     * </p>
     * .
     *
     * @param quantidadeItens
     *            valor a ser atribuído
     */
    public void setQuantidadeItens(final Integer quantidadeItens) {
	this.quantidadeItens = quantidadeItens;
    }

    /**
     * <p>
     * Retorna o valor do atributo listaManual
     * </p>
     * .
     *
     * @return listaManual
     */
    public Collection<InfoManualUsuario> getListaManual() {
	return this.listaManual;
    }

    /**
     * <p>
     * Define o valor do atributo listaManual
     * </p>
     * .
     *
     * @param listaManual
     *            valor a ser atribuído
     */
    public void setListaManual(final Collection<InfoManualUsuario> listaManual) {
	this.listaManual = listaManual;
    }

}
