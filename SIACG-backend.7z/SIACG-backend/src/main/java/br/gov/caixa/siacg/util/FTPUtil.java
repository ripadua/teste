/*
 * Copyright (c) 2020 Caixa Econômica Federal. Todos os direitos
 * reservados.
 *
 * Caixa Econômica Federal - SIACG - Sistema de Crédito Rural
 *
 * Este software foi desenvolvido sob demanda da CAIXA e está
 * protegido por leis de direitos autorais e tratados internacionais. As
 * condições de cópia e utilização do todo ou partes dependem de autorização da
 * empresa. Cópias não são permitidas sem expressa autorização. Não pode ser
 * comercializado ou utilizado para propósitos particulares.
 *
 * Uso exclusivo da Caixa Econômica Federal. A reprodução ou distribuição não
 * autorizada deste programa ou de parte dele, resultará em punições civis e
 * criminais e os infratores incorrem em sanções previstas na legislação em
 * vigor.
 *
 * Histórico do TFS:
 *
 * LastChangedRevision: $Revision$
 * LastChangedBy: $Author$
 * LastChangedDate: $Date$
 *
 * HeadURL: $HeadURL$
 *
 */	
package br.gov.caixa.siacg.util;

import java.io.IOException;
import java.io.InputStream;

import org.apache.commons.io.IOUtils;
import org.apache.commons.net.ftp.FTP;
import org.apache.commons.net.ftp.FTPClient;
import org.apache.commons.net.ftp.FTPFile;
import org.apache.commons.net.ftp.FTPFileFilter;
import org.apache.commons.net.ftp.FTPReply;

import br.gov.caixa.pedesgo.arquitetura.util.UtilString;
import br.gov.caixa.pedesgo.arquitetura.siico.util.UtilObjeto;
import br.gov.caixa.pedesgo.arquitetura.util.LogCefUtil;

/**
 * <p>FTPUtil</p>
 *
 * <p>Classe utilitária responsável por armazenar métodos relacionados a
 * conexão FTP.</p>
 *
 * <br><b>Empresa:</b> Cef - Caixa Econômica Federal
 *
 *
 * @author f734546
 *
 * @version 1.0
*/
public class FTPUtil {
    
    /** Atributo ERRO. */
    private static final String ERRO = ". Erro: ";
    
    // propriedade do servidor - manual usuario
    public static final String FTP_CREDENCIAL_MANUAL_USUARIO = "siacg.credencial.ftp.manual.usuario";
    public static final String DIRETORIO_MANUAL_USUARIO = "siacg.diretorio.ftp.manual.usuario";

    private static final String FTP_CREDENCIAL_MANUAL_USUARIO_VALUE = System.getProperty(FTPUtil.FTP_CREDENCIAL_MANUAL_USUARIO);
    public static final String DIRETORIO_MANUAL_USUARIO_VALUE = System.getProperty(FTPUtil.DIRETORIO_MANUAL_USUARIO);
    
    private String servidor;
    private String usuario;
    private String senha;
    private FTPClient ftpClient;

    /**
     * Responsável pela criação de novas instâncias desta classe.
     *
     *
     */
    public FTPUtil() {
	super();

    }

    /**
     * Responsável pela criação de novas instâncias desta classe.
     *
     * @param servidorFtp
     * @param usuario
     * @param senha
     * @param ftpClient
     *
     */
    private FTPUtil(final String servidorFtp, final String usuario, final String senha, final FTPClient ftpClient) {
	this.servidor = servidorFtp;
	this.usuario = usuario;
	this.senha = senha;
	this.ftpClient = ftpClient;
    }
    
    public FTPUtil getFtpManual(final String servidorFtp) {
	if (UtilString.isVazio(servidorFtp) || UtilString.isVazio(FTPUtil.FTP_CREDENCIAL_MANUAL_USUARIO_VALUE)) {
	    LogCefUtil.warn("Não será possível estabelecer conexão com o servidor ftp (manual do usuario). Falta informações do servidor e/ ou propriedade " + FTPUtil.FTP_CREDENCIAL_MANUAL_USUARIO);
	    return null;
	}

	final String[] credencial = FTPUtil.FTP_CREDENCIAL_MANUAL_USUARIO_VALUE.split(":");
	String user = null;
	String pass = null;

	try {
	    user = credencial[0];
	    pass = credencial[1];
	} catch (Exception e) {
	    LogCefUtil.error("Ocorreu um erro ao recuperar as credenciais para conexão no servidor ftp (manual do usuario):");
	    LogCefUtil.error(e);
	}

	return new FTPUtil(servidorFtp, user, pass, new FTPClient());

    }
    
       /**
     * <p>Retorna o valor do atributo servidor</p>.
     *
     * @return servidor
    */
    public String getServidor() {
        return this.servidor;
    }

    /**
     * <p>Define o valor do atributo servidor</p>.
     *
     * @param servidor valor a ser atribuído
    */
    public void setServidor(final String servidor) {
        this.servidor = servidor;
    }
       
    /**
     * <p>
     * Método responsável por obter, a partir do diretorio FTP especificado, um
     * FTPFile do tipo arquivo com o nomeArquivo informado.
     * </p>
     *
     * @author f734546
     *
     * @param diretorio
     *            - diretório para busca do arquivo
     * @param nomeArquivo
     * @return
     */
    public FTPFile[] getFileFTPwithName(final String diretorio, final String nomeArquivo) {
	FTPFile[] files = null;

	try {

	    if (!UtilString.isVazio(diretorio) && !UtilString.isVazio(nomeArquivo) && this.connect()) {

		final FTPFileFilter filter = new FTPFileFilter() {

		    @Override
		    public boolean accept(FTPFile ftpFile) {
			return (ftpFile.isFile() && ftpFile.getName().equalsIgnoreCase(nomeArquivo));
		    }
		};

		files = this.ftpClient.listFiles(diretorio, filter);
	    }

	} catch (final IOException e) {
	    LogCefUtil.error("Erro ao listar arquivos do diretorio FTP " + diretorio + ", com o nome " + nomeArquivo + ": " + e);

	} finally {
	    this.disconnectFTP();
	}

	return files;
    }

    /**
     * <p>
     * Método responsável por realizar uma conexão FPT.
     * </p>
     * 
     * @throws IOException
     * @return boolean - Retorna true se a conexão foi realizada com sucesso e
     *         false caso contrário.
     * 
     */
    private boolean connect() throws IOException {

	boolean connect = false;

	this.ftpClient.connect(this.servidor);

	// verifica se conectou com sucesso!
	if (FTPReply.isPositiveCompletion(this.ftpClient.getReplyCode())) {
	    connect = true;
	    this.ftpClient.login(this.usuario, this.senha);

	} else {

	    // erro ao se conectar
	    this.disconnectFTP();
	    LogCefUtil.warn("Conexão com o servidor FTP " + this.servidor + " recusada!");
	}

	return connect;
    }

    /**
     * <p>
     * Método responsável por criar um arquivo em pathDestino.
     * </p>
     *
     * @author f734546
     *
     * @param pathOrigem
     *            - path de origem. Exemplo: caminhoOrigem/nome.txt
     * @param pathDestino
     *            - path destino. Exemplo: caminhoDestino/nome.txt
     */
    public void criarArquivoFTP(final String pathDestino, final InputStream in) {

	try {

	    if (!UtilString.isVazio(pathDestino) && UtilObjeto.isReferencia(in) && this.connect()) {

		this.ftpClient.enterLocalPassiveMode();
		this.ftpClient.setFileType(FTP.BINARY_FILE_TYPE);

		final boolean criou = this.ftpClient.storeFile(pathDestino, in);

		LogCefUtil.info("Arquivo " + pathDestino + " criado: " + criou);

		this.disconnectFTP();
	    }

	} catch (final IOException e) {
	    LogCefUtil.error("Erro ao criar arquivo no servidor FTP - " + pathDestino + FTPUtil.ERRO + e);
	    this.disconnectFTP();
	}
    }

    /**
     * <p>
     * Método responsável por renomear e/ou transferir um arquivo de pathDestino
     * para pathOrigem.
     * </p>
     *
     * @author f734546
     *
     * @param pathOrigem
     *            - path de origem. Exemplo: caminhoOrigem/nome.txt
     * @param pathDestino
     *            - path destino. Exemplo: caminhoDestino/nome2.txt
     * @return true, se o arquivo foi renomeado e/ou transferido com sucesso
     */
    public boolean renomearTransferirArquivoFTP(final String pathOrigem, final String pathDestino) {

	boolean alterou = false;

	try {

	    if (!UtilString.isVazio(pathOrigem) && !UtilString.isVazio(pathDestino) && this.connect()) {

		this.ftpClient.enterLocalPassiveMode();
		this.ftpClient.setFileType(FTP.ASCII_FILE_TYPE);

		alterou = this.ftpClient.rename(pathOrigem, pathDestino);

		LogCefUtil.info("Arquivo alterado de " + pathOrigem + " para " + pathDestino + ": " + alterou);
	    }

	} catch (final IOException e) {
	    LogCefUtil.error("Erro ao criar arquivo no diretório do servidor FTP - " + pathDestino + FTPUtil.ERRO + e);

	} finally {
	    this.disconnectFTP();
	}

	return alterou;
    }

    /**
     * <p>
     * Método responsável por recuperar os bytes do arquivo especificado.
     * </p>
     *
     * @author f734546
     *
     * @param pathArquivo
     *            - caminho\nomeArquivo
     */
    public byte[] getByteFileFTP(final String pathArquivo) {

	byte[] bytesFile = null;

	try {

	    if (this.connect()) {
		this.ftpClient.enterLocalPassiveMode();
		this.ftpClient.setFileType(FTP.ASCII_FILE_TYPE);
		final InputStream is = this.ftpClient.retrieveFileStream(pathArquivo);

		if (is != null) {

		    bytesFile = IOUtils.toByteArray(is);
		    
		    is.close();
		}

	    }

	} catch (final IOException e) {
	    LogCefUtil.error("Erro ao obter InputStream do arquivo " + pathArquivo + " do servidor FTP: " + e);

	} finally {
	    this.disconnectFTP();
	}

	return bytesFile;
    }
    
    /**
     * <p>
     * Método responsável por deletar um arquivo que está em diretorioFtp.
     * </p>
     *
     * @author f734546
     *
     * @param pathFile
     *            - caminho do arquivo a ser deletado. Exemplo: caminho/nome.txt
     * @param diretorioFtp
     *            - diretorio onde se encontra o arquivo
     */
    public boolean deletarArquivoFTP(final String pathFile) {

	boolean deletou = false;
	try {

	    if (this.connect()) {

		this.ftpClient.enterLocalPassiveMode();
		this.ftpClient.setFileType(FTP.BINARY_FILE_TYPE);

		deletou = this.ftpClient.deleteFile(pathFile);

		LogCefUtil.info("Arquivo deletado de " + pathFile + ": " + deletou);
	    }

	} catch (final IOException e) {
	    LogCefUtil.error("Erro ao deletar arquivo " + pathFile + FTPUtil.ERRO + e);

	} finally {
	    this.disconnectFTP();
	}

	return deletou;
    }

    /**
     * Fecha a conexão com o FTP.
     * 
     * @description Faz a desconexão com o FTP.
     * @return void
     * 
     */
    public void disconnectFTP() {
	try {

	    this.ftpClient.logout();
	    this.ftpClient.disconnect();

	} catch (final IOException e) {
	    LogCefUtil.error("Erro ao fechar conexão com servidor FTP: " + e);
	}
    }
    
    public static String getDiretorioManualUsuario() {
	final String diretorio = FTPUtil.DIRETORIO_MANUAL_USUARIO_VALUE;
	
	if(UtilString.isVazio(diretorio)) {
	    LogCefUtil.warn("Falta valor para a propriedade " + FTPUtil.DIRETORIO_MANUAL_USUARIO + " do servidor.");
	}
	
	return diretorio;
    }

}
