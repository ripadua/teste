package br.gov.caixa.siacg.strategy.impl;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;

import javax.ejb.EJB;
import javax.ejb.Stateless;

import org.apache.commons.collections.CollectionUtils;

import br.gov.caixa.pedesgo.arquitetura.to.FeriadoTO;
import br.gov.caixa.pedesgo.arquitetura.util.UtilData;
import br.gov.caixa.pedesgo.arquitetura.util.UtilFeriado;
import br.gov.caixa.siacg.comum.to.ChequeCalculoTO;
import br.gov.caixa.siacg.comum.to.ContaContratoCalculoTO;
import br.gov.caixa.siacg.comum.to.ContratoCalculoTO;
import br.gov.caixa.siacg.comum.to.CustodiaChequeCalculoTO;
import br.gov.caixa.siacg.comum.to.GarantiaContratoCalculoTO;
import br.gov.caixa.siacg.dao.ChequeDAO;
import br.gov.caixa.siacg.dao.ChequeExcepcionadoDAO;
import br.gov.caixa.siacg.dao.FeriadoDAO;
import br.gov.caixa.siacg.dao.ParametroCalculoDAO;
import br.gov.caixa.siacg.dao.UnidadeDAO;
import br.gov.caixa.siacg.model.domain.AnaliseContrato;
import br.gov.caixa.siacg.model.enums.ParametroCalculoEnum;
import br.gov.caixa.siacg.model.enums.TipoOrigemContaContratoEnum;
import br.gov.caixa.siacg.model.vo.ParametrosCalculoGarantiaVO;
import br.gov.caixa.siacg.model.vo.RelatorioAnaliseContratoVO;
import br.gov.caixa.siacg.strategy.CalculoGarantia;

/**
 * <p>
 * CalculoGarantiaDuplicata
 * </p>
 * <p>
 * Descrição: Implementação do calculo para Garantia do tipo Cheques.
 * </p>
 * <br>
 * <b>Empresa:</b> Cef - Caixa Econômica Federal
 *
 * @author guilherme.santos
 * @version 1.0
 */
@Stateless(mappedName = "CalculoGarantiaCheques")
public class CalculoGarantiaCheques implements CalculoGarantia {

    private static final long serialVersionUID = 1800610647163453039L;
    /** Atributo UMA_SEMANA. */
    private static final int UMA_SEMANA = 7;

    /** Atributo parametroCalculoDAO. */
    @EJB
    private transient ParametroCalculoDAO parametroCalculoDAO;
    /** Atributo chequeDAO. */
    @EJB
    private transient ChequeDAO chequeDAO;
    /** Atributo chequeExcepcionadoDAO. */
    @EJB
    private transient ChequeExcepcionadoDAO chequeExcepcionadoDAO;
    /** Atributo feriadoDAO. */
    @EJB
    private transient FeriadoDAO feriadoDAO;
    /** Atributo unidadeDAO. */
    @EJB
    private transient UnidadeDAO unidadeDAO;

    /**
     * @see br.gov.caixa.siacg.strategy.CalculoGarantia#calcular(br.gov.caixa.siacg.model.vo.ParametrosCalculoGarantiaVO,
     *      br.gov.caixa.siacg.model.vo.RelatorioAnaliseContratoVO)
     */
    @Override
    public RelatorioAnaliseContratoVO calcular(final ParametrosCalculoGarantiaVO parametrosCalculo, RelatorioAnaliseContratoVO relatorio) {

        final AnaliseContrato analiseContrato = relatorio.getAnaliseContrato();
        final Collection<ChequeCalculoTO> listaCompletaCheques = this.consultarTodosCheques(parametrosCalculo);
        final Integer nuGarantia = parametrosCalculo.getGarantiaContrato().getNuGarantiaContrato();
        final ContratoCalculoTO contrato = parametrosCalculo.getContrato();

        Collection<FeriadoTO> listaFeriado = null;
        String estadoUnidade = null;

        if (!listaCompletaCheques.isEmpty()) {
            // busca o ultimo cheque e o cheque mais antigo
            final Date dataChequeUltimo = this.consultarChequeMaisAntigoOuUltimo(listaCompletaCheques, true);
            final Date dataChequeMaisAntigo = this.consultarChequeMaisAntigoOuUltimo(listaCompletaCheques, false);

            // consulta a lista de feriado das datas dos cheques
            listaFeriado = this.feriadoDAO.consultarFeriadosEntreDatas(dataChequeMaisAntigo,
        	    UtilData.somarSubtrairDias(dataChequeUltimo, CalculoGarantiaCheques.UMA_SEMANA), contrato.getNuUnidade(),
                    contrato.getNuNatural());

            // busca o estado da unidade para obter feriados estaduais
            estadoUnidade = this.unidadeDAO.getEstadoUnidade(contrato.getNuUnidade(), contrato.getNuNatural());
        }

        relatorio.setValorApurado(parametrosCalculo.getValorApurado());
        relatorio.setValorEsperado(parametrosCalculo.getValorEsperado());
        analiseContrato.setValorTotalChequesGarantia(this.calcularSomatoriaValores(listaCompletaCheques));

        // Trata os Cheques de outros Contratos
        final Collection<ChequeCalculoTO> listaChequesOutrosContratos = this.consultarChequesOutrasGarantias(listaCompletaCheques,
                parametrosCalculo.getGarantiaContrato());
        listaCompletaCheques.removeAll(listaChequesOutrosContratos);
        analiseContrato.setValorChequesUtilizadosOutros(this.calcularSomatoriaValores(listaChequesOutrosContratos));

        // Trata os Cheques fora do prazo minimo parametrizado
        final Integer vrPrazoMinimoPermitido;
        vrPrazoMinimoPermitido = this.verificarQtdParametroPermitido(ParametroCalculoEnum.PRAZO_MINIMO_CHEQUE,
                parametrosCalculo.getGarantiaContrato().getVrPrazoMinimoPermitido());
        relatorio = this.consultarChequesForaPrazoMinimo(listaCompletaCheques, relatorio, vrPrazoMinimoPermitido);
        listaCompletaCheques.removeAll(relatorio.getListaChequesForaPrazoMinimo());
        analiseContrato.setValorChequesForaPrazoMinimo(this.calcularSomatoriaValores(relatorio.getListaChequesForaPrazoMinimo()));
        analiseContrato.setQuantidadeChequesForaPrazoMinimo(relatorio.getListaChequesForaPrazoMinimo().size());

        // Trata os Cheques fora do prazo maximo parametrizado
        final Integer vrPrazoMaximoPermitido;
        vrPrazoMaximoPermitido = this.verificarQtdParametroPermitido(ParametroCalculoEnum.PRAZO_MAXIMO_CHEQUE,
                parametrosCalculo.getGarantiaContrato().getVrPrazoMaximoPermitido());
        relatorio = this.consultarChequesForaPrazoMaximo(listaCompletaCheques, relatorio, vrPrazoMaximoPermitido, listaFeriado,
                parametrosCalculo.getContrato(), estadoUnidade);
        listaCompletaCheques.removeAll(relatorio.getListaChequesForaPrazoMaximo());
        analiseContrato.setValorChequesForaPrazoMaximo(this.calcularSomatoriaValores(relatorio.getListaChequesForaPrazoMaximo()));
        analiseContrato.setQuantidadeChequesForaPrazoMaximo(relatorio.getListaChequesForaPrazoMaximo().size());

        // Trata os Cheques fora do valor maximo parametrizado
        final BigDecimal vrMaximoPermitido;
        vrMaximoPermitido = this.verificarVrParametroPermitido(ParametroCalculoEnum.VALOR_MAXIMO_CHEQUE,
                parametrosCalculo.getGarantiaContrato().getVrMaximoPermitido());
        relatorio = this.consultarChequesForaValorMaximo(listaCompletaCheques, relatorio, vrMaximoPermitido);
        listaCompletaCheques.removeAll(relatorio.getListaChequesForaValorMaximo());
        analiseContrato.setValorChequesForaValorMaximo(this.calcularSomatoriaValores(relatorio.getListaChequesForaValorMaximo()));
        analiseContrato.setQuantidadeChequesForaValorMaximo(relatorio.getListaChequesForaValorMaximo().size());

        // Desvincula todos os cheques para uma nova parametrização
        this.chequeDAO.limparChequesDaGarantia(nuGarantia);

        // Parametriza a garantia de Cheque
        relatorio = this.parametrizarGarantia(listaCompletaCheques, relatorio, parametrosCalculo);
        if (CollectionUtils.isNotEmpty(relatorio.getListaChequesUtilizados())) {
            listaCompletaCheques.removeAll(relatorio.getListaChequesUtilizados());
            this.chequeDAO.parametrizarChequesComGarantia(relatorio.getListaChequesUtilizados(), nuGarantia);
            relatorio.setValorApurado(this.somarValores(relatorio.getListaChequesUtilizados()));
        }

        // Atribui o valor não utilizado (disponivel) dos Cheques
        analiseContrato.setValorChequesNaoUtilizados(this.consultarValorNaoUtilizado(listaCompletaCheques));
        analiseContrato.setValorChequesForaParametro(this.consultarVrItensForaParametros(analiseContrato));
        analiseContrato.setValorChequesExcepcionados(analiseContrato.getValorChequesExcepcionados()
                .add(this.chequeExcepcionadoDAO.somarValorChequesExcepcionadosDaGarantiaContrato(parametrosCalculo.getGarantiaContrato().getNuGarantiaContrato())));

        analiseContrato.setValorLiquidoGarantiaCheque(this.calcularValorLiquidoCheque(analiseContrato));

        return relatorio;
    }

    /**
     * <p>
     * Método responsável por consultar na lista de cheques, qual o cheque com a
     * data de vencimento mais antiga ou o ultimo.
     * <p>
     *
     * @param listaCheques
     *            valor a ser atribuido
     * @param consultarUltimo
     *            valor a ser atribuido
     * @return Date
     * @author Caio Graco
     */
    private Date consultarChequeMaisAntigoOuUltimo(final Collection<ChequeCalculoTO> listaCheques, final boolean consultarUltimo) {

        // pega o primeiro cheque da lista, apenas para comparação
        Date dataChequeAntigoOuUltimo = listaCheques.iterator().next().getDtVencimento();

        for (final ChequeCalculoTO cheque : listaCheques) {

            // se for true, busca o ultimo cheque, senão, o mais antigo
            if (consultarUltimo) {
                if (UtilData.verificarSeDataEhMaior(cheque.getDtVencimento(), dataChequeAntigoOuUltimo)) {
                    dataChequeAntigoOuUltimo = cheque.getDtVencimento();
                }
            } else {
                if (UtilData.verificarSeDataEhMenor(cheque.getDtVencimento(), dataChequeAntigoOuUltimo)) {
                    dataChequeAntigoOuUltimo = cheque.getDtVencimento();
                }
            }
        }

        return dataChequeAntigoOuUltimo;
    }

    /**
     * <p>
     * Método responsável por somar os valores de cheques da lista.
     * <p>
     *
     * @param listaChequesUtilizados
     *            valor a ser atribuido
     * @return BigDecimal
     * @author guilherme.santos
     */
    private BigDecimal somarValores(final Collection<ChequeCalculoTO> listaChequesUtilizados) {
        BigDecimal retorno = BigDecimal.ZERO;

        for (final ChequeCalculoTO cheque : listaChequesUtilizados) {
            retorno = retorno.add(cheque.getVrCheque());
        }

        return retorno;
    }

    /**
     * <p>
     * Método responsável por verificar se existe parametro para garantia, caso
     * não exista, consulta dos parametros automaticos.
     * <p>
     *
     * @param parametro
     *            valor a ser atribuido
     * @param vrPrazoMinimoPermitido
     *            valor a ser atribuido
     * @return Integer
     * @author guilherme.santos
     */
    private Integer verificarQtdParametroPermitido(final ParametroCalculoEnum parametro, final BigDecimal vrPrazoMinimoPermitido) {
        if (vrPrazoMinimoPermitido == null) {
            return this.parametroCalculoDAO.obter(parametro.getCodigo()).getVrParametroCalculo().intValue();
        }
        return vrPrazoMinimoPermitido.intValue();

    }

    /**
     * <p>
     * Método responsável por verificar se existe parametro para garantia, caso
     * não exista, consulta dos parametros automaticos.
     * <p>
     *
     * @param parametro
     *            valor a ser atribuido
     * @param vrPrazoMinimoPermitido
     *            valor a ser atribuido
     * @return BigDecimal
     * @author guilherme.santos
     */
    private BigDecimal verificarVrParametroPermitido(final ParametroCalculoEnum parametro, final BigDecimal vrPrazoMinimoPermitido) {
        if (vrPrazoMinimoPermitido == null) {
            return this.parametroCalculoDAO.obter(parametro.getCodigo()).getVrParametroCalculo();
        }
        return vrPrazoMinimoPermitido;

    }

    /**
     * <p>
     * Método responsável por calcular a somatoria dos valores dos cheques.
     * <p>
     *
     * @param listaCompletaCheques
     *            valor a ser atribuido
     * @return BigDecimal
     * @author guilherme.santos
     */
    private BigDecimal calcularSomatoriaValores(final Collection<ChequeCalculoTO> listaCompletaCheques) {
        BigDecimal retorno = BigDecimal.ZERO;

        for (final ChequeCalculoTO cheque : listaCompletaCheques) {
            retorno = retorno.add(cheque.getVrCheque());
        }
        return retorno;

    }

    /**
     * <p>
     * Método responsável por consultar o valor dos itens fora do parametross.
     * <p>
     *
     * @param analiseContrato
     *            valor a ser atribuido
     * @return BigDecimal
     * @author guilherme.santos
     */
    private BigDecimal consultarVrItensForaParametros(final AnaliseContrato analiseContrato) {
        return analiseContrato.getValorChequesForaPrazoMinimo().add(analiseContrato.getValorChequesForaPrazoMaximo())
                .add(analiseContrato.getValorChequesForaValorMaximo());
    }

    /**
     * <p>
     * Método responsável por somar o valor não utilizado na parametrização da
     * garantia.
     * <p>
     *
     * @param listaCompletaCheques
     *            valor a ser atribuido
     * @return BigDecimal
     * @author guilherme.santos
     */
    private BigDecimal consultarValorNaoUtilizado(final Collection<ChequeCalculoTO> listaCompletaCheques) {
        BigDecimal somatoria = BigDecimal.ZERO;

        for (final ChequeCalculoTO cheque : listaCompletaCheques) {
            somatoria = somatoria.add(cheque.getVrCheque());
        }

        return somatoria;
    }

    /**
     * <p>
     * Método responsável por parametrizar os cheques disponiveis para
     * satisfazer o valor esperado da garantia.
     * <p>
     *
     * @param listaCompletaCheques
     *            valor a ser atribuido
     * @param relatorio
     *            valor a ser atribuido
     * @param parametrosCalculo
     *            valor a ser atribuido
     * @return RelatorioanaliseContratoVO
     * @author guilherme.santos
     */
    private RelatorioAnaliseContratoVO parametrizarGarantia(final Collection<ChequeCalculoTO> listaCompletaCheques, final RelatorioAnaliseContratoVO relatorio,
            final ParametrosCalculoGarantiaVO parametrosCalculo) {

        BigDecimal somaValoresUsados = BigDecimal.ZERO;

        for (final ChequeCalculoTO cheque : listaCompletaCheques) {
            if (parametrosCalculo.getValorEsperado().compareTo(somaValoresUsados) > 0) {
                somaValoresUsados = somaValoresUsados.add(cheque.getVrCheque());
                cheque.setNuGarantia(parametrosCalculo.getGarantiaContrato().getNuGarantia());
                relatorio.getListaChequesUtilizados().add(cheque);
            } else {
                break;
            }
        }

        return relatorio;

    }

    /**
     * <p>
     * Método responsável por consultar e tratar cheques fora do valor maximo
     * parametrizado.
     * <p>
     *
     * @param listaCheques
     *            valor a ser atribuido
     * @param relatorio
     *            valor a ser atribuido
     * @param vrMaximoPermitido
     *            valor a ser atribuido
     * @return RelatorioAnaliseContratoVO
     * @author guilherme.santos
     */
    private RelatorioAnaliseContratoVO consultarChequesForaValorMaximo(final Collection<ChequeCalculoTO> listaCheques,
            final RelatorioAnaliseContratoVO relatorio, final BigDecimal vrMaximoPermitido) {

        BigDecimal vrChequesForaValorMaximo = BigDecimal.ZERO;
        Integer qtChequesForaValorMaximo = 0;

        for (final ChequeCalculoTO cheque : listaCheques) {
            if (this.validarChequeForaValorMaximo(vrMaximoPermitido, cheque)) {
                relatorio.getListaChequesForaValorMaximo().add(cheque);
                vrChequesForaValorMaximo = vrChequesForaValorMaximo.add(cheque.getVrCheque());
                qtChequesForaValorMaximo++;
            }
        }

        relatorio.getAnaliseContrato().setValorChequesForaValorMaximo(vrChequesForaValorMaximo);
        relatorio.getAnaliseContrato().setQuantidadeChequesForaValorMaximo(qtChequesForaValorMaximo);
        relatorio.getAnaliseContrato().setLimiteChequesForaValorMaximo(vrMaximoPermitido);

        return relatorio;

    }

    /**
     * <p>
     * Método responsável por calcular o valor liquido da cheque.
     * <p>
     *
     * @param analiseContrato
     *            valor a ser atribuido
     * @return BigDecimal
     * @author guilherme.santos
     */
    private BigDecimal calcularValorLiquidoCheque(final AnaliseContrato analiseContrato) {
        return analiseContrato.getValorTotalChequesGarantia().add(analiseContrato.getValorChequesExcepcionados())
                .subtract(analiseContrato.getValorChequesUtilizadosOutros()).subtract(analiseContrato.getValorChequesForaParametro());
    }

    /**
     * <p>
     * Método responsável por consultar e tratar os dados dos cheques fora do
     * prazo maximo parametrizado.
     * <p>
     *
     * @param listaCheques
     *            valor a ser atribuido
     * @param relatorio
     *            valor a ser atribuido
     * @param vrPrazoMaximo
     *            valor a ser atribuido
     * @param listaFeriado
     *            valor a ser atribuido
     * @param contrato
     *            valor a ser atribuido
     * @param estadoUnidade
     *            valor a ser atribuido
     * @return RelatorioAnaliseContratoVO
     * @author Caio Graco
     */
    private RelatorioAnaliseContratoVO consultarChequesForaPrazoMaximo(final Collection<ChequeCalculoTO> listaCheques,
            final RelatorioAnaliseContratoVO relatorio, final Integer vrPrazoMaximo, final Collection<FeriadoTO> listaFeriado,
            final ContratoCalculoTO contrato, final String estadoUnidade) {

        final Integer diasPrazoMaximo = vrPrazoMaximo == null ? Integer.valueOf("0") : vrPrazoMaximo;
        final Date dataMaximaPermitida = UtilData.somarSubtrairDias(UtilData.converterDataSemHoras(new Date()), diasPrazoMaximo);
        BigDecimal vrChequesForaPrazoMaximo = BigDecimal.ZERO;
        Integer qtChequesForaPrazoMaximo = 0;

        for (final ChequeCalculoTO cheque : listaCheques) {
            if (this.validarChequeForaPrazoMaximo(dataMaximaPermitida, cheque, listaFeriado, contrato, estadoUnidade)) {
                relatorio.getListaChequesForaPrazoMaximo().add(cheque);
                vrChequesForaPrazoMaximo = vrChequesForaPrazoMaximo.add(cheque.getVrCheque());
                qtChequesForaPrazoMaximo++;
            }
        }

        relatorio.getAnaliseContrato().setValorChequesForaPrazoMaximo(vrChequesForaPrazoMaximo);
        relatorio.getAnaliseContrato().setQuantidadeChequesForaPrazoMaximo(qtChequesForaPrazoMaximo);
        relatorio.getAnaliseContrato().setLimiteChequesForaPrazoMaximo(vrPrazoMaximo == null ? BigDecimal.ZERO : BigDecimal.valueOf(vrPrazoMaximo));

        return relatorio;

    }

    /**
     * <p>
     * Método responsável por consultar e tratar dados dos cheques fora do prazo
     * minimo parametrizado.
     * <p>
     *
     * @param listaCheques
     *            valor a ser atribuido
     * @param relatorio
     *            valor a ser atribuido
     * @param vrPrazoMinimo
     *            valor a ser atribuido
     * @return RelatorioAnaliseContratoVO
     * @author guilherme.santos
     */
    private RelatorioAnaliseContratoVO consultarChequesForaPrazoMinimo(final Collection<ChequeCalculoTO> listaCheques,
            final RelatorioAnaliseContratoVO relatorio, final Integer vrPrazoMinimo) {
        final Integer diasPrazoMinimo = vrPrazoMinimo == null ? Integer.valueOf("0") : vrPrazoMinimo;
        BigDecimal vrChequesForaPrazoMinimo = BigDecimal.ZERO;
        Integer qtChequesForaPrazoMinimo = 0;

        for (final ChequeCalculoTO cheque : listaCheques) {
            if (this.validarChequeForaPrazoMinimo(diasPrazoMinimo, cheque)) {
                relatorio.getListaChequesForaPrazoMinimo().add(cheque);
                vrChequesForaPrazoMinimo = vrChequesForaPrazoMinimo.add(cheque.getVrCheque());
                qtChequesForaPrazoMinimo++;
            }
        }

        relatorio.getAnaliseContrato().setValorChequesForaPrazoMinimo(vrChequesForaPrazoMinimo);
        relatorio.getAnaliseContrato().setQuantidadeChequesForaPrazoMinimo(qtChequesForaPrazoMinimo);
        relatorio.getAnaliseContrato().setLimiteChequesForaPrazoMinimo(vrPrazoMinimo == null ? BigDecimal.ZERO : BigDecimal.valueOf(vrPrazoMinimo));

        return relatorio;

    }

    /**
     * <p>
     * Método responsável por validar se o valor do cheque está acima do máximo
     * parametrizado.
     * <p>
     *
     * @param vrMaximoPermitido
     *            valor a ser atribuido
     * @param cheque
     *            valor a ser atribuido
     * @return boolean
     * @author guilherme.santos
     */
    private boolean validarChequeForaValorMaximo(final BigDecimal vrMaximoPermitido, final ChequeCalculoTO cheque) {
        return vrMaximoPermitido != null && cheque.getVrCheque().compareTo(vrMaximoPermitido) > 0;

    }

    /**
     * <p>
     * Método responsável por validar se o valor do cheque está fora do prazo
     * minimo parametrizado.
     * <p>
     *
     * @param diasPrazoMinimo
     *            valor a ser atribuido
     * @param cheque
     *            valor a ser atribuido
     * @return boolean
     * @author guilherme.santos
     */
    private boolean validarChequeForaPrazoMinimo(final int diasPrazoMinimo, final ChequeCalculoTO cheque) {
        return cheque.consultarDiasVigencia() < diasPrazoMinimo;
    }

    /**
     * <p>
     * Método responsável por validar se o valor do cheque está fora do prazo
     * maximo parametrizado.
     * <p>
     *
     * @param dataMaximaPermitida
     *            valor a ser atribuido
     * @param cheque
     *            valor a ser atribuido
     * @param listaFeriado
     *            valor a ser atribuido
     * @param contrato
     *            valor a ser atribuido
     * @param estadoUnidade
     *            valor a ser atribuido
     * @return boolean
     * @author Caio Graco
     */
    private boolean validarChequeForaPrazoMaximo(final Date dataMaximaPermitida, final ChequeCalculoTO cheque, final Collection<FeriadoTO> listaFeriado,
            final ContratoCalculoTO contrato, final String estadoUnidade) {
        Date dataVencimentoDiaUtil = new Date();

        if (listaFeriado != null) {
            final Date dataVencimentoSemHora = UtilData.converterDataSemHoras(cheque.getDtVencimento());
            dataVencimentoDiaUtil = UtilFeriado.proximoDiaUtil(listaFeriado, contrato.getNuUnidade(), contrato.getNuNatural(), estadoUnidade,
                    dataVencimentoSemHora);
        }

        return UtilData.verificarSeDataEhMaior(dataVencimentoDiaUtil, dataMaximaPermitida);
    }

    /**
     * <p>
     * Método responsável por consultar todos os cheques que não estão marcados
     * para esse contrato.
     * <p>
     *
     * @param listaCompletaCheques
     *            valor a ser atribuido
     * @param garantia
     *            valor a ser atribuido
     * @return Collectin<Cheque>
     * @author guilherme.santos
     */
    private Collection<ChequeCalculoTO> consultarChequesOutrasGarantias(final Collection<ChequeCalculoTO> listaCompletaCheques, final GarantiaContratoCalculoTO garantia) {

        final Collection<ChequeCalculoTO> listaChequesOutrosContratos = new ArrayList<>();

        for (final ChequeCalculoTO cheque : listaCompletaCheques) {
            if (cheque.getNuGarantia() != null && !cheque.getNuGarantia().equals(garantia.getNuGarantia())) {
                listaChequesOutrosContratos.add(cheque);
            }
        }

        return listaChequesOutrosContratos;

    }

    /**
     * <p>
     * Método responsável por consultar todos os cheques marcados para garantia
     * de Cheque.
     * <p>
     *
     * @param parametrosCalculo
     *            valor a ser atribuido
     * @return Collection<Cheque>
     * @author guilherme.santos
     */
    private Collection<ChequeCalculoTO> consultarTodosCheques(final ParametrosCalculoGarantiaVO parametrosCalculo) {

        final Collection<ChequeCalculoTO> listaCheques = new ArrayList<>();

        for (final ContaContratoCalculoTO contaContrato : parametrosCalculo.getContrato().getListaContaContrato()) {

            // Realiza calculos apenas de Contas importadas ou/e para cheque
            if (contaContrato.getIcUtilizarSaldoCheque() && (contaContrato.getIcOrigem() == TipoOrigemContaContratoEnum.IMPORTADO
                    || contaContrato.getIcOrigem() == TipoOrigemContaContratoEnum.CHEQUE) && contaContrato.getContaCorrente() != null
                    && contaContrato.getContaCorrente().getListaCustodiaCheque() != null) {

                for (final CustodiaChequeCalculoTO custodia : contaContrato.getContaCorrente().getListaCustodiaCheque()) {
                    if (custodia.getListaCheque() != null) {
                    	listaCheques.addAll(custodia.getListaCheque());                    	
                    }
                }
            }
        }
        return listaCheques;
    }
}
