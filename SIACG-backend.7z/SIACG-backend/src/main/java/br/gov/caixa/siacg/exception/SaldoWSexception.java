/*
 * Copyright (c) 2017 Caixa Econômica Federal. Todos os direitos
 * reservados.
 *
 * Caixa Econômica Federal - SIACG
 *
 * Este software foi desenvolvido sob demanda da CAIXA e está
 * protegido por leis de direitos autorais e tratados internacionais. As
 * condições de cópia e utilização do total ou partes dependem de autorização da
 * empresa. Cópias não são permitidas sem expressa autorização. Não pode ser
 * comercializado ou utilizado para propósitos particulares.
 *
 * Uso exclusivo da Caixa Econômica Federal. A reprodução ou distribuição não
 * autorizada deste programa ou de parte dele, resultará em punições civis e
 * criminais e os infratores incorrem em sanções previstas na legislação em
 * vigor.
 *
 * Histórico do Subversion:
 *
 * LastChangedRevision: $Revision$
 * LastChangedBy: $Author$
 * LastChangedDate: $Date$
 *
 * HeadURL: $HeadURL$
 *
 */
package br.gov.caixa.siacg.exception;


/**
 * <p>
 * SaldoWSexception
 * </p>
 * <p>
 * Descrição: Classe responsável por representar uma exceção que pode ser
 * lançada sempre que uma regra negocial não for atendida durante o recebimento
 * de uma mensagem pelo serviço que consulta os saldos de contas de uma pessoa
 * (SaldoWS).
 * </p>
 * <br>
 * <b>Empresa:</b> Cef - Caixa Econômica Federal
 *
 * @author gerusa.soares
 * @version 1.0
 */
public class SaldoWSexception extends Exception {

    /** Atributo serialVersionUID. */
    private static final long serialVersionUID = -7839402060908629701L;

    /** Atributo codigo. */
    private final String codigo;

    /** Atributo descricao. */
    private final String descricao;
    
    /** Atributo sistemaConsultado. */
    private final String sistemaConsultado;
    
    /** Atributo Chave do Erro no .properties. */
    private final String chave;

    /**
     * Construtor
     *
     * @param codigo
     * @param descricao
     */
    public SaldoWSexception(final String sistemaConsultado, final String codigo, final String descricao) {
        this(sistemaConsultado, codigo, descricao, null);
    }
    
    /**
     * 
     * Responsável pela criação de novas instâncias desta classe.
     *
     * @param sistemaConsultado Sintema que está sendo integrado
     * @param codigo código do erro @see RetornoServicoSaldoEnum
     * @param descricao descrição do erro.
     * @param chave chave do erro no app-mensagem.properties
     *
     */
    public SaldoWSexception(final String sistemaConsultado, final String codigo, final String descricao, String chave) {
    	this.sistemaConsultado = sistemaConsultado;
    	this.codigo = codigo;
        this.descricao = descricao;
        this.chave = chave;
    }

    /**
     * Retorna o valor do atributo codigo.
     *
     * @return codigo
     */
    public String getCodigo() {
        return this.codigo;
    }

    /**
     * Retorna o valor do atributo descricao.
     *
     * @return descricao
     */
    public String getDescricao() {
        return this.descricao;
    }

    /**
     * Retorna o valor do atributo sistemaConsultado.
     *
     * @return sistemaConsultado
     */
	public String getSistemaConsultado() {
		return sistemaConsultado;
	}

	/**
	 * <p>Retorna o valor do atributo chave</p>.
	 *
	 * @return chave
	*/
	public String getChave() {
		return this.chave;
	}

	/**
	 * @see java.lang.Object#toString()
	*/
	@Override
	public String toString() {
	    return "SaldoWSexception [codigo=" + codigo + ", descricao=" + descricao + ", sistemaConsultado=" + sistemaConsultado + ", chave=" + chave
		    + "]";
	}
	
}