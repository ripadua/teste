package br.gov.caixa.siacg.view.mb;

import javax.ejb.EJB;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;

import br.gov.caixa.pedesgo.arquitetura.controlador.AbstractBean;
import br.gov.caixa.pedesgo.arquitetura.controlador.ManutencaoBean;
import br.gov.caixa.pedesgo.arquitetura.util.LogCefUtil;
import br.gov.caixa.pedesgo.arquitetura.util.UtilObjeto;
import br.gov.caixa.pedesgo.arquitetura.util.UtilString;
import br.gov.caixa.siacg.model.domain.TemplateMensageria;
import br.gov.caixa.siacg.service.TemplateMensageriaService;
import br.gov.caixa.siacg.view.form.TemplateMensageriaVisao;

/**
 * <p>
 * TemplateMensageriaMB.
 * </p>
 * <p>
 * Descrição: Classe Bean responsável por armazenar os metodos amarrados a tela
 * do caso de uso de Template mensageria
 * </p>
 * <br>
 * <b>Empresa:</b> Cef - Caixa Econômica Federal
 *
 * @author Waltenes Junior
 * @version 1.0
 */
@SessionScoped
@ManagedBean
public class TemplateMensageriaMB extends ManutencaoBean<TemplateMensageria> {

    /** Atributo ESPAÇO. */
    private static final String ESPACO = " ";

    /** Atributo SISTEMA. */
    private static final String SISTEMA = "siacg";

    /** Atributo serialVersionUID. */
    private static final long serialVersionUID = 231767297452250354L;

    /** Atributo DIRETORIO_PAGINAS. */
    private static final String DIRETORIO_PAGINAS = "/pages/";

    /** Atributo PREFIXO_CASO_USO. */
    private static final String PREFIXO_CASO_USO = "templateMensageria";

    /** Atributo VAR_RESOURCE_BUNDLE. */
    private static final String VAR_RESOURCE_BUNDLE = "msgApp";

    /** Atributo MENSAGEM_EXISTE_TEMPLATE_ATIVO_NIVEL. */
    private static final String MENSAGEM_EXISTE_TEMPLATE_ATIVO_NIVEL = "MN022";

    /** Atributo MENSAGEM_SUCESSO. */
    private static final String MENSAGEM_SUCESSO = "MA002";

    /** Atributo LOG_NAO_POSSIVEL_INCLUIR. */
    private static final String LOG_NAO_POSSIVEL_INCLUIR = "Não foi possivel incluir o template ";

    /** Atributo servico. */
    @EJB
    private transient TemplateMensageriaService servico;

    /** Atributo visao. */
    private transient TemplateMensageriaVisao visao;

    /**
     * <p>
     * Método responsável por acessar o serviço de template de mensageria.
     * <p>
     *
     * @author Caio Graco
     */
    public void acessarServicoTemplateMensageria() {
        final String urlWebService = this.servico.obterURLServicoManterTemplateMensageria(TemplateMensageriaMB.SISTEMA);
        this.getVisao().setUrlSemsgServicoMensageria(urlWebService);
    }

    /**
     * @see br.gov.caixa.pedesgo.arquitetura.controlador.ManutencaoBean#salvar(br.gov.caixa.pedesgo.arquitetura.entidade.Entidade)
     */
    @Override
    public String salvar(final TemplateMensageria entidade) {

        final TemplateMensageriaVisao visao = this.getVisao();

        if (this.servico.campoObrigatorioNaoInformado(entidade, visao.getListaAEnviar())) {
            super.adicionaListaMensagemDeAlerta(entidade.getMensagens());
            return super.MESMA_TELA;
        }

        if (UtilObjeto.isReferencia(this.servico.obterTemplatePorNivel(entidade.getIcNivelMensageria(), entidade.getNuTemplateMensageria()))) {
            super.adicionaMensagemDeAlerta(TemplateMensageriaMB.MENSAGEM_EXISTE_TEMPLATE_ATIVO_NIVEL);
            return super.MESMA_TELA;
        }

        entidade.setIcAtivo(Boolean.TRUE);

        try {
            this.servico.salvar(entidade);
            this.servico.salvarDestinatario(entidade.getNuTemplateMensageria(), visao.getListaAEnviar(), visao.getListaCopiaAEnviar());
            visao.setLista(super.listar());
            visao.setExibirModal(Boolean.TRUE);
            visao.setEntidade(new TemplateMensageria());
            
        } catch (final RuntimeException e) {
            LogCefUtil.error(TemplateMensageriaMB.LOG_NAO_POSSIVEL_INCLUIR + e.getCause());
            LogCefUtil.error(e);
        }


        return super.MESMA_TELA;
    }

    /**
     * <p>
     * Método responsável por ativar um template mensageria.
     * <p>
     *
     * @param entidade
     *            valor a ser atribuído
     * @return String
     * @author Waltenes Junior
     */
    public String ativarTemplate(final TemplateMensageria entidade) {

        final TemplateMensageria templateAtivo = this.servico.obterTemplatePorNivel(entidade.getIcNivelMensageriaEnum().getCodigo(),
                entidade.getNuTemplateMensageria());

        if (UtilObjeto.isReferencia(templateAtivo)) {
            templateAtivo.setIcAtivo(Boolean.FALSE);
            this.servico.salvar(templateAtivo);
        }

        entidade.setIcAtivo(Boolean.TRUE);
        this.servico.salvar(entidade);

        this.carregar();

        super.adicionaMensagemDeSucesso(TemplateMensageriaMB.MENSAGEM_SUCESSO);
        return super.MESMA_TELA;
    }

    /**
     * @see br.gov.caixa.pedesgo.arquitetura.controlador.ManutencaoBean#remover(br.gov.caixa.pedesgo.arquitetura.entidade.Entidade)
     */
    @Override
    public String remover(final TemplateMensageria entidade) {

        entidade.setIcAtivo(Boolean.FALSE);
        super.salvar(entidade);

        this.getVisao().setLista(super.listar());

        return super.MESMA_TELA;
    }

    /**
     * <p>
     * Método responsável por abrir a edição de um template.
     * <p>
     *
     * @param entidade
     *            valor a ser atribuído
     * @return String com a tela de edição
     * @author Waltenes Junior
     */
    public String abrirEdicao(final TemplateMensageria entidade) {

        final TemplateMensageriaVisao visao = this.getVisao();

        visao.setEntidade(entidade);

        this.servico.preencherListaDestinatario(entidade.getNuTemplateMensageria(), visao.getListaAEnviar(), visao.getListaCopiaAEnviar());

        return this.getTelaEdicao();
    }

    /**
     * <p>
     * Método responsável por abrir o detalhe de um template.
     * <p>
     *
     * @param entidade
     *            valor a ser atribuído
     * @return String com a tela de detalhe
     * @author Waltenes Junior
     */
    public String abrirTelaDetalhe(final TemplateMensageria entidade) {

        final Integer numeroUnidade = Integer.valueOf(super.getUnidadeUsuario());
        final TemplateMensageriaService servico = this.servico;

        entidade.setDeTextoMensageria(
                servico.substituirTagTexto(entidade.getDeTextoMensageria(), servico.listarContratosParametrizadosPorLote(3), numeroUnidade));

        entidade.setNoAssuntoMensageria(servico.substituirTagTexto(entidade.getNoAssuntoMensageria(), null, numeroUnidade));

        this.getVisao().setEntidade(entidade);

        return this.getTelaDetalhe();
    }

    /**
     * @see br.gov.caixa.pedesgo.arquitetura.controlador.AbstractBean#carregar()
     */
    @Override
    protected void carregar() {
        this.visao = null;
        final TemplateMensageriaVisao visao = this.getVisao();

        visao.setEntidade(new TemplateMensageria());

        visao.setLista(super.listar());
    }

    /**
     * <p>
     * Método responsável por inserir uma tag no assunto do template.
     * <p>
     *
     * @author Waltenes Junior / Leandro.oliveira
     */
    public void inserirTagAssunto() {

        final TemplateMensageriaVisao visao = this.getVisao();

        if (!UtilString.isVazio(visao.getEntidade().getNoAssuntoMensageria())) {

            visao.getEntidade().setNoAssuntoMensageria(
                    visao.getEntidade().getNoAssuntoMensageria().concat(TemplateMensageriaMB.ESPACO).concat(visao.getCampoSelecionavelSelecionado()));
        } else {

            visao.getEntidade().setNoAssuntoMensageria(TemplateMensageriaMB.ESPACO.concat(visao.getCampoSelecionavelSelecionado()));
        }
    }

    /**
     * <p>
     * Método responsável por inserir uma tag no texto do template.
     * <p>
     *
     * @author Waltenes Junior / Leandro.oliveira
     */
    public void inserirTagTexto() {

        final TemplateMensageriaVisao visao = this.getVisao();

        if (!UtilString.isVazio(visao.getEntidade().getDeTextoMensageria())) {

            visao.getEntidade().setDeTextoMensageria(
                    visao.getEntidade().getDeTextoMensageria().concat(TemplateMensageriaMB.ESPACO).concat(visao.getCampoSelecionavelSelecionado()));

        } else {

            visao.getEntidade().setDeTextoMensageria(TemplateMensageriaMB.ESPACO.concat(visao.getCampoSelecionavelSelecionado()));
        }
    }

    /**
     * <p>
     * Método responsável por.
     * <p>
     *
     * @author Leandro S. Oliveira
     */
    public void removerItemListaAEnviar() {

        for (final String string : this.getVisao().getListaCopiaAEnviar()) {

            if (this.getVisao().getListaAEnviar().contains(string)) {

                this.getVisao().getListaAEnviar().remove(string);
            }
        }
    }

    /**
     * <p>
     * Método responsável por.
     * <p>
     *
     * @author Leandro S. Oliveira
     */
    public void removerItemListaCopiaAEnviar() {

        for (final String string : this.getVisao().getListaAEnviar()) {

            if (this.getVisao().getListaCopiaAEnviar().contains(string)) {

                this.getVisao().getListaCopiaAEnviar().remove(string);
            }
        }
    }

    /**
     * <p>
     * Método responsável por listar os template mensageria de acordo com o
     * filtro.
     * <p>
     *
     * @param filtro
     *            valor a ser atribuído
     * @return String
     * @author Waltenes Junior
     */
    public String listarTemplateMensageriaPorFiltro(final TemplateMensageria filtro) {

        this.getVisao().setLista(this.servico.listarTemplaMensageriaPorFiltro(filtro));
        return super.MESMA_TELA;
    }

    /**
     * @see br.gov.caixa.pedesgo.arquitetura.controlador.AbstractBean#getTelaConsulta()
     */
    @Override
    public String getTelaConsulta() {
        return TemplateMensageriaMB.DIRETORIO_PAGINAS + this.getPrefixoCasoDeUso() + AbstractBean.SUFIXO_TELA_CONSULTA;
    }

    /**
     * @see br.gov.caixa.pedesgo.arquitetura.controlador.AbstractBean#getTelaEdicao()
     */
    @Override
    public String getTelaEdicao() {
        return TemplateMensageriaMB.DIRETORIO_PAGINAS + this.getPrefixoCasoDeUso() + AbstractBean.SUFIXO_TELA_EDICAO;
    }

    /**
     * @see br.gov.caixa.pedesgo.arquitetura.controlador.AbstractBean#getTelaDetalhe()
     */
    @Override
    public String getTelaDetalhe() {
        return TemplateMensageriaMB.DIRETORIO_PAGINAS + this.getPrefixoCasoDeUso() + AbstractBean.SUFIXO_TELA_DETALHE;
    }

    /**
     * @see br.gov.caixa.pedesgo.arquitetura.controlador.AbstractBean#getNomeVarResourceBundle()
     */
    @Override
    protected String getNomeVarResourceBundle() {
        return TemplateMensageriaMB.VAR_RESOURCE_BUNDLE;
    }

    /**
     * @see br.gov.caixa.pedesgo.arquitetura.controlador.AbstractBean#getPrefixoCasoDeUso()
     */
    @Override
    protected String getPrefixoCasoDeUso() {
        return TemplateMensageriaMB.PREFIXO_CASO_USO;
    }

    /**
     * @see br.gov.caixa.pedesgo.arquitetura.controlador.AbstractBean#getService()
     */
    @SuppressWarnings("unchecked")
    @Override
    public TemplateMensageriaService getService() {
        return this.servico;
    }

    /**
     * @see br.gov.caixa.pedesgo.arquitetura.controlador.AbstractBean#getVisao()
     */
    @Override
    public TemplateMensageriaVisao getVisao() {
        if (this.visao == null) {
            this.visao = new TemplateMensageriaVisao();
        }

        return this.visao;
    }
}
