package br.gov.caixa.siacg.view.form;

import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;

import br.gov.caixa.pedesgo.arquitetura.visao.ManutencaoVisao;
import br.gov.caixa.siacg.model.domain.Contrato;

/**
 * <p>
 * UnidadeVisao
 * </p>
 * <p>
 * Descrição: Classe UnidadeVisao
 * </p>
 * <br>
 * <b>Empresa:</b> Cef - Caixa Econômica Federal.
 *
 * @author GS Tecnologia
 * @version 1.0
 */
@ManagedBean(name = UnidadeVisao.NOME_MANAGED_BEAN)
@ViewScoped
public class UnidadeVisao extends ManutencaoVisao<Contrato> {

    /** Constante serialVersionUID. */
    private static final long serialVersionUID = 1L;

    /** Constante NOME_MANAGED_BEAN. */
    public static final String NOME_MANAGED_BEAN = "unidadeVisao";

    /** Constante EL_MANAGED_BEAN. */
    public static final String EL_MANAGED_BEAN = "#{unidadeVisao}";

}
