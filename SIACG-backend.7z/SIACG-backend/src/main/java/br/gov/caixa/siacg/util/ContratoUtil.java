package br.gov.caixa.siacg.util;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.regex.PatternSyntaxException;

import javax.faces.context.FacesContext;
import javax.servlet.http.HttpServletRequest;

import org.apache.commons.lang3.StringUtils;

import br.gov.caixa.pedesgo.arquitetura.util.UtilString;
import br.gov.caixa.pedesgo.arquitetura.util.UtilFormatacao;

/**
 * <p>
 * ContratoUtil
 * </p>
 * <p>
 * Descrição: Classe utilitária responsável por centralizar tratamentos das
 * informações do contrato.
 * </p>
 * <br>
 * <b>Empresa:</b> Cef - Caixa Econômica Federal
 *
 * @author guilherme.santos
 * @version 1.0
 */
public class ContratoUtil {

    /** Atributo HIFEM. */
    private static final char HIFEM = '-';
    /** Atributo UNDERLINE. */
    private static final char UNDERLINE = '_';
    /** Atributo CARACTER_DESCONSIDERAR_MINUSCULO. */
    private static final char CARACTER_DESCONSIDERAR_MINUSCULO = 'x';
    /** Atributo CARACTER_DESCONSIDERAR_MAIUSCULO. */
    private static final char CARACTER_DESCONSIDERAR_MAIUSCULO = 'X';
    /** Atributo PONTO. */
    private static final char PONTO = '.';
    /** Atributo PONTO_COM_ESCAPE. */
    private static final String PONTO_COM_ESCAPE = "\\.";

    /** Atributo MAPA_OPERACAO_SISTEMA. */
    private static final String MAPA_OPERACAO_SISTEMA = "mapaOperacaoSistema";

    private ContratoUtil() {
	throw new IllegalStateException("Classe de Utilidade");
    }    

    /**
     * 
     * <p>Método responsável por verificar se o numero do contrato informado bate com a mascara informada</p>.
     *
     * @author p575337
     *
     * @param numeroContrato numero do contrato sem mascara. apenas números.
     * @param mascara da tabela acg.acgtb038_operacao_sistema
     * @return true se for popssível formatar o numero na mascara informada.
     */
    public static boolean match(final String numeroContrato, final String mascara) {
	boolean match = false;
	
	if (!UtilString.isVazio(mascara) && !UtilString.isVazio(numeroContrato)  && UtilString.isNumerico(NumeroUtil.somenteNumeros(numeroContrato))) {
	    int qte = StringUtils.countMatches(mascara, String.valueOf(UNDERLINE));
	    qte += StringUtils.countMatches(mascara, String.valueOf(CARACTER_DESCONSIDERAR_MINUSCULO));
	    qte += StringUtils.countMatches(mascara, String.valueOf(CARACTER_DESCONSIDERAR_MAIUSCULO));
	    match = qte == NumeroUtil.somenteNumeros(numeroContrato).length();
	}
	return match;
    }


    /**
     * <p>
     * Método responsável por formatar o numero do contrato de acordo com a
     * máscara informada.
     * <p>
     *
     * @param numeroContrato
     *            valor a ser atribuido
     * @param mascara
     *            valor a ser atribuido
     * @return String
     * @author guilherme.santos
     */
    public static String formatarNumeroContrato(final String numeroContrato, final String mascara) {
	String numeroFormatado = "";

	try {
	    final char[] mascaraCharArray = mascara.toCharArray();
	    final char[] numeroContratoCharArray = numeroContrato.toCharArray();

	    for (int indiceMascara = 0, indiceNumero = 0; indiceMascara < mascaraCharArray.length; indiceMascara++) {

		switch (mascaraCharArray[indiceMascara]) {
		case ContratoUtil.UNDERLINE:
		    numeroFormatado = numeroFormatado.concat(String.valueOf(numeroContratoCharArray[indiceNumero]));
		    indiceNumero++;
		    break;
		case ContratoUtil.PONTO:
		    numeroFormatado = numeroFormatado.concat(String.valueOf(ContratoUtil.PONTO));
		    break;
		case ContratoUtil.HIFEM:
		    numeroFormatado = numeroFormatado.concat(String.valueOf(ContratoUtil.HIFEM));
		    break;
		case ContratoUtil.CARACTER_DESCONSIDERAR_MINUSCULO:
		    indiceNumero++;
		    break;
		case ContratoUtil.CARACTER_DESCONSIDERAR_MAIUSCULO:
		    indiceNumero++;
		    break;
		default:
		    break;
		}
	    }
	} catch (final ArrayIndexOutOfBoundsException e) {
	    LogCEF.error(e);
	    LogCEF.error("Erro ao formatar numero do contrato: " + numeroContrato + "/" + mascara);
	    numeroFormatado = numeroContrato;
	}

	return numeroFormatado;
    }

    /**
     * <p>
     * Método responsável por remover a máscara do numero do contrato informado.
     * <p>
     *
     * @param numeroContrato
     *            valor a ser atribuido
     * @return String
     * @author guilherme.santos
     */
    public static String removerMascaraNumeroContrato(final String numeroContrato) {
	String numeroSemMascara = "";

	try {
	    numeroSemMascara = numeroContrato.replaceAll(String.valueOf(ContratoUtil.HIFEM), "").replaceAll(ContratoUtil.PONTO_COM_ESCAPE, "");
	} catch (final PatternSyntaxException e) {
	    LogCEF.error(e);
	    LogCEF.error("Erro ao remover máscara do numero do contrato: " + numeroContrato);
	}

	return numeroSemMascara;
    }

    /**
     * <p>
     * Método responsável por contar a quantidade de divisões.
     * <p>
     *
     * @param mascara
     *            valor a ser atribuido
     * @return int
     * @author guilherme.santos
     */
    public static int calcularDivisoesMascara(final String mascara) {
	int divisoes = 1;

	final char[] mascaraCharArray = mascara.toCharArray();

	for (final char element : mascaraCharArray) {

	    switch (element) {
	    case ContratoUtil.PONTO:
		divisoes++;
		break;
	    case ContratoUtil.HIFEM:
		divisoes++;
		break;
	    default:
		break;
	    }
	}

	return divisoes;
    }

    /**
     * <p>
     * Método responsável por calcular a quantidade de caracteres da divisão
     * informada.
     * <p>
     *
     * @param mascara
     *            valor a ser atribuido
     * @param divisao
     *            valor a ser atribuido
     * @return int
     * @author guilherme.santos
     */
    public static int calcularCaracteresDaDivisao(final String mascara, final int divisao) {
	int caracteres = 0;
	int contadorDivisao = 1;

	try {
	    final char[] mascaraCharArray = mascara.toCharArray();

	    for (final char element : mascaraCharArray) {

		switch (element) {
		case ContratoUtil.UNDERLINE:
		    if (divisao == contadorDivisao) {
			caracteres++;
		    }
		    break;
		case ContratoUtil.PONTO:
		    contadorDivisao++;
		    break;
		case ContratoUtil.HIFEM:
		    contadorDivisao++;
		    break;
		default:
		    break;
		}
	    }
	} catch (final Exception e) {
	    LogCEF.debug(e);
	    caracteres = 0;
	}

	return caracteres;
    }

    /**
     * <p>
     * Método responsável por montar o numero do contrato completando com zero a
     * esquerda dos digitos não informados.
     * <p>
     *
     * @param mascara
     *            valor a ser atribuido
     * @param parte1
     *            valor a ser atribuido
     * @param parte2
     *            valor a ser atribuido
     * @param parte3
     *            valor a ser atribuido
     * @param parte4
     *            valor a ser atribuido
     * @return String
     * @author guilherme.santos
     */
    public static String montarNumeroContrato(final String mascara, final String parte1, final String parte2, final String parte3,
	    final String parte4) {
	String numeroContrato = "";
	numeroContrato = numeroContrato.concat(ContratoUtil.completarComZero(mascara, parte1, 1));
	numeroContrato = numeroContrato.concat(ContratoUtil.completarComZero(mascara, parte2, 2));
	numeroContrato = numeroContrato.concat(ContratoUtil.completarComZero(mascara, parte3, 3));
	numeroContrato = numeroContrato.concat(ContratoUtil.completarComZero(mascara, parte4, 4));

	return numeroContrato;
    }

    /**
     * <p>
     * Método responsável por completar com zero a esquerda do numero inforado.
     * <p>
     *
     * @param mascara
     *            valor a ser atribuido
     * @param numeroParcial
     *            valor a ser atribuido
     * @param divisao
     *            valor a ser atribuido
     * @return String
     * @author guilherme.santos
     */
    private static String completarComZero(final String mascara, final String numeroParcial, final int divisao) {
	String numero = "";
	final int caracteresDaDivisao = ContratoUtil.calcularCaracteresDaDivisao(mascara, divisao);

	if (caracteresDaDivisao > 0) {
	    if (caracteresDaDivisao == numeroParcial.length()) {
		numero = numeroParcial;
	    } else {
		numero = StringUtils.leftPad(numeroParcial, caracteresDaDivisao, "0");
	    }
	}

	return numero;
    }

    /**
     * <p>Método responsável por formatar o numero do contrato com a operacao que esta na session</p>.
     *
     * @author p541915
     *
     * @param nuOperacao
     * @param coIdentificador
     * @return
     */
    @SuppressWarnings({ "unchecked", "unlikely-arg-type" })
    public static String formatarContratoComMascaraSessao(Integer nuOperacao, String coIdentificador) {
	final HttpServletRequest request = (HttpServletRequest) FacesContext.getCurrentInstance().getExternalContext().getRequest();
	Map<Integer, String> mapaOperacaoSistema = (HashMap<Integer, String>) request.getSession().getAttribute(ContratoUtil.MAPA_OPERACAO_SISTEMA);
	if (mapaOperacaoSistema != null && nuOperacao != null) {
	    String mascara = mapaOperacaoSistema.get(UtilFormatacao.completarComZeroEsquerda(nuOperacao.toString(), 4));
	    if (mascara != null) {
		mascara = mascara.replace("x", "_");
		mascara = mascara.replace("X", "_");
		return FormatUtils.applyMask(mascara, coIdentificador);
	    }
	}
	return coIdentificador;
    }

    /**
     * <p>
     * Método responsável por retornar uma sub lista a partir da lista original
     * passada por parâmetro.
     * <p>
     *
     * @param listaOriginal
     *            valor a ser atribuido
     * @param primeiroIndice
     *            início da sub lista
     * @param tamanhoLote
     *            quantidade de registros que a sub lista retornará a partir do
     *            primeiro índice. Ex.: se o primeiro índice for 2500 o tamanho
     *            do lote 200 irá retornar os indices da lista da posição 2499
     *            até 2699. Totalizando os 200 registros que é o tamanho do
     *            lote.
     * @return List<T> Sub lista
     * @author Mábio Barbosa
     * @author diego.morais
     */
    public static <T> List<T> subLista(final List<T> listaOriginal, final int primeiroIndice, final int tamanhoLote) {
	if (listaOriginal.size() > primeiroIndice) {
	    return listaOriginal.subList(primeiroIndice, Math.min(listaOriginal.size(), primeiroIndice + tamanhoLote));
	}
	return new ArrayList<>();
    }
}
