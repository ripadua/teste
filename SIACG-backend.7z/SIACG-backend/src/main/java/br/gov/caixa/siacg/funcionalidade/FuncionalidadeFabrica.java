/*
 * Copyright (c) 2016 Caixa Econômica Federal. Todos os direitos
 * reservados.
 *
 * Caixa Econômica Federal - SIACG
 *
 * Este software foi desenvolvido sob demanda da CAIXA e está
 * protegido por leis de direitos autorais e tratados internacionais. As
 * condições de cópia e utilização do todo ou partes dependem de autorização da
 * pessoa. Cópias não são permitidas sem expressa autorização. Não pode ser
 * comercializado ou utilizado para propósitos particulares.
 *
 * Uso exclusivo da Caixa Econômica Federal. A reprodução ou distribuição não
 * autorizada deste programa ou de parte dele, resultará em punições civis e
 * criminais e os infratores incorrem em sanções previstas na legislação em
 * vigor.
 *
 * Histórico do Subversion:
 *
 * LastChangedRevision: $Revision$
 * LastChangedBy: $Author$
 * LastChangedDate: $Date$
 *
 * HeadURL: $HeadURL$
 *
 */
package br.gov.caixa.siacg.funcionalidade;

import javax.ejb.Singleton;
import javax.inject.Inject;

import br.gov.caixa.siacg.dao.OperacaoSistemaDAO;
import br.gov.caixa.siacg.model.enums.FuncionalidadeEnum;
import br.gov.caixa.siacg.service.ContratoService;
import br.gov.caixa.siacg.service.DestinatarioService;

/**
 * <p>
 * FuncaoFabrica.
 * </p>
 * <p>
 * Descrição: Fabrica que fornece objetos de funcao
 * </p>
 * <br>
 * <b>Empresa:</b> Cef - Caixa Econômica Federal
 *
 * @author Bruno Martins de Carvalho
 * @version 1.0
 */
@Singleton
public class FuncionalidadeFabrica {

    /** Atributo contratoService. */
    @Inject
    private ContratoService contratoService;

    /** Atributo destinatarioService. */
    @Inject
    private DestinatarioService destinatarioService;

    /** Atributo operacaoSistemaDAO. */
    @Inject
    private OperacaoSistemaDAO operacaoSistemaDAO;

    /**
     * Obtem a classe da funcionalidade.
     *
     * @param funcionalidadeEnum
     *            valor a ser atribuido
     * @return IFuncao
     * @author Bruno Martins de Carvalho
     */
    public IFuncionalidade getFuncionalidade(final FuncionalidadeEnum funcionalidadeEnum) {
        IFuncionalidade funcionalidade = null;

        switch (funcionalidadeEnum) {

        case NOVOS_CONTRATOS:
            funcionalidade = new NovosContratosFuncionalidade(this.contratoService, this.destinatarioService, this.operacaoSistemaDAO);
            break;

        case GARANTIAS_NAO_PARAMETRIZADAS:
            funcionalidade = new GarantiasNaoParametrizadasFuncionalidade(this.contratoService, this.destinatarioService, this.operacaoSistemaDAO);
            break;

        case GARANTIAS_INSUFICIENTES:
            funcionalidade = new GarantiasInsuficientesFuncionalidade(this.contratoService, this.destinatarioService, this.operacaoSistemaDAO);
            break;

        default:
            break;
        }

        return funcionalidade;
    }

}
