/**
 * Copyright (c) 2020 Caixa Econômica Federal. Todos os direitos
 * reservados.
 *
 * Caixa Econômica Federal - SIACG
 *
 * Este software foi desenvolvido sob demanda da CAIXA e está
 * protegido por leis de direitos autorais e tratados internacionais. As
 * condições de cópia e utilização total ou partes dependem de autorização da
 * empresa. Cópias não são permitidas sem expressa autorização. Não pode ser
 * comercializado ou utilizado para propósitos particulares.
 *
 * Uso exclusivo da Caixa Econômica Federal. A reprodução ou distribuição não
 * autorizada deste programa ou de parte dele, resultará em punições civis e
 * criminais e os infratores incorrem em sanções previstas na legislação em
 * vigor.
 *
 * Histórico do TFS:
 *
 * LastChangedRevision: $Revision$
 * LastChangedBy: $Author$
 * LastChangedDate: $Date$
 *
 * HeadURL: $HeadURL$
 *
 */	
package br.gov.caixa.siacg.comum.to;

import java.io.Serializable;
import java.math.BigDecimal;

import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * <p>GarantiaCartaoCreditoCalculoTO</p>
 *
 * <p>Descrição: Descrição do tipo</p>
 *
 * <br><b>Empresa:</b> Cef - Caixa Econômica Federal
 *
 *
 * @author f541915
 *
 * @version 1.0
*/
public class GarantiaCartaoCreditoCalculoTO implements Serializable {

    /** Atributo serialVersionUID. */
    private static final long serialVersionUID = 1L;

    /** Atributo nuGarantiaCartaoCredito. */
    @JsonProperty("nu_garantia_cartao_credito")
    private Integer nuGarantiaCartaoCredito;
    
    /** Atributo icOrigemPreAnalise. */
    @JsonProperty("ic_origem_pre_analise")
    private boolean icOrigemPreAnalise;
    
    /** Atributo pcConcentracao. */
    @JsonProperty("pc_concentracao")
    private BigDecimal pcConcentracao;
    
    /** Atributo nuBandeiraCartao. */
    @JsonProperty("nu_bandeira_cartao")
    private Integer nuBandeiraCartao;
    
    /** Atributo vrConsumido. */
    @JsonProperty("vr_consumido")
    private BigDecimal vrConsumido;
    
    /** Atributo contaCorrente. */
    @JsonProperty("conta_corrente")
    private ContaCorrenteCalculoTO contaCorrente;

    /**
     * <p>Retorna o valor do atributo nuGarantiaCartaoCredito</p>.
     *
     * @return nuGarantiaCartaoCredito
    */
    public Integer getNuGarantiaCartaoCredito() {
        return this.nuGarantiaCartaoCredito;
    }

    /**
     * <p>Define o valor do atributo nuGarantiaCartaoCredito</p>.
     *
     * @param nuGarantiaCartaoCredito valor a ser atribuído
    */
    public void setNuGarantiaCartaoCredito(Integer nuGarantiaCartaoCredito) {
        this.nuGarantiaCartaoCredito = nuGarantiaCartaoCredito;
    }

    /**
     * <p>Retorna o valor do atributo pcConcentracao</p>.
     *
     * @return pcConcentracao
    */
    public BigDecimal getPcConcentracao() {
        return this.pcConcentracao;
    }

    /**
     * <p>Define o valor do atributo pcConcentracao</p>.
     *
     * @param pcConcentracao valor a ser atribuído
    */
    public void setPcConcentracao(BigDecimal pcConcentracao) {
        this.pcConcentracao = pcConcentracao;
    }

    /**
     * <p>Retorna o valor do atributo contaCorrente</p>.
     *
     * @return contaCorrente
    */
    public ContaCorrenteCalculoTO getContaCorrente() {
	return this.contaCorrente;
    }

    /**
     * <p>Define o valor do atributo contaCorrente</p>.
     *
     * @param contaCorrente valor a ser atribuído
    */
    public void setContaCorrente(ContaCorrenteCalculoTO contaCorrente) {
	this.contaCorrente = contaCorrente;
    }

    /**
     * <p>Retorna o valor do atributo icOrigemPreAnalise</p>.
     *
     * @return icOrigemPreAnalise
    */
    public boolean isIcOrigemPreAnalise() {
	return this.icOrigemPreAnalise;
    }

    /**
     * <p>Define o valor do atributo icOrigemPreAnalise</p>.
     *
     * @param icOrigemPreAnalise valor a ser atribuído
    */
    public void setIcOrigemPreAnalise(boolean icOrigemPreAnalise) {
	this.icOrigemPreAnalise = icOrigemPreAnalise;
    }

    /**
     * <p>Retorna o valor do atributo nuBandeiraCartao</p>.
     *
     * @return nuBandeiraCartao
    */
    public Integer getNuBandeiraCartao() {
	return this.nuBandeiraCartao;
    }

    /**
     * <p>Define o valor do atributo nuBandeiraCartao</p>.
     *
     * @param nuBandeiraCartao valor a ser atribuído
    */
    public void setNuBandeiraCartao(Integer nuBandeiraCartao) {
	this.nuBandeiraCartao = nuBandeiraCartao;
    }

    /**
     * <p>Retorna o valor do atributo vrConsumido</p>.
     *
     * @return vrConsumido
    */
    public BigDecimal getVrConsumido() {
	return this.vrConsumido;
    }

    /**
     * <p>Define o valor do atributo vrConsumido</p>.
     *
     * @param vrConsumido valor a ser atribuído
    */
    public void setVrConsumido(BigDecimal vrConsumido) {
	this.vrConsumido = vrConsumido;
    }
    
    
}
