/*
 * Copyright (c) 2019 Caixa Econômica Federal. Todos os direitos
 * reservados.
 *
 * Caixa Econômica Federal - SIACG - Sistema de Crédito Rural
 *
 * Este software foi desenvolvido sob demanda da CAIXA e está
 * protegido por leis de direitos autorais e tratados internacionais. As
 * condições de cópia e utilização do todo ou partes dependem de autorização da
 * empresa. Cópias não são permitidas sem expressa autorização. Não pode ser
 * comercializado ou utilizado para propósitos particulares.
 *
 * Uso exclusivo da Caixa Econômica Federal. A reprodução ou distribuição não
 * autorizada deste programa ou de parte dele, resultará em punições civis e
 * criminais e os infratores incorrem em sanções previstas na legislação em
 * vigor.
 *
 * Histórico do TFS:
 *
 * LastChangedRevision: $Revision$
 * LastChangedBy: $Author$
 * LastChangedDate: $Date$
 *
 * HeadURL: $HeadURL$
 *
 */	
package br.gov.caixa.siacg.view.mb;

import java.util.ArrayList;

import javax.ejb.EJB;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ManagedProperty;
import javax.faces.bean.SessionScoped;
import javax.inject.Inject;

import org.primefaces.context.RequestContext;

import br.gov.caixa.pedesgo.arquitetura.controlador.ManutencaoBean;
import br.gov.caixa.pedesgo.arquitetura.enumerador.EnumAcao;
import br.gov.caixa.pedesgo.arquitetura.siico.util.LogCefUtil;
import br.gov.caixa.pedesgo.arquitetura.to.MensagemTO;
import br.gov.caixa.pedesgo.arquitetura.util.MensagensUtil;
import br.gov.caixa.pedesgo.arquitetura.util.UsuarioUtil;
import br.gov.caixa.pedesgo.arquitetura.util.UtilObjeto;
import br.gov.caixa.siacg.model.domain.Fornecedor;
import br.gov.caixa.siacg.model.domain.TipoFornecedor;
import br.gov.caixa.siacg.model.enums.NoFuncionalidadeEnum;
import br.gov.caixa.siacg.pagination.FornecedorLazyModel;
import br.gov.caixa.siacg.service.FornecedorService;
import br.gov.caixa.siacg.service.InstituicaoBancariaService;
import br.gov.caixa.siacg.service.TipoFornecedorService;
import br.gov.caixa.siacg.view.form.FornecedorVisao;

/**
 * <p>FornecedorMB</p>
 *
 * <p>Descrição: Descrição do tipo</p>
 *
 * <br><b>Empresa:</b> Cef - Caixa Econômica Federal
 *
 *
 * @author Winston
 *
 * @version 1.0
*/
@ManagedBean
@SessionScoped
public class FornecedorMB  extends ManutencaoBean<Fornecedor>{

    /** Atributo serialVersionUID. */
    private static final long serialVersionUID = 1L;

    
    /** Atributo PREFIXO_CASO_USO. */
    private static final String PREFIXO_CASO_USO = "tipoFornecedor";

    /** Atributo NOME_MANAGED_BEAN. */
    public static final String NOME_MANAGED_BEAN = "tipoFornecedorMB";

    /** Atributo EL_MANAGED_BEAN. */
    public static final String EL_MANAGED_BEAN = "#{tipoFornecedorMB}";
    
    /** Atributo PAGINA_CONSULTA_CONTRATO. */
    private static final String PAGINA_CONSULTA_FORNECEDOR = "/pages/execucao/fornecedor/consulta.xhtml?faces-redirect=true";

    /** Atributo PAGINA_INCLUSAO_CONTRATO. */
    private static final String PAGINA_INCLUSAO_FORNECEDOR = "/pages/execucao/fornecedor/edicao.xhtml?faces-redirect=true";
    
    private static final String MSG_APP = "msgApp";

    /** Atributo de Visao */
    private FornecedorVisao visao;
    
    /** Atributo Servido Fornecedor */
    @EJB
    private transient FornecedorService servico;
    
    
    /** Atributo de Consulta */
    @ManagedProperty(value = FornecedorLazyModel.EL_MANAGED_BEAN)
    private FornecedorLazyModel consulta;
    
    /** Atributo TipoFornecedor Service */
    @Inject
    private transient TipoFornecedorService tipoFornecedorService;
    
    /** Atributo Instituicao Bancaria */
    @Inject
    private transient InstituicaoBancariaService bancoServico;
    
    @Override
    public void carregar() {
		this.visao = getVisao();
		this.visao.getListaInstituicaoBancaria().clear();
		this.visao.getTipoFornecedor();
		this.visao.getTipoFornecedorParaInativar();
		this.carregarCombosDeInclusao();
		this.getConsulta().getFiltro().setIcSituacao(Boolean.TRUE);
		this.visao.setMostraDadosFornecedor(true);
    }
    
    public String inativarTipoFornecedor() {
    	final TipoFornecedor tipoFornecedor = this.getVisao().getTipoFornecedorParaInativar();

    	if (this.tipoFornecedorService.usadoEmFornecedor(tipoFornecedor)) {
    	    super.adicionaMensagemDeErro("Tipo Fornecedor está sendo usado");
    	} else {
    	    tipoFornecedor.setIcSituacao(false);
    	    this.tipoFornecedorService.salvar(tipoFornecedor);
    	    this.carregar();
    	    super.adicionaMensagemDeSucesso("Inativado com Sucesso");
    	}
    	
    	return super.MESMA_TELA;
    }
    
    public void excluirTipoFornecedor() {
    	TipoFornecedor tipoFornecedor = this.getVisao().getTipoFornecedorParaInativar();
    	if (tipoFornecedor != null) {
    		try {
				this.tipoFornecedorService.remover(tipoFornecedor);
				this.visao.setListaTipoFornecedor(new ArrayList<>(this.tipoFornecedorService.listar()));
				super.adicionaMensagemDeSucesso("Excluído com Sucesso");
			} catch (Exception e) {
				this.getVisao().setTipoFornecedorParaInativar(null);
				MensagensUtil.adicionaMensagemDeAlerta(FornecedorMB.MSG_APP, "Existem despesas lançadas para o tipo despesa selecionado", "");
				LogCefUtil.error("Erro ao excluir tipo fornecedor. Existem despesas lançadas para o tipo despesa selecionado.");
				LogCefUtil.error(e);
			}
    	}
    }
    
    public void adicionarTipoFornecedor() {
		this.visao = this.getVisao();
		TipoFornecedor tipoFornecedor = prepararTipoFornecedor( this.visao.getTipoFornecedor());
		this.tipoFornecedorService.validarDados(tipoFornecedor);
	
		if (tipoFornecedor.hasMensagens()) {	
		    for (final MensagemTO mensagem : tipoFornecedor.getMensagens()) {
		    	MensagensUtil.adicionaMensagemDeAlerta(FornecedorMB.MSG_APP, mensagem.getChaveMensagem(), mensagem.getArgumentos());
		    }
		} else {
			
		    this.tipoFornecedorService.salvar(tipoFornecedor);
		    this.visao.setTipoFornecedor(new TipoFornecedor());
		    this.carregarCombosDeInclusao();
		    RequestContext.getCurrentInstance().execute("PF('modalSucesso2').show();");
		}
    }

	private TipoFornecedor prepararTipoFornecedor(TipoFornecedor tipoFornecedor) {
		tipoFornecedor.setNoTipoFornecedor(tipoFornecedor.getNoTipoFornecedor().toUpperCase());
		tipoFornecedor.setIcSituacao(true);
		return tipoFornecedor;
	}

	public void validarTipoFornecedor() {
    	if (this.getVisao().getFornecedor().getTipoFornecedor() != null) {
    		Integer id = this.getVisao().getFornecedor().getTipoFornecedor().getNuTipoFornecedor();
    		TipoFornecedor tipoFornecedor = this.tipoFornecedorService.obter(id);
    		if (tipoFornecedor != null) {
    			String noTipoFornecedor = tipoFornecedor.getNoTipoFornecedor().trim();
    			boolean validacao = "CARTORIO".equals(noTipoFornecedor) || "CARTÓRIO".equals(noTipoFornecedor);
    			this.visao.setMostraDadosFornecedor(!validacao);
				if (validacao) {
    				String mensagem = " Para cadastrar Cartórios utilize a opção Gestão de Serventias em Manutenção. ";
    				MensagensUtil.adicionaMensagemDeAlerta(FornecedorMB.MSG_APP,  mensagem, "");
    			}
    		}
    	}
    }
   
    private void carregarCombosDeInclusao() {
		this.visao.setListaTipoFornecedor(this.tipoFornecedorService.listar(true));
		this.visao.setListaInstituicaoBancaria(this.bancoServico.listarTodos());
    }
	
    public void limpar() {
		this.visao.getFornecedor().setTipoFornecedor(null);
		this.visao.getFornecedor().setInstiuicaoBancaria(null);
		this.visao.setFornecedor(null);
		this.visao = getVisao();
    }

    @Override
    protected String getPrefixoCasoDeUso() {
    	return FornecedorMB.PREFIXO_CASO_USO;
    }

    @SuppressWarnings("unchecked")
    @Override
    public FornecedorService getService() {
    	return this.servico;
    }

    @Override
    public FornecedorVisao getVisao() {
		if(visao == null ) {
		    this.visao = new FornecedorVisao();
		}
		return visao;
    }

    public String abrirConsulta() {
		this.carregar();
		this.getConsulta().limparFiltro();
		this.restricaoAbrangencia();
		this.limpar();
		return FornecedorMB.PAGINA_CONSULTA_FORNECEDOR;
    } 
    
    public String abrirInclusao() {
        this.getVisao().setEntidade(new Fornecedor());
        this.carregar();
        return FornecedorMB.PAGINA_INCLUSAO_FORNECEDOR;
    }    
  
    public void salvarFornecedor() {
		final Fornecedor fornecedor = this.getVisao().getFornecedor();
		fornecedor.setDeTelefone(String.valueOf(this.getVisao().getFornecedor().getDeTelefone()));
		fornecedor.setIcSituacao(Boolean.TRUE);
		
		Integer id = this.getVisao().getFornecedor().getTipoFornecedor().getNuTipoFornecedor();
		TipoFornecedor tipoFornecedor = this.tipoFornecedorService.obter(id);
		fornecedor.setTipoFornecedor(tipoFornecedor);
		
		this.servico.validarDados(fornecedor);
		
		if (fornecedor.hasMensagens()){
		    for (final MensagemTO mensagem : this.visao.getFornecedor().getMensagens()){
		    	MensagensUtil.adicionaMensagemDeAlerta(FornecedorMB.MSG_APP, mensagem.getChaveMensagem(), mensagem.getArgumentos());
		    }
		} else {
		    this.servico.salvar(fornecedor);
		    RequestContext.getCurrentInstance().execute("PF('modalSucesso').show();");
		}
    }
    
    public String abrirAlteracao(final Fornecedor fornecedor) {	
		final Fornecedor fornecedorHelp = this.servico.obter(fornecedor.getNuFornecedor());
		this.getVisao().setFornecedor(fornecedorHelp);	
		return FornecedorMB.PAGINA_INCLUSAO_FORNECEDOR;
    }
    
    public String ativar() {
        final Fornecedor fornecedor = this.getVisao().getFornecedorParaInativar();
        fornecedor.setIcSituacao(Boolean.TRUE);
        this.servico.salvar(fornecedor);

        this.getConsulta();

        return super.MESMA_TELA;
    }
    
    public String excluir() {
    	final Fornecedor fornecedor= this.servico.obter(this.getVisao().getFornecedorParaInativar().getNuFornecedor());
        fornecedor.setIcSituacao(Boolean.FALSE);
        this.servico.salvar(fornecedor);
        this.getConsulta();
        RequestContext.getCurrentInstance().execute("PF('modalSucesso').show();");
        return super.MESMA_TELA;
    }
    
    public void filtrar() {
    	this.getConsulta();
    }
    
   
    private void restricaoAbrangencia() {
		if (UsuarioUtil.contemPermissao(NoFuncionalidadeEnum.PARAMETRIZA_CONTRATO.getNoFuncionalidade(), EnumAcao.INCLUIR.getNoAcao(), null, null)
			|| UsuarioUtil.contemPermissao(NoFuncionalidadeEnum.PARAMETRIZA_CONTRATO.getNoFuncionalidade(), EnumAcao.ALTERAR.getNoAcao(), null,
				null)) {
	
		    this.getVisao().setRestricaoAbangencia(true);
		}
    }
  
    public FornecedorLazyModel getConsulta() {
		if(!UtilObjeto.isReferencia(this.consulta)) {
		    this.consulta = new FornecedorLazyModel();
		}
		return this.consulta;
    }

    public void setConsulta(FornecedorLazyModel consulta) {
    	this.consulta = consulta;
    }
    
}
