package br.gov.caixa.siacg.view.mb;

import java.util.ArrayList;

import javax.annotation.PostConstruct;
import javax.ejb.EJB;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;

import br.gov.caixa.pedesgo.arquitetura.controlador.ManutencaoBean;
import br.gov.caixa.siacg.comum.to.sifec.RelatorioDestinatarioTO;
import br.gov.caixa.siacg.model.domain.Destinatario;
import br.gov.caixa.siacg.model.domain.RelatorioDestinatario;
import br.gov.caixa.siacg.model.enums.RelatorioDestinatarioEnum;
import br.gov.caixa.siacg.service.DestinatarioService;
import br.gov.caixa.siacg.service.RelatorioDestinatarioService;
import br.gov.caixa.siacg.view.form.DestinatarioVisao;

/**
 * <p>
 * DestinatatioMB
 * </p>
 * <p>
 * Descrição: Classe DestinatatioMB
 * </p>
 * <br>
 * <b>Empresa:</b> Cef - Caixa Econômica Federal.
 *
 * @author GS Tecnologia
 * @version 1.0
 */
@ViewScoped
@ManagedBean
public class DestinatatioMB extends ManutencaoBean<Destinatario> {

	/** Constante serialVersionUID. */
	private static final long serialVersionUID = -9111456499601861478L;

	/** Constante NOME_VAR_RESOURCE_BUNDLE. */
	private static final String NOME_VAR_RESOURCE_BUNDLE = "msgApp";

	/** Atributo visao. */
	private DestinatarioVisao visao;

	/** Atributo service. */
	@EJB
	private transient DestinatarioService service;

	/** Atributo service. */
	@EJB
	private transient RelatorioDestinatarioService relatorioService;

	/**
	 * Método Dest.
	 */
	@PostConstruct
	public void dest() {
		this.visao = new DestinatarioVisao();
		this.getVisao().setDestinatarioList(new ArrayList<Destinatario>(this.service.listar()));
	}

	/**
	 * Método Salvar.
	 *
	 * @return string
	 */
	public String salvar() {
		final Destinatario dest = this.getVisao().getDestinatario();
		if (dadosValidos(dest)) {
			this.salvar(dest);
			this.verificaIncluiDestinatarioNaLista(dest);
			this.novoDestinatario();
		} else {
			super.adicionaMensagemDeErro("MA005");
		}
		this.getVisao().setDestinatarioList(new ArrayList<Destinatario>(this.service.listar()));
		return null;
	}
	
	
	public void salvarDestinatario() {
		relatorioService.removerTodos(getVisao().getDestinatario().getListaRelatorioDestinatario());
		getVisao().getDestinatario().setListaRelatorioDestinatario(new ArrayList<RelatorioDestinatario>());
		
		for(RelatorioDestinatarioTO relatorio : getVisao().getRelatorioDestinatarioLists()) {
    		if(relatorio.isIcMarcado()) {
    			getVisao().getDestinatario().getListaRelatorioDestinatario().add(
    					new RelatorioDestinatario(getVisao().getDestinatario(),relatorio.getRelatorioDestinatarioEnum()));
    		}
    	}
		
		salvar();
	}

	public void abrirModalDestinatario(Destinatario dest) {
		getVisao().setDestinatario(dest);
		getVisao().setRelatorioDestinatarioLists(new ArrayList<RelatorioDestinatarioTO>());
			
		for(RelatorioDestinatarioEnum r : getVisao().getRelatorioDestinatario()) {
    		getVisao().getRelatorioDestinatarioLists().add(new RelatorioDestinatarioTO(r));
    	}
    	for(RelatorioDestinatarioTO relatorio :getVisao().getRelatorioDestinatarioLists()) {
    		for(RelatorioDestinatario r : dest.getListaRelatorioDestinatario()) {
    			if(r.getIcRelatorio().equals(relatorio.getRelatorioDestinatarioEnum())) {
    				relatorio.setIcMarcado(true);
    			}
    		}
    	}
    }

	private boolean dadosValidos(Destinatario dest) {
		if (dest == null) {
			return Boolean.FALSE;
		}
		if (dest.getEmail() == null || dest.getEmail().isEmpty()) {
			return Boolean.FALSE;
		}
		if (dest.getIc() == null || dest.getIc().isEmpty()) {
			return Boolean.FALSE;
		}

		return Boolean.TRUE;
	}

	/**
	 * <p>
	 * Método responsável por.
	 * <p>
	 *
	 * @param dest
	 *            valor a ser atribuído
	 * @author guilherme.santos
	 */
	private void verificaIncluiDestinatarioNaLista(final Destinatario dest) {
		if (this.getVisao().getDestinatarioList().contains(dest)) {
			this.getVisao().getDestinatarioList().add(this.getVisao().getDestinatarioList().indexOf(dest), dest);
		} else {
			this.getVisao().getDestinatarioList().add(dest);
		}
	}

	/**
	 * Método Destinatario para remover.
	 *
	 * @param destinatario
	 *            the destinatario
	 * @return string
	 */
	public String destinatarioParaRemover(final Destinatario destinatario) {
		this.visao.setDestinatario(destinatario);
		return null;
	}

	/**
	 * Método Remover.
	 *
	 * @return string
	 */
	public String remover() {
		final Destinatario destinatario = this.visao.getDestinatario();
		this.service.remover(destinatario);
		this.getVisao().getDestinatarioList().remove(destinatario);
		return null;
	}

	/**
	 * Método Editar.
	 *
	 * @param destinatario
	 *            the destinatario
	 * @return string
	 */
	public String editar(final Destinatario destinatario) {
		this.getVisao().setDestinatario(destinatario);
		return null;
	}

	/**
	 * Método Limpar.
	 *
	 * @return string
	 */
	public String limpar() {
		this.getVisao().setDestinatario(new Destinatario());
		return null;
	}

	/**
	 * @see br.gov.caixa.pedesgo.arquitetura.controlador.AbstractBean#getVisao()
	 */
	@Override
	public DestinatarioVisao getVisao() {
		return this.visao;
	}

	/**
	 * Método Abrir destinatario.
	 *
	 * @return string
	 */
	public String abrirDestinatario() {
		return DestinatarioVisao.PAGINA_DESTINATARIO;
	}

	/**
	 * Método Novo destinatario.
	 *
	 * @return string
	 */
	public String novoDestinatario() {
		return this.limpar();
	}

	/**
	 * @see br.gov.caixa.pedesgo.arquitetura.controlador.AbstractBean#getNomeVarResourceBundle()
	 */
	@Override
	protected String getNomeVarResourceBundle() {
		return DestinatatioMB.NOME_VAR_RESOURCE_BUNDLE;
	}

	/**
	 * @see br.gov.caixa.pedesgo.arquitetura.controlador.AbstractBean#getPrefixoCasoDeUso()
	 */
	@Override
	protected String getPrefixoCasoDeUso() {
		return null;
	}

	/**
	 * @see br.gov.caixa.pedesgo.arquitetura.controlador.AbstractBean#getService()
	 */
	@SuppressWarnings("unchecked")
	@Override
	public DestinatarioService getService() {
		return this.service;
	}
}