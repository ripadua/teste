
package br.gov.caixa.siacg.view.form;

/**
 * <p>
 * TrilhaHistoricoCampoAlteradoVisao.
 * </p>
 * <p>
 * Descrição: TrilhaHistoricoCampoAlteradoVisao
 * </p>
 * <br>
 * <b>Empresa:</b> Cef - Caixa Econômica Federal
 *
 * @version 1.0
 */
public class TrilhaHistoricoCampoAlteradoVisao {

    /** Atributo nomeCampo. */
    private String nomeCampo;

    /** Atributo valorAntesAlteracao. */
    private String valorAntesAlteracao;

    /** Atributo valorDepoisAlteracao. */
    private String valorDepoisAlteracao;

    /**
     * Retorna o valor do atributo nomeCampo.
     *
     * @return nomeCampo
     */
    public String getNomeCampo() {
        return this.nomeCampo;
    }

    /**
     * Define o valor do atributo nomeCampo.
     *
     * @param nomeCampo
     *            valor a ser atribuído
     */
    public void setNomeCampo(final String nomeCampo) {
        this.nomeCampo = nomeCampo;
    }

    /**
     * Retorna o valor do atributo valorAntesAlteracao.
     *
     * @return valorAntesAlteracao
     */
    public String getValorAntesAlteracao() {
        return this.valorAntesAlteracao;
    }

    /**
     * Define o valor do atributo valorAntesAlteracao.
     *
     * @param valorAntesAlteracao
     *            valor a ser atribuído
     */
    public void setValorAntesAlteracao(final String valorAntesAlteracao) {
        this.valorAntesAlteracao = valorAntesAlteracao;
    }

    /**
     * Retorna o valor do atributo valorDepoisAlteracao.
     *
     * @return valorDepoisAlteracao
     */
    public String getValorDepoisAlteracao() {
        return this.valorDepoisAlteracao;
    }

    /**
     * Define o valor do atributo valorDepoisAlteracao.
     *
     * @param valorDepoisAlteracao
     *            valor a ser atribuído
     */
    public void setValorDepoisAlteracao(final String valorDepoisAlteracao) {
        this.valorDepoisAlteracao = valorDepoisAlteracao;
    }
}
