/**
 * reservados. Copyright (c) 2009-2011 Caixa Econômica Federal. Todos os direitos
 *
 * Caixa Econômica Federal - SIACG – Sistema de Acompanhamento de Carteiras de Cobrança
 *
 * Este programa de computador foi desenvolvido sob demanda da CAIXA e está protegido por leis de direitos autorais e
 * tratados internacionais. As condições de cópia e utilização do todo ou partes dependem de autorização da pessoa.
 * Cópias não são permitidas sem expressa autorização. Não pode ser comercializado ou utilizado para propósitos
 * particulares.
 *
 * Uso exclusivo da Caixa Econômica Federal. A reprodução ou distribuição não autorizada deste programa ou de parte
 * dele, resultará em punições civis e criminais e os infratores incorrem em sanções previstas na legislação em vigor.
 *
 * Histórico do Subversion:
 *
 * LastChangedRevision: LastChangedBy: LastChangedDate:
 *
 * HeadURL:
 *
 */
package br.gov.caixa.siacg.view.mb;

import java.awt.image.RenderedImage;
import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.text.NumberFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Objects;
import java.util.TreeMap;
import java.util.logging.Logger;

import javax.ejb.EJB;
import javax.enterprise.context.SessionScoped;
import javax.faces.context.FacesContext;
import javax.imageio.ImageIO;
import javax.inject.Inject;
import javax.inject.Named;
import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpSession;

import org.apache.commons.codec.binary.Base64;
import org.apache.commons.collections.CollectionUtils;
import org.primefaces.model.DefaultStreamedContent;
import org.primefaces.model.StreamedContent;
import org.primefaces.model.chart.CartesianChartModel;
import org.primefaces.model.chart.ChartSeries;

import br.com.christ.html2pdf.exception.ConversionException;
import br.com.christ.jsf.html2pdf.listener.PDFConverterConfig;
import br.gov.caixa.pedesgo.arquitetura.controlador.ManutencaoBean;
import br.gov.caixa.pedesgo.arquitetura.enumerador.EnumAcao;
import br.gov.caixa.pedesgo.arquitetura.enums.EnumExtensaoArquivo;
import br.gov.caixa.pedesgo.arquitetura.relatorio.UtilRelatorio;
import br.gov.caixa.pedesgo.arquitetura.util.LogCefUtil;
import br.gov.caixa.pedesgo.arquitetura.util.MensagensUtil;
import br.gov.caixa.pedesgo.arquitetura.util.UsuarioUtil;
import br.gov.caixa.pedesgo.arquitetura.util.UtilObjeto;
import br.gov.caixa.pedesgo.arquitetura.util.UtilString;
import br.gov.caixa.siacg.comparator.DataImagemComparator;
import br.gov.caixa.siacg.comparator.DescricaoGrupoGarantiaComparator;
import br.gov.caixa.siacg.comparator.TotalDuplicatasMaioresSacadosComparator;
import br.gov.caixa.siacg.interceptador.Auditoria;
import br.gov.caixa.siacg.interceptador.OperacaoAuditoria;
import br.gov.caixa.siacg.model.domain.AnaliseCartaoBandeira;
import br.gov.caixa.siacg.model.domain.AnaliseCartaoCredito;
import br.gov.caixa.siacg.model.domain.AnaliseContrato;
import br.gov.caixa.siacg.model.domain.AnaliseParecer;
import br.gov.caixa.siacg.model.domain.BandeiraCartao;
import br.gov.caixa.siacg.model.domain.Cedente;
import br.gov.caixa.siacg.model.domain.ContaCorrente;
import br.gov.caixa.siacg.model.domain.Contrato;
import br.gov.caixa.siacg.model.domain.GarantiaAplicacao;
import br.gov.caixa.siacg.model.domain.GarantiaCartaoCredito;
import br.gov.caixa.siacg.model.domain.GarantiaContrato;
import br.gov.caixa.siacg.model.domain.Pessoa;
import br.gov.caixa.siacg.model.domain.SinalizadorLiquidez;
import br.gov.caixa.siacg.model.domain.Titulo;
import br.gov.caixa.siacg.model.domain.TotalizadorMaiorSacado;
import br.gov.caixa.siacg.model.domain.UnidadeHabitacional;
import br.gov.caixa.siacg.model.enums.CaracteristicaEnum;
import br.gov.caixa.siacg.model.enums.GrupoGarantiaEnum;
import br.gov.caixa.siacg.model.enums.NoFuncionalidadeEnum;
import br.gov.caixa.siacg.model.vo.ContratoParametrizadoVO;
import br.gov.caixa.siacg.model.vo.PessoaVO;
import br.gov.caixa.siacg.model.vo.RelatorioAnaliseContratoVO;
import br.gov.caixa.siacg.model.vo.RelatorioHipersuficienciaVO;
import br.gov.caixa.siacg.model.vo.RelatorioProspectoComTitulosVO;
import br.gov.caixa.siacg.model.vo.RelatorioProspectoSemTitulosVO;
import br.gov.caixa.siacg.model.vo.TitulosSemComercializacaoVO;
import br.gov.caixa.siacg.model.vo.VariacaoRecebiveisVO;
import br.gov.caixa.siacg.service.AnaliseCartaoCreditoService;
import br.gov.caixa.siacg.service.ChequeExcepcionadoService;
import br.gov.caixa.siacg.service.ContratoService;
import br.gov.caixa.siacg.service.EmpreendimentoService;
import br.gov.caixa.siacg.service.GarantiaCartaoCreditoService;
import br.gov.caixa.siacg.service.ParametrizacaoContratoService;
import br.gov.caixa.siacg.service.ProspectoService;
import br.gov.caixa.siacg.service.RelatorioAnaliseService;
import br.gov.caixa.siacg.service.SinalizadorLiquidezService;
import br.gov.caixa.siacg.service.TituloService;
import br.gov.caixa.siacg.service.UnidadeHabitacionalService;
import br.gov.caixa.siacg.util.LogCEF;
import br.gov.caixa.siacg.util.NumeroUtil;
import br.gov.caixa.siacg.view.form.DetalheDuplicatasVisao;
import br.gov.caixa.siacg.view.form.RelatorioAnaliseVisao;
import net.sf.jasperreports.engine.JasperFillManager;
import net.sf.jasperreports.engine.JasperPrint;
import net.sf.jasperreports.engine.data.JRBeanCollectionDataSource;

/**
 * <p>
 * RelatorioAnaliseMB
 * </p>
 * <p>
 * Descrição: Managed bean do caso de uso <code>Relatório de Análise de
 * carteira</code>.
 * </p>
 * <br>
 * <b>Empresa:</b> Cef - Caixa Econômica Federal
 *
 * @author ricardocrispim@gsgroup.com.br
 * @version 1.0
 */
@Named
@SessionScoped
public class RelatorioAnaliseMB extends ManutencaoBean<AnaliseContrato> {

    /** Atributo CHARSET_NAME_UTF8. */
    private static final String CHARSET_NAME_UTF8 = "UTF-8";

    /** Atributo VIRGULA. */
    private static final String VIRGULA = ",";

    /** Atributo VAZIO. */
    private static final String VAZIO = "";

    /** Atributo PNG. */
    private static final String PNG = "png";

    /** Atributo serialVersionUID. */
    private static final long serialVersionUID = 509553705294132803L;

    /** Atributo LOG. */
    private static final Logger LOG = Logger.getLogger(RelatorioAnaliseMB.class.getName());

    /** Atributo NOME_MANAGED_BEAN. */
    public static final String NOME_MANAGED_BEAN = "relatorioAnaliseMB";

    /** Atributo EL_MANAGED_BEAN. */
    public static final String EL_MANAGED_BEAN = "#{relatorioAnaliseMB}";

    /** Atributo PAGINA_RELATORIO_ANALISE. */
    public static final String PAGINA_RELATORIO_ANALISE = "/pages/analise/analiseRelatorio.xhtml?faces-redirect=true";

    /** Atributo PAGINA_RELATORIO_ANALISE_HABITACAO. */
    public static final String PAGINA_RELATORIO_ANALISE_HABITACAO = "/pages/analise/analiseGarantiaHabitacao.xhtml?faces-redirect=true";

    /** Atributo PAGINA_DETALHE_DUPLICATAS. */
    public static final String PAGINA_DETALHE_DUPLICATAS = "/pages/analise/detalheDuplicatas.xhtml?faces-redirect=true";

    /** Atributo TOTAL_CONTA_CORRENTE_NLM. */
    public static final String TOTAL_CONTA_CORRENTE_NLM = "Total em Conta Corrente NLM";

    /** Atributo VALOR_ESPERADO. */
    public static final String VALOR_ESPERADO = "Garantia Pactuada";

    /** Atributo VALOR_GARANTIA. */
    public static final String VALOR_GARANTIA = "Garantia Constituída";

    /** Atributo ESTOQUE. */
    public static final String ESTOQUE = "ESTOQUE";

    /** Atributo POS_OBRA. */
    public static final String POS_OBRA = "PÓS OBRA";

    /** Atributo SD_SC. */
    public static final String SD_SC = "SD + SC";

    /** Atributo IGR. */
    public static final String IGR = "IGR";

    /** Atributo GRAFICO_PNG. */
    private static final String GRAFICO_PNG = File.separator + "grafico.png";

    /** Atributo CAMINHO_REL_PROSP_SEMTITULO. */
    public static final String CAMINHO_REL_PROSP_SEMTITULO = "/reports/prospectoSemTitulos.jasper";

    /** Atributo CAMINHO_REL_PROSP_SEMTITULO. */
    public static final String CAMINHO_REL_PROSP_COMTITULO = "/reports/prospectoComTitulos.jasper";

    /** Atributo CAMINHO_REL_PROSP_SEMTITULO. */
    public static final String CAMINHO_REL_TITULOS_SEM_COMERC = "/reports/titulosSemComercializacao.jasper";

    /** Atributo service. */
    @EJB
    private transient RelatorioAnaliseService service;

    /** Atributo tituloService. */
    @EJB
    private transient TituloService tituloService;

    @EJB
    private transient UnidadeHabitacionalService uhService;

    @EJB
    private transient ProspectoService prospectoService;

    /** Atributo parametrizacaoService. */
    @EJB
    private transient ParametrizacaoContratoService parametrizacaoService;

    /** Atributo chequeExcepcionadoService. */
    @Inject
    private transient ChequeExcepcionadoService chequeExcepcionadoService;

    /** Atributo contratoService. */
    @Inject
    private transient ContratoService contratoService;

    /** Atributo sinalizadorService. */
    @Inject
    private transient SinalizadorLiquidezService sinalizadorService;

    /** Atributo pdfConverterConfig. */
    @Inject
    private transient PDFConverterConfig pdfConverterConfig;

    /** Atributo parametrizacaoContratoMB. */
    @Inject
    private ParametrizacaoContratoMB parametrizacaoContratoMB;

    /** Atributo detalheDuplicatasMB. */
    @Inject
    private DetalheDuplicatasMB detalheDuplicatasMB;

    /** Atributo detalheChequeMB. */
    @Inject
    private DetalheChequeMB detalheChequeMB;

    /** Atributo visao. */
    private RelatorioAnaliseVisao visao;

    /** Atributo mesesEano. */
    private List<String> mesesEano;

    /** Atributo mesesEanoGrafico. */
    private List<String> mesesEanoGrafico;

    @EJB
    private transient EmpreendimentoService empreendimentoService;
    
    @EJB
    private GarantiaCartaoCreditoService garantiaCartaoCreditoService;

    /** Atributo relatorioHipersuficienciaVO */
    private transient RelatorioHipersuficienciaVO relatorioHipersuficienciaVO;
    
    @Inject
    private AnaliseCartaoCreditoService analiseCartaoCreditoService;
 
    /**
     * Carrega os dados necessarios na visão.
     *
     * @param contrato
     *            valor a ser atribuído
     * @author Ricardo Crispim
     */
    public void carregarDados(final Contrato contrato) {
	this.iniciarBoleanosRelatorio();
	this.limparListas();

	final boolean calculoAutomatico = false;

	visao.setBase64ImagemGrafico(RelatorioAnaliseMB.VAZIO);
	final RelatorioAnaliseService servico = this.getService();
	visao.setContratoSelecionado(contrato);

	AnaliseContrato analiseContrato = contrato.getNuUltimaAnaliseContrato();
	visao.setListaGarantiaContratoDuplicata(servico.listarGarantiaContratoDuplicata(contrato, null));
	final RelatorioAnaliseContratoVO relatorio = null;

        if (servico.isNecessarioRealizarNovaAnalise(analiseContrato)) {
            servico.realizarCalculoAnaliseContrato(contrato.converterParaContratoCalculoTO(), calculoAutomatico, UsuarioUtil.getUsuarioLogado().getDeMatricula());
            analiseContrato = servico.obterUltimaAnaliseContrato(contrato.getNuContrato());
        }

	this.getVisao().setAnaliseContrato(analiseContrato);

	Integer nuPessoa = contrato.getNuPessoa().getNuPessoa();
	this.getVisao().setPossuiSaldoCarteiraDisponivel(this.service.isPessoaPossuiSaldoCarteiraDisponivel(nuPessoa));
	this.getVisao().setListaSaldoCartaoBandeira(this.service.listarSaldoCartaoBandeiraPessoa(nuPessoa));

	// Popula a grid de aplicações financeiras
	this.getVisao().getListaGarantiaAplicacao().clear();

	BigDecimal saldoTotal = BigDecimal.ZERO;
	BigDecimal totalGarantia = BigDecimal.ZERO;

	for (final GarantiaContrato garantiaContrato : contrato.getGarantiaContratoList()) {
	    if (CollectionUtils.isNotEmpty(garantiaContrato.getListGarantiaAplicacao())) {
		for (final GarantiaAplicacao garantiaAplicacao : garantiaContrato.getListGarantiaAplicacao()) {

		    this.getVisao().getListaGarantiaAplicacao().add(garantiaAplicacao);

		    saldoTotal = saldoTotal.add(garantiaAplicacao.getId().getAplicacaoFinanceira().getVrSaldo());
		    totalGarantia = totalGarantia.add(garantiaAplicacao.getVrConsumidoAplicacaoFinanceira());
		}

		visao.setContemGarantiaAplicacaoFinanceira(true);
	    }

	    if (garantiaContrato.isGarantiaDuplicata() && garantiaContrato.getIcCaracteristica() != null) {
		visao.setContemGarantiaDuplicata(true);
		if (garantiaContrato.getIcCaracteristica().getValor().equals(CaracteristicaEnum.ESTOQUE.getValor())) {
		    visao.setContemGarantiaCaracteristicaEstoque(true);
		    visao.setCedentesUtilizadosEstoque(garantiaContrato.getListaCedentesUtilizados());
		} else if (garantiaContrato.getIcCaracteristica().getValor().equals(CaracteristicaEnum.FLUXO.getValor())) {
		    visao.setContemGarantiaCaracteristicaFluxo(true);
		    visao.setCedentesUtilizadosFluxo(garantiaContrato.getListaCedentesUtilizados());
		}

	    }

	    // Habilita dados da aplicação financeira
	    if (!visao.isContemGarantiaAplicacaoFinanceira() && garantiaContrato.isGarantiaAplicacaoFinanceira()) {
		visao.setContemGarantiaAplicacaoFinanceira(true);
	    }

	    // Habilita dados do Cheque
	    if (!visao.isContemGarantiaCheque() && garantiaContrato.isGarantiaCheque()) {
		visao.setContemGarantiaCheque(true);
	    }

	    // Habilita dados da garantia de Cartão
	    if (!visao.isContemGarantiaCartao() && garantiaContrato.isGarantiaCartaoCredito()) {
		this.tratarInformacoesCartaoCredito(contrato, visao);
	    }
	}

	// Define o valor total da grid
	visao.setTotalValorSaldoGarantiaAplicacaoFinanceira(totalGarantia);
	visao.setTotalValorSaldoTotalAplicacaoFinanceira(saldoTotal);

	visao.setRelatorio(relatorio);
	visao.setEntidade(analiseContrato);

	// Ordenar lista de AnaliseParecer por descrição do Grupo Garantia
	Collections.sort(new ArrayList<AnaliseParecer>(analiseContrato.getAnaliseParecerList()), new DescricaoGrupoGarantiaComparator());

	visao.setListaContaContratoNaoLivreMovimentacao(
		this.service.listarContaContratoNaoLivreMovimentacaoPorNumeroContrato(contrato.getNuContrato()));
	visao.setCodigoCedente(null);

	if (visao.isContemGarantiaDuplicata()) {
	    this.tratarInformacoesDuplicata(visao, servico);
	}

	this.verificarExistenciaCaracteristicaETipoGarantia();
	visao.setListaUltimasAnalisesContrato(
		this.getService().obterCincoUltimasAnalisesExcluindoAnaliseAtual(contrato.getNuContrato(), analiseContrato.getNuAnaliseContrato()));
	// Verificar permissoes do usuario logado
	this.verificarPermissoes();

	this.getVisao().setSegmentoMPE(this.parametrizacaoService.isSegmentoMPE(contrato));
    }

    /**
     * <p>
     * Método responsável por tratar informações de garantias de cartão de
     * crédito.
     * <p>
     *
     * @param contrato
     *            valor a ser atribuído
     * @param visao
     *            valor a ser atribuído
     * @author guilherme.santos
     */
    private void tratarInformacoesCartaoCredito(final Contrato contrato, final RelatorioAnaliseVisao visao) {
	visao.setContemGarantiaCartao(true);
	this.getVisao().setListaCartaoCreditoEstoque(analiseCartaoCreditoService.listarAnaliseCartaoCredito(contrato.getNuContrato(), "02", false));
	this.getVisao().setListaCartaoCreditoFluxo(analiseCartaoCreditoService.listarAnaliseCartaoCredito(contrato.getNuContrato(), "01", false));
	this.categorizarCartaoEstoquePorBandeira();
	this.categorizarCartaoFluxoPorBandeira();

	this.getVisao().setContemGarantiaCartaoEstoque(!this.getVisao().getListaCartaoCreditoEstoque().isEmpty());
	this.getVisao().setContemGarantiaCartaoFluxo(!this.getVisao().getListaCartaoCreditoFluxo().isEmpty());
    }

    /**
     * <p>
     * Método responsável por popular o mapa das bandeiras com as analises de
     * estoque
     * </p>
     * .
     *
     * @author p541915
     *
     */
    private void categorizarCartaoEstoquePorBandeira() {
		Map<BandeiraCartao, Collection<AnaliseCartaoBandeira>> retorno = new TreeMap<>(Collections.reverseOrder(new Comparator<BandeiraCartao>() {
		    @Override
		    public int compare(final BandeiraCartao bandeiraCartao1, final BandeiraCartao bandeiraCartao2) {
			return bandeiraCartao1.getVrAnaliseEstoqueTotal().compareTo(bandeiraCartao2.getVrAnaliseEstoqueTotal());
		    }
		}));
	
		Map<BandeiraCartao, Collection<AnaliseCartaoBandeira>> mapaCartaoPorBandeira = new HashMap<>();
		Contrato contratro = this.getVisao().getContratoSelecionado();
	
		for (AnaliseCartaoCredito analise : this.getVisao().getListaCartaoCreditoEstoque()) {
		    for (AnaliseCartaoBandeira analiseBandeira : analise.getAnalisesCartaoBandeira()) {
				BandeiraCartao bandeiraCartao = analiseBandeira.getBandeiraCartao();
				ContaCorrente nuConta = analise.getNuConta();
				 
				BigDecimal pPcConcentracao = this.pegarPercentualConcetracao(nuConta, contratro.getGarantiaContratoList(), bandeiraCartao, "02");
				analiseBandeira.setPcConcentracao(pPcConcentracao);
				
				if (mapaCartaoPorBandeira.containsKey(bandeiraCartao)) {
				    mapaCartaoPorBandeira.get(bandeiraCartao).add(analiseBandeira);
				} else {
				    Collection<AnaliseCartaoBandeira> listaAnaliseCartaoBandeira = new ArrayList<>();
				    listaAnaliseCartaoBandeira.add(analiseBandeira);
				    mapaCartaoPorBandeira.put(bandeiraCartao, listaAnaliseCartaoBandeira);
				}
				//atualizaValoresBandeiraPorAnalise(bandeiraCartao, analiseBandeira);
				atualizaValoresAnaliseBandeiraEstoque(bandeiraCartao, analiseBandeira);
		    }
		}
	
		for (BandeiraCartao bandeiraCartao : new ArrayList<>(mapaCartaoPorBandeira.keySet())) {
		    retorno.put(bandeiraCartao, mapaCartaoPorBandeira.get(bandeiraCartao));
		}
	
		this.getVisao().setMapaCartaoPorBandeiraEstoque(retorno);
    }

    /**
     * <p>
     * Método responsável por popular o mapa das bandeiras com as analises de
     * fluxo
     * </p>
     * .
     *
     * @author p541915
     *
     */
    private void categorizarCartaoFluxoPorBandeira() {
		Map<BandeiraCartao, Collection<AnaliseCartaoBandeira>> retorno = new TreeMap<>(Collections.reverseOrder(new Comparator<BandeiraCartao>() {
		    @Override
		    public int compare(final BandeiraCartao bandeiraCartao1, final BandeiraCartao bandeiraCartao2) {
		    	return bandeiraCartao1.getVrAnaliseFluxoTotal().compareTo(bandeiraCartao2.getVrAnaliseFluxoTotal());
		    }
		}));
	
		Map<BandeiraCartao, Collection<AnaliseCartaoBandeira>> mapaCartaoPorBandeira = new HashMap<>();
		Contrato contratro = this.getVisao().getContratoSelecionado();
		
		for (AnaliseCartaoCredito analise : this.getVisao().getListaCartaoCreditoFluxo()) {
		    for (AnaliseCartaoBandeira analiseBandeira : analise.getAnalisesCartaoBandeira()) {
				BandeiraCartao bandeiraCartao = analiseBandeira.getBandeiraCartao();
				ContaCorrente nuConta = analise.getNuConta();
				 
				BigDecimal pPcConcentracao = this.pegarPercentualConcetracao(nuConta, contratro.getGarantiaContratoList(), bandeiraCartao, "01");
				analiseBandeira.setPcConcentracao(pPcConcentracao);
				
				//GarantiaCartaoCreditoDAO
				if (mapaCartaoPorBandeira.containsKey(bandeiraCartao)) {
				    mapaCartaoPorBandeira.get(bandeiraCartao).add(analiseBandeira);
				} else {
				    Collection<AnaliseCartaoBandeira> listaAnaliseCartaoBandeira = new ArrayList<>();
				    listaAnaliseCartaoBandeira.add(analiseBandeira);
				    mapaCartaoPorBandeira.put(bandeiraCartao, listaAnaliseCartaoBandeira);
				}
				atualizaValoresAnaliseBandeiraFluxo(bandeiraCartao, analiseBandeira);
		    }
		}
	
		for (BandeiraCartao bandeiraCartao : new ArrayList<>(mapaCartaoPorBandeira.keySet())) {
		    Collection<AnaliseCartaoBandeira> value = mapaCartaoPorBandeira.get(bandeiraCartao);		    
		    retorno.put(bandeiraCartao, value);
		}
	
//		this.getVisao().setMapaCartaoPorBandeiraFluxo(retorno);
		this.getVisao().setMapaCartaoPorBandeiraFluxo(mapaCartaoPorBandeira);
    }
    

    /**
     * 
     * <p>Método responsável por buscar o valor percentual informado pelo usuario Garantia Cartao de Credito</p>.
     *
     * @author f585733
     *
     * @param nuConta
     * @param garantiaContratoList
     * @param bandeiraCartao
     * @param icCaracteristica
     * @return
     */
    private BigDecimal pegarPercentualConcetracao(ContaCorrente nuConta, Collection<GarantiaContrato> garantiaContratoList,
	    BandeiraCartao bandeiraCartao, String icCaracteristica) {
	BigDecimal pPcConcentracao = BigDecimal.ZERO;

	for (GarantiaContrato garantiaContrato : garantiaContratoList) {
	    if (garantiaContrato.isGarantiaCartaoCredito()) {
		Collection<GarantiaCartaoCredito> cartoes = garantiaContrato.getListaGarantiaCartaoCredito();
		for (GarantiaCartaoCredito garantiaCartaoCredito : cartoes) {
		    if (garantiaCartaoCredito.getNuConta().equals(nuConta)
			    && bandeiraCartao.getNoBandeiraCartao().equals(garantiaCartaoCredito.getBandeiraCartao().getNoBandeiraCartao())
			    && garantiaContrato.getIdentificadorCaracteristica().equals(icCaracteristica)) {
			pPcConcentracao = garantiaCartaoCredito.getPcConcentracao();
			break;
		    }
		}
	    }

	}

	return pPcConcentracao;
    }

    /**
     * 
     * <p>
     * Método responsável por setar os valores de ESTOQUE da bandeira de acordo com a
     * análise informada.
     * </p>
     * .
     *
     * @param bandeiraCartao
     *            bandeira destino dos valores atualizados
     * @param analiseBandeira
     *            análise origem dos valores
     * 
     * @author rafael.souza
     */
    private void atualizaValoresAnaliseBandeiraEstoque(BandeiraCartao bandeiraCartao, AnaliseCartaoBandeira analiseBandeira) {
	bandeiraCartao.setVrAnaliseEstoqueTotal(bandeiraCartao.getVrAnaliseEstoqueTotal().add(analiseBandeira.getVrSaldoTotal()));
	bandeiraCartao.setVrAnaliseEstoqueGarantiaOutrosContratosTotal(
		bandeiraCartao.getVrAnaliseEstoqueGarantiaOutrosContratosTotal().add(analiseBandeira.getVrOutrosContratos()));
	bandeiraCartao.setVrAnaliseEstoqueGarantiaContratoTotal(
		bandeiraCartao.getVrAnaliseEstoqueGarantiaContratoTotal().add(analiseBandeira.getVrConsumidoContrato()));
	bandeiraCartao
		.setVrAnaliseEstoquePreAnaliseTotal(bandeiraCartao.getVrAnaliseEstoquePreAnaliseTotal().add(analiseBandeira.getVrSaldoDisponivel()));
    }
    
    /**
     * 
     * <p>
     * Método responsável por setar os valores de FLUXO da bandeira de acordo com a
     * análise informada.
     * </p>
     * .
     *
     * @param bandeiraCartao
     *            bandeira destino dos valores atualizados
     * @param analiseBandeira
     *            análise origem dos valores
     * 
     * @author gilberto.nery
     */
    private void atualizaValoresAnaliseBandeiraFluxo(BandeiraCartao bandeiraCartao, AnaliseCartaoBandeira analiseBandeira) {
	bandeiraCartao.setVrAnaliseFluxoTotal(bandeiraCartao.getVrAnaliseEstoqueTotal().add(analiseBandeira.getVrSaldoTotal()));
	bandeiraCartao.setVrAnaliseFluxoGarantiaOutrosContratosTotal(
		bandeiraCartao.getVrAnaliseFluxoGarantiaOutrosContratosTotal().add(analiseBandeira.getVrOutrosContratos()));
	bandeiraCartao.setVrAnaliseFluxoGarantiaContratoTotal(
		bandeiraCartao.getVrAnaliseFluxoGarantiaContratoTotal().add(analiseBandeira.getVrConsumidoContrato()));
	bandeiraCartao
		.setVrAnaliseFluxoPreAnaliseTotal(bandeiraCartao.getVrAnaliseFluxoPreAnaliseTotal().add(analiseBandeira.getVrSaldoDisponivel()));
    }

    /**
     * <p>
     * Método responsável por tratar informações referente a garantias
     * duplicatas.
     * <p>
     *
     * @param visao
     *            valor a ser atribuído
     * @param servico
     *            valor a ser atribuído
     * @author guilherme.santos
     */
    private void tratarInformacoesDuplicata(final RelatorioAnaliseVisao visao, final RelatorioAnaliseService servico) {

	final Collection<Cedente> listaCedentesGarantiaDuplicata = servico.listarCedentesGarantiacontrato(visao.getListaGarantiaContratoDuplicata());

	final List<TotalizadorMaiorSacado> listMaioresSacados = (List<TotalizadorMaiorSacado>) servico
		.listarDezMaioresSacados(listaCedentesGarantiaDuplicata);

	Collections.sort(listMaioresSacados, new TotalDuplicatasMaioresSacadosComparator());

	visao.setListaMaioresSacados(listMaioresSacados);

	visao.setListaCedentesDuplicatas(super.construirCombobox(listaCedentesGarantiaDuplicata, "coCedente", "coCedente"));
	this.criarGraficoEvolucaoDaCarteiraDeRecebiveis();
	this.getImagemSinalizadorLiquidez();
    }

    /**
     * <p>
     * Método responsável por inicializar as listas da tela de analiseRelatorio.
     * <p>
     *
     * @author guilherme.santos
     */
    private void limparListas() {
	this.getVisao().setListaCartaoCreditoEstoque(new ArrayList<AnaliseCartaoCredito>());
	this.getVisao().setListaCartaoCreditoEstoque(new ArrayList<AnaliseCartaoCredito>());
    }

    /**
     * <p>
     * Método responsável por calcular o total da quantidade de duplicatas a
     * vencer.
     * <p>
     *
     * @return Integer
     * @author Caio Graco
     */
    public Integer totalQuantidadeDuplicatasAVencer() {
	final Collection<TotalizadorMaiorSacado> listaMaioresSacados = this.getVisao().getListaMaioresSacados();

	Integer total = 0;

	for (final TotalizadorMaiorSacado sacado : listaMaioresSacados) {
	    total = total + sacado.getQtTituloVencer();
	}

	return total;
    }

    /**
     * <p>
     * Método responsável por calcular o total da quantidade de duplicatas
     * pagas.
     * <p>
     *
     * @return Integer
     * @author Caio Graco
     */
    public Integer totalQuantidadeDuplicatasPagas() {
	final Collection<TotalizadorMaiorSacado> listaMaioresSacados = this.getVisao().getListaMaioresSacados();

	Integer total = 0;

	for (final TotalizadorMaiorSacado sacado : listaMaioresSacados) {
	    total = total + sacado.getQtTituloPago();
	}

	return total;
    }

    /**
     * <p>
     * Método responsável por calcular o total da quantidade de duplicatas
     * inadimplentes.
     * <p>
     *
     * @return Integer
     * @author Caio Graco
     */
    public Integer totalQuantidadeDuplicatasInadimplentes() {
	final Collection<TotalizadorMaiorSacado> listaMaioresSacados = this.getVisao().getListaMaioresSacados();

	Integer total = 0;

	for (final TotalizadorMaiorSacado sacado : listaMaioresSacados) {
	    total = total + (sacado.getQtTituloBaixadoProtestado() + sacado.getQtTituloVencido());
	}

	return total;
    }

    /**
     * <p>
     * Método responsável por calcular o total do valor das duplicatas
     * inadimplentes.
     * <p>
     *
     * @return BigDecimal
     * @author Caio Graco
     */
    public BigDecimal totalValorDuplicatasInadimplentes() {
	final Collection<TotalizadorMaiorSacado> listaMaioresSacados = this.getVisao().getListaMaioresSacados();

	BigDecimal total = BigDecimal.ZERO;

	for (final TotalizadorMaiorSacado sacado : listaMaioresSacados) {
	    total = total.add(sacado.getVrTituloBaixadoProtestado().add(sacado.getVrTituloVencido()));
	}

	return total;
    }

    /**
     * <p>
     * Método responsável por calcular o total do valor das duplicatas a vencer.
     * <p>
     *
     * @return BigDecimal
     * @author Caio Graco
     */
    public BigDecimal totalValorDuplicatasAVencer() {
	final Collection<TotalizadorMaiorSacado> listaMaioresSacados = this.getVisao().getListaMaioresSacados();

	BigDecimal total = BigDecimal.ZERO;

	for (final TotalizadorMaiorSacado sacado : listaMaioresSacados) {
	    total = total.add(sacado.getVrTituloVencer());
	}

	return total;
    }

    /**
     * <p>
     * Método responsável por calcular o total do valor das duplicatas pagas.
     * <p>
     *
     * @return BigDecimal
     * @author Caio Graco
     */
    public BigDecimal totalValorDuplicatasPagas() {
	final Collection<TotalizadorMaiorSacado> listaMaioresSacados = this.getVisao().getListaMaioresSacados();

	BigDecimal total = BigDecimal.ZERO;

	for (final TotalizadorMaiorSacado sacado : listaMaioresSacados) {
	    total = total.add(sacado.getVrTituloPago());
	}

	return total;
    }

    /**
     * <p>
     * Método responsável por gerar um byte[] e passar para o método
     * <code>salvarBytePdfAnalise(byte[] bytesPDFRelatorio)</code> como.
     * parametro
     * <p>
     *
     * @return String
     * @author Waltenes Junior
     * @throws ConversionException 
     */
    public String gerarImagemPdf() {

	this.pdfConverterConfig.setEnablePdf(true);
	this.pdfConverterConfig.setFileName("Analise_contrato_N_" + this.getVisao().getEntidade().getNuAnaliseContrato() + ".pdf");
	this.pdfConverterConfig.setPdfAction("#{relatorioAnaliseMB.salvarBytePdfAnalise}");

	return "relatorio";
    }

    /**
     * Método responsável por receber as String referente ao caminho adicionado
     * ao inputHidden id="base64ImagemGrafico".
     *
     * pela função javaScript exportChart();
     *
     * @author Leandro Santos Oliveira
     *
     */
    public void gerarImagemGrafico() {

	final RelatorioAnaliseVisao visao = this.getVisao();

	if (!UtilString.isVazio(visao.getBase64ImagemGrafico()) && visao.getBase64ImagemGrafico().split(RelatorioAnaliseMB.VIRGULA).length > 1) {

	    final String encoded = visao.getBase64ImagemGrafico().split(RelatorioAnaliseMB.VIRGULA)[1];

	    try {
		final byte[] decoded = Base64.decodeBase64(encoded.getBytes(RelatorioAnaliseMB.CHARSET_NAME_UTF8));
		final RenderedImage renderedImage = ImageIO.read(new ByteArrayInputStream(decoded));

		ImageIO.write(renderedImage, RelatorioAnaliseMB.PNG,
			new File(this.getCaminhoRelatorio() + File.separatorChar + RelatorioAnaliseMB.GRAFICO_PNG));

		visao.setBase64ImagemGrafico(RelatorioAnaliseMB.VAZIO);

	    } catch (final UnsupportedEncodingException eu) {
		LogCefUtil.error(eu.getMessage());
		LogCefUtil.error(eu);
	    } catch (final IOException e) {
		LogCefUtil.error(e.getCause());
		LogCefUtil.error(e);
	    }
	}
    }

    /**
     * Método responsável por recuperar o caminho do Diretorio do Servidor...
     *
     * @author Leandro Santos Oliveira
     *
     * @return <code>String</code>
     */
    public String getCaminhoRelatorio() {

	return ((HttpSession) FacesContext.getCurrentInstance().getExternalContext().getSession(false)).getServletContext()
		.getRealPath(File.separatorChar + "resources" + File.separatorChar + "img");
    }

    /**
     * <p>
     * Método responsável por salvar o byte[] do pdf na base de dados e chamar o
     * método de impressão do pdf.
     * <p>
     *
     * @param bytesPDFRelatorio
     *            valor a ser atribuído
     * @return String com a mesma tela
     * @author Waltenes Junior
     */
    public String salvarBytePdfAnalise(final byte[] bytesPDFRelatorio) {
	if (getVisao().getEntidade() != null && getVisao().getEntidade().getImAnaliseContrato() == null) {
	    getVisao().getEntidade().setImAnaliseContrato(bytesPDFRelatorio);
	    getService().salvar(getVisao().getEntidade());
	}

	try {
	    this.imprimirPdf(bytesPDFRelatorio,
		    "Analise_contrato_N_" + getVisao().getEntidade().getNuAnaliseContrato() + EnumExtensaoArquivo.PDF.getExtensao());
	} catch (final IOException e) {
	    LogCefUtil.error("PDF não pode ser gerado");
	    LogCefUtil.error(e);
	}

	return super.MESMA_TELA;
    }

    /**
     * <p>
     * Método responsável por iniciar todos os boleanos que renderizam as grids
     * do relatorio.
     * <p>
     *
     * @author Caio Graco
     */
    public void iniciarBoleanosRelatorio() {
	final RelatorioAnaliseVisao visao = this.getVisao();
	visao.setContemGarantiaCaracteristicaFluxo(false);
	visao.setContemGarantiaCaracteristicaEstoque(false);
	visao.setContemGarantiaDuplicata(false);
	visao.setContemGarantiaCheque(false);
	visao.setContemGarantiaCartao(false);
	visao.setContemGarantiaAlienacaoVeiculo(false);
	visao.setContemGarantiaAlienacaoImobiliaria(false);
	visao.setContemGarantiaAplicacaoFinanceira(false);
	visao.setContemGarantiaMaquinaEquipamento(false);
	visao.setContemGarantiaOutros(false);
	visao.setContemGarantiaCartao(false);
	visao.setContemGarantiaCartaoEstoque(false);
	visao.setContemGarantiaCartaoFluxo(false);
	visao.setPossuiSaldoCarteiraDisponivel(false);
    }

    /**
     * <p>
     * Método responsável por abrir os cheques excepcionados das garantias do
     * tipo cheque do contrato.
     * <p>
     *
     * @author Caio Graco
     */
    public void abrirChequesExcepcionadas() {
	this.getVisao().setListaChequeExcepcionados(
		this.chequeExcepcionadoService.listarPorGarantiaContrato(this.getVisao().getContratoSelecionado().getGarantiaContratoList()));
    }

    /**
     * <p>
     * Método responsável por listar as duplicatas excepcionadas do contrato.
     * <p>
     *
     * @param duplicataExcepcionada
     *            valor a ser atribuído
     * @author Caio Graco
     */
    public void abrirDuplicatasExcepcionadas(final Boolean duplicataExcepcionada) {
	this.getVisao().getListaDuplicatasExcepcionadas().clear();

	this.getVisao().setListaDuplicatasExcepcionadas(
		this.parametrizacaoService.listaDuplicataExcepcionadaPorContrato(this.getVisao().getContratoSelecionado(), duplicataExcepcionada));
    }

    /**
     * <p>
     * Método responsável por consultar sacados excepcionados da
     * GarantiaContrato.
     * <p>
     *
     * @author guilherme.santos
     */
    public void abrirSacadoExcepcionado() {
	final GarantiaContrato garantiaContratoDuplicataEstoque;

	this.getVisao().getListaSacadoExcepcionadoVO().clear();
	garantiaContratoDuplicataEstoque = this.getVisao().getGarantiaContratoDuplicataEstoque();

	if (garantiaContratoDuplicataEstoque != null) {
	    this.getVisao().getListaSacadoExcepcionadoVO()
		    .addAll(this.service.listarSacadoExcepcionadoPorGarantia(garantiaContratoDuplicataEstoque.getNuGarantia()));
	}
    }

    /**
     * <p>
     * Método responsável por verificar a existência de características de
     * Garantia (FLUXO, ESTOQUE) e tipos de Garantia (DUPLICATA, CHEQUE, CARTAO,
     * ALIENACAO_VEICULO, ALIENACAO_IMOBILIARIA, MAQUINA_EQUIPAMENTO, OUTROS)
     * para renderização da página.
     * <p>
     *
     * @author Ronnie Mikihiro
     */
    public void verificarExistenciaCaracteristicaETipoGarantia() {
	final RelatorioAnaliseVisao visao = this.getVisao();
	final Collection<GarantiaContrato> listaGarantiaContrato = visao.getContratoSelecionado().getGarantiaContratoList();

	for (final GarantiaContrato garantiaContrato : listaGarantiaContrato) {

	    if (garantiaContrato.getGarantia().isGrupoGarantia(GrupoGarantiaEnum.DUPLICATA)) {
		if (CaracteristicaEnum.FLUXO.equals(garantiaContrato.getIcCaracteristica())) {
		    visao.setContemGarantiaCaracteristicaFluxo(true);
		} else if (CaracteristicaEnum.ESTOQUE.equals(garantiaContrato.getIcCaracteristica())) {
		    visao.setContemGarantiaCaracteristicaEstoque(true);
		}
		visao.setContemGarantiaDuplicata(true);
		continue;
	    }

	    if (garantiaContrato.getGarantia().isGrupoGarantia(GrupoGarantiaEnum.CHEQUE)) {
		visao.setContemGarantiaCheque(true);
		continue;
	    }

	    if (garantiaContrato.getGarantia().isGrupoGarantia(GrupoGarantiaEnum.CARTAO_CREDITO)) {
		visao.setContemGarantiaCartao(true);
		continue;
	    }
	}
    }

    /**
     * <p>
     * Método responsável por atualizar a grid Dez Maiores Sacados de acordo com
     * o cedente selecionado pelo filtro.
     * <p>
     *
     * @author Ronnie Mikihiro, guilherme.santos
     */
    public void atualizarGridDezMaioresSacados() {
	final RelatorioAnaliseService servico = this.getService();
	final RelatorioAnaliseVisao visao = this.getVisao();
	if (UtilString.isVazio(visao.getCodigoCedente())) {
	    visao.setListaMaioresSacados(
		    servico.listarDezMaioresSacados(servico.listarCedentesGarantiacontrato(visao.getListaGarantiaContratoDuplicata())));
	} else {
	    final Cedente cedenteSelecionadoCombobox = this.consultarCedente();

	    if (cedenteSelecionadoCombobox != null) {
		visao.setListaMaioresSacados(servico.listarDezMaioresSacados(cedenteSelecionadoCombobox.getNuCedente()));
	    }
	}
    }

    /**
     * <p>
     * Método responsável por consultar o Cedente selecionado.
     * <p>
     *
     * @return Cedente
     * @author guilherme.santos
     */
    private Cedente consultarCedente() {
	Cedente cedenteSelecionadoCombobox = this.getService().obterCedenteCodigoCedentePessoa(this.visao.getCodigoCedente(),
		this.visao.getContratoSelecionado().getNuPessoa());

	if (cedenteSelecionadoCombobox == null) {
	    cedenteSelecionadoCombobox = this.getService().obterCedenteCodigoCedente(this.visao.getCodigoCedente()).iterator().next();
	}
	return cedenteSelecionadoCombobox;
    }

    /**
     * <p>
     * Método responsável por construir o gráfico de evolução da carteira de
     * recebiveis.
     * </p>
     *
     * @author joseroberto@gsgroup.com.br
     */
    private void criarGraficoEvolucaoDaCarteiraDeRecebiveis() {
	final RelatorioAnaliseVisao visao = this.getVisao();
	visao.setGraficoModel(new CartesianChartModel());

	final SimpleDateFormat formataData = new SimpleDateFormat("dd/MM/yyyy");

	final ChartSeries totalContaCorrenteNlm = new ChartSeries();
	totalContaCorrenteNlm.setLabel(RelatorioAnaliseMB.TOTAL_CONTA_CORRENTE_NLM);

	final ChartSeries valorEsperado = new ChartSeries();
	valorEsperado.setLabel(RelatorioAnaliseMB.VALOR_ESPERADO);

	final ChartSeries valorApurado = new ChartSeries();
	valorApurado.setLabel(RelatorioAnaliseMB.VALOR_GARANTIA);

	final Collection<AnaliseContrato> cincoUltimasAnalisesContrato = this.getService()
		.obterCincoUltimasAnalisesPorNumeroContrato(visao.getContratoSelecionado().getNuContrato());

	final List<AnaliseContrato> listaOrdenada = new ArrayList<>(cincoUltimasAnalisesContrato);

	Collections.sort(listaOrdenada, new DataImagemComparator());

	if (listaOrdenada.size() == 1) {
	    final GregorianCalendar calendar = new GregorianCalendar();
	    calendar.add(Calendar.DAY_OF_MONTH, -1);
	    final String dataOntem = formataData.format(calendar.getTime());

	    totalContaCorrenteNlm.set(dataOntem, 0);
	    valorEsperado.set(dataOntem, 0);
	    valorApurado.set(dataOntem, 0);
	}

	if (UtilObjeto.isReferencia(listaOrdenada) && !listaOrdenada.isEmpty()) {
	    for (final AnaliseContrato analiseContrato : listaOrdenada) {
		BigDecimal vrEsperado = BigDecimal.ZERO;
		for (final AnaliseParecer analiseParecer : analiseContrato.getAnaliseParecerList()) {
		    // é do tipo estoque, nao deve ficar o contains
		    if (analiseParecer.getGarantia().isGrupoGarantia(GrupoGarantiaEnum.DUPLICATA) && analiseParecer.getNoFormaGarantia() != null
			    && analiseParecer.getNoFormaGarantia().contains("E")) {
			vrEsperado = analiseParecer.getVrEsperado();
		    }
		}
		valorEsperado.set(formataData.format(analiseContrato.getDtImagem()), vrEsperado);
		totalContaCorrenteNlm.set(formataData.format(analiseContrato.getDtImagem()), analiseContrato.getVrSaldoCcNaoLivre());
		valorApurado.set(formataData.format(analiseContrato.getDtImagem()), analiseContrato.getVrLiquidoCarteira());
	    }
	}

	visao.getGraficoModel().addSeries(totalContaCorrenteNlm);
	visao.getGraficoModel().addSeries(valorEsperado);
	visao.getGraficoModel().addSeries(valorApurado);

    }

    /**
     * <p>
     * Método responsável por abrir a tela de relatório de analise de garantia.
     * <p>
     *
     * @param contratoParametrizadoVO
     *            valor a ser atribuído
     * @return String
     * @author guilherme.santos
     */
    @Auditoria
    @OperacaoAuditoria(acao = "ABRIR_RELATORIO_ANALISE_GARANTIA", parametros = {"contrato"})
    public String abrirRelatorioAnaliseGarantia(final ContratoParametrizadoVO contratoParametrizadoVO) {
	final Contrato contrato = new Contrato(contratoParametrizadoVO.getNuContrato());
	contrato.setIcCategoria(contratoParametrizadoVO.getIcCategoria());
	if (contrato.isContratoHabitacional()) {
	    return this.abrirRelatorioHabitacional(contrato);
	} else {
	    return this.abrirRelatorio(contrato);
	}
    }

    /**
     * <p>
     * Método responsável por Abre a pagina de relatório de analise carteira.
     * <p>
     *
     * @param contrato
     *            valor a ser atribuído
     * @return <code>String</code>
     * @author Ricardo Crispim
     */
    public String abrirRelatorio(Contrato contrato) {
	contrato = this.contratoService.obterContratoComRelacionamentosInicializados(contrato.getNuContrato());
	this.getVisao().setContratosSelecionados(this.service.listarOutrosContratosParametrizadosDaPessoa(contrato));
	this.carregarDados(contrato);
	this.processarResultadoAnalise();
	return RelatorioAnaliseMB.PAGINA_RELATORIO_ANALISE;
    }

    /**
     * <p>
     * Método responsável por Abre a pagina de relatório de analise carteira.
     * <p>
     *
     * @param contrato
     *            valor a ser atribuído
     * @return <code>String</code>
     * @author Brunno
     */
    public String abrirRelatorioHabitacional(Contrato contrato) {
	contrato = this.contratoService.obterContratoComRelacionamentosInicializados(contrato.getNuContrato());
	
	if (Objects.nonNull(contrato.getEmpreendimento())) {
	    final Long nuEmpreendimento = contrato.getEmpreendimento().getNuEmpreendimento();
	    getVisao().setNuEmpreendimento(nuEmpreendimento);
	    carregaTabelaVariacao(nuEmpreendimento, new Date());
	}
	carregarDadosRelHabitacao(contrato);
	processarResultadoAnalise();
	verificarPermissoes();
	return RelatorioAnaliseMB.PAGINA_RELATORIO_ANALISE_HABITACAO;
    }

    /**
     * <p>
     * Método responsável por carrega Tabela Variacao
     * <p>
     *
     * @param contrato
     *            valor a ser atribuído
     * @return <code>String</code>
     * @author Brunno
     */
    private void carregaTabelaVariacao(Long nuEmpreendimento, Date dataInicio) {
	final RelatorioAnaliseVisao v = this.getVisao();

	List<VariacaoRecebiveisVO> listVariacaoRecebiveis = new ArrayList<>();

	final Date anteriorSeisMeses = this.getAnterior6meses(dataInicio);
	final VariacaoRecebiveisVO voEstoque = empreendimentoService.variacaoEstoque(nuEmpreendimento, anteriorSeisMeses, dataInicio);
	final VariacaoRecebiveisVO voPosObra = empreendimentoService.variacaoPosObra(nuEmpreendimento, anteriorSeisMeses, dataInicio);
	final VariacaoRecebiveisVO voSDSC = empreendimentoService.variacaoSDSC(nuEmpreendimento, anteriorSeisMeses, dataInicio);

	listVariacaoRecebiveis.add(voEstoque);
	listVariacaoRecebiveis.add(voPosObra);
	listVariacaoRecebiveis.add(voSDSC);
	final VariacaoRecebiveisVO voIGR = calculaIGR(voEstoque, voPosObra, voSDSC);
	listVariacaoRecebiveis.add(voIGR);
	v.setListVariacaoRecebiveis(listVariacaoRecebiveis);

	this.somaMes(dataInicio);
	this.somaMesGrafico(dataInicio);

	this.criarGraficoVariacaoFuncaoTempo(voEstoque, voPosObra, voSDSC);
	this.criarGraficoVariacaoIGR(voIGR);

    }

    /**
     * <p>
     * Método responsável por criar Grafico Variacao Funcao Tempo
     * <p>
     * 
     * @author Brunno
     */
    private void criarGraficoVariacaoFuncaoTempo(VariacaoRecebiveisVO voEstoque, VariacaoRecebiveisVO voPosObra, VariacaoRecebiveisVO voSDSC) {
	final RelatorioAnaliseVisao visaoRel = this.getVisao();
	visao.setGraficoModel(new CartesianChartModel());

	final ChartSeries estoque = new ChartSeries();
	estoque.setLabel(RelatorioAnaliseMB.ESTOQUE);
	estoque.set(mesesEanoGrafico.get(0), voEstoque.getValor1());
	estoque.set(mesesEanoGrafico.get(1), voEstoque.getValor2());
	estoque.set(mesesEanoGrafico.get(2), voEstoque.getValor3());
	estoque.set(mesesEanoGrafico.get(3), voEstoque.getValor4());
	estoque.set(mesesEanoGrafico.get(4), voEstoque.getValor5());
	estoque.set(mesesEanoGrafico.get(5), voEstoque.getValor6());

	final ChartSeries posObra = new ChartSeries();
	posObra.setLabel(RelatorioAnaliseMB.POS_OBRA);
	posObra.set(mesesEanoGrafico.get(0), voPosObra.getValor1());
	posObra.set(mesesEanoGrafico.get(1), voPosObra.getValor2());
	posObra.set(mesesEanoGrafico.get(2), voPosObra.getValor3());
	posObra.set(mesesEanoGrafico.get(3), voPosObra.getValor4());
	posObra.set(mesesEanoGrafico.get(4), voPosObra.getValor5());
	posObra.set(mesesEanoGrafico.get(5), voPosObra.getValor6());

	final ChartSeries sdSc = new ChartSeries();
	sdSc.setLabel(RelatorioAnaliseMB.SD_SC);
	sdSc.set(mesesEanoGrafico.get(0), voSDSC.getValor1());
	sdSc.set(mesesEanoGrafico.get(1), voSDSC.getValor2());
	sdSc.set(mesesEanoGrafico.get(2), voSDSC.getValor3());
	sdSc.set(mesesEanoGrafico.get(3), voSDSC.getValor4());
	sdSc.set(mesesEanoGrafico.get(4), voSDSC.getValor5());
	sdSc.set(mesesEanoGrafico.get(5), voSDSC.getValor6());

	visaoRel.getGraficoModel().addSeries(estoque);
	visaoRel.getGraficoModel().addSeries(posObra);
	visaoRel.getGraficoModel().addSeries(sdSc);

    }

    /**
     * <p>
     * Método responsável por criar Grafico Variacao IGR Funcao Tempo
     * <p>
     * 
     * @author Brunno
     */
    private void criarGraficoVariacaoIGR(VariacaoRecebiveisVO voIGR) {
	final RelatorioAnaliseVisao visaoRel = this.getVisao();
	visao.setGraficoModelIgr(new CartesianChartModel());

	final ChartSeries igr = new ChartSeries();
	igr.setLabel(RelatorioAnaliseMB.IGR);
	igr.set(mesesEanoGrafico.get(0), voIGR.getValor1());
	igr.set(mesesEanoGrafico.get(1), voIGR.getValor2());
	igr.set(mesesEanoGrafico.get(2), voIGR.getValor3());
	igr.set(mesesEanoGrafico.get(3), voIGR.getValor4());
	igr.set(mesesEanoGrafico.get(4), voIGR.getValor5());
	igr.set(mesesEanoGrafico.get(5), voIGR.getValor6());

	visaoRel.getGraficoModelIgr().addSeries(igr);

    }

    /**
     * <p>
     * Método responsável por carrega Tabela Variacao por filtro
     * <p>
     * 
     * @author Brunno
     */
    public void filtrarTblVariacao() {
	carregaTabelaVariacao(this.getVisao().getNuEmpreendimento(), this.getVisao().getDataFiltroTblVariacao());
    }

    /**
     * <p>
     * Método responsável por calcular o IGR
     * <p>
     * 
     * @author Brunno
     */

    private VariacaoRecebiveisVO calculaIGR(VariacaoRecebiveisVO voEstoque, VariacaoRecebiveisVO voPosObra, VariacaoRecebiveisVO voSDSC) {
	VariacaoRecebiveisVO igr = new VariacaoRecebiveisVO();
	igr.setVariacao("IGR");
	if (voEstoque.getValor1().compareTo(BigDecimal.ZERO) != 0 || voPosObra.getValor1().compareTo(BigDecimal.ZERO) != 0
		|| voSDSC.getValor1().compareTo(BigDecimal.ZERO) != 0) {
	    igr.setValor1(criaExpressao(voEstoque.getValor1().add(voPosObra.getValor1()), voSDSC.getValor1()));
	}
	if (voEstoque.getValor2().compareTo(BigDecimal.ZERO) != 0 || voPosObra.getValor2().compareTo(BigDecimal.ZERO) != 0
		|| voSDSC.getValor2().compareTo(BigDecimal.ZERO) != 0) {
	    igr.setValor2(criaExpressao(voEstoque.getValor2().add(voPosObra.getValor2()), voSDSC.getValor2()));
	}
	if (voEstoque.getValor3().compareTo(BigDecimal.ZERO) != 0 || voPosObra.getValor3().compareTo(BigDecimal.ZERO) != 0
		|| voSDSC.getValor3().compareTo(BigDecimal.ZERO) != 0) {
	    igr.setValor3(criaExpressao(voEstoque.getValor3().add(voPosObra.getValor3()), voSDSC.getValor3()));
	}
	if (voEstoque.getValor4().compareTo(BigDecimal.ZERO) != 0 || voPosObra.getValor4().compareTo(BigDecimal.ZERO) != 0
		|| voSDSC.getValor4().compareTo(BigDecimal.ZERO) != 0) {
	    igr.setValor4(criaExpressao(voEstoque.getValor4().add(voPosObra.getValor4()), voSDSC.getValor4()));
	}
	if (voEstoque.getValor5().compareTo(BigDecimal.ZERO) != 0 || voPosObra.getValor5().compareTo(BigDecimal.ZERO) != 0
		|| voSDSC.getValor5().compareTo(BigDecimal.ZERO) != 0) {
	    igr.setValor5(criaExpressao(voEstoque.getValor5().add(voPosObra.getValor5()), voSDSC.getValor5()));
	}
	if (voEstoque.getValor6().compareTo(BigDecimal.ZERO) != 0 || voPosObra.getValor6().compareTo(BigDecimal.ZERO) != 0
		|| voSDSC.getValor6().compareTo(BigDecimal.ZERO) != 0) {
	    igr.setValor6(criaExpressao(voEstoque.getValor6().add(voPosObra.getValor6()), voSDSC.getValor6()));
	}

	return igr;
    }

    /**
     * <p>
     * Método responsável por criar a expressao de calculo de IGR
     * <p>
     * 
     * @author Brunno
     */

    private BigDecimal criaExpressao(BigDecimal estoquePosObra, BigDecimal sdSc) {
	if (sdSc.compareTo(BigDecimal.ZERO) != 0) {
	    return (estoquePosObra.divide(sdSc, RoundingMode.HALF_DOWN)).multiply(new BigDecimal("100"));
	} else {
	    return estoquePosObra.multiply(new BigDecimal("100"));
	}
    }

    /**
     * <p>
     * Método responsável por subtrair 6 meses a data parâmetro
     * <p>
     * 
     * @param Date
     * 
     * @return <code>Date</code>
     */
    private Date getAnterior6meses(Date data) {
	Calendar cal = Calendar.getInstance();
	cal.setTime(data);
	cal.set(Calendar.MONTH, cal.get(Calendar.MONTH) - 5);

	return cal.getTime();
    }

    /**
     * <p>
     * Método responsável por somar mes e retornar no formato (MMMMM yyyy)
     * <p>
     * 
     * @param Date
     * 
     * @return <code>List String</code>
     */
    private List<String> somaMes(Date data) {
	this.mesesEano = new ArrayList<>();
	for (int i = 5; i >= 0; i--) {
	    Calendar cal = Calendar.getInstance();
	    cal.setTime(data);
	    cal.set(Calendar.MONTH, cal.get(Calendar.MONTH) - i);
	    Date novaData = cal.getTime();
	    SimpleDateFormat formato = new SimpleDateFormat("MMMMM yyyy", new Locale("pt", "BR"));

	    mesesEano.add(formato.format(novaData));
	}

	return mesesEano;
    }

    /**
     * <p>
     * Método responsável por somar mes e retornar no formato (MMM yyyy)
     * <p>
     * 
     * @param Date
     * 
     * @return <code>List String</code>
     */
    private List<String> somaMesGrafico(Date data) {
	this.mesesEanoGrafico = new ArrayList<>();
	for (int i = 5; i >= 0; i--) {
	    Calendar cal = Calendar.getInstance();
	    cal.setTime(data);
	    cal.set(Calendar.MONTH, cal.get(Calendar.MONTH) - i);
	    Date novaData = cal.getTime();
	    SimpleDateFormat formato = new SimpleDateFormat("MMM yyyy", new Locale("pt", "BR"));

	    mesesEanoGrafico.add(formato.format(novaData));
	}

	return mesesEanoGrafico;
    }

    /**
     * <p>
     * Método responsável por Abre a pagina de relatório de analise carteira.
     * <p>
     *
     * @param contrato
     *            valor a ser atribuído
     * @return <code>String</code>
     * @author Brunno
     */
    public void carregarDadosRelHabitacao(final Contrato contrato) {
	
	if (contrato.getEmpreendimento() != null) {
	    final Long nuEmpreendimento = contrato.getEmpreendimento().getNuEmpreendimento();
	    getVisao().setValorTotalPrevisto(empreendimentoService.valorAReceber(nuEmpreendimento));
	    getVisao().setValorTotalRealizado(empreendimentoService.valorRecebido(nuEmpreendimento));
	    getVisao().setDiferencaAcumulada(getVisao().getValorTotalRealizado().subtract(getVisao().getValorTotalPrevisto()));
	    getVisao().setTitulosHabitacionais(tituloService.habitacionais(nuEmpreendimento));
	}

	getVisao().setContratoSelecionado(contrato);
	
	AnaliseContrato analiseContrato = contrato.getNuUltimaAnaliseContrato();
	getVisao().setListaGarantiaContratoDuplicata(getService().listarGarantiaContratoDuplicata(contrato, null));

        if (getService().isNecessarioRealizarNovaAnalise(analiseContrato)) {
        	getService().realizarCalculoAnaliseContrato(contrato.converterParaContratoCalculoTO(), false, UsuarioUtil.getUsuarioLogado().getDeMatricula());
            analiseContrato = getService().obterUltimaAnaliseContrato(contrato.getNuContrato());
        }
        getVisao().setEntidade(analiseContrato);
        Collections.sort(new ArrayList<AnaliseParecer>(getVisao().getEntidade().getAnaliseParecerList()), new DescricaoGrupoGarantiaComparator());
    }

    /**
     * 
     * <p>
     * Método responsável por gerarRelatorioTitulosNaoVencidos
     * </p>
     * .
     *
     * @author p566506
     *
     * @param contrato
     */
    public void gerarRelatorioTitulosNaoVencidos(final ContratoParametrizadoVO contratoParametrizadoVO) {
	Contrato contrato = new Contrato();
	contrato.setNuContrato(contratoParametrizadoVO.getNuContrato());
	contrato = this.contratoService.obterContratoComRelacionamentosInicializados(contrato.getNuContrato());
	Collection<UnidadeHabitacional> listaUnidades = this.uhService.listarUnidadesHabitacionais(contrato.getEmpreendimento());
	List<RelatorioProspectoSemTitulosVO> dadosRelatorio = new ArrayList<>();
	List<RelatorioProspectoComTitulosVO> dadosRelatorioComTitulo = new ArrayList<>();

	RelatorioProspectoComTitulosVO prospectoComTitulos = null;
	RelatorioProspectoSemTitulosVO prospectoSemTitulos = null;
	for (UnidadeHabitacional unidade : listaUnidades) {
	    // Busca Prospectos Sem Titulos vinculados ao sacado
	    prospectoSemTitulos = prospectoService.vrProspectoSemTitulo(unidade, new Date(), addDiasDataCorrente(30));
	    RelatorioProspectoSemTitulosVO vrProspecto2 = prospectoService.vrProspectoSemTitulo(unidade, addDiasDataCorrente(30),
		    addDiasDataCorrente(60));

	    // Busca Prospectos Com Titulos vinculados ao sacado
	    prospectoComTitulos = prospectoService.vrProspectoComTitulo(unidade, new Date(), addDiasDataCorrente(30));
	    RelatorioProspectoComTitulosVO prospectoComTitulosMes2 = prospectoService.vrProspectoComTitulo(unidade, addDiasDataCorrente(30),
		    addDiasDataCorrente(60));

	    if (prospectoSemTitulos != null) {
		if (vrProspecto2 != null) {
		    prospectoSemTitulos.setVrProspectoMes2(vrProspecto2.getVrProspectoMes1());
		}
		dadosRelatorio.add(prospectoSemTitulos);
	    }
	    if (prospectoComTitulos != null) {
		if (prospectoComTitulosMes2 != null) {
		    prospectoComTitulos.setVrProspectoMes2(prospectoComTitulosMes2.getVrProspectoMes1());
		    prospectoComTitulos.setVrTituloMes2(prospectoComTitulosMes2.getVrTituloMes1());
		}

		BigDecimal diferencaProspTituloMes1 = valorNotNull(prospectoComTitulos.getVrProspectoMes1())
			.subtract(valorNotNull(prospectoComTitulos.getVrTituloMes1()));
		prospectoComTitulos.setDiferencaProspTituloMes1(diferencaProspTituloMes1);
		BigDecimal diferencaProspTituloMes2 = valorNotNull(prospectoComTitulos.getVrProspectoMes2())
			.subtract(valorNotNull(prospectoComTitulos.getVrTituloMes2()));
		prospectoComTitulos.setDiferencaProspTituloMes2(diferencaProspTituloMes2);

		BigDecimal totalVrProspecto = valorNotNull(prospectoComTitulos.getVrProspectoMes1())
			.add(valorNotNull(prospectoComTitulos.getVrProspectoMes2()));
		prospectoComTitulos.setTotalVrProspecto(totalVrProspecto);

		BigDecimal totalVrBoletos = valorNotNull(prospectoComTitulos.getVrTituloMes1())
			.add(valorNotNull(prospectoComTitulos.getVrTituloMes2()));
		prospectoComTitulos.setTotalVrBoletos(totalVrBoletos);

		BigDecimal totalVrDiferenca = valorNotNull(prospectoComTitulos.getDiferencaProspTituloMes1())
			.add(valorNotNull(prospectoComTitulos.getDiferencaProspTituloMes2()));
		prospectoComTitulos.setTotalVrDiferenca(totalVrDiferenca);

		dadosRelatorioComTitulo.add(prospectoComTitulos);
	    }
	}

	List<TitulosSemComercializacaoVO> listTitulosSemComercializacao = prospectoService.titulosSemComercializacao(contrato.getEmpreendimento(),
		new Date(), addDiasDataCorrente(30));

	if (!dadosRelatorio.isEmpty() || !dadosRelatorioComTitulo.isEmpty() || !listTitulosSemComercializacao.isEmpty()) {
	    exportarRelatorio(dadosRelatorio, dadosRelatorioComTitulo, listTitulosSemComercializacao);
	} else {
	    this.adicionaMensagemDeAlerta("Empreendimento não possui Prospectos");
	}
    }

    /**
     * 
     * <p>
     * Método responsável por Tratar valor BigDecimal
     * </p>
     * .
     *
     * @author p566506
     *
     * @param valor
     * @return BigDecimal
     */
    private BigDecimal valorNotNull(BigDecimal valor) {
	if (valor == null) {
	    valor = BigDecimal.ZERO;
	}
	return valor;
    }

    /**
     * 
     * <p>
     * Método responsável por exportarRelatorio Excel
     * </p>
     * .
     *
     * @author p566506
     *
     * @param dadosProspectoSemTitulos
     */
    private void exportarRelatorio(List<RelatorioProspectoSemTitulosVO> dadosProspectoSemTitulos,
	    List<RelatorioProspectoComTitulosVO> dadosRelatorioComTitulo, List<TitulosSemComercializacaoVO> dadosTitulosSemComercializacao) {
	final JRBeanCollectionDataSource bCSourceSemTitulo = new JRBeanCollectionDataSource(dadosProspectoSemTitulos);
	final JRBeanCollectionDataSource bCSourceComTitulo = new JRBeanCollectionDataSource(dadosRelatorioComTitulo);
	final JRBeanCollectionDataSource bCSourceTituloSemComercializacao = new JRBeanCollectionDataSource(dadosTitulosSemComercializacao);
	Map<String, Object> map = new HashMap<>();
	ArrayList<JasperPrint> listaRelatorios = new ArrayList<>();
	String pathJasperProspectoSemtitulos = RelatorioAnaliseMB.CAMINHO_REL_PROSP_SEMTITULO;
	String pathJasperProspectoComtitulos = RelatorioAnaliseMB.CAMINHO_REL_PROSP_COMTITULO;
	String pathJasperTitulosSemComercializacao = RelatorioAnaliseMB.CAMINHO_REL_TITULOS_SEM_COMERC;

	try {
	    JasperPrint jpProspectoSemtitulos = JasperFillManager.fillReport(getClass().getResourceAsStream(pathJasperProspectoSemtitulos), map,
		    bCSourceSemTitulo);
	    JasperPrint jpProspectoComtitulos = JasperFillManager.fillReport(getClass().getResourceAsStream(pathJasperProspectoComtitulos), map,
		    bCSourceComTitulo);
	    JasperPrint jpTitulosSemComercializacao = JasperFillManager
		    .fillReport(getClass().getResourceAsStream(pathJasperTitulosSemComercializacao), map, bCSourceTituloSemComercializacao);
	    listaRelatorios.add(jpProspectoSemtitulos);
	    listaRelatorios.add(jpProspectoComtitulos);
	    listaRelatorios.add(jpTitulosSemComercializacao);

	    UtilRelatorio.getInstancia().addExtensaoArquivo(EnumExtensaoArquivo.XLS).addNomeRelatorio("Relatório Concilização")
		    .addResposta(super.getResponse()).gerarRelatorioLista(listaRelatorios, EnumExtensaoArquivo.XLS);
	} catch (Exception e) {
	    LogCEF.debug(e);
	    RelatorioAnaliseMB.LOG.fine(e.getMessage());
	}

    }

    /**
     * 
     * <p>
     * Método responsável por addDiasDataCorrente
     * </p>
     * .
     *
     * @author p566506
     *
     * @param dias
     * @return
     */
    private Date addDiasDataCorrente(int dias) {
	Date dataCorrente = new Date();
	Calendar c = Calendar.getInstance();
	c.setTime(dataCorrente);
	c.add(Calendar.DATE, +dias);

	return c.getTime();
    }

    /**
     * <p>
     * Método responsável por Abrir o dialog de valor a receber por unidade.
     * <p>
     * 
     * @author Brunno
     */
    public void setValorAReceberPorUH() {
	final RelatorioAnaliseVisao visao = this.getVisao();
	visao.setListVlPrevistoPorUH(
		this.empreendimentoService.valorAReceberPorUH(visao.getContratoSelecionado().getEmpreendimento().getNuEmpreendimento()));

    }

    /**
     * <p>
     * Método responsável por abrir dialog valor realizado por uh.
     * <p>
     * 
     * @author Brunno
     */
    public void setValorRealizadoPorUh() {
	final RelatorioAnaliseVisao visao = this.getVisao();
	visao.setListVlRealizadoPorUH(
		this.empreendimentoService.valorRealizadoPorUH(visao.getContratoSelecionado().getEmpreendimento().getNuEmpreendimento()));
    }

    /**
     * <p>
     * Método responsável por abrir dialog de diferenca acumulada por uh.
     * <p>
     * 
     * @author Brunno
     */
    public void setValorDiferencaAcumuladaPorUH() {
	final RelatorioAnaliseVisao visao = this.getVisao();
	visao.setListDiferencaAcumuladaPorUH(
		this.empreendimentoService.valorDiferencaAcumuladaPorUH(visao.getContratoSelecionado().getEmpreendimento().getNuEmpreendimento()));
    }

    /**
     * Processa o resultado da analise para mostrar resultado na tela.
     *
     * @author Ricardo Crispim
     */
    private void processarResultadoAnalise() {
	final RelatorioAnaliseVisao visao = this.getVisao();
	final AnaliseContrato analiseContrato = visao.getEntidade();
	analiseContrato.setNuContrato(this.getVisao().getContratoSelecionado());
	
	visao.setValorResultadoParecer(analiseContrato.getVrDiferencaParcial());
	visao.setValorResultadoParecerTotal(analiseContrato.getVrDiferencaParcial().add(analiseContrato.getVrContaNLM()));
	visao.setResultadoParecer(analiseContrato.getResultadoParecer());
	visao.consultarMaiorInadimplencia();
	visao.setResultadoParecerTotal(analiseContrato.getResultadoParecerTotal());
	visao.setCorParecer(analiseContrato.getCorSaldoParcial());
	visao.setCorParecerTotal(analiseContrato.getCorSaldoTotal());
	visao.setSaldoTotalContaCorrenteNLM(this.getVisao().getContratoSelecionado().getVrSaldoCcNaoLivre());
    }

    /**
     * <p>
     * Método responsável por carregar a lista de duplicatas do sacado.
     * <p>
     *
     * @param totalizadorMaiorSacado
     *            valor a ser atribuído
     * @return <code>void</code>
     * @author Waltenes Junior
     */
    public String carregarDuplicatasSacado(final TotalizadorMaiorSacado totalizadorMaiorSacado) {
	final RelatorioAnaliseVisao visao = this.getVisao();
	visao.setTotalizadorMaiorSacadoSelecionado(totalizadorMaiorSacado);
	visao.setListaDuplicatasSacado(this.service.listarDuplicatasPorNumeroSacado(
		totalizadorMaiorSacado.getTotalizadorMaiorSacadoPK().getNuSacado(), visao.isMostrarDuplicatasSacadoValidas(),
		this.getGarantiaContrato(visao.getListaGarantiaContratoDuplicata(), CaracteristicaEnum.ESTOQUE),
		visao.getContratoSelecionado().getNuPessoa()));
	visao.setExibirDialogDuplicatasSacado(Boolean.TRUE);
	return super.MESMA_TELA;
    }

    /**
     * <p>
     * Método responsável por atualizar grid de duplicatas do dez maiores
     * sacados.
     * <p>
     *
     * @author Waltenes Junior
     */
    public void atualizarGridMaiorSacado() {
	final RelatorioAnaliseVisao visao = this.getVisao();

	final Collection<Titulo> listTitulos = this.tituloService.atualizarGridDuplicatas(this.service.listarDuplicatasPorNumeroSacado(
		visao.getTotalizadorMaiorSacadoSelecionado().getTotalizadorMaiorSacadoPK().getNuSacado(), visao.isMostrarDuplicatasSacadoValidas(),
		this.getGarantiaContrato(visao.getListaGarantiaContratoDuplicata(), CaracteristicaEnum.ESTOQUE),
		visao.getContratoSelecionado().getNuPessoa()), visao.getDuplicataInadimplenteVO());

	visao.setListaDuplicatasSacado(listTitulos);
    }

    /**
     * <p>
     * Método responsável por carregar duplicatas validas ou não do sacado
     * passado por parâmetro.
     * <p>
     *
     * @author Waltenes Junior
     */
    public void carregarDuplicatasValidasSacado() {
	final RelatorioAnaliseVisao visao = this.getVisao();
	visao.setListaDuplicatasSacado(this.service.listarDuplicatasPorNumeroSacado(
		visao.getTotalizadorMaiorSacadoSelecionado().getTotalizadorMaiorSacadoPK().getNuSacado(), visao.isMostrarDuplicatasSacadoValidas(),
		this.getGarantiaContrato(visao.getListaGarantiaContratoDuplicata(), CaracteristicaEnum.ESTOQUE),
		visao.getContratoSelecionado().getNuPessoa()));
    }

    /**
     * <p>
     * Método responsável por atribuir valor a garantia de duplicata do contrato
     * quando na lista contiver uma com o tipo de caracteristica ESTOQUE.
     * <p>
     *
     * @param listaGarantiaContrato
     *            valor a ser atribuído
     * @param caracteristicaDuplicata
     *            valor a ser atribuído
     * @return GarantiaContrato
     * @author Waltenes Junior
     */
    private GarantiaContrato getGarantiaContrato(final Collection<GarantiaContrato> listaGarantiaContrato,
	    final CaracteristicaEnum caracteristicaDuplicata) {
	GarantiaContrato garantiaContratoRetorno = new GarantiaContrato();
	for (final GarantiaContrato garantiaContrato : listaGarantiaContrato) {
	    if (garantiaContrato.isGarantiaDuplicata() && caracteristicaDuplicata.equals(garantiaContrato.getIcCaracteristica())) {
		garantiaContratoRetorno = garantiaContrato;
	    }
	}
	return garantiaContratoRetorno;
    }

    /**
     * <p>
     * Método responsável por abrir a tela com os detalhes dos cheques em
     * carteira.
     * <p>
     *
     * @return String
     * @author Caio Graco
     */
    public String abrirDetalheCheques() {
	this.getDetalheChequeMB().getVisao().setPaginaOrigem(RelatorioAnaliseMB.PAGINA_RELATORIO_ANALISE);

	this.getDetalheChequeMB().getVisao().setPessoaVO(this.atribuirValoresPessoa());
	this.getDetalheChequeMB().getVisao().setContrato(this.getVisao().getContratoSelecionado());

	return this.getDetalheChequeMB().abrirDetalheCheques();
    }

    /**
     * <p>
     * Método responsável por abrir o detalhe das duplicatas estoque.
     * <p>
     *
     * @return String
     * @author Caio Graco
     */
    public String abrirDetalheDuplicatasEstoque() {
	return this.abrirDetalheDuplicatas(CaracteristicaEnum.ESTOQUE);
    }

    /**
     * <p>
     * Método responsável por abrir o detalhe das duplicatas fluxo.
     * <p>
     *
     * @return String
     * @author Caio Graco
     */
    public String abrirDetalheDuplicatasFluxo() {
	return this.abrirDetalheDuplicatas(CaracteristicaEnum.FLUXO);
    }

    /**
     * <p>
     * Abre a tela de detalhe de duplicatas.
     * <p>
     *
     * @param caracteristica
     *            valor a ser atribuído
     * @return String
     * @author Ricardo Crispim
     */
    public String abrirDetalheDuplicatas(final CaracteristicaEnum caracteristica) {
	final DetalheDuplicatasVisao visao = new DetalheDuplicatasVisao();
	visao.setPaginaOrigem(RelatorioAnaliseMB.PAGINA_RELATORIO_ANALISE);
	visao.setValorBreadcrumb("Relatório Análise Carteira");
	visao.setMostrarDuplicatasValidas(Boolean.FALSE);

	visao.setPessoaVO(this.atribuirValoresPessoa());

	final GarantiaContrato garantia = this.getGarantiaContrato(this.getVisao().getListaGarantiaContratoDuplicata(), caracteristica);
	visao.setCedentesSelecionados(garantia.getCedenteList());
	visao.setValorMaximo(garantia.getVrMaximoPermitido());
	visao.setPrazoMaximo(garantia.getVrPrazoMaximoPermitido() == null ? 0 : garantia.getVrPrazoMaximoPermitido().intValue());
	visao.setConcentracaoMaximaValor(garantia.getVrPercentualMaximoCncno());
	visao.setIcInstrucaoProtesto(garantia.getInstrucaoProtesto());
	visao.setValorEsperado(this.getService().calcularValorEsperado(garantia));
	visao.setNuContrato(garantia.getNuContrato().getNuContrato());
	this.getDetalheDuplicatasMB().setVisao(visao);

	return this.getDetalheDuplicatasMB().abrirDetalheDuplicatas();
    }

    /**
     * <p>
     * Método responsável por abrir o detalhe das duplicatas quando o tipo do
     * contrato for habitacional
     * </p>
     * .
     *
     * @author f503697
     *
     * @return página de detalhe de duplicatas
     */
    public String abrirDetalheDuplicatasHabitacional() {
	final DetalheDuplicatasVisao visao = new DetalheDuplicatasVisao();
	visao.setPaginaOrigem(RelatorioAnaliseMB.PAGINA_RELATORIO_ANALISE_HABITACAO);
	visao.setValorBreadcrumb("Relatório de Análise de Carteira");
	visao.setMostrarDuplicatasValidas(Boolean.FALSE);
	visao.setNuEmpreendimento(getVisao().getContratoSelecionado().getEmpreendimento().getNuEmpreendimento());
	visao.setPessoaVO(this.atribuirValoresPessoa());

	getDetalheDuplicatasMB().setVisao(visao);
	getDetalheDuplicatasMB().getVisao().setLista(getVisao().getTitulosHabitacionais());

	return "/pages/analise/detalheDuplicatasHabitacional.xhtml?faces-redirect=true";
    }

    /**
     * <p>
     * Método responsável por atribuir os valores da pessoa que aparecerá no
     * cabeçalho.
     * <p>
     *
     * @return PessoaVO
     * @author Caio Graco
     */
    private PessoaVO atribuirValoresPessoa() {
	final NumberFormat formatarValorMoeda = NumberFormat.getCurrencyInstance();
	formatarValorMoeda.setMaximumFractionDigits(2);

	final PessoaVO vo = new PessoaVO();
	final Pessoa pessoa = this.getVisao().getContratoSelecionado().getNuPessoa();

	vo.setPessoa(pessoa.getCnpjFormatado().concat(pessoa.getNoPessoa() == null ? RelatorioAnaliseMB.VAZIO : " - " + pessoa.getNoPessoa()));
	vo.setContrato(this.getVisao().getContratoSelecionado().getCoContrato());
	vo.setVrContrato(formatarValorMoeda.format(this.getVisao().getContratoSelecionado().getVrContrato()));
	vo.setSaldoDevedor(formatarValorMoeda.format(this.getVisao().getContratoSelecionado().getVrSaldoDevedor()));

	return vo;
    }

    /**
     * <p>
     * Método responsável por abrir o pdf do relatório.
     * <p>
     *
     * @param analiseContrato
     *            valor a ser atribuído
     * @author Ricardo Crispim
     */
    public void abrirPdfAnaliseContrato(final AnaliseContrato analiseContrato) {
	try {

	    if (analiseContrato.getImAnaliseContrato() == null) {
		this.adicionaMensagemDeErro(MensagensUtil.getMensagem("msgApp", "uc_relatorio_analise_carteira_erro_abrir_pdf"));
	    } else {
		final byte[] bytes = analiseContrato.getImAnaliseContrato();

		final String nomeArquivo = "Analise_Contrato_N_" + analiseContrato.getNuAnaliseContrato() + EnumExtensaoArquivo.PDF.getExtensao();

		this.imprimirPdf(bytes, nomeArquivo);
	    }
	} catch (final IOException | IllegalStateException e) {
	    RelatorioAnaliseMB.LOG.fine(e.getMessage());
	    RelatorioAnaliseMB.LOG.fine("Erro ao gerar pdf da AnaliseContrato.");
	    LogCefUtil.error(e);
	}
    }

    /**
     * <p>
     * Método responsável por imprimir um pdf de acordo com o
     * <code>byte[]</code> passado por parâmetro.
     * <p>
     *
     * @param bytes
     *            valor a ser atribuído
     * @param nomeArquivo
     *            valor a ser atribuído
     * @throws IOException
     *             valor a ser atribuído
     * @author Waltenes Junior
     */
    private void imprimirPdf(final byte[] bytes, final String nomeArquivo) throws IOException {
	try {
	    this.getResponse().addHeader("Content-disposition", "attachment; filename=" + nomeArquivo);
	    this.getResponse().setContentType(EnumExtensaoArquivo.PDF.getContentType());
	    this.getResponse().setContentLength(bytes.length);

	    final ServletOutputStream saida = this.getResponse().getOutputStream();

	    saida.write(bytes, 0, bytes.length);
	    saida.flush();
	    saida.close();
	    FacesContext.getCurrentInstance().responseComplete();
	} catch (Exception e) {
	    LogCefUtil.error(e);
	}
    }

    /**
     * <p>
     * Método responsável por verificar se o Cliente possui saldo disponível
     * (maior que zero) na carteira;
     * </p>
     * 
     * @return se o cliente possui saldo na carteira.
     */
    public boolean isClientePossuiSaldoCarteira() {
	return !NumeroUtil.isNuloOuZero(getVisao().getContratoSelecionado().getNuPessoa().getNuSaldo().getVrDuplicataEstoque())
		|| !NumeroUtil.isNuloOuZero(getVisao().getContratoSelecionado().getNuPessoa().getNuSaldo().getVrDuplicataFluxo())
		|| !NumeroUtil.isNuloOuZero(getVisao().getContratoSelecionado().getNuPessoa().getNuSaldo().getVrAplicacaoEstoque())
		|| !NumeroUtil.isNuloOuZero(getVisao().getContratoSelecionado().getNuPessoa().getNuSaldo().getVrChequeEstoque())
		|| !NumeroUtil.isNuloOuZero(getVisao().getContratoSelecionado().getNuPessoa().getNuSaldo().getVrContaNLM());

    }

    /**
     * @see br.gov.caixa.pedesgo.arquitetura.controlador.AbstractBean#getService()
     */
    @SuppressWarnings("unchecked")
    @Override
    public RelatorioAnaliseService getService() {
	return this.service;
    }

    /**
     * @see br.gov.caixa.pedesgo.arquitetura.controlador.AbstractBean#getVisao()
     */
    @Override
    public RelatorioAnaliseVisao getVisao() {
	if (this.visao == null) {
	    this.visao = new RelatorioAnaliseVisao();
	}
	return this.visao;
    }

    /**
     * Define o valor do atributo RelatorioAnaliseVisao.
     *
     * @param visao
     *            valor a ser atribuído
     */
    public void setVisao(final RelatorioAnaliseVisao visao) {
	this.visao = visao;
    }

    /**
     * Retorna o valor do atributo tituloService.
     *
     * @return tituloService
     */
    public TituloService getTituloService() {

	return this.tituloService;
    }

    /**
     * @see br.gov.caixa.pedesgo.arquitetura.controlador.AbstractBean#getNomeVarResourceBundle()
     */
    @Override
    protected String getNomeVarResourceBundle() {
	return null;
    }

    /**
     * @see br.gov.caixa.pedesgo.arquitetura.controlador.AbstractBean#getPrefixoCasoDeUso()
     */
    @Override
    protected String getPrefixoCasoDeUso() {
	return null;
    }

    /**
     * Retorna o valor do atributo parametrizacaoContratoMB.
     *
     * @return parametrizacaoContratoMB
     */
    public ParametrizacaoContratoMB getParametrizacaoContratoMB() {

	return this.parametrizacaoContratoMB;
    }

    /**
     * Define o valor do atributo parametrizacaoContratoMB.
     *
     * @param parametrizacaoContratoMB
     *            valor a ser atribuído
     */
    public void setParametrizacaoContratoMB(final ParametrizacaoContratoMB parametrizacaoContratoMB) {

	this.parametrizacaoContratoMB = parametrizacaoContratoMB;
    }

    /**
     * Retorna o valor do atributo detalheDuplicatasMB.
     *
     * @return detalheDuplicatasMB
     */
    public DetalheDuplicatasMB getDetalheDuplicatasMB() {

	return this.detalheDuplicatasMB;

    }

    /**
     * Define o valor do atributo detalheDuplicatasMB.
     *
     * @param detalheDuplicatasMB
     *            valor a ser atribuído
     */
    public void setDetalheDuplicatasMB(final DetalheDuplicatasMB detalheDuplicatasMB) {

	this.detalheDuplicatasMB = detalheDuplicatasMB;

    }

    /**
     * <p>
     * Método responsável por verificar permissões do usuario logado.
     * <p>
     *
     * @author guilherme.santos
     */
    private void verificarPermissoes() {
	// Controle de permissões da funcionalidade Detalhar Analise Garantia
	this.getVisao().setExibirBotaoDetalharAnaliseGarantia(
		UsuarioUtil.contemPermissao(NoFuncionalidadeEnum.ANALISE_GARANTIA.getNoFuncionalidade(), EnumAcao.CONSULTAR.getNoAcao(), null, null));
	// Controle de permissões da funcionalidade Detalhar Total das
	// Duplicatas em Carteira
	this.getVisao().setExibirLupaTotalDuplicataCarteira(UsuarioUtil.contemPermissao(
		NoFuncionalidadeEnum.ANALISE_GARANTIA_DETALHES_TOTAL_DUPLICATAS.getNoFuncionalidade(), EnumAcao.CONSULTAR.getNoAcao(), null, null));
    }

    /**
     * Retorna o valor do atributo detalheChequeMB.
     *
     * @return detalheChequeMB
     */
    public DetalheChequeMB getDetalheChequeMB() {

	return this.detalheChequeMB;
    }

    /**
     * Define o valor do atributo detalheChequeMB.
     *
     * @param detalheChequeMB
     *            valor a ser atribuído
     */
    public void setDetalheChequeMB(final DetalheChequeMB detalheChequeMB) {

	this.detalheChequeMB = detalheChequeMB;
    }

    /**
     * <p>
     * Método responsável por carregar o atributo imagemSinalizadorLiquidez da
     * visão.
     * <p>
     *
     * @author gerusa.soares
     */
    public void getImagemSinalizadorLiquidez() {

	final Double percentual = this.getVisao().getAnaliseContrato().getPercentualIndiceLiquidez();

	if (percentual != null) {

	    final SinalizadorLiquidez sinalizador = this.sinalizadorService.getSinalizadorLiquidezByPercentual(new BigDecimal(percentual.toString()));

	    if (sinalizador != null) {
		final String nome = sinalizador.getNoArquivoImagem();

		final StreamedContent streamedContent = new DefaultStreamedContent(new ByteArrayInputStream(sinalizador.getImSinalizadorLiquidez()),
			"", nome);

		this.getVisao().setImagemIndiceLiquidez(streamedContent);

		this.getVisao().setNomeIndiceLiquidez(sinalizador.getNoSinalizadorLiquidez());

		this.getVisao().setDescricaoIndiceLiquidez(sinalizador.getDeSinalizadorLiquidez());
	    }

	}

    }

    /**
     * <p>
     * Retorna o valor do atributo mesesEano
     * </p>
     * .
     *
     * @return mesesEano
     */
    public List<String> getMesesEano() {
	return this.mesesEano;
    }

    /**
     * <p>
     * Define o valor do atributo mesesEano
     * </p>
     * .
     *
     * @param mesesEano
     *            valor a ser atribuído
     */
    public void setMesesEano(List<String> mesesEano) {
	this.mesesEano = mesesEano;
    }

    /**
     * <p>
     * Retorna o valor do atributo mesesEanoGrafico
     * </p>
     * .
     *
     * @return mesesEanoGrafico
     */
    public List<String> getMesesEanoGrafico() {
	return this.mesesEanoGrafico;
    }

    /**
     * <p>
     * Define o valor do atributo mesesEanoGrafico
     * </p>
     * .
     *
     * @param mesesEanoGrafico
     *            valor a ser atribuído
     */
    public void setMesesEanoGrafico(List<String> mesesEanoGrafico) {
	this.mesesEanoGrafico = mesesEanoGrafico;
    }

    /**
     * <p>
     * Retorna o valor do atributo relatorioHipersuficienciaVO
     * </p>
     * .
     *
     * @return relatorioHipersuficienciaVO
     * 
     * @author narcieliton.lopes
     * @dataCriacao: 2019-10-10 yyyy-MM-dd
     */
    public RelatorioHipersuficienciaVO getRelatorioHipersuficienciaVO() {
	return relatorioHipersuficienciaVO;
    }

    /**
     * <p>
     * Define o valor do atributo relatorioHipersuficienciaVO
     * </p>
     * .
     *
     * @param relatorioHipersuficienciaVO
     *            valor a ser relatorioHipersuficienciaVO
     * @author narcieliton.lopes
     * @dataCriacao: 2019-10-10 yyyy-MM-dd
     */
    public void setRelatorioHipersuficienciaVO(RelatorioHipersuficienciaVO relatorioHipersuficienciaVO) {
	this.relatorioHipersuficienciaVO = relatorioHipersuficienciaVO;
    }

    /**
     * <p>
     * Converte o objeto contratoParametrizadoVO selecionado na tela para o
     * objeto relatorioHipersuficienciaVO. consulta dados da hipersuficiencia.
     * chama o metodo para carregar detalhe da hipersuficiencia.
     * 
     * </p>
     * .
     *
     * @param relatorioHipersuficienciaVO
     *            valor a ser relatorioHipersuficienciaVO
     * @author narcieliton.lopes
     * @dataCriacao: 2019-10-10 yyyy-MM-dd
     */
    public void consultarHiperSuficiencia(final ContratoParametrizadoVO contratoParametrizadoVO) {
	this.relatorioHipersuficienciaVO = new RelatorioHipersuficienciaVO();
	this.relatorioHipersuficienciaVO.converterObjetos(contratoParametrizadoVO);
	final RelatorioAnaliseVisao visao = this.getVisao();
	final RelatorioAnaliseService servico = this.getService();

	Contrato contrato = new Contrato();
	contrato.setNuContrato(contratoParametrizadoVO.getNuContrato());
	contrato = this.contratoService.obterContratoComRelacionamentosInicializados(contrato.getNuContrato());
	visao.setContratoSelecionado(contrato);
	this.getVisao().setContratosSelecionados(this.service.listarOutrosContratosParametrizadosDaPessoa(contrato));
	visao.setListaGarantiaContratoDuplicata(servico.listarGarantiaContratoDuplicata(contrato, null));

	this.abrirDetalheDuplicatasHipersuficiente();
    }

    /**
     * <p>
     * consulta os detalhes da hipersuficiencia para mostrar na grid.
     * </p>
     * .
     *
     * @param relatorioHipersuficienciaVO
     *            valor a ser relatorioHipersuficienciaVO
     * @author narcieliton.lopes
     * @dataCriacao: 2019-10-10 yyyy-MM-dd
     */
    public void abrirDetalheDuplicatasHipersuficiente() {
	final DetalheDuplicatasVisao visao = new DetalheDuplicatasVisao();
	visao.setPessoaVO(this.atribuirValoresPessoa());
	final GarantiaContrato garantia = this.getGarantiaContrato(this.getVisao().getListaGarantiaContratoDuplicata(), CaracteristicaEnum.ESTOQUE);

	if (!garantia.getCedenteList().isEmpty() && garantia.getInstrucaoProtesto() != null && garantia.getNuContrato() != null) {

	    visao.setCedentesSelecionados(garantia.getCedenteList());
	    visao.setIcInstrucaoProtesto(garantia.getInstrucaoProtesto());
	    visao.setNuContrato(garantia.getNuContrato().getNuContrato());
	    this.getDetalheDuplicatasMB().setVisao(visao);
	    this.getDetalheDuplicatasMB().abrirDetalheDuplicatasHipersuficiente();
	}
    }
}
