/*
 * Copyright (c) 2018 Caixa Econômica Federal. Todos os direitos
 * reservados.
 *
 * Caixa Econômica Federal - SIACG - Sistema de Crédito Rural
 *
 * Este software foi desenvolvido sob demanda da CAIXA e está
 * protegido por leis de direitos autorais e tratados internacionais. As
 * condições de cópia e utilização do todo ou partes dependem de autorização da
 * empresa. Cópias não são permitidas sem expressa autorização. Não pode ser
 * comercializado ou utilizado para propósitos particulares.
 *
 * Uso exclusivo da Caixa Econômica Federal. A reprodução ou distribuição não
 * autorizada deste programa ou de parte dele, resultará em punições civis e
 * criminais e os infratores incorrem em sanções previstas na legislação em
 * vigor.
 *
 * Histórico do TFS:
 *
 * LastChangedRevision: $Revision$
 * LastChangedBy: $Author$
 * LastChangedDate: $Date$
 *
 * HeadURL: $HeadURL$
 *
 */
package br.gov.caixa.siacg.view.form;

import java.util.ArrayList;
import java.util.List;

import br.gov.caixa.pedesgo.arquitetura.visao.ManutencaoVisao;
import br.gov.caixa.siacg.model.domain.AplicacaoFinanceira;
import br.gov.caixa.siacg.model.vo.AplicacaoFinanceiraVO;

/**
 * <p>
 * AplicacaoFinanceiraVisao
 * </p>
 *
 * <p>
 * Descrição: Descrição do tipo
 * </p>
 *
 * <br>
 * <b>Empresa:</b> Cef - Caixa Econômica Federal
 *
 * 
 * 
 * @author Winston
 *
 * @version 1.0
 */
public class AplicacaoFinanceiraVisao extends ManutencaoVisao<AplicacaoFinanceira> {

    /** Atributo serialVersionUID. */
    private static final long serialVersionUID = 1L;

    /** Atributo serialVersionUID. */
    

    /** Atributo filtro. */
    private transient AplicacaoFinanceiraVO filtro;

    /** Atibuto de AplicacaoFinanceira */
    private AplicacaoFinanceira aplicacaoFinanceira;

    /* Atributo listaAplicacao Financeira */
    private transient List<AplicacaoFinanceiraVO> listaAplicacaoFinanceira;
    
    private transient List<AplicacaoFinanceiraVO> listaDadosdasContas; 

    private Integer qtdItens; 

    /**
     * <p>
     * Retorna o valor do atributo listaAplicacaoFinanceira
     * </p>
     * .
     *
     * @return listaAplicacaoFinanceira
     */
    public List<AplicacaoFinanceiraVO> getListaAplicacaoFinanceira() {
	if (this.listaAplicacaoFinanceira == null) {
	    this.listaAplicacaoFinanceira = new ArrayList<>();
	}

	return this.listaAplicacaoFinanceira;
    }

    /**
     * <p>
     * Define o valor do atributo listaAplicacaoFinanceira
     * </p>
     * .
     *
     * @param listaAplicacaoFinanceira
     *            valor a ser atribuído
     */
    public void setListaAplicacaoFinanceira(List<AplicacaoFinanceiraVO> listaAplicacaoFinanceira) {
	this.listaAplicacaoFinanceira = listaAplicacaoFinanceira;
    }

    /**
     * <p>
     * Retorna o valor do atributo aplicacaoFinanceira
     * </p>
     * .
     *
     * @return aplicacaoFinanceira
     */
    public AplicacaoFinanceira getAplicacaoFinanceira() {
	if (this.aplicacaoFinanceira == null) {
	    this.aplicacaoFinanceira = new AplicacaoFinanceira();
	}
	return this.aplicacaoFinanceira;
    }

    /**
     * <p>
     * Define o valor do atributo aplicacaoFinanceira
     * </p>
     * .
     *
     * @param aplicacaoFinanceira
     *            valor a ser atribuído
     */
    public void setAplicacaoFinanceira(AplicacaoFinanceira aplicacaoFinanceira) {
	this.aplicacaoFinanceira = aplicacaoFinanceira;
    }

    /**
     * <p>
     * Retorna o valor do atributo filtro
     * </p>
     * .
     *
     * @return filtro
     */
    public AplicacaoFinanceiraVO getFiltro() {
	if(this.filtro == null) {
	    this.filtro = new AplicacaoFinanceiraVO();
	}
	return this.filtro;
    }

    /**
     * <p>
     * Define o valor do atributo filtro
     * </p>
     * .
     *
     * @param filtro
     *            valor a ser atribuído
     */
    public void setFiltro(AplicacaoFinanceiraVO filtro) {
	this.filtro = filtro;
    }

    /**
     * <p>Retorna o valor do atributo qtdItens</p>.
     *
     * @return qtdItens
    */
    public Integer getQtdItens() {
	this.qtdItens = 0;
	
	if (!this.getListaAplicacaoFinanceira().isEmpty()) {
		this.qtdItens = this.listaAplicacaoFinanceira.size();
	}
	return this.qtdItens;
    }

    /**
     * <p>Define o valor do atributo qtdItens</p>.
     *
     * @param qtdItens valor a ser atribuído
    */
    public void setQtdItens(Integer qtdItens) {
	this.qtdItens = qtdItens;
    }

    /**
     * <p>Retorna o valor do atributo listaDadosdasContas</p>.
     *
     * @return listaDadosdasContas
    */
    public List<AplicacaoFinanceiraVO> getListaDadosdasContas() {
	
	if(this.listaDadosdasContas == null){
	    this.listaDadosdasContas = new ArrayList<>();
	}
	return this.listaDadosdasContas;
    }

    /**
     * <p>Define o valor do atributo listaDadosdasContas</p>.
     *
     * @param aplicacaoFinanceiraVO valor a ser atribuído
    */
    public void setListaDadosdasContas(List<AplicacaoFinanceiraVO> aplicacaoFinanceiraVO) {
	this.listaDadosdasContas = aplicacaoFinanceiraVO;
	
    }

}
