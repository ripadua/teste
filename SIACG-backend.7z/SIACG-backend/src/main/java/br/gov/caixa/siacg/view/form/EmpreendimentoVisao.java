package br.gov.caixa.siacg.view.form;

import java.math.BigDecimal;
import java.util.List;

import br.gov.caixa.pedesgo.arquitetura.visao.ManutencaoVisao;
import br.gov.caixa.siacg.model.domain.Empreendimento;
import br.gov.caixa.siacg.model.vo.EmpreendimentoVO;

/**
 * <p>
 * LoginVisao
 * </p>
 * <p>
 * Descrição: Classe de visão do Empreendimento.
 * </p>
 * <br>
 * <b>Empresa:</b> Cef - Caixa Econômica Federal
 *
 * @author TO BRASIl
 */
public class EmpreendimentoVisao extends ManutencaoVisao<Empreendimento> {

	private static final long serialVersionUID = 1L;

	private List<EmpreendimentoVO> listaEmpreendimentoVO;
	
	private BigDecimal quantidadeHabitacional = BigDecimal.ZERO;
	
	private BigDecimal quantidadeHabitacionalParcial = BigDecimal.ZERO;
	
	/** Atributo autoCompleteFiltro. */
	private String autoCompleteFiltro;
	
	/** Atributo autoCompleteFiltro. */
	private Long nuEmpreendimento;

	public List<EmpreendimentoVO> getListaEmpreendimento() {
		return listaEmpreendimentoVO;
	}

	public void setListaEmpreendimentoVO(List<EmpreendimentoVO> listaEmpreendimentoVO) {
		this.listaEmpreendimentoVO = listaEmpreendimentoVO;
	}

	public BigDecimal getQuantidadeHabitacional() {
		return quantidadeHabitacional;
	}

	public void setQuantidadeHabitacional(BigDecimal quantidadeHabitacional) {
		this.quantidadeHabitacional = quantidadeHabitacional;
	}

	public BigDecimal getQuantidadeHabitacionalParcial() {
		return quantidadeHabitacionalParcial;
	}

	public void setQuantidadeHabitacionalParcial(BigDecimal quantidadeHabitacionalParcial) {
		this.quantidadeHabitacionalParcial = quantidadeHabitacionalParcial;
	}
	
	public String getAutoCompleteFiltro() {
	    return this.autoCompleteFiltro;
	}

	public void setAutoCompleteFiltro(String autoCompleteFiltro) {
	    this.autoCompleteFiltro = autoCompleteFiltro;
	}

	public Long getNuEmpreendimento() {
	    return this.nuEmpreendimento;
	}

	public void setNuEmpreendimento(Long nuEmpreendimento) {
	    this.nuEmpreendimento = nuEmpreendimento;
	}
}
