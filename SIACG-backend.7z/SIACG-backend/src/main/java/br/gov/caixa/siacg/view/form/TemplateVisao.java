package br.gov.caixa.siacg.view.form;

import java.util.Collection;
import java.util.Map;

import br.gov.caixa.pedesgo.arquitetura.entidade.Entidade;
import br.gov.caixa.pedesgo.arquitetura.enums.EnumExtensaoArquivo;
import br.gov.caixa.pedesgo.arquitetura.visao.ManutencaoVisao;

/**
 * <p>
 * TemplateVisao
 * </p>
 * <p>
 * Template responsável por abstrair os atributos comuns entre as visões. 
 * </p>
 *
 * <br>
 * <b>Empresa:</b> Cef - Caixa Econômica Federal
 *
 *
 * @author Alexandre Morais
 *
 * @version 1.0
 */
public class TemplateVisao<T extends Entidade> extends ManutencaoVisao<T> {

	private static final long serialVersionUID = 6755385518290029524L;

	private String nomeRelatorio;
	private String caminhoRelatorio;
	private transient Map<String, Object> mapaParametros;
	private EnumExtensaoArquivo tipoArquivo;
	private transient Collection<?> colecaoRelatorio;
	private String mensagemModal;
	private boolean exibirModal;
	private boolean exibirBotaoIncluir;
	private boolean exibirBotaoEditar;
	private boolean exibirBotaoExcluir;

	/**
	 * <p>
	 * Retorna o valor do atributo nomeRelatorio
	 * </p>
	 * .
	 *
	 * @return nomeRelatorio
	 */
	public String getNomeRelatorio() {
		return this.nomeRelatorio;
	}

	/**
	 * <p>
	 * Define o valor do atributo nomeRelatorio
	 * </p>
	 * .
	 *
	 * @param nomeRelatorio
	 *            valor a ser atribuído
	 */
	public void setNomeRelatorio(String nomeRelatorio) {
		this.nomeRelatorio = nomeRelatorio;
	}

	/**
	 * <p>
	 * Retorna o valor do atributo caminhoRelatorio
	 * </p>
	 * .
	 *
	 * @return caminhoRelatorio
	 */
	public String getCaminhoRelatorio() {
		return this.caminhoRelatorio;
	}

	/**
	 * <p>
	 * Define o valor do atributo caminhoRelatorio
	 * </p>
	 * .
	 *
	 * @param caminhoRelatorio
	 *            valor a ser atribuído
	 */
	public void setCaminhoRelatorio(String caminhoRelatorio) {
		this.caminhoRelatorio = caminhoRelatorio;
	}

	/**
	 * <p>
	 * Retorna o valor do atributo mapaParametros
	 * </p>
	 * .
	 *
	 * @return mapaParametros
	 */
	public Map<String, Object> getMapaParametros() {
		return this.mapaParametros;
	}

	/**
	 * <p>
	 * Define o valor do atributo mapaParametros
	 * </p>
	 * .
	 *
	 * @param mapaParametros
	 *            valor a ser atribuído
	 */
	public void setMapaParametros(Map<String, Object> mapaParametros) {
		this.mapaParametros = mapaParametros;
	}

	/**
	 * <p>
	 * Retorna o valor do atributo tipoArquivo
	 * </p>
	 * .
	 *
	 * @return tipoArquivo
	 */
	public EnumExtensaoArquivo getTipoArquivo() {
		return this.tipoArquivo;
	}

	/**
	 * <p>
	 * Define o valor do atributo tipoArquivo
	 * </p>
	 * .
	 *
	 * @param tipoArquivo
	 *            valor a ser atribuído
	 */
	public void setTipoArquivo(EnumExtensaoArquivo tipoArquivo) {
		this.tipoArquivo = tipoArquivo;
	}

	/**
	 * <p>
	 * Retorna o valor do atributo colecaoRelatorio
	 * </p>
	 * .
	 *
	 * @return colecaoRelatorio
	 */
	public Collection<?> getColecaoRelatorio() {
		return this.colecaoRelatorio;
	}

	/**
	 * <p>
	 * Define o valor do atributo colecaoRelatorio
	 * </p>
	 * .
	 *
	 * @param colecaoRelatorio
	 *            valor a ser atribuído
	 */
	public void setColecaoRelatorio(Collection<?> colecaoRelatorio) {
		this.colecaoRelatorio = colecaoRelatorio;
	}

	/**
	 * <p>
	 * Retorna o valor do atributo mensagemModal
	 * </p>
	 * .
	 *
	 * @return mensagemModal
	 */
	public String getMensagemModal() {
		return this.mensagemModal;
	}

	/**
	 * <p>
	 * Define o valor do atributo mensagemModal
	 * </p>
	 * .
	 *
	 * @param mensagemModal
	 *            valor a ser atribuído
	 */
	public void setMensagemModal(String mensagemModal) {
		this.mensagemModal = mensagemModal;
	}

	/**
	 * <p>
	 * Retorna o valor do atributo exibirModal
	 * </p>
	 * .
	 *
	 * @return exibirModal
	 */
	public boolean isExibirModal() {
		return this.exibirModal;
	}

	/**
	 * <p>
	 * Define o valor do atributo exibirModal
	 * </p>
	 * .
	 *
	 * @param exibirModal
	 *            valor a ser atribuído
	 */
	public void setExibirModal(boolean exibirModal) {
		this.exibirModal = exibirModal;
	}

	/**
	 * <p>
	 * Retorna o valor do atributo exibirBotaoIncluir
	 * </p>
	 * .
	 *
	 * @return exibirBotaoIncluir
	 */
	public boolean isExibirBotaoIncluir() {
		return this.exibirBotaoIncluir;
	}

	/**
	 * <p>
	 * Define o valor do atributo exibirBotaoIncluir
	 * </p>
	 * .
	 *
	 * @param exibirBotaoIncluir
	 *            valor a ser atribuído
	 */
	public void setExibirBotaoIncluir(boolean exibirBotaoIncluir) {
		this.exibirBotaoIncluir = exibirBotaoIncluir;
	}

	/**
	 * <p>
	 * Retorna o valor do atributo exibirBotaoEditar
	 * </p>
	 * .
	 *
	 * @return exibirBotaoEditar
	 */
	public boolean isExibirBotaoEditar() {
		return this.exibirBotaoEditar;
	}

	/**
	 * <p>
	 * Define o valor do atributo exibirBotaoEditar
	 * </p>
	 * .
	 *
	 * @param exibirBotaoEditar
	 *            valor a ser atribuído
	 */
	public void setExibirBotaoEditar(boolean exibirBotaoEditar) {
		this.exibirBotaoEditar = exibirBotaoEditar;
	}

	/**
	 * <p>
	 * Retorna o valor do atributo exibirBotaoExcluir
	 * </p>
	 * .
	 *
	 * @return exibirBotaoExcluir
	 */
	public boolean isExibirBotaoExcluir() {
		return this.exibirBotaoExcluir;
	}

	/**
	 * <p>
	 * Define o valor do atributo exibirBotaoExcluir
	 * </p>
	 * .
	 *
	 * @param exibirBotaoExcluir
	 *            valor a ser atribuído
	 */
	public void setExibirBotaoExcluir(boolean exibirBotaoExcluir) {
		this.exibirBotaoExcluir = exibirBotaoExcluir;
	}

}
