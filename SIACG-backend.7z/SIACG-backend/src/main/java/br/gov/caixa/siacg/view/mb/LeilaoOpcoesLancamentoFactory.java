package br.gov.caixa.siacg.view.mb;

import java.util.EnumMap;
import java.util.Map;

import javax.ejb.Stateless;
import javax.inject.Inject;

import br.gov.caixa.siacg.model.enums.leilao.OpcoesLancamentoEnum;

@Stateless
public class LeilaoOpcoesLancamentoFactory {

    private EnumMap<OpcoesLancamentoEnum, LeilaoOpcoesLancamentoService> opcoesLancamento;

    // @ManagedProperty(value = LeilaoDespesaMB.NOME_MANAGED_BEAN)
    @Inject
    private LeilaoDespesaMB leilaoDespesaMB;
    
    @Inject
    private LeilaoPendenciaMB leilaoPendenciaMB;

    public Map<OpcoesLancamentoEnum, LeilaoOpcoesLancamentoService> getArquivos() {
	if (opcoesLancamento == null) {
	    opcoesLancamento = new EnumMap<>(OpcoesLancamentoEnum.class);
	    opcoesLancamento.put(OpcoesLancamentoEnum.LANCAR_DESPESAS, leilaoDespesaMB);
	    opcoesLancamento.put(OpcoesLancamentoEnum.LANCAR_PENDENCIA, leilaoPendenciaMB);
	}
	return opcoesLancamento;
    }

}
