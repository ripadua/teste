package br.gov.caixa.siacg.util;

import org.hibernate.dialect.Oracle10gDialect;
import org.hibernate.dialect.function.SQLFunctionTemplate;
import org.hibernate.type.StandardBasicTypes;

public class OracleDialect extends Oracle10gDialect {

    public OracleDialect() {
	super();
	registerFunction("listagg", new SQLFunctionTemplate(StandardBasicTypes.STRING, "LISTAGG(?1,',') WITHIN GROUP(ORDER BY ?1)"));
    }
}
