package br.gov.caixa.siacg.view.mb;

import java.math.BigDecimal;
import java.util.Objects;

import javax.ejb.EJB;
import javax.enterprise.context.SessionScoped;
import javax.inject.Named;

import org.apache.commons.lang3.StringUtils;
import org.primefaces.context.RequestContext;

import br.gov.caixa.pedesgo.arquitetura.to.MensagemTO;
import br.gov.caixa.pedesgo.arquitetura.util.MensagensUtil;
import br.gov.caixa.siacg.model.domain.Despesa;
import br.gov.caixa.siacg.model.domain.leilao.Leilao;
import br.gov.caixa.siacg.service.DespesaService;
import br.gov.caixa.siacg.service.ImovelService;
import br.gov.caixa.siacg.view.form.LeilaoDespesaVisao;

@Named
@SessionScoped
public class LeilaoDespesaMB implements LeilaoOpcoesLancamentoService {

    private static final long serialVersionUID = 1L;

    public static final String NOME_MANAGED_BEAN = "leilaoDespesaMB";

    private static final String CAMPO_OBRIGATORIO = "MA009";

    private LeilaoDespesaVisao leilaoDespesaVisao;

    @EJB
    private DespesaService despesaService;

    @EJB
    private ImovelService imovelService;

    public LeilaoDespesaVisao getLeilaoDespesaVisao() {
	if (Objects.isNull(leilaoDespesaVisao)) {
	    this.leilaoDespesaVisao = new LeilaoDespesaVisao();
	}
	return this.leilaoDespesaVisao;
    }

    public void setLeilaoDespesaVisao(LeilaoDespesaVisao leilaoDespesaVisao) {
	this.leilaoDespesaVisao = leilaoDespesaVisao;
    }

    public void iniciar(Leilao leilao) {

	RequestContext context = RequestContext.getCurrentInstance();

	context.execute("PF('dialogWidgetLeilaoDespesa').show()");

	this.limparCampos();

	this.getLeilaoDespesaVisao().setLeilao(leilao);

	this.getLeilaoDespesaVisao().setLista(despesaService.listarDespesasPorImovel(leilao.getNuImovel()));

    }

    public void salvar() {

	Despesa despesa = this.getLeilaoDespesaVisao().getEntidade();

	Despesa entidade;

	if (Objects.nonNull(despesa.getNuDespesa())) {
	    entidade = this.despesaService.obter(despesa.getNuDespesa());
	} else {
	    entidade = new Despesa();
	    entidade.setImovel(this.imovelService.obter(this.getLeilaoDespesaVisao().getLeilao().getNuImovel()));
	}

	preencherDados(entidade, despesa);

	validarDados(entidade);

	if (entidade.hasMensagens()) {
	    for (final MensagemTO mensagem : entidade.getMensagens()) {
		MensagensUtil.adicionaMensagemDeAlerta("msgApp", mensagem.getChaveMensagem(), mensagem.getArgumentos());
	    }
	} else {
	    this.despesaService.salvar(entidade);
	    RequestContext.getCurrentInstance().execute("PF('modalSucesso').show();");
	}

	this.iniciar(this.getLeilaoDespesaVisao().getLeilao());

    }

    private void preencherDados(Despesa entidade, Despesa despesa) {
	entidade.setDeDespesa(despesa.getDeDespesa());
	entidade.setDtInicio(despesa.getDtInicio());
	entidade.setDtFim(despesa.getDtFim());
	entidade.setVrDespesa(despesa.getVrDespesa());
    }

    public void validarDados(Despesa despesa) {

	despesa.limparMensagens();

	if (StringUtils.isEmpty(despesa.getDeDespesa())) {
	    despesa.adicionarMensagem(CAMPO_OBRIGATORIO, "Descrição");
	}

	if (Objects.isNull(despesa.getDtInicio())) {
	    despesa.adicionarMensagem(CAMPO_OBRIGATORIO, "Data Início");
	}

	if (Objects.isNull(despesa.getDtFim())) {
	    despesa.adicionarMensagem(CAMPO_OBRIGATORIO, "Data Fim");
	}

	if (despesa.getVrDespesa().compareTo(new BigDecimal(0)) < 1) {
	    despesa.adicionarMensagem("O campo Valor é Inválido.", "");
	}

    }

    public void limparCampos() {
	this.getLeilaoDespesaVisao().getEntidade().setDeDespesa("");
	this.getLeilaoDespesaVisao().getEntidade().setDtInicio(null);
	this.getLeilaoDespesaVisao().getEntidade().setDtFim(null);
	this.getLeilaoDespesaVisao().getEntidade().setVrDespesa(null);
    }

}
