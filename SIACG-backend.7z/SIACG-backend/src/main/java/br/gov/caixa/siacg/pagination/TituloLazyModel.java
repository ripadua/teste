package br.gov.caixa.siacg.pagination;

import java.util.List;
import java.util.Map;

import javax.ejb.EJB;
import javax.faces.bean.SessionScoped;
import javax.inject.Named;

import org.primefaces.model.SortOrder;

import br.gov.caixa.pedesgo.arquitetura.paginacao.Paginacao;
import br.gov.caixa.pedesgo.arquitetura.paginacao.PaginacaoDemanda;
import br.gov.caixa.siacg.model.domain.Titulo;
import br.gov.caixa.siacg.model.enums.IdentificadorCobrancaTituloEnum;
import br.gov.caixa.siacg.model.enums.SituacaoDuplicataEnum;
import br.gov.caixa.siacg.model.enums.SituacaoTituloEnum;
import br.gov.caixa.siacg.model.enums.TipoTituloEnum;
import br.gov.caixa.siacg.model.vo.FiltroTituloVO;
import br.gov.caixa.siacg.service.TituloService;

/**
 * <p>
 * TituloLazyModel
 * </p>
 *
 * <p>
 * Descrição: Descrição do tipo
 * </p>
 *
 * <br>
 * <b>Empresa:</b> Cef - Caixa Econômica Federal
 *
 *
 * @author p566506
 *
 * @version 1.0
 */

@Named
@SessionScoped
public class TituloLazyModel extends Paginacao<Titulo> {

	private static final long serialVersionUID = -6038965454195521432L;

	/** Atributo NOME_MANAGED_BEAN. */
	public static final String NOME_MANAGED_BEAN = "tituloLazyModel";

	/** Atributo EL_MANAGED_BEAN. */
	public static final String EL_MANAGED_BEAN = "#{tituloLazyModel}";

	/** Atributo service. */
	@EJB
	private transient TituloService tituloService;

	private transient FiltroTituloVO filtro;

	/**
     * @see br.gov.caixa.pedesgo.arquitetura.integracao.componente.paginacao.Paginacao#load(int,
     *      int, java.lang.String, org.primefaces.model.SortOrder,
     *      java.util.Map)
     */
	@Override
	public List<Titulo> load(int inicio, int fim, String campoOrdenacao, SortOrder ordenacao,
			Map<String, String> parametros) {

		this.filtro.setCampoOrdenacao(campoOrdenacao);
		this.filtro.setTipoOrdenacao(ordenacao.name());
		final PaginacaoDemanda<Titulo> resultado = this.tituloService.listar(this.filtro, inicio, fim);
		for(Titulo t : resultado.getLista()) {
			t.setIdentificadorTitulo(TipoTituloEnum.obterDeValor(t.getIdentificadorTitulo()).name());
			t.setIdentificadorSituacaoDuplicata(SituacaoDuplicataEnum.obterDeValor(t.getIdentificadorSituacaoDuplicata()).name());
			t.setIdentificadorCobranca(IdentificadorCobrancaTituloEnum.obterDeValor(t.getIdentificadorCobranca()).name());
			t.setIcSituacaoTitulo(SituacaoTituloEnum.obterDeValor(t.getIdentificadorSituacaoTitulo()));		
		}

		super.setWrappedData(resultado.getLista());
		super.setRowCount(resultado.getQuantidadeRegistros() == 0 ? resultado.getLista().size() : resultado.getQuantidadeRegistros());

		return resultado.getLista();
	}

	@SuppressWarnings("unchecked")
	@Override
	public TituloService getServico() {
		return this.tituloService;
	}

	/**
	 * <p>
	 * Retorna o valor do atributo filtro
	 * </p>
	 * .
	 *
	 * @return filtro
	 */
	public FiltroTituloVO getFiltro() {
		if (this.filtro == null) {
			this.filtro = new FiltroTituloVO();
		}
		return this.filtro;
	}

	/**
	 * <p>
	 * Define o valor do atributo filtro
	 * </p>
	 * .
	 *
	 * @param filtro
	 *            valor a ser atribuído
	 */
	public void setFiltro(FiltroTituloVO filtro) {
		this.filtro = filtro;
	}
	
	  /**
     * <p>
     * Método responsável por limpar filtro da consulta.
     * <p>
     *
     * @author Brunno Antunes
     */
    public void limparFiltro() {
        this.filtro = new FiltroTituloVO();
    }


}
