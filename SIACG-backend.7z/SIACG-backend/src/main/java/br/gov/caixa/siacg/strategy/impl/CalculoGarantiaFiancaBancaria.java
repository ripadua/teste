package br.gov.caixa.siacg.strategy.impl;

import java.math.BigDecimal;

import javax.ejb.Stateless;

import br.gov.caixa.siacg.model.vo.ParametrosCalculoGarantiaVO;
import br.gov.caixa.siacg.model.vo.RelatorioAnaliseContratoVO;
import br.gov.caixa.siacg.strategy.CalculoGarantia;

/**
 * <p>
 * CalculoGarantiaFiancaBancaria
 * </p>
 * <p>
 * Descrição: Implementação do calculo para Garantia do tipo Fianca Bancaria.
 * </p>
 * <br>
 * <b>Empresa:</b> Cef - Caixa Econômica Federal
 *
 * @author guilherme.santos
 * @version 1.0
 */
@Stateless(mappedName = "CalculoGarantiaFiancaBancaria")
public class CalculoGarantiaFiancaBancaria implements CalculoGarantia {

    private static final long serialVersionUID = 8874649810239114541L;

    /**
     * @see br.gov.caixa.siacg.strategy.CalculoGarantia#calcular(br.gov.caixa.siacg.model.vo.ParametrosCalculoGarantiaVO)
     */
    @Override
    public RelatorioAnaliseContratoVO calcular(final ParametrosCalculoGarantiaVO parametrosCalculo, RelatorioAnaliseContratoVO relatorio) {
        if (relatorio == null) {
			relatorio = new RelatorioAnaliseContratoVO();
		}

		if (parametrosCalculo == null || parametrosCalculo.getGarantiaContrato() == null || parametrosCalculo.getGarantiaContrato().getVrGarantia() == null) {
			relatorio.setValorApurado(BigDecimal.ZERO);
			return relatorio;
		}

		relatorio.setValorApurado(parametrosCalculo.getGarantiaContrato().getVrGarantia());

		return relatorio;
    }
}
