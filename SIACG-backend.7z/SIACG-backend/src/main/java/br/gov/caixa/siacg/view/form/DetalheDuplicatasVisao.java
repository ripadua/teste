package br.gov.caixa.siacg.view.form;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

import javax.faces.model.SelectItem;

import br.gov.caixa.siacg.model.domain.Cedente;
import br.gov.caixa.siacg.model.domain.Titulo;
import br.gov.caixa.siacg.model.enums.UtilizacaoTituloEnum;
import br.gov.caixa.siacg.model.vo.DuplicataInadimplenteVO;
import br.gov.caixa.siacg.model.vo.PessoaVO;

/**
 * <p>
 * RelatorioAnaliseVisao
 * </p>
 * <p>
 * Descrição: Classe responsável por armazenar os dados da visão de detalhe de
 * duplicatas.
 * </p>
 * 
 * <b>Empresa:</b> Cef - Caixa Econômica Federal
 *
 * @author ricardocrispim@gsgroup.com.br
 * @version 1.0
 */
public class DetalheDuplicatasVisao extends TemplateVisao<Titulo> {

    private static final long serialVersionUID = 1L;

    private String valorBreadcrumb;
    private String paginaOrigem;
    private boolean mostrarDuplicatasValidas;
    private Integer prazoMaximo;
    private BigDecimal valorMaximo;
    private BigDecimal concentracaoMaximaValor;
    private Boolean icInstrucaoProtesto;
    private BigDecimal valorEsperado;
    private Integer nuContrato;
    private Long nuEmpreendimento;

    private PessoaVO pessoaVO;
    private transient DuplicataInadimplenteVO duplicataInadimplenteVO = new DuplicataInadimplenteVO();

    private Collection<Cedente> cedentesSelecionados;
    private SelectItem[] listaUtilizacaoTitulo;
    
    /**
     * Retorna o valor do atributo mostrarDuplicatasValidas.
     *
     * @return mostrarDuplicatasValidas
     */
    public boolean isMostrarDuplicatasValidas() {

        return this.mostrarDuplicatasValidas;

    }

    /**
     * Define o valor do atributo mostrarDuplicatasValidas.
     *
     * @param mostrarDuplicatasValidas
     *            valor a ser atribuído
     */
    public void setMostrarDuplicatasValidas(final boolean mostrarDuplicatasValidas) {

        this.mostrarDuplicatasValidas = mostrarDuplicatasValidas;

    }

    /**
     * Retorna o valor do atributo valorBreadcrumb.
     *
     * @return valorBreadcrumb
     */
    public String getValorBreadcrumb() {

        return this.valorBreadcrumb;

    }

    /**
     * Define o valor do atributo valorBreadcrumb.
     *
     * @param valorBreadcrumb
     *            valor a ser atribuído
     */
    public void setValorBreadcrumb(final String valorBreadcrumb) {

        this.valorBreadcrumb = valorBreadcrumb;

    }

    /**
     * Retorna o valor do atributo duplicataInadimplenteVO.
     *
     * @return duplicataInadimplenteVO
     */
    public DuplicataInadimplenteVO getDuplicataInadimplenteVO() {

        return this.duplicataInadimplenteVO;

    }

    /**
     * Define o valor do atributo duplicataInadimplenteVO.
     *
     * @param duplicataInadimplenteVO
     *            valor a ser atribuído
     */
    public void setDuplicataInadimplenteVO(final DuplicataInadimplenteVO duplicataInadimplenteVO) {

        this.duplicataInadimplenteVO = duplicataInadimplenteVO;

    }

    /**
     * Retorna o valor do atributo paginaOrigem.
     *
     * @return paginaOrigem
     */
    public String getPaginaOrigem() {

        return this.paginaOrigem;

    }

    /**
     * Define o valor do atributo paginaOrigem.
     *
     * @param paginaOrigem
     *            valor a ser atribuído
     */
    public void setPaginaOrigem(final String paginaOrigem) {

        this.paginaOrigem = paginaOrigem;

    }

    /**
     * Retorna o valor do atributo cedentesSelecionados.
     *
     * @return cedentesSelecionados
     */
    public Collection<Cedente> getCedentesSelecionados() {

        return this.cedentesSelecionados;

    }

    /**
     * Define o valor do atributo cedentesSelecionados.
     *
     * @param cedentesSelecionados
     *            valor a ser atribuído
     */
    public void setCedentesSelecionados(final Collection<Cedente> cedentesSelecionados) {

        this.cedentesSelecionados = cedentesSelecionados;

    }

    /**
     * Retorna o valor do atributo prazoMaximo.
     *
     * @return prazoMaximo
     */
    public Integer getPrazoMaximo() {

        return this.prazoMaximo;
    }

    /**
     * Define o valor do atributo prazoMaximo.
     *
     * @param prazoMaximo
     *            valor a ser atribuído
     */
    public void setPrazoMaximo(final Integer prazoMaximo) {

        this.prazoMaximo = prazoMaximo;
    }

    /**
     * Retorna o valor do atributo valorMaximo.
     *
     * @return valorMaximo
     */
    public BigDecimal getValorMaximo() {

        return this.valorMaximo;
    }

    /**
     * Define o valor do atributo valorMaximo.
     *
     * @param valorMaximo
     *            valor a ser atribuído
     */
    public void setValorMaximo(final BigDecimal valorMaximo) {

        this.valorMaximo = valorMaximo;
    }

    /**
     * Retorna o valor do atributo concentracaoMaximaValor.
     *
     * @return concentracaoMaximaValor
     */
    public BigDecimal getConcentracaoMaximaValor() {

        return this.concentracaoMaximaValor;
    }

    /**
     * Define o valor do atributo concentracaoMaximaValor.
     *
     * @param concentracaoMaximaValor
     *            valor a ser atribuído
     */
    public void setConcentracaoMaximaValor(final BigDecimal concentracaoMaximaValor) {

        this.concentracaoMaximaValor = concentracaoMaximaValor;
    }

    /**
     * Retorna o valor do atributo valorEsperado.
     *
     * @return valorEsperado
     */
    public BigDecimal getValorEsperado() {

        return this.valorEsperado;

    }

    /**
     * Define o valor do atributo valorEsperado.
     *
     * @param valorEsperado
     *            valor a ser atribuído
     */
    public void setValorEsperado(final BigDecimal valorEsperado) {

        this.valorEsperado = valorEsperado;

    }

    /**
     * Retorna o valor do atributo pessoaVO.
     *
     * @return pessoaVO
     */
    public PessoaVO getPessoaVO() {

        return this.pessoaVO;
    }

    /**
     * Define o valor do atributo pessoaVO.
     *
     * @param pessoaVO
     *            valor a ser atribuído
     */
    public void setPessoaVO(final PessoaVO pessoaVO) {

        this.pessoaVO = pessoaVO;
    }

    /**
     * Retorna o valor do atributo icSituacaoProtesto.
     *
     * @return icSituacaoProtesto
     */
    public Boolean getIcInstrucaoProtesto() {

        return this.icInstrucaoProtesto;

    }

    /**
     * Define o valor do atributo icSituacaoProtesto.
     *
     * @param icInstrucaoProtesto
     *            valor a ser atribuído
     */
    public void setIcInstrucaoProtesto(final Boolean icInstrucaoProtesto) {

        this.icInstrucaoProtesto = icInstrucaoProtesto;

    }

    /**
     * Retorna o valor do atributo nuContrato.
     *
     * @return nuContrato
     */
    public Integer getNuContrato() {

        return this.nuContrato;
    }

    /**
	 * <p>Retorna o valor do atributo nuEmpreendimento</p>.
	 *
	 * @return nuEmpreendimento
	*/
	public Long getNuEmpreendimento() {
		return this.nuEmpreendimento;
	}

	/**
	 * <p>Define o valor do atributo nuEmpreendimento</p>.
	 *
	 * @param nuEmpreendimento valor a ser atribuído
	*/
	public void setNuEmpreendimento(Long nuEmpreendimento) {
		this.nuEmpreendimento = nuEmpreendimento;
	}

	/**
     * Define o valor do atributo nuContrato.
     *
     * @param nuContrato
     *            valor a ser atribuído
     */
    public void setNuContrato(final Integer nuContrato) {

        this.nuContrato = nuContrato;
    }

    /**
     * <p>
     * Método responsável por listar todas oções {@link UtilizacaoTituloEnum}.
     * <p>
     *
     * @return SelectItem
     * @author guilherme.santos
     */
    public SelectItem[] getListaUtilizacaoTitulo() {

        if (this.listaUtilizacaoTitulo == null) {
            final List<String> situacoes = new ArrayList<>();

            situacoes.add(UtilizacaoTituloEnum.GN.getValor());
            situacoes.add(UtilizacaoTituloEnum.DE.getValor());
            situacoes.add(UtilizacaoTituloEnum.SE.getValor());

            final SelectItem[] options = new SelectItem[situacoes.size() + 1];

            options[0] = new SelectItem("", "-");
            for (int i = 0; i < situacoes.size(); i++) {
                options[i + 1] = new SelectItem(situacoes.get(i), situacoes.get(i));
            }

            this.setListaUtilizacaoTitulo(options);
        }

        return this.listaUtilizacaoTitulo;
    }

    /**
     * Define o valor do atributo listaUtilizacaoTitulo.
     *
     * @param listaUtilizacaoTitulo
     *            valor a ser atribuído
     */
    public void setListaUtilizacaoTitulo(final SelectItem[] listaUtilizacaoTitulo) {

        this.listaUtilizacaoTitulo = listaUtilizacaoTitulo;
    }
   
}