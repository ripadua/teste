package br.gov.caixa.siacg.pagination;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.ejb.EJB;
import javax.enterprise.context.SessionScoped;
import javax.inject.Inject;
import javax.inject.Named;

import org.primefaces.model.SortOrder;

import br.gov.caixa.pedesgo.arquitetura.enumerador.EnumAcao;
import br.gov.caixa.pedesgo.arquitetura.enumerador.EnumTipoAbrangencia;
import br.gov.caixa.pedesgo.arquitetura.paginacao.Paginacao;
import br.gov.caixa.pedesgo.arquitetura.paginacao.PaginacaoDemanda;
import br.gov.caixa.pedesgo.arquitetura.util.UsuarioUtil;
import br.gov.caixa.siacg.commons.UtilPermissao;
import br.gov.caixa.siacg.model.domain.Contrato;
import br.gov.caixa.siacg.model.enums.NoFuncionalidadeEnum;
import br.gov.caixa.siacg.model.vo.FiltroContratoVO;
import br.gov.caixa.siacg.service.ContratoService;

/**
 * <p>
 * ContratoLazyModel.
 * </p>
 * <p>
 * Descrição: Classe de paginação sob demanda do contrato
 * </p>
 * <br>
 * <b>Empresa:</b> Cef - Caixa Econômica Federal
 *
 * @author Waltenes Junior
 * @version 1.0
 */
@Named
@SessionScoped
public class ContratoLazyModel extends Paginacao<Contrato> {

    private static final long serialVersionUID = -6038965454195521432L;

    /** Atributo NOME_MANAGED_BEAN. */
    public static final String NOME_MANAGED_BEAN = "contratoLazyModel";
    /** Atributo EL_MANAGED_BEAN. */
    public static final String EL_MANAGED_BEAN = "#{contratoLazyModel}";

    /** Atributo service. */
    @EJB
    private transient ContratoService service;

    /** Atributo permissao. */
    @Inject
    private transient UtilPermissao permissao;

    /** Atributo filtro. */
    private transient FiltroContratoVO filtro;
    
    /** Atributo CATEGORIA_COMERCIAL. */
    private static final Character CATEGORIA_COMERCIAL = '1';
    
    /** Atributo CATEGORIA_HABITACIONAL. */
    private static final Character CATEGORIA_HABITACIONAL = '2';

    /**
     * @see br.gov.caixa.pedesgo.arquitetura.integracao.componente.paginacao.Paginacao#getServico()
     */
    @Override
    @SuppressWarnings("unchecked")
    public ContratoService getServico() {
        return this.service;
    }

    /**
     * @see br.gov.caixa.pedesgo.arquitetura.integracao.componente.paginacao.Paginacao#load(int,
     *      int, java.lang.String, org.primefaces.model.SortOrder,
     *      java.util.Map)
     */
    @Override
    public List<Contrato> load(final int inicio, final int fim, final String campoOrdenacao, final SortOrder ordenacao,
            final Map<String, String> parametros) {

        if (this.getFiltro().getListaUnidade().isEmpty() && UsuarioUtil.contemPermissao(NoFuncionalidadeEnum.PESQUISA_CONTRATO.getNoFuncionalidade(),
                EnumAcao.CONSULTAR.getNoAcao(), EnumTipoAbrangencia.RESTRITA_UNIDADE.getTipoAbrangencia(), null)) {
            this.getFiltro()
                    .setListaUnidade(this.permissao.prepararConsultaPorTipoAbrangencia(NoFuncionalidadeEnum.PESQUISA_CONTRATO.getNoFuncionalidade()));
        }
        
        boolean comercial = UsuarioUtil.contemPermissao("comercial", "consultar", null, null);
        boolean habitacional = UsuarioUtil.contemPermissao("habitacional", "consultar", null, null);
        
        this.filtro.getListaCategoria().clear();
        
        if (comercial) {
            this.filtro.getListaCategoria().add(CATEGORIA_COMERCIAL);
        }
        
        if (habitacional) {
            this.filtro.getListaCategoria().add(CATEGORIA_HABITACIONAL);
        }

        this.filtro.setCampoOrdenacao(campoOrdenacao);
        this.filtro.setTipoOrdenacao(ordenacao.name());
        PaginacaoDemanda<Contrato> resultado = this.service.listarContratos(this.filtro, inicio, fim);
        
        super.setWrappedData(resultado.getLista());
        super.setRowCount(resultado.getQuantidadeRegistros());

        return resultado.getLista();
    }

    /**
     * <p>
     * Método responsável por limpar filtro da consulta.
     * <p>
     *
     * @author Waltenes junior
     */
    public void limparFiltro() {
        this.filtro = new FiltroContratoVO();
    }

    /**
     * Retorna o valor do atributo filtro.
     *
     * @return filtro
     */
    public FiltroContratoVO getFiltro() {
        if (this.filtro == null) {
            this.filtro = new FiltroContratoVO();
        }
        return this.filtro;
    }

    /**
     * Define o valor do atributo filtro.
     *
     * @param filtro
     *            valor a ser atribuído
     */
    public void setFiltro(final FiltroContratoVO filtro) {
        this.filtro = filtro;
    }
}
