package br.gov.caixa.siacg.validator;

import javax.faces.application.FacesMessage;
import javax.faces.component.UIComponent;
import javax.faces.context.FacesContext;
import javax.faces.validator.FacesValidator;
import javax.faces.validator.Validator;
import javax.faces.validator.ValidatorException;

import org.primefaces.context.RequestContext;

import br.gov.caixa.pedesgo.arquitetura.util.UtilObjeto;
import br.gov.caixa.pedesgo.arquitetura.util.UtilCnpj;

/**
 * <p>
 * CnpjValidator
 * </p>
 * <p>
 * Descrição: Classe CnpjValidator
 * </p>
 * <br>
 * <b>Empresa:</b> Cef - Caixa Econômica Federal.
 *
 * @author Bruno Martins de Carvalho
 * @version 1.0
 */
@FacesValidator(value = "cnpjValidator")
public class CnpjValidator implements Validator {

    /**
     * @see javax.faces.validator.Validator#validate(javax.faces.context.FacesContext,
     *      javax.faces.component.UIComponent, java.lang.Object)
     */
    @Override
    public void validate(final FacesContext context, final UIComponent component, final Object value) throws ValidatorException {

        if (UtilObjeto.isReferencia(value)) {
            final String cnpj = String.valueOf(value);

            if (!UtilCnpj.isCNPJ(cnpj)) {
        	this.resetValueField(component);
        	
                final FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_WARN, "CNPJ inválido", "MN024");
                throw new ValidatorException(message);
            }
        }
    }
    
    private void resetValueField(final UIComponent component) {
    	RequestContext.getCurrentInstance().execute("$('#"+component.getId()+"').val('');"); 
    	RequestContext.getCurrentInstance().execute("$('#"+component.getId()+"').css('cssText','border-radius: 4px;border: 1px solid red !important; width: 200px;');");    	
    }
}
