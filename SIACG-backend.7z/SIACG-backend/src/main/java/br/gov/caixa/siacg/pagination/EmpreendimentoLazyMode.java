package br.gov.caixa.siacg.pagination;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.math.RoundingMode;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.ejb.EJB;
import javax.enterprise.context.SessionScoped;
import javax.inject.Named;

import org.primefaces.model.SortOrder;

import br.gov.caixa.pedesgo.arquitetura.paginacao.Paginacao;
import br.gov.caixa.pedesgo.arquitetura.paginacao.PaginacaoDemanda;
import br.gov.caixa.siacg.model.domain.Empreendimento;
import br.gov.caixa.siacg.model.vo.EmpreendimentoVO;
import br.gov.caixa.siacg.service.EmpreendimentoService;

@Named
@SessionScoped
public class EmpreendimentoLazyMode extends Paginacao<EmpreendimentoVO>{

    /** Atributo NOME_MANAGED_BEAN. */
    public static final String NOME_MANAGED_BEAN = "empreendimentoLazyModel";
    /** Atributo EL_MANAGED_BEAN. */
    public static final String EL_MANAGED_BEAN = "#{empreendimentoLazyModel}";
    

    private static final long serialVersionUID = -6038965454195521432L;
    
	@EJB
	private transient EmpreendimentoService servico;
	
	private transient EmpreendimentoVO filtro;
	
	@Override
	public List<EmpreendimentoVO> load(int inicio, int fim, String campoOrdenacao, SortOrder ordenacao,
			Map<String, String> parametros) {		
		
		 final PaginacaoDemanda<Empreendimento> resultado = this.servico.listaEmpreendimento(inicio, fim, filtro);

		 final List<EmpreendimentoVO> lista = new ArrayList<>();
		 
		 for (Empreendimento item : resultado.getLista()) {
			 EmpreendimentoVO empreendimentoVO =  new EmpreendimentoVO();
			 empreendimentoVO.setNomeEmpreendimento(item.getNoEmpreendimento());
			 empreendimentoVO.setNuEmpreendimento(item.getNuEmpreendimento());
			 
			 BigInteger rcPrevisto = this.servico.qtdTotalAReceber(item.getNuEmpreendimento());			 
			 BigInteger rcRecebida = this.servico.qtdTotalRecebida(item.getNuEmpreendimento());
			 BigDecimal valorPrevisto = this.servico.valorAReceber(item.getNuEmpreendimento());
			 BigDecimal valorRecebido = this.servico.valorRecebido(item.getNuEmpreendimento());
			 
			 BigDecimal valorTotalPendencia = this.servico.valorRecebidoPendencia(item.getNuEmpreendimento());
			 
			 BigInteger qtdPendencia = this.servico.qtdTotalRecebidaPendentes(item.getNuEmpreendimento());
			 empreendimentoVO.setNuContratoPai(item.getNuContratoPai());
			 empreendimentoVO.setQtdRecebidaPrevista(rcPrevisto);
			 empreendimentoVO.setQtdRecebida(rcRecebida);
			 empreendimentoVO.setQtdRecebidaPrevistaPerc(calcularPorc(BigDecimal.valueOf(rcPrevisto.floatValue()), BigDecimal.valueOf(rcRecebida.floatValue())));
			 
			 empreendimentoVO.setValorPrevisto(valorPrevisto);
			 empreendimentoVO.setValorRecebido(valorRecebido);
			 empreendimentoVO.setValorPerc(calcularPorc(valorPrevisto, valorRecebido));
			 
			 empreendimentoVO.setQtdPendencias(qtdPendencia);
			 empreendimentoVO.setValorTotalPendencia(valorTotalPendencia);
			 empreendimentoVO.setPercentualPendencia(calcularPorc(valorPrevisto, valorTotalPendencia));
			 
			 
			 lista.add(empreendimentoVO);
		 }
		 
	     super.setWrappedData(lista);
	     super.setRowCount(resultado.getQuantidadeRegistros() == 0 ? lista.size() : resultado.getQuantidadeRegistros());
		 
		return lista;
	}
	
	private BigDecimal calcularPorc(BigDecimal rcPrevisto, BigDecimal rcRecebida) {
		
		BigDecimal valor;
		if(rcPrevisto.compareTo(BigDecimal.ZERO) == 0) {
			valor = BigDecimal.ZERO;
		}else {
			valor = rcRecebida.multiply(BigDecimal.valueOf(100)).divide(rcPrevisto, 2, RoundingMode.HALF_UP);
		}

		return valor;
		
	}
	
	public void limparFiltro() {
		this.filtro = new EmpreendimentoVO();
	}

	@Override
    @SuppressWarnings("unchecked")
	public EmpreendimentoService getServico() {
		return this.servico;
	}

	public EmpreendimentoVO getFiltro() {
		return filtro;
	}

	public void setFiltro(EmpreendimentoVO filtro) {
		this.filtro = filtro;
	}

	
	
}
