package br.gov.caixa.siacg.util;

public class RestUtil {

	private RestUtil() {
		throw new IllegalStateException("Classe de Utilidade");
	}
	
    public static RecursoErro gerarRecursoErro(int statusCode, String msg, String detalhe) {
        RecursoErro recursoErro = new RecursoErro();
        recursoErro.setCodigo(statusCode);
        recursoErro.setMensagem(msg);
        recursoErro.setDetalhe(detalhe);
        return recursoErro;
    }
}
