/*
 * Copyright (c) 2016 Caixa Econômica Federal. Todos os direitos
 * reservados.
 *
 * Caixa Econômica Federal - SIACG_dev
 *
 * Este software foi desenvolvido sob demanda da CAIXA e está
 * protegido por leis de direitos autorais e tratados internacionais. As
 * condições de cópia e utilização do todo ou partes dependem de autorização da
 * pessoa. Cópias não são permitidas sem expressa autorização. Não pode ser
 * comercializado ou utilizado para propósitos particulares.
 *
 * Uso exclusivo da Caixa Econômica Federal. A reprodução ou distribuição não
 * autorizada deste programa ou de parte dele, resultará em punições civis e
 * criminais e os infratores incorrem em sanções previstas na legislação em
 * vigor.
 *
 * Histórico do Subversion:
 *
 * LastChangedRevision: $Revision$
 * LastChangedBy: $Author$
 * LastChangedDate: $Date$
 *
 * HeadURL: $HeadURL$
 *
 */
package br.gov.caixa.siacg.comum.to;

import java.math.BigDecimal;
import java.util.Date;

import br.gov.caixa.pedesgo.arquitetura.util.UtilObjeto;
import br.gov.caixa.pedesgo.arquitetura.enumerador.EnumTipoFormatacao;
import br.gov.caixa.pedesgo.arquitetura.util.UtilData;
import br.gov.caixa.pedesgo.arquitetura.util.UtilCnpj;
import br.gov.caixa.pedesgo.arquitetura.util.UtilFormatacao;
import br.gov.caixa.siacg.util.ContratoUtil;

/**
 * <p>
 * RelatorioBasePainelGarantiaTO.
 * </p>
 * <p>
 * Descrição: TO que armazena os campos utilizados no relatorio painel de
 * garantias.
 * </p>
 * <br>
 * <b>Empresa:</b> Cef - Caixa Econômica Federal
 *
 * @author Bruno Martins de Carvalho
 * @version 1.0
 */
public class RelatorioBasePainelGarantiaTO {

    /** Atributo coSuat. */
    private String coSuat;
    /** Atributo noSuat. */
    private String noSuat;

    /** Atributo coSr. */
    private String coSr;
    /** Atributo noSr. */
    private String noSr;

    /** Atributo coUnidade. */
    private String coUnidade;
    /** Atributo noUnidade. */
    private String noUnidade;

    /** Atributo noOperacao. */
    private String noOperacao;
    /** Atributo nuOperacao. */
    private Integer nuOperacao;

    /** Atributo coIdentificadorContrato. */
    private String coIdentificadorContrato;
    /** Atributo dtContrato. */
    private Date dtContrato;

    /** Atributo vrSaldoDevedor. */
    private BigDecimal vrSaldoDevedor;
    /** Atributo noSegmento. */
    private String noSegmento;

    /** Atributo noCliente. */
    private String noCliente;
    /** Atributo cnpj. */
    private String cnpj;

    /** Atributo vrGarantiaPactuadaDuplicata. */
    private BigDecimal vrGarantiaPactuadaDuplicata;
    /** Atributo vrGarantiaConstDuplicata. */
    private BigDecimal vrGarantiaConstDuplicata;
    /** Atributo vrDiferencaDuplicata. */
    private BigDecimal vrDiferencaDuplicata;

    /** Atributo vrGarantiaPactuadaAplicacao. */
    private BigDecimal vrGarantiaPactuadaAplicacao;
    /** Atributo vrGarantiaConstAplicacao. */
    private BigDecimal vrGarantiaConstAplicacao;
    /** Atributo vrDiferencaAplicacao. */
    private BigDecimal vrDiferencaAplicacao;

    /** Atributo vrGarantiaPactuadaCartao. */
    private BigDecimal vrGarantiaPactuadaCartao;
    /** Atributo vrGarantiaConstCartao. */
    private BigDecimal vrGarantiaConstCartao;
    /** Atributo vrDiferencaCartao. */
    private BigDecimal vrDiferencaCartao;

    /** Atributo vrGarantiaPactuadaCheque. */
    private BigDecimal vrGarantiaPactuadaCheque;
    /** Atributo vrGarantiaConstCheque. */
    private BigDecimal vrGarantiaConstCheque;
    /** Atributo vrDiferencaCheque. */
    private BigDecimal vrDiferencaCheque;
    
    /** Atributo vrGarantiaPactuadaMaquinaEquipamento. */
    private BigDecimal vrGarantiaPactuadaMaquinaEquipamento;
    /** Atributo vrGarantiaCnstaMaquinaEquipamento. */
    private BigDecimal vrGarantiaCnstaMaquinaEquipamento;
    /** Atributo vrDiferencaMaquinaEquipamento. */
    private BigDecimal vrDiferencaMaquinaEquipamento;
    
    /** Atributo vrGarantiaPactuadaImovel. */
    private BigDecimal vrGarantiaPactuadaImovel;
    /** Atributo vrGarantiaCnstaImovel. */
    private BigDecimal vrGarantiaCnstaImovel;
    /** Atributo vrDiferencaImovel. */
    private BigDecimal vrDiferencaImovel;
    
    /** Atributo vrGarantiaPactuadaProdutoAgricola. */
    private BigDecimal vrGarantiaPactuadaProdutoAgricola;
    /** Atributo vrGarantiaCnstaProdutoAgricola. */
    private BigDecimal vrGarantiaCnstaProdutoAgricola;
    /** Atributo vrDiferencaProdutoAgricola. */
    private BigDecimal vrDiferencaProdutoAgricola;

    /** Atributo vrGarantiaPactuadaOutras. */
    private BigDecimal vrGarantiaPactuadaOutras;
    /** Atributo vrGarantiaConstOutras. */
    private BigDecimal vrGarantiaConstOutras;
    /** Atributo vrDiferencaOutras. */
    private BigDecimal vrDiferencaOutras;

    /** Atributo vrGarantiaPactuadaTotal. */
    private BigDecimal vrGarantiaPactuadaTotal;
    /** Atributo vrGarantiaConstTotal. */
    private BigDecimal vrGarantiaConstTotal;

    /** Atributo vrDiferencaParcial. */
    private BigDecimal vrDiferencaParcial;

    /** Atributo vrSaldoNLM. */
    private BigDecimal vrSaldoNLM;

    /** Atributo totalPactuado4Garantias. */
    private BigDecimal totalPactuado4Garantias;

    /** Atributo statusGarantias. */
    private String statusGarantias;

    /** Atributo icPendenteParametrizacao. */
    private Boolean icPendenteParametrizacao;

    /** Atributo dtInicioInsuficiencia. */
    private Date dtInicioInsuficiencia;

    /** Atributo vrFaturamento. */
    private BigDecimal vrFaturamento;

    /** Atributo diasGarantiaInsuficiente. */
    private Integer diasGarantiaInsuficiente;

    /**
     * Construtor.
     *
     * @param coSuat
     *            valor a ser atribuido
     * @param noSuat
     *            valor a ser atribuido
     * @param coSr
     *            valor a ser atribuido
     * @param noSr
     *            valor a ser atribuido
     * @param coUnidade
     *            valor a ser atribuido
     * @param noUnidade
     *            valor a ser atribuido
     * @param noOperacao
     *            valor a ser atribuido
     * @param nuOperacao
     *            valor a ser atribuido
     * @param coIdentificadorContrato
     *            valor a ser atribuido
     * @param dtContrato
     *            valor a ser atribuido
     * @param vrSaldoDevedor
     *            valor a ser atribuido
     * @param noSegmento
     *            valor a ser atribuido
     * @param noCliente
     *            valor a ser atribuido
     * @param cnpj
     *            valor a ser atribuido
     * @param vrGarantiaPactuadaDuplicata
     *            valor a ser atribuido
     * @param vrGarantiaConstDuplicata
     *            valor a ser atribuido
     * @param vrDiferencaDuplicata
     *            valor a ser atribuido
     * @param vrGarantiaPactuadaAplicacao
     *            valor a ser atribuido
     * @param vrGarantiaConstAplicacao
     *            valor a ser atribuido
     * @param vrDiferencaAplicacao
     *            valor a ser atribuido
     * @param vrGarantiaPactuadaCartao
     *            valor a ser atribuido
     * @param vrGarantiaConstCartao
     *            valor a ser atribuido
     * @param vrDiferencaCartao
     *            valor a ser atribuido
     * @param vrGarantiaPactuadaCheque
     *            valor a ser atribuido
     * @param vrGarantiaConstCheque
     *            valor a ser atribuido
     * @param vrDiferencaCheque
     *            valor a ser atribuido
     * @param vrGarantiaPactuadaOutras
     *            valor a ser atribuido
     * @param vrGarantiaConstOutras
     *            valor a ser atribuido
     * @param vrDiferencaOutras
     *            valor a ser atribuido
     * @param vrGarantiaPactuadaTotal
     *            valor a ser atribuido
     * @param vrGarantiaConstTotal
     *            valor a ser atribuido
     * @param vrDiferencaParcial
     *            valor a ser atribuido
     * @param vrSaldoNLM
     *            valor a ser atribuido
     * @param statusGarantias
     *            valor a ser atribuido
     * @param icPendenteParametrizacao
     *            valor a ser atribuido
     * @param dtInicioInsuficiencia
     *            valor a ser atribuido
     * @param vrFaturamento
     *            valor a ser atribuido
     */
    public RelatorioBasePainelGarantiaTO(final String coSuat, final String noSuat, final String coSr, final String noSr, final String coUnidade,
            final String noUnidade, final String noOperacao, final Integer nuOperacao, final String coIdentificadorContrato, final Date dtContrato,
            final BigDecimal vrSaldoDevedor, final String noSegmento, final String noCliente, final String cnpj,
            final BigDecimal vrGarantiaPactuadaDuplicata, final BigDecimal vrGarantiaConstDuplicata, final BigDecimal vrDiferencaDuplicata,
            final BigDecimal vrGarantiaPactuadaAplicacao, final BigDecimal vrGarantiaConstAplicacao, final BigDecimal vrDiferencaAplicacao,
            final BigDecimal vrGarantiaPactuadaCartao, final BigDecimal vrGarantiaConstCartao, final BigDecimal vrDiferencaCartao,
            final BigDecimal vrGarantiaPactuadaCheque, final BigDecimal vrGarantiaConstCheque, final BigDecimal vrDiferencaCheque,
            final BigDecimal vrGarantiaPactuadaMaquinaEquipamento, final BigDecimal vrGarantiaCnstaMaquinaEquipamento, final BigDecimal vrDiferencaMaquinaEquipamento,
            final BigDecimal vrGarantiaPactuadaImovel, final BigDecimal vrGarantiaCnstaImovel, final BigDecimal vrDiferencaImovel,
            final BigDecimal vrGarantiaPactuadaProdutoAgricola, final BigDecimal vrGarantiaCnstaProdutoAgricola, final BigDecimal vrDiferencaProdutoAgricola,
            final BigDecimal vrGarantiaPactuadaOutras, final BigDecimal vrGarantiaConstOutras, final BigDecimal vrDiferencaOutras,
            final BigDecimal vrGarantiaPactuadaTotal, final BigDecimal vrGarantiaConstTotal, final BigDecimal vrDiferencaParcial,
            final BigDecimal vrSaldoNLM, final String statusGarantias, final Boolean icPendenteParametrizacao, final Date dtInicioInsuficiencia,
            final BigDecimal vrFaturamento) {
	
        this.coSuat = coSuat;
        this.noSuat = noSuat;
        this.coSr = coSr;
        this.noSr = noSr;
        this.coUnidade = coUnidade;
        this.noUnidade = noUnidade;
        this.noOperacao = noOperacao;
        this.nuOperacao = nuOperacao;
        this.coIdentificadorContrato = coIdentificadorContrato;
        this.dtContrato = dtContrato;
        this.vrSaldoDevedor = vrSaldoDevedor;
        this.noSegmento = noSegmento;
        this.noCliente = noCliente;
        this.cnpj = cnpj;
        this.vrGarantiaPactuadaDuplicata = vrGarantiaPactuadaDuplicata;
        this.vrGarantiaConstDuplicata = vrGarantiaConstDuplicata;
        this.vrDiferencaDuplicata = vrDiferencaDuplicata;
        this.vrGarantiaPactuadaAplicacao = vrGarantiaPactuadaAplicacao;
        this.vrGarantiaConstAplicacao = vrGarantiaConstAplicacao;
        this.vrDiferencaAplicacao = vrDiferencaAplicacao;
        this.vrGarantiaPactuadaCartao = vrGarantiaPactuadaCartao;
        this.vrGarantiaConstCartao = vrGarantiaConstCartao;
        this.vrDiferencaCartao = vrDiferencaCartao;
        this.vrGarantiaPactuadaCheque = vrGarantiaPactuadaCheque;
        this.vrGarantiaConstCheque = vrGarantiaConstCheque;
        this.vrDiferencaCheque = vrDiferencaCheque;
        this.vrGarantiaPactuadaMaquinaEquipamento = vrGarantiaPactuadaMaquinaEquipamento;
        this.vrGarantiaCnstaMaquinaEquipamento = vrGarantiaCnstaMaquinaEquipamento;
        this.vrDiferencaMaquinaEquipamento = vrDiferencaMaquinaEquipamento;
        this.vrGarantiaPactuadaImovel = vrGarantiaPactuadaImovel;
        this.vrGarantiaCnstaImovel = vrGarantiaCnstaImovel;
        this.vrDiferencaImovel = vrDiferencaImovel;
        this.vrGarantiaPactuadaProdutoAgricola = vrGarantiaPactuadaProdutoAgricola;
        this.vrGarantiaCnstaProdutoAgricola = vrGarantiaCnstaProdutoAgricola;
        this.vrDiferencaProdutoAgricola = vrDiferencaProdutoAgricola;
        this.vrGarantiaPactuadaOutras = vrGarantiaPactuadaOutras;
        this.vrGarantiaConstOutras = vrGarantiaConstOutras;
        this.vrDiferencaOutras = vrDiferencaOutras;
        this.vrGarantiaPactuadaTotal = vrGarantiaPactuadaTotal;
        this.vrGarantiaConstTotal = vrGarantiaConstTotal;
        this.vrDiferencaParcial = vrDiferencaParcial;
        this.vrSaldoNLM = vrSaldoNLM;
        this.statusGarantias = statusGarantias;
        this.icPendenteParametrizacao = icPendenteParametrizacao;
        this.dtInicioInsuficiencia = dtInicioInsuficiencia;
        this.vrFaturamento = vrFaturamento;
    }

    /**
     * Construtor.
     *
     */
    public RelatorioBasePainelGarantiaTO() {
    }

    /**
     * Retorna o valor do atributo coSuat.
     *
     * @return coSuat
     */
    public String getCoSuat() {
        return this.coSuat;
    }

    /**
     * Retorna o valor do atributo noSuat.
     *
     * @return noSuat
     */
    public String getNoSuat() {
        return this.noSuat;
    }

    /**
     * Retorna o valor do atributo coSr.
     *
     * @return coSr
     */
    public String getCoSr() {
        return this.coSr;
    }

    /**
     * Retorna o valor do atributo noSr.
     *
     * @return noSr
     */
    public String getNoSr() {
        return this.noSr;
    }

    /**
     * Retorna o valor do atributo coUnidade.
     *
     * @return coUnidade
     */
    public String getCoUnidade() {
        return this.coUnidade;
    }

    /**
     * Retorna o valor do atributo noUnidade.
     *
     * @return noUnidade
     */
    public String getNoUnidade() {
        return this.noUnidade;
    }

    /**
     * Retorna o valor do atributo noOperacao.
     *
     * @return noOperacao
     */
    public String getNoOperacao() {
        return this.noOperacao;
    }

    /**
     * Retorna o valor do atributo coIdentificadorContrato.
     *
     * @return coIdentificadorContrato
     */
    public String getCoIdentificadorContrato() {
        if (UtilObjeto.isReferencia(this.coIdentificadorContrato) && UtilObjeto.isReferencia(this.nuOperacao)
                && this.coIdentificadorContrato.length() >= 4) {
            this.coIdentificadorContrato = ContratoUtil.formatarContratoComMascaraSessao(this.nuOperacao, this.coIdentificadorContrato);
        }
        return this.coIdentificadorContrato;
    }

    /**
     * Retorna o valor do atributo dtContrato.
     *
     * @return dtContrato
     */
    public Date getDtContrato() {
        return this.dtContrato;
    }

    /**
     * Retorna o valor do atributo vrSaldoDevedor.
     *
     * @return vrSaldoDevedor
     */
    public BigDecimal getVrSaldoDevedor() {
        return this.vrSaldoDevedor;
    }

    /**
     * Retorna o valor do atributo noSegmento.
     *
     * @return noSegmento
     */
    public String getNoSegmento() {
        return this.noSegmento;
    }

    /**
     * Retorna o valor do atributo noCliente.
     *
     * @return noCliente
     */
    public String getNoCliente() {
        return this.noCliente;
    }

    /**
     * Retorna o valor do atributo cnpj.
     *
     * @return cnpj
     */
    public String getCnpj() {
        if (UtilCnpj.isCNPJ(this.cnpj)) {
            this.cnpj = UtilFormatacao.formatar(this.cnpj, EnumTipoFormatacao.CNPJ);
        }

        return this.cnpj;
    }

    /**
     * Retorna o valor do atributo vrGarantiaPactuadaDuplicata.
     *
     * @return vrGarantiaPactuadaDuplicata
     */
    public BigDecimal getVrGarantiaPactuadaDuplicata() {
        if (!UtilObjeto.isReferencia(this.vrGarantiaPactuadaDuplicata)) {
            this.vrGarantiaPactuadaDuplicata = BigDecimal.ZERO;
        }
        return this.vrGarantiaPactuadaDuplicata;
    }

    /**
     * Retorna o valor do atributo vrGarantiaConstDuplicata.
     *
     * @return vrGarantiaConstDuplicata
     */
    public BigDecimal getVrGarantiaConstDuplicata() {
        if (!UtilObjeto.isReferencia(this.vrGarantiaConstDuplicata)) {
            this.vrGarantiaConstDuplicata = BigDecimal.ZERO;
        }
        return this.vrGarantiaConstDuplicata;
    }

    /**
     * Retorna o valor do atributo vrDiferencaDuplicata.
     *
     * @return vrDiferencaDuplicata
     */
    public BigDecimal getVrDiferencaDuplicata() {
        if (!UtilObjeto.isReferencia(this.vrDiferencaDuplicata)) {
            this.vrDiferencaDuplicata = BigDecimal.ZERO;
        }
        return this.vrDiferencaDuplicata;
    }

    /**
     * Retorna o valor do atributo vrGarantiaPactuadaAplicacao.
     *
     * @return vrGarantiaPactuadaAplicacao
     */
    public BigDecimal getVrGarantiaPactuadaAplicacao() {
        if (!UtilObjeto.isReferencia(this.vrGarantiaPactuadaAplicacao)) {
            this.vrGarantiaPactuadaAplicacao = BigDecimal.ZERO;
        }
        return this.vrGarantiaPactuadaAplicacao;
    }

    /**
     * Retorna o valor do atributo vrGarantiaConstAplicacao.
     *
     * @return vrGarantiaConstAplicacao
     */
    public BigDecimal getVrGarantiaConstAplicacao() {
        if (!UtilObjeto.isReferencia(this.vrGarantiaConstAplicacao)) {
            this.vrGarantiaConstAplicacao = BigDecimal.ZERO;
        }
        return this.vrGarantiaConstAplicacao;
    }

    /**
     * Retorna o valor do atributo vrDiferencaAplicacao.
     *
     * @return vrDiferencaAplicacao
     */
    public BigDecimal getVrDiferencaAplicacao() {
        if (!UtilObjeto.isReferencia(this.vrDiferencaAplicacao)) {
            this.vrDiferencaAplicacao = BigDecimal.ZERO;
        }
        return this.vrDiferencaAplicacao;
    }

    /**
     * Retorna o valor do atributo vrGarantiaPactuadaCartao.
     *
     * @return vrGarantiaPactuadaCartao
     */
    public BigDecimal getVrGarantiaPactuadaCartao() {
        if (!UtilObjeto.isReferencia(this.vrGarantiaPactuadaCartao)) {
            this.vrGarantiaPactuadaCartao = BigDecimal.ZERO;
        }
        return this.vrGarantiaPactuadaCartao;
    }

    /**
     * Retorna o valor do atributo vrGarantiaConstCartao.
     *
     * @return vrGarantiaConstCartao
     */
    public BigDecimal getVrGarantiaConstCartao() {
        if (!UtilObjeto.isReferencia(this.vrGarantiaConstCartao)) {
            this.vrGarantiaConstCartao = BigDecimal.ZERO;
        }
        return this.vrGarantiaConstCartao;
    }

    /**
     * Retorna o valor do atributo vrDiferencaCartao.
     *
     * @return vrDiferencaCartao
     */
    public BigDecimal getVrDiferencaCartao() {
        if (!UtilObjeto.isReferencia(this.vrDiferencaCartao)) {
            this.vrDiferencaCartao = BigDecimal.ZERO;
        }
        return this.vrDiferencaCartao;
    }

    /**
     * Retorna o valor do atributo vrGarantiaPactuadaCheque.
     *
     * @return vrGarantiaPactuadaCheque
     */
    public BigDecimal getVrGarantiaPactuadaCheque() {
        if (!UtilObjeto.isReferencia(this.vrGarantiaPactuadaCheque)) {
            this.vrGarantiaPactuadaCheque = BigDecimal.ZERO;
        }
        return this.vrGarantiaPactuadaCheque;
    }

    /**
     * Retorna o valor do atributo vrGarantiaConstCheque.
     *
     * @return vrGarantiaConstCheque
     */
    public BigDecimal getVrGarantiaConstCheque() {
        if (!UtilObjeto.isReferencia(this.vrGarantiaConstCheque)) {
            this.vrGarantiaConstCheque = BigDecimal.ZERO;
        }
        return this.vrGarantiaConstCheque;
    }

    /**
     * Retorna o valor do atributo vrDiferencaCheque.
     *
     * @return vrDiferencaCheque
     */
    public BigDecimal getVrDiferencaCheque() {
        if (!UtilObjeto.isReferencia(this.vrDiferencaCheque)) {
            this.vrDiferencaCheque = BigDecimal.ZERO;
        }
        return this.vrDiferencaCheque;
    }

    /**
     * Retorna o valor do atributo vrGarantiaPactuadaOutras.
     *
     * @return vrGarantiaPactuadaOutras
     */
    public BigDecimal getVrGarantiaPactuadaOutras() {
        if (!UtilObjeto.isReferencia(this.vrGarantiaPactuadaOutras)) {
            this.vrGarantiaPactuadaOutras = BigDecimal.ZERO;
        }
        return this.vrGarantiaPactuadaOutras;
    }

    /**
     * Retorna o valor do atributo vrGarantiaConstOutras.
     *
     * @return vrGarantiaConstOutras
     */
    public BigDecimal getVrGarantiaConstOutras() {
        if (!UtilObjeto.isReferencia(this.vrGarantiaConstOutras)) {
            this.vrGarantiaConstOutras = BigDecimal.ZERO;
        }
        return this.vrGarantiaConstOutras;
    }

    /**
     * Retorna o valor do atributo vrDiferencaOutras.
     *
     * @return vrDiferencaOutras
     */
    public BigDecimal getVrDiferencaOutras() {
        if (!UtilObjeto.isReferencia(this.vrDiferencaOutras)) {
            this.vrDiferencaOutras = BigDecimal.ZERO;
        }
        return this.vrDiferencaOutras;
    }

    /**
     * Retorna o valor do atributo vrGarantiaPactuadaTotal.
     *
     * @return vrGarantiaPactuadaTotal
     */
    public BigDecimal getVrGarantiaPactuadaTotal() {
        if (!UtilObjeto.isReferencia(this.vrGarantiaPactuadaTotal)) {
            this.vrGarantiaPactuadaTotal = BigDecimal.ZERO;
        }
        return this.vrGarantiaPactuadaTotal;
    }

    /**
     * Retorna o valor do atributo vrGarantiaConstTotal.
     *
     * @return vrGarantiaConstTotal
     */
    public BigDecimal getVrGarantiaConstTotal() {
        if (!UtilObjeto.isReferencia(this.vrGarantiaConstTotal)) {
            this.vrGarantiaConstTotal = BigDecimal.ZERO;
        }
        return this.vrGarantiaConstTotal;
    }

    /**
     * Retorna o valor do atributo vrDiferencaParcial.
     *
     * @return vrDiferencaParcial
     */
    public BigDecimal getVrDiferencaParcial() {
        if (!UtilObjeto.isReferencia(this.vrDiferencaParcial)) {
            this.vrDiferencaParcial = BigDecimal.ZERO;
        }
        return this.vrDiferencaParcial;
    }

    /**
     * Retorna o valor do atributo vrSaldoNLM.
     *
     * @return vrSaldoNLM
     */
    public BigDecimal getVrSaldoNLM() {
        if (!UtilObjeto.isReferencia(this.vrSaldoNLM)) {
            this.vrSaldoNLM = BigDecimal.ZERO;
        }
        return this.vrSaldoNLM;
    }

    /**
     * Retorna o valor do atributo totalPactuado4Garantias.
     *
     * @return totalPactuado4Garantias
     */
    public BigDecimal getTotalPactuado4Garantias() {
        if (!UtilObjeto.isReferencia(this.totalPactuado4Garantias)) {
            this.totalPactuado4Garantias = BigDecimal.ZERO;
        }
        return this.totalPactuado4Garantias;
    }

    /**
     * Retorna o valor do atributo statusGarantias.
     *
     * @return statusGarantias
     */
    public String getStatusGarantias() {
        return this.statusGarantias;
    }

    /**
     * Define o valor do atributo coSuat.
     *
     * @param coSuat
     *            valor a ser atribuído
     */
    public void setCoSuat(final String coSuat) {
        this.coSuat = coSuat;
    }

    /**
     * Define o valor do atributo noSuat.
     *
     * @param noSuat
     *            valor a ser atribuído
     */
    public void setNoSuat(final String noSuat) {
        this.noSuat = noSuat;
    }

    /**
     * Define o valor do atributo coSr.
     *
     * @param coSr
     *            valor a ser atribuído
     */
    public void setCoSr(final String coSr) {
        this.coSr = coSr;
    }

    /**
     * Define o valor do atributo noSr.
     *
     * @param noSr
     *            valor a ser atribuído
     */
    public void setNoSr(final String noSr) {
        this.noSr = noSr;
    }

    /**
     * Define o valor do atributo coUnidade.
     *
     * @param coUnidade
     *            valor a ser atribuído
     */
    public void setCoUnidade(final String coUnidade) {
        this.coUnidade = coUnidade;
    }

    /**
     * Define o valor do atributo noUnidade.
     *
     * @param noUnidade
     *            valor a ser atribuído
     */
    public void setNoUnidade(final String noUnidade) {
        this.noUnidade = noUnidade;
    }

    /**
     * Define o valor do atributo noOperacao.
     *
     * @param noOperacao
     *            valor a ser atribuído
     */
    public void setNoOperacao(final String noOperacao) {
        this.noOperacao = noOperacao;
    }

    /**
     * Define o valor do atributo coIdentificadorContrato.
     *
     * @param coIdentificadorContrato
     *            valor a ser atribuído
     */
    public void setCoIdentificadorContrato(final String coIdentificadorContrato) {
        this.coIdentificadorContrato = coIdentificadorContrato;
    }

    /**
     * Define o valor do atributo dtContrato.
     *
     * @param dtContrato
     *            valor a ser atribuído
     */
    public void setDtContrato(final Date dtContrato) {
        this.dtContrato = dtContrato;
    }

    /**
     * Define o valor do atributo vrSaldoDevedor.
     *
     * @param vrSaldoDevedor
     *            valor a ser atribuído
     */
    public void setVrSaldoDevedor(final BigDecimal vrSaldoDevedor) {
        this.vrSaldoDevedor = vrSaldoDevedor;
    }

    /**
     * Define o valor do atributo noSegmento.
     *
     * @param noSegmento
     *            valor a ser atribuído
     */
    public void setNoSegmento(final String noSegmento) {
        this.noSegmento = noSegmento;
    }

    /**
     * Define o valor do atributo noCliente.
     *
     * @param noCliente
     *            valor a ser atribuído
     */
    public void setNoCliente(final String noCliente) {
        this.noCliente = noCliente;
    }

    /**
     * Define o valor do atributo cnpj.
     *
     * @param cnpj
     *            valor a ser atribuído
     */
    public void setCnpj(final String cnpj) {
        this.cnpj = cnpj;
    }

    /**
     * Define o valor do atributo vrGarantiaPactuadaDuplicata.
     *
     * @param vrGarantiaPactuadaDuplicata
     *            valor a ser atribuído
     */
    public void setVrGarantiaPactuadaDuplicata(final BigDecimal vrGarantiaPactuadaDuplicata) {
        this.vrGarantiaPactuadaDuplicata = vrGarantiaPactuadaDuplicata;
    }

    /**
     * Define o valor do atributo vrGarantiaConstDuplicata.
     *
     * @param vrGarantiaConstDuplicata
     *            valor a ser atribuído
     */
    public void setVrGarantiaConstDuplicata(final BigDecimal vrGarantiaConstDuplicata) {
        this.vrGarantiaConstDuplicata = vrGarantiaConstDuplicata;
    }

    /**
     * Define o valor do atributo vrDiferencaDuplicata.
     *
     * @param vrDiferencaDuplicata
     *            valor a ser atribuído
     */
    public void setVrDiferencaDuplicata(final BigDecimal vrDiferencaDuplicata) {
        this.vrDiferencaDuplicata = vrDiferencaDuplicata;
    }

    /**
     * Define o valor do atributo vrGarantiaPactuadaAplicacao.
     *
     * @param vrGarantiaPactuadaAplicacao
     *            valor a ser atribuído
     */
    public void setVrGarantiaPactuadaAplicacao(final BigDecimal vrGarantiaPactuadaAplicacao) {
        this.vrGarantiaPactuadaAplicacao = vrGarantiaPactuadaAplicacao;
    }

    /**
     * Define o valor do atributo vrGarantiaConstAplicacao.
     *
     * @param vrGarantiaConstAplicacao
     *            valor a ser atribuído
     */
    public void setVrGarantiaConstAplicacao(final BigDecimal vrGarantiaConstAplicacao) {
        this.vrGarantiaConstAplicacao = vrGarantiaConstAplicacao;
    }

    /**
     * Define o valor do atributo vrDiferencaAplicacao.
     *
     * @param vrDiferencaAplicacao
     *            valor a ser atribuído
     */
    public void setVrDiferencaAplicacao(final BigDecimal vrDiferencaAplicacao) {
        this.vrDiferencaAplicacao = vrDiferencaAplicacao;
    }

    /**
     * Define o valor do atributo vrGarantiaPactuadaCartao.
     *
     * @param vrGarantiaPactuadaCartao
     *            valor a ser atribuído
     */
    public void setVrGarantiaPactuadaCartao(final BigDecimal vrGarantiaPactuadaCartao) {
        this.vrGarantiaPactuadaCartao = vrGarantiaPactuadaCartao;
    }

    /**
     * Define o valor do atributo vrGarantiaConstCartao.
     *
     * @param vrGarantiaConstCartao
     *            valor a ser atribuído
     */
    public void setVrGarantiaConstCartao(final BigDecimal vrGarantiaConstCartao) {
        this.vrGarantiaConstCartao = vrGarantiaConstCartao;
    }

    /**
     * Define o valor do atributo vrDiferencaCartao.
     *
     * @param vrDiferencaCartao
     *            valor a ser atribuído
     */
    public void setVrDiferencaCartao(final BigDecimal vrDiferencaCartao) {
        this.vrDiferencaCartao = vrDiferencaCartao;
    }

    /**
     * Define o valor do atributo vrGarantiaPactuadaCheque.
     *
     * @param vrGarantiaPactuadaCheque
     *            valor a ser atribuído
     */
    public void setVrGarantiaPactuadaCheque(final BigDecimal vrGarantiaPactuadaCheque) {
        this.vrGarantiaPactuadaCheque = vrGarantiaPactuadaCheque;
    }

    /**
     * Define o valor do atributo vrGarantiaConstCheque.
     *
     * @param vrGarantiaConstCheque
     *            valor a ser atribuído
     */
    public void setVrGarantiaConstCheque(final BigDecimal vrGarantiaConstCheque) {
        this.vrGarantiaConstCheque = vrGarantiaConstCheque;
    }

    /**
     * Define o valor do atributo vrDiferencaCheque.
     *
     * @param vrDiferencaCheque
     *            valor a ser atribuído
     */
    public void setVrDiferencaCheque(final BigDecimal vrDiferencaCheque) {
        this.vrDiferencaCheque = vrDiferencaCheque;
    }

    /**
     * Define o valor do atributo vrGarantiaPactuadaOutras.
     *
     * @param vrGarantiaPactuadaOutras
     *            valor a ser atribuído
     */
    public void setVrGarantiaPactuadaOutras(final BigDecimal vrGarantiaPactuadaOutras) {
        this.vrGarantiaPactuadaOutras = vrGarantiaPactuadaOutras;
    }

    /**
     * Define o valor do atributo vrGarantiaConstOutras.
     *
     * @param vrGarantiaConstOutras
     *            valor a ser atribuído
     */
    public void setVrGarantiaConstOutras(final BigDecimal vrGarantiaConstOutras) {
        this.vrGarantiaConstOutras = vrGarantiaConstOutras;
    }

    /**
     * Define o valor do atributo vrDiferencaOutras.
     *
     * @param vrDiferencaOutras
     *            valor a ser atribuído
     */
    public void setVrDiferencaOutras(final BigDecimal vrDiferencaOutras) {
        this.vrDiferencaOutras = vrDiferencaOutras;
    }

    /**
     * Define o valor do atributo vrGarantiaPactuadaTotal.
     *
     * @param vrGarantiaPactuadaTotal
     *            valor a ser atribuído
     */
    public void setVrGarantiaPactuadaTotal(final BigDecimal vrGarantiaPactuadaTotal) {
        this.vrGarantiaPactuadaTotal = vrGarantiaPactuadaTotal;
    }

    /**
     * Define o valor do atributo vrGarantiaConstTotal.
     *
     * @param vrGarantiaConstTotal
     *            valor a ser atribuído
     */
    public void setVrGarantiaConstTotal(final BigDecimal vrGarantiaConstTotal) {
        this.vrGarantiaConstTotal = vrGarantiaConstTotal;
    }

    /**
     * Define o valor do atributo vrDiferencaParcial.
     *
     * @param vrDiferencaParcial
     *            valor a ser atribuído
     */
    public void setVrDiferencaParcial(final BigDecimal vrDiferencaParcial) {
        this.vrDiferencaParcial = vrDiferencaParcial;
    }

    /**
     * Define o valor do atributo vrSaldoNLM.
     *
     * @param vrSaldoNLM
     *            valor a ser atribuído
     */
    public void setVrSaldoNLM(final BigDecimal vrSaldoNLM) {
        this.vrSaldoNLM = vrSaldoNLM;
    }

    /**
     * Define o valor do atributo totalPactuado4Garantias.
     *
     * @param totalPactuado4Garantias
     *            valor a ser atribuído
     */
    public void setTotalPactuado4Garantias(final BigDecimal totalPactuado4Garantias) {
        this.totalPactuado4Garantias = totalPactuado4Garantias;
    }

    /**
     * Define o valor do atributo statusGarantias.
     *
     * @param statusGarantias
     *            valor a ser atribuído
     */
    public void setStatusGarantias(final String statusGarantias) {
        this.statusGarantias = statusGarantias;
    }

    /**
     * Retorna o valor do atributo vrFaturamento.
     *
     * @return vrFaturamento
     */
    public BigDecimal getVrFaturamento() {
        if (!UtilObjeto.isReferencia(this.vrFaturamento)) {
            this.vrFaturamento = BigDecimal.ZERO;
        }
        return this.vrFaturamento;
    }

    /**
     * Define o valor do atributo vrFaturamento.
     *
     * @param vrFaturamento
     *            valor a ser atribuído
     */
    public void setVrFaturamento(final BigDecimal vrFaturamento) {
        this.vrFaturamento = vrFaturamento;
    }

    /**
     * Retorna o valor do atributo dtInicioInsuficiencia.
     *
     * @return dtInicioInsuficiencia
     */
    public Date getDtInicioInsuficiencia() {
        return this.dtInicioInsuficiencia;
    }

    /**
     * Retorna o valor do atributo diasGarantiaInsuficiente.
     *
     * @return diasGarantiaInsuficiente
     */
    public Integer getDiasGarantiaInsuficiente() {
        if (!UtilObjeto.isReferencia(this.diasGarantiaInsuficiente)) {
            if (UtilObjeto.isReferencia(this.getDtInicioInsuficiencia())) {
                this.diasGarantiaInsuficiente = UtilData.diferencaEmDiasEntreDatas(this.getDtInicioInsuficiencia(), new Date());
            } else {
                this.diasGarantiaInsuficiente = UtilData.diferencaEmDiasEntreDatas(new Date(), new Date());
            }
        }

        return this.diasGarantiaInsuficiente;
    }

    /**
     * Define o valor do atributo dtInicioInsuficiencia.
     *
     * @param dtInicioInsuficiencia
     *            valor a ser atribuído
     */
    public void setDtInicioInsuficiencia(final Date dtInicioInsuficiencia) {
        this.dtInicioInsuficiencia = dtInicioInsuficiencia;
    }

    /**
     * Define o valor do atributo diasGarantiaInsuficiente.
     *
     * @param diasGarantiaInsuficiente
     *            valor a ser atribuído
     */
    public void setDiasGarantiaInsuficiente(final Integer diasGarantiaInsuficiente) {
        this.diasGarantiaInsuficiente = diasGarantiaInsuficiente;
    }

    /**
     * Retorna o valor do atributo icPendenteParametrizacao.
     *
     * @return icPendenteParametrizacao
     */
    public Boolean getIcPendenteParametrizacao() {
        return this.icPendenteParametrizacao;
    }

    /**
     * Define o valor do atributo icPendenteParametrizacao.
     *
     * @param icPendenteParametrizacao
     *            valor a ser atribuído
     */
    public void setIcPendenteParametrizacao(final Boolean icPendenteParametrizacao) {
        this.icPendenteParametrizacao = icPendenteParametrizacao;
    }

    /**
     * Retorna o valor do atributo nuOperacao.
     *
     * @return nuOperacao
     */
    public Integer getNuOperacao() {
        return this.nuOperacao;
    }

    /**
     * Define o valor do atributo nuOperacao.
     *
     * @param nuOperacao
     *            valor a ser atribuído
     */
    public void setNuOperacao(final Integer nuOperacao) {
        this.nuOperacao = nuOperacao;
    }

    /**
     * Retorna o valor do atributo vrGarantiaPactuadaMaquinaEquipamento.
     *
     * @return vrGarantiaPactuadaMaquinaEquipamento
     */
    public BigDecimal getVrGarantiaPactuadaMaquinaEquipamento() {
        return UtilObjeto.isReferencia(this.vrGarantiaPactuadaMaquinaEquipamento) ? this.vrGarantiaPactuadaMaquinaEquipamento : BigDecimal.ZERO;
    }

    /**
     * Define o valor do atributo vrGarantiaPactuadaMaquinaEquipamento.
     *
     * @param vrGarantiaPactuadaMaquinaEquipamento
     *            valor a ser atribuído
     */
    public void setVrGarantiaPactuadaMaquinaEquipamento(BigDecimal vrGarantiaPactuadaMaquinaEquipamento) {
        this.vrGarantiaPactuadaMaquinaEquipamento = vrGarantiaPactuadaMaquinaEquipamento;
    }

    /**
     * Retorna o valor do atributo vrGarantiaCnstaMaquinaEquipamento.
     *
     * @return vrGarantiaCnstaMaquinaEquipamento
     */
    public BigDecimal getVrGarantiaCnstaMaquinaEquipamento() {
	return UtilObjeto.isReferencia(this.vrGarantiaCnstaMaquinaEquipamento) ? this.vrGarantiaCnstaMaquinaEquipamento : BigDecimal.ZERO;
    }

    /**
     * Define o valor do atributo vrGarantiaCnstaMaquinaEquipamento.
     *
     * @param vrGarantiaCnstaMaquinaEquipamento
     *            valor a ser atribuído
     */
    public void setVrGarantiaCnstaMaquinaEquipamento(BigDecimal vrGarantiaCnstaMaquinaEquipamento) {
        this.vrGarantiaCnstaMaquinaEquipamento = vrGarantiaCnstaMaquinaEquipamento;
    }

    /**
     * Retorna o valor do atributo vrDiferencaMaquinaEquipamento.
     *
     * @return vrDiferencaMaquinaEquipamento
     */
    public BigDecimal getVrDiferencaMaquinaEquipamento() {
	return UtilObjeto.isReferencia(this.vrDiferencaMaquinaEquipamento) ? this.vrDiferencaMaquinaEquipamento : BigDecimal.ZERO;
    }

    /**
     * Define o valor do atributo vrDiferencaMaquinaEquipamento.
     *
     * @param vrDiferencaMaquinaEquipamento
     *            valor a ser atribuído
     */
    public void setVrDiferencaMaquinaEquipamento(BigDecimal vrDiferencaMaquinaEquipamento) {
        this.vrDiferencaMaquinaEquipamento = vrDiferencaMaquinaEquipamento;
    }

    /**
     * Retorna o valor do atributo vrGarantiaPactuadaImovel.
     *
     * @return vrGarantiaPactuadaImovel
     */
    public BigDecimal getVrGarantiaPactuadaImovel() {
	return UtilObjeto.isReferencia(this.vrGarantiaPactuadaImovel) ? this.vrGarantiaPactuadaImovel : BigDecimal.ZERO;
    }

    /**
     * Define o valor do atributo vrGarantiaPactuadaImovel.
     *
     * @param vrGarantiaPactuadaImovel
     *            valor a ser atribuído
     */
    public void setVrGarantiaPactuadaImovel(BigDecimal vrGarantiaPactuadaImovel) {
        this.vrGarantiaPactuadaImovel = vrGarantiaPactuadaImovel;
    }

    /**
     * Retorna o valor do atributo vrGarantiaCnstaImovel.
     *
     * @return vrGarantiaCnstaImovel
     */
    public BigDecimal getVrGarantiaCnstaImovel() {
	return UtilObjeto.isReferencia(this.vrGarantiaCnstaImovel) ? this.vrGarantiaCnstaImovel : BigDecimal.ZERO;
    }

    /**
     * Define o valor do atributo vrGarantiaCnstaImovel.
     *
     * @param vrGarantiaCnstaImovel
     *            valor a ser atribuído
     */
    public void setVrGarantiaCnstaImovel(BigDecimal vrGarantiaCnstaImovel) {
        this.vrGarantiaCnstaImovel = vrGarantiaCnstaImovel;
    }

    /**
     * Retorna o valor do atributo vrDiferencaImovel.
     *
     * @return vrDiferencaImovel
     */
    public BigDecimal getVrDiferencaImovel() {
	return UtilObjeto.isReferencia(this.vrDiferencaImovel) ? this.vrDiferencaImovel : BigDecimal.ZERO;
    }

    /**
     * Define o valor do atributo vrDiferencaImovel.
     *
     * @param vrDiferencaImovel
     *            valor a ser atribuído
     */
    public void setVrDiferencaImovel(BigDecimal vrDiferencaImovel) {
        this.vrDiferencaImovel = vrDiferencaImovel;
    }

    /**
     * Retorna o valor do atributo vrGarantiaPactuadaProdutoAgricola.
     *
     * @return vrGarantiaPactuadaProdutoAgricola
     */
    public BigDecimal getVrGarantiaPactuadaProdutoAgricola() {
	return UtilObjeto.isReferencia(this.vrGarantiaPactuadaProdutoAgricola) ? this.vrGarantiaPactuadaProdutoAgricola : BigDecimal.ZERO;
    }

    /**
     * Define o valor do atributo vrGarantiaPactuadaProdutoAgricola.
     *
     * @param vrGarantiaPactuadaProdutoAgricola
     *            valor a ser atribuído
     */
    public void setVrGarantiaPactuadaProdutoAgricola(BigDecimal vrGarantiaPactuadaProdutoAgricola) {
        this.vrGarantiaPactuadaProdutoAgricola = vrGarantiaPactuadaProdutoAgricola;
    }

    /**
     * Retorna o valor do atributo vrGarantiaCnstaProdutoAgricola.
     *
     * @return vrGarantiaCnstaProdutoAgricola
     */
    public BigDecimal getVrGarantiaCnstaProdutoAgricola() {
	return UtilObjeto.isReferencia(this.vrGarantiaCnstaProdutoAgricola) ? this.vrGarantiaCnstaProdutoAgricola : BigDecimal.ZERO;
    }

    /**
     * Define o valor do atributo vrGarantiaCnstaProdutoAgricola.
     *
     * @param vrGarantiaCnstaProdutoAgricola
     *            valor a ser atribuído
     */
    public void setVrGarantiaCnstaProdutoAgricola(BigDecimal vrGarantiaCnstaProdutoAgricola) {
        this.vrGarantiaCnstaProdutoAgricola = vrGarantiaCnstaProdutoAgricola;
    }

    /**
     * Retorna o valor do atributo vrDiferencaProdutoAgricola.
     *
     * @return vrDiferencaProdutoAgricola
     */
    public BigDecimal getVrDiferencaProdutoAgricola() {
	return UtilObjeto.isReferencia(this.vrDiferencaProdutoAgricola) ? this.vrDiferencaProdutoAgricola : BigDecimal.ZERO;
    }

    /**
     * Define o valor do atributo vrDiferencaProdutoAgricola.
     *
     * @param vrDiferencaProdutoAgricola
     *            valor a ser atribuído
     */
    public void setVrDiferencaProdutoAgricola(BigDecimal vrDiferencaProdutoAgricola) {
        this.vrDiferencaProdutoAgricola = vrDiferencaProdutoAgricola;
    }

}
