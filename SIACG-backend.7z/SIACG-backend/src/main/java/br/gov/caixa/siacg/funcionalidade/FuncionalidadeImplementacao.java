/*
 * Copyright (c) 2016 Caixa Econômica Federal. Todos os direitos
 * reservados.
 *
 * Caixa Econômica Federal - SIACG
 *
 * Este software foi desenvolvido sob demanda da CAIXA e está
 * protegido por leis de direitos autorais e tratados internacionais. As
 * condições de cópia e utilização do todo ou partes dependem de autorização da
 * pessoa. Cópias não são permitidas sem expressa autorização. Não pode ser
 * comercializado ou utilizado para propósitos particulares.
 *
 * Uso exclusivo da Caixa Econômica Federal. A reprodução ou distribuição não
 * autorizada deste programa ou de parte dele, resultará em punições civis e
 * criminais e os infratores incorrem em sanções previstas na legislação em
 * vigor.
 *
 * Histórico do Subversion:
 *
 * LastChangedRevision: $Revision$
 * LastChangedBy: $Author$
 * LastChangedDate: $Date$
 *
 * HeadURL: $HeadURL$
 *
 */
package br.gov.caixa.siacg.funcionalidade;

import java.io.PrintWriter;
import java.io.StringWriter;
import java.text.NumberFormat;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import br.gov.caixa.pedesgo.arquitetura.util.UtilObjeto;
import br.gov.caixa.pedesgo.arquitetura.util.UtilString;
import br.gov.caixa.pedesgo.arquitetura.to.TemplateMensageriaTO;
import br.gov.caixa.pedesgo.arquitetura.enumerador.EnumFalha;
import br.gov.caixa.pedesgo.arquitetura.util.LogCefUtil;
import br.gov.caixa.siacg.dao.OperacaoSistemaDAO;
import br.gov.caixa.siacg.model.domain.OperacaoSistema;
import br.gov.caixa.siacg.model.enums.CampoSelecionavelEnum;
import br.gov.caixa.siacg.model.enums.DestinatarioEnum;
import br.gov.caixa.siacg.model.vo.ContratoVO;
import br.gov.caixa.siacg.util.FormatUtils;

/**
 * <p>
 * FuncionalidadeImplementacao.
 * </p>
 * <p>
 * Descrição: Classe abstrata que define o contrato que as funcoes devem seguir
 * no sistema
 * </p>
 * <br>
 * <b>Empresa:</b> Cef - Caixa Econômica Federal
 *
 * @author Bruno Martins de Carvalho
 * @version 1.0
 */
public abstract class FuncionalidadeImplementacao extends IFuncionalidade {

    /** Atributo DIFERENCA. */
    private static final String DIFERENCA = "Diferença (R$)";
    /** Atributo GARANTIA_CONSTITUIDA. */
    private static final String GARANTIA_CONSTITUIDA = "Garantia Constituída (R$)";
    /** Atributo GARANTIA_PACTUADA. */
    private static final String GARANTIA_PACTUADA = "Garantia Pactuada (R$)";
    /** Atributo CLIENTE_CABECALHO. */
    private static final String CLIENTE_CABECALHO = "Cliente";
    /** Atributo CONTRATO_CABECALHO. */
    private static final String CONTRATO_CABECALHO = "Contrato";
    /** Atributo OPERACAO_CABECALHO. */
    private static final String OPERACAO_CABECALHO = "Operacao";
    /** Atributo UNIDADE_CABECALHO. */
    private static final String UNIDADE_CABECALHO = "Unidade";
    /** Atributo SR_CABECALHO. */
    private static final String SR_CABECALHO = "SR";
    /** Atributo SUAT_CABECALHO. */
    private static final String SUAT_CABECALHO = "SUAT";

    /** Atributo CODIGO_GESTOR_RISCO. */
    private static final String CODIGO_GESTOR_RISCO = "03";
    /** Atributo CODIGO_AUDITORIA. */
    private static final String CODIGO_AUDITORIA = "02";
    /** Atributo CODIGO_GESTOR_SISTEMA. */
    private static final String CODIGO_GESTOR_SISTEMA = "01";

    /** Atributo TRACO. */
    private static final String TRACO = " - ";

    /** Atributo VAZIO. */
    private static final String VAZIO = "";

    /** Atributo ESPACO. */
    private static final String ESPACO = " ";

    /** Atributo mapaOperacaoSistema. */
    private Map<String, String> mapaOperacaoSistema;

    /**
     * @see br.gov.caixa.siacg.funcionalidade.IFuncionalidade#getNome()
     */
    @Override
    public abstract String getNome();

    /**
     * @see br.gov.caixa.siacg.funcionalidade.IFuncionalidade#getNomeOpcional()
     */
    @Override
    public abstract String getNomeOpcional();

    /**
     * @see br.gov.caixa.siacg.funcionalidade.IFuncionalidade#getDescricao()
     */
    @Override
    public abstract String getDescricao();

    /**
     * @see br.gov.caixa.siacg.funcionalidade.IFuncionalidade#traduzirTemplate(br.gov.caixa.pedesgo.arquitetura.comum.to.TemplateMensageriaTO)
     */
    @Override
    public abstract Collection<TemplateMensageriaTO> traduzirTemplate(TemplateMensageriaTO templateMensageriaTO);

    /**
     * @see br.gov.caixa.siacg.funcionalidade.IFuncionalidade#substituirTagTexto(java.lang.String,
     *      java.util.List, java.lang.Integer)
     */
    @Override
    public String substituirTagTexto(String texto, final List<ContratoVO> listaContratoEnvio) {

        if (UtilObjeto.isReferencia(texto)) {

            final ContratoVO contrato = listaContratoEnvio.get(0);

            if (texto.contains(CampoSelecionavelEnum.SUAT.getTag()) && UtilObjeto.isReferencia(contrato)
                    && !UtilString.isVazio(contrato.getNomeSuat()) && UtilObjeto.isReferencia(contrato.getNuSuat())) {

                texto = UtilString.substituirString(texto, CampoSelecionavelEnum.SUAT.getTag(),
                        CampoSelecionavelEnum.SUAT.getNome().concat(FuncionalidadeImplementacao.ESPACO).concat(contrato.getNuSuat().toString())
                                .concat(FuncionalidadeImplementacao.TRACO).concat(contrato.getNomeSuat().trim()));
            }

            if (texto.contains(CampoSelecionavelEnum.SR.getTag()) && UtilObjeto.isReferencia(contrato) && !UtilString.isVazio(contrato.getNomeSr())
                    && UtilObjeto.isReferencia(contrato.getNuSr())) {

                texto = UtilString.substituirString(texto, CampoSelecionavelEnum.SR.getTag(),
                        CampoSelecionavelEnum.SR.getNome().concat(FuncionalidadeImplementacao.ESPACO).concat(contrato.getNuSr().toString())
                                .concat(FuncionalidadeImplementacao.TRACO).concat(contrato.getNomeSr().trim()));
            }

            if (texto.contains(CampoSelecionavelEnum.UNIDADE.getTag()) && UtilObjeto.isReferencia(contrato)
                    && !UtilString.isVazio(contrato.getNomeUnidade()) && UtilObjeto.isReferencia(contrato.getNuUnidade())) {

                texto = UtilString.substituirString(texto, CampoSelecionavelEnum.UNIDADE.getTag(),
                        CampoSelecionavelEnum.UNIDADE.getNome().concat(FuncionalidadeImplementacao.ESPACO).concat(contrato.getNuUnidade().toString())
                                .concat(FuncionalidadeImplementacao.TRACO).concat(contrato.getNomeUnidade().trim()));
            }

            if (texto.contains(CampoSelecionavelEnum.LISTA_CONTRATO.getTag()) && UtilObjeto.isReferencia(listaContratoEnvio)) {

                texto = texto.replace(CampoSelecionavelEnum.LISTA_CONTRATO.getTag(), this.montarGridContratos(listaContratoEnvio));
            }
        }

        return texto;
    }

    /**
     * @see br.gov.caixa.siacg.funcionalidade.IFuncionalidade#montarGridContratos(java.util.Collection)
     */
    @Override
    public String montarGridContratos(final Collection<ContratoVO> listaContrato) {

        final StringBuffer retorno = new StringBuffer();//NOSONAR

        retorno.append("<html>");
        retorno.append("<head>");

        retorno.append("<style type=\"text/css\">");
        retorno.append(".cabecalho{ ");
        retorno.append("background: #0039ba !important; ");
        retorno.append("padding: 4px 10px; ");
        retorno.append("border-bottom: 1px solid white; ");
        retorno.append("border-top: 1px solid #ffffff; ");
        retorno.append("color: #ffffff; ");
        retorno.append("margin-top: -1px; ");
        retorno.append("font-weight: bold; ");
        retorno.append("} ");
        retorno.append("</style> ");

        retorno.append("</head>");
        retorno.append("<body>");

        retorno.append("<table>");
        // Colunas de titulos
        retorno.append("<tr>");

        retorno.append("<td align=\"center\" class=\"cabecalho\">");
        retorno.append(FuncionalidadeImplementacao.SUAT_CABECALHO);
        retorno.append("</td>");

        retorno.append("<td align=\"center\" class=\"cabecalho\">");
        retorno.append(FuncionalidadeImplementacao.SR_CABECALHO);
        retorno.append("</td>");

        retorno.append("<td align=\"center\" class=\"cabecalho\">");
        retorno.append(FuncionalidadeImplementacao.UNIDADE_CABECALHO);
        retorno.append("</td>");

        retorno.append("<td align=\"center\" class=\"cabecalho\">");
        retorno.append(FuncionalidadeImplementacao.OPERACAO_CABECALHO);
        retorno.append("</td>");

        retorno.append("<td align=\"center\" class=\"cabecalho\">");
        retorno.append(FuncionalidadeImplementacao.CONTRATO_CABECALHO);
        retorno.append("</td>");

        retorno.append("<td align=\"center\" class=\"cabecalho\">");
        retorno.append(FuncionalidadeImplementacao.CLIENTE_CABECALHO);
        retorno.append("</td>");

        retorno.append("<td align=\"center\" class=\"cabecalho\">");
        retorno.append(FuncionalidadeImplementacao.GARANTIA_PACTUADA);
        retorno.append("</td>");

        retorno.append("<td align=\"center\" class=\"cabecalho\">");
        retorno.append(FuncionalidadeImplementacao.GARANTIA_CONSTITUIDA);
        retorno.append("</td>");

        retorno.append("<td align=\"center\" class=\"cabecalho\">");
        retorno.append(FuncionalidadeImplementacao.DIFERENCA);
        retorno.append("</td>");

        retorno.append("</tr>");

        for (final ContratoVO contrato : listaContrato) {
            // linhas com valores
            retorno.append("<tr>");

            retorno.append("<td>");
            retorno.append(contrato.getNomeSuat().trim());
            retorno.append("</td>");

            retorno.append("<td>");
            retorno.append(contrato.getNomeSr().trim());
            retorno.append("</td>");

            retorno.append("<td>");
            retorno.append(contrato.getNomeUnidade().trim());
            retorno.append("</td>");

            retorno.append("<td>");
            retorno.append(contrato.getNuOperacao() == null ? "" : contrato.getNuOperacao());
            retorno.append("</td>");

            retorno.append("<td>");
            retorno.append(this.formatarCodigoContrato(contrato));
            retorno.append("</td>");

            retorno.append("<td>");
            if (UtilObjeto.isReferencia(contrato.getNomePessoa())) {
                retorno.append(contrato.getNomePessoa());
            } else {
                retorno.append(contrato.getCnpjPessoa());
            }
            retorno.append("</td>");

            retorno.append("<td align=\"right\">");
            retorno.append(NumberFormat.getCurrencyInstance().format(contrato.getVrEsperadoTotal()));
            retorno.append("</td>");

            retorno.append("<td align=\"right\">");
            retorno.append(NumberFormat.getCurrencyInstance().format(contrato.getVrApuradoTotal()));
            retorno.append("</td>");

            retorno.append("<td align=\"right\">");
            retorno.append(NumberFormat.getCurrencyInstance().format(contrato.getVrDiferencaApuradoEsperadoTotal()));
            retorno.append("</td>");

            retorno.append("</tr>");
        }

        retorno.append("</table>");

        retorno.append("</body>");

        retorno.append("</html>");
        return retorno.toString();
    }

    /**
     * <p>
     * Método responsável por formatar o codigo do contrato.
     * <p>
     *
     * @param contrato
     *            valor a ser atribuido
     * @return String
     * @author Bruno Martins de Carvalho
     */
    private String formatarCodigoContrato(final ContratoVO contrato) {

        String contratoFormatado = FuncionalidadeImplementacao.VAZIO;
        final Map<String, String> mapOperSistema = this.getMapaOperacaoSistema();

        if (UtilObjeto.isReferencia(contrato.getCoContrato())) {
            String mascara;
            
            if (contrato.getCoContrato().length() <= 16) {
                mascara = mapOperSistema.get(contrato.getCoContrato().substring(4, 7));
            } else {
                mascara = mapOperSistema.get(contrato.getCoContrato().substring(4, 8));
            }

            if (!UtilString.isVazio(mascara)) {
                contratoFormatado = FormatUtils.applyMask(mascara, contrato.getCoContrato());
            }
        }

        return contratoFormatado;
    }

    /**
     * <p>
     * Método responsável por obter o mapa de operação do sistema.
     * <p>
     *
     * @return Map
     * @author Bruno Martins de Carvalho
     */
    public Map<String, String> getMapaOperacaoSistema() {

        if (!UtilObjeto.isReferencia(this.mapaOperacaoSistema)) {

            this.mapaOperacaoSistema = new HashMap<>();

            final Collection<OperacaoSistema> listaSistemas = this.getOperacaoSistemaDAO().listar();

            for (final OperacaoSistema operacaoSistema : listaSistemas) {

                this.mapaOperacaoSistema.put(operacaoSistema.getNuOperacao(), operacaoSistema.getDeMascara());
            }

        }

        return this.mapaOperacaoSistema;
    }

    /**
     * @see br.gov.caixa.siacg.funcionalidade.IFuncionalidade#getOperacaoSistemaDAO()
     */
    @Override
    public abstract OperacaoSistemaDAO getOperacaoSistemaDAO();

    /**
     * <p>
     * Método responsável por obter o email do destinatario passado por
     * parametro.
     * <p>
     *
     * @param destinatario
     *            valor a ser atribuido
     * @param nuUnidade
     *            valor a ser atribuido
     * @return Collection<String>
     * @author Waltenes Junior
     */
    public Collection<String> obterDestinatario(final String destinatario, final ContratoVO nuUnidade) {

        final Collection<String> retorno = new ArrayList<>();

        if (destinatario.equals(DestinatarioEnum.UNIDADE.getNome())) {
            retorno.add(nuUnidade.getCoEmailUnidade().trim());
        }

        if (destinatario.equals(DestinatarioEnum.SR.getNome())) {
            retorno.add(nuUnidade.getCoEmailSr().trim());
        }

        if (destinatario.equals(DestinatarioEnum.SUAT.getNome())) {
            retorno.add(nuUnidade.getCoEmailSuat().trim());
        }

        if (destinatario.equals(DestinatarioEnum.GESTOR_SISTEMA.getNome())) {
            retorno.addAll(
                    this.getDestinatarioService().listarEmailDestinatarioPorTipoDestinatario(FuncionalidadeImplementacao.CODIGO_GESTOR_SISTEMA));
        }

        if (destinatario.equals(DestinatarioEnum.AUDITORIA.getNome())) {
            retorno.addAll(this.getDestinatarioService().listarEmailDestinatarioPorTipoDestinatario(FuncionalidadeImplementacao.CODIGO_AUDITORIA));
        }

        if (destinatario.equals(DestinatarioEnum.GESTOR_RISCO.getNome())) {
            retorno.addAll(this.getDestinatarioService().listarEmailDestinatarioPorTipoDestinatario(FuncionalidadeImplementacao.CODIGO_GESTOR_RISCO));
        }

        if (retorno.isEmpty()) {
            retorno.add(destinatario);
        }

        return retorno;
    }
    
    /**
     * <p>
     * Método responsável por agrupar os contratos em um templateMensageria por
     * Unidade.
     * <p>
     *
     * @param listaContrato
     *            valor a ser atribuido
     * @param templateMensageriaTO
     *            valor a ser atribuido
     * @return Map<Integer, TemplateMensageriaTO>
     * @author Bruno Martins de Carvalho
     */
    public Map<Integer, TemplateMensageriaTO> agruparContratosPorUnidade(final Collection<ContratoVO> listaContrato,
            final TemplateMensageriaTO templateMensageriaTO) {

        final List<Integer> listaUnidade = new ArrayList<>();
        final Map<Integer, TemplateMensageriaTO> mapaUnidadeTemplate = new LinkedHashMap<>();

        for (final ContratoVO contrato : listaContrato) {
            if (!listaUnidade.contains(contrato.getNuUnidade())) {
                listaUnidade.add(contrato.getNuUnidade());
            }
        }

        TemplateMensageriaTO novoTemplate;

        for (final Integer nuUnidade : listaUnidade) {
            novoTemplate = UtilObjeto.clone(templateMensageriaTO);

            try {
                final List<ContratoVO> listaContratoPorUnidade = new ArrayList<>();

                novoTemplate.setNuUnidade(nuUnidade);

                for (final ContratoVO contrato : listaContrato) {
                    if (contrato.getNuUnidade().equals(nuUnidade) && !listaContratoPorUnidade.contains(contrato)) {
                        listaContratoPorUnidade.add(contrato);
                    }
                }
                // Remove da lista de contrato pois ja foram atribuidos a uma
                // unidade.
                listaContrato.removeAll(listaContratoPorUnidade);

                novoTemplate.setDeTextoMensageria(this.substituirTagTexto(novoTemplate.getDeTextoMensageria(), listaContratoPorUnidade));
                novoTemplate.setNoAssuntoMensageria(this.substituirTagTexto(novoTemplate.getNoAssuntoMensageria(), listaContratoPorUnidade));

                this.preencherListasDestinatarios(novoTemplate, listaContratoPorUnidade.get(0));

            } catch (UnsupportedOperationException | ClassCastException | NullPointerException | StringIndexOutOfBoundsException e) {
            	LogCefUtil.error(e);
                final StringWriter sw = new StringWriter();
                e.printStackTrace(new PrintWriter(sw));

                novoTemplate.setCausaErro(sw.toString());
                novoTemplate.setIcTipoFalha(EnumFalha.PROCESSAMENTO.getNuFalha());
            } finally {
                mapaUnidadeTemplate.put(nuUnidade, novoTemplate);
            }
        }

        return mapaUnidadeTemplate;
    }
    
    /**
     * <p>
     * Método responsável por preencher a listas de destinatarios e
     * destinatarios cópia.
     * <p>
     *
     * @param templateMensageriaTO
     *            valor a ser atribuido
     * @param contrato
     *            valor a ser atribuido
     * @author Bruno Martins de Carvalho
     */
    private void preencherListasDestinatarios(final TemplateMensageriaTO templateMensageriaTO, final ContratoVO contrato) {

        final List<String> destinatarios = new ArrayList<>();
        final List<String> destinatariosCopia = new ArrayList<>();

        for (final String destinatario : templateMensageriaTO.getListaDestinatarios()) {
            final Collection<String> lista = this.obterDestinatario(destinatario, contrato);
            if (!destinatarios.containsAll(lista)) {
                destinatarios.addAll(lista);
            }
        }
        for (final String destinatarioCopia : templateMensageriaTO.getListaDestinatariosCopia()) {
            final Collection<String> lista = this.obterDestinatario(destinatarioCopia, contrato);
            if (!destinatariosCopia.containsAll(lista)) {
                destinatariosCopia.addAll(lista);
            }
        }
        templateMensageriaTO.setListaDestinatarios(UtilObjeto.clone(destinatarios));
        templateMensageriaTO.setListaDestinatariosCopia(UtilObjeto.clone(destinatariosCopia));
    }
    
    /**
     * <p>
     * Método responsável por agrupar os contratos.
     * <p>
     *
     * @param listaContrato
     *            valor a ser atribuido
     * @param templateMensageriaTO
     *            valor a ser atribuido
     * @return Map
     * @author Bruno Martins de Carvalho
     */
    public Map<Integer, TemplateMensageriaTO> agruparContratos(final Collection<ContratoVO> listaContrato,
            final TemplateMensageriaTO templateMensageriaTO) {

        return this.agruparContratosPorUnidade(listaContrato, templateMensageriaTO);
    }
}
