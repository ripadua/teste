/*
 * Copyright (c) 2021 Caixa Econômica Federal. Todos os direitos
 * reservados.
 *
 * Caixa Econômica Federal - SIACG - Sistema de Crédito Rural
 *
 * Este software foi desenvolvido sob demanda da CAIXA e está
 * protegido por leis de direitos autorais e tratados internacionais. As
 * condições de cópia e utilização do todo ou partes dependem de autorização da
 * empresa. Cópias não são permitidas sem expressa autorização. Não pode ser
 * comercializado ou utilizado para propósitos particulares.
 *
 * Uso exclusivo da Caixa Econômica Federal. A reprodução ou distribuição não
 * autorizada deste programa ou de parte dele, resultará em punições civis e
 * criminais e os infratores incorrem em sanções previstas na legislação em
 * vigor.
 *
 * Histórico do TFS:
 *
 * LastChangedRevision: $Revision$
 * LastChangedBy: $Author$
 * LastChangedDate: $Date$
 *
 * HeadURL: $HeadURL$
 *
 */	
package br.gov.caixa.siacg.view.mb;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import javax.enterprise.context.SessionScoped;
import javax.faces.context.FacesContext;
import javax.inject.Inject;
import javax.inject.Named;

import org.primefaces.context.RequestContext;

import br.gov.caixa.pedesgo.arquitetura.controlador.ManutencaoBean;
import br.gov.caixa.pedesgo.arquitetura.enums.EnumExtensaoArquivo;
import br.gov.caixa.pedesgo.arquitetura.relatorio.UtilRelatorio;
import br.gov.caixa.pedesgo.arquitetura.siico.util.DataUtil;
import br.gov.caixa.pedesgo.arquitetura.util.LogCefUtil;
import br.gov.caixa.pedesgo.arquitetura.util.UsuarioUtil;
import br.gov.caixa.pedesgo.arquitetura.util.UtilData;
import br.gov.caixa.pedesgo.arquitetura.util.UtilObjeto;
import br.gov.caixa.pedesgo.arquitetura.util.UtilString;
import br.gov.caixa.siacg.comum.to.AvaliacaoTO;
import br.gov.caixa.siacg.comum.to.RespostaAvaliacaoImovelTO;
import br.gov.caixa.siacg.comum.to.RespostaLaudoEngenhariaTO;
import br.gov.caixa.siacg.model.domain.Contrato;
import br.gov.caixa.siacg.model.domain.HistoricoCalculoValorImovel;
import br.gov.caixa.siacg.model.domain.Imovel;
import br.gov.caixa.siacg.model.enums.EstadoOcupacaoImovelEnum;
import br.gov.caixa.siacg.model.enums.OrigemContratoHabitacionalEnum;
import br.gov.caixa.siacg.model.vo.ComprovanteCalculoValorImovelVO;
import br.gov.caixa.siacg.model.vo.HistoricoCalculoValorImoveFiltroVO;
import br.gov.caixa.siacg.pagination.HistoricoCalculoValorImovelLazyModel;
import br.gov.caixa.siacg.service.ContratoService;
import br.gov.caixa.siacg.service.HistoricoCalculoValorImovelService;
import br.gov.caixa.siacg.service.ImovelService;
import br.gov.caixa.siacg.service.OrigemFinanceiraService;
import br.gov.caixa.siacg.service.ValorDesagioService;
import br.gov.caixa.siacg.util.LogCEF;
import br.gov.caixa.siacg.view.form.HistoricoCalculoValorImovelVisao;
import br.gov.caixa.siacg.webservice.AvaliacaoImovelWS;

/**
 * <p>CalculoValorImovelMB</p>
 *
 * <p>Descrição: Descrição do tipo</p>
 *
 * <br><b>Empresa:</b> Cef - Caixa Econômica Federal
 *
 *
 * @author gerusa.soares
 *
 * @version 1.0
*/
@Named
@SessionScoped
public class CalculoValorImovelMB extends ManutencaoBean<HistoricoCalculoValorImovel> {
    
    /** Atributo serialVersionUID. */
    private static final long serialVersionUID = 1L;

    /** Atributo PREFIXO_CASO_USO. */
    private static final String PREFIXO_CASO_USO = "calculoValorImovel";

    /** Atributo NOME_MANAGED_BEAN. */
    public static final String NOME_MANAGED_BEAN = "calculoValorImovelMB";

    /** Atributo EL_MANAGED_BEAN. */
    public static final String EL_MANAGED_BEAN = "#{calculoValorImovelMB}";

    /** Atributo PAGINA_CONSULTA_CALCULO_VALOR_IMOVEL. */
    private static final String PAGINA_CONSULTA_CALCULO_VALOR_IMOVEL = "/pages/execucao/calculoValorImovel/consulta.xhtml?faces-redirect=true";
    
    private static final String PAGINA_INCLUSAO_CALCULO_VALOR_IMOVEL = "/pages/execucao/calculoValorImovel/inclusao.xhtml?faces-redirect=true";
    
    private static final String CAMINHO_RELATORIO_CALCULO_PDF = "/reports/calculo_valor_imovel_pdf.jasper";
    
    private static final String NOME_RELATORIO_CALCULO = "comprovante_calculo_valor_justo";
    
    @Inject
    private HistoricoCalculoValorImovelLazyModel consultaHistoricoCalculo;
    
    @Inject
    private HistoricoCalculoValorImovelService historicoCalculoValorImovelService;
    
    @Inject
    private ContratoService contratoService;
    
    @Inject
    private ImovelService imovelService;
    
    @Inject
    private OrigemFinanceiraService origemFinanceiraService;
    
    @Inject
    private ValorDesagioService valorDesagioService;
    
    @Inject
    private AvaliacaoImovelWS avaliacaoImovelWS;
    
    private HistoricoCalculoValorImovelVisao visao;
    
    /** Atributo mapOrigemFinaceira nuProduto| icOrigem. */
    private Map<Short, String> mapOrigemFinaceira = new HashMap<>();
    
    /** Atributo mapValorDesagio icOrigem-icEstado | vrDesagio. */
    private Map<String, BigDecimal> mapValorDesagio = new HashMap<>();

    /**
     * @see br.gov.caixa.pedesgo.arquitetura.controlador.AbstractBean#getPrefixoCasoDeUso()
    */
    @Override
    protected String getPrefixoCasoDeUso() {
	return CalculoValorImovelMB.PREFIXO_CASO_USO;
    }

    /**
     * @see br.gov.caixa.pedesgo.arquitetura.controlador.AbstractBean#getService()
    */
    @SuppressWarnings("unchecked")
    @Override
    public HistoricoCalculoValorImovelService getService() {
	return this.historicoCalculoValorImovelService;
    }

    public HistoricoCalculoValorImovelLazyModel getConsultaHistoricoCalculo() {
        return this.consultaHistoricoCalculo;
    }

    public void setConsultaHistoricoCalculo(final HistoricoCalculoValorImovelLazyModel consultaHistoricoCalculo) {
        this.consultaHistoricoCalculo = consultaHistoricoCalculo;
    }
    
    /**
     * @see br.gov.caixa.pedesgo.arquitetura.controlador.AbstractBean#getVisao()
     */
    @Override
    public HistoricoCalculoValorImovelVisao getVisao() {
	if(!UtilObjeto.isReferencia(this.visao)) {
	    this.visao = new HistoricoCalculoValorImovelVisao();
	}
	return this.visao;
    }
    
    public void setVisao(HistoricoCalculoValorImovelVisao visao) {
        this.visao = visao;
    }
    
    public String limparTelaAbrirConsulta() {
	this.getVisao().setDesabilitaBotaoNovo(true);
	this.consultaHistoricoCalculo.setFiltroPesquisa(new HistoricoCalculoValorImoveFiltroVO());
	return this.abrirConsulta();
    }
    
    private String abrirConsulta() {
	this.carregar();
	return CalculoValorImovelMB.PAGINA_CONSULTA_CALCULO_VALOR_IMOVEL;
    }

    public String filtrar() {
	if(!this.consultaHistoricoCalculo.isExisteFiltro(this.consultaHistoricoCalculo.getFiltroPesquisa())) {
	    super.adicionaMensagemDeAlerta("Informe ao menos um filtro.");
	    return "";
	}
	
	final Date dtCalculoInicio = this.consultaHistoricoCalculo.getFiltroPesquisa().getDtCalculoInicio();
	if(UtilData.verificarSeDataEhMaior(dtCalculoInicio, new Date())) {
	    super.adicionaMensagemDeAlerta("Data Início do Período deve ser menor ou igual a Data Atual.");
	    return "";
	}
	
	final Date dtCalculoFim = this.consultaHistoricoCalculo.getFiltroPesquisa().getDtCalculoFim();
	if(UtilData.verificarSeDataEhMaior(dtCalculoInicio, dtCalculoFim)) {
	    super.adicionaMensagemDeAlerta("Data Início do Período deve ser menor que Data Fim.");
	    return "";
	}
	
	this.getVisao().setDesabilitaBotaoNovo(false);
	return this.abrirConsulta();
    }
    
    public String abrirPaginaNovoCalculo() {
	this.setVisao(new HistoricoCalculoValorImovelVisao());
	return CalculoValorImovelMB.PAGINA_INCLUSAO_CALCULO_VALOR_IMOVEL;
    }
    
    public void listarImovelContrato() {

	this.getVisao().getEntidade().setContrato(new Contrato());
	this.getVisao().getEntidade().setImovel(new Imovel());
	this.getVisao().setListaImoveisContrato(new ArrayList<Imovel>());
	
	String coIdentificadorContrato = !UtilString.isVazio(this.getVisao().getCoIdentificadorContrato()) ? this.getVisao().getCoIdentificadorContrato().replace("_", "").trim() : "";

	if (!UtilString.isVazio(coIdentificadorContrato)) {

	    final Contrato contrato = this.contratoService.obterContratoHabitacionalPorCoContrato(coIdentificadorContrato);
	    if (!UtilObjeto.isReferencia(contrato) || !UtilObjeto.isReferencia(contrato.getNuContrato())) {
		super.adicionaMensagemDeAlerta("Contrato Habitacional " + coIdentificadorContrato + " não encontrado.");
		return;
	    }
	    
	    this.getVisao().getEntidade().setContrato(contrato);
	    
	    final List<Imovel> listaImovel = this.imovelService.listarImovelPorNuContrato(contrato.getNuContrato());
		
	    if (UtilObjeto.isVazio(listaImovel)) {
		super.adicionaMensagemDeAlerta("Não foram encontrados imóveis vinculados ao contrato " + coIdentificadorContrato);
		
	    } else if(listaImovel.size() > 1) {
		this.getVisao().setListaImoveisContrato(listaImovel);
		RequestContext.getCurrentInstance().execute("modalSelecionarImovelWidget.show();");
		
	    } else {
		this.getVisao().getEntidade().setImovel(listaImovel.get(0));
		this.listarAvaliacaoImovel();
	    }
	}
	
    }
    
    public String voltar() {
	this.getVisao().setDesabilitaBotaoNovo(false);
	this.consultaHistoricoCalculo.setFiltroPesquisa(new HistoricoCalculoValorImoveFiltroVO());
	return this.abrirConsulta();
    }
    
    public void listarAvaliacaoImovel() {
	
	this.getVisao().setListaAvaliacaoImovel(new ArrayList<AvaliacaoTO>());
	this.getVisao().setAvaliacaoImovelSelecionada(null);
	
	final Imovel imovelVisao = this.getVisao().getEntidade().getImovel();
	final Long matricula = imovelVisao.getNuMatricula();
	final String livro = imovelVisao.getLivroServentia();
	final String cartorio = imovelVisao.getGestaoServentia().getCodigoCns();
	
	try {
	    
	    final RespostaAvaliacaoImovelTO retorno = this.avaliacaoImovelWS.buscarAvaliacoesImoveisDadosImovel(matricula, livro, cartorio);
	    
	    
	    if(retorno != null && retorno.getAvaliacao() != null && !UtilObjeto.isVazio(retorno.getAvaliacao().getListaAvaliacoes())) {
		
		 if (retorno.getAvaliacao().getListaAvaliacoes().size() > 1) {
			this.getVisao().setListaAvaliacaoImovel(retorno.getAvaliacao().getListaAvaliacoes());
			RequestContext.getCurrentInstance().execute("modalAvaliacaoImovelWidget.show();");
			
		    } else {
			
			final AvaliacaoTO avaliacaoTO = retorno.getAvaliacao().getListaAvaliacoes().get(0);
			
			this.getVisao().setAvaliacaoImovelSelecionada(avaliacaoTO);
			this.getVisao().getEntidade().getImovel().setDataAvaliacao(avaliacaoTO.getDataAbertura());
			this.getVisao().getEntidade().getImovel().setCoOrdemServicoAvaliacao(avaliacaoTO.getOrdemServico());
			
			this.adicionaMensagemDeSucesso("Consulta do Número O.S e Data da Avaliação realizada com sucesso.");
			
			this.consultarValorAvaliacao();
		    }
	    } else {
		super.adicionaMensagemDeAlerta("Não houve retorno na consulta aos dados da Avaliação do imóvel.");
	    }
	    
	} catch (Exception e) {
	    LogCEF.debug(e);
	    
	    super.adicionaMensagemDeAlerta("Não foi possível consultar as avaliações do imóvel.");
	    
	    final String detalhe = e.getCause() != null ? e.getCause().getMessage() : "";
	    if(!UtilString.isVazio(detalhe)) {
		super.adicionaMensagemDeAlerta(detalhe);
	    }
	}
	
    }

    public void consultarValorAvaliacao() {
	
	try {
	    
	    final Integer codigoImovel = this.getVisao().getAvaliacaoImovelSelecionada().getImovel().getCodigoImovel();
	    final BigInteger identificacaoAvaliacao = this.getVisao().getAvaliacaoImovelSelecionada().getIdentificacaoAvaliacao();

	    final RespostaLaudoEngenhariaTO laudo = this.avaliacaoImovelWS.buscarLaudoPorCodigoImovelAndIdentAvaliacao(codigoImovel, identificacaoAvaliacao);
	    if (laudo != null && laudo.getLaudoEngenharia() != null) {
		this.getVisao().getEntidade().getImovel().setValorAvaliacao(laudo.getLaudoEngenharia().getValorAvaliacao());
		
		if (laudo.getLaudoEngenharia().getDataRegistroLaudo() != null) {
		    this.getVisao().getEntidade().getImovel().setDataAvaliacao(UtilData.converterStringParaDate(laudo.getLaudoEngenharia().getDataRegistroLaudo(), "yyyy/MM/dd"));
		}
		
		this.adicionaMensagemDeSucesso("Consulta do Valor da Avaliação realizada com sucesso.");
		
	    } else {
		super.adicionaMensagemDeAlerta("Não houve retorno na consulta do Valor da Avaliação do imóvel.");
	    }
	    
	} catch (Exception e) {
	    LogCEF.debug(e);

	    super.adicionaMensagemDeAlerta("Não foi possível consultar o Valor da Avaliação.");
	    
	    final String detalhe = e.getCause() != null ? e.getCause().getMessage() : "";
	    if(!UtilString.isVazio(detalhe)) {
		super.adicionaMensagemDeAlerta(detalhe);
	    }
	}
    }
    
    public void solicitarCalculoValorJustoImovel() {
	
	this.limparParametrosCalculo();
	
	final Imovel imovel = this.getVisao().getEntidade().getImovel();
	final BigDecimal vrAvaliacao = imovel.getValorAvaliacao();
	final boolean vrAvaliacaoInvalido = !UtilObjeto.isReferenciaNumeroPositivo(vrAvaliacao);
	if(vrAvaliacaoInvalido) {
	    super.adicionaMensagemDeAlerta("Valor Avaliação é obrigatório.");
	}
	
	final String icEstadoOcupacao = imovel.getIcEstadoOcupacao();
	final boolean estadoOcupacaoInvalido = UtilString.isVazio(icEstadoOcupacao);
	if(estadoOcupacaoInvalido) {
	    super.adicionaMensagemDeAlerta("Estado Ocupação é obrigatório.");
	}
	
	final Date dtAvaliacao = imovel.getDataAvaliacao();
	final boolean dtAvaliacaoInvalida = UtilObjeto.isReferencia(dtAvaliacao) && DataUtil.verificarSeDataEhMaior(dtAvaliacao, new Date());
	if(dtAvaliacaoInvalida) {
	    super.adicionaMensagemDeAlerta("Data Avaliação deve ser menor ou igual Data Atual.");
	}
	
	if(vrAvaliacaoInvalido || estadoOcupacaoInvalido || dtAvaliacaoInvalida) {
	    return;
	}
	
	final Integer operacao = this.getVisao().getEntidade().getContrato().getNuOperacao();
	
	if (UtilObjeto.isReferenciaNumeroPositivo(operacao)) {
	    Short nuOperacao = operacao.shortValue();

	    String icOrigem = null;
	    if (!this.mapOrigemFinaceira.containsKey(nuOperacao)) {
		icOrigem = this.origemFinanceiraService.consultarIcOrigemFinanceiraPorNuProduto(nuOperacao);
		this.mapOrigemFinaceira.put(nuOperacao, icOrigem);
	    }

	    icOrigem = this.mapOrigemFinaceira.get(nuOperacao);
	    this.calcularValorJustoImovel(icEstadoOcupacao, icOrigem);
	}
	
    }

    /**
     * <p>Método responsável por</p>
     *
     * @author gerusa.soares
     *
     */
    private void limparParametrosCalculo() {
	this.getVisao().setVrDesagioImovel(null);
	this.getVisao().setVrJusto(null);
	this.getVisao().setIdCalculo(null);
    }

    /**
     * @author gerusa.soares
     *
     * @param icEstadoOcupacao
     * @param icOrigem
     */
    private void calcularValorJustoImovel(final String icEstadoOcupacao, final String icOrigem) {
	final String keyMapValorDesagio = icOrigem.concat("-").concat(icEstadoOcupacao);
	BigDecimal vrDesagio = this.mapValorDesagio.get(keyMapValorDesagio);
	
	if(!UtilObjeto.isReferencia(vrDesagio)) {
	    vrDesagio = this.valorDesagioService.consultarValorPorOrigemFinanceiraEstadoOcupacao(icOrigem, icEstadoOcupacao);
	    this.mapValorDesagio.put(keyMapValorDesagio, vrDesagio);
	}
	
	if(!UtilObjeto.isReferencia(vrDesagio)) {
	    this.adicionaMensagemDeAlerta("Não foi possível realizar o cálculo. Não existe Valor de Deságio para a Origem Financeira e o Estado Ocupação informados.");
	    LogCefUtil.warn("Não foi possível realizar o cálculo. Não existe Valor de Deságio para a Origem Financeira e o Estado Ocupação informados: " + icOrigem + ", " + icEstadoOcupacao);
	    return;
	}
	
	this.getVisao().setVrDesagioImovel(vrDesagio);
	
	final BigDecimal subtracao = BigDecimal.ONE.subtract(vrDesagio);
	final BigDecimal vrJusto = this.getVisao().getEntidade().getImovel().getValorAvaliacao().multiply(subtracao);
	this.getVisao().setVrJusto(vrJusto);
    }
    
    public void gerarComprovanteCalculo() {
	if(!UtilObjeto.isReferencia(this.getVisao().getVrJusto())) {
	    this.adicionaMensagemDeAlerta("Necessário Calcular antes de Gerar Comprovante.");
	    return;
	}
	
	this.getVisao().setIdCalculo(UUID.randomUUID().toString());
	this.historicoCalculoValorImovelService.salvarHistoricoCalculoValorImovelVisao(this.getVisao(), UsuarioUtil.getUsuarioLogado().getDeMatricula());
	
	this.gerarComprovanteCalculoPdf();
	
	this.limparParametrosCalculo();
    }
    
    private void gerarComprovanteCalculoPdf() {
	
	try {
            UtilRelatorio.getInstancia().addCaminhoRelatorio(CalculoValorImovelMB.CAMINHO_RELATORIO_CALCULO_PDF)
            	    .addColecao(Arrays.asList(this.criarComprovante()))
                    .addResposta(this.getResponse()).addParametros(this.montarMapaParametros()).addNomeRelatorio(CalculoValorImovelMB.NOME_RELATORIO_CALCULO)
                    .addExtensaoArquivo(EnumExtensaoArquivo.PDF).gerarRelatorio();
        } catch (final Exception e) {
            LogCEF.error("Erro ao gerar comprovante do cálculo do valor justo do imóvel: ");
            e.printStackTrace();
        }
    }
    
   private ComprovanteCalculoValorImovelVO criarComprovante() {

       final HistoricoCalculoValorImovelVisao historicoVisao = this.getVisao();
       final String origem = historicoVisao.getOrigemEnumSelecionada() != null ? historicoVisao.getOrigemEnumSelecionada().toString() : null;
	
       final ComprovanteCalculoValorImovelVO vo = new ComprovanteCalculoValorImovelVO();
       vo.setOrigemContrato(origem);
       vo.setCoSequencial(origem != null && origem.equals(OrigemContratoHabitacionalEnum.COMERCIAL.toString()) ? historicoVisao.getCoSequencial() : null);

       final Contrato contrato = historicoVisao.getEntidade().getContrato();
       vo.setContrato(contrato.getCoContrato());
       vo.setProduto(contrato.getNuOperacao());
       vo.setTipoPessoa(contrato.getNuPessoa().getIcPfPj());
       vo.setCpfCnpj(contrato.getNuPessoa().getNuCnpjFormatado());

       final Imovel imovel = historicoVisao.getEntidade().getImovel();
       vo.setOsAvaliacao(imovel.getCoOrdemServicoAvaliacao());
       vo.setCartorio(imovel.getGestaoServentia().getCodigoCns().concat(" - ").concat(imovel.getGestaoServentia().getDenominacao()));
       vo.setMatriculaImovel(imovel.getNuMatricula());
       vo.setCidade(imovel.getNoMunicipio());
       vo.setUf(imovel.getNoUf());
       vo.setArea(imovel.getVrAreaImovel());
       vo.setDataAvaliacao(UtilData.converterDateParaString(imovel.getDataAvaliacao(), UtilData.DD_MM_YYYY));
       vo.setValorAvaliacao(imovel.getValorAvaliacao());
       vo.setValorJusto(historicoVisao.getVrJusto());
       vo.setIdCalculo(historicoVisao.getIdCalculo());

       final EstadoOcupacaoImovelEnum estadoEnum = EstadoOcupacaoImovelEnum.geEnumByCodigo(imovel.getIcEstadoOcupacao());
       vo.setEstadoOcupacao(estadoEnum != null ? estadoEnum.toString() : "");
       
       return vo;
   }
    
    private Map<String, Object> montarMapaParametros() {
        final Map<String, Object> parametros = new LinkedHashMap<>();
        parametros.put("LOGO_CAIXA", FacesContext.getCurrentInstance().getExternalContext().getResourceAsStream("/resources/img/caixa_logo.jpg"));
        parametros.put("MATRICULA_USUARIO", UsuarioUtil.getUsuarioLogado().getDeMatricula());
	
        return parametros;
    }
    
}
