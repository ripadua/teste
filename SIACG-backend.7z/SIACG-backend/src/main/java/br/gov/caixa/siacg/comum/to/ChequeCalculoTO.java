/**
 * Copyright (c) 2020 Caixa Econômica Federal. Todos os direitos
 * reservados.
 *
 * Caixa Econômica Federal - SIACG
 *
 * Este software foi desenvolvido sob demanda da CAIXA e está
 * protegido por leis de direitos autorais e tratados internacionais. As
 * condições de cópia e utilização total ou partes dependem de autorização da
 * empresa. Cópias não são permitidas sem expressa autorização. Não pode ser
 * comercializado ou utilizado para propósitos particulares.
 *
 * Uso exclusivo da Caixa Econômica Federal. A reprodução ou distribuição não
 * autorizada deste programa ou de parte dele, resultará em punições civis e
 * criminais e os infratores incorrem em sanções previstas na legislação em
 * vigor.
 *
 * Histórico do TFS:
 *
 * LastChangedRevision: $Revision$
 * LastChangedBy: $Author$
 * LastChangedDate: $Date$
 *
 * HeadURL: $HeadURL$
 *
 */	
package br.gov.caixa.siacg.comum.to;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

import com.fasterxml.jackson.annotation.JsonProperty;

import br.gov.caixa.pedesgo.arquitetura.util.UtilData;

/**
 * <p>ChequeCalculoTO</p>
 *
 * <p>Descrição: Descrição do tipo</p>
 *
 * <br><b>Empresa:</b> Cef - Caixa Econômica Federal
 *
 *
 * @author f541915
 *
 * @version 1.0
*/
public class ChequeCalculoTO implements Serializable {
    
    /** Atributo serialVersionUID. */
    private static final long serialVersionUID = 1L;
    
    /** Atributo nuCheque. */
    @JsonProperty("nu_cheque")
    private Integer nuCheque;
    
    /** Atributo dtEntrada. */
    @JsonProperty("dt_entrada")
    private Date dtEntrada;
    
    /** Atributo dtVencimento. */
    @JsonProperty("dt_vencimento")
    private Date dtVencimento;
    
    /** Atributo vrCheque. */
    @JsonProperty("vr_cheque")
    private BigDecimal vrCheque;
    
    /** Atributo nuGarantia. */
    @JsonProperty("nu_garantia_contrato")
    private Integer nuGarantia;

    /**
     * <p>Retorna o valor do atributo nuCheque</p>.
     *
     * @return nuCheque
    */
    public Integer getNuCheque() {
        return this.nuCheque;
    }

    /**
     * <p>Define o valor do atributo nuCheque</p>.
     *
     * @param nuCheque valor a ser atribuído
    */
    public void setNuCheque(Integer nuCheque) {
        this.nuCheque = nuCheque;
    }

    /**
     * <p>Retorna o valor do atributo dtVencimento</p>.
     *
     * @return dtVencimento
    */
    public Date getDtVencimento() {
        return this.dtVencimento;
    }

    /**
     * <p>Define o valor do atributo dtVencimento</p>.
     *
     * @param dtVencimento valor a ser atribuído
    */
    public void setDtVencimento(Date dtVencimento) {
        this.dtVencimento = dtVencimento;
    }

    /**
     * <p>Retorna o valor do atributo vrCheque</p>.
     *
     * @return vrCheque
    */
    public BigDecimal getVrCheque() {
	return this.vrCheque;
    }

    /**
     * <p>Define o valor do atributo vrCheque</p>.
     *
     * @param vrCheque valor a ser atribuído
    */
    public void setVrCheque(BigDecimal vrCheque) {
	this.vrCheque = vrCheque;
    }

    /**
     * <p>Retorna o valor do atributo nuGarantia</p>.
     *
     * @return nuGarantia
    */
    public Integer getNuGarantia() {
	return this.nuGarantia;
    }

    /**
     * <p>Define o valor do atributo nuGarantia</p>.
     *
     * @param nuGarantia valor a ser atribuído
    */
    public void setNuGarantia(Integer nuGarantia) {
	this.nuGarantia = nuGarantia;
    }
    
    /**
     * <p>
     * Método responsável por consultar a diferença em dias entre a data de
     * entrada e data de vencimento do cheque.
     * <p>
     *
     * @return int
     * @author guilherme.santos
     */
    public int consultarDiasVigencia() {
        return UtilData.diferencaEmDiasEntreDatas(this.getDtEntrada(), this.getDtVencimento());
    }

    /**
     * <p>Retorna o valor do atributo dtEntrada</p>.
     *
     * @return dtEntrada
    */
    public Date getDtEntrada() {
	return this.dtEntrada;
    }

    /**
     * <p>Define o valor do atributo dtEntrada</p>.
     *
     * @param dtEntrada valor a ser atribuído
    */
    public void setDtEntrada(Date dtEntrada) {
	this.dtEntrada = dtEntrada;
    }
    
}
