package br.gov.caixa.siacg.view.form;

import java.util.Collection;

import br.gov.caixa.pedesgo.arquitetura.visao.ManutencaoVisao;
import br.gov.caixa.siacg.model.domain.Contrato;
import br.gov.caixa.siacg.model.domain.GarantiaContrato;

/**
 * <p>
 * DesbloqueioGarantiaVisao
 * </p>
 *
 * <p>
 * Descrição: Armazena os dados de visão da funcionalidade responsável por
 * solicitar o desbloqueio de garantiaContrato.
 * </p>
 *
 * <br>
 * <b>Empresa:</b> Cef - Caixa Econômica Federal
 *
 *
 * @author f734546
 *
 * @version 1.0
 */
public class DesbloqueioGarantiaVisao extends ManutencaoVisao<GarantiaContrato> {

    /** Atributo serialVersionUID. */
    private static final long serialVersionUID = -3730321552026209871L;

    /** Atributo quantidadeItens. */
    private Integer quantidadeItens;
    
    private Contrato contrato;

    /** Atributo listaGarantia. */
    private Collection<GarantiaContrato> listaGarantia;

    /** Atributo garantiaParaDesbloqueio. */
    private GarantiaContrato garantiaParaDesbloqueio;

    /**
     * <p>
     * Retorna o valor do atributo quantidadeItens
     * </p>
     * .
     *
     * @return quantidadeItens
     */
    public Integer getQuantidadeItens() {
	return this.quantidadeItens;
    }

    /**
     * <p>
     * Define o valor do atributo quantidadeItens
     * </p>
     * .
     *
     * @param quantidadeItens
     *            valor a ser atribuído
     */
    public void setQuantidadeItens(final Integer quantidadeItens) {
	this.quantidadeItens = quantidadeItens;
    }
    
    /**
     * <p>Retorna o valor do atributo contrato</p>.
     *
     * @return contrato
    */
    public Contrato getContrato() {
        return this.contrato;
    }

    /**
     * <p>Define o valor do atributo contrato</p>.
     *
     * @param contrato valor a ser atribuído
    */
    public void setContrato(final Contrato contrato) {
        this.contrato = contrato;
    }

    /**
     * <p>
     * Retorna o valor do atributo listaGarantia
     * </p>
     * .
     *
     * @return listaGarantia
     */
    public Collection<GarantiaContrato> getListaGarantia() {
	return this.listaGarantia;
    }

    /**
     * <p>
     * Define o valor do atributo listaGarantia
     * </p>
     * .
     *
     * @param listaGarantia
     *            valor a ser atribuído
     */
    public void setListaGarantia(final Collection<GarantiaContrato> listaGarantia) {
	this.listaGarantia = listaGarantia;
    }

    /**
     * <p>
     * Retorna o valor do atributo garantiaParaDesbloqueio
     * </p>
     * .
     *
     * @return garantiaParaDesbloqueio
     */
    public GarantiaContrato getGarantiaParaDesbloqueio() {
	return this.garantiaParaDesbloqueio;
    }

    /**
     * <p>
     * Define o valor do atributo garantiaParaDesbloqueio
     * </p>
     * .
     *
     * @param garantiaParaDesbloqueio
     *            valor a ser atribuído
     */
    public void setGarantiaParaDesbloqueio(final GarantiaContrato garantiaParaDesbloqueio) {
	this.garantiaParaDesbloqueio = garantiaParaDesbloqueio;
    }

}
