package br.gov.caixa.siacg.pagination;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.Map;

import javax.ejb.EJB;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;

import org.primefaces.model.SortOrder;

import br.gov.caixa.pedesgo.arquitetura.paginacao.Paginacao;
import br.gov.caixa.pedesgo.arquitetura.paginacao.PaginacaoDemanda;
import br.gov.caixa.siacg.model.domain.Cedente;
import br.gov.caixa.siacg.model.domain.Sacado;
import br.gov.caixa.siacg.model.vo.FiltroSacadoVO;
import br.gov.caixa.siacg.service.SacadoService;

/**
 * <p>
 * SacadoLazyModel.
 * </p>
 * <p>
 * Descrição: Classe de paginação sob demanda do sacado
 * </p>
 * <br>
 * <b>Empresa:</b> Cef - Caixa Econômica Federal
 *
 * @author Waltenes Junior
 * @version 1.0
 */
@ManagedBean(name = SacadoLazyModel.NOME_MANAGED_BEAN)
@SessionScoped
public class SacadoLazyModel extends Paginacao<Sacado> {

    private static final long serialVersionUID = -6038965454195521432L;

    /** Atributo NOME_MANAGED_BEAN. */
    public static final String NOME_MANAGED_BEAN = "sacadoLazyModel";
    /** Atributo EL_MANAGED_BEAN. */
    public static final String EL_MANAGED_BEAN = "#{sacadoLazyModel}";

    /** Atributo service. */
    @EJB
    private transient SacadoService service;

    /** Atributo filtroSacadoVO. */
    private transient FiltroSacadoVO filtroSacadoVO;

    /**
     * @see br.gov.caixa.pedesgo.arquitetura.integracao.componente.paginacao.Paginacao#getServico()
     */
    @Override
    @SuppressWarnings("unchecked")
    public SacadoService getServico() {
        return this.service;
    }

    /**
     * @see br.gov.caixa.pedesgo.arquitetura.integracao.componente.paginacao.Paginacao#load(int,
     *      int, java.lang.String, org.primefaces.model.SortOrder,
     *      java.util.Map)
     */
    @Override
    public List<Sacado> load(final int inicio, final int fim, final String campoOrdenacao, final SortOrder ordenacao,
            final Map<String, String> parametros) {
        this.filtroSacadoVO.setCampoOrdenacao(campoOrdenacao);
        this.filtroSacadoVO.setTipoOrdenacao(ordenacao.name());
        final PaginacaoDemanda<Sacado> resultado = this.service.listaSacados(this.filtroSacadoVO, inicio, fim);

        if (resultado.getLista() != null && !resultado.getLista().isEmpty()) {
            for (final Sacado sacado : resultado.getLista()) {
                this.verificarListaCedentes(sacado);
            }
        }

        this.setWrappedData(resultado.getLista());
        this.setRowCount(resultado.getQuantidadeRegistros());
        return resultado.getLista();
    }

    /**
     * <p>
     * Método responsável por verificar a lista de cedentes.
     * <p>
     *
     * @param sacado
     *            valor a ser atribuido
     * @author Caio Graco
     */
    private void verificarListaCedentes(final Sacado sacado) {
        final Collection<String> listaCodigoCedente = new ArrayList<>();
        final Collection<Cedente> listaCedenteNaoRepetido = new ArrayList<>();

        final Sacado sacadoInicializado = this.service.obterComRelacionamentoInicializado(sacado);

        for (final Cedente cedente : sacadoInicializado.getListaCedenteNaoAceito()) {
            if (!listaCodigoCedente.contains(cedente.getCoCedente())) {
                listaCodigoCedente.add(cedente.getCoCedente());
            }
        }

        for (final String codigo : listaCodigoCedente) {
            final Collection<Cedente> listaCedente = this.service.obterListaCedentePorCodigo(codigo);

            listaCedenteNaoRepetido.add(listaCedente.iterator().next());
        }

        sacado.setListaCedenteNaoAceitoNaoRepetido(listaCedenteNaoRepetido);
    }

    /**
     * <p>
     * Método responsável por limpar o filtro da consulta.
     * <p>
     *
     * @author Waltenes Junior
     */
    public void limparFiltro() {
        this.filtroSacadoVO.setApelidoTO(null);
        this.filtroSacadoVO.setCnpjTO(null);
        this.filtroSacadoVO.setCpfTO(null);
        this.filtroSacadoVO.setRazaoSocialSacadoTO(null);
        this.filtroSacadoVO.setNomeSacadoTO(null);
    }

    /**
     * Retorna o valor do atributo consultaVisao.
     *
     * @return <code>consultaVisao</code>
     */
    public FiltroSacadoVO getFiltroSacadoVO() {
        if (this.filtroSacadoVO == null) {
            this.filtroSacadoVO = new FiltroSacadoVO();
        }
        return this.filtroSacadoVO;
    }

    /**
     * Define o valor do atributo filtroSacadoVO.
     *
     * @param filtroSacadoVO
     *            valor a ser atribuído
     */
    public void setFiltroSacadoVO(final FiltroSacadoVO filtroSacadoVO) {
        this.filtroSacadoVO = filtroSacadoVO;
    }
}
