/**
 * Copyright (c) 2014 Caixa Econômica Federal. Todos os direitos
 * reservados.
 *
 * Caixa Econômica Federal - SIACG - Sistema de Acompanhamento e Controle de Garantias
 *
 * Este software foi desenvolvido sob demanda da CAIXA e está
 * protegido por leis de direitos autorais e tratados internacionais. As
 * condições de cópia e utilização do todo ou partes dependem de autorização da
 * pessoa. Cópias não são permitidas sem expressa autorização. Não pode ser
 * comercializado ou utilizado para propósitos particulares.
 *
 * Uso exclusivo da Caixa Econômica Federal. A reprodução ou distribuição não
 * autorizada deste programa ou de parte dele, resultará em punições civis e
 * criminais e os infratores incorrem em sanções previstas na legislação em
 * vigor.
 *
 * Histórico do Subversion:
 *
 * LastChangedRevision: $Revision$
 * LastChangedBy: $Author$
 * LastChangedDate: $Date$
 *
 * HeadURL: $HeadURL$
 *
 */
package br.gov.caixa.siacg.view.mb;

import java.util.ArrayList;
import java.util.Collection;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.Map;

import javax.annotation.PostConstruct;
import javax.ejb.EJB;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ManagedProperty;
import javax.faces.bean.ViewScoped;
import javax.faces.context.FacesContext;
import javax.faces.event.AjaxBehaviorEvent;

import org.apache.commons.collections.CollectionUtils;

import br.gov.caixa.pedesgo.arquitetura.controlador.AbstractBean;
import br.gov.caixa.pedesgo.arquitetura.controlador.ManutencaoBean;
import br.gov.caixa.pedesgo.arquitetura.enumerador.EnumAcao;
import br.gov.caixa.pedesgo.arquitetura.enumerador.EnumNomeAbrangenciaRestritaUnidade;
import br.gov.caixa.pedesgo.arquitetura.enumerador.EnumTipoAbrangencia;
import br.gov.caixa.pedesgo.arquitetura.enums.EnumExtensaoArquivo;
import br.gov.caixa.pedesgo.arquitetura.relatorio.UtilRelatorio;
import br.gov.caixa.pedesgo.arquitetura.util.LogCefUtil;
import br.gov.caixa.pedesgo.arquitetura.util.MensagensUtil;
import br.gov.caixa.pedesgo.arquitetura.util.UsuarioUtil;
import br.gov.caixa.pedesgo.arquitetura.util.UtilObjeto;
import br.gov.caixa.pedesgo.arquitetura.util.UtilString;
import br.gov.caixa.siacg.model.domain.Saldo;
import br.gov.caixa.siacg.model.enums.NoFuncionalidadeEnum;
import br.gov.caixa.siacg.model.vo.FiltroContratoVO;
import br.gov.caixa.siacg.model.vo.SaldoVO;
import br.gov.caixa.siacg.model.vo.SrVO;
import br.gov.caixa.siacg.model.vo.UnidadeVO;
import br.gov.caixa.siacg.pagination.RelatorioSaldoLiquidoPessoaLazyModel;
import br.gov.caixa.siacg.service.RelatorioSaldoLiquidoPessoaService;
import br.gov.caixa.siacg.view.form.RelatorioSaldoLiquidoPessoaVisao;

/**
 * <p>
 * AcompanhamentoEndividamentoMB.
 * </p>
 * <p>
 * Descrição: Bean Gerenciado para o Acompanahmento de Endividamento
 * </p>
 * <br>
 * <b>Empresa:</b> Cef - Caixa Econômica Federal
 *
 * @author guilherme.santos
 * @version 1.0
 */
@ManagedBean
@ViewScoped
public class RelatorioSaldoLiquidoPessoaMB extends ManutencaoBean<Saldo> {

    /** Atributo IMAGEM_CAIXA_LOGO. */
    private static final String IMAGEM_CAIXA_LOGO = "/resources/img/caixa_logo.jpg";

    /** Atributo CAMINHO_RELATORIO. */
    private static final String CAMINHO_RELATORIO = "/reports/";

    /** Atributo NOME_JASPER_RELATORIO_SALDO. */
    private static final String NOME_JASPER_RELATORIO_SALDO = "relatorio_saldo_limite_garantia_pessoa.jasper";

    /** Atributo NOME_RELATORIO_SALDO_LIQUIDO_GARANTIA_PESSOA. */
    private static final String NOME_RELATORIO_SALDO_LIQUIDO_GARANTIA_PESSOA = "Relatorio_Saldo_Liquido_Garantias_Pessoa";

    /** Atributo serialVersionUID. */
    private static final long serialVersionUID = -6313373940518853305L;

    /** Atributo NOME_MANAGED_BEAN. */
    public static final String NOME_MANAGED_BEAN = "relatorioSaldoLiquidoPessoaMB";

    /** Atributo EL_MANAGED_BEAN. */
    public static final String EL_MANAGED_BEAN = "#{relatorioSaldoLiquidoPessoaMB}";

    /** Atributo VAR_RESOURCE_BUNDLE. */
    private static final String VAR_RESOURCE_BUNDLE = "msgApp";

    /** Atributo DIRETORIO_PAGINAS. */
    private static final String DIRETORIO_PAGINAS = "/pages/";

    /** Atributo PREFIXO_CASO_USO. */
    private static final String PREFIXO_CASO_USO = "relatorioSaldoLiquidoEmpresa";

    /** Atributo service. */
    @EJB
    private transient RelatorioSaldoLiquidoPessoaService service;

    /** Atributo visao. */
    private transient RelatorioSaldoLiquidoPessoaVisao visao;

    /** Atributo paginacaoRelatorioSaldoLiquidoPessoa. */
    @ManagedProperty(value = RelatorioSaldoLiquidoPessoaLazyModel.EL_MANAGED_BEAN)
    private RelatorioSaldoLiquidoPessoaLazyModel paginacaoRelatorioSaldoLiquidoPessoa;

    /**
     * @see br.gov.caixa.pedesgo.arquitetura.controlador.AbstractBean#getPrefixoCasoDeUso()
     */
    @Override
    protected String getPrefixoCasoDeUso() {
        return RelatorioSaldoLiquidoPessoaMB.PREFIXO_CASO_USO;
    }

    /**
     * @see br.gov.caixa.pedesgo.arquitetura.controlador.AbstractBean#getTelaConsulta()
     */
    @Override
    public String getTelaConsulta() {
        return RelatorioSaldoLiquidoPessoaMB.DIRETORIO_PAGINAS + this.getPrefixoCasoDeUso() + AbstractBean.SUFIXO_TELA_CONSULTA;
    }

    /**
     * @see br.gov.caixa.pedesgo.arquitetura.controlador.AbstractBean#getNomeVarResourceBundle()
     */
    @Override
    protected String getNomeVarResourceBundle() {
        return RelatorioSaldoLiquidoPessoaMB.VAR_RESOURCE_BUNDLE;
    }

    /**
     * @see br.gov.caixa.pedesgo.arquitetura.controlador.AbstractBean#getService()
     */
    @SuppressWarnings("unchecked")
    @Override
    public RelatorioSaldoLiquidoPessoaService getService() {
        return this.service;
    }

    /**
     * @see br.gov.caixa.pedesgo.arquitetura.controlador.AbstractBean#getVisao()
     */
    @Override
    public RelatorioSaldoLiquidoPessoaVisao getVisao() {
        if (this.visao == null) {
            this.visao = new RelatorioSaldoLiquidoPessoaVisao();
        }
        return this.visao;
    }

    /**
     * <p>
     * Método responsável por exportar xls.
     * <p>
     */
    public void exportarXLS() {

        final Collection<SaldoVO> listarSaldosLiquidoPessoa = this.service
                .listarSaldosLiquidoPessoa(this.paginacaoRelatorioSaldoLiquidoPessoa.getFiltro());
        final Map<String, Object> parametros = new LinkedHashMap<>();

        parametros.put("LOGO_CAIXA", super.getExternalContext().getResourceAsStream(RelatorioSaldoLiquidoPessoaMB.IMAGEM_CAIXA_LOGO));
        parametros.put("MATRICULA_USUARIO", super.getMatriculaUsuario());

        try {
            if (CollectionUtils.isNotEmpty(listarSaldosLiquidoPessoa)) {
                UtilRelatorio.getInstancia()
                        .addCaminhoRelatorio(
                                RelatorioSaldoLiquidoPessoaMB.CAMINHO_RELATORIO + RelatorioSaldoLiquidoPessoaMB.NOME_JASPER_RELATORIO_SALDO)
                        .addColecao(listarSaldosLiquidoPessoa).addExtensaoArquivo(EnumExtensaoArquivo.XLS)
                        .addNomeRelatorio(RelatorioSaldoLiquidoPessoaMB.NOME_RELATORIO_SALDO_LIQUIDO_GARANTIA_PESSOA).addParametros(parametros)
                        .addResposta(super.getResponse()).gerarRelatorio();
            } else {
                this.adicionaMensagemDeAlerta(MensagensUtil.getMensagem(VAR_RESOURCE_BUNDLE, "MA001"));
            }

        } catch (final Exception e) {
            LogCefUtil.error("Não foi possivel gerar o XLS" + e.getCause());
            LogCefUtil.error(e);
        }
    }

    /**
     * Retorna o valor do atributo paginacaoAcompanhamentoEndividamento.
     *
     * @return paginacaoAcompanhamentoEndividamento
     */
    public RelatorioSaldoLiquidoPessoaLazyModel getPaginacaoRelatorioSaldoLiquidoPessoa() {

        return this.paginacaoRelatorioSaldoLiquidoPessoa;
    }

    /**
     * Define o valor do atributo paginacaoRelatorioSaldoLiquidoPessoa.
     *
     * @param paginacaoRelatorioSaldoLiquidoPessoa
     *            valor a ser atribuído
     */
    public void setPaginacaoRelatorioSaldoLiquidoPessoa(final RelatorioSaldoLiquidoPessoaLazyModel paginacaoRelatorioSaldoLiquidoPessoa) {

        this.paginacaoRelatorioSaldoLiquidoPessoa = paginacaoRelatorioSaldoLiquidoPessoa;
    }

    /**
     * <p>
     * Método responsável por limpar o filtro de consulta.
     * <p>
     *
     * @return String
     * @author guilherme.santos
     */
    public String limparFiltro() {
        this.paginacaoRelatorioSaldoLiquidoPessoa.setFiltro(new FiltroContratoVO());

        return super.MESMA_TELA;
    }

    /**
     * <p>
     * Ação executada quando a combobox de SUAT for selecionada.
     * </p>
     *
     * @param eventoAjax
     *            valor a ser atribuído
     * @author guilherme.santos
     */
    public void selecionarSuat(final AjaxBehaviorEvent eventoAjax) {
        final RelatorioSaldoLiquidoPessoaVisao visao = this.getVisao();
        final FiltroContratoVO consultaContrato = this.getPaginacaoRelatorioSaldoLiquidoPessoa().getFiltro();

        this.limparListaUnidadeFiltro();

        if (UtilObjeto.isReferencia(visao) && visao.getNuSuat() != null && !visao.getNuSuat().equals(0)) {
            visao.setSrList(this.getService().listarSrsPorNuSuat(visao.getNuSuat()));
            final Collection<Integer> listaSrs = new ArrayList<>();
            for (final SrVO srVO : visao.getSrList()) {
                listaSrs.add(srVO.getNuSrVO());
            }
            final Collection<Integer> listaUnidadeVinculadasSrs = this.service.getNuUnidadesVinculadasSR(listaSrs);
            consultaContrato.setListaUnidade(listaUnidadeVinculadasSrs);
            visao.setUnidadeList(new LinkedList<UnidadeVO>());

            visao.setNuSuat(visao.getNuSuat());
        } else {
            visao.setSrList(new LinkedList<SrVO>());
            visao.setUnidadeList(new LinkedList<UnidadeVO>());
            visao.setNuSuat(null);
        }
    }

    /**
     * <p>
     * Ação executada quando a combobox de SR for selecionada.
     * </p>
     *
     * @param eventoAjax
     *            valor a ser atribuído
     * @author guilherme.santos
     */
    public void selecionarSr(final AjaxBehaviorEvent eventoAjax) {
        final RelatorioSaldoLiquidoPessoaVisao visao = this.getVisao();
        this.limparListaUnidadeFiltro();

        if (UtilObjeto.isReferencia(visao) && visao.getNuSr() != null && !visao.getNuSr().equals(0)) {
            visao.setUnidadeList(this.getService().listarUnidadesPorNuSr(visao.getNuSr()));
            for (final UnidadeVO unidadeVO : visao.getUnidadeList()) {
                final Integer unidade = unidadeVO.getCoUnidadeVO();
                this.getPaginacaoRelatorioSaldoLiquidoPessoa().getFiltro().getListaUnidade().add(unidade);
            }
            visao.setNuSr(visao.getNuSr());
        } else {
            this.selecionarSuat(eventoAjax);
            visao.setNuSr(null);
            visao.setNuUnidade(null);
        }
    }

    /**
     * <p>
     * Ação executada quando a combobox de Unidade for selecionada.
     * <p>
     *
     * @param eventoAjax
     *            valor a ser atribuído
     * @author guilherme.santos
     */
    public void selecionarUnidade(final AjaxBehaviorEvent eventoAjax) {
        final RelatorioSaldoLiquidoPessoaVisao visao = this.getVisao();
        this.limparListaUnidadeFiltro();

        if (UtilObjeto.isReferencia(visao) && visao.getNuUnidade() != null && !visao.getNuUnidade().equals(0)) {
            this.getPaginacaoRelatorioSaldoLiquidoPessoa().getFiltro().getListaUnidade().add(visao.getNuUnidade());
            visao.setNuUnidade(visao.getNuUnidade());
        } else {
            this.selecionarSr(eventoAjax);
            visao.setNuUnidade(null);
        }
    }

    /**
     * <p>
     * Método responsável por limpa a lista de unidades do filtro da consulta.
     * <p>
     *
     * @author guilherme.santos
     */
    private void limparListaUnidadeFiltro() {
        this.getPaginacaoRelatorioSaldoLiquidoPessoa().getFiltro().setListaUnidade(new ArrayList<Integer>());
    }

    /**
     * <p>
     * Método responsável por construir o bread crumb para usuário e configurar
     * valor do filtro usado na aplicação.
     * </p>
     *
     * @author guilherme.santos
     */
    @PostConstruct
    public void inicializar() {

        final FacesContext contexto = FacesContext.getCurrentInstance();

        if (UtilObjeto.isReferencia(contexto)) {

            final String unidadeUsuario = super.getUnidadeUsuario();
            
            if (!UtilString.isVazio(unidadeUsuario)) {

                final Integer nuUnidadeusuarioLogado = Integer.valueOf(unidadeUsuario);

                if (UtilObjeto.isReferencia(nuUnidadeusuarioLogado)) {

                    final RelatorioSaldoLiquidoPessoaVisao visao = this.getVisao();

                    if (UsuarioUtil.contemPermissao(NoFuncionalidadeEnum.CONSULTA_UNIDADE.getNoFuncionalidade(), EnumAcao.CONSULTAR.getNoAcao(),
                            EnumTipoAbrangencia.RESTRITA_UNIDADE.getTipoAbrangencia(),
                            EnumNomeAbrangenciaRestritaUnidade.TODAS.getNomeAbrangencia())) {

                        visao.setSuatList(this.service.listarSuats());
                        visao.setExibirGestorCaixa(true);

                        if (visao.getNuSuat() != null) {
                            visao.setNuSuat(visao.getNuSuat());
                            this.selecionarSuat(null);
                        }
                        if (visao.getNuSr() != null) {
                            visao.setSrList(this.getService().listarSrsPorNuSuat(visao.getNuSuat()));
                            visao.setNuSr(visao.getNuSr());
                            this.selecionarSr(null);
                        }
                        if (visao.getNuUnidade() != null) {
                            visao.setUnidadeList(this.getService().listarUnidadesPorNuSr(visao.getNuSr()));
                            visao.setNuUnidade(visao.getNuUnidade());
                            this.selecionarUnidade(null);
                        }

                    } else if (UsuarioUtil.contemPermissao(NoFuncionalidadeEnum.CONSULTA_UNIDADE.getNoFuncionalidade(),
                            EnumAcao.CONSULTAR.getNoAcao(), EnumTipoAbrangencia.RESTRITA_UNIDADE.getTipoAbrangencia(),
                            EnumNomeAbrangenciaRestritaUnidade.VINCULADAS.getNomeAbrangencia())) {

                        visao.setExibirGestorRegional(true);
                        visao.setExibirColunaSR(true);
                        visao.setExibirColunaSUAT(true);

                        if (visao.getNuUnidade() != null) {
                            visao.setUnidadeList(this.getService().listarUnidadesPorNuSr(nuUnidadeusuarioLogado));
                            visao.setNuUnidade(visao.getNuUnidade());
                        }

                    } else if (UsuarioUtil.contemPermissao(NoFuncionalidadeEnum.CONSULTA_UNIDADE.getNoFuncionalidade(),
                            EnumAcao.CONSULTAR.getNoAcao(), EnumTipoAbrangencia.RESTRITA_UNIDADE.getTipoAbrangencia(),
                            EnumNomeAbrangenciaRestritaUnidade.UNIDADE.getNomeAbrangencia())) {

                        visao.setExibirGestorUnidade(true);
                        visao.setExibirColunaUnidade(true);
                        visao.setExibirColunaSR(true);
                        visao.setExibirColunaSUAT(true);
                    }
                }
            }
        }
    }
}
