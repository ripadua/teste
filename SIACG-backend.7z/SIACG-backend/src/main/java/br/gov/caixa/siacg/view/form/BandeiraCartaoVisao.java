/**
 * Copyright (c) 2015 Caixa Econômica Federal. Todos os direitos
 * reservados.
 *
 * Caixa Econômica Federal - SIACG - Sistema de Crédito Rural
 *
 * Este software foi desenvolvido sob demanda da CAIXA e está
 * protegido por leis de direitos autorais e tratados internacionais. As
 * condições de cópia e utilização do todo ou partes dependem de autorização da
 * pessoa. Cópias não são permitidas sem expressa autorização. Não pode ser
 * comercializado ou utilizado para propósitos particulares.
 *
 * Uso exclusivo da Caixa Econômica Federal. A reprodução ou distribuição não
 * autorizada deste programa ou de parte dele, resultará em punições civis e
 * criminais e os infratores incorrem em sanções previstas na legislação em
 * vigor.
 *
 * Histórico do Subversion:
 *
 * LastChangedRevision: $Revision$
 * LastChangedBy: $Author$
 * LastChangedDate: $Date$
 *
 * HeadURL: $HeadURL$
 *
 */
package br.gov.caixa.siacg.view.form;

import java.util.Arrays;
import java.util.List;

import br.gov.caixa.siacg.model.domain.BandeiraCartao;
import br.gov.caixa.siacg.model.enums.TipoMovimentacaoBandeiraEnum;
import br.gov.caixa.siacg.model.enums.TrueFalseEnum;
import br.gov.caixa.siacg.model.vo.FiltroBandeiraCartaoVO;
import br.gov.caixa.siacg.view.mb.BandeiraCartaoMB;

/**
 * <p>
 * BandeiraCartaoVisao
 * </p>
 * <p>
 * Descrição: classe de visão auxiliar da classe bean {@link BandeiraCartaoMB}.
 * </p>
 * <br>
 * <b>Empresa:</b> Cef - Caixa Econômica Federal
 *
 * @author Marco Isecke
 * @version 1.0
 */
public class BandeiraCartaoVisao extends TemplateVisao<BandeiraCartao> {

	private static final long serialVersionUID = 4791335970578330615L;

	private List<BandeiraCartao> listaBandeiraCartao;
	private FiltroBandeiraCartaoVO filtro;
	private boolean isInclusao;

	/**
	 * @return the listaBandeiraCartao
	 */
	public List<BandeiraCartao> getListaBandeiraCartao() {
		return listaBandeiraCartao;
	}

	/**
	 * @param listaBandeiraCartao
	 *            the listaBandeiraCartao to set
	 */
	public void setListaBandeiraCartao(List<BandeiraCartao> listaBandeiraCartao) {
		this.listaBandeiraCartao = listaBandeiraCartao;
	}

	/**
	 * @return the filtro
	 */
	public FiltroBandeiraCartaoVO getFiltro() {
		if (this.filtro == null) {
			filtro = new FiltroBandeiraCartaoVO();
		}
		return filtro;
	}

	/**
	 * @param filtro
	 *            the filtro to set
	 */
	public void setFiltro(FiltroBandeiraCartaoVO filtro) {
		this.filtro = filtro;
	}

	/**
	 * @return the isAtivoOpcoes
	 */
	public List<TrueFalseEnum> getSituacoes() {
		return Arrays.asList(TrueFalseEnum.values());
	}

	public List<TipoMovimentacaoBandeiraEnum> getTiposMovimentos(){
		return Arrays.asList(TipoMovimentacaoBandeiraEnum.values());
	}
	
	/**
	 * <p>
	 * Retorna o valor do atributo isInclusao
	 * </p>
	 * .
	 *
	 * @return isInclusao
	 */
	public boolean isInclusao() {
		return this.isInclusao;
	}

	/**
	 * <p>
	 * Define o valor do atributo isInclusao
	 * </p>
	 * .
	 *
	 * @param isInclusao
	 *            valor a ser atribuído
	 */
	public void setInclusao(boolean isInclusao) {
		this.isInclusao = isInclusao;
	}
}
