package br.gov.caixa.siacg.view.form;

import br.gov.caixa.siacg.model.domain.Despesa;
import br.gov.caixa.siacg.model.domain.leilao.Leilao;

public class LeilaoDespesaVisao extends TemplateVisao<Despesa> {

    private static final long serialVersionUID = 1L;

    private Leilao leilao;

    public Leilao getLeilao() {
	return this.leilao;
    }

    public void setLeilao(Leilao leilao) {
	this.leilao = leilao;
    }

}
