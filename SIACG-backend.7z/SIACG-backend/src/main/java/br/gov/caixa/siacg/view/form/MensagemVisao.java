/**
 * Copyright (c) 2013 Caixa Econômica Federal. Todos os direitos
 * reservados.
 *
 * Caixa Econômica Federal - SIACG - Sistema de Crédito Rural
 *
 * Este software foi desenvolvido sob demanda da CAIXA e está
 * protegido por leis de direitos autorais e tratados internacionais. As
 * condições de cópia e utilização do todo ou partes dependem de autorização da
 * pessoa. Cópias não são permitidas sem expressa autorização. Não pode ser
 * comercializado ou utilizado para propósitos particulares.
 *
 * Uso exclusivo da Caixa Econômica Federal. A reprodução ou distribuição não
 * autorizada deste programa ou de parte dele, resultará em punições civis e
 * criminais e os infratores incorrem em sanções previstas na legislação em
 * vigor.
 *
 * Histórico do Subversion:
 *
 * LastChangedRevision: $Revision$
 * LastChangedBy: $Author$
 * LastChangedDate: $Date$
 *
 * HeadURL: $HeadURL$
 *
 */
package br.gov.caixa.siacg.view.form;

import br.gov.caixa.siacg.model.domain.Mensagem;

/**
 * <p>
 * MensagemVisao
 * </p>
 * <p>
 * Descrição: Classe responsável por armazenar os dados da visão do caso de uso
 * <code> Mantem mensagem de apresentação </code>.
 * </p>
 * <br>
 * <b>Empresa:</b> Cef - Caixa Econômica Federal
 *
 * @author Waltenes Junior
 * @version 1.0
 */
public class MensagemVisao extends TemplateVisao<Mensagem> {

    private static final long serialVersionUID = -1635010541182342440L;

    private boolean edicao;

    /**
     * Retorna o valor do atributo edicao.
     *
     * @return edicao
     */
    public boolean isEdicao() {
        return this.edicao;
    }

    /**
     * Define o valor do atributo edicao.
     *
     * @param edicao
     *            valor a ser atribuído
     */
    public void setEdicao(final boolean edicao) {
        this.edicao = edicao;
    }
}
