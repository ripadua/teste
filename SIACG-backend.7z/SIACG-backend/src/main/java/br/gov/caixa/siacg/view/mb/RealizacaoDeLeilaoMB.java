package br.gov.caixa.siacg.view.mb;

import java.util.List;
import java.util.Objects;

import javax.ejb.EJB;
import javax.enterprise.context.SessionScoped;
import javax.inject.Inject;
import javax.inject.Named;

import org.primefaces.context.RequestContext;

import br.gov.caixa.pedesgo.arquitetura.controlador.ManutencaoBean;
import br.gov.caixa.pedesgo.arquitetura.util.UtilObjeto;
import br.gov.caixa.siacg.commons.AppConstant;
import br.gov.caixa.siacg.comum.to.sicli.RespostaSicliTO;
import br.gov.caixa.siacg.jms.SolicitaDadosClienteSicli;
import br.gov.caixa.siacg.model.domain.leilao.HistoricoLeilao;
import br.gov.caixa.siacg.model.domain.leilao.Leilao;
import br.gov.caixa.siacg.model.enums.leilao.OpcoesLancamentoEnum;
import br.gov.caixa.siacg.model.enums.leilao.SituacaoLeilaoEnum;
import br.gov.caixa.siacg.model.vo.FiltroLeilaoVO;
import br.gov.caixa.siacg.pagination.LeilaoLazyModel;
import br.gov.caixa.siacg.service.BemClienteService;
import br.gov.caixa.siacg.service.ContratoService;
import br.gov.caixa.siacg.service.HistoricoLeilaoService;
import br.gov.caixa.siacg.service.ImovelService;
import br.gov.caixa.siacg.service.LeilaoService;
import br.gov.caixa.siacg.view.form.LeilaoVisao;

@Named
@SessionScoped
public class RealizacaoDeLeilaoMB extends ManutencaoBean<Leilao> {

    private static final long serialVersionUID = 1L;

    private static final String PAGINA_CONSULTA = "/pages/realizacaoDeLeilao/consulta.xhtml?faces-redirect=true";
    private static final String NOME_MANAGED_BEAN = "realizacaoDeLeilaoMB";

    @EJB
    private transient LeilaoService service;

    @EJB
    private transient BemClienteService bemClienteService;

    @EJB
    private transient ImovelService imovelService;

    @EJB
    private transient ContratoService contratoService;

    @EJB
    private SolicitaDadosClienteSicli solicitaDadosClienteSicli;
    
    @EJB
    private HistoricoLeilaoService historicoLeilaoService;
    
    @EJB
    private LeilaoService leilaoService;

    private LeilaoVisao visao;

    @Inject
    private LeilaoLazyModel consulta;

    @Inject
    private LeilaoOpcoesLancamentoFactory leilaoOpcoesLancamentoFactory;

    @Override
    protected String getNomeVarResourceBundle() {
	return AppConstant.RESOURCE_BUNDLE;
    }

    @Override
    protected String getPrefixoCasoDeUso() {
	return NOME_MANAGED_BEAN;
    }

    @SuppressWarnings("unchecked")
    @Override
    public LeilaoService getService() {
	return service;
    }

    @Override
    public LeilaoVisao getVisao() {
	if (!UtilObjeto.isReferencia(this.visao)) {
	    this.visao = new LeilaoVisao();
	}
	return this.visao;
    }

    public String abrirConsulta() {
	this.getVisao().setOpcaoLancamento(null);
	return RealizacaoDeLeilaoMB.PAGINA_CONSULTA;
    }

    public void limparConsulta() {
	this.getConsulta().setFiltro(new FiltroLeilaoVO());
    }

    public void pesquisar() {
	this.getConsulta();
    }

    public LeilaoLazyModel getConsulta() {
	return this.consulta;
    }

    public void setConsulta(LeilaoLazyModel consulta) {
	this.consulta = consulta;
    }

    public void visualizarImovel(final Leilao leilao) {

	getVisao().setBemCliente(bemClienteService.obter(leilao.getNuBemCliente()));

	this.getVisao().getBemCliente().getImovel()
		.setListaProprietario(this.bemClienteService.listarProprietariosAtivosImovel(getVisao().getBemCliente().getImovel().getNuImovel()));
    }
    
    public void listarHistoricoLeilao(final Leilao leilao) {
	this.getVisao().setEntidade(leilao);
	final List<HistoricoLeilao> listaHistoricoLeilao = this.historicoLeilaoService.listarHistoricoLeilao(leilao.getId());
	this.getVisao().setListaHistoricoLeilao(listaHistoricoLeilao);
    }

    public void visualizarContrato(final Leilao leilao) {
	getVisao().setContrato(this.contratoService.obterContratoComRelacionamentosInicializados(leilao.getNuContrato()));
    }

    public void visualizarEmpreendimento(final Leilao leilao) {

	RequestContext context = RequestContext.getCurrentInstance();

	String nuCnpj = leilao.getNuCnpj();
	RespostaSicliTO resposta = this.solicitaDadosClienteSicli.consultarCliente(nuCnpj);

	if (Objects.nonNull(resposta)) {

	    getVisao().setEmpreendimento(resposta);

	    context.execute("PF('dialogWidgetEmpreendimento').show()");

	} else {
	    this.adicionaMensagemDeErro("MA017");
	}

    }

    public void confirmar() {
	final OpcoesLancamentoEnum opcaoLancamento = this.getVisao().getOpcaoLancamento();
	if(opcaoLancamento != null) {
	    leilaoOpcoesLancamentoFactory.getArquivos().get(opcaoLancamento).iniciar(this.getVisao().getEntidade());
	}
    }
    
    public void sanarPendencia() {
	final Leilao leilao = this.leilaoService.sanarPendenciaLeilao(this.getVisao().getEntidade());
	
	if(leilao.getIcSituacao() != SituacaoLeilaoEnum.EM_PENDENCIA) {
	    this.adicionaMensagemDeSucesso("Operação realizada com sucesso!");
	} else {
	    this.adicionaMensagemDeAlerta("Não foi possível realizar a operação.");
	}
    }
    
    public void removerImovelProcessoLeilao() {
	final Leilao leilao = this.leilaoService.removerImovelProcessoLeilao(this.getVisao().getEntidade());

	if (leilao.getIcSituacao() == SituacaoLeilaoEnum.EXCLUIDO) {
	    this.adicionaMensagemDeSucesso("Operação realizada com sucesso!");
	} else {
	    this.adicionaMensagemDeAlerta("Não foi possível realizar a operação.");
	}
    }

}
