/**
 * reservados. Copyright (c) 2009-2011 Caixa Econômica Federal. Todos os direitos
 *
 * Caixa Econômica Federal - SIACG – Sistema de Acompanhamento de Carteiras de Cobrança
 *
 * Este programa de computador foi desenvolvido sob demanda da CAIXA e está protegido por leis de direitos autorais e
 * tratados internacionais. As condições de cópia e utilização do todo ou partes dependem de autorização da pessoa.
 * Cópias não são permitidas sem expressa autorização. Não pode ser comercializado ou utilizado para propósitos
 * particulares.
 *
 * Uso exclusivo da Caixa Econômica Federal. A reprodução ou distribuição não autorizada deste programa ou de parte
 * dele, resultará em punições civis e criminais e os infratores incorrem em sanções previstas na legislação em vigor.
 *
 * Histórico do Subversion:
 *
 * LastChangedRevision: LastChangedBy: LastChangedDate:
 *
 * HeadURL:
 *
 */
package br.gov.caixa.siacg.view.mb;

import javax.annotation.PostConstruct;
import javax.ejb.EJB;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;
import javax.inject.Inject;

import br.gov.caixa.pedesgo.arquitetura.controlador.ManutencaoBean;
import br.gov.caixa.pedesgo.arquitetura.to.MensagemTO;
import br.gov.caixa.pedesgo.arquitetura.util.MensagensUtil;
import br.gov.caixa.pedesgo.arquitetura.util.UtilObjeto;
import br.gov.caixa.pedesgo.arquitetura.util.UtilString;
import br.gov.caixa.siacg.model.domain.GestaoServentia;
import br.gov.caixa.siacg.model.domain.InstituicaoBancaria;
import br.gov.caixa.siacg.service.GestaoServentiaService;
import br.gov.caixa.siacg.service.InstituicaoBancariaService;
import br.gov.caixa.siacg.view.form.GestaoServentiaVisao;

/**
 * <p>
 * GestaoServentiaMB
 * </p>
 * <p>
 * Descrição: Managed bean do caso de uso <code>GestaoServentia</code>.
 * </p>
 * <br>
 * <b>Empresa:</b> Cef - Caixa Econômica Federal
 *
 * @author Leandro Oliveira
 * @version 1.0
 */
@ManagedBean
@SessionScoped
public class GestaoServentiaMB extends ManutencaoBean<GestaoServentia> {

	private static final String REGISTRO_ATIVO_MA007 = "MA007";

	private static final String REGISTRO_INATIVO_MA006 = "MA006";

	private static final String FILTRO_OBRIGATORIO_PARA_CONSULTA = "MN064";

	/** Atributo serialVersionUID. */
	private static final long serialVersionUID = 1133316313004308593L;

	/** Atributo NOME_MANAGED_BEAN. */
	public static final String NOME_MANAGED_BEAN = "gestaoServentialMB";

	/** Atributo EL_MANAGED_BEAN. */
	public static final String EL_MANAGED_BEAN = "#{gestaoServentiaMB}";

	/** Atributo PAGINA_SACADO_CONSULTA. */
	private static final String PAGINA_GESTAO_SERVENTIA_CONSULTA = "/pages/gestaoServentia/consulta.xhtml?faces-redirect=true";

	private static final String PAGINA_GESTAO_SERVENTIA_INCLUSAO = "/pages/gestaoServentia/edicao.xhtml?faces-redirect=true";

	/** Atributo MENSAGE_SUCESSO. */
	private static final String MENSAGE_SUCESSO = "MA002";

	/** Atributo MSG_APP. */
	private static final String MSG_APP = "msgApp";

	/** Atributo service. */
	@EJB
	private transient GestaoServentiaService service;
	
	@Inject
	private transient InstituicaoBancariaService bancoServico;

	/** Atributo visao. */
	private GestaoServentiaVisao visao;

	/**
	 * <p>
	 * Método responsável por abrir a tela de consutla da Gestao Serventia.
	 * <p>
	 *
	 * @param filtro
	 * @return <code>String</code>
	 * @author Leandro Oliveira
	 */
	public String abrirConsulta() {
		this.limparFiltros();
		return GestaoServentiaMB.PAGINA_GESTAO_SERVENTIA_CONSULTA;
	}

	public void limparFiltros() {
		this.visao = null;
		//this.getVisao().getEntidade().geti
		this.getVisao().getLista().clear();
		this.visao.getLista().addAll(this.getService().listar());
	}

	/**
	 * <p>
	 * Método responsável por abrir a tela de consutla da Gestao Serventia.
	 * <p>
	 *
	 * @param filtro
	 * @return <code>String</code>
	 * @author Leandro Oliveira
	 */
	public void filtrar() {
		if (!UtilString.isVazio(this.visao.getEntidade().getCodigoCns())
				|| !UtilString.isVazio(this.visao.getEntidade().getDenominacao())
				|| !UtilString.isVazio(this.visao.getEntidade().getDescricaoMunicipio())
				|| !UtilString.isVazio(this.visao.getEntidade().getSiglaUf())
				|| !UtilString.isVazio(this.visao.getEntidade().getSituacao())) {
			this.getVisao().setLista(this.getService().listarGestaoServentiaPorFiltros(this.visao.getEntidade()));
		} else {
			super.adicionaMensagemDeAlerta(MensagensUtil.getMensagem(GestaoServentiaMB.MSG_APP,
					GestaoServentiaMB.FILTRO_OBRIGATORIO_PARA_CONSULTA));
		}
	}

	/**
	 * <p>
	 * Método responsável por abrir a tela de edição da Gestao Serventia.
	 * <p>
	 *
	 * @param sacado valor a ser atribuído
	 * @return <code>String</code>
	 * @author Leandro Oliveira
	 */
	public String abrirEdicao(final GestaoServentia gestaoServentia) {
		this.visao.getListaInstituicaoBancaria().addAll((this.bancoServico.listarTodos()));
		GestaoServentia item = this.service.obter(gestaoServentia.getNuGestaoServentia());
		if(item.getInstiuicaoBancaria() == null || item.getInstiuicaoBancaria().getNuInstuicaoBancaria() == null) {
			item.setInstiuicaoBancaria(new InstituicaoBancaria());
		}
		this.visao.setEntidade(item);
		this.mostrarDadosBancarios();
		return GestaoServentiaMB.PAGINA_GESTAO_SERVENTIA_INCLUSAO;
	}

	/**
	 * <p>
	 * Método responsável por abrir a tela de edição da Gestao Serventia.
	 * <p>
	 *
	 * @param sacado valor a ser atribuído
	 * @return <code>String</code>
	 * @author Leandro Oliveira
	 */
	public String abrirInclusao() {
		this.visao.setEntidade(new GestaoServentia());
		this.visao.getListaInstituicaoBancaria().addAll((this.bancoServico.listarTodos()));
		this.mostrarDadosBancarios();
		return GestaoServentiaMB.PAGINA_GESTAO_SERVENTIA_INCLUSAO;
	}
	
	public void onSelectIcBanco() {
		if (getVisao().getEntidade().getInstiuicaoBancaria() != null && getVisao().getEntidade().getInstiuicaoBancaria().getNuInstuicaoBancaria() != null) {
			this.getVisao().setMostraDadosBancarios(this.getVisao().getEntidade().getInstiuicaoBancaria().getNuInstuicaoBancaria() > 0);
		}
	}
	
	public boolean apresentaDadosBancarios() {
		return getVisao().getEntidade().getInstiuicaoBancaria() != null && (getVisao().getEntidade().getInstiuicaoBancaria().getNuInstuicaoBancaria() != null);
	}
	
	@PostConstruct
	public void atualizarTela() {
		this.mostrarDadosBancarios();
	}
	
	public boolean mostrarDadosBancarios() {
		boolean retorno = true;
//		if (this.getVisao().getEntidade().getInstiuicaoBancaria().getNuInstuicaoBancaria() != null &&  this.getVisao().getEntidade().getInstiuicaoBancaria().getNuInstuicaoBancaria() > 0) {
//			retorno = true;
//		}
		return retorno;
	}

	public void salvarAlterarGestaoServentia() {
		this.getService().validarDados(visao.getEntidade());

		if (visao.getEntidade().hasMensagens()) {
			for (final MensagemTO mensagem : visao.getEntidade().getMensagens()) {
				MensagensUtil.adicionaMensagemDeAlerta(GestaoServentiaMB.MSG_APP, mensagem.getChaveMensagem(),
						mensagem.getArgumentos());
			}
		} else {
			if (!UtilObjeto.isReferencia(this.visao.getEntidade().getNuGestaoServentia())
					|| this.visao.getEntidade().getNuGestaoServentia() == 0) {
				this.visao.getEntidade().setIcAtivo(Boolean.TRUE);
			}
		
			this.getService().salvar(this.visao.getEntidade());
			this.getVisao().setMensagemModal(MensagensUtil.getMensagem(GestaoServentiaMB.MSG_APP, GestaoServentiaMB.MENSAGE_SUCESSO));
			this.visao.getEntidade().setInstiuicaoBancaria( new InstituicaoBancaria());
		}
	}

	public String getDescricaoBotao() {
		final String INCLUIR = "Incluir";
		final String ALTERAR = "Alterar";
		return this.getVisao().getEntidade().getNuGestaoServentia() == null ? INCLUIR : ALTERAR;
	}

	public void atribuirValorEntidade(final GestaoServentia gestao) {
		this.getVisao().setGestaoServentia(gestao);
	}

	public void ativarInativarGestaoServentia() {
		this.getVisao().getGestaoServentia().setIcAtivo(!this.getVisao().getGestaoServentia().getIcAtivo());
		this.getService().salvar(this.visao.getGestaoServentia());

		if (this.visao.getGestaoServentia().getIcAtivo()) {
			super.adicionaMensagemDeSucesso(
					MensagensUtil.getMensagem(GestaoServentiaMB.MSG_APP, GestaoServentiaMB.REGISTRO_ATIVO_MA007));
		} else {
			super.adicionaMensagemDeSucesso(
					MensagensUtil.getMensagem(GestaoServentiaMB.MSG_APP, GestaoServentiaMB.REGISTRO_INATIVO_MA006));
		}
		this.getVisao().setLista(this.getService().listarGestaoServentiaPorFiltros(new GestaoServentia()));
	}
	
	@Override
	protected String getPrefixoCasoDeUso() {
		return null;
	}

	@SuppressWarnings("unchecked")
	@Override
	public GestaoServentiaService getService() {
		return this.service;
	}

	@Override
	public GestaoServentiaVisao getVisao() {
		if (this.visao == null) {
			this.visao = new GestaoServentiaVisao();
		}
		return this.visao;
	}

}
