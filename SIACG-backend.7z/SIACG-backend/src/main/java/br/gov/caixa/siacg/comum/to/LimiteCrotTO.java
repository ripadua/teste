/*
 * Copyright (c) 2016 Caixa Econômica Federal. Todos os direitos
 * reservados.
 *
 * Caixa Econômica Federal - SIACG_dev
 *
 * Este software foi desenvolvido sob demanda da CAIXA e está
 * protegido por leis de direitos autorais e tratados internacionais. As
 * condições de cópia e utilização do todo ou partes dependem de autorização da
 * pessoa. Cópias não são permitidas sem expressa autorização. Não pode ser
 * comercializado ou utilizado para propósitos particulares.
 *
 * Uso exclusivo da Caixa Econômica Federal. A reprodução ou distribuição não
 * autorizada deste programa ou de parte dele, resultará em punições civis e
 * criminais e os infratores incorrem em sanções previstas na legislação em
 * vigor.
 *
 * Histórico do Subversion:
 *
 * LastChangedRevision: $Revision$
 * LastChangedBy: $Author$
 * LastChangedDate: $Date$
 *
 * HeadURL: $HeadURL$
 *
 */
package br.gov.caixa.siacg.comum.to;

import java.math.BigDecimal;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import br.gov.caixa.siacg.exception.ParametrosInvalidosException;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

/**
 * <p>LimiteCrotTO</p>
 *
 * <p>Descrição: Descrição do tipo</p>
 *
 * <br><b>Empresa:</b> Cef - Caixa Econômica Federal
 *
 *
 * @author p575337
 *
 * @version 1.0
 */
@JsonIgnoreProperties(ignoreUnknown = true)
@ApiModel(value="LimiteCROT")
public class LimiteCrotTO {

    @ApiModelProperty(value = "Unidade/Agência", example="612")
    private Integer unidade;
    @ApiModelProperty(value = "Produto", example="1288-POUPANCA - PF")
    private String produto;
    @ApiModelProperty(value = "Número", example="989486549")
    private Integer numero;
    @ApiModelProperty(value = "Digíto", example="1")
    private Integer dv;
    @ApiModelProperty(value = "Limite CROT contratado.", example="5001.89")
    private BigDecimal limniteCrotContratado;
    @ApiModelProperty(value = "Código da Mensagem", example="00")
    private String codigoMensagem;
    @ApiModelProperty(value = "Mesnagem retornada pelo serviço integrado ou o SIACG.", example="OPERACAO REALIZADA COM SUCESSO.")
    private String mensagem;
    @ApiModelProperty(value = "Qual Sistema Originou a Mensagem.", example="SID00")
    private String origem;




    public LimiteCrotTO() {
	super();

    }

    public LimiteCrotTO(ContaSid09TO contaTO) {
	this();
	setUnidade(contaTO.getUnidade());
	setProduto(String.valueOf(contaTO.getProduto()));
	setNumero(contaTO.getNumero());
	setDv(contaTO.getDv());
    }

    public LimiteCrotTO(ParametrosInvalidosException e) {
	setCodigoMensagem(e.getCodigo());
	setMensagem(e.getDescricao());
	setOrigem(e.getSistema());
    }

    /**
     * <p>Retorna o valor do atributo unidade</p>.
     *
     * @return unidade
     */
    public Integer getUnidade() {
	return this.unidade;
    }
    /**
     * <p>Define o valor do atributo unidade</p>.
     *
     * @param unidade valor a ser atribuído
     */
    public void setUnidade(Integer unidade) {
	this.unidade = unidade;
    }
    /**
     * <p>Retorna o valor do atributo produto</p>.
     *
     * @return produto
     */
    public String getProduto() {
	return this.produto;
    }
    /**
     * <p>Define o valor do atributo produto</p>.
     *
     * @param produto valor a ser atribuído
     */
    public void setProduto(String produto) {
	this.produto = produto;
    }
    /**
     * <p>Retorna o valor do atributo numero</p>.
     *
     * @return numero
     */
    public Integer getNumero() {
	return this.numero;
    }
    /**
     * <p>Define o valor do atributo numero</p>.
     *
     * @param numero valor a ser atribuído
     */
    public void setNumero(Integer numero) {
	this.numero = numero;
    }
    /**
     * <p>Retorna o valor do atributo dv</p>.
     *
     * @return dv
     */
    public Integer getDv() {
	return this.dv;
    }
    /**
     * <p>Define o valor do atributo dv</p>.
     *
     * @param dv valor a ser atribuído
     */
    public void setDv(Integer dv) {
	this.dv = dv;
    }

    /**
     * <p>Retorna o valor do atributo codigoMensagem</p>.
     *
     * @return codigoMensagem
     */
    public String getCodigoMensagem() {
	return this.codigoMensagem;
    }

    /**
     * <p>Define o valor do atributo codigoMensagem</p>.
     *
     * @param codigoMensagem valor a ser atribuído
     */
    public void setCodigoMensagem(String codigoMensagem) {
	this.codigoMensagem = codigoMensagem;
    }

    /**
     * <p>Retorna o valor do atributo mensagem</p>.
     *
     * @return mensagem
     */
    public String getMensagem() {
	return this.mensagem;
    }

    /**
     * <p>Define o valor do atributo mensagem</p>.
     *
     * @param mensagem valor a ser atribuído
     */
    public void setMensagem(String mensagem) {
	this.mensagem = mensagem;
    }

    /**
     * <p>Retorna o valor do atributo origem</p>.
     *
     * @return origem
     */
    public String getOrigem() {
	return this.origem;
    }

    /**
     * <p>Define o valor do atributo origem</p>.
     *
     * @param origem valor a ser atribuído
     */
    public void setOrigem(String origem) {
	this.origem = origem;
    }

    /**
     * <p>Retorna o valor do atributo limniteCrotContratado</p>.
     *
     * @return limniteCrotContratado
     */
    public BigDecimal getLimniteCrotContratado() {
	return this.limniteCrotContratado;
    }

    /**
     * <p>Define o valor do atributo limniteCrotContratado</p>.
     *
     * @param limniteCrotContratado valor a ser atribuído
     */
    public void setLimniteCrotContratado(BigDecimal limniteCrotContratado) {
	this.limniteCrotContratado = limniteCrotContratado;
    }
}