/**
 * Copyright (c) 2013 Caixa Econômica Federal. Todos os direitos reservados.
 *
 * Caixa Econômica Federal - SIACG - Sistema de Crédito Rural
 *
 * Este software foi desenvolvido sob demanda da CAIXA e está protegido por leis de direitos autorais e tratados
 * internacionais. As condições de cópia e utilização do todo ou partes dependem de autorização da pessoa. Cópias não
 * são permitidas sem expressa autorização. Não pode ser comercializado ou utilizado para propósitos particulares.
 *
 * Uso exclusivo da Caixa Econômica Federal. A reprodução ou distribuição não autorizada deste programa ou de parte
 * dele, resultará em punições civis e criminais e os infratores incorrem em sanções previstas na legislação em vigor.
 *
 * Histórico do Subversion:
 *
 * LastChangedRevision: $Revision$ LastChangedBy: $Author$ LastChangedDate: $Date$
 *
 * HeadURL: $HeadURL$
 *
 */
package br.gov.caixa.siacg.view.mb;

import javax.ejb.EJB;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ManagedProperty;
import javax.faces.bean.SessionScoped;

import br.gov.caixa.pedesgo.arquitetura.controlador.ManutencaoBean;
import br.gov.caixa.pedesgo.arquitetura.enumerador.EnumAcao;
import br.gov.caixa.pedesgo.arquitetura.util.MensagensUtil;
import br.gov.caixa.pedesgo.arquitetura.util.UsuarioUtil;
import br.gov.caixa.pedesgo.arquitetura.util.UtilObjeto;
import br.gov.caixa.pedesgo.arquitetura.util.UtilString;
import br.gov.caixa.siacg.model.domain.Mensagem;
import br.gov.caixa.siacg.model.enums.NoFuncionalidadeEnum;
import br.gov.caixa.siacg.pagination.MensagemLazyModel;
import br.gov.caixa.siacg.service.MensagemService;
import br.gov.caixa.siacg.view.form.MensagemVisao;

/**
 * <p>
 * MensagemMB.
 * </p>
 * <p>
 * Descrição: Managed bean do caso de uso
 * <code> Mantem mensagem de apresentação </code>
 * </p>
 * <br>
 * <b>Empresa:</b> Cef - Caixa Econômica Federal
 *
 * @author Waltenes Junior
 * @version 1.0
 */
@ManagedBean
@SessionScoped
public class MensagemMB extends ManutencaoBean<Mensagem> {

    private static final long serialVersionUID = 598501248515653348L;

    /** Atributo NOME_MANAGED_BEAN. */
    public static final String NOME_MANAGED_BEAN = "mensagemMB";

    /** Atributo EL_MANAGED_BEAN. */
    public static final String EL_MANAGED_BEAN = "#{mensagemMB}";

    /** Atributo PAGINA_MENSAGEM_EDICAO. */
    private static final String PAGINA_MENSAGEM_EDICAO = "/pages/mensagem/edicao.xhtml?faces-redirect=true";

    /** Atributo PAGINA_MENSAGEM_DETALHE. */
    private static final String PAGINA_MENSAGEM_DETALHE = "/pages/mensagem/detalhe.xhtml?faces-redirect=true";

    /** Atributo PAGINA_MENSAGEM_CONSULTA. */
    private static final String PAGINA_MENSAGEM_CONSULTA = "/pages/mensagem/consulta.xhtml?faces-redirect=true";

    /** Atributo MENSAGEM_CAMPO_OBRIGATORIO. */
    private static final String MENSAGEM_CAMPO_OBRIGATORIO = "MA005";

    /** Atributo MENSAGEM_INATIVAR_REGISTRO. */
    private static final String MENSAGEM_INATIVAR_REGISTRO = "MC003";

    /** Atributo PROPERTIE_APP_MENSAGEM. */
    private static final String PROPERTIE_APP_MENSAGEM = "msgApp";

    /** Atributo consulta. */
    @ManagedProperty(value = MensagemLazyModel.EL_MANAGED_BEAN)
    private MensagemLazyModel consulta;

    /** Atributo service. */
    @EJB
    private transient MensagemService service;

    /** Atributo visao. */
    private transient MensagemVisao visao;

    /**
     * <p>
     * Método responsável por abrir a pagina de edição da mensagem.
     * <p>
     *
     * @param entidade
     *            valor a ser atribuído
     * @return String com a pagina de edição
     * @author Waltenes Junior
     */
    public String abrirEdicao(final Mensagem entidade) {
        this.getVisao().setEntidade(entidade);
        this.getVisao().setEdicao(true);
        return MensagemMB.PAGINA_MENSAGEM_EDICAO;
    }

    /**
     * <p>
     * Método responsável por carregar dados da tela de consulta.
     * <p>
     *
     * @return String
     * @author guilherme.santos
     */
    public String abrirConsulta() {
        this.verificarPermissoes();
        return MensagemMB.PAGINA_MENSAGEM_CONSULTA;
    }

    /**
     * <p>
     * Método responsável por abrir a pagina de inclusão da mensagem.
     * <p>
     *
     * @return String com a pagina de edição
     * @author Waltenes Junior
     */
    public String abrirInclusao() {
        this.getVisao().setEdicao(false);
        this.getVisao().setEntidade(new Mensagem());
        return MensagemMB.PAGINA_MENSAGEM_EDICAO;
    }

    /**
     * <p>
     * Método responsável por incluir uma mensagem na base de dados.
     * <p>
     *
     * @param entidade
     *            valor a ser atribuído
     * @return String com a mesma tela.
     * @author Waltenes Junior
     */
    public String incluirMensagem(final Mensagem entidade) {
        if (!UtilObjeto.isReferencia(entidade.getDeTituloMensagem()) || UtilString.isVazio(entidade.getDeTituloMensagem())
                || !UtilObjeto.isReferencia(entidade.getDtInicioApresentacaoMensagem())
                || !UtilObjeto.isReferencia(entidade.getDtFimApresentacaoMensagem()) || !UtilObjeto.isReferencia(entidade.getDeMensagem())
                || UtilString.isVazio(entidade.getDeMensagem())) {

            super.adicionaMensagemInformativa(MensagemMB.MENSAGEM_CAMPO_OBRIGATORIO);
        } else {
            this.getVisao().setMensagemModal(MensagensUtil.getMensagem(MensagemMB.PROPERTIE_APP_MENSAGEM, this.service.incluirMensagem(entidade)));

            this.getVisao().setExibirModal(true);
        }
        return super.MESMA_TELA;
    }

    /**
     * <p>
     * Método responsável por abrir a tela de detalhe da mensagem.
     * <p>
     *
     * @param entidade
     *            valor a ser atribuído
     * @return String com a mesma tela.
     * @author Waltenes Junior
     */
    public String abrirDetalhe(final Mensagem entidade) {
        this.getVisao().setEntidade(entidade);
        return MensagemMB.PAGINA_MENSAGEM_DETALHE;
    }

    /**
     * <p>
     * Método responsável por abrir modal de afirmação de inativação da
     * visualização da mensagem.
     * <p>
     *
     * @author Waltenes Junior
     */
    public void abrirModalInativarVisualizacaoMensagem() {
        this.getVisao().setMensagemModal(MensagensUtil.getMensagem(MensagemMB.PROPERTIE_APP_MENSAGEM, MensagemMB.MENSAGEM_INATIVAR_REGISTRO));
        this.getVisao().setExibirModal(true);
    }

    /**
     * <p>
     * Método responsável por atualizar visualização da mensagem - se estiver
     * ativada ele inativa.
     * <p>
     *
     * @param entidade
     *            valor a ser atribuído
     * @return String com a mesma tela
     * @author Waltenes Junior
     */
    public String atualizarVisualizacaoMensagem(final Mensagem entidade) {
        if (entidade.getIcAtivo().equals(true)) {
            entidade.setIcAtivo(false);
        }
        return super.salvar(entidade);
    }

    /**
     * @see br.gov.caixa.pedesgo.arquitetura.controlador.AbstractBean#getNomeVarResourceBundle()
     */
    @Override
    protected String getNomeVarResourceBundle() {
        return MensagemMB.PROPERTIE_APP_MENSAGEM;
    }

    /**
     * @see br.gov.caixa.pedesgo.arquitetura.controlador.AbstractBean#getService()
     */
    @SuppressWarnings("unchecked")
    @Override
    public MensagemService getService() {
        return this.service;
    }

    /**
     * @see br.gov.caixa.pedesgo.arquitetura.controlador.AbstractBean#getVisao()
     */
    @Override
    public MensagemVisao getVisao() {
        if (this.visao == null) {
            this.visao = new MensagemVisao();
        }
        return this.visao;
    }

    /**
     * Retorna o valor do atributo consulta.
     *
     * @return consulta
     */
    public MensagemLazyModel getConsulta() {
        return this.consulta;
    }

    /**
     * Define o valor do atributo consulta.
     *
     * @param consulta
     *            valor a ser atribuído
     */
    public void setConsulta(final MensagemLazyModel consulta) {
        this.consulta = consulta;
    }

    /**
     * @see br.gov.caixa.pedesgo.arquitetura.controlador.AbstractBean#getPrefixoCasoDeUso()
     */
    @Override
    protected String getPrefixoCasoDeUso() {
        return null;
    }

    /**
     * <p>
     * Método responsável por verificar permissões do usuario logado.
     * <p>
     *
     * @author guilherme.santos
     */
    private void verificarPermissoes() {
        // Controle de permissões da funcionalidade Editar Sacado Não Aceito
        this.getVisao().setExibirBotaoEditar(UsuarioUtil.contemPermissao(NoFuncionalidadeEnum.MANTEM_SACADO_NAO_ACEITO.getNoFuncionalidade(),
                EnumAcao.ALTERAR.getNoAcao(), null, null));
        // Controle de permissões da funcionalidade Editar Sacado Não Aceito
        this.getVisao().setExibirBotaoIncluir(UsuarioUtil.contemPermissao(NoFuncionalidadeEnum.MANTEM_SACADO_NAO_ACEITO.getNoFuncionalidade(),
                EnumAcao.INCLUIR.getNoAcao(), null, null));
        // Controle de permissões da funcionalidade Editar Sacado Não Aceito
        this.getVisao().setExibirBotaoExcluir(UsuarioUtil.contemPermissao(NoFuncionalidadeEnum.MANTEM_SACADO_NAO_ACEITO.getNoFuncionalidade(),
                EnumAcao.EXCLUIR.getNoAcao(), null, null));
    }
}
