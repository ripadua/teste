package br.gov.caixa.siacg.view.mb;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collection;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.ejb.EJB;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;
import javax.faces.component.UIComponent;
import javax.faces.component.html.HtmlPanelGrid;
import javax.faces.context.FacesContext;
import javax.faces.event.AjaxBehaviorEvent;
import javax.inject.Inject;
import javax.servlet.http.HttpServletRequest;

import org.apache.commons.lang.StringUtils;

import br.gov.caixa.pedesgo.arquitetura.controlador.ManutencaoBean;
import br.gov.caixa.pedesgo.arquitetura.enumerador.EnumAcao;
import br.gov.caixa.pedesgo.arquitetura.enumerador.EnumNomeAbrangenciaRestritaUnidade;
import br.gov.caixa.pedesgo.arquitetura.enumerador.EnumTipoAbrangencia;
import br.gov.caixa.pedesgo.arquitetura.util.UsuarioUtil;
import br.gov.caixa.pedesgo.arquitetura.util.UtilObjeto;
import br.gov.caixa.pedesgo.arquitetura.util.UtilString;
import br.gov.caixa.siacg.exception.ParametrosInvalidosException;
import br.gov.caixa.siacg.model.domain.DWAnaliseContrato;
import br.gov.caixa.siacg.model.domain.Segmento;
import br.gov.caixa.siacg.model.enums.NoFuncionalidadeEnum;
import br.gov.caixa.siacg.model.vo.EmpreendimentoVO;
import br.gov.caixa.siacg.model.vo.SrEUnidadeVO;
import br.gov.caixa.siacg.model.vo.SrVO;
import br.gov.caixa.siacg.model.vo.UnidadeVO;
import br.gov.caixa.siacg.pagination.EmpreendimentoLazyMode;
import br.gov.caixa.siacg.service.DWAnaliseContratoService;
import br.gov.caixa.siacg.service.EmpreendimentoService;
import br.gov.caixa.siacg.service.PropriedadeService;
import br.gov.caixa.siacg.service.SuatService;
import br.gov.caixa.siacg.service.UnidadeService;
import br.gov.caixa.siacg.service.UnidadeVinculadaSuatService;
import br.gov.caixa.siacg.singleton.UsuarioOnlineSingleton;
import br.gov.caixa.siacg.util.LogCEF;
import br.gov.caixa.siacg.view.form.DWAnaliseContratoVisao;
import br.gov.caixa.siacg.view.form.EmpreendimentoVisao;

/**
 * <p>
 * DWAnaliseContratoMB.
 * </p>
 * <p>
 * Descrição: Classe controller da pagina index.
 * </p>ar
 * <br>
 * <b>Empresa:</b> Cef - Caixa Econômica Federal
 *
 * @author Caio Graco
 * @version 1.0
 */
@ManagedBean
@ViewScoped
public class DWAnaliseContratoMB extends ManutencaoBean<DWAnaliseContrato> {

	private static final long serialVersionUID = 3641157987679854793L;

	/** Atributo NOME_MANAGED_BEAN. */
	public static final String NOME_MANAGED_BEAN = "dWAnaliseContratoMB";

	/** Atributo EL_MANAGED_BEAN. */
	public static final String EL_MANAGED_BEAN = "#{dWAnaliseContratoMB}";

	/** Atributo COLUMN_INSUFICIENTE. */
	private static final String COLUMN_INSUFICIENTE = "idColumnInsuficiente";

	/** Atributo COLUMN_PARAMETRIZADO. */
	private static final String COLUMN_PARAMETRIZADO = "idColumnParametrizado";

	/** Atributo COLUMN_NOVOS. */
	private static final String COLUMN_NOVOS = "idColumnNovo";
	/** Atributo COLUMN_NOVOS. */
	private static final String COLUMN_HABITACIONAL = "idColumnHabitacional";

	/** Atributo CAIXA. */
	private static final String CAIXA = "CAIXA";

	/** Atributo SUAT. */
	private static final String SUAT = "SUAT";

	/** Atributo SR. */
	private static final String SR = "SR";

	/** Atributo AGENCIA. */
	private static final String AGENCIA = "UNIDADE";

	/** Atributo CONTRATO. */
	private static final String CONTRATO = "CONTRATO";

	/** Atributo GRID. */
	private static final String GRID = "GRID";

	/** Atributo COMBO. */
	private static final String COMBO = "COMBO";

	/** Atributo INICIO. */
	private static final String INICIO = "INICIO";
	
	private static final String UNIDADE = "unidade";

	private static final Integer HIERARQUIA=1;
	
	/** Atributo service. */
	@Inject
	private transient DWAnaliseContratoService service;

	@Inject
	private EmpreendimentoLazyMode empreendimentoLazy;

	@Inject
	private transient EmpreendimentoService empreendimentoService;

	/** Atributo unidadeService. */
	@Inject
	private transient UnidadeService unidadeService;
	
	/** Atributo unidadeVinculadaSuatService. */
	@Inject
	private transient UnidadeVinculadaSuatService unidadeVinculadaSuatService;

	/** Atributo suatService. */
	@Inject
	private transient SuatService suatService;
	
    @EJB
    private transient PropriedadeService propriedadeService;

	/** Atributo visao. */
	private transient DWAnaliseContratoVisao visao;

	private transient EmpreendimentoVisao empreendimentoVisao;

	/** Atributo listaColunas. */
	private transient List<UIComponent> listaColunas = new ArrayList<>(0);
	/** Atributo listaColunas. */
	private transient List<UIComponent> listaColunasHabitacional = new ArrayList<>(0);

	/** Atributo panelGrid. */
	private transient HtmlPanelGrid panelGrid;

	private transient HtmlPanelGrid panelGridHabitacional;
	
	/**
	 * <p>
	 * Método responsável pela inicialização de componentes de forma automática no
	 * início da aplicação.
	 * </p>
	 *
	 * @author Charles Júnior
	 */
	@PostConstruct
	public void inicializar() {
	    	this.atualizarUsuarioOnlinePainelSiacg(); 
	    	
		this.obterMensagens();
		this.getVisao().setDiasParaDataReferencia(this.service.diasParaDataReferencia());
		this.getVisao().setDataReferencia(this.service.dataReferencia());
		this.getVisao().processarLogImportacao(this.service.listarLogImportacao());
		this.configurarPermissao();
		this.iniciarListaComboSegmento();
		this.carregarListaUnidades();
	}

	private void atualizarUsuarioOnlinePainelSiacg() {
	    UsuarioOnlineSingleton.adicionarUsuario();
	}
	
	/**
	 * <p>
	 * Método responsável por verificar se a lista de segmento está vazia. Se a
	 * lista estiver vazia, o componente não será renderizado na tela.
	 * <p>
	 *
	 * @return Boolean
	 * @author robson.oliveira
	 */
	public Boolean listaSegmentoContemValor() {
		return !this.getVisao().getSegmentoList().isEmpty();
	}
	
	private void carregarListaUnidades() {
		List<UnidadeVO> listaDires = new ArrayList<>();
		
		Integer tipoConfig = HIERARQUIA;
		Integer unidadeGestora = null; 
		try {
			List<Integer> codigos = new ArrayList<>();
			String dados = this.propriedadeService.getPropriedadeBanco("unidade.lista", UNIDADE);
			tipoConfig = Integer.parseInt(this.propriedadeService.getPropriedadeBanco("unidade.tipoconfig", UNIDADE));
			unidadeGestora = Integer.parseInt(this.propriedadeService.getPropriedadeBanco("unidade.unidadeGestora", UNIDADE));
			
			String[] lista = dados.split(";");
			for (String item : lista) {
				codigos.add(Integer.parseInt(item));
			}
			listaDires = new ArrayList<>(this.unidadeVinculadaSuatService.listarDiresPorCodigo(codigos));
		} catch (ParametrosInvalidosException e) {
			LogCEF.error("Erro ao carregar propriedades de unidades. Detalhes: ");
			LogCEF.error(e);
		}
			
		this.getVisao().setListaDires(listaDires);
		this.getVisao().setTipoConfig(tipoConfig);
		this.getVisao().setUnidadeGestoraProcesso(unidadeGestora);
	}

	/**
	 * <p>
	 * Método responsável por fazer a chamada de atualização dos gráficos no início
	 * da aplicação.
	 * </p>
	 *
	 * @author Charles Júnior
	 */
	public void atualizarGraficoInicio() {
	    this.getVisao().setApresentarGridEmpreendimento(Boolean.TRUE);
		this.atualizarGraficos(this.visao.getVrTotalInsuficiente(), this.visao.getVrTotalPactuado(), this.visao.getQuantidadeNaoParametrizado(),
				this.visao.getQuantidadeNovo(), this.visao.getQuantidadeTotal());
	}

	/**
	 * <p>
	 * Método responsável por configurar a permissão de exibição de componentes na
	 * tela.
	 * <p>
	 *
	 * @author Charles Júnior
	 */
	public void configurarPermissao() {
		final FacesContext contexto = FacesContext.getCurrentInstance();

		if (UtilObjeto.isReferencia(contexto) && this.possuiPeloMenosUmaPermissaoDePainel()) {

			final String unidadeUsuario = super.getUnidadeUsuario();

			if (!UtilString.isVazio(unidadeUsuario)) {

				final Integer nuUnidadeusuarioLogado = Integer.valueOf(unidadeUsuario);

				if (UtilObjeto.isReferencia(nuUnidadeusuarioLogado)) {

					if (UsuarioUtil.contemPermissao(NoFuncionalidadeEnum.CONSULTA_UNIDADE.getNoFuncionalidade(), EnumAcao.CONSULTAR.getNoAcao(),
							EnumTipoAbrangencia.RESTRITA_UNIDADE.getTipoAbrangencia(),
							EnumNomeAbrangenciaRestritaUnidade.TODAS.getNomeAbrangencia())) {

						// Lista todas as SUATS
						this.visao.setSuatList(this.unidadeVinculadaSuatService.listarSuats());

						this.visao.setExibirGestorCaixa(true);

						// Seta nivel de consulta, se for caixa traz nos
						// paineis
						// so as suats
						this.visao.setNivelConsulta(CAIXA);

						// Chama a consulta que carrega os paineis e informa
						// o
						// tipo que disparou a consulta (inicio, combo,
						// painel)
						this.chamarConsultas(new DWAnaliseContrato(), DWAnaliseContratoMB.INICIO);

						// Bota para voltar ao nivel inicial
						this.visao.setExibirBotaoVoltarConsulta(true);

					} else if (UsuarioUtil.contemPermissao(NoFuncionalidadeEnum.CONSULTA_UNIDADE.getNoFuncionalidade(),
							EnumAcao.CONSULTAR.getNoAcao(), EnumTipoAbrangencia.RESTRITA_UNIDADE.getTipoAbrangencia(),
							EnumNomeAbrangenciaRestritaUnidade.VINCULADAS.getNomeAbrangencia())) {

						this.construirBreadCrumbGestorRegional(nuUnidadeusuarioLogado);
						this.visao.setExibirGestorRegional(true);
						this.visao.setExibirColunaSR(true);
						this.visao.setExibirColunaSUAT(true);

						this.visao.setNivelConsulta("SR");
						final DWAnaliseContrato analiseContrato = new DWAnaliseContrato();
						analiseContrato.setCoIdentificador(unidadeUsuario);
						this.chamarConsultas(analiseContrato, DWAnaliseContratoMB.INICIO);

					} else if (UsuarioUtil.contemPermissao(NoFuncionalidadeEnum.CONSULTA_UNIDADE.getNoFuncionalidade(),
							EnumAcao.CONSULTAR.getNoAcao(), EnumTipoAbrangencia.RESTRITA_UNIDADE.getTipoAbrangencia(),
							EnumNomeAbrangenciaRestritaUnidade.UNIDADE.getNomeAbrangencia())) {

						this.construirBreadCrumbGestorUnidade(nuUnidadeusuarioLogado);
						this.visao.setExibirGestorUnidade(true);
						this.visao.setExibirColunaUnidade(true);
						this.visao.setExibirColunaSR(true);
						this.visao.setExibirColunaSUAT(true);

						this.visao.setNivelConsulta("UNIDADE");
						final DWAnaliseContrato analiseContrato = new DWAnaliseContrato();
						analiseContrato.setCoIdentificador(unidadeUsuario);
						this.chamarConsultas(analiseContrato, DWAnaliseContratoMB.INICIO);

					}
				}
			}
		}

	}

	/**
	 * <p>
	 * Método responsável por verificar se o usuário contém permissão de
	 * visualização de pelo menos um painel.
	 * <p>
	 *
	 * @return boolean
	 * @author Bruno Martins de Carvalho
	 */
	private boolean possuiPeloMenosUmaPermissaoDePainel() {
		return UsuarioUtil.contemFuncionalidade(NoFuncionalidadeEnum.PAINEL_GARANTIA_INSUFICIENTE.getNoFuncionalidade())
				|| UsuarioUtil.contemFuncionalidade(NoFuncionalidadeEnum.PAINEL_CONTRATO_NAO_PARAMETRIZADO.getNoFuncionalidade())
				|| UsuarioUtil.contemFuncionalidade(NoFuncionalidadeEnum.PAINEL_NOVO_CONTRATO.getNoFuncionalidade());
	}

	

	/**
	 * <p>
	 * Método responsável por definir os tipos de segmentos que cada usuário terá
	 * acesso.
	 * <p>
	 *
	 * @return Collection<Segmento>
	 * @author robson.oliveira
	 */
	private Collection<Segmento> criarListaSegmentoConformePermissao() {
		final Collection<Segmento> listaSegmento = this.service.listarSegmentos();

		for (final Iterator<Segmento> iterator = listaSegmento.iterator(); iterator.hasNext();) {
			if (!UsuarioUtil.contemPermissao(iterator.next().getDeFuncionalidade(), EnumAcao.CONSULTAR.getNoAcao(), null, null)) {

				iterator.remove();
			}
		}
		return listaSegmento;
	}

	/**
	 * <p>
	 * Método responsável por inicializar a lista de segmentos e por preencher a
	 * combo de acordo com os segmentos do banco.
	 * <p>
	 *
	 * @author Caio Graco
	 */
	private void iniciarListaComboSegmento() {
		this.getVisao().setSegmentoList(new ArrayList<Segmento>());
		this.getVisao().setSegmentoList(this.criarListaSegmentoConformePermissao());
	}

	/**
	 * <p>
	 * Método responsável por criar e retornar o objeto this.visao. É verificado se
	 * tem uma referência ao objeto. Se não houver, cria e retorna. Se houver,
	 * apenas retorna.
	 * </p>
	 *
	 * @author Charles Júnior
	 */
	@Override
	public DWAnaliseContratoVisao getVisao() {
		if (!UtilObjeto.isReferencia(this.visao)) {
			this.visao = new DWAnaliseContratoVisao();
		}
		return this.visao;
	}

	/**
	 * <p>
	 * Método responsável por criar e retornar o objeto this.empreendimentoVisao. É
	 * verificado se tem uma referência ao objeto. Se não houver, cria e retorna. Se
	 * houver, apenas retorna.
	 * </p>
	 *
	 * @author TO Brasil
	 */
	public EmpreendimentoVisao getEmpreendimentoVisao() {
		if (!UtilObjeto.isReferencia(this.empreendimentoVisao)) {
			this.empreendimentoVisao = new EmpreendimentoVisao();
		}
		return empreendimentoVisao;
	}

	/**
	 * <p>
	 * Método responsável por fazer a chamada às consultas ao EmpreendimentoVisao
	 * quando é feito o click na linha do grid. É informado "grid" para saber a
	 * origem da ação. Pois a origem da consulta também pode ser o "combo".
	 * </p>
	 *
	 * @param empreendimentoVisao
	 *            valor a ser atribuído
	 * @author TO Brasil
	 */
	public void setEmpreendimentoVisao(EmpreendimentoVisao empreendimentoVisao) {
		this.empreendimentoVisao = empreendimentoVisao;
	}

	/**
	 * <p>
	 * Método responsável por fazer a chamada às consultas ao DW quando é feito o
	 * click na linha do grid. É informado "grid" para saber a origem da ação. Pois
	 * a origem da consulta também pode ser o "combo".
	 * </p>
	 *
	 * @param analiseContrato
	 *            valor a ser atribuído
	 * @author Charles Júnior
	 */
	public void chamarConsultaPeloGrid(final DWAnaliseContrato analiseContrato) {
		this.chamarConsultas(analiseContrato, DWAnaliseContratoMB.GRID);
	}

	/**
	 * <p>
	 * Método responsável por fazer a consulta das mensagens. Exibe ou oculta o
	 * painel de mensagens.
	 * </p>
	 *
	 * @author Charles Júnior
	 */
	public void obterMensagens() {
		this.getVisao().setListaMensagens(this.getService().listarMensagensPorDataAtual());

		if (!this.getVisao().getListaMensagens().isEmpty()) {
			this.getVisao().setExibirPainelMensagem(true);
		} else {
			this.getVisao().setExibirPainelMensagem(false);
		}
	}

	/**
	 * <p>
	 * Método responsável por fazer as consultas ao DW. É identificado qual o nível
	 * da consulta: SUAT - SR - UNIDADE - CONTRATO
	 * </p>
	 *
	 * @param analiseContrato
	 *            valor a ser atribuído
	 * @param origem
	 *            valor a ser atribuído
	 * @author Charles Júnior
	 */
	public void chamarConsultas(final DWAnaliseContrato analiseContrato, final String origem) {
		final Collection<String> listaSegmentoFiltro = this.getVisao().getSegmentoListString();

		if (analiseContrato != null && analiseContrato.getCoIdentificador() != null) {
			this.visao.setCoIdentificador(analiseContrato.getCoIdentificador());
		}

		if (this.isNivelConsultaIgual(DWAnaliseContratoMB.CAIXA)) {
			this.consultarNivelCaixa(listaSegmentoFiltro);

		} else if (this.isNivelConsultaIgual(DWAnaliseContratoMB.SUAT)) {
			if (origem.equals(DWAnaliseContratoMB.GRID)) {
				this.visao.setNuSuat(Integer.parseInt(this.visao.getCoIdentificador()));
				this.preencherComboPelaGrid(DWAnaliseContratoMB.SUAT, Integer.parseInt(this.visao.getCoIdentificador()));
			}
			this.getSession().setAttribute("nuSuat", this.visao.getNuSuat());
			this.consultarNivelSuat(this.visao.getCoIdentificador());

		} else if (this.isNivelConsultaIgual(DWAnaliseContratoMB.SR)) {
			if (origem.equals(DWAnaliseContratoMB.GRID)) {
				this.visao.setNuSr(Integer.parseInt(this.visao.getCoIdentificador()));
				this.preencherComboPelaGrid(DWAnaliseContratoMB.SR, Integer.parseInt(this.visao.getCoIdentificador()));
			}
			this.getSession().setAttribute("nuSr", this.visao.getNuSr());
			this.consultarNivelSr();

		} else if (this.isNivelConsultaIgual(DWAnaliseContratoMB.AGENCIA)) {
			if (origem.equals(DWAnaliseContratoMB.GRID)) { 
				this.visao.setNuUnidade(Integer.parseInt(this.visao.getCoIdentificador()));
			}
			this.getSession().setAttribute("nuUnidade", this.visao.getNuUnidade());
			this.consultarNivelAgencia();

		}

		if (!origem.equals(DWAnaliseContratoMB.INICIO)) {
			this.atualizarGraficos(this.visao.getVrTotalInsuficiente(), this.visao.getVrTotalPactuado(), this.visao.getQuantidadeNaoParametrizado(),
					this.visao.getQuantidadeNovo(), this.visao.getQuantidadeTotal());
		}

	}

	/**
	 * <p>
	 * Método responsável por verificar o nivel da consulta.
	 * <p>
	 *
	 * @param valor
	 *            valor a ser atribuído
	 * @return boolean
	 * @author Charles Júnior
	 */
	public boolean isNivelConsultaIgual(final String valor) {
		return this.visao.getNivelConsulta().equals(valor);
	}

	/**
	 * <p>
	 * Método responsável por guardar os valores dos gráficos no nível contrato. É
	 * necessário para reconstruir o gráfico quando está no último nível.
	 * <p>
	 *
	 * @param quantidadeInsuficiente
	 *            valor a ser atribuído
	 * @param quantidadeNaoParametrizado
	 *            valor a ser atribuído
	 * @param quantidadeNovo
	 *            valor a ser atribuído
	 * @param quantidadeTotal
	 *            valor a ser atribuído
	 * @author Charles Júnior
	 */
	public void manterValoresGraficos(final Integer quantidadeInsuficiente, final Integer quantidadeNaoParametrizado, final Integer quantidadeNovo,
			final Integer quantidadeTotal) {
		this.visao.setQuantidadeInsuficiente(quantidadeInsuficiente);
		this.visao.setQuantidadeNaoParametrizado(quantidadeNaoParametrizado);
		this.visao.setQuantidadeNovo(quantidadeNovo);
		this.visao.setQuantidadeTotal(quantidadeTotal);
	}

	/**
	 * <p>
	 * Método responsável por gerar as informações do contrato de garantia
	 * insuficiente por nível caixa agrupado por Suat.
	 * <p>
	 *
	 * @param listaSegmentoFiltro
	 *            valor a ser atribuído
	 * @return List<DWAnaliseContrato>
	 * @author robson.oliveira
	 */
	private List<DWAnaliseContrato> gerarGarantiasInsuficientesNivelCaixaPorSuat(final Collection<String> listaSegmentoFiltro) {
		return this.service.gerarGarantiasInsuficientes(this.service.listarGarantiasInsuficientesNivelCaixaPorSuat(listaSegmentoFiltro));
	}

	/**
	 * <p>
	 * Método responsável por gerar as informações do contrato de garantia
	 * insuficiente por nível suat agrupado por sr.
	 * <p>
	 *
	 * @return List<DWAnaliseContrato>
	 * @author robson.oliveira
	 */
	private List<DWAnaliseContrato> gerarGarantiasInsuficientesNivelSUATPorSR() {
		return this.service.gerarGarantiasInsuficientes(
				this.service.listarGarantiasInsuficientesNivelSUATPorSR(this.visao.getCoIdentificador(), this.visao.getSegmentoListString()));
	}

	/**
	 * <p>
	 * Método responsável por gerar as informações do contrato de garantia
	 * insuficiente por nível agência agrupado por contrato.
	 * <p>
	 *
	 * @return List<DWAnaliseContrato>
	 * @author robson.oliveira
	 */
	private List<DWAnaliseContrato> gerarGarantiasInsuficientesNivelAgenciaPorContrato() {
		String nuSr = "";
		if (this.getVisao().getNuSr() != null) {
			nuSr = this.getVisao().getNuSr().toString();
		}

		return this.service.gerarGarantiasInsuficientes(this.service.listarGarantiasInsuficientesNivelAgenciaPorContrato(
				this.getVisao().getCoIdentificador(), nuSr, this.getVisao().getSegmentoListString()));
	}

	/**
	 * <p>
	 * Método responsável por gerar as informações do contrato de garantia
	 * insuficiente por nível sr agrupado por agencia.
	 * <p>
	 *
	 * @return List<DWAnaliseContrato>
	 * @author robson.oliveira
	 */
	private List<DWAnaliseContrato> gerarGarantiasInsuficientesNivelSRPorAgencia() {
		String nuSuat = "";
		if (this.getVisao().getNuSuat() != null) {
			nuSuat = this.getVisao().getNuSuat().toString();
		}

		return this.service.gerarGarantiasInsuficientes(this.service.listarGarantiasInsuficientesNivelSRPorAgencia(
				this.getVisao().getCoIdentificador(), nuSuat, this.getVisao().getSegmentoListString()));
	}

	/**
	 * <p>
	 * Método responsável por obter o valor total de garantias pactuadas.
	 * <p>
	 *
	 * @param lista
	 *            valor a ser atribuído
	 * @return BigDecimal
	 * @author robson.oliveira
	 */
	private BigDecimal obtemValortotalGarantiaPactuada(final List<DWAnaliseContrato> lista) {
		return this.service.obtemValortotalGarantiaPactuada(lista);
	}

	/**
	 * <p>
	 * Método responsável por obter o valor total dos contratos insuficientes.
	 * <p>
	 *
	 * @param lista
	 *            valor a ser atribuído
	 * @return BigDecimal
	 * @author robson.oliveira
	 */
	private BigDecimal obtemValortotalContratosInsuficientes(final List<DWAnaliseContrato> lista) {
		return this.service.obtemValortotalContratosInsuficientes(lista);
	}

	/**
	 * <p>
	 * Método responsável por consultar as SUAT´s que serão apresentadas na combo.
	 * </p>
	 *
	 * @param listaSegmentoFiltro
	 *            valor a ser atribuído
	 * @author Charles Júnior
	 */
	public void consultarNivelCaixa(final Collection<String> listaSegmentoFiltro) {

		final Integer totalGeral = this.service.totalGeralNivelCaixa(listaSegmentoFiltro);
		final Integer totalQuantidadeNaoParametrizado = this.service.totalContratosNaoParametrizadosNivelCaixaPorSuat(listaSegmentoFiltro);
		final Integer totalQuantidadeNovo = this.service.totalNovosContratosNivelCaixaPorSuat(this.getDataReferenciaConsulta(), listaSegmentoFiltro);

		final List<DWAnaliseContrato> insuficientes = this.gerarGarantiasInsuficientesNivelCaixaPorSuat(listaSegmentoFiltro);

		final List<DWAnaliseContrato> naoParametrizados = this.service
				.listarContratosNaoParametrizadosNivelCaixaPorSUAT(totalQuantidadeNaoParametrizado, listaSegmentoFiltro);

		final List<DWAnaliseContrato> contratosNovos = this.service.listarNovosContratosNivelCaixaPorSUAT(totalQuantidadeNovo,
				this.getDataReferenciaConsulta(), listaSegmentoFiltro);

		this.visao.setNivelConsulta(DWAnaliseContratoMB.SUAT);
		this.visao.setTituloGrid(DWAnaliseContratoMB.SUAT);

		this.atualizarGrid(insuficientes, naoParametrizados, contratosNovos);

		this.visao.setVrTotalPactuado(this.obtemValortotalGarantiaPactuada(insuficientes));
		this.visao.setVrTotalInsuficiente(this.obtemValortotalContratosInsuficientes(insuficientes));
		this.visao.setQuantidadeNaoParametrizado(totalQuantidadeNaoParametrizado);
		this.visao.setQuantidadeNovo(totalQuantidadeNovo);
		this.visao.setQuantidadeTotal(totalGeral);
		this.contQtdHabitacinal();
	}

	public void contQtdHabitacinal() {
		this.getEmpreendimentoVisao().setQuantidadeHabitacional(this.empreendimentoService.valorAReceber(null));
		this.getEmpreendimentoVisao().setQuantidadeHabitacionalParcial(this.empreendimentoService.valorRecebidoPendencia(null));
	}

	/**
	 * <p>
	 * Método responsável for fazer as consultas referentes ao nível suat agrupado
	 * por sr.
	 * </p>
	 *
	 * @author Charles Júnior
	 */
	private void consultarNivelSuat(String coIdentificador) {

		final Integer totalGeral = this.service.totalGeralNivelSUAT(coIdentificador, this.visao.getSegmentoListString());
		final Integer totalQuantidadeNaoParametrizado = this.service.totalContratosNaoParametrizadosNivelSuatPorSr(coIdentificador,
				this.visao.getSegmentoListString());
		final Integer totalQuantidadeNovo = this.service.totalNovosContratosNivelSuatPorSr(coIdentificador,
				this.getDataReferenciaConsulta(), this.visao.getSegmentoListString());

		final List<DWAnaliseContrato> insuficientes = this.gerarGarantiasInsuficientesNivelSUATPorSR();

		final List<DWAnaliseContrato> naoParametrizados = this.service.listarContratosNaoParametrizadosNivelSUATPorSR(coIdentificador,
				totalQuantidadeNaoParametrizado, this.visao.getSegmentoListString());

		final List<DWAnaliseContrato> contratosNovos = this.service.listarNovosContratosNivelSUATPorSR(coIdentificador,
				totalQuantidadeNovo, this.getDataReferenciaConsulta(), this.visao.getSegmentoListString());

		this.visao.setNivelConsulta(DWAnaliseContratoMB.SR);
		this.visao.setTituloGrid(DWAnaliseContratoMB.SR);

		this.atualizarGrid(insuficientes, naoParametrizados, contratosNovos);

		this.visao.setVrTotalPactuado(this.obtemValortotalGarantiaPactuada(insuficientes));
		this.visao.setVrTotalInsuficiente(this.obtemValortotalContratosInsuficientes(insuficientes));
		this.visao.setQuantidadeNaoParametrizado(totalQuantidadeNaoParametrizado);
		this.visao.setQuantidadeNovo(totalQuantidadeNovo);
		this.visao.setQuantidadeTotal(totalGeral);

	}

	/**
	 * <p>
	 * Método responsável for fazer as consultas referentes ao nível sr agrupado por
	 * agencia (unidade).
	 * </p>
	 *
	 * @author Charles Júnior
	 */
	public void consultarNivelSr() {
		String coIdentificador = this.visao.getCoIdentificador();
		List<String> segmentos = this.visao.getSegmentoListString();
		Date dataRefConsulta = this.getDataReferenciaConsulta();
		
		final Integer totalGeral = this.service.totalGeralNivelSR(coIdentificador, segmentos);
		final Integer totalQtdNaoParametrizado = this.service.totalContratosNaoParametrizadosNivelSrPorUnidade(coIdentificador, segmentos);
		final Integer totalQtdNovo = this.service.totalNovosContratosNivelSrPorUnidade(coIdentificador, dataRefConsulta, segmentos);

		final List<DWAnaliseContrato> insuficientes = this.gerarGarantiasInsuficientesNivelSRPorAgencia();
		final List<DWAnaliseContrato> naoParametrizados = this.service.listarContratosNaoParametrizadosNivelSRPorAgencia(coIdentificador, totalQtdNaoParametrizado, segmentos);
		final List<DWAnaliseContrato> contratosNovos = this.service.listarNovosContratosNivelSRPorAgencia(coIdentificador, totalQtdNovo, dataRefConsulta, segmentos);

		this.visao.setNivelConsulta(DWAnaliseContratoMB.AGENCIA);
		this.visao.setTituloGrid(DWAnaliseContratoMB.AGENCIA);

		this.atualizarGrid(insuficientes, naoParametrizados, contratosNovos);

		this.visao.setVrTotalPactuado(this.obtemValortotalGarantiaPactuada(insuficientes));
		this.visao.setVrTotalInsuficiente(this.obtemValortotalContratosInsuficientes(insuficientes));
		this.visao.setQuantidadeNaoParametrizado(totalQtdNaoParametrizado);
		this.visao.setQuantidadeNovo(totalQtdNovo);
		this.visao.setQuantidadeTotal(totalGeral);
	}

	/**
	 * <p>
	 * Método responsável for fazer as consultas dos contratos, referentes ao nível
	 * agencia (unidade).
	 * </p>
	 *
	 * @author Charles Júnior
	 */
	public void consultarNivelAgencia() {
		final Integer totalGeral = this.service.totalGeralNivelAgencia(this.visao.getCoIdentificador(), this.visao.getSegmentoListString());

		final Integer totalQuantidadeNaoParametrizado = this.service
				.totalContratosNaoParametrizadosNivelAgenciaPorContrato(this.visao.getCoIdentificador(), this.visao.getSegmentoListString());
		final Integer totalQuantidadeNovo = this.service.totalNovosContratosNivelAgenciaPorContrato(this.visao.getCoIdentificador(),
				this.getDataReferenciaConsulta(), this.visao.getSegmentoListString());

		final List<DWAnaliseContrato> insuficientes = this.gerarGarantiasInsuficientesNivelAgenciaPorContrato();

		final List<DWAnaliseContrato> naoParametrizados = this.service.listarContratosNaoParametrizadosNivelAgenciaPorContrato(
				this.visao.getCoIdentificador(), totalQuantidadeNaoParametrizado, this.visao.getSegmentoListString());

		final List<DWAnaliseContrato> contratosNovos = this.service.listarNovosContratosNivelAgenciaPorContrato(this.visao.getCoIdentificador(),
				totalQuantidadeNovo, this.getDataReferenciaConsulta(), this.visao.getSegmentoListString());

		this.visao.setNivelConsulta(DWAnaliseContratoMB.CONTRATO);
		this.visao.setTituloGrid(DWAnaliseContratoMB.CONTRATO);

		this.atualizarGrid(insuficientes, naoParametrizados, contratosNovos);

		this.visao.setVrTotalPactuado(this.obtemValortotalGarantiaPactuada(insuficientes));
		this.visao.setVrTotalInsuficiente(this.obtemValortotalContratosInsuficientes(insuficientes));
		this.visao.setQuantidadeNaoParametrizado(totalQuantidadeNaoParametrizado);
		this.visao.setQuantidadeNovo(totalQuantidadeNovo);
		this.visao.setQuantidadeTotal(totalGeral);
	}

	/**
	 * <p>
	 * Método responsável por atualizar os objetos que refletem a grid dos gráficos.
	 * Deixa todas as tabelas do mesmo tamanho.
	 * </p>
	 *
	 * @param insuficientes
	 *            valor a ser atribuído
	 * @param naoParametrizados
	 *            valor a ser atribuído
	 * @param contratosNovos
	 *            valor a ser atribuído
	 * @author Charles Júnior
	 * @param habitacional
	 */
	public void atualizarGrid(final List<DWAnaliseContrato> insuficientes, final List<DWAnaliseContrato> naoParametrizados,
			final List<DWAnaliseContrato> contratosNovos) {

		Integer maiorGrid = 0;
		final DWAnaliseContrato analiseContrato = new DWAnaliseContrato();
		analiseContrato.setNoIdentificador("	");

		if (insuficientes.size() > maiorGrid) {
			maiorGrid = insuficientes.size();
		}

		if (naoParametrizados.size() > maiorGrid) {
			maiorGrid = naoParametrizados.size();
		}

		if (contratosNovos.size() > maiorGrid) {
			maiorGrid = contratosNovos.size();
		}

		if (contratosNovos.size() > maiorGrid) {
			maiorGrid = contratosNovos.size();
		}

		if (maiorGrid > 0) {
			if (insuficientes.size() < maiorGrid) {
				for (int i = insuficientes.size(); i < maiorGrid; i++) {
					insuficientes.add(analiseContrato);
				}
			}

			if (naoParametrizados.size() < maiorGrid) {
				for (int i = naoParametrizados.size(); i < maiorGrid; i++) {
					naoParametrizados.add(analiseContrato);
				}
			}

			if (contratosNovos.size() < maiorGrid) {
				for (int i = contratosNovos.size(); i < maiorGrid; i++) {
					contratosNovos.add(analiseContrato);
				}
			}
		}

		this.visao.setGarantiasInsuficientes(insuficientes);
		this.visao.setContratosNaoParametrizados(naoParametrizados);
		this.visao.setContratosNovos(contratosNovos);
	}

	/**
	 * <p>
	 * Método responsável por calcular os valores apresentados nos painéis de
	 * contratos.
	 * <p>
	 *
	 * @param totalValorInsuficiente
	 *            valor a ser atribuído
	 * @param totalValorPactuado
	 *            valor a ser atribuído
	 * @param totalQuantidadeNaoParametrizado
	 *            valor a ser atribuído
	 * @param totalQuantidadeNovo
	 *            valor a ser atribuído
	 * @param totalGeral
	 *            valor a ser atribuído
	 * @author robson.oliveira
	 * @param qtdHabitacional
	 */
	public void atualizarGraficos(final BigDecimal totalValorInsuficiente, final BigDecimal totalValorPactuado,
			final Integer totalQuantidadeNaoParametrizado, final Integer totalQuantidadeNovo, final Integer totalGeral) {

		if (UsuarioUtil.contemPermissao("comercial", "consultar", null, null)) {
			for (final UIComponent coluna : this.obterColunasDoPainelGrafico()) {
				if (coluna.getId().equalsIgnoreCase(DWAnaliseContratoMB.COLUMN_INSUFICIENTE) && coluna.isRendered()) {
					this.service.executaFuncaoJavaScript("graficoInsuficiente(" + totalValorInsuficiente + "," + totalValorPactuado + ");");
					continue;
				}

				if (coluna.getId().equalsIgnoreCase(DWAnaliseContratoMB.COLUMN_PARAMETRIZADO) && coluna.isRendered()) {
					this.service.executaFuncaoJavaScript("graficoNaoParametrizado(" + totalQuantidadeNaoParametrizado + "," + totalGeral + ");");
					continue;
				}

				if (coluna.getId().equalsIgnoreCase(DWAnaliseContratoMB.COLUMN_NOVOS) && coluna.isRendered()) {
					this.service.executaFuncaoJavaScript("graficoContratoNovo(" + totalQuantidadeNovo + "," + totalGeral + ");");
					continue;
				}
			}
		}

		if (UsuarioUtil.contemPermissao("habitacional", "consultar", null, null)) {
			for (final UIComponent coluna : this.obterColunasDoPaingelGraficoHabitacional()) {
				if (coluna.getId().equalsIgnoreCase(DWAnaliseContratoMB.COLUMN_HABITACIONAL) && coluna.isRendered()) {
					this.service.executaFuncaoJavaScript("graficoHabitacional(" + getEmpreendimentoVisao().getQuantidadeHabitacionalParcial() + ","
							+ getEmpreendimentoVisao().getQuantidadeHabitacional() + ");");
				}
			}
		}

	}

	/**
	 * <p>
	 * Método responsável por listar as colunas do componente PanelGrid.
	 * <p>
	 *
	 * @return List<UIComponent>
	 * @author robson.oliveira
	 */
	private List<UIComponent> obterColunasDoPainelGrafico() {
		if (this.listaColunas.isEmpty()) {
			this.listaColunas = this.getPanelGrid().getChildren();
		}
		return this.listaColunas;
	}

	private List<UIComponent> obterColunasDoPaingelGraficoHabitacional() {

		if (this.listaColunasHabitacional.isEmpty()) {
			this.listaColunasHabitacional = this.getPanelGridHabitacional().getChildren();
		}
		return this.listaColunasHabitacional;
	}

	/**
	 * <p>
	 * Método responsável por construir o breadcrumb do gestor regional.
	 * </p>
	 *
	 * @param numeroUnidadeUsuarioLogado
	 *            valor a ser atribuído
	 * @author Charles Júnior
	 */
	private void construirBreadCrumbGestorRegional(final Integer numeroUnidadeUsuarioLogado) {
		final Integer numeroSuatUnidadeUsuarioLogado = this.unidadeVinculadaSuatService.getNuSuatPorSR(numeroUnidadeUsuarioLogado);
		visao.setNomeSuat(this.suatService.getNomeSuat(numeroSuatUnidadeUsuarioLogado));
		visao.setNomeSr(this.unidadeService.getNomeSRPorNuUnidade(numeroUnidadeUsuarioLogado));

		if (UtilObjeto.isReferencia(numeroUnidadeUsuarioLogado)) {
			final Collection<UnidadeVO> unidadeSrList = this.unidadeVinculadaSuatService.listarUnidadesPorNuSr(numeroUnidadeUsuarioLogado);
			visao.setUnidadeList(unidadeSrList);
		}
	}

	/**
	 * <p>
	 * Método responsável por contruir o breadcrumb do gestor de uma unidade.
	 * </p>
	 *
	 * @param numeroUnidadeUsuarioLogado
	 *            valor a ser atribuído
	 * @author Charles Júnior
	 */
	private void construirBreadCrumbGestorUnidade(final Integer numeroUnidadeUsuarioLogado) {
		final DWAnaliseContratoVisao visao = this.getVisao();
		final Integer numeroSuatUnidadeUsuarioLogado = this.unidadeVinculadaSuatService.getNuSuatPorUnidade(numeroUnidadeUsuarioLogado);

		visao.setNomeUnidade(this.unidadeService.getNomeUnidade(numeroUnidadeUsuarioLogado));
		visao.setNomeSuat(this.suatService.getNomeSuat(numeroSuatUnidadeUsuarioLogado));
		visao.setNomeSr(this.unidadeService.getNomeSRPorNuUnidade(numeroUnidadeUsuarioLogado));
	}

	/**
	 * <p>
	 * Ação executada quando a combobox de SUAT for selecionada.
	 * </p>
	 *
	 * valor a ser atribuído
	 * 
	 * @author Charles Júnior
	 */
	public void selecionarSuat() {
		Collection<SrVO> lista = new ArrayList<>();
		this.visao.setNuSuat(this.visao.getCodSuatSelecionada());
		if (UtilObjeto.isReferencia(visao) && visao.getNuSuat() != null && !visao.getNuSuat().equals(0)) {
			// Consulta as SR baseado na DIRE selecionada.
			lista = this.getService().listarSrsPorNuSuat(visao.getNuSuat());
			this.visao.setSrList(lista);
			this.visao.setUnidadeList(null);
			this.visao.setListaUnidade(null);
			this.visao.setUnidadeSelecionada(null);
			this.visao.setNivelConsulta(DWAnaliseContratoMB.SUAT);
			this.visao.setTituloGrid(DWAnaliseContratoMB.SUAT);
			
			final DWAnaliseContrato coIdentificador = new DWAnaliseContrato();
			coIdentificador.setCoIdentificador(visao.getNuSuat().toString());			
			this.chamarConsultas(coIdentificador, DWAnaliseContratoMB.COMBO);
		} else {
			this.visao.setSrList(new LinkedList<SrVO>());
			this.visao.setUnidadeList(new LinkedList<UnidadeVO>());
			this.visao.setListaUnidade(null);
			this.visao.setNivelConsulta(DWAnaliseContratoMB.CAIXA);
			this.visao.setTituloGrid(DWAnaliseContratoMB.CAIXA);
			
			final DWAnaliseContrato coIdentificador = null;
			this.chamarConsultas(coIdentificador, DWAnaliseContratoMB.COMBO);
		}
	}

	/**
	 * <p>
	 * Método responsável por verificar o tipo do nível de consulta.
	 * <p>
	 *
	 * @author robson.oliveira
	 */
	private void configurarNivelConsulta() {
		if (this.visao.getNivelConsulta().equals(DWAnaliseContratoMB.SUAT)) {
			this.visao.setNivelConsulta(DWAnaliseContratoMB.CAIXA);

		} else if (this.visao.getNivelConsulta().equals(DWAnaliseContratoMB.SR)) {
			this.visao.setNivelConsulta(DWAnaliseContratoMB.SUAT);

		} else if (this.visao.getNivelConsulta().equals(DWAnaliseContratoMB.AGENCIA)) {
			this.visao.setNivelConsulta(DWAnaliseContratoMB.SR);

		} else if (this.visao.getNivelConsulta().equals(DWAnaliseContratoMB.CONTRATO)) {
			this.visao.setNivelConsulta(DWAnaliseContratoMB.AGENCIA);
		}
	}

	/**
	 * <p>
	 * Ação executada quando a combobox de Segmento for selecionada.
	 * </p>
	 *
	 * @param eventoAjax
	 *            valor a ser atribuído
	 * @author Caio Graco
	 */
	public void selecionarSegmento(final AjaxBehaviorEvent eventoAjax) {
		this.configurarNivelConsulta();
		this.chamarConsultas(null, this.getVisao().getNivelConsulta());
	}

	/**
	 * <p>
	 * Ação executada quando a combobox de SR for selecionada.
	 * </p>
	 *
	 * @param eventoAjax
	 *            valor a ser atribuído
	 * @author Charles Júnior
	 */
	public void selecionarSr() {
		visao.setNuSr(this.visao.getCodSuvSelecionado());
		
		if (UtilObjeto.isReferencia(visao) && visao.getNuSr() != null && !visao.getNuSr().equals(0)) {
			Collection<UnidadeVO> lista = this.getService().listarUnidadesPorNuSr(visao.getNuSr());
			visao.setListaUnidade(lista);
			
			this.visao.setNivelConsulta(DWAnaliseContratoMB.SR);
			this.visao.setTituloGrid(DWAnaliseContratoMB.SR);

			final DWAnaliseContrato coIdentificador = new DWAnaliseContrato();
			coIdentificador.setCoIdentificador(visao.getNuSr().toString());
			this.chamarConsultas(coIdentificador, DWAnaliseContratoMB.COMBO);
		} else {
			visao.setNuSr(null);
			visao.setNuUnidade(null);
			
			visao.setListaUnidade(null);
			this.visao.setNivelConsulta(DWAnaliseContratoMB.SUAT);
			this.visao.setTituloGrid(DWAnaliseContratoMB.SUAT);

			final DWAnaliseContrato coIdentificador = new DWAnaliseContrato();
			coIdentificador.setCoIdentificador(visao.getNuSuat().toString());
			this.chamarConsultas(coIdentificador, DWAnaliseContratoMB.COMBO);
		}

	}

	/**
	 * <p>
	 * Ação executada quando a combobox de Unidade for selecionada.
	 * <p>
	 *
	 * @param eventoAjax
	 *            valor a ser atribuído
	 * @author Charles Júnior
	 */
	public void selecionarUnidade() {
		visao.setNuUnidade(this.getVisao().getUnidadeSelecionada());

		final DWAnaliseContrato coIdentificador = new DWAnaliseContrato();
		if (UtilObjeto.isReferencia(visao) && visao.getNuUnidade() != null && !visao.getNuUnidade().equals(0)) {
			this.visao.setNivelConsulta(DWAnaliseContratoMB.AGENCIA);
			this.visao.setTituloGrid(DWAnaliseContratoMB.AGENCIA);
			coIdentificador.setCoIdentificador(visao.getNuUnidade().toString());
		} else {
			visao.setNuUnidade(null);
			// Hierarquico
			this.visao.setNivelConsulta(DWAnaliseContratoMB.SR);
			this.visao.setTituloGrid(DWAnaliseContratoMB.SR);
			coIdentificador.setCoIdentificador(visao.getNuSr().toString());
		}

		this.chamarConsultas(coIdentificador, DWAnaliseContratoMB.COMBO);
	}

	/**
	 * <p>
	 * Método responsável por voltar a consulta um nível anterior.
	 * <p>
	 *
	 * @author admin
	 */
	public void voltarNivelConsulta() {

		final DWAnaliseContrato analiseContrato = new DWAnaliseContrato();

		if (this.isNivelConsultaIgual(DWAnaliseContratoMB.SR)) {
			this.visao.setNivelConsulta(DWAnaliseContratoMB.CAIXA);
			this.chamarConsultaPeloGrid(analiseContrato);
			this.visao.setSrList(new LinkedList<SrVO>());
			this.visao.setUnidadeList(new LinkedList<UnidadeVO>());
			this.visao.setNuSuat(null);
			this.visao.setNuSr(null);
			this.visao.setNuUnidade(null);
		}

		if (this.isNivelConsultaIgual(DWAnaliseContratoMB.AGENCIA)) {
			this.visao.setNivelConsulta(DWAnaliseContratoMB.SUAT);
			analiseContrato.setCoIdentificador(this.visao.getNuSuat().toString());
			this.chamarConsultaPeloGrid(analiseContrato);
			// visao.setSrList(new LinkedList<SrVO>());
			this.visao.setNuSr(null);
			this.visao.setNuUnidade(null);
		}

		if (this.isNivelConsultaIgual(DWAnaliseContratoMB.CONTRATO)) {
			this.visao.setNivelConsulta(DWAnaliseContratoMB.SR);
			analiseContrato.setCoIdentificador(this.visao.getNuSr().toString());
			this.chamarConsultaPeloGrid(analiseContrato);
			this.visao.setUnidadeList(new LinkedList<UnidadeVO>());
			this.visao.setNuUnidade(null);
		}
	}

	/**
	 * <p>
	 * Ação executada quando a linha da grid por clicada. Será atutalizado o combo
	 * de acordo com o nível em que se encontram as informações na grid.
	 * <p>
	 *
	 * @param nivelConsulta
	 *            valor a ser atribuído
	 * @param nuIdentificador
	 *            valor a ser atribuído
	 * @author Charles Júnior
	 */
	public void preencherComboPelaGrid(final String nivelConsulta, final Integer nuIdentificador) {
		if (nivelConsulta.equals(DWAnaliseContratoMB.SUAT)) {
			if (UtilObjeto.isReferencia(visao) && visao.getNuSuat() != null && !visao.getNuSuat().equals(0)) {
				visao.setSrList(this.getService().listarSrsPorNuSuat(visao.getNuSuat()));
				final Collection<Integer> listaSrs = new ArrayList<>();
				for (final SrVO srVO : visao.getSrList()) {
					listaSrs.add(srVO.getNuSrVO());
				}
				this.unidadeVinculadaSuatService.getNuUnidadesVinculadasSR(listaSrs);
				visao.setUnidadeList(new LinkedList<UnidadeVO>());
			}
		} else if (nivelConsulta.equals(DWAnaliseContratoMB.SR) && UtilObjeto.isReferencia(visao) && visao.getNuSr() != null
				&& !visao.getNuSr().equals(0)) {
			visao.setUnidadeList(this.getService().listarUnidadesPorNuSr(visao.getNuSr()));
		}
	}

	/**
	 * <p>
	 * Método responsável por retornar o nome da Suat de acordo com o número.
	 * <p>
	 *
	 * @param nuSuat
	 *            valor a ser atribuído
	 * @return int
	 * @author Charles Júnior
	 */
	public String noSuat(final int nuSuat) {
		return this.suatService.getNomeSuat(nuSuat);
	}

	/**
	 * <p>
	 * Método responsável por retornar o nome da SR.
	 * <p>
	 *
	 * @param nuSr
	 *            valor a ser atribuído
	 * @return int
	 * @author Charles Júnior
	 */
	public String noSr(final int nuSr) {
		return this.unidadeVinculadaSuatService.getNoSr(nuSr);
	}

	/**
	 * <p>
	 * Método responsável por retornar o nome da unidade.
	 * <p>
	 *
	 * @param nuUnidade
	 *            valor a ser atribuído
	 * @return int
	 * @author Charles Júnior
	 */
	public String noUnidade(final int nuUnidade) {
		return this.unidadeService.getNomeUnidade(nuUnidade);
	}

	/**
	 * <p>
	 * Define o valor do atributo DWAnaliseContratoVisao.
	 * </p>
	 *
	 * @param visao
	 *            valor a ser atribuído
	 * @author Charles Júnior
	 */
	public void setVisao(final DWAnaliseContratoVisao visao) {
		this.visao = visao;
	}

	/**
	 * @see br.gov.caixa.pedesgo.arquitetura.controlador.AbstractBean#getNomeVarResourceBundle()
	 */
	@Override
	public String getNomeVarResourceBundle() {
		return null;
	}

	/**
	 * @see br.gov.caixa.pedesgo.arquitetura.controlador.AbstractBean#getPrefixoCasoDeUso()
	 */
	@Override
	public String getPrefixoCasoDeUso() {
		return null;
	}

	/**
	 * <p>
	 * Método responsável por limpar breadcrumb.
	 * <p>
	 *
	 * @author Caio Graco
	 */
	public void limparBreadCrumb() {
		final DWAnaliseContratoVisao visao = this.getVisao();
		visao.setNuSuat(0);
		visao.setSrList(new LinkedList<SrVO>());
		visao.setUnidadeList(new LinkedList<UnidadeVO>());
	}

	/**
	 * <p>
	 * Método responsável por retornar a data que será usada na consulta de novos
	 * contratos. Pega a data de refêrencia e subtrai pela quantidade de dias
	 * referentes aos novos contratos.
	 * <p>
	 *
	 * @return Date
	 * @author Charles Júnior
	 */
	public Date getDataReferenciaConsulta() {
		Date dataReferencia = this.visao.getDataReferencia();

		if (dataReferencia != null) {
			final GregorianCalendar gc = new GregorianCalendar();
			gc.setTime(dataReferencia);
			gc.set(Calendar.DATE, gc.get(Calendar.DATE) - this.visao.getDiasParaDataReferencia());
			dataReferencia = gc.getTime();
		}

		return dataReferencia;
	}

	/**
	 * @see br.gov.caixa.pedesgo.arquitetura.controlador.AbstractBean#getService()
	 */
	@SuppressWarnings("unchecked")
	@Override
	public DWAnaliseContratoService getService() {
		return this.service;
	}

	/**
	 * <p>
	 * Método responsável por retornar o valor do atributo listaColunas.
	 * <p>
	 *
	 * @return List<UIComponent>
	 * @author robson.oliveira
	 */
	public List<UIComponent> getListaColunas() {
		return this.listaColunas;
	}

	/**
	 * <p>
	 * Método responsável por setar o atributo listaColunas.
	 * <p>
	 *
	 * @param listaColunas
	 *            valor a ser atribuído
	 * @author robson.oliveira
	 */
	public void setListaColunas(final List<UIComponent> listaColunas) {
		this.listaColunas = listaColunas;
	}

	/**
	 * <p>
	 * Método responsável por retornar o valor do atributo panelGrid.
	 * <p>
	 *
	 * @return HtmlPanelGrid
	 * @author robson.oliveira
	 */
	public HtmlPanelGrid getPanelGrid() {
		if (this.panelGrid == null) {
			this.panelGrid = new HtmlPanelGrid();
		}
		return this.panelGrid;
	}

	/**
	 * <p>
	 * Método responsável por retornar o valor do atributo panelGridHabitacional.
	 * <p>
	 *
	 * @return HtmlPanelGrid
	 * @author TO Brasil
	 */
	public HtmlPanelGrid getPanelGridHabitacional() {
		if (this.panelGridHabitacional == null) {
			this.panelGridHabitacional = new HtmlPanelGrid();
		}
		return panelGridHabitacional;
	}

	/**
	 * <p>
	 * Método responsável por atribuir o valor do atributo panelGrid.
	 * <p>
	 *
	 * @param panelGridHabitacional
	 *            valor a ser atribuído
	 * @author TO Brasil
	 */
	public void setPanelGridHabitacional(HtmlPanelGrid panelGridHabitacional) {
		this.panelGridHabitacional = panelGridHabitacional;
	}

	/**
	 * <p>
	 * Método responsável por atribuir o valor do atributo panelGrid.
	 * <p>
	 *
	 * @param panelGrid
	 *            valor a ser atribuído
	 * @author robson.oliveira
	 */
	public void setPanelGrid(final HtmlPanelGrid panelGrid) {
		this.panelGrid = panelGrid;
	}

	public EmpreendimentoLazyMode getEmpreendimentoLazy() {
		if (this.empreendimentoLazy == null) {
			this.empreendimentoLazy = new EmpreendimentoLazyMode();
		}
		filtrarEmpreendimento();

		return empreendimentoLazy;
	}

	private void filtrarEmpreendimento() {
		if (this.empreendimentoLazy != null) {
			EmpreendimentoVO filtro = new EmpreendimentoVO();
			HttpServletRequest request = (HttpServletRequest) FacesContext.getCurrentInstance().getExternalContext().getRequest();
			String nuContrato = request.getParameter("empreendimentoHabitacional:numeroContratoFiltro:filter");
			String nomeContrato = request.getParameter("empreendimentoHabitacional:nomeContratoFiltro:filter");
			filtro.setNomeEmpreendimento(nomeContrato);
			if(StringUtils.isNotEmpty(nuContrato)) {
				filtro.setNuContratoPaiString(nuContrato);
			} else {
				filtro.setNuContratoPai(null);
			}
			this.empreendimentoLazy.setFiltro(filtro);
		}
	}

	public void setEmpreendimentoLazy(EmpreendimentoLazyMode empreendimentoLazy) {
		this.empreendimentoLazy = empreendimentoLazy;
	}


	public String selecionarUnidadeProcesso() {
		UnidadeVO unidade = this.getVisao().getSuatSelecionada();
		LogCEF.info("Item selecionado: " + unidade.toString());
		return super.MESMA_TELA;
	}
	
	public void selectSRUnidade() {
		if (getVisao().getSrUnidade().getNuSrDirVO() != null) {
			getVisao().setNuSuat(getVisao().getSrUnidade().getNuSrDirVO().getCoUnidadeVO());
			selecionarSuat();
		} else if (getVisao().getSrUnidade().getSgSrVO() != null) {
			getVisao().setNuSr(getVisao().getSrUnidade().getSgSrVO().getNuSrVO());
			selecionarSr();
		} else if (getVisao().getSrUnidade().getNuSrVO() != null) {
			getVisao().setNuUnidade(getVisao().getSrUnidade().getNuSrVO().getCoUnidadeVO());
			selecionarUnidade();
		}
	}

	/**
	 * Metodo responsavel por preencher o AutoComplete.
	 * 
	 * @param noSuat
	 * @return
	 */
	public Collection<SrEUnidadeVO> autoCompleteUnidadeSr(final String noSuat) {		
		Integer nuSuat = getIntValue(noSuat);
		
		final String unidadeUsuario = super.getUnidadeUsuario();
		Integer nuUnidade = null;
		if (!UtilString.isVazio(unidadeUsuario)) {
			nuUnidade = Integer.valueOf(unidadeUsuario);
		}	
		
		if(getVisao().isExibirGestorRegional() || getVisao().isExibirGestorNacional() && !getVisao().isExibirGestorCaixa()) {
			
			final Collection<UnidadeVO> unidadeSrList = unidadeVinculadaSuatService.listarUnidadesPorNuSr(nuUnidade);
			for (final UnidadeVO unidadeVo : unidadeSrList) {
				if(unidadeVo.getCoUnidadeVO().toString().contains(noSuat)) {
					visao.getSrUnidadesList().add(new SrEUnidadeVO(unidadeVo));
				}
			}
			
		} else {
			visao.setSrUnidadesList(new ArrayList<SrEUnidadeVO>());
			
	
			Collection<UnidadeVO> suatsList = unidadeVinculadaSuatService.listarDiresPorNome(noSuat, nuSuat);
			for (final UnidadeVO unidadeVo : suatsList) {
				visao.getSrUnidadesList().add(new SrEUnidadeVO(unidadeVo, true));
			}
	
			Collection<SrVO> srsList = unidadeVinculadaSuatService.listarSrsPorNoSuat(noSuat, nuSuat);
			for (final SrVO snidadeVo : srsList) {
				visao.getSrUnidadesList().add(new SrEUnidadeVO(snidadeVo));
			}
	
			Collection<UnidadeVO> unidadeList = unidadeVinculadaSuatService.listarUnidadesPorNoSr(noSuat, nuSuat);
			for (final UnidadeVO unidadeVo : unidadeList) {
				visao.getSrUnidadesList().add(new SrEUnidadeVO(unidadeVo));
			}
			
		}

		return visao.getSrUnidadesList();
	}

	/**
	 * Retorna um {@link Integer} de uma {@link String}
	 * 
	 * @param nomeSuat
	 * @return
	 */
	private Integer getIntValue(String nomeSuat) {

		String numero = nomeSuat.replaceAll("[^0-9]", "");
		if (StringUtils.isNotEmpty(numero)) {
			return Integer.valueOf(numero);
		}
		return null;
	}
}