/*
 * Copyright (c) 2016 Caixa Econômica Federal. Todos os direitos
 * reservados.
 *
 * Caixa Econômica Federal - SIACG_dev
 *
 * Este software foi desenvolvido sob demanda da CAIXA e está
 * protegido por leis de direitos autorais e tratados internacionais. As
 * condições de cópia e utilização do total ou partes dependem de autorização da
 * pessoa. Cópias não são permitidas sem expressa autorização. Não pode ser
 * comercializado ou utilizado para propósitos particulares.
 *
 * Uso exclusivo da Caixa Econômica Federal. A reprodução ou distribuição não
 * autorizada deste programa ou de parte dele, resultará em punições civis e
 * criminais e os infratores incorrem em sanções previstas na legislação em
 * vigor.
 *
 * Histórico do Subversion:
 *
 * LastChangedRevision: $Revision$
 * LastChangedBy: $Author$
 * LastChangedDate: $Date$
 *
 * HeadURL: $HeadURL$
 *
 */
package br.gov.caixa.siacg.comum.to;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * 
 * <p>BodySid00TO</p>
 *
 * <p>Descrição: Descrição do tipo</p>
 *
 * <br><b>Empresa:</b> Cef - Caixa Econômica Federal
 *
 *
 * @author p575337
 *
 * @version 1.0
 */
@JsonIgnoreProperties(ignoreUnknown = true)
public class LancamentoContaSid00TO {

	@JsonProperty(value="tipo_lancamento")
    private Integer tipoLancamento;

	@JsonProperty(value="codigo_lancamento")
    private Integer codigoLancamento;
	
	@JsonProperty(value="tipo_documento")
    private Integer tipoDocumento;

	/**
	 * <p>Retorna o valor do atributo tipoLancamento</p>.
	 *
	 * @return tipoLancamento
	*/
	public Integer getTipoLancamento() {
		return this.tipoLancamento;
	}

	/**
	 * <p>Define o valor do atributo tipoLancamento</p>.
	 *
	 * @param tipoLancamento valor a ser atribuído
	*/
	public void setTipoLancamento(Integer tipoLancamento) {
		this.tipoLancamento = tipoLancamento;
	}

	/**
	 * <p>Retorna o valor do atributo codigoLancamento</p>.
	 *
	 * @return codigoLancamento
	*/
	public Integer getCodigoLancamento() {
		return this.codigoLancamento;
	}

	/**
	 * <p>Define o valor do atributo codigoLancamento</p>.
	 *
	 * @param codigoLancamento valor a ser atribuído
	*/
	public void setCodigoLancamento(Integer codigoLancamento) {
		this.codigoLancamento = codigoLancamento;
	}

	/**
	 * <p>Retorna o valor do atributo tipoDocumento</p>.
	 *
	 * @return tipoDocumento
	*/
	public Integer getTipoDocumento() {
		return this.tipoDocumento;
	}

	/**
	 * <p>Define o valor do atributo tipoDocumento</p>.
	 *
	 * @param tipoDocumento valor a ser atribuído
	*/
	public void setTipoDocumento(Integer tipoDocumento) {
		this.tipoDocumento = tipoDocumento;
	}
}