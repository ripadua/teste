package br.gov.caixa.siacg.view.form;

import java.util.ArrayList;
import java.util.List;

import br.gov.caixa.siacg.model.domain.Propriedade;
import br.gov.caixa.siacg.model.domain.ViewProdutoSiico;

/**
 * <p>
 * ParametrizacaoContratoVisao
 * </p>
 * <p>
 * Descrição: Classe responsável por armazenar os dados de visão da
 * funcionalidade de manutenção de Parametros.
 * </p>
 * <br>
 * <b>Empresa:</b> Cef - Caixa Econômica Federal
 *
 * @author ludemeula.sa
 */
public class ParametroVisao extends TemplateVisao<Propriedade> {

	private static final long serialVersionUID = -6469542894041006921L;

	private List<ViewProdutoSiico> operacoesSelecionadas;
	private List<ViewProdutoSiico> operacoesRemovidas;

	/**
	 * <p>Retorna o valor do atributo operacoesSelecionadas</p>.
	 *
	 * @return operacoesSelecionadas
	*/
	public List<ViewProdutoSiico> getOperacoesSelecionadas() {
		if (operacoesSelecionadas == null) {
			setOperacoesSelecionadas(new ArrayList<ViewProdutoSiico>());
		}
		
		return this.operacoesSelecionadas;
	}

	/**
	 * <p>Define o valor do atributo operacoesSelecionadas</p>.
	 *
	 * @param operacoesSelecionadas valor a ser atribuído
	*/
	public void setOperacoesSelecionadas(List<ViewProdutoSiico> operacoesSelecionadas) {
		this.operacoesSelecionadas = operacoesSelecionadas;
	}

	/**
	 * <p>
	 * Retorna o valor do atributo operacoesRemovidas
	 * </p>
	 * .
	 *
	 * @return operacoesRemovidas
	 */
	public List<ViewProdutoSiico> getOperacoesRemovidas() {
		if (operacoesRemovidas == null) {
			setOperacoesRemovidas(new ArrayList<ViewProdutoSiico>());
		}
		
		return this.operacoesRemovidas;
	}

	/**
	 * <p>
	 * Define o valor do atributo operacoesRemovidas
	 * </p>
	 * .
	 *
	 * @param operacoesRemovidas
	 *            valor a ser atribuído
	 */
	public void setOperacoesRemovidas(List<ViewProdutoSiico> operacoesRemovidas) {
		this.operacoesRemovidas = operacoesRemovidas;
	}

}