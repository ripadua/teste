/*
 * Copyright (c) 2016 Caixa Econômica Federal. Todos os direitos
 * reservados.
 *
 * Caixa Econômica Federal - SIACG_dev
 *
 * Este software foi desenvolvido sob demanda da CAIXA e está
 * protegido por leis de direitos autorais e tratados internacionais. As
 * condições de cópia e utilização do total ou partes dependem de autorização da
 * pessoa. Cópias não são permitidas sem expressa autorização. Não pode ser
 * comercializado ou utilizado para propósitos particulares.
 *
 * Uso exclusivo da Caixa Econômica Federal. A reprodução ou distribuição não
 * autorizada deste programa ou de parte dele, resultará em punições civis e
 * criminais e os infratores incorrem em sanções previstas na legislação em
 * vigor.
 *
 * Histórico do Subversion:
 *
 * LastChangedRevision: $Revision$
 * LastChangedBy: $Author$
 * LastChangedDate: $Date$
 *
 * HeadURL: $HeadURL$
 *
 */
package br.gov.caixa.siacg.comum.to;

import java.math.BigDecimal;
import java.util.Date;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import br.gov.caixa.siacg.commons.AppConstant;
import br.gov.caixa.siacg.model.json.saldows.Garantia;
import br.gov.caixa.siacg.util.NumeroUtil;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

/**
 * 
 * <p>RespostaAcaoPreventivaTO</p>
 *
 * <p>Retorno do SID00</p>
 *
 * <br><b>Empresa:</b> Cef - Caixa Econômica Federal
 *
 *
 * @author p575337
 *
 * @version 1.0
 */
@JsonIgnoreProperties(ignoreUnknown=true, value={"nuLogServicoSaldo", "digitoContrato", "numeroBloqueio", "identificadorPessoa", "garantia", "valorContrato", "prestacao", "numeroDesbloqueio", "input", "output", "matricula", "matriculaAutorizador", "unidadeContrato", "operacao", "numeroContrato", "codigoContaEdigitoVerificador", "codigoConta", "numeroProduto", "codigoAgencia", "codigoOperacao", "codigoDigitoVerificador", "numeroNota", "dtContrato"})
@ApiModel(value="ItemResposta")
public class GarantiaAcaoPreventivaTO {

    /**Campos retornado na resposta do serviço*/
    @ApiModelProperty(value = "Código da mensagem retornada pelo sistema que foi feita a integração. 0 ou 00 é Sucesso, qualquer outro valor é erro .", example="00")
    private String codigoRetorno;
    @ApiModelProperty(value = "Mensagem retornada pelo sistema que foi feita a integração.", example="OPERACAO REALIZADA COM SUCESSO.")
    private String mensagem;
    @ApiModelProperty(value = "Sistema que originou a mensagem.", example="SID00")
    private String sistema;
    @ApiModelProperty(value = "Código da garantia que foi processada.", example="0238001004211505-90-20180813000519")
    private String codigoGarantia;
    @ApiModelProperty(value = "Valor.", example="10235.55")
    private BigDecimal valor;
    @ApiModelProperty(value = "CEDES responsavel pelo Sistema.", example="CEDESSP01")
    private String cedesResponsavel;

    /**Campo do processamento inteno*/
    private String numeroBloqueio;
    private String numeroDesbloqueio;
    private String input;
    private String output;
    private String matricula;
    private String matriculaAutorizador;
    private String unidadeContrato;
    private String operacao;
    private String numeroContrato;
    private String digitoContrato;
    private Garantia garantia;
    private BigDecimal valorContrato;
    private BigDecimal prestacao;
    private String identificadorPessoa;
    private Integer nuLogServicoSaldo;
    private Date dtContrato;


    public GarantiaAcaoPreventivaTO(Garantia garantia) {
	super();
	setCodigoGarantia(garantia.getCodigoGarantia());
	setValor(garantia.getValorBloqueio());
	setSistema(AppConstant.SIACG);
	setNumeroDesbloqueio(garantia.getNumeroNotaDesbloqueio());
	setGarantia(garantia);
    }
    /**
     * <p>Retorna o valor do atributo codigoRetorno</p>.
     *
     * @return codigoRetorno
     */
    public String getCodigoRetorno() {
	return this.codigoRetorno;
    }
    /**
     * <p>Define o valor do atributo codigoRetorno</p>.
     *
     * @param codigoRetorno valor a ser atribuído
     */
    public void setCodigoRetorno(String codigoRetorno) {
	this.codigoRetorno = codigoRetorno;
    }
    /**
     * <p>Retorna o valor do atributo mensagem</p>.
     *
     * @return mensagem
     */
    public String getMensagem() {
	return this.mensagem;
    }
    /**
     * <p>Define o valor do atributo mensagem</p>.
     *
     * @param mensagem valor a ser atribuído
     */
    public void setMensagem(String mensagem) {
	this.mensagem = mensagem;
    }
    /**
     * <p>Retorna o valor do atributo sistema</p>.
     *
     * @return sistema
     */
    public String getSistema() {
	return this.sistema;
    }
    /**
     * <p>Define o valor do atributo sistema</p>.
     *
     * @param sistema valor a ser atribuído
     */
    public void setSistema(String sistema) {
	this.sistema = sistema;
    }
    /**
     * <p>Retorna o valor do atributo codigoGarantia</p>.
     *
     * @return codigoGarantia
     */
    public String getCodigoGarantia() {
	return this.codigoGarantia;
    }
    /**
     * <p>Define o valor do atributo codigoGarantia</p>.
     *
     * @param codigoGarantia valor a ser atribuído
     */
    public void setCodigoGarantia(String codigoGarantia) {
	this.codigoGarantia = codigoGarantia;
    }
    /**
     * <p>Retorna o valor do atributo numeroBloqueio</p>.
     *
     * @return numeroBloqueio
     */
    public String getNumeroBloqueio() {
	return this.numeroBloqueio;
    }
    /**
     * <p>Define o valor do atributo numeroBloqueio</p>.
     *
     * @param numeroBloqueio valor a ser atribuído
     */
    public void setNumeroBloqueio(String numeroBloqueio) {
	this.numeroBloqueio = numeroBloqueio;
    }
    /**
     * <p>Retorna o valor do atributo valor</p>.
     *
     * @return valor
     */
    public BigDecimal getValor() {
	return this.valor;
    }
    /**
     * <p>Define o valor do atributo valor</p>.
     *
     * @param valor valor a ser atribuído
     */
    public void setValor(BigDecimal valor) {
	this.valor = valor;
    }
    /**
     * <p>Retorna o valor do atributo input</p>.
     *
     * @return input
     */
    public String getInput() {
	return this.input;
    }
    /**
     * <p>Define o valor do atributo input</p>.
     *
     * @param input valor a ser atribuído
     */
    public void setInput(String input) {
	this.input = input;
    }
    /**
     * <p>Retorna o valor do atributo output</p>.
     *
     * @return output
     */
    public String getOutput() {
	return this.output;
    }
    /**
     * <p>Define o valor do atributo output</p>.
     *
     * @param output valor a ser atribuído
     */
    public void setOutput(String output) {
	this.output = output;
    }

    /**
     * <p>Retorna o valor do atributo matricula</p>.
     *
     * @return matricula
     */
    public String getMatricula() {
	return this.matricula;
    }
    /**
     * <p>Define o valor do atributo matricula</p>.
     *
     * @param matricula valor a ser atribuído
     */
    public void setMatricula(String matricula) {
	this.matricula = matricula;
    }

    /**
     * <p>Retorna o valor do atributo numeroDesbloqueio</p>.
     *
     * @return numeroDesbloqueio
     */
    public String getNumeroDesbloqueio() {
	return this.numeroDesbloqueio;
    }
    
    /**
     * <p>Retorna o valor do atributo matriculaAutorizador</p>.
     *
     * @return matriculaAutorizador
    */
    public String getMatriculaAutorizador() {
        return this.matriculaAutorizador;
    }
    /**
     * <p>Define o valor do atributo matriculaAutorizador</p>.
     *
     * @param matriculaAutorizador valor a ser atribuído
    */
    public void setMatriculaAutorizador(String matriculaAutorizador) {
        this.matriculaAutorizador = matriculaAutorizador;
    }
    /**
     * <p>Retorna o valor do atributo unidadeContrato</p>.
     *
     * @return unidadeContrato
    */
    public String getUnidadeContrato() {
        return this.unidadeContrato;
    }
    /**
     * <p>Define o valor do atributo unidadeContrato</p>.
     *
     * @param unidadeContrato valor a ser atribuído
    */
    public void setUnidadeContrato(String unidadeContrato) {
        this.unidadeContrato = unidadeContrato;
    }
    /**
     * <p>Retorna o valor do atributo operacao</p>.
     *
     * @return operacao
    */
    public String getOperacao() {
        return this.operacao;
    }
    /**
     * <p>Define o valor do atributo operacao</p>.
     *
     * @param operacao valor a ser atribuído
    */
    public void setOperacao(String operacao) {
        this.operacao = operacao;
    }
    /**
     * <p>Retorna o valor do atributo numeroContrato</p>.
     *
     * @return numeroContrato
    */
    public String getNumeroContrato() {
        return this.numeroContrato;
    }
    /**
     * <p>Define o valor do atributo numeroContrato</p>.
     *
     * @param numeroContrato valor a ser atribuído
    */
    public void setNumeroContrato(String numeroContrato) {
        this.numeroContrato = numeroContrato;
    }
    /**
     * <p>Define o valor do atributo numeroDesbloqueio</p>.
     *
     * @param numeroDesbloqueio valor a ser atribuído
     */
    public void setNumeroDesbloqueio(String numeroDesbloqueio) {
	this.numeroDesbloqueio = numeroDesbloqueio;
    }
    
    
    
    /**
     * <p>Retorna o valor do atributo garantia</p>.
     *
     * @return garantia
    */
    public Garantia getGarantia() {
        return this.garantia;
    }
    /**
     * <p>Define o valor do atributo garantia</p>.
     *
     * @param garantia valor a ser atribuído
    */
    public void setGarantia(Garantia garantia) {
        this.garantia = garantia;
    }
    /**
     * <p>Retorna o valor do atributo valorContrato</p>.
     *
     * @return valorContrato
    */
    public BigDecimal getValorContrato() {
        return this.valorContrato;
    }
    /**
     * <p>Define o valor do atributo valorContrato</p>.
     *
     * @param valorContrato valor a ser atribuído
    */
    public void setValorContrato(BigDecimal valorContrato) {
        this.valorContrato = valorContrato;
    }
    /**
     * <p>Retorna o valor do atributo prestacao</p>.
     *
     * @return prestacao
    */
    public BigDecimal getPrestacao() {
        return this.prestacao;
    }
    /**
     * <p>Define o valor do atributo prestacao</p>.
     *
     * @param prestacao valor a ser atribuído
    */
    public void setPrestacao(BigDecimal prestacao) {
        this.prestacao = prestacao;
    }
    
    /**
     * <p>Retorna o valor do atributo identificadorPessoa</p>.
     *
     * @return identificadorPessoa
    */
    public String getIdentificadorPessoa() {
        return this.identificadorPessoa;
    }
    /**
     * <p>Define o valor do atributo identificadorPessoa</p>.
     *
     * @param identificadorPessoa valor a ser atribuído
    */
    public void setIdentificadorPessoa(String identificadorPessoa) {
        this.identificadorPessoa = identificadorPessoa;
    }
    
    /**
     * <p>Retorna o valor do atributo digitoContrato</p>.
     *
     * @return digitoContrato
    */
    public String getDigitoContrato() {
        return this.digitoContrato;
    }
    /**
     * <p>Define o valor do atributo digitoContrato</p>.
     *
     * @param digitoContrato valor a ser atribuído
    */
    public void setDigitoContrato(String digitoContrato) {
        this.digitoContrato = digitoContrato;
    }
    
    /**
     * <p>Retorna o valor do atributo nuLogServicoSaldo</p>.
     *
     * @return nuLogServicoSaldo
    */
    public Integer getNuLogServicoSaldo() {
        return this.nuLogServicoSaldo;
    }
    /**
     * <p>Define o valor do atributo nuLogServicoSaldo</p>.
     *
     * @param nuLogServicoSaldo valor a ser atribuído
    */
    public void setNuLogServicoSaldo(Integer nuLogServicoSaldo) {
        this.nuLogServicoSaldo = nuLogServicoSaldo;
    }
    /**
     * <p> Método responsável por getCodigoOperacao <p>
     *
     * codigoGarantia: "0002583001111115"
     * Agencia:0002 operação:001 conta:00111111 dv:5
     * 
     * @return
     * @author douglas.lopes
     */
    @JsonIgnore
    public Integer getCodigoOperacao() {
	if (!isCodigoGarantiaValido())
	    return null;
	String retorno;
	String[] split = codigoGarantia.split("-");
	if (split.length == 4) {
	    retorno = NumeroUtil.somenteNumeros(split[1]);
	}else {
	    retorno = this.codigoGarantia.substring(4, 7);
	}
	return NumeroUtil.parseInt(retorno);
    }

    /**
     * <p> Método responsável por isCodigoGarantiaValido <p>
     *
     * @author douglas.lopes
     */
    @JsonIgnore
    private boolean isCodigoGarantiaValido() {
	return (null != this.codigoGarantia && this.codigoGarantia.length()>=16);
    }

    /**
     * <p> Método responsável por getCodigoAgencia <p>
     *
     * codigoGarantia: "0002583001111115"
     * Agencia:0002 operação:001 conta:00111111 dv:5
     * 
     * @return
     * @author douglas.lopes
     */
    @JsonIgnore
    public Integer getCodigoAgencia() {
	if (!isCodigoGarantiaValido())
	    return null;

	return NumeroUtil.parseInt(this.codigoGarantia.substring(0, 4));
    }

    /**
     * 
     * <p>Método responsável por obter o número da nota.</p>.
     *
     * @author p575337
     *
     * @return Nota
     */
    @JsonIgnore
    public String getNumeroNota() {
	String retorno;
	if (codigoGarantia != null && codigoGarantia.length() > 16) {
	    retorno = NumeroUtil.somenteNumeros(codigoGarantia.substring(codigoGarantia.lastIndexOf('-')));
	} else {
	    retorno = null;
	}
	return retorno;
    }

    @JsonIgnore
    public Long getCodigoContaEdigitoVerificador() {
	if (!isCodigoGarantiaValido())
	    return null;

	return NumeroUtil.parseLong(this.codigoGarantia.substring(7, 16));
    }

    @JsonIgnore
    public String getNumeroProduto() {
	String retorno = null;
	if (codigoGarantia != null) {
	    String[] split = codigoGarantia.split("-");
	    if (split.length == 3) {
		retorno = NumeroUtil.somenteNumeros(split[1]);
	    }
	}
	return retorno;
    }

    /**
     * <p> Método responsável por getCodigoConta <p>
     *
     * codigoGarantia: "0002583001111115"
     * Agencia:0002 operação:001 conta:00111111 dv:5
     * 
     * @return
     * @author douglas.lopes
     */
    @JsonIgnore
    public Integer getCodigoConta() {
	if (!isCodigoGarantiaValido())
	    return null;

	return NumeroUtil.parseInt(this.codigoGarantia.substring(7, 15));
    }

    @JsonIgnore
    public Integer getCodigoDigitoVerificador() {
	if (!isCodigoGarantiaValido())
	    return null;

	return NumeroUtil.parseInt(this.codigoGarantia.substring(15, 16));
    }
    /**
     * <p>Retorna o valor do atributo cedesResponsavel</p>.
     *
     * @return cedesResponsavel
    */
    public String getCedesResponsavel() {
        return this.cedesResponsavel;
    }
    /**
     * <p>Define o valor do atributo cedesResponsavel</p>.
     *
     * @param cedesResponsavel valor a ser atribuído
    */
    public void setCedesResponsavel(String cedesResponsavel) {
        this.cedesResponsavel = cedesResponsavel;
    }
    /**
     * <p>Retorna o valor do atributo dtContrato</p>.
     *
     * @return dtContrato
    */
    public Date getDtContrato() {
        return this.dtContrato;
    }
    /**
     * <p>Define o valor do atributo dtContrato</p>.
     *
     * @param dtContrato valor a ser atribuído
    */
    public void setDtContrato(Date dtContrato) {
        this.dtContrato = dtContrato;
    }
}