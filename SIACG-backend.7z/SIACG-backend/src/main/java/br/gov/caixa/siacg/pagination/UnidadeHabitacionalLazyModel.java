package br.gov.caixa.siacg.pagination;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.enterprise.context.SessionScoped;
import javax.inject.Inject;
import javax.inject.Named;

import org.primefaces.model.SortOrder;

import br.gov.caixa.pedesgo.arquitetura.paginacao.Paginacao;
import br.gov.caixa.pedesgo.arquitetura.paginacao.PaginacaoDemanda;
import br.gov.caixa.siacg.model.domain.Contrato;
import br.gov.caixa.siacg.model.domain.Empreendimento;
import br.gov.caixa.siacg.model.domain.UnidadeHabitacional;
import br.gov.caixa.siacg.model.vo.FiltroUnidadeHabitacionalVO;
import br.gov.caixa.siacg.service.CalculoValorMinimoDesligamentoService;
import br.gov.caixa.siacg.service.UnidadeHabitacionalService;

/**
 * <p>
 * UnidadeHabitacionalLazyModel.
 * </p>
 * <p>
 * Descrição: Classe de paginação sob demanda de unidade habitacional;
 * </p>
 * <br>
 * <b>Empresa:</b> Cef - Caixa Econômica Federal
 *
 * @author ludemeula.sa
 * @version 1.0
 */
@Named
@SessionScoped
public class UnidadeHabitacionalLazyModel extends Paginacao<UnidadeHabitacional> {
	
	private static final long serialVersionUID = 1710863672619023343L;

	@Inject
    private UnidadeHabitacionalService service;
	
    @Inject
	private CalculoValorMinimoDesligamentoService calculoVMD;
    
    private FiltroUnidadeHabitacionalVO filtro;

    private Contrato contrato;
    private BigDecimal valorMantido;
    
    /**
     * @see br.gov.caixa.pedesgo.arquitetura.integracao.componente.paginacao.Paginacao#load(int,
     *      int, java.lang.String, org.primefaces.model.SortOrder,
     *      java.util.Map)
     */
    @Override
    public List<UnidadeHabitacional> load(final int inicio, final int fim, final String campoOrdenacao, final SortOrder ordenacao, final Map<String, String> parametros) {
    	List<UnidadeHabitacional> unidades = new ArrayList<>();
    	
    	if (getFiltro().getNuEmpreendimento() != null) {
    		final PaginacaoDemanda<UnidadeHabitacional> resultado = this.service.listar(getFiltro(), inicio, fim);
            unidades = resultado.getLista();
            
    		super.setWrappedData(unidades);
            super.setRowCount(resultado.getQuantidadeRegistros() == 0 ? unidades.size() : resultado.getQuantidadeRegistros());
            
    		calculoVMD.calcular(getContrato(), unidades, getValorMantido());
    	}

        return unidades;
    }
    
    /**
     * @see br.gov.caixa.pedesgo.arquitetura.integracao.componente.paginacao.Paginacao#getServico()
     */
    @Override
    @SuppressWarnings("unchecked")
    public UnidadeHabitacionalService getServico() {
        return this.service;
    }

    public void adicionarFiltros(final Empreendimento empreendimento, final Contrato contrato, final BigDecimal valorMantido) {
    	setFiltro(new FiltroUnidadeHabitacionalVO());
    	
    	getFiltro().setNuEmpreendimento(empreendimento.getNuEmpreendimento());
    	this.contrato = contrato;
    	this.valorMantido = valorMantido;
    }
    
    /**
     * Retorna o valor do atributo filtro.
     *
     * @return filtro
     */
    public FiltroUnidadeHabitacionalVO getFiltro() {
        if (this.filtro == null) {
            this.filtro = new FiltroUnidadeHabitacionalVO();
        }
        return this.filtro;
    }

    /**
     * Define o valor do atributo filtro.
     *
     * @param filtro
     *            valor a ser atribuído
     */
    public void setFiltro(final FiltroUnidadeHabitacionalVO filtro) {
        this.filtro = filtro;
    }

	/**
	 * <p>Retorna o valor do atributo contrato</p>.
	 *
	 * @return contrato
	*/
	private Contrato getContrato() {
		return this.contrato;
	}

	/**
	 * <p>Retorna o valor do atributo valorMantido</p>.
	 *
	 * @return valorMantido
	*/
	private BigDecimal getValorMantido() {
		return this.valorMantido;
	}
}