/**
 * Copyright (c) 2015 Caixa Econômica Federal. Todos os direitos
 * reservados.
 *
 * Caixa Econômica Federal - SIACG - Sistema de Crédito Rural
 *
 * Este software foi desenvolvido sob demanda da CAIXA e está
 * protegido por leis de direitos autorais e tratados internacionais. As
 * condições de cópia e utilização do todo ou partes dependem de autorização da
 * pessoa. Cópias não são permitidas sem expressa autorização. Não pode ser
 * comercializado ou utilizado para propósitos particulares.
 *
 * Uso exclusivo da Caixa Econômica Federal. A reprodução ou distribuição não
 * autorizada deste programa ou de parte dele, resultará em punições civis e
 * criminais e os infratores incorrem em sanções previstas na legislação em
 * vigor.
 *
 * Histórico do Subversion:
 *
 * LastChangedRevision: $Revision$
 * LastChangedBy: $Author$
 * LastChangedDate: $Date$
 *
 * HeadURL: $HeadURL$
 *
 */
package br.gov.caixa.siacg.view.mb;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.IllegalFormatException;
import java.util.List;

import javax.ejb.EJB;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;

import org.apache.commons.collections.CollectionUtils;
import org.primefaces.context.RequestContext;
import org.primefaces.event.UnselectEvent;

import br.gov.caixa.pedesgo.arquitetura.controlador.AbstractBean;
import br.gov.caixa.pedesgo.arquitetura.controlador.ManutencaoBean;
import br.gov.caixa.pedesgo.arquitetura.util.LogCefUtil;
import br.gov.caixa.pedesgo.arquitetura.util.UtilString;
import br.gov.caixa.siacg.model.domain.Garantia;
import br.gov.caixa.siacg.model.domain.GarantiaCaixaProduto;
import br.gov.caixa.siacg.model.domain.GarantiaProduto;
import br.gov.caixa.siacg.model.domain.ViewProdutoSiico;
import br.gov.caixa.siacg.model.vo.ProdutoModalidadeVO;
import br.gov.caixa.siacg.service.GarantiaCaixaProdutoService;
import br.gov.caixa.siacg.service.GarantiaProdutoService;
import br.gov.caixa.siacg.service.GarantiaService;
import br.gov.caixa.siacg.service.ParametroProdutoService;
import br.gov.caixa.siacg.service.ViewProdutoSiicoService;
import br.gov.caixa.siacg.view.form.GarantiaProdutoVisao;

/**
 * <p>
 * GarantiaProdutoMB.
 * </p>
 * <p>
 * Descrição: Bean Gerenciável para a entidade GarantiaProduto.
 * </p>
 * <br>
 * <b>Empresa:</b> Cef - Caixa Econômica Federal
 *
 * @author Mábio Barbosa
 * @version 1.0
 */
@ManagedBean
@SessionScoped
public class GarantiaProdutoMB extends ManutencaoBean<GarantiaProduto> {

	/** Atributo serialVersionUID. */
	private static final long serialVersionUID = -4248095391849635745L;

	/** Atributo PREFIXO_CASO_USO. */
	private static final String PREFIXO_CASO_USO = "garantiaProduto";

	/** Atributo DIRETORIO_PAGINAS. */
	private static final String DIRETORIO_PAGINAS = "/pages/";

	/** Atributo NOME_MANAGED_BEAN. */
	public static final String NOME_MANAGED_BEAN = "garantiaProdutoMB";

	/** Atributo EL_MANAGED_BEAN. */
	public static final String EL_MANAGED_BEAN = "#{garantiaProdutoMB}";

	/** Atributo VAR_RESOURCE_BUNDLE. */
	private static final String VAR_RESOURCE_BUNDLE = "msgApp";

	/** Atributo MODO_INCLUSAO. */
	public static final int MODO_INCLUSAO = 0;

	/** Atributo OPERACAO_SUCESSO. */
	private static final String OPERACAO_SUCESSO = "MA002";

	/** Atributo ERRO_OPERACAO. */
	private static final String ERRO_OPERACAO = "MA012";

	/** Atributo SELECIONAR_PRODUTO_MODALIDADE. */
	private static final String SELECIONAR_PRODUTO_MODALIDADE = "MN055";

	/** Atributo NENHUM_REGISTRO. */
	private static final String NENHUM_REGISTRO = "MN056";

	/** Atributo EXISTE_PARAMETRIZACAO. */
	private static final String EXISTE_PARAMETRIZACAO = "MN059";

	/** Atributo EXISTE_PARAMETRIZACAO_SALVAR. */
	private static final String EXISTE_PARAMETRIZACAO_SALVAR = "MN060";
	
	private static final String GARANTIA_BACEN_UTILIZADA = "MN070";

	/** Atributo strModalidadeFormatadaFiltro. */
	private String strModalidadeFormatadaFiltro;

	/** Atributo strModalidadeFormatada. */
	private String strModalidadeFormatada;

	/** Atributo visao. */
	private transient GarantiaProdutoVisao visao;

	/** Atributo garantiaService. */
	@EJB
	private transient GarantiaService garantiaService;

	/** Atributo garantiaProdutoService. */
	@EJB
	private transient GarantiaProdutoService garantiaProdutoService;

	/** Atributo garantiaProdutoService. */
	@EJB
	private transient GarantiaCaixaProdutoService garantiaCaixaProdutoService;

	/** Atributo parametroProdutoService. */
	@EJB
	private transient ParametroProdutoService parametroProdutoService;

	@EJB
	private transient ViewProdutoSiicoService viewProdutoSiicoService;

	/** Atributos picklist garantias BACEN obrigatórias */
	private List<Garantia> listModelGarantiasSelecionada;
	private List<Garantia> garantiasDisponiveis;
	private List<Garantia> garantiasIncluidas;
	private List<Garantia> garantiasSelecionadas;
	private List<Garantia> garantiasObrigatoriasExcluir;

	/** Atributos picklist garantias BACEN acessórias */
	private List<Garantia> garantiasDisponiveisAcessorias;
	private List<Garantia> garantiasIncluidasAcessorias;
	private List<Garantia> garantiasSelecionadasAcessorias;
	private List<Garantia> garantiasAcessoriasExcluir;

	/** Atributos picklist garantias Caixa */
	private List<ViewProdutoSiico> garantiasDisponiveisCaixa;
	private List<ViewProdutoSiico> garantiasIncluidasCaixa;
	private List<ViewProdutoSiico> garantiasSelecionadasCaixa;
	private List<ViewProdutoSiico> garantiasCaixaExcluir;

	/**
	 * @see br.gov.caixa.pedesgo.arquitetura.controlador.AbstractBean#carregar()
	 */
	@Override
	protected void carregar() {
		this.getVisao().setEntidade(new GarantiaProduto());

		this.limparFiltros();
		this.buscarGarantiasFiltroInicio();

		this.visao.setAutoCompleteProduto(null);
		this.setStrModalidadeFormatada(null);
		this.visao.setTelaEdicao(false);
		this.visao.getGarantiasProduto().clear();
		this.visao.getGarantiasCaixaProduto().clear();

		this.initPickListGarantiasObrigatorias();
		this.initPickListGarantiasAcessorias();
		this.initPickListGarantiasCaixa();
	}

	/**
	 * @see br.gov.caixa.pedesgo.arquitetura.controlador.AbstractBean#getPrefixoCasoDeUso()
	 */
	@Override
	protected String getPrefixoCasoDeUso() {
		return GarantiaProdutoMB.PREFIXO_CASO_USO;
	}

	/**
	 * @see br.gov.caixa.pedesgo.arquitetura.controlador.AbstractBean#getService()
	 */
	@SuppressWarnings("unchecked")
	@Override
	public GarantiaService getService() {
		return this.garantiaService;
	}

	/**
	 * @see br.gov.caixa.pedesgo.arquitetura.controlador.AbstractBean#getTelaInclusao()
	 */
	@Override
	public String getTelaInclusao() {
		// /inclusao.xhtml?faces-redirect=true
		return GarantiaProdutoMB.DIRETORIO_PAGINAS.concat(this.getPrefixoCasoDeUso())
				.concat(AbstractBean.SUFIXO_TELA_INCLUSAO);
	}

	/**
	 * @see br.gov.caixa.pedesgo.arquitetura.controlador.AbstractBean#getTelaEdicao()
	 */
	@Override
	public String getTelaEdicao() {
		return GarantiaProdutoMB.DIRETORIO_PAGINAS.concat(this.getPrefixoCasoDeUso())
				.concat(AbstractBean.SUFIXO_TELA_EDICAO);
	}

	/**
	 * @see br.gov.caixa.pedesgo.arquitetura.controlador.AbstractBean#getTelaConsulta()
	 */
	@Override
	public String getTelaConsulta() {
		return GarantiaProdutoMB.DIRETORIO_PAGINAS.concat(this.getPrefixoCasoDeUso())
				.concat(AbstractBean.SUFIXO_TELA_CONSULTA);
	}

	/**
	 * @see br.gov.caixa.pedesgo.arquitetura.controlador.AbstractBean#getNomeVarResourceBundle()
	 */
	@Override
	protected String getNomeVarResourceBundle() {
		return GarantiaProdutoMB.VAR_RESOURCE_BUNDLE;
	}

	/**
	 * @see br.gov.caixa.pedesgo.arquitetura.controlador.AbstractBean#getVisao()
	 */
	@Override
	public GarantiaProdutoVisao getVisao() {
		if (this.visao == null) {
			this.visao = new GarantiaProdutoVisao();
		}
		return this.visao;
	}

	private void initPickListGarantiasObrigatorias() {
		garantiasDisponiveis = this.listarAtivos();
		garantiasIncluidas = new ArrayList<>();
		garantiasSelecionadas = new ArrayList<>();
		garantiasObrigatoriasExcluir = new ArrayList<>();
	}

	private void initPickListGarantiasAcessorias() {
		garantiasDisponiveisAcessorias = this.listarAtivos();
		garantiasIncluidasAcessorias = new ArrayList<>();
		garantiasSelecionadasAcessorias = new ArrayList<>();
		garantiasAcessoriasExcluir = new ArrayList<>();
	}

	private void initPickListGarantiasCaixa() {
		garantiasDisponiveisCaixa = this.listarGarantiasCaixa();
		garantiasIncluidasCaixa = new ArrayList<>();
		garantiasSelecionadasCaixa = new ArrayList<>();
		garantiasCaixaExcluir = new ArrayList<>();
	}

    public Collection<ViewProdutoSiico> autoCompleteProduto(final String produto) {
    	this.limpaCamposDaTela();
    	if (produto != null && produto.trim().length() > 1) {
    	    return this.viewProdutoSiicoService.listaAutoComplete(produto);
    	}
    	return new ArrayList<ViewProdutoSiico>();
    }

	public Collection<ViewProdutoSiico> autoCompleteAcessorias(final String produto) {
		this.limpaCamposDaTela();
		return this.viewProdutoSiicoService.listaAutoComplete(produto);
	}

	private void limpaCamposDaTela() {
		this.visao.limpar();
		this.setStrModalidadeFormatada("");
	}

	private void limparFiltros() {
		this.visao.setAutoCompleteProdutoFiltro(null);
		this.setStrModalidadeFormatadaFiltro(null);

		this.visao.setNuProdutoSelecionadoFiltro(null);
		this.visao.setNuModalidadeSelecionadaFiltro(null);

		this.visao.setListaProdutoModadalideVOFiltro(null);
	}

	private void onSelectProdutoFiltro() {
		this.selecionarProdutoFiltro(this.getVisao().getAutoCompleteProdutoFiltro());
	}

	public void onSelectProduto() {
		this.selecionarProduto(this.getVisao().getAutoCompleteProduto());
		this.carregarDadosBanco();
	}

	private void selecionarProdutoFiltro(String autoCompleteProduto) {
		if (!UtilString.isVazio(autoCompleteProduto)) {
			this.getVisao().setNuProdutoSelecionadoFiltro(this.obterNuProduto(autoCompleteProduto));
		} else {
			this.getVisao().setNuProdutoSelecionadoFiltro(null);
		}
	}

	public void selecionarProduto(String autoCompleteProduto) {
		this.limparListasSelecionadas();
		this.limparListasCaixa();

		if (!UtilString.isVazio(autoCompleteProduto)) {
			this.getVisao().setNuProdutoSelecionado(this.obterNuProduto(autoCompleteProduto));
		} else {
			this.getVisao().setNuProdutoSelecionado(null);
		}
	}

	private Integer obterNuProduto(String autoCompleteProduto) {
		if (!UtilString.isVazio(autoCompleteProduto)) {
			String[] retornoSplit = autoCompleteProduto.split(" ");
			return Integer.parseInt(retornoSplit[0]);
		}
		return null;
	}

	private void carregarDadosBanco() {
		if (this.visao.getNuProdutoSelecionado() != null && this.visao.getNuModalidadeSelecionada() != null) {

			this.preencheGarantiasDoBancoNoPickList();
			this.removerItensJaAdicionados();
		}
	}

	private List<ViewProdutoSiico> listarGarantiasCaixa() {
		if (CollectionUtils.isEmpty(this.visao.getListaProdutoCaixa())) {
			this.visao
					.setListaProdutoCaixa(new ArrayList<>(this.viewProdutoSiicoService.listarProdutosTipoEmprestimo()));

			this.ordenaGarantiaCaixaPorCodigo(this.visao.getListaProdutoCaixa());
		}

		return this.visao.getListaProdutoCaixa();
	}

	/**
	 * <p>
	 * Método responsável por formatar números nas tabelas com três digitos.
	 * </p>
	 */
	public String showFormattedNumberColumn(final Object value, final String format) {
		try {
			if (value != null) {
				return String.format(format, Integer.parseInt(value.toString()));
			} else {
				return "";
			}
		} catch (final NumberFormatException | IllegalFormatException e) {
			LogCefUtil.error(e);
			return value.toString();
		}

	}

	/**
	 * <p>
	 * Método responsável por formatar números nas tabelas com três digitos.
	 * </p>
	 */
	public String showFormattedNumberColumn(final Object value) {
		return this.showFormattedNumberColumn(value, "%03d");
	}

	/**
	 * <p>
	 * Método responsável por formatar números nas tabelas com quatro digitos.
	 * </p>
	 */
	public String showFormattedNumberColumn4Digits(final Object value) {
		return this.showFormattedNumberColumn(value, "%04d");
	}

	public String getStrModalidadeFormatadaFiltro() {
		return strModalidadeFormatadaFiltro;
	}

	public void setStrModalidadeFormatadaFiltro(String strModalidadeFormatadaFiltro) {
		this.strModalidadeFormatadaFiltro = strModalidadeFormatadaFiltro;
	}

	public String getStrModalidadeFormatada() {
		return this.strModalidadeFormatada;
	}

	public void setStrModalidadeFormatada(final String strModalidadeFormatada) {
		this.strModalidadeFormatada = strModalidadeFormatada;
	}

	/**
	 * <p>
	 * Método executado quando perde o foco do campo de código de Modalidade.
	 * </p>
	 * 
	 * @param evento
	 */
	public void getSelectModalidadeFiltro() {
		if (!this.getStrModalidadeFormatadaFiltro().isEmpty()) {
			this.strModalidadeFormatadaFiltro = this
					.showFormattedNumberColumn4Digits(this.getStrModalidadeFormatadaFiltro());
			final Integer nuModalidade = Integer.parseInt(this.getStrModalidadeFormatadaFiltro());
			this.getVisao().setNuModalidadeSelecionadaFiltro(nuModalidade);
		} else {
			this.getVisao().setNuModalidadeSelecionadaFiltro(null);
		}
	}
	
	public void removeItemListaAcessorias(UnselectEvent event) {
		garantiasAcessoriasExcluir.add((Garantia)event.getObject());
	}
	
	public void removeItemListaCaixa(UnselectEvent event) {
		garantiasCaixaExcluir.add((ViewProdutoSiico)event.getObject());
	}
	
	public void removeItemListaObrigatorias(UnselectEvent event) {
		garantiasObrigatoriasExcluir.add((Garantia)event.getObject());
	}

	/**
	 * <p>
	 * Método executado quando perde o foco do campo de código de Modalidade.
	 * </p>
	 * 
	 * @param evento
	 */
	public void getSelectModalidade() {
		this.limparListasSelecionadas();
		this.limparListasCaixa();

		if (!this.getStrModalidadeFormatada().isEmpty()) {
			this.strModalidadeFormatada = this.showFormattedNumberColumn4Digits(this.getStrModalidadeFormatada());
			final Integer nuModalidade = Integer.parseInt(this.getStrModalidadeFormatada());
			this.getVisao().setNuModalidadeSelecionada(nuModalidade);

			this.carregarDadosBanco();
		} else {
			this.getVisao().setNuModalidadeSelecionada(null);
		}
	}

	private void buscarGarantiasFiltroInicio() {
		if (this.visao.getNuProdutoSelecionadoFiltro() == null
				&& this.visao.getNuModalidadeSelecionadaFiltro() == null) {
			this.visao.setListaProdutoModadalideVOFiltro(
					garantiaProdutoService.listarProdutoModalidadeTodasGarantias(null));
		}
	}

	private void buscarGarantiasFiltro() {
		
		this.visao.setListaProdutoModadalideVOFiltro(garantiaProdutoService
				.listarProdutoModalidadeTodasGarantias(this.visao.getProdutoModalidadeVOFiltro()));
	}

	private void buscarGarantiasTelaEdicao() {
		GarantiaProduto garantiaProduto = new GarantiaProduto(null, this.visao.getNuProdutoSelecionado(),
				this.visao.getNuModalidadeSelecionada());
		GarantiaCaixaProduto garantiaCaixaProduto = new GarantiaCaixaProduto(null, this.visao.getNuProdutoSelecionado(),
				this.visao.getNuModalidadeSelecionada());

		this.visao.setListaGarantiaBacenObrigatorias(
				garantiaProdutoService.listarGarantiasBacenPorProduto(garantiaProduto, true));
		this.visao.setListaGarantiaBacenAcessorias(
				garantiaProdutoService.listarGarantiasBacenPorProduto(garantiaProduto, false));
		this.visao.setListaProdutoCaixaBD(
				garantiaCaixaProdutoService.listarGarantiasCaixaPorProduto(garantiaCaixaProduto));
	}

	/**
	 * <p>
	 * Método responsável por filtrar a lista de garantias.
	 * <p>
	 *
	 * @author Mábio Barbosa
	 */
	public void filtrar() {
		onSelectProdutoFiltro();

		// Se NÃO informar o produto e a modalidade buscar sem filtro.
		if (this.visao.getNuProdutoSelecionadoFiltro() == null
				&& this.visao.getNuModalidadeSelecionadaFiltro() == null) {
			this.buscarGarantiasFiltroInicio();
		} else {
			this.buscarGarantiasFiltro();
		}
	}

	/**
	 * <p>
	 * Método responsável por abrir a página de inclusão.
	 * <p>
	 *
	 * @return String
	 * @author Mábio Barbosa
	 */
	public String abrirInclusao() {
		this.getVisao().setEntidade(new GarantiaProduto());
		this.visao.limpar();
		this.visao.setTelaEdicao(false);

		return this.getTelaEdicao();
	}

	/**
	 * <p>
	 * Método responsável por abrir a página de alteração.
	 * <p>
	 *
	 * @param garantiaProdutoVO
	 * @return String
	 * @author Mábio Barbosa
	 */
	public String abrirAlteracao(ProdutoModalidadeVO garantiaProdutoVO) {
		// Setando os dados para edição
		this.visao.setTelaEdicao(true);
		this.visao.setNuProdutoSelecionado(garantiaProdutoVO.getNuProduto());
		this.visao.setNuModalidadeSelecionada(garantiaProdutoVO.getNuModalidade());
		this.visao.setAutoCompleteProduto(garantiaProdutoVO.getNuProduto() + " - " + garantiaProdutoVO.getNoProduto());
		this.setStrModalidadeFormatada(this.showFormattedNumberColumn4Digits(garantiaProdutoVO.getNuModalidade()));

		// Buscando dados
		this.carregarDadosBanco();

		return this.getTelaEdicao();
	}
	
	public List<Garantia> getGarantiasDisponiveis() {
		return garantiasDisponiveis;
	}

	public void setGarantiasDisponiveis(List<Garantia> garantiasDisponiveis) {
		this.garantiasDisponiveis = garantiasDisponiveis;
	}

	public List<Garantia> getGarantiasIncluidas() {
		return garantiasIncluidas;
	}

	public void setGarantiasIncluidas(List<Garantia> garantiasIncluidas) {
		this.garantiasIncluidas = garantiasIncluidas;
	}

	public List<Garantia> getGarantiasSelecionadas() {
		return garantiasSelecionadas;
	}

	public void setGarantiasSelecionadas(List<Garantia> garantiasSelecionadas) {
		this.garantiasSelecionadas = garantiasSelecionadas;
	}

	public List<Garantia> getGarantiasDisponiveisAcessorias() {
		return garantiasDisponiveisAcessorias;
	}

	public void setGarantiasDisponiveisAcessorias(List<Garantia> garantiasDisponiveisAcessorias) {
		this.garantiasDisponiveisAcessorias = garantiasDisponiveisAcessorias;
	}

	public List<Garantia> getGarantiasIncluidasAcessorias() {
		return garantiasIncluidasAcessorias;
	}

	public void setGarantiasIncluidasAcessorias(List<Garantia> garantiasIncluidasAcessorias) {
		this.garantiasIncluidasAcessorias = garantiasIncluidasAcessorias;
	}

	public List<Garantia> getGarantiasSelecionadasAcessorias() {
		return garantiasSelecionadasAcessorias;
	}

	public void setGarantiasSelecionadasAcessorias(List<Garantia> garantiasSelecionadasAcessorias) {
		this.garantiasSelecionadasAcessorias = garantiasSelecionadasAcessorias;
	}

	public List<ViewProdutoSiico> getGarantiasDisponiveisCaixa() {
		return garantiasDisponiveisCaixa;
	}

	public void setGarantiasDisponiveisCaixa(List<ViewProdutoSiico> garantiasDisponiveisCaixa) {
		this.garantiasDisponiveisCaixa = garantiasDisponiveisCaixa;
	}

	public List<ViewProdutoSiico> getGarantiasIncluidasCaixa() {
		return garantiasIncluidasCaixa;
	}

	public void setGarantiasIncluidasCaixa(List<ViewProdutoSiico> garantiasIncluidasCaixa) {
		this.garantiasIncluidasCaixa = garantiasIncluidasCaixa;
	}

	public List<ViewProdutoSiico> getGarantiasSelecionadasCaixa() {
		return garantiasSelecionadasCaixa;
	}

	public void setGarantiasSelecionadasCaixa(List<ViewProdutoSiico> garantiasSelecionadasCaixa) {
		this.garantiasSelecionadasCaixa = garantiasSelecionadasCaixa;
	}

	/** FIM - Métodos picklist */

	private void populaListasIncluir() {
		this.visao.getGarantiasProduto().clear();
		this.visao.getGarantiasCaixaProduto().clear();

		this.populaGarantiaProduto(garantiasIncluidas, this.visao.getGarantiasProduto(), true);
		this.populaGarantiaProduto(garantiasIncluidasAcessorias, this.visao.getGarantiasProduto(), false);
		this.populaGarantiaCaixaProduto(garantiasIncluidasCaixa, this.visao.getGarantiasCaixaProduto());
	}

	private void populaListasExcluir() {
		this.visao.getGarantiasProdutoExcluir().clear();
		this.visao.getGarantiasCaixaProdutoExcluir().clear();

		this.populaGarantiaProduto(garantiasObrigatoriasExcluir, this.visao.getGarantiasProdutoExcluir(), true);
		this.populaGarantiaProduto(garantiasAcessoriasExcluir, this.visao.getGarantiasProdutoExcluir(), false);
		this.populaGarantiaCaixaProduto(garantiasCaixaExcluir, this.visao.getGarantiasCaixaProdutoExcluir());
	}

	private void populaGarantiaProduto(List<Garantia> lista, List<GarantiaProduto> listaGarProd,
			boolean isObrigatoria) {
		if(lista != null) {
			for (Garantia garantia : lista) {
				listaGarProd.add(this.populaGarantiaProduto(garantia, isObrigatoria));
			}
		}
	}

	private void populaGarantiaCaixaProduto(List<ViewProdutoSiico> lista,
			List<GarantiaCaixaProduto> listaGarCaixaProd) {
		if(lista != null && !lista.isEmpty()) {
			for (ViewProdutoSiico prodSiico : lista) {
				listaGarCaixaProd.add(this.populaGarantiaCaixaProduto(prodSiico));
			}
		}
	}

	private GarantiaProduto populaGarantiaProduto(Garantia garantia, boolean isObrigatoria) {
		Collection<Garantia> garantias = this.garantiaService.filtrar(garantia);
		if(garantias != null && !garantias.isEmpty()) {
			Garantia garantiaCompleta = garantias.iterator().next();
			GarantiaProduto garantiaProduto = new GarantiaProduto(garantiaCompleta.getNuGarantia(),
					this.visao.getNuProdutoSelecionado(), this.visao.getNuModalidadeSelecionada());
			garantiaProduto.setIcGarantiaObrigatoria(isObrigatoria);
			
			return garantiaProduto;
		}
		return null;
	}

	private GarantiaCaixaProduto populaGarantiaCaixaProduto(ViewProdutoSiico prodSiico) {
		return new GarantiaCaixaProduto(prodSiico.getProdutoSiicoID().getNuProduto(), this.visao.getNuProdutoSelecionado(),
				this.visao.getNuModalidadeSelecionada());
	}

	private void preencheGarantiasDoBancoNoPickList() {
		// Consulta garantias
		this.buscarGarantiasTelaEdicao();

		// Popula listas
		this.preencheGarantiasBacenObrigatorias();
		this.preencheGarantiasBacenAcessorias();
		this.preencheGarantiasCaixa();

		// Ações após listas populadas
		this.removerItensJaAdicionados();
		this.ordenarListas();
	}

	private void preencheGarantiasBacenObrigatorias() {
		garantiasSelecionadas.addAll(this.visao.getListaGarantiaBacenObrigatorias());
		garantiasIncluidas.addAll(this.visao.getListaGarantiaBacenObrigatorias());
	}

	private void preencheGarantiasBacenAcessorias() {
		garantiasSelecionadasAcessorias.addAll(this.visao.getListaGarantiaBacenAcessorias());
		garantiasIncluidasAcessorias.addAll(this.visao.getListaGarantiaBacenAcessorias());
	}

	private void preencheGarantiasCaixa() {
		garantiasIncluidasCaixa.addAll(this.visao.getListaProdutoCaixaBD());
		garantiasSelecionadasCaixa.addAll(this.visao.getListaProdutoCaixaBD());
	}

	private void removerItensJaAdicionados() {
		garantiasDisponiveis.removeAll(garantiasSelecionadas);
		garantiasDisponiveisAcessorias.removeAll(garantiasSelecionadasAcessorias);
		this.removerItemGarantiaCaixaDaLista();
	}

	private void removerItemGarantiaCaixaDaLista() {
		// Percorre os itens selecionados
		for (ViewProdutoSiico itemSel : garantiasSelecionadasCaixa) {

			// Caso tenha itens selecionados, remover os equivalentes na parte
			// Disponível.
			for (ViewProdutoSiico itemDispon : garantiasDisponiveisCaixa) {
				if (itemSel.getProdutoSiicoID().getNuProduto().equals(itemDispon.getProdutoSiicoID().getNuProduto())) {
					garantiasDisponiveisCaixa.remove(itemDispon);
					break;
				}
			}
		}
	}

	private void limparListasSelecionadas() {
		garantiasSelecionadas.clear();
		garantiasSelecionadasAcessorias.clear();

		garantiasIncluidas.clear();
		garantiasIncluidasAcessorias.clear();
	}

	private void limparListasCaixa() {
		garantiasIncluidasCaixa.clear();
		garantiasSelecionadasCaixa.clear();
	}

	private boolean validaSalvar() {
		if (this.visao.getNuProdutoSelecionado() == null || this.visao.getNuModalidadeSelecionada() == null) {
			super.adicionaMensagemDeErro(GarantiaProdutoMB.SELECIONAR_PRODUTO_MODALIDADE);
			return false;

		} else if (this.garantiasIncluidas == null || this.garantiasIncluidas.isEmpty()) {
			super.adicionaMensagemDeErro(GarantiaProdutoMB.NENHUM_REGISTRO);
			return false;

		} else if (isExisteParametrizacaoProduto()) {
			super.adicionaMensagemDeErro(GarantiaProdutoMB.EXISTE_PARAMETRIZACAO_SALVAR);
			return false;
		} else if (!validarGarantiasBacenAcessorias(this.garantiasIncluidasAcessorias, this.garantiasIncluidas)) {
        	    super.adicionaMensagemDeErro(GarantiaProdutoMB.GARANTIA_BACEN_UTILIZADA);
        	    return false;
        	}

		return true;
	}

	private boolean validarGarantiasBacenAcessorias(List<Garantia> garantiasBacenAcessorias, List<Garantia> garantiasBacenObrigatorias) {
	    boolean retorno = true;
	    if (garantiasBacenAcessorias != null && !garantiasBacenAcessorias.isEmpty()) {
		for (Garantia item : garantiasBacenAcessorias) {
		    if (garantiasBacenObrigatorias.contains(item) ) {
			retorno = false;
			break;
		    }
		}
		
	    }
	    return retorno;
	}

	private boolean isExisteParametrizacaoProduto() {
		return this.garantiaProdutoService.isExisteParametrizacaoProduto(this.visao.getProdutoModalidadeVO(),
				this.visao.getGarantiasProdutoExcluir(), this.visao.getGarantiasCaixaProdutoExcluir());
	}

	/**
	 * <p>
	 * Método responsável por salvar a garantia.
	 * <p>
	 *
	 * @author Mábio Barbosa
	 */
	public void salvar() {
		try {
			this.populaListasIncluir();
			this.populaListasExcluir();

			if (this.validaSalvar()) {
				this.garantiaProdutoService.salvarItensProdutoCredito(this.visao.getProdutoModalidadeVO(),
						this.visao.getGarantiasProduto(), this.visao.getGarantiasCaixaProduto(),
						this.visao.getGarantiasProdutoExcluir(), this.visao.getGarantiasCaixaProdutoExcluir());

				RequestContext.getCurrentInstance().execute("PF('modalSucesso').show();");

				// Após salvar, atualizar a tela de consulta.
				this.filtrar();
			}
		} catch (Exception e) {
			super.adicionaMensagemDeErro(GarantiaProdutoMB.ERRO_OPERACAO);
			LogCefUtil.error(e);
		}
	}

	/**
	 * <p>
	 * Método responsável por excluir os vinculos entre as garantias e o
	 * produto/modalidade.
	 * <p>
	 *
	 * @return String
	 * @author Mábio Barbosa
	 */
	public String excluir() {
		try {
			if (this.garantiaProdutoService
					.isExisteParametrizacaoProduto(this.getVisao().getProdutoModalidadeVOExcluir())) {
				super.adicionaMensagemDeErro(GarantiaProdutoMB.EXISTE_PARAMETRIZACAO);

			} else {
				this.garantiaProdutoService.excluir(this.getVisao().getProdutoModalidadeVOExcluir());
				super.adicionaMensagemDeSucesso(GarantiaProdutoMB.OPERACAO_SUCESSO);

				this.carregar();
			}

		} catch (Exception e) {
			super.adicionaMensagemDeErro(GarantiaProdutoMB.ERRO_OPERACAO);
			LogCefUtil.error(e);
		}

		return super.MESMA_TELA;
	}

	private void ordenaPorCodigo(List<Garantia> listaGarantias) {
		if (CollectionUtils.isNotEmpty(listaGarantias)) {
			Collections.sort(listaGarantias, new Comparator<Garantia>() {
				@Override
				public int compare(Garantia g1, Garantia g2) {
					String coOperacaoG1 = g1.getCoOperacao().replaceAll("[^\\d]", "");
					String coOperacaoG2 = g2.getCoOperacao().replaceAll("[^\\d]", "");
					if(coOperacaoG1 != null && !coOperacaoG1.isEmpty() && coOperacaoG2 != null && !coOperacaoG2.isEmpty()) {
						Integer coOpe1 = Integer.parseInt(coOperacaoG1);
						Integer coOpe2 = Integer.parseInt(coOperacaoG2);
						return coOpe1.compareTo(coOpe2);
						
					}
					return -1;

				}
			});
		}
	}

	private void ordenaGarantiaCaixaPorCodigo(List<ViewProdutoSiico> listaProdutoSiico) {
		if (CollectionUtils.isNotEmpty(listaProdutoSiico)) {
			Collections.sort(listaProdutoSiico, new Comparator<ViewProdutoSiico>() {
				@Override
				public int compare(ViewProdutoSiico v1, ViewProdutoSiico v2) {
					return v1.getProdutoSiicoID().getNuProduto().compareTo(v2.getProdutoSiicoID().getNuProduto());
				}
			});
		}
	}

	private void ordenarListas() {
		this.ordenarListasGarantiasObrigatorias();
		this.ordenarListasGarantiasAcessorias();
		this.ordenarListasGarantiasCaixa();
	}

	private void ordenarListasGarantiasObrigatorias() {
		this.ordenaPorCodigo(garantiasDisponiveis);
		this.ordenaPorCodigo(garantiasSelecionadas);
		this.ordenaPorCodigo(garantiasIncluidas);
	}

	private void ordenarListasGarantiasAcessorias() {
		this.ordenaPorCodigo(garantiasDisponiveisAcessorias);
		this.ordenaPorCodigo(garantiasSelecionadasAcessorias);
		this.ordenaPorCodigo(garantiasIncluidasAcessorias);
	}

	private void ordenarListasGarantiasCaixa() {
		this.ordenaGarantiaCaixaPorCodigo(garantiasDisponiveisCaixa);
		this.ordenaGarantiaCaixaPorCodigo(garantiasSelecionadasCaixa);
		this.ordenaGarantiaCaixaPorCodigo(garantiasIncluidasCaixa);
	}

	private List<Garantia> listarAtivos() {
		List<Garantia> listaGarantias = (List<Garantia>) this.garantiaService.listarAtivos();

		this.ordenaPorCodigo(listaGarantias);

		return listaGarantias;
	}
	
	 

	private List<Garantia> listarAtivosPorNome(String parametro) {
	    return (List<Garantia>) this.garantiaService.listarAtivosPorNome(parametro);
	}
	
	public List<Garantia> listarBacenPorNome(String parametro) {
	    List<Garantia> listaGarantias = listarAtivosPorNome(parametro);
	    this.ordenaPorCodigo(listaGarantias);
	    return listaGarantias;
	}

	public List<Garantia> getListModelGarantiasSelecionada() {
		return listModelGarantiasSelecionada;
	}

	public void setListModelGarantiasSelecionada(List<Garantia> listModelGarantiasSelecionada) {
		this.listModelGarantiasSelecionada = listModelGarantiasSelecionada;
	}

}
