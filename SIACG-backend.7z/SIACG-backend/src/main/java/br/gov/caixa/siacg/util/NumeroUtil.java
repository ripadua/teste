/*
 * Copyright (c) 2018 Caixa Econômica Federal. Todos os direitos
 * reservados.
 *
 * Caixa Econômica Federal - SIACG
 *
 * Este software foi desenvolvido sob demanda da CAIXA e está
 * protegido por leis de direitos autorais e tratados internacionais. As
 * condições de cópia e utilização do total ou partes dependem de autorização da
 * empresa. Cópias não são permitidas sem expressa autorização. Não pode ser
 * comercializado ou utilizado para propósitos particulares.
 *
 * Uso exclusivo da Caixa Econômica Federal. A reprodução ou distribuição não
 * autorizada deste programa ou de parte dele, resultará em punições civis e
 * criminais e os infratores incorrem em sanções previstas na legislação em
 * vigor.
 *
 * Histórico do Subversion:
 *
 * LastChangedRevision: $Revision$
 * LastChangedBy: $Author$
 * LastChangedDate: $Date$
 *
 * HeadURL: $HeadURL$
 *
 */	
package br.gov.caixa.siacg.util;

import java.lang.reflect.InvocationTargetException;
import java.math.BigDecimal;


/**
 * <p>NumeroUtil</p>
 * <p>Descrição: Classe utilitária de Números</p>
 * <br><b>Empresa:</b> Cef - Caixa Econômica Federal
 *
 * @author douglas.lopes
 * @version 1.0
 */	
public class NumeroUtil {

	private NumeroUtil() {
		 throw new IllegalStateException("Classe de Utilidade");
	}
	
    /**
     * <p> Método responsável por converter uma String em Long <p>
     *
     * @param str
     * @return Retorna nulo caso ocorra exceção.
     * @author douglas.lopes
     */
    public static Long parseLong(String str) {
        try {
            return Long.parseLong(str);
        }catch (NumberFormatException e) {
            return null;
        }
    }
    
    /**
     * 
     * <p>Método responsável por</p>.
     *
     * @author p575337
     *
     * @param str
     * @return Integer
     */
    public static Integer parseInt(String str) {
        try {
            return Integer.parseInt(str);
        }catch (NumberFormatException e) {
            return null;
        }
    }
    /**
     * 
     * <p>Método responsável por</p>.
     *
     * @author p575337
     *
     * @param str texto a converter
     * @return BigDecimal
     */
    public static BigDecimal parseBigDecimal(String str) {
    	try {
    		return new BigDecimal(str);
        }catch (NumberFormatException e) {
            return null;
        }
    }
    /**
     * 
     * <p>Método responsável por</p>.
     *
     * @author p575337
     *
     * @param str
     * @return Short
     */
    public static Short parseShort(String str) {
    	try {
    		return Short.parseShort(str);
        }catch (NumberFormatException e) {
            return null;
        }
    }

    /**
     * <p> Método responsável por converter um String em um objeto do
     * tipo numérico. <p>
     *
     * @param klazz Espera-se uma classe do tipo numérica
     * @param arg String
     * @return
     * @author douglas.lopes
     */
    public static <T> T converterStringEmNumero(Class<T> klazz, String arg) {
        Exception cause = null;
        T ret = null;
        try {
            ret = klazz.cast(
                klazz.getDeclaredMethod("valueOf", String.class)
                .invoke(null, arg)
            );
        } catch (NoSuchMethodException | IllegalAccessException | InvocationTargetException e) {
            cause = e;
        } 
        if (cause == null) {
            return ret;
        } else {
            return null;
        }
    }
    /**
     * Verifica se o número é nulo ou está zerado.
     * @param numero a ser avaliado
     * @return true se for 0 or null
     */
    public static boolean isNuloOuZero(BigDecimal numero) {
    	return numero == null || BigDecimal.ZERO.compareTo(numero) == 0;
    }
    
    /**
     * <p>Método responsável por remover todos os caracteres que não seja digitos.</p>.
     *
     * @author p575337
     *
     * @param texto a ser excluido
     * @return Somente os números da String
     */
    public static String somenteNumeros(final String texto) {
    	String retorno =  "";
    	if (texto != null) {
    		retorno = texto.replaceAll("\\D+","");
		}
    	return retorno;
    }
}