/*
 * Copyright (c) 2019 Caixa Econômica Federal. Todos os direitos
 * reservados.
 *
 * Caixa Econômica Federal - SIACG - Sistema de Crédito Rural
 *
 * Este software foi desenvolvido sob demanda da CAIXA e está
 * protegido por leis de direitos autorais e tratados internacionais. As
 * condições de cópia e utilização do todo ou partes dependem de autorização da
 * empresa. Cópias não são permitidas sem expressa autorização. Não pode ser
 * comercializado ou utilizado para propósitos particulares.
 *
 * Uso exclusivo da Caixa Econômica Federal. A reprodução ou distribuição não
 * autorizada deste programa ou de parte dele, resultará em punições civis e
 * criminais e os infratores incorrem em sanções previstas na legislação em
 * vigor.
 *
 * Histórico do TFS:
 *
 * LastChangedRevision: $Revision$
 * LastChangedBy: $Author$
 * LastChangedDate: $Date$
 *
 * HeadURL: $HeadURL$
 *
 */
package br.gov.caixa.siacg.view.form;

import java.util.ArrayList;
import java.util.List;

import br.gov.caixa.siacg.model.domain.Despesa;
import br.gov.caixa.siacg.model.vo.DocumentoLancamentoEventoVO;

/**
 * <p>
 * DocumentoLancamentoEventoVisao
 * </p>
 * <p>
 * Descrição: Classe responsável por armazenar os dados da visão do caso de uso
 * de <code>Consulta de DLE</code>.
 * </p>
 * 
 * <b>Empresa:</b> Cef - Caixa Econômica Federal
 *
 * @author Ludemeula Fernandes de Sá
 * @version 1.0
 */
public class DocumentoLancamentoEventoVisao extends TemplateVisao<Despesa> {

	private static final long serialVersionUID = 8582680683428641735L;

	private List<DocumentoLancamentoEventoVO> dles;

	/**
	 * <p>
	 * Retorna o valor do atributo dles
	 * </p>
	 * .
	 *
	 * @return dles
	 */
	public List<DocumentoLancamentoEventoVO> getDles() {
		if (dles == null) {
			setDles(new ArrayList<DocumentoLancamentoEventoVO>());
		}
		
		return this.dles;
	}

	/**
	 * <p>
	 * Define o valor do atributo dles
	 * </p>
	 * .
	 *
	 * @param dles
	 *            valor a ser atribuído
	 */
	public void setDles(List<DocumentoLancamentoEventoVO> dles) {
		this.dles = dles;
	}
}