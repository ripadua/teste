package br.gov.caixa.siacg.view.mb;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;

import javax.ejb.EJB;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;
import javax.inject.Inject;

import org.apache.commons.lang.StringUtils;

import br.gov.caixa.pedesgo.arquitetura.controlador.AbstractBean;
import br.gov.caixa.pedesgo.arquitetura.controlador.ManutencaoBean;
import br.gov.caixa.pedesgo.arquitetura.dao.DAO;
import br.gov.caixa.pedesgo.arquitetura.enums.EnumExtensaoArquivo;
import br.gov.caixa.pedesgo.arquitetura.relatorio.UtilRelatorio;
import br.gov.caixa.pedesgo.arquitetura.servico.Servico;
import br.gov.caixa.pedesgo.arquitetura.util.LogCefUtil;
import br.gov.caixa.siacg.model.domain.Titulo;
import br.gov.caixa.siacg.pagination.TituloLazyModel;
import br.gov.caixa.siacg.service.TituloService;
import br.gov.caixa.siacg.view.form.TituloVisao;

/**
 * <p>
 * TituloMB.
 * </p>
 * <p>
 * Descrição: Bean Gerenciável para a entidade Titulo.
 * </p>
 * <br>
 * <b>Empresa:</b> Cef - Caixa Econômica Federal
 *
 * @author Brunno Antunes
 * @version 1.0
 */
@ManagedBean
@SessionScoped
public class TituloMB extends ManutencaoBean<Titulo> {

    private static final long serialVersionUID = -4248095391849635745L;
    private static final String PREFIXO_CASO_USO = "titulos";
    private static final String DIRETORIO_PAGINAS = "/pages/";
    public static final String NOME_MANAGED_BEAN = "TituloMB";
    public static final String EL_MANAGED_BEAN = "#{tituloMB}";
    private static final String VAR_RESOURCE_BUNDLE = "msgApp";
    
    private static final String PAGINA_CONSULTA_TITULO = "/pages/titulos/consulta.xhtml?faces-redirect=true";
	private static final String NOME_RELATORIO_TITULOS = "Titulos";
	
    private transient TituloVisao visao;

    @EJB
    private transient TituloService tituloService;
    
    @Inject
    private TituloLazyModel consulta;
    
	@Override
	protected String getPrefixoCasoDeUso() {
		 return TituloMB.PREFIXO_CASO_USO;
	}

	@Override
	public <S extends Servico<Titulo, DAO<Titulo>>> S getService() {
		return null;
	}
	
	@Override
	public TituloVisao getVisao() {
		 if (this.visao == null) {
	            this.visao = new TituloVisao();
	        }
	        return this.visao;
	}
	
	public void limparFiltros() {
		getConsulta().limparFiltro();
	}
	
	/**
     * @see br.gov.caixa.pedesgo.arquitetura.controlador.AbstractBean#getNomeVarResourceBundle()
     */
    @Override
    protected String getNomeVarResourceBundle() {
        return TituloMB.VAR_RESOURCE_BUNDLE;
    }
    
    /**
     * @see br.gov.caixa.pedesgo.arquitetura.controlador.AbstractBean#getTelaConsulta()
     */
    @Override
    public String getTelaConsulta() {
        return TituloMB.DIRETORIO_PAGINAS.concat(this.getPrefixoCasoDeUso()).concat(AbstractBean.SUFIXO_TELA_CONSULTA);
    }
    
    public TituloLazyModel getConsulta() {
    	if (this.consulta == null) {
    		this.consulta = new TituloLazyModel();
    	}

    	return this.consulta;
    }

    public void setConsulta(TituloLazyModel consulta) {
    	this.consulta = consulta;}
	
	/**
     * <p>
     * Método responsável por filtrar a lista de titulos.
     * <p>
     *
     * @author Brunno Antunes
     */
	public String filtrar() {
		if (StringUtils.isNotEmpty(getConsulta().getFiltro().getIcSituacaoDuplicata())) {
			if (StringUtils.isNotEmpty(getConsulta().getFiltro().getCnpjCedente())
					|| StringUtils.isNotEmpty(getConsulta().getFiltro().getCpfCnpjSacado())
					|| StringUtils.isNotEmpty(getConsulta().getFiltro().getNossoNumero())
					|| StringUtils.isNotEmpty(getConsulta().getFiltro().getNuCendente())) {
				return TituloMB.PAGINA_CONSULTA_TITULO;
			}
			super.adicionaMensagemDeAlerta("MA084");
			return "";
		} else {
			super.adicionaMensagemDeAlerta("MA084");
			return "";
		}
	}
	
	/**
	 * <p>
	 * Método responsável por exportar xls da tela de {@link TituloService}
	 * <p>
	 */
	public void exportarCSVTituloParametrizado() {
		InputStream inputStream = null;
		try {
			final File arquivo = tituloService.titulos(getConsulta().getFiltro(), getConsulta().getRowCount());

			inputStream = new FileInputStream(arquivo);

			final byte[] arquivo2 = new byte[(int) arquivo.length()];

			inputStream.read(arquivo2, 0, arquivo2.length);

			UtilRelatorio.getInstancia().adicionarArquivoCessao(arquivo2, NOME_RELATORIO_TITULOS, EnumExtensaoArquivo.CSV.getExtensao());
		} catch (final Exception e) {
			LogCefUtil.error("Não foi possivel gerar o CSV: " + e.getMessage());
			LogCefUtil.error(e);
		} finally {
			try {
				if (inputStream != null) {
					inputStream.close();
				}
			} catch (IOException e1) {
				LogCefUtil.error("Não foi possivel gerar o CSV " + e1.getCause());
				LogCefUtil.error(e1);
			}
		}
	}

	public boolean isPodeGerarRelatorio() {
		return getConsulta().getRowCount() > 0;
	}
}
