package br.gov.caixa.siacg.strategy.impl;

import java.math.BigDecimal;

import javax.ejb.EJB;
import javax.ejb.Stateless;

import br.gov.caixa.siacg.model.vo.ParametrosCalculoGarantiaVO;
import br.gov.caixa.siacg.model.vo.RelatorioAnaliseContratoVO;
import br.gov.caixa.siacg.service.GarantiaHipotecaService;
import br.gov.caixa.siacg.strategy.CalculoGarantia;

/**
 * 
 * <p>
 * CalculoGarantiaEmpreendimentoHipoteca
 * </p>
 *
 * <p>
 * Descrição: Descrição do tipo
 * </p>
 *
 * <br>
 * <b>Empresa:</b> Cef - Caixa Econômica Federal
 *
 *
 * @author p566506
 *
 * @version 1.0
 */
@Stateless
public class CalculoGarantiaEmpreendimentoHipoteca implements CalculoGarantia {

    private static final long serialVersionUID = 7170040531431287763L;

    @EJB
    private GarantiaHipotecaService garantiaHipotecaService;

    @Override
    public RelatorioAnaliseContratoVO calcular(ParametrosCalculoGarantiaVO parametrosCalculo, RelatorioAnaliseContratoVO relatorio) {
	if (relatorio == null) {
	    relatorio = new RelatorioAnaliseContratoVO();
	}

	if (parametrosCalculo == null || parametrosCalculo.getGarantiaContrato() == null
		|| parametrosCalculo.getGarantiaContrato().getContrato() == null
		|| parametrosCalculo.getGarantiaContrato().getContrato().getNuContrato() == null) {
	    relatorio.setValorApurado(BigDecimal.ZERO);
	    return relatorio;
	}
	return this.garantiaHipotecaService.calcular(parametrosCalculo, relatorio);
    }
}