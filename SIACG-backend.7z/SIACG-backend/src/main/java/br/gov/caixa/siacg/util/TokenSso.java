package br.gov.caixa.siacg.util;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.URL;

import javax.ws.rs.core.Response.Status;

import br.gov.caixa.pedesgo.arquitetura.util.UtilString;
import br.gov.caixa.pedesgo.arquitetura.util.UtilJson;
import br.gov.caixa.pedesgo.arquitetura.util.UtilWS;
import br.gov.caixa.siacg.commons.AppConstant;

/**
 * <p>TokenSso</p>
 *
 * <p>Descrição: Descrição do tipo</p>
 *
 * <br><b>Empresa:</b> Cef - Caixa Econômica Federal
 *
 *
 * @author p575337
 *
 * @version 1.0
 */
public class TokenSso {

    /**
     * <p>Método responsável por obter ServiceTokenSSO</p>.
     *
     * @author p575337
     *
     * @return
     */
    public String getServiceTokenSSO() {
		String url = System.getProperty("url_sso_intranet", "https://login.des.caixa")+"/auth/realms/intranet/protocol/openid-connect/token";
		String clientId = System.getProperty(AppConstant.PROPRIEDADE_CLI_SER_ACG, "cli-ser-acg");
		String clientSecret = System.getProperty(AppConstant.PROPRIEDADE_TOKEN_SSO, "9e27458c-942d-4a4a-8199-72d0610530e9");
	
		final StringBuilder sb = new StringBuilder("grant_type=client_credentials");
		sb.append("&client_id=").append(clientId).append("&client_secret=").append(clientSecret);
		try {
		    String consumir = this.consumirServico(url, sb.toString());
		    if (UtilString.isVazio(consumir)) {
			return Status.SERVICE_UNAVAILABLE.getStatusCode()+" Erro de comunicação com o SSO";
		    }
		    return UtilJson.consultarAtributo(consumir, "access_token");
		} catch (Exception e) {
		    LogCEF.error(e);
		    return Status.INTERNAL_SERVER_ERROR.getStatusCode() + "Erro ao converter objeto para ser enviado ao serivço";
		}
    }
    
    public String getServiceTokenSSOSifec() {
    	String url = System.getProperty(AppConstant.URL_SSO_INTERNET, "https://logindes.caixa.gov.br")+"/auth/realms/internet/protocol/openid-connect/token";
    	String clientId = System.getProperty(AppConstant.PROPRIEDADE_CLI_SER_ACG, "cli-ser-acg");
    	String clientSecret = System.getProperty(AppConstant.PROPRIEDADE_TOKEN_SSO_SIFEC, "39110e42-8a33-49dd-a6c4-3c89fc3bfa91");
    	
    	final StringBuilder sb = new StringBuilder("grant_type=client_credentials");
    	sb.append("&client_id=").append(clientId).append("&client_secret=").append(clientSecret);
    	try {
    		String consumir = this.consumirServico(url, sb.toString());
    		if (UtilString.isVazio(consumir)) {
    			return Status.SERVICE_UNAVAILABLE.getStatusCode()+" Erro de comunicação com o SSO";
    		}
    		return UtilJson.consultarAtributo(consumir, "access_token");
    	} catch (Exception e) {
    		LogCEF.error(e);
    		return Status.INTERNAL_SERVER_ERROR.getStatusCode() + "Erro ao converter objeto para ser enviado ao serivço";
    	}
    }

    private String consumirServico(final String urlWebService, final String parametros) {
		String retorno = null;
		try {
		    final URL url = new URL(urlWebService);
		    final HttpURLConnection connection = (HttpURLConnection) url.openConnection();
		    connection.setDoOutput(true);
		    connection.setRequestMethod("POST");
		    connection.setRequestProperty("Content-Type", "application/x-www-form-urlencoded");
		    connection.setConnectTimeout(30000);
		    connection.setReadTimeout(30000);
		    connection.addRequestProperty("User-Agent", "Mozilla/5.0 (compatible; MSIE 6.0; Windows NT 5.0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/62.0.3202.94 Safari/537.36");
		    final OutputStreamWriter out = new OutputStreamWriter(connection.getOutputStream(), UtilWS.UTF_8);
		    out.write(parametros);
		    out.close();
		    final BufferedReader in = new BufferedReader(new InputStreamReader(connection.getInputStream(), UtilWS.UTF_8));
		    final StringBuilder buffer = new StringBuilder();
		    String s = "";
		    while ((s = in.readLine()) != null) {
			buffer.append(s + "\r\n");
		    }
		    retorno = buffer.toString();
		    in.close();
		} catch (final Exception e) {
		    LogCEF.error(e);
		}
		return retorno;
    }
}
