/*
 * Copyright (c) 2019 Caixa Econômica Federal. Todos os direitos
 * reservados.
 *
 * Caixa Econômica Federal - SIACG - Sistema de Crédito Rural
 *
 * Este software foi desenvolvido sob demanda da CAIXA e está
 * protegido por leis de direitos autorais e tratados internacionais. As
 * condições de cópia e utilização do todo ou partes dependem de autorização da
 * empresa. Cópias não são permitidas sem expressa autorização. Não pode ser
 * comercializado ou utilizado para propósitos particulares.
 *
 * Uso exclusivo da Caixa Econômica Federal. A reprodução ou distribuição não
 * autorizada deste programa ou de parte dele, resultará em punições civis e
 * criminais e os infratores incorrem em sanções previstas na legislação em
 * vigor.
 *
 * Histórico do TFS:
 *
 * LastChangedRevision: $Revision$
 * LastChangedBy: $Author$
 * LastChangedDate: $Date$
 *
 * HeadURL: $HeadURL$
 *
 */
package br.gov.caixa.siacg.view.form;

import java.util.ArrayList;
import java.util.List;

import br.gov.caixa.siacg.model.domain.Despesa;
import br.gov.caixa.siacg.model.domain.Fornecedor;
import br.gov.caixa.siacg.model.domain.GestaoServentia;
import br.gov.caixa.siacg.model.domain.Imovel;
import br.gov.caixa.siacg.model.domain.TipoDespesa;
import br.gov.caixa.siacg.model.domain.TipoFornecedor;

/**
 * <p>
 * DespesaVisao
 * </p>
 *
 * <p>
 * Descrição: Descrição do tipo
 * </p>
 *
 * <br>
 * <b>Empresa:</b> Cef - Caixa Econômica Federal
 *
 *
 * @author f799837
 *
 * @version 1.0
 */
public class DespesaVisao extends TemplateVisao<Despesa> {

    private static final long serialVersionUID = 1L;

    private Despesa despesa;

    private Despesa despesaParaInativar;

    private Fornecedor fornecedor;
    
    private GestaoServentia gestaoServentia;

    private String ufSelecionada;

    private String municipioSelecionado;

    private Boolean icPesquisaCidade;

    private Boolean icPesquisaCartorio;

    private List<TipoDespesa> listaTipoDespesa;
    
    private List<Despesa> listaDespesa;
    
    private List<TipoDespesa> eventos;

    private List<Fornecedor> listaFornecedores;
    
    private List<TipoFornecedor> listaTipoFornecedores;

    private List<String> listaUf;

    private List<String> listaMunicipios;

    private List<GestaoServentia> listaDeCartorios;

    private boolean restricaoAbangencia;
    
    private Integer nuPesquisaImovel;
    
    private List<Imovel>listaImovel;
    
    private Imovel imovelSelecionado;
    
    private TipoDespesa tipoDespesa;
    
    private TipoDespesa tipoDespesaInativar;
    
    private TipoFornecedor tipoFornecedor;

    /**
     * <p>
     * Retorna o valor do atributo restricaoAbangencia
     * </p>
     * .
     *
     * @return restricaoAbangencia
     */
    public boolean isRestricaoAbangencia() {
	return this.restricaoAbangencia;
    }

    /**
     * <p>
     * Define o valor do atributo restricaoAbangencia
     * </p>
     * .
     *
     * @param restricaoAbangencia
     *            valor a ser atribuído
     */
    public void setRestricaoAbangencia(boolean restricaoAbangencia) {
	this.restricaoAbangencia = restricaoAbangencia;
    }

    /**
     * <p>
     * Retorna o valor do atributo despesa
     * </p>
     * .
     *
     * @return despesa
     */
    public Despesa getDespesa() {
	if (this.despesa == null) {
	    this.despesa = new Despesa();
	    this.despesa.setIcTipoCredor(0);
	}
	return this.despesa;
    }

    /**
     * <p>
     * Define o valor do atributo despesa
     * </p>
     * .
     *
     * @param despesa
     *            valor a ser atribuído
     */
    public void setDespesa(Despesa despesa) {
	this.despesa = despesa;
    }

    /**
     * <p>
     * Retorna o valor do atributo despesaParaInativar
     * </p>
     * .
     *
     * @return despesaParaInativar
     */
    public Despesa getDespesaParaInativar() {
	if (this.despesaParaInativar == null) {
	    this.despesaParaInativar = new Despesa();
	}
	return this.despesaParaInativar;
    }

    /**
     * <p>
     * Define o valor do atributo despesaParaInativar
     * </p>
     * .
     *
     * @param despesaParaInativar
     *            valor a ser atribuído
     */
    public void setDespesaParaInativar(Despesa despesaParaInativar) {
	this.despesaParaInativar = despesaParaInativar;
    }

    /**
     * <p>
     * Retorna o valor do atributo listaTipoDespesa
     * </p>
     * .
     *
     * @return listaTipoDespesa
     */
    public List<TipoDespesa> getListaTipoDespesa() {
	if (this.listaTipoDespesa == null) {
	    this.listaTipoDespesa = new ArrayList<>();
	}
	return this.listaTipoDespesa;
    }
    
    public void setListaTipoDespesa(List<TipoDespesa> listaTipoDespesa) {
    	this.listaTipoDespesa = listaTipoDespesa;
    }
    
    public List<Fornecedor> getListaFornecedores() {
		if (this.listaFornecedores == null) {
		    this.listaFornecedores = new ArrayList<>();
		}
		return this.listaFornecedores;
    }
    
    public void setListaFornecedores(List<Fornecedor> listaFornecedores) {
    	this.listaFornecedores = listaFornecedores;
    }

    public List<TipoFornecedor> getListaTipoFornecedores() {
    	if (this.listaTipoFornecedores == null) {
    		this.listaTipoFornecedores = new ArrayList<>();
    	}
		return listaTipoFornecedores;
	}

	public void setListaTipoFornecedores(List<TipoFornecedor> listaTipoFornecedores) {
		this.listaTipoFornecedores = listaTipoFornecedores;
	}   
 
    public Fornecedor getFornecedor() {
    	if (this.fornecedor == null) {
		    this.fornecedor = new Fornecedor();
		}
		return fornecedor;
	}

	public void setFornecedor(Fornecedor fornecedor) {
		this.fornecedor = fornecedor;
	}

	public GestaoServentia getGestaoServentia() {
		if (this.gestaoServentia == null) {
		    this.gestaoServentia = new GestaoServentia();
		}
		return gestaoServentia;
	}

	public void setGestaoServentia(GestaoServentia gestaoServentia) {
		this.gestaoServentia = gestaoServentia;
	}

	public List<String> getListaUf() {
		if (this.listaUf == null) {
		    this.listaUf = new ArrayList<>();
		}
		return this.listaUf;
    }

    /**
     * <p>
     * Define o valor do atributo listaUf
     * </p>
     * .
     *
     * @param listaUf
     *            valor a ser atribuído
     */
    public void setListaUf(List<String> listaUf) {
	this.listaUf = listaUf;
    }

    /**
     * <p>
     * Retorna o valor do atributo listaMunicipios
     * </p>
     * .
     *
     * @return listaMunicipios
     */
    public List<String> getListaMunicipios() {
	if (this.listaMunicipios == null) {
	    this.listaMunicipios = new ArrayList<>();
	}

	return this.listaMunicipios;
    }

    /**
     * <p>
     * Define o valor do atributo listaMunicipios
     * </p>
     * .
     *
     * @param listaMunicipios
     *            valor a ser atribuído
     */
    public void setListaMunicipios(List<String> listaMunicipios) {
	this.listaMunicipios = listaMunicipios;
    }

    /**
     * <p>
     * Retorna o valor do atributo listaDeCartorios
     * </p>
     * .
     *
     * @return listaDeCartorios
     */
    public List<GestaoServentia> getListaDeCartorios() {
	if (this.listaDeCartorios == null) {
	    this.listaDeCartorios = new ArrayList<>();
	}
	return this.listaDeCartorios;
    }

    /**
     * <p>
     * Define o valor do atributo listaDeCartorios
     * </p>
     * .
     *
     * @param listaDeCartorios
     *            valor a ser atribuído
     */
    public void setListaDeCartorios(List<GestaoServentia> listaDeCartorios) {
	this.listaDeCartorios = listaDeCartorios;
    }

    /**
     * <p>
     * Retorna o valor do atributo ufSelecionada
     * </p>
     * .
     *
     * @return ufSelecionada
     */
    public String getUfSelecionada() {
	return this.ufSelecionada;
    }

    /**
     * <p>
     * Define o valor do atributo ufSelecionada
     * </p>
     * .
     *
     * @param ufSelecionada
     *            valor a ser atribuído
     */
    public void setUfSelecionada(String ufSelecionada) {
	this.ufSelecionada = ufSelecionada;
    }

    /**
     * <p>
     * Retorna o valor do atributo icPesquisaCidade
     * </p>
     * .
     *
     * @return icPesquisaCidade
     */
    public Boolean getIcPesquisaCidade() {
	return this.icPesquisaCidade;
    }

    /**
     * <p>
     * Define o valor do atributo icPesquisaCidade
     * </p>
     * .
     *
     * @param icPesquisaCidade
     *            valor a ser atribuído
     */
    public void setIcPesquisaCidade(Boolean icPesquisaCidade) {
	this.icPesquisaCidade = icPesquisaCidade;
    }

    /**
     * <p>
     * Retorna o valor do atributo icPesquisaCartorio
     * </p>
     * .
     *
     * @return icPesquisaCartorio
     */
    public Boolean getIcPesquisaCartorio() {
	return this.icPesquisaCartorio;
    }

    /**
     * <p>
     * Define o valor do atributo icPesquisaCartorio
     * </p>
     * .
     *
     * @param icPesquisaCartorio
     *            valor a ser atribuído
     */
    public void setIcPesquisaCartorio(Boolean icPesquisaCartorio) {
	this.icPesquisaCartorio = icPesquisaCartorio;
    }

    /**
     * <p>
     * Retorna o valor do atributo municipioSelecionado
     * </p>
     * .
     *
     * @return municipioSelecionado
     */
    public String getMunicipioSelecionado() {
	return this.municipioSelecionado;
    }

    /**
     * <p>
     * Define o valor do atributo municipioSelecionado
     * </p>
     * .
     *
     * @param municipioSelecionado
     *            valor a ser atribuído
     */
    public void setMunicipioSelecionado(String municipioSelecionado) {
	this.municipioSelecionado = municipioSelecionado;
    }

    /**
     * <p>Retorna o valor do atributo nuPesquisaImovel</p>.
     *
     * @return nuPesquisaImovel
    */
    public Integer getNuPesquisaImovel() {
	return this.nuPesquisaImovel;
    }

    /**
     * <p>Define o valor do atributo nuPesquisaImovel</p>.
     *
     * @param nuPesquisaImovel valor a ser atribuído
    */
    public void setNuPesquisaImovel(Integer nuPesquisaImovel) {
	this.nuPesquisaImovel = nuPesquisaImovel;
    }

    /**
     * <p>Retorna o valor do atributo listaImovel</p>.
     *
     * @return listaImovel
    */
    public List<Imovel> getListaImovel() {
	if(this.listaImovel == null) {
	    this.listaImovel = new ArrayList<>();
	}
	return this.listaImovel;
    }

    /**
     * <p>Define o valor do atributo listaImovel</p>.
     *
     * @param listaImovel valor a ser atribuído
    */
    public void setListaImovel(List<Imovel> listaImovel) {
	this.listaImovel = listaImovel;
    }

    /**
     * <p>Retorna o valor do atributo imovelSelecionado</p>.
     *
     * @return imovelSelecionado
    */
	public Imovel getImovelSelecionado() {
		if (this.imovelSelecionado == null) {
			this.imovelSelecionado = new Imovel();
		}
		return this.imovelSelecionado;
	}

    public void setImovelSelecionado(Imovel imovelSelecionado) {
    	this.imovelSelecionado = imovelSelecionado;
    }

	public TipoDespesa getTipoDespesa() {
		if (this.tipoDespesa == null) {
			this.tipoDespesa = new TipoDespesa();
			this.tipoDespesa.setNuTipoDespesa(0);
		}
		return this.tipoDespesa;
	}

	public void setTipoDespesa(TipoDespesa tipoDespesa) {
		this.tipoDespesa = tipoDespesa;
	}	

	public TipoDespesa getTipoDespesaInativar() {
		if (this.tipoDespesaInativar == null) {
			this.tipoDespesaInativar = new TipoDespesa();
		}
		return tipoDespesaInativar;
	}

	public void setTipoDespesaInativar(TipoDespesa tipoDespesaInativar) {
		this.tipoDespesaInativar = tipoDespesaInativar;
	}

	public TipoFornecedor getTipoFornecedor() {
		if (this.tipoFornecedor == null) {
			this.tipoFornecedor = new TipoFornecedor();
		}
		return tipoFornecedor;
	}

	public void setTipoFornecedor(TipoFornecedor tipoFornecedor) {
		this.tipoFornecedor = tipoFornecedor;
	}

	public List<Despesa> getListaDespesa() {
		if(this.listaDespesa == null) {
		    this.listaDespesa = new ArrayList<>();
		}
		return this.listaDespesa;
	}

	public void setListaDespesa(List<Despesa> listaDespesa) {
		this.listaDespesa = listaDespesa;
	}

	public List<TipoDespesa> getEventos() {
		if(this.eventos == null) {
		    this.eventos = new ArrayList<>();
		}
		return eventos;
	}

	public void setEventos(List<TipoDespesa> eventos) {
		this.eventos = eventos;
	}

}
