/*
 * Copyright (c) 2019 Caixa Econômica Federal. Todos os direitos
 * reservados.
 *
 * Caixa Econômica Federal - SIACG - Sistema de Crédito Rural
 *
 * Este software foi desenvolvido sob demanda da CAIXA e está
 * protegido por leis de direitos autorais e tratados internacionais. As
 * condições de cópia e utilização do todo ou partes dependem de autorização da
 * empresa. Cópias não são permitidas sem expressa autorização. Não pode ser
 * comercializado ou utilizado para propósitos particulares.
 *
 * Uso exclusivo da Caixa Econômica Federal. A reprodução ou distribuição não
 * autorizada deste programa ou de parte dele, resultará em punições civis e
 * criminais e os infratores incorrem em sanções previstas na legislação em
 * vigor.
 *
 * Histórico do TFS:
 *
 * LastChangedRevision: $Revision$
 * LastChangedBy: $Author$
 * LastChangedDate: $Date$
 *
 * HeadURL: $HeadURL$
 *
 */
package br.gov.caixa.siacg.util;

import java.util.HashMap;

import javax.ejb.Singleton;

import br.gov.caixa.pedesgo.arquitetura.util.UtilString;
import br.gov.caixa.pedesgo.arquitetura.enumerador.EnumMetodoHTTP;
import br.gov.caixa.pedesgo.arquitetura.enumerador.EnumTipoFormatacao;
import br.gov.caixa.pedesgo.arquitetura.util.LogCefUtil;
import br.gov.caixa.pedesgo.arquitetura.util.UtilFormatacao;
import br.gov.caixa.pedesgo.arquitetura.util.UtilJson;
import br.gov.caixa.pedesgo.arquitetura.util.UtilWS;
import br.gov.caixa.siacg.commons.AppConstant;
import br.gov.caixa.siacg.comum.to.sifec.RespostaSifecDadosContratoTO;
import br.gov.caixa.siacg.comum.to.sifec.RespostaSifecDadosGarantiaContratoTO;
import br.gov.caixa.siacg.comum.to.sifec.RespostaSifecDadosPessoaTO;
import br.gov.caixa.siacg.comum.to.sifec.RespostaSifecDatasContratoTO;

/**
 * <p>
 * SifecUtil
 * </p>
 *
 * <p>
 * Descrição: Descrição do tipo
 * </p>
 *
 * <br>
 * <b>Empresa:</b> Cef - Caixa Econômica Federal
 *
 *
 * @author Mábio Barbosa
 *
 * @version 1.0
 */
@Singleton
public class SifecUtil {

    private static final String API_KEY = "apikey";
	private static final String SISTEMA = "?sistema=";
	private static final String URL_SERVICO_SIFEC_DADOS_CONTRATOS_DEFAULT = "https://api.des.caixa:8443/credito-comercial/v1/contratos/";
    private static final String APIKEY_SIFEC_DADOS_CONTRATOS_DEFAULT = "l7xx9d8ec05003ea45ee8e9d6913c0eec31c";

    /**
     * 
     * <p>
     * Método responsável por consumir o serviço do SIFEC que retorna
     * informações do contrato.
     * </p>
     * .
     *
     * @author Mábio Barbosa
     *
     * @param idContrato
     * @param sistema
     *            Sistema originador do contrato
     * @return RespostaSifecDadosContratoTO
     */
    public RespostaSifecDadosPessoaTO consumirServicoSifecDadosContratoPorPessoa(String cpfCnpj, String sistema) {
	String urlWebService = System.getProperty(AppConstant.PROPRIEDADE_SERVICO_SIFEC_DADOS_CONTRATOS, URL_SERVICO_SIFEC_DADOS_CONTRATOS_DEFAULT);
	urlWebService = urlWebService.substring(0, urlWebService.length() - 1);

	final StringBuilder url = new StringBuilder(urlWebService);
	if (!UtilString.isVazio(cpfCnpj)) {
	    cpfCnpj = UtilFormatacao.removerMascara(cpfCnpj, EnumTipoFormatacao.CNPJ);
	    url.append(cpfCnpj.length() == 11 || cpfCnpj.length() == 14 && cpfCnpj.contains("-") ? "?cpf=" : "?cnpj=").append(cpfCnpj);
	}
	
	HashMap<String, String> header = new HashMap<>();
	header.put(API_KEY, System.getProperty(AppConstant.PROPRIEDADE_APIKEY, APIKEY_SIFEC_DADOS_CONTRATOS_DEFAULT));
	
	LogCEF.info("SIACG -> consumirContratosSIFEC URL -> " + url.toString());

	String jsonRetorno = UtilWS.consumirServicoComToken(url.toString(), null, EnumMetodoHTTP.GET.name(), new TokenSso().getServiceTokenSSO(), true,
		header);

	if (UtilString.isVazio(jsonRetorno)) {
	    LogCefUtil.imprimirLog("SIACG -> consumirServicoSifecDadosContratoPorPessoa -> ", url.toString());
	    LogCEF.info("SIACG -> consumirContratosSIFEC -> Retorno: " + null);	
	    return null;
	} else {
		LogCEF.info("SIACG -> consumirContratosSIFEC -> Retorno: " + jsonRetorno);	
	    return UtilJson.convertJsonAsClass(jsonRetorno, RespostaSifecDadosPessoaTO.class);
	}
    }

    public RespostaSifecDadosContratoTO consumirServicoSifecDetalheContrato(String contratoFormatado, String sistema) {
	final String urlWebService = System.getProperty(AppConstant.PROPRIEDADE_SERVICO_SIFEC_DADOS_CONTRATOS,
		URL_SERVICO_SIFEC_DADOS_CONTRATOS_DEFAULT);

	final StringBuilder url = new StringBuilder(urlWebService);
	url.append(contratoFormatado);
	url.append(SISTEMA).append(sistema);

	HashMap<String, String> header = new HashMap<>();
	header.put(API_KEY, System.getProperty(AppConstant.PROPRIEDADE_APIKEY, APIKEY_SIFEC_DADOS_CONTRATOS_DEFAULT));

	String jsonRetorno = UtilWS.consumirServicoComToken(url.toString(), null, EnumMetodoHTTP.GET.name(), new TokenSso().getServiceTokenSSO(), true,
		header);

	if (UtilString.isVazio(jsonRetorno)) {
	    LogCefUtil.imprimirLog("SIACG -> consumirServicoSifecDetalheContrato -> ", url.toString());
	    return null;
	} else {
	    return UtilJson.convertJsonAsClass(jsonRetorno, RespostaSifecDadosContratoTO.class);
	}
    }

    public RespostaSifecDadosGarantiaContratoTO consumirServicoSifecGarantiasContrato(String contratoFormatado, String sistema) {
	final String urlWebService = System.getProperty(AppConstant.PROPRIEDADE_SERVICO_SIFEC_DADOS_CONTRATOS,
		URL_SERVICO_SIFEC_DADOS_CONTRATOS_DEFAULT);

	final StringBuilder url = new StringBuilder(urlWebService);
	url.append(contratoFormatado);
	url.append("/dados-adicionais");
	url.append(SISTEMA).append(sistema);
	url.append("&dadosAdicionais=garantias");

	HashMap<String, String> header = new HashMap<>();
	header.put(API_KEY, System.getProperty(AppConstant.PROPRIEDADE_APIKEY, APIKEY_SIFEC_DADOS_CONTRATOS_DEFAULT));

	String jsonRetorno = UtilWS.consumirServicoComToken(url.toString(), null, EnumMetodoHTTP.GET.name(), new TokenSso().getServiceTokenSSO(), true,
		header);

	if (UtilString.isVazio(jsonRetorno)) {
	    LogCefUtil.imprimirLog("SIACG -> consumirServicoSifecGarantiasContrato -> ", url.toString());
	    return null;
	} else {
	    return UtilJson.convertJsonAsClass(jsonRetorno, RespostaSifecDadosGarantiaContratoTO.class);
	}
    }

    public RespostaSifecDatasContratoTO consumirServicoSifecDatasContrato(String contratoFormatado, String sistema) {
	final String urlWebService = System.getProperty(AppConstant.PROPRIEDADE_SERVICO_SIFEC_DADOS_CONTRATOS,
		URL_SERVICO_SIFEC_DADOS_CONTRATOS_DEFAULT);

	final StringBuilder url = new StringBuilder(urlWebService);
	url.append(contratoFormatado);
	url.append("/dados-adicionais");
	url.append(SISTEMA).append(sistema);
	url.append("&dadosAdicionais=datas");

	HashMap<String, String> header = new HashMap<>();
	header.put(API_KEY, System.getProperty(AppConstant.PROPRIEDADE_APIKEY, APIKEY_SIFEC_DADOS_CONTRATOS_DEFAULT));

	String jsonRetorno = UtilWS.consumirServicoComToken(url.toString(), null, EnumMetodoHTTP.GET.name(), new TokenSso().getServiceTokenSSO(), true,
		header);

	if (UtilString.isVazio(jsonRetorno)) {
	    LogCefUtil.imprimirLog("SIACG -> consumirServicoSifecDatasContrato -> ", url.toString());
	    return null;
	} else {
	    return UtilJson.convertJsonAsClass(jsonRetorno, RespostaSifecDatasContratoTO.class);
	}
    }

}
