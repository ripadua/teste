/*
 * Copyright (c) 2016 Caixa Econômica Federal. Todos os direitos
 * reservados.
 *
 * Caixa Econômica Federal - SIACG – Sistema de Acompanhamento de Carteiras de Cobrança
 *
 * Este programa de computador foi desenvolvido sob demanda da CAIXA e está protegido por leis de direitos autorais e
 * tratados internacionais. As condições de cópia e utilização do todo ou partes dependem de autorização da pessoa.
 * Cópias não são permitidas sem expressa autorização. Não pode ser comercializado ou utilizado para propósitos
 * particulares.
 *
 * Uso exclusivo da Caixa Econômica Federal. A reprodução ou distribuição não autorizada deste programa ou de parte
 * dele, resultará em punições civis e criminais e os infratores incorrem em sanções previstas na legislação em vigor.
 *
 * Histórico do Subversion:
 *
 * LastChangedRevision: LastChangedBy: LastChangedDate:
 *
 * HeadURL:
 *
 */
package br.gov.caixa.siacg.view.mb;

import java.util.ArrayList;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.enterprise.context.SessionScoped;
import javax.inject.Inject;
import javax.inject.Named;

import org.primefaces.event.UnselectEvent;

import br.gov.caixa.pedesgo.arquitetura.controlador.ManutencaoBean;
import br.gov.caixa.pedesgo.arquitetura.util.MensagensUtil;
import br.gov.caixa.pedesgo.arquitetura.util.UtilString;
import br.gov.caixa.siacg.commons.AppConstant;
import br.gov.caixa.siacg.commons.MsgConstant;
import br.gov.caixa.siacg.exception.ParametrosInvalidosException;
import br.gov.caixa.siacg.model.domain.Propriedade;
import br.gov.caixa.siacg.model.domain.ViewProdutoSiico;
import br.gov.caixa.siacg.service.PropriedadeService;
import br.gov.caixa.siacg.service.ViewProdutoSiicoService;
import br.gov.caixa.siacg.util.LogCEF;
import br.gov.caixa.siacg.view.form.ParametroVisao;

/**
 * <p>
 * ParametroMB
 * </p>
 * <p>
 * Descrição: Managed bean para a funcionalidade de Manutenção de Parametros.
 * </p>
 * <br>
 * <b>Empresa:</b> Cef - Caixa Econômica Federal
 *
 * @author ludemeula.sa
 * @version 1.0
 */
@Named
@SessionScoped
public class ParametroMB extends ManutencaoBean<Propriedade> {
	
	private static final long serialVersionUID = 6011958969638251244L;

	@Inject
	private PropriedadeService service;
	
	@Inject
	private ViewProdutoSiicoService produtoService;
	
	private ParametroVisao visao;
	
	@PostConstruct
	public void carregarDadosVisao() {
		visao = new ParametroVisao();
		
		carregarDadosOperacoes();
	}
	
	/**
	 * <p>Método responsável por listar as operações do SIICO segundo o nome informado.</p>.
	 *
	 * @author ludemeula.sa
	 *
	 * @param nome a ser buscado
	 * @return Operações segundo o nome informado.
	 */
	public List<ViewProdutoSiico> listarOperacaoPorNome(String nome) {
		List<ViewProdutoSiico> retorno = new ArrayList<>();
		if (!UtilString.isVazio(nome)) {
			retorno = new ArrayList<>(produtoService.listaAutoComplete(nome));
		}
	    return retorno;
	}

	public void removerOperacaoSelecionada(UnselectEvent event) {
		getVisao().getOperacoesRemovidas().add((ViewProdutoSiico)event.getObject());
	}
	
	
	public void salvarOperacao() {
		Propriedade propriedade = criarPropriedade(prepararValorPropriedade(getVisao().getOperacoesSelecionadas()));
		propriedade.setDeComentario("Lista de operações que serão exceção no cálculo de suficiência.");
		
        getService().salvar(propriedade);
        adicionaMensagemDeSucesso(MensagensUtil.getMensagem(AppConstant.RESOURCE_BUNDLE, MsgConstant.OPERACAO_COM_SUCESSO));
	}
	
	private Propriedade criarPropriedade(String valor) {
		Propriedade propriedade = new Propriedade();
		propriedade.setNoPropriedade(AppConstant.PROPRIEDADE_CALCULO_SUFICIENCIA_EXCECAO_NOME);
		propriedade.setNoGrupo(AppConstant.PROPRIEDADE_CALCULO_SUFICIENCIA_EXCECAO_GRUPO);
		propriedade.setNoValorPropriedade(valor);
		
		return propriedade;
	}
	
	private String prepararValorPropriedade(List<ViewProdutoSiico> list) {
		StringBuilder retorno = new StringBuilder();
		if (list != null && !list.isEmpty()) {
			for (ViewProdutoSiico item : list) {
				retorno.append(item.getProdutoSiicoID().getNuProduto());
				retorno.append(";");
			}
		}
		
		return retorno.toString();
	}
	
	private void carregarDadosOperacoes() {        
        try {
        	List<ViewProdutoSiico> produtos = new ArrayList<>();
			String dados = getService().getPropriedadeBanco(AppConstant.PROPRIEDADE_CALCULO_SUFICIENCIA_EXCECAO_NOME, AppConstant.PROPRIEDADE_CALCULO_SUFICIENCIA_EXCECAO_GRUPO);
			String[] lista = dados.split(";");
			for (String item : lista) {
				int codigo = Integer.parseInt(item);
				ViewProdutoSiico produto = produtoService.obterProdutoPorCodigo(codigo);
				if (produto != null) {
					produtos.add(produto);
				}
			}
			getVisao().setOperacoesSelecionadas(produtos);		
		} catch (ParametrosInvalidosException e) {
			LogCEF.error("Erro ao carregar as propriedades das operações. Detalhes: ");
			LogCEF.error(e);
		}
	}
	/*******************************************************************
	 * GETTERS && SETTERS
	 ******************************************************************/
	@Override
	protected String getPrefixoCasoDeUso() {
		return AppConstant.RESOURCE_BUNDLE;
	}

	@SuppressWarnings("unchecked")
	@Override
	public PropriedadeService getService() {
		return this.service;
	}

	@Override
	public ParametroVisao getVisao() {
		return visao;
	}
}