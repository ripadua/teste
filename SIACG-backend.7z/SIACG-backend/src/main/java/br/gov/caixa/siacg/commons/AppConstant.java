/**
 * reservados.
 * Copyright (c) 2009-2011 Caixa EconÃ´mica Federal. Todos os direitos
 *
 * Caixa EconÃ´mica Federal - SIACG â€“ Sistema de Acompanhamento de Carteiras de CobranÃ§a
 *
 * Este programa de computador foi desenvolvido sob demanda da CAIXA e estÃ¡
 * protegido por leis de direitos autorais e tratados internacionais. As
 * condiÃ§Ãµes de cÃ³pia e utilizaÃ§Ã£o total ou partes dependem de autorizaÃ§Ã£o da
 * pessoa. CÃ³pias nÃ£o sÃ£o permitidas sem expressa autorizaÃ§Ã£o. NÃ£o pode ser
 * comercializado ou utilizado para propÃ³sitos particulares.
 *
 * Uso exclusivo da Caixa EconÃ´mica Federal. A reproduÃ§Ã£o ou distribuiÃ§Ã£o nÃ£o
 * autorizada deste programa ou de parte dele, resultarÃ¡ em puniÃ§Ãµes civis e
 * criminais e os infratores incorrem em sanÃ§Ãµes previstas na legislaÃ§Ã£o em
 * vigor.
 *
 * HistÃ³rico do Subversion:
 *
 * LastChangedRevision:
 * LastChangedBy:
 * LastChangedDate:
 *
 * HeadURL:
 *
 */

package br.gov.caixa.siacg.commons;

import java.text.SimpleDateFormat;

/**
 * <p>
 * AppConstant
 * </p>
 * <p>
 * Descrição: Classe AppConstant
 * </p>
 * <br>
 * <b>Empresa:</b> Cef - Caixa Econômica Federal.
 *
 * @author GS Tecnologia
 * @version 1.0
 */
public class AppConstant {

    /* NOME DO SCHEMA DE BANCO DE DADOS UTILIZADO PELAS ENTIDADES DO SIACG */
    /** Atributo SCHEMA_acg. */
    public static final String SCHEMA_ACGSM001 = "ACG";

    /** Atributo SCHEMA_ICOSM001. */
    public static final String SCHEMA_ICOSM001 = "icosm001";

    /** Atributo SCHEMA_ACGSM002. */
    public static final String SCHEMA_ACGSM002 = "acgsm002";

    /* UNIDADE DE PERSISTÊNCIA */
    /** Atributo NOME_PERSISTENCE_UNIT. */
    public static final String NOME_PERSISTENCE_UNIT = "siacgPU";

    /** Atributo NOME_PERSISTENCE_UNIT_DW. */
    public static final String NOME_PERSISTENCE_UNIT_DW = "siacgPUDW";

    /** Atributo NOME_PERSISTENCE_UNIT_DW. */
    public static final String NOME_PERSISTENCE_UNIT_SIICO = "siicoPU";

    public static final String UNIDADES_DIRES = "siico.api.unidades.dire";

    /** Atributo do Sistema */
    public static final String SICLI = "SICLI";
    /** Atributo do Sistema */
    public static final String SIACG = "SIACG";
    /** Atributo do Sistema Aplicação Financeira */
    public static final String SIFIX = "SIFIX";
    /** Atributo do Sistema Contas */
    public static final String SID00 = "SID00";
    /** Atributo do Sistema Contas */
    public static final String SID09 = "SID09";
    /** Sistema de Gravame */
    public static final String SICGR = "SICGR";
    /** Sistema de NSGD */
    public static final String NSGD = "NSGD";
    /** CEDES NSGD */
    public static final String CEDES_NSGD = "CEDESSP372";
    /** CEDES SIFIX */
    public static final String CEDES_SIFIX = " CEDESBR271";
    /** CEDES SID00 */
    public static final String CEDES_SID00 = " CEDESSP244";
    /** Path onde estão os arquivos de entrada */
    public static final String PROPRIEDADE_PATH_ENTRADA = "siacg.path.entrada";
    /** Path onde estão os arquivos de saida */
    public static final String PROPRIEDADE_PATH_SAIDA = "siacg.path.saida";
    /** Path onde estão os arquivos de retencao */
    public static final String PROPRIEDADE_PATH_RETENCAO = "siacg.path.retencao";
    
    public static final String PROPRIEDADE_PATH_MANUAL_USUARIO = "siacg.path.manual.usuario";
    
    /** Propriedade contendo a url do serviço de desbloqueio do SIFIX */
    public static final String PROPRIEDADE_SERVICO_DESBLOQUEIO_SIFIX = "siacg.url.sifix.desbloqueio";

    /** Propriedade contendo a url do serviço de bloqueio do SIFIX */
    public static final String PROPRIEDADE_SERVICO_BLOQUEIO_SIFIX = "siacg.url.sifix.bloqueio";
    /// Propriedade contendo a url do serviço de bloqueio do NSGD
    public static final String PROPRIEDADE_SERVICO_BLOQUEIO_NSGD = "siacg.url.nsgd.bloqueio.wsdl";

    /** Propriedade contendo a url do serviço de desbloqueio do SID00 */
    public static final String PROPRIEDADE_SERVICO_DESBLOQUEIO_SID00 = "siacg.url.sid00.desbloqueio";

    /** Propriedade contendo a url do serviço de bloqueio do SID00 */
    public static final String PROPRIEDADE_SERVICO_BLOQUEIO_SID00 = "siacg.url.sid00.bloqueio";

    /** Propriedade contendo a url do serviço de Saldo do SID00 */
    public static final String PROPRIEDADE_SERVICO_SALDO_SID00 = "siacg.url.sid00.saldo.wsdl";

    /** Propriedade contendo a url do serviço de dados do cliente do SICLI */
    public static final String PROPRIEDADE_SERVICO_SICLI_CLIENTES = "siacg.url.sicli.clientes";

    /** Propriedade contendo a url do serviço de dados do cliente do SID 09 */
    public static final String PROPRIEDADE_NOME_SERVICO_SID09 = "url.servico.consulta.cliente.sid09";

    /** Propriedade contendo a url do serviço de dados do cliente do SICLI */
    public static final String PROPRIEDADE_APIKEY = "siacg.apikey";

    public static final String PROPRIEDADE_CLI_SER_ACG = "siacg.cli.ser_acg";

    public static final String PROPRIEDADE_TOKEN_SSO = "siacg.token.sso";

    public static final String URL_SSO_INTERNET = "url_sso_internet";

    public static final String PROPRIEDADE_TOKEN_SSO_SIFEC = "siacg.token.sso.sifec";

    /** Propriedade contendo a url do serviço de dados do cliente do SIFEC */
    public static final String PROPRIEDADE_SERVICO_SIFEC_DADOS_CONTRATOS = "siacg.url.sifec.dados.contratos";

    /* Propriedades de dados de veículos obtidos do SIFEC */
    public static final String PROPRIEDADE_SERVICO_SIFEC_DADOS_VEICULOS = "siacg.url.sifec.dados.veiculos";

    /** Propriedade contendo a url do serviço de indicadores do SIBDO */
    public static final String PROPRIEDADE_SERVICO_INDICADORES_SIBDO = "siacg.url.sibdo.consulta.indicadores";

    /** Propriedade contendo a url do serviço de desbloqueio do SID00 */
    public static final String PROPRIEDADE_USUARIO_SIBDO = "siacg.usuario.sibdo";

    /** Propriedade contendo versao do SIBDO **/
    public static final String PROPRIEDADE_VERSAO_SIBDO = "siacg.versao.sibdo";

    /** Propriedade contendo matricula do usuario que consulta SIBDO **/
    public static final String PROPRIEDADE_MATRICULA_SIBDO = "siacg.matricula.sibdo";

    /** Propriedade contendo operação do SIBDO **/
    public static final String PROPRIEDADE_OPERACAO_SIBDO = "siacg.operacao.sibdo";

    /** Propriedade contendo indice SIBDO **/
    public static final String PROPRIEDADE_INDICE_SIBDO = "siacg.indice.sibdo";

    /** Propriedade contendo sistema de origem que consulta o SIBDO **/
    public static final String PROPRIEDADE_SISTEMA_ORIGEM_SIBDO = "siacg.sistema.origem.sibdo";

    /** Propriedade contendo identificador origem que consulta o SIBDO **/
    public static final String PROPRIEDADE_IDENTIFICADOR_ORIGEM_SIBDO = "siacg.identificador.origem.sibdo";

    /** Propriedade contendo unidade que consulta o SIBDO **/
    public static final String PROPRIEDADE_UNIDADE_ORIGEM_SIBDO = "siacg.unidade.sibdo";

    public static final String DELIMITADOR = ";";

    public static final String QUEBRALINHA = "\n";

    public static final String RESOURCE_BUNDLE = "msgApp";

    public static final String USUARIO_DESBLOQUEIO_MATRICULA = "siacg.usuario.desbloqueio.matricula";

    public static final String PROPRIEDADE_CALCULO_SUFICIENCIA_EXCECAO_NOME = "calculo.suficiencia.excecao.operacao";
    public static final String PROPRIEDADE_CALCULO_SUFICIENCIA_EXCECAO_GRUPO = "calculo.suficiencia";

    public static final String PROPRIEDADE_SERVICO_SIOPI_DADOS_IMOVEIS = "siacg.url.siopi.dados.imoveis";

    public static final String PROPRIEDADE_SERVICO_HABITACAO_ORIGINACAO = "siacg.habitacao.originacao";

    public static final String PROPRIEDADE_SERVICO_HABITACAO_ORIGINACAO_CPF_CNPJ = "siacg.habitacao.originacao.cpfCnpj";

    public static final String PROPRIEDADE_SERVICO_HABITACAO_ORIGINACAO_AVALIACOES = "siacg.habitacao.originacao.avaliacoes";
    public static final String PROPRIEDADE_SERVICO_HABITACAO_ORIGINACAO_AVALIACOES_LAUDO = "siacg.habitacao.originacao.laudo";
    
    public static final SimpleDateFormat SDF_YYYY_MM_DD = new SimpleDateFormat("yyyy-MM-dd");
    
    /** Atributo PROPRIEDADE_ENVIO_AUTOMATICO. */
    public static final String PROPRIEDADE_ENVIO_AUTOMATICO = "envio.mensageria.automatico";
    /** Atributo PROPRIEDADE_EXPRESSAO. */
    public static final String PROPRIEDADE_EXPRESSAO = "envio.mensageria.expressao";
    /** Atributo PROPRIEDADE_GRUPO. */
    public static final String PROPRIEDADE_GRUPO_MENSAGERIA = "mensageria";
    /** Atributo LABEL_LIGADO. */
    public static final String LABEL_LIGADO = "ligado";
    
    public static final String PROPRIEDADE_NU_OPERACAO_GIM="siacg.gim.operacao";
    
    public static final String PROPRIEDADE_NU_UNIDADE_LEILAO = "siacg.nu.unidade.leilao";
    
    public static final String PROPRIEDADE_NU_NATURAL_LEILAO = "siacg.nu.natural.leilao";

    public static final String PROPRIEDADE_OPERACAO_VEICULO_PARAMETRIZACAO_AUTOMATICA = "siacg.operacao.veiculo.parametrizacao.automatica";
    
    public static final String PROPRIEDADE_OPERACAO_VEICULO_CALCULO_SUFICIENCIA = "siacg.operacao.veiculo.calculo.suficiencia";

    private AppConstant() {
	throw new IllegalStateException("Utility class");
    }
}
