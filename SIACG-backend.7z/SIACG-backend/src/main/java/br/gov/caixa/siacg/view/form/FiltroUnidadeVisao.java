/**
 * Copyright (c) 2013 Caixa Econômica Federal. Todos os direitos
 * reservados.
 *
 * Caixa Econômica Federal - SIACG - Sistema de Crédito Rural
 *
 * Este software foi desenvolvido sob demanda da CAIXA e está
 * protegido por leis de direitos autorais e tratados internacionais. As
 * condições de cópia e utilização do todo ou partes dependem de autorização da
 * pessoa. Cópias não são permitidas sem expressa autorização. Não pode ser
 * comercializado ou utilizado para propósitos particulares.
 *
 * Uso exclusivo da Caixa Econômica Federal. A reprodução ou distribuição não
 * autorizada deste programa ou de parte dele, resultará em punições civis e
 * criminais e os infratores incorrem em sanções previstas na legislação em
 * vigor.
 *
 * Histórico do Subversion:
 *
 * LastChangedRevision: $Revision$
 * LastChangedBy: $Author$
 * LastChangedDate: $Date$
 *
 * HeadURL: $HeadURL$
 *
 */
package br.gov.caixa.siacg.view.form;

import java.util.ArrayList;
import java.util.Collection;

import br.gov.caixa.siacg.model.domain.Mensagem;
import br.gov.caixa.siacg.model.vo.SrVO;
import br.gov.caixa.siacg.model.vo.UnidadeVO;

/**
 * <p>
 * LoginVisao
 * </p>
 * <p>
 * Descrição: Classe de visão do login.
 * </p>
 * <br>
 * <b>Empresa:</b> Cef - Caixa Econômica Federal
 *
 * @author guilherme.santos
 * @version 1.0
 */
public class FiltroUnidadeVisao extends TemplateVisao<Mensagem> {

    private static final long serialVersionUID = 3430660501444995025L;

    private boolean exibirGestorCaixa;

    private boolean exibirGestorNacional;

    private boolean exibirGestorRegional;

    private boolean exibirGestorUnidade;

    private boolean exibirColunaUnidade;

    private boolean exibirColunaSR;

    private boolean exibirColunaSUAT;

    private boolean exibirBotaoVoltarConsulta;

    private String nomeSuat;

    private String nomeSr;

    private String nomeUnidade;

    private Integer nuSuat;

    private Integer nuSr;

    private Integer nuUnidade;

    private String nivelConsulta;

    private Mensagem mensagem;

    private Collection<Mensagem> listaMensagens;

    private Collection<UnidadeVO> unidadeList;

    private Collection<UnidadeVO> suatList;

    private Collection<SrVO> srList;

    /**
     * Retorna o valor do atributo listaMensagens.
     *
     * @return listaMensagens
     */
    public Collection<Mensagem> getListaMensagens() {
        if (this.listaMensagens == null) {
            this.listaMensagens = new ArrayList<>();
        }
        return this.listaMensagens;
    }

    /**
     * Define o valor do atributo listaMensagens.
     *
     * @param listaMensagens
     *            valor a ser atribuído
     */
    public void setListaMensagens(final Collection<Mensagem> listaMensagens) {
        this.listaMensagens = listaMensagens;
    }

    /**
     * Retorna o valor do atributo mensagem.
     *
     * @return mensagem
     */
    public Mensagem getMensagem() {

        return this.mensagem;
    }

    /**
     * Define o valor do atributo mensagem.
     *
     * @param mensagem
     *            valor a ser atribuído
     */
    public void setMensagem(final Mensagem mensagem) {

        this.mensagem = mensagem;
    }

    /**
     * Retorna o valor do atributo unidadeList.
     *
     * @return unidadeList
     */
    public Collection<UnidadeVO> getUnidadeList() {
        return this.unidadeList;
    }

    /**
     * Define o valor do atributo unidadeList.
     *
     * @param unidadeList
     *            valor a ser atribuído
     */
    public void setUnidadeList(final Collection<UnidadeVO> unidadeList) {
        this.unidadeList = unidadeList;
    }

    /**
     * Retorna o valor do atributo suatList.
     *
     * @return suatList
     */
    public Collection<UnidadeVO> getSuatList() {
        return this.suatList;
    }

    /**
     * Define o valor do atributo suatList.
     *
     * @param suatList
     *            valor a ser atribuído
     */
    public void setSuatList(final Collection<UnidadeVO> suatList) {
        this.suatList = suatList;
    }

    /**
     * Retorna o valor do atributo srList.
     *
     * @return srList
     */
    public Collection<SrVO> getSrList() {
        return this.srList;
    }

    /**
     * Define o valor do atributo srList.
     *
     * @param srList
     *            valor a ser atribuído
     */
    public void setSrList(final Collection<SrVO> srList) {
        this.srList = srList;
    }

    /**
     * Retorna o valor do atributo exibirGestorCaixa.
     *
     * @return exibirGestorCaixa
     */
    public boolean isExibirGestorCaixa() {
        return this.exibirGestorCaixa;
    }

    /**
     * Define o valor do atributo exibirGestorCaixa.
     *
     * @param exibirGestorCaixa
     *            valor a ser atribuído
     */
    public void setExibirGestorCaixa(final boolean exibirGestorCaixa) {
        this.exibirGestorCaixa = exibirGestorCaixa;
    }

    /**
     * Retorna o valor do atributo exibirGestorNacional.
     *
     * @return exibirGestorNacional
     */
    public boolean isExibirGestorNacional() {
        return this.exibirGestorNacional;
    }

    /**
     * Define o valor do atributo exibirGestorNacional.
     *
     * @param exibirGestorNacional
     *            valor a ser atribuído
     */
    public void setExibirGestorNacional(final boolean exibirGestorNacional) {
        this.exibirGestorNacional = exibirGestorNacional;
    }

    /**
     * Retorna o valor do atributo exibirGestorRegional.
     *
     * @return exibirGestorRegional
     */
    public boolean isExibirGestorRegional() {
        return this.exibirGestorRegional;
    }

    /**
     * Define o valor do atributo exibirGestorRegional.
     *
     * @param exibirGestorRegional
     *            valor a ser atribuído
     */
    public void setExibirGestorRegional(final boolean exibirGestorRegional) {
        this.exibirGestorRegional = exibirGestorRegional;
    }

    /**
     * Retorna o valor do atributo exibirGestorUnidade.
     *
     * @return exibirGestorUnidade
     */
    public boolean isExibirGestorUnidade() {
        return this.exibirGestorUnidade;
    }

    /**
     * Define o valor do atributo exibirGestorUnidade.
     *
     * @param exibirGestorUnidade
     *            valor a ser atribuído
     */
    public void setExibirGestorUnidade(final boolean exibirGestorUnidade) {
        this.exibirGestorUnidade = exibirGestorUnidade;
    }

    /**
     * Retorna o valor do atributo exibirColunaUnidade.
     *
     * @return exibirColunaUnidade
     */
    public boolean isExibirColunaUnidade() {
        return this.exibirColunaUnidade;
    }

    /**
     * Define o valor do atributo exibirColunaUnidade.
     *
     * @param exibirColunaUnidade
     *            valor a ser atribuído
     */
    public void setExibirColunaUnidade(final boolean exibirColunaUnidade) {
        this.exibirColunaUnidade = exibirColunaUnidade;
    }

    /**
     * Retorna o valor do atributo exibirColunaSR.
     *
     * @return exibirColunaSR
     */
    public boolean isExibirColunaSR() {
        return this.exibirColunaSR;
    }

    /**
     * Define o valor do atributo exibirColunaSR.
     *
     * @param exibirColunaSR
     *            valor a ser atribuído
     */
    public void setExibirColunaSR(final boolean exibirColunaSR) {
        this.exibirColunaSR = exibirColunaSR;
    }

    /**
     * Retorna o valor do atributo exibirColunaSUAT.
     *
     * @return exibirColunaSUAT
     */
    public boolean isExibirColunaSUAT() {
        return this.exibirColunaSUAT;
    }

    /**
     * Define o valor do atributo exibirColunaSUAT.
     *
     * @param exibirColunaSUAT
     *            valor a ser atribuído
     */
    public void setExibirColunaSUAT(final boolean exibirColunaSUAT) {
        this.exibirColunaSUAT = exibirColunaSUAT;
    }

    /**
     * Retorna o valor do atributo nuSuat.
     *
     * @return nuSuat
     */
    public Integer getNuSuat() {
        return this.nuSuat;
    }

    /**
     * Define o valor do atributo nuSuat.
     *
     * @param nuSuat
     *            valor a ser atribuído
     */
    public void setNuSuat(final Integer nuSuat) {
        this.nuSuat = nuSuat;
    }

    /**
     * Retorna o valor do atributo nuSr.
     *
     * @return nuSr
     */
    public Integer getNuSr() {
        return this.nuSr;
    }

    /**
     * Define o valor do atributo nuSr.
     *
     * @param nuSr
     *            valor a ser atribuído
     */
    public void setNuSr(final Integer nuSr) {
        this.nuSr = nuSr;
    }

    /**
     * Retorna o valor do atributo nuUnidade.
     *
     * @return nuUnidade
     */
    public Integer getNuUnidade() {
        return this.nuUnidade;
    }

    /**
     * Define o valor do atributo nuUnidade.
     *
     * @param nuUnidade
     *            valor a ser atribuído
     */
    public void setNuUnidade(final Integer nuUnidade) {
        this.nuUnidade = nuUnidade;
    }

    /**
     * Retorna o valor do atributo nomeSuat.
     *
     * @return nomeSuat
     */
    public String getNomeSuat() {
        return this.nomeSuat;
    }

    /**
     * Define o valor do atributo nomeSuat.
     *
     * @param nomeSuat
     *            valor a ser atribuído
     */
    public void setNomeSuat(final String nomeSuat) {
        this.nomeSuat = nomeSuat;
    }

    /**
     * Retorna o valor do atributo nomeSr.
     *
     * @return nomeSr
     */
    public String getNomeSr() {
        return this.nomeSr;
    }

    /**
     * Define o valor do atributo nomeSr.
     *
     * @param nomeSr
     *            valor a ser atribuído
     */
    public void setNomeSr(final String nomeSr) {
        this.nomeSr = nomeSr;
    }

    /**
     * Retorna o valor do atributo nomeUnidade.
     *
     * @return nomeUnidade
     */
    public String getNomeUnidade() {
        return this.nomeUnidade;
    }

    /**
     * Define o valor do atributo nomeUnidade.
     *
     * @param nomeUnidade
     *            valor a ser atribuído
     */
    public void setNomeUnidade(final String nomeUnidade) {
        this.nomeUnidade = nomeUnidade;
    }

    /**
     * Retorna o valor do atributo exibirBotaoVoltarConsulta.
     *
     * @return exibirBotaoVoltarConsulta
     */
    public boolean isExibirBotaoVoltarConsulta() {
        return this.exibirBotaoVoltarConsulta;
    }

    /**
     * Define o valor do atributo exibirBotaoVoltarConsulta.
     *
     * @param exibirBotaoVoltarConsulta
     *            valor a ser atribuído
     */
    public void setExibirBotaoVoltarConsulta(final boolean exibirBotaoVoltarConsulta) {
        this.exibirBotaoVoltarConsulta = exibirBotaoVoltarConsulta;
    }

    /**
     * Retorna o valor do atributo nivelConsulta.
     *
     * @return nivelConsulta
     */
    public String getNivelConsulta() {
        return this.nivelConsulta;
    }

    /**
     * Define o valor do atributo nivelConsulta.
     *
     * @param nivelConsulta
     *            valor a ser atribuído
     */
    public void setNivelConsulta(final String nivelConsulta) {
        this.nivelConsulta = nivelConsulta;
    }
}
