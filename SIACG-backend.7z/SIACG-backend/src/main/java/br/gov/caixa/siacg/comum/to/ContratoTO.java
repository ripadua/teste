/*
 * Copyright (c) 2016 Caixa Econômica Federal. Todos os direitos
 * reservados.
 *
 * Caixa Econômica Federal - SIACG_dev
 *
 * Este software foi desenvolvido sob demanda da CAIXA e está
 * protegido por leis de direitos autorais e tratados internacionais. As
 * condições de cópia e utilização do total ou partes dependem de autorização da
 * pessoa. Cópias não são permitidas sem expressa autorização. Não pode ser
 * comercializado ou utilizado para propósitos particulares.
 *
 * Uso exclusivo da Caixa Econômica Federal. A reprodução ou distribuição não
 * autorizada deste programa ou de parte dele, resultará em punições civis e
 * criminais e os infratores incorrem em sanções previstas na legislação em
 * vigor.
 *
 * Histórico do Subversion:
 *
 * LastChangedRevision: $Revision$
 * LastChangedBy: $Author$
 * LastChangedDate: $Date$
 *
 * HeadURL: $HeadURL$
 *
 */
package br.gov.caixa.siacg.comum.to;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import br.gov.caixa.pedesgo.arquitetura.util.UtilFormatacao;

/**
 * 
 * <p>
 * ContratosTO
 * </p>
 *
 * <p>
 * Descrição: Contratos.
 * </p>
 *
 * <br>
 * <b>Empresa:</b> Cef - Caixa Econômica Federal
 *
 *
 * @author f538462
 *
 * @version 1.0
 */
@JsonIgnoreProperties(ignoreUnknown = true)
public class ContratoTO implements Serializable {

    /** Atributo serialVersionUID. */
    private static final long serialVersionUID = -1682760725038933412L;
    private String coIdentificacao;
    
    private Integer nuProduto;
    
    private Integer nuNaturalSistema;
    
    private String nuCrto;
    
    private Integer icSituacao;
    
    private String noProduto;
    
    private Integer unidade;
    
    private Integer numero;
    
    private Integer digito;
    
    private boolean icVinculado;

    /**
     * <p>
     * Retorna o valor do atributo coIdentificacao
     * </p>
     * .
     *
     * @return coIdentificacao
     */
    public String getCoIdentificacao() {
	return this.coIdentificacao;
    }

    /**
     * <p>
     * Define o valor do atributo coIdentificacao
     * </p>
     * .
     *
     * @param coIdentificacao
     *            valor a ser atribuído
     */
    public void setCoIdentificacao(final String coIdentificacao) {
	if (coIdentificacao != null) {
	    this.coIdentificacao = coIdentificacao.trim();
	}
    }

    /**
     * <p>
     * Retorna o valor do atributo nuProduto
     * </p>
     * .
     *
     * @return nuProduto
     */
    public Integer getNuProduto() {
	return this.nuProduto;
    }

    /**
     * <p>
     * Define o valor do atributo nuProduto
     * </p>
     * .
     *
     * @param nuProduto
     *            valor a ser atribuído
     */
    public void setNuProduto(final Integer nuProduto) {
	this.nuProduto = nuProduto;
    }

    /**
     * <p>
     * Retorna o valor do atributo nuNaturalSistema
     * </p>
     * .
     *
     * @return nuNaturalSistema
     */
    public Integer getNuNaturalSistema() {
	return this.nuNaturalSistema;
    }

    /**
     * <p>
     * Define o valor do atributo nuNaturalSistema
     * </p>
     * .
     *
     * @param nuNaturalSistema
     *            valor a ser atribuído
     */
    public void setNuNaturalSistema(final Integer nuNaturalSistema) {
	this.nuNaturalSistema = nuNaturalSistema;
    }

    /**
     * <p>
     * Define o valor do atributo nuCrto
     * </p>
     * .
     *
     * @param nuCrto
     *            valor a ser atribuído
     */
    public void setNuCrto(final String nuCrto) {
	this.nuCrto = nuCrto;
    }

    /**
     * <p>
     * Retorna o valor do atributo icSituacao
     * </p>
     * .
     *
     * @return icSituacao
     */
    public Integer getIcSituacao() {
	return this.icSituacao;
    }

    /**
     * <p>
     * Define o valor do atributo icSituacao
     * </p>
     * .
     *
     * @param icSituacao
     *            valor a ser atribuído
     */
    public void setIcSituacao(final Integer icSituacao) {
	this.icSituacao = icSituacao;
    }

    /**
     * <p>
     * Retorna o valor do atributo noProduto
     * </p>
     * .
     *
     * @return noProduto
     */
    public String getNoProduto() {
	return this.noProduto;
    }

    /**
     * <p>
     * Define o valor do atributo noProduto
     * </p>
     * .
     *
     * @param noProduto
     *            valor a ser atribuído
     */
    public void setNoProduto(final String noProduto) {
	this.noProduto = noProduto;
    }

    public String getNuCrto() {
	return this.nuCrto;
    }

    public Integer getUnidade() {
	return this.unidade;
    }

    public void setUnidade(final Integer unidade) {
	this.unidade = unidade;
    }

    public Integer getNumero() {
	return this.numero;
    }

    public void setNumero(final Integer numero) {
	this.numero = numero;
    }

    public Integer getDigito() {
	return this.digito;
    }

    public void setDigito(final Integer digito) {
	this.digito = digito;
    }

    /**
     * 
     * <p>
     * Método responsável por retorna o numero da conta concatenado:
     * </p>
     * .
     *
     * @author p575337
     *
     * @return Agencia-Produto-Numero-Digito
     */
    public String getConta() {
	final StringBuilder conta = new StringBuilder();
	conta.append(UtilFormatacao.completarComZeroEsquerda(this.getUnidade().toString(), 4));
	conta.append("-");
	conta.append(UtilFormatacao.completarComZeroEsquerda(this.getNuProduto().toString(), 4));
	conta.append("-");
	conta.append(this.getNumero());
	conta.append("-");
	conta.append(this.getDigito());
	return conta.toString();
    }

    /**
     * <p>
     * Retorna o valor do atributo icVinculado
     * </p>
     * .
     *
     * @return icVinculado
     */
    public boolean isIcVinculado() {
	return this.icVinculado;
    }

    /**
     * <p>
     * Define o valor do atributo icVinculado
     * </p>
     * .
     *
     * @param icVinculado
     *            valor a ser atribuído
     */
    public void setIcVinculado(final boolean icVinculado) {
	this.icVinculado = icVinculado;
    }

}