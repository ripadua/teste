/*
 * Copyright (c) 2019 Caixa Econômica Federal. Todos os direitos
 * reservados.
 *
 * Caixa Econômica Federal - SIACG - Sistema de Crédito Rural
 *
 * Este software foi desenvolvido sob demanda da CAIXA e está
 * protegido por leis de direitos autorais e tratados internacionais. As
 * condições de cópia e utilização do todo ou partes dependem de autorização da
 * empresa. Cópias não são permitidas sem expressa autorização. Não pode ser
 * comercializado ou utilizado para propósitos particulares.
 *
 * Uso exclusivo da Caixa Econômica Federal. A reprodução ou distribuição não
 * autorizada deste programa ou de parte dele, resultará em punições civis e
 * criminais e os infratores incorrem em sanções previstas na legislação em
 * vigor.
 *
 * Histórico do TFS:
 *
 * LastChangedRevision: $Revision$
 * LastChangedBy: $Author$
 * LastChangedDate: $Date$
 *
 * HeadURL: $HeadURL$
 *
 */
package br.gov.caixa.siacg.view.form;

import java.util.ArrayList;
import java.util.List;

import br.gov.caixa.siacg.model.domain.Empreendimento;
import br.gov.caixa.siacg.model.domain.FonteExpressao;
import br.gov.caixa.siacg.model.domain.Formula;
import br.gov.caixa.siacg.model.domain.FormulaItem;
import br.gov.caixa.siacg.model.domain.ParametroFormulaItem;
import br.gov.caixa.siacg.model.domain.ParametroFuncao;
import br.gov.caixa.siacg.model.domain.TipoExpressao;
import br.gov.caixa.siacg.model.domain.Tipologia;
import br.gov.caixa.siacg.model.domain.UnidadeHabitacional;
import br.gov.caixa.siacg.model.domain.VinculoCalculo;

/**
 * <p>
 * ParametrizacaoFormulaVisao
 * </p>
 * <p>
 * Descrição: Classe responsável por armazenar os dados da visão do caso de uso
 * de <code>Parametrização de Fórmulas</code>.
 * </p>
 * 
 * <b>Empresa:</b> Cef - Caixa Econômica Federal
 *
 * @author Ludemeula Fernandes de Sá
 * @version 1.0
 */
public class ParametrizacaoFormulaVisao extends TemplateVisao<Formula> {

	private static final long serialVersionUID = -6770862906956832453L;

	private String nomeFormula;
	private FormulaItem formulaItem;
	private FormulaItem itemSelecionado;
	private VinculoCalculo vinculoCalculo;
	private VinculoCalculo vinculoFiltro;
	private List<TipoExpressao> tipoExpressoes;
	private List<TipoExpressao> tipoExpressoesFuncao;
	private List<FonteExpressao> fonteExpressoes;
	private List<ParametroFuncao> parametroFuncoes;
	private List<ParametroFormulaItem> funcoes;
	private List<Empreendimento> empreendimentos;
	private List<UnidadeHabitacional> unidades;
	private List<Tipologia> tipologias;
	private List<VinculoCalculo> vinculos;
	private List<Formula> formulas;
	private Integer indexAba;
	private String coApf;

	/**
	 * <p>
	 * Retorna o valor do atributo nomeFormula
	 * </p>
	 * .
	 *
	 * @return nomeFormula
	 */
	public String getNomeFormula() {
		return this.nomeFormula;
	}

	/**
	 * <p>
	 * Define o valor do atributo nomeFormula
	 * </p>
	 * .
	 *
	 * @param nomeFormula
	 *            valor a ser atribuído
	 */
	public void setNomeFormula(String nomeFormula) {
		this.nomeFormula = nomeFormula;
	}

	/**
	 * <p>
	 * Retorna o valor do atributo formulaItem
	 * </p>
	 * .
	 *
	 * @return formulaItem
	 */
	public FormulaItem getFormulaItem() {
		return this.formulaItem;
	}

	/**
	 * <p>
	 * Define o valor do atributo formulaItem
	 * </p>
	 * .
	 *
	 * @param formulaItem
	 *            valor a ser atribuído
	 */
	public void setFormulaItem(FormulaItem formulaItem) {
		this.formulaItem = formulaItem;
	}

	/**
	 * <p>
	 * Retorna o valor do atributo itemSelecionado
	 * </p>
	 * .
	 *
	 * @return itemSelecionado
	 */
	public FormulaItem getItemSelecionado() {
		return this.itemSelecionado;
	}

	/**
	 * <p>
	 * Define o valor do atributo itemSelecionado
	 * </p>
	 * .
	 *
	 * @param itemSelecionado
	 *            valor a ser atribuído
	 */
	public void setItemSelecionado(FormulaItem itemSelecionado) {
		this.itemSelecionado = itemSelecionado;
	}

	/**
	 * <p>
	 * Retorna o valor do atributo tipoExpressoes
	 * </p>
	 * .
	 *
	 * @return tipoExpressoes
	 */
	public List<TipoExpressao> getTipoExpressoes() {
		if (tipoExpressoes == null) {
			setTipoExpressoes(new ArrayList<TipoExpressao>());
		}

		return this.tipoExpressoes;
	}

	/**
	 * <p>
	 * Define o valor do atributo tipoExpressoes
	 * </p>
	 * .
	 *
	 * @param tipoExpressoes
	 *            valor a ser atribuído
	 */
	public void setTipoExpressoes(List<TipoExpressao> tipoExpressoes) {
		this.tipoExpressoes = tipoExpressoes;
	}

	/**
	 * <p>
	 * Retorna o valor do atributo fonteExpressoes
	 * </p>
	 * .
	 *
	 * @return fonteExpressoes
	 */
	public List<FonteExpressao> getFonteExpressoes() {
		if (fonteExpressoes == null) {
			setFonteExpressoes(new ArrayList<FonteExpressao>());
		}

		return this.fonteExpressoes;
	}

	/**
	 * <p>
	 * Define o valor do atributo fonteExpressoes
	 * </p>
	 * .
	 *
	 * @param fonteExpressoes
	 *            valor a ser atribuído
	 */
	public void setFonteExpressoes(List<FonteExpressao> fonteExpressoes) {
		this.fonteExpressoes = fonteExpressoes;
	}

	/**
	 * <p>
	 * Retorna o valor do atributo parametroFuncoes
	 * </p>
	 * .
	 *
	 * @return parametroFuncoes
	 */
	public List<ParametroFuncao> getParametroFuncoes() {
		if (parametroFuncoes == null) {
			setParametroFuncoes(new ArrayList<ParametroFuncao>());
		}

		return this.parametroFuncoes;
	}

	/**
	 * <p>
	 * Define o valor do atributo parametroFuncoes
	 * </p>
	 * .
	 *
	 * @param parametroFuncoes
	 *            valor a ser atribuído
	 */
	public void setParametroFuncoes(List<ParametroFuncao> parametroFuncoes) {
		this.parametroFuncoes = parametroFuncoes;
	}

	/**
	 * <p>
	 * Retorna o valor do atributo tipoExpressoesFuncao
	 * </p>
	 * .
	 *
	 * @return tipoExpressoesFuncao
	 */
	public List<TipoExpressao> getTipoExpressoesFuncao() {
		if (tipoExpressoesFuncao == null) {
			setTipoExpressoesFuncao(new ArrayList<TipoExpressao>());
		}

		return this.tipoExpressoesFuncao;
	}

	/**
	 * <p>
	 * Define o valor do atributo tipoExpressoesFuncao
	 * </p>
	 * .
	 *
	 * @param tipoExpressoesFuncao
	 *            valor a ser atribuído
	 */
	public void setTipoExpressoesFuncao(List<TipoExpressao> tipoExpressoesFuncao) {
		this.tipoExpressoesFuncao = tipoExpressoesFuncao;
	}

	/**
	 * <p>
	 * Retorna o valor do atributo funcoes
	 * </p>
	 * .
	 *
	 * @return funcoes
	 */
	public List<ParametroFormulaItem> getFuncoes() {
		if (funcoes == null) {
			setFuncoes(new ArrayList<ParametroFormulaItem>());
		}

		return this.funcoes;
	}

	/**
	 * <p>
	 * Define o valor do atributo funcoes
	 * </p>
	 * .
	 *
	 * @param funcoes
	 *            valor a ser atribuído
	 */
	public void setFuncoes(List<ParametroFormulaItem> funcoes) {
		this.funcoes = funcoes;
	}

	/**
	 * <p>
	 * Retorna o valor do atributo vinculoCalculo
	 * </p>
	 * .
	 *
	 * @return vinculoCalculo
	 */
	public VinculoCalculo getVinculoCalculo() {
		return this.vinculoCalculo;
	}

	/**
	 * <p>
	 * Define o valor do atributo vinculoCalculo
	 * </p>
	 * .
	 *
	 * @param vinculoCalculo
	 *            valor a ser atribuído
	 */
	public void setVinculoCalculo(VinculoCalculo vinculoCalculo) {
		this.vinculoCalculo = vinculoCalculo;
	}
	
	/**
	 * <p>Retorna o valor do atributo vinculoFiltro</p>.
	 *
	 * @return vinculoFiltro
	*/
	public VinculoCalculo getVinculoFiltro() {
		return this.vinculoFiltro;
	}

	/**
	 * <p>Define o valor do atributo vinculoFiltro</p>.
	 *
	 * @param vinculoFiltro valor a ser atribuído
	*/
	public void setVinculoFiltro(VinculoCalculo vinculoFiltro) {
		this.vinculoFiltro = vinculoFiltro;
	}

	/**
	 * <p>
	 * Retorna o valor do atributo indexAba
	 * </p>
	 * .
	 *
	 * @return indexAba
	 */
	public Integer getIndexAba() {
		return this.indexAba;
	}

	/**
	 * <p>
	 * Define o valor do atributo indexAba
	 * </p>
	 * .
	 *
	 * @param indexAba
	 *            valor a ser atribuído
	 */
	public void setIndexAba(Integer indexAba) {
		this.indexAba = indexAba;
	}

	/**
	 * <p>
	 * Retorna o valor do atributo coApf
	 * </p>
	 * .
	 *
	 * @return coApf
	 */
	public String getCoApf() {
		return this.coApf;
	}

	/**
	 * <p>
	 * Define o valor do atributo coApf
	 * </p>
	 * .
	 *
	 * @param coApf
	 *            valor a ser atribuído
	 */
	public void setCoApf(String coApf) {
		this.coApf = coApf;
	}

	/**
	 * <p>
	 * Retorna o valor do atributo empreendimentos
	 * </p>
	 * .
	 *
	 * @return empreendimentos
	 */
	public List<Empreendimento> getEmpreendimentos() {
		if (empreendimentos == null) {
			setEmpreendimentos(new ArrayList<Empreendimento>());
		}
		
		return this.empreendimentos;
	}

	/**
	 * <p>
	 * Define o valor do atributo empreendimentos
	 * </p>
	 * .
	 *
	 * @param empreendimentos
	 *            valor a ser atribuído
	 */
	public void setEmpreendimentos(List<Empreendimento> empreendimentos) {
		this.empreendimentos = empreendimentos;
	}

	/**
	 * <p>
	 * Retorna o valor do atributo unidades
	 * </p>
	 * .
	 *
	 * @return unidades
	 */
	public List<UnidadeHabitacional> getUnidades() {
		if (unidades == null) {
			setUnidades(new ArrayList<UnidadeHabitacional>());
		}
		
		return this.unidades;
	}

	/**
	 * <p>
	 * Define o valor do atributo unidades
	 * </p>
	 * .
	 *
	 * @param unidades
	 *            valor a ser atribuído
	 */
	public void setUnidades(List<UnidadeHabitacional> unidades) {
		this.unidades = unidades;
	}

	/**
	 * <p>
	 * Retorna o valor do atributo tipologias
	 * </p>
	 * .
	 *
	 * @return tipologias
	 */
	public List<Tipologia> getTipologias() {
		if (tipologias == null) {
			setTipologias(new ArrayList<Tipologia>());
		}
		
		return this.tipologias;
	}

	/**
	 * <p>
	 * Define o valor do atributo tipologias
	 * </p>
	 * .
	 *
	 * @param tipologias
	 *            valor a ser atribuído
	 */
	public void setTipologias(List<Tipologia> tipologias) {
		this.tipologias = tipologias;
	}

	/**
	 * <p>
	 * Retorna o valor do atributo vinculos
	 * </p>
	 * .
	 *
	 * @return vinculos
	 */
	public List<VinculoCalculo> getVinculos() {
		if (vinculos == null) {
			setVinculos(new ArrayList<VinculoCalculo>());
		}
		
		return this.vinculos;
	}

	/**
	 * <p>
	 * Define o valor do atributo vinculos
	 * </p>
	 * .
	 *
	 * @param vinculos
	 *            valor a ser atribuído
	 */
	public void setVinculos(List<VinculoCalculo> vinculos) {
		this.vinculos = vinculos;
	}

	/**
	 * <p>
	 * Retorna o valor do atributo formulas
	 * </p>
	 * .
	 *
	 * @return formulas
	 */
	public List<Formula> getFormulas() {
		if (formulas == null) {
			setFormulas(new ArrayList<Formula>());
		}
		
		return this.formulas;
	}

	/**
	 * <p>
	 * Define o valor do atributo formulas
	 * </p>
	 * .
	 *
	 * @param formulas
	 *            valor a ser atribuído
	 */
	public void setFormulas(List<Formula> formulas) {
		this.formulas = formulas;
	}

	public enum TipoPagina {
		PARAMETRIZACAO, VINCULO
	}
}