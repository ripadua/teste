package br.gov.caixa.siacg.view.mb;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.logging.Logger;

import javax.annotation.PostConstruct;
import javax.ejb.EJB;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;
import javax.faces.context.FacesContext;
import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.net.ftp.FTPClient;
import org.primefaces.event.SelectEvent;

import br.gov.caixa.pedesgo.arquitetura.controlador.AbstractBean;
import br.gov.caixa.pedesgo.arquitetura.controlador.ManutencaoBean;
import br.gov.caixa.pedesgo.arquitetura.util.LogCefUtil;
import br.gov.caixa.pedesgo.arquitetura.util.UsuarioUtil;
import br.gov.caixa.pedesgo.arquitetura.util.UtilObjeto;
import br.gov.caixa.siacg.model.domain.Empreendimento;
import br.gov.caixa.siacg.model.domain.Relatorio;
import br.gov.caixa.siacg.model.vo.RelatorioConciliacaoVO;
import br.gov.caixa.siacg.model.vo.RelatorioProspectoRecebidoVO;
import br.gov.caixa.siacg.service.RecebidoService;
import br.gov.caixa.siacg.service.RelatorioService;
import br.gov.caixa.siacg.view.form.RelatorioVisao;
import net.sf.jasperreports.engine.JRException;
import net.sf.jasperreports.engine.JasperFillManager;
import net.sf.jasperreports.engine.JasperPrint;
import net.sf.jasperreports.engine.data.JRBeanCollectionDataSource;
import net.sf.jasperreports.engine.export.JRXlsExporter;
import net.sf.jasperreports.engine.export.JRXlsExporterParameter;

/**
 * <p>
 * RelatorioMB.
 * </p>
 * <p>
 * Descrição: Classe bean responsável por armazenar os metodos do menu relatorio
 * </p>
 * <br>
 * <b>Empresa:</b> Cef - Caixa Econômica Federal
 *
 * @author Waltenes Junior
 * @version 1.0
 */
@SessionScoped
@ManagedBean
public class RelatorioMB extends ManutencaoBean<Relatorio> {

	/** Atributo serialVersionUID. */
	private static final long serialVersionUID = 1429065977770500653L;

	/** Atributo DIRETORIO_PAGINAS. */
	private static final String DIRETORIO_PAGINAS = "/pages/";

	/** Atributo service. */
	@EJB
	private transient RelatorioService service;
	
	/** Atributo service. */
	@EJB
	private transient RecebidoService recebidoService;

	/** Atributo visao. */
	private transient RelatorioVisao visao;

	/** Atributo LOG. */
	private static final Logger LOG = Logger.getLogger(RelatorioMB.class.getName());

	/** arquivoSelecionado. */
	private String arquivoSelecionado;
	
	/** DIRETORIO_FTP. */
	private static final String DIRETORIO_FTP = "siacg.diretorio";
	
	/** HOST_FTP. */
	private static final String HOST_FTP = "siacg.host.ftp";
	
	/** SENHA_FTP. */
	private static final String SENHA_FTP = "siacg.senha.ftp";
	
	/** USER_FTP. */
	private static final String USER_FTP = "siacg.user.ftp";
	
	/** DIRETORIO_FTP_APETITE_RISCO*/
	private static final String DIRETORIO_FTP_APETITE_RISCO_APOS_2018 = "siacg.diretorio.apetite.risco";

	/** DIRETORIO_FTP_APETITE_RISCO*/
	private static final String DIRETORIO_FTP_APETITE_RISCO_ATE_2018 = "siacg.diretorio.apetite.risco.ate.2018";
	
	/** arquivoSelecionadoDiretorioApetiteRiscoAte2018. */
	private String arquivoSelecionadoDiretorioApetiteRiscoAte2018;
	
	/** arquivoSelecionadoDiretorioApetiteRiscoApos2018. */
	private String arquivoSelecionadoDiretorioApetiteRiscoApos2018;
	
	/**
	 * @see br.gov.caixa.pedesgo.arquitetura.controlador.AbstractBean#carregar()
	 */
	@PostConstruct
	@Override
	protected void carregar() {

		this.getVisao().setLista(new ArrayList<Relatorio>());

		for (final Relatorio relatorio : service.listar()) {

			relatorio.setDeEndereco(this.service.substituirTagUrl(relatorio.getDeEndereco()));
			relatorio.setContemPermissao(
					UsuarioUtil.contemPermissao(relatorio.getDeFuncionalidade(), relatorio.getDeAcao(), null, null));

			if (relatorio.isContemPermissao() && !relatorio.getDeRelatorio().equals("Aplicacao financeira bloqueada") 
					&& !relatorio.getDeFuncionalidade().equals("rel_apetite_risco")
					&& !relatorio.getDeFuncionalidade().equals("rel_apetite_risco_2018")) {
				this.getVisao().getLista().add(relatorio);
			}
		}
	}

	/**
	 * @see br.gov.caixa.pedesgo.arquitetura.controlador.AbstractBean#getTelaConsulta()
	 */
	@Override
	public String getTelaConsulta() {
		return RelatorioMB.DIRETORIO_PAGINAS + this.getPrefixoCasoDeUso() + AbstractBean.SUFIXO_TELA_CONSULTA;
	}

	/**
	 * @see br.gov.caixa.pedesgo.arquitetura.controlador.AbstractBean#getPrefixoCasoDeUso()
	 */
	@Override
	protected String getPrefixoCasoDeUso() {
		return "relatorio";
	}

	/**
	 * @see br.gov.caixa.pedesgo.arquitetura.controlador.AbstractBean#getService()
	 */
	@SuppressWarnings("unchecked")
	@Override
	public RelatorioService getService() {
		return this.service;
	}

	/**
	 * @see br.gov.caixa.pedesgo.arquitetura.controlador.AbstractBean#getVisao()
	 */
	@Override
	public RelatorioVisao getVisao() {
		if (!UtilObjeto.isReferencia(this.visao)) {
			this.visao = new RelatorioVisao();
		}

		return this.visao;
	}

	/**
	 * <p>
	 * Retorna o valor do atributo arquivoSelecionado
	 * </p>
	 * .
	 *
	 * @return arquivoSelecionado
	 */
	public String getArquivoSelecionado() {
		return this.arquivoSelecionado;
	}

	/**
	 * <p>
	 * Define o valor do atributo arquivoSelecionado
	 * </p>
	 * .
	 *
	 * @param arquivoSelecionado
	 *            valor a ser atribuído
	 */
	public void setArquivoSelecionado(final String arquivoSelecionado) {
		this.arquivoSelecionado = arquivoSelecionado;
	}
	
	/**
	 * <p>
	 * Lista arquivos do diretorio FTP
	 * </p>
	 * .
	 *
	 * @return lista dos nomes dos arquivos
	 */
	public String[] listarDiretorio() {
		String[] files = null;
		final FTPClient f = new FTPClient();	
		try {
			f.connect(System.getProperty(RelatorioMB.HOST_FTP));
			f.login(System.getProperty(RelatorioMB.USER_FTP), System.getProperty(RelatorioMB.SENHA_FTP));
			f.changeWorkingDirectory(System.getProperty(RelatorioMB.DIRETORIO_FTP));
			files = f.listNames();
		} catch  (Exception e) {
			RelatorioMB.LOG.fine(e.getMessage());
			LogCefUtil.error(e);
		} finally {
			try {
				f.disconnect();
			} catch(Exception ex) {
				RelatorioMB.LOG.fine(ex.getMessage());
				LogCefUtil.error(ex);
			}
		}


		return files;
	}

	/**
	 * <p>
	 * Lista arquivos do diretorio FTP
	 * </p>
	 * .
	 *
	 * @return realiza download de arquivo selecionado na tela
	 */
	public void downloadArquivo() {
		final FTPClient f = new FTPClient();
		try {			
			f.connect(System.getProperty(RelatorioMB.HOST_FTP));
			f.login(System.getProperty(RelatorioMB.USER_FTP), System.getProperty(RelatorioMB.SENHA_FTP));
			f.changeWorkingDirectory(System.getProperty(RelatorioMB.DIRETORIO_FTP));
			if(this.arquivoSelecionado != null) {
				this.getResponse().setContentType("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet");
				this.getResponse().addHeader("Content-disposition", "attachment; filename=" + this.arquivoSelecionado);
				f.setFileType(FTPClient.BINARY_FILE_TYPE);
				f.retrieveFile(this.arquivoSelecionado, this.getResponse().getOutputStream());				
				this.getResponse().getOutputStream().flush();
				this.getResponse().getOutputStream().close();
				FacesContext.getCurrentInstance().responseComplete();				
			}
		} catch (final Exception e) {
			RelatorioMB.LOG.fine(e.getMessage());
			LogCefUtil.error(e);
		} finally {
			try {
				f.disconnect();
			} catch(Exception ex) {
				RelatorioMB.LOG.fine(ex.getMessage());
				LogCefUtil.error(ex);
			}
		}
	}
	
	/**
	 * <p>
	 * Busca dados do FTP
	 * </p>
	 * .
	 *
	 * @return dados do FTP
	 */	
	public Relatorio buscaDadosFtp() {
		return service.retornaEndereco("rel_aplicacao_financ_blq");
	}
	
	/**
	 * <p>Método responsável por verificar se a quantidade mínima de parâmetros para geração do relatório foi informada</p>.
	 *
	 * @return TRUE caso tenha sido informado parâmetro, FALSE caso contrário. 
	 */
	private boolean isRelatorioProspectoRecebidoValido() {
	    return !this.getVisao().getCodApf().isEmpty() || this.getVisao().getNuEmpreendimento() != null || this.getVisao().getCpfCnpj() != null;
	}	
	
	/**
	 * <p>
	 * Relatorio de Prospecto e recebidos.
	 * </p>
	 * .
	 *
	 * @return relatorio formato xls.
	 */
	public void callRelatorio() {
		if(isRelatorioProspectoRecebidoValido()) {			
			List<RelatorioProspectoRecebidoVO> dadosRelatorio = this.montarCampos();
			this.geraRelatorio(dadosRelatorio, "/reports/prospectoRecebido.jasper", "ProspetoXrecebidos.xls");
			
			this.getVisao().setCodApf("");
		    	this.getVisao().setCpfCnpj("");
		    	this.getVisao().setNuEmpreendimento(null);
		} else {
			this.adicionaMensagemDeAlerta("Preencha ao menos um campo para gerar o relatório.");
		}
	}

	@SuppressWarnings("all")
	private void geraRelatorio(List<?> dadosRelatorio, String pathJasper, String filename) {
	    if(!dadosRelatorio.isEmpty()) {
	    	final JRBeanCollectionDataSource beanCollectionDataSource = new JRBeanCollectionDataSource(dadosRelatorio);
	    	Map<String, Object> map = new HashMap<>();

	    	FacesContext context = FacesContext.getCurrentInstance();

	    	HttpServletResponse response = (HttpServletResponse) context.getExternalContext().getResponse(); 
	    	try {
	    	    JasperPrint impressao = JasperFillManager.fillReport(getClass().getResourceAsStream(pathJasper), map,
	    				beanCollectionDataSource);

	    		JRXlsExporter exporter = new JRXlsExporter();   
	    		ByteArrayOutputStream xlsReport = new ByteArrayOutputStream();   
	    		exporter.setParameter(JRXlsExporterParameter.JASPER_PRINT, impressao);  
	    		exporter.setParameter(JRXlsExporterParameter.OUTPUT_STREAM, xlsReport);   
	    		exporter.setParameter(JRXlsExporterParameter.IS_REMOVE_EMPTY_SPACE_BETWEEN_ROWS, Boolean.TRUE);   
	    		exporter.setParameter(JRXlsExporterParameter.IS_WHITE_PAGE_BACKGROUND, Boolean.TRUE);   
	    		exporter.setParameter(JRXlsExporterParameter.IS_ONE_PAGE_PER_SHEET, Boolean.TRUE);

	    		exporter.exportReport();   
	    		byte[] bytes = xlsReport.toByteArray();   
	    		response.setContentType("application/vnd.ms-excel");   
	    		response.setHeader("Content-disposition", "attachment; filename="+ filename);
	    		response.setContentLength(bytes.length);   
	    		xlsReport.close();   
	    		ServletOutputStream ouputStream = response.getOutputStream();   
	    		ouputStream.write(bytes, 0, bytes.length);   
	    		ouputStream.flush();   
	    		ouputStream.close(); 	

	    	} catch (final JRException | IOException e) {
	    		RelatorioMB.LOG.fine(e.getMessage());
	    		super.adicionaMensagemDeErro("Erro ao gerar o relatório!");
	    		LogCefUtil.error(e);
	    	}
	    } else {
	    	this.adicionaMensagemDeAlerta("Parâmetros apresentados não geraram registros.");
	    }
	}
	
	/**
	 * <p>
	 * Busca dados para relatorio de Prospecto x Recebidos.
	 * </p>
	 *
	 * @return Lista de RelatorioProspectoRecebidoVO.
	 */
	public List<RelatorioProspectoRecebidoVO> montarCampos() {
		return recebidoService.relatorioProspectoRecebidos(this.getVisao().getCodApf(), this.getVisao().getNuEmpreendimento(), this.getVisao().getCpfCnpj());

	}
	
	/**
	 * <p>
	 * Limpar filtro relatorio prospectos recebidos
	 * </p>
	 */
	public void limparFiltro () {
		this.visao = new RelatorioVisao();
	}
	
	/**
	 * 
	 * <p>Método responsável por gerar o Relatório de Conciliação em Excel (.xls)</p>.
	 *
	 * @author Mábio Barbosa
	 *
	 */
	public void callRelatorioConciliacao() {
	    List<RelatorioConciliacaoVO> lista = this.recebidoService.relatorioConciliacao(this.getVisao().getNuEmpreendimento());
	    this.geraRelatorio(lista, "/reports/conciliacao_recebido.jasper", "Conciliacao_" + System.currentTimeMillis() + ".xls");
	    
	    this.getVisao().setNuEmpreendimento(null);
	}
	
	/**
	 * 
	 * <p>Método responsável por obter o item selecionado no elemento AutoComplete de Empreendimento</p>.
	 *
	 * @author Mábio Barbosa
	 *
	 * @param event {@link SelectEvent}
	 */
	public void onSelectEmpreendimentoFiltro(SelectEvent event) {
	    if (event.getObject() instanceof Empreendimento) {
		this.getVisao().setNuEmpreendimento(((Empreendimento) event.getObject()).getNuEmpreendimento());
	    }
	}
	

	/**
	 * <p>
	 * Lista arquivos do diretorio FTP
	 * </p>
	 * .
	 *
	 * @return lista dos nomes dos arquivos
	 */
	public String[] listarDiretorioApetiteRisco() {
		String[] files = null;
		final FTPClient ftp = new FTPClient();	
				
		try {
			ftp.connect(System.getProperty(RelatorioMB.HOST_FTP));
			ftp.login(System.getProperty(RelatorioMB.USER_FTP), System.getProperty(RelatorioMB.SENHA_FTP));
			ftp.changeWorkingDirectory(System.getProperty(RelatorioMB.DIRETORIO_FTP_APETITE_RISCO_APOS_2018));
			files = ftp.listNames();
		} catch  (Exception e) {
			RelatorioMB.LOG.fine(e.getMessage());
			LogCefUtil.error(e);
		} finally {
			try {
				ftp.disconnect();
			} catch(Exception ex) {
				RelatorioMB.LOG.fine(ex.getMessage());
				LogCefUtil.error(ex);
			}
		}
		return files;
	}

	/**
	 * <p>
	 * Lista arquivos do diretorio FTP
	 * </p>
	 * .
	 *
	 * @return realiza download de arquivo selecionado na tela
	 */
	public void downloadArquivoApetiteRisco() {
		final FTPClient ftp = new FTPClient();
		try {			
			ftp.connect(System.getProperty(RelatorioMB.HOST_FTP));
			ftp.login(System.getProperty(RelatorioMB.USER_FTP), System.getProperty(RelatorioMB.SENHA_FTP));
			ftp.changeWorkingDirectory(System.getProperty(RelatorioMB.DIRETORIO_FTP_APETITE_RISCO_APOS_2018));
			if(this.arquivoSelecionadoDiretorioApetiteRiscoApos2018 != null) {
				this.getResponse().setContentType("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet");
				this.getResponse().addHeader("Content-disposition", "attachment; filename=" + this.arquivoSelecionadoDiretorioApetiteRiscoApos2018);
				ftp.setFileType(FTPClient.BINARY_FILE_TYPE);
				ftp.retrieveFile(this.arquivoSelecionadoDiretorioApetiteRiscoApos2018, this.getResponse().getOutputStream());				
				this.getResponse().getOutputStream().flush();
				this.getResponse().getOutputStream().close();
				FacesContext.getCurrentInstance().responseComplete();
							
			}
		} catch (final Exception e) {
			RelatorioMB.LOG.fine(e.getMessage());
			LogCefUtil.error(e);
		} finally {
			try {
				ftp.disconnect();
			} catch(Exception ex) {
				RelatorioMB.LOG.fine(ex.getMessage());
				LogCefUtil.error(ex);
			}
		}
	}
	
	
	/**
	 * <p>
	 * Lista arquivos do diretorio FTP
	 * </p>
	 * .
	 *
	 * @return lista dos nomes dos arquivos
	 */
	public String[] listarDiretorioApetiteRiscoAte2018() {
		
		String[] files = null;
		final FTPClient ftp = new FTPClient();	
				
		try {
			ftp.connect(System.getProperty(RelatorioMB.HOST_FTP));
			ftp.login(System.getProperty(RelatorioMB.USER_FTP), System.getProperty(RelatorioMB.SENHA_FTP));
			ftp.changeWorkingDirectory(System.getProperty(RelatorioMB.DIRETORIO_FTP_APETITE_RISCO_ATE_2018));
			files = ftp.listNames();
		} catch  (Exception e) {
			RelatorioMB.LOG.fine(e.getMessage());
			LogCefUtil.error(e);
		} finally {
			try {
				ftp.disconnect();
			} catch(Exception ex) {
				RelatorioMB.LOG.fine(ex.getMessage());
				LogCefUtil.error(ex);
			}
		}
		return files;
	}

	/**
	 * <p>
	 * Lista arquivos do diretorio FTP
	 * </p>
	 * .
	 *
	 * @return realiza download de arquivo selecionado na tela
	 */
	public void downloadArquivoApetiteRiscoAte2018() {
		final FTPClient ftp = new FTPClient();
		try {			
			ftp.connect(System.getProperty(RelatorioMB.HOST_FTP));
			ftp.login(System.getProperty(RelatorioMB.USER_FTP), System.getProperty(RelatorioMB.SENHA_FTP));
			ftp.changeWorkingDirectory(System.getProperty(RelatorioMB.DIRETORIO_FTP_APETITE_RISCO_ATE_2018));
			if(this.arquivoSelecionadoDiretorioApetiteRiscoAte2018 != null) {
				this.getResponse().setContentType("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet");
				this.getResponse().addHeader("Content-disposition", "attachment; filename=" + this.arquivoSelecionadoDiretorioApetiteRiscoAte2018);
				ftp.setFileType(FTPClient.BINARY_FILE_TYPE);
				ftp.retrieveFile(this.arquivoSelecionadoDiretorioApetiteRiscoAte2018, this.getResponse().getOutputStream());				
				this.getResponse().getOutputStream().flush();
				this.getResponse().getOutputStream().close();
				FacesContext.getCurrentInstance().responseComplete();
				
			}
		} catch (final Exception e) {
			RelatorioMB.LOG.fine(e.getMessage());
			LogCefUtil.error(e);
		} finally {
			try {
				ftp.disconnect();
			} catch(Exception ex) {
				RelatorioMB.LOG.fine(ex.getMessage());
				LogCefUtil.error(ex);
			}
		}
		
	}

	public String getArquivoSelecionadoDiretorioApetiteRiscoAte2018() {
		return arquivoSelecionadoDiretorioApetiteRiscoAte2018;
	}

	public void setArquivoSelecionadoDiretorioApetiteRiscoAte2018(String arquivoSelecionadoDiretorioApetiteRiscoAte2018) {
		this.arquivoSelecionadoDiretorioApetiteRiscoAte2018 = arquivoSelecionadoDiretorioApetiteRiscoAte2018;
	}

	public String getArquivoSelecionadoDiretorioApetiteRiscoApos2018() {
		return arquivoSelecionadoDiretorioApetiteRiscoApos2018;
	}

	public void setArquivoSelecionadoDiretorioApetiteRiscoApos2018(String arquivoSelecionadoDiretorioApetiteRiscoApos2018) {
		this.arquivoSelecionadoDiretorioApetiteRiscoApos2018 = arquivoSelecionadoDiretorioApetiteRiscoApos2018;
	}
		
}
