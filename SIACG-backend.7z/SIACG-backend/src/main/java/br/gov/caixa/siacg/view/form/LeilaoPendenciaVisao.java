/*
 * Copyright (c) 2021 Caixa Econômica Federal. Todos os direitos
 * reservados.
 *
 * Caixa Econômica Federal - SIACG - Sistema de Crédito Rural
 *
 * Este software foi desenvolvido sob demanda da CAIXA e está
 * protegido por leis de direitos autorais e tratados internacionais. As
 * condições de cópia e utilização do todo ou partes dependem de autorização da
 * empresa. Cópias não são permitidas sem expressa autorização. Não pode ser
 * comercializado ou utilizado para propósitos particulares.
 *
 * Uso exclusivo da Caixa Econômica Federal. A reprodução ou distribuição não
 * autorizada deste programa ou de parte dele, resultará em punições civis e
 * criminais e os infratores incorrem em sanções previstas na legislação em
 * vigor.
 *
 * Histórico do TFS:
 *
 * LastChangedRevision: $Revision$
 * LastChangedBy: $Author$
 * LastChangedDate: $Date$
 *
 * HeadURL: $HeadURL$
 *
 */
package br.gov.caixa.siacg.view.form;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import br.gov.caixa.siacg.model.domain.leilao.Leilao;
import br.gov.caixa.siacg.model.domain.leilao.LeilaoCampoPendencia;
import br.gov.caixa.siacg.model.domain.leilao.LeilaoCampoPendenciaValor;
import br.gov.caixa.siacg.model.domain.leilao.LeilaoPendencia;
import br.gov.caixa.siacg.model.domain.leilao.TipoPendenciaLeilao;

/**
 * <p>
 * LeilaoPendenciaVisao
 * </p>
 *
 * <p>
 * Descrição: Descrição do tipo
 * </p>
 *
 * <br>
 * <b>Empresa:</b> Cef - Caixa Econômica Federal
 *
 *
 * @author gerusa.soares
 *
 * @version 1.0
 */
public class LeilaoPendenciaVisao extends TemplateVisao<Leilao> {

    /** Atributo serialVersionUID. */
    private static final long serialVersionUID = 1L;

    private LeilaoPendencia pendencia;

    private List<TipoPendenciaLeilao> listaTipoPendenciaLeilao;
    private List<LeilaoCampoPendencia> listaCampoPendencia;
    private List<LeilaoCampoPendenciaValor> listaCampoPendenciaValor;

    private Map<TipoPendenciaLeilao, List<LeilaoCampoPendencia>> mapCampoPendencia;
    private Map<LeilaoCampoPendencia, List<LeilaoCampoPendenciaValor>> mapCampoPendenciaValor;

    private boolean icExibirTextArea = false;
    private String deRespostaComboIcAberto;

    public LeilaoPendencia getPendencia() {
	if (this.pendencia == null) {
	    this.pendencia = new LeilaoPendencia();
	    this.pendencia.setTipoPendenciaLeilao(new TipoPendenciaLeilao());
	}
	return this.pendencia;
    }

    public void setPendencia(final LeilaoPendencia pendencia) {
	this.pendencia = pendencia;
    }

    public List<TipoPendenciaLeilao> getListaTipoPendenciaLeilao() {
	return this.listaTipoPendenciaLeilao;
    }

    public void setListaTipoPendenciaLeilao(final List<TipoPendenciaLeilao> listaTipoPendenciaLeilao) {
	this.listaTipoPendenciaLeilao = listaTipoPendenciaLeilao;
    }

    public List<LeilaoCampoPendencia> getListaCampoPendencia() {
	return this.listaCampoPendencia;
    }

    public void setListaCampoPendencia(final List<LeilaoCampoPendencia> listaCampoPendencia) {
	this.listaCampoPendencia = listaCampoPendencia;
    }

    public List<LeilaoCampoPendenciaValor> getListaCampoPendenciaValor() {
	return this.listaCampoPendenciaValor;
    }

    public void setListaCampoPendenciaValor(final List<LeilaoCampoPendenciaValor> listaCampoPendenciaValor) {
	this.listaCampoPendenciaValor = listaCampoPendenciaValor;
    }

    public Map<TipoPendenciaLeilao, List<LeilaoCampoPendencia>> getMapCampoPendencia() {
	if (this.mapCampoPendencia == null) {
	    this.mapCampoPendencia = new HashMap<>();
	}
	return this.mapCampoPendencia;
    }

    public void setMapCampoPendencia(final Map<TipoPendenciaLeilao, List<LeilaoCampoPendencia>> mapCampoPendencia) {
	this.mapCampoPendencia = mapCampoPendencia;
    }

    public Map<LeilaoCampoPendencia, List<LeilaoCampoPendenciaValor>> getMapCampoPendenciaValor() {
	if (this.mapCampoPendenciaValor == null) {
	    this.mapCampoPendenciaValor = new HashMap<>();
	}
	return this.mapCampoPendenciaValor;
    }

    public void setMapCampoPendenciaValor(final Map<LeilaoCampoPendencia, List<LeilaoCampoPendenciaValor>> mapCampoPendenciaValor) {
	this.mapCampoPendenciaValor = mapCampoPendenciaValor;
    }

    public boolean isIcExibirTextArea() {
	return this.icExibirTextArea;
    }

    public void setIcExibirTextArea(final boolean icExibirTextArea) {
	this.icExibirTextArea = icExibirTextArea;
    }

    public String getDeRespostaComboIcAberto() {
	return this.deRespostaComboIcAberto;
    }

    public void setDeRespostaComboIcAberto(final String deRespostaComboIcAberto) {
	this.deRespostaComboIcAberto = deRespostaComboIcAberto;
    }

}
