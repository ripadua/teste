package br.gov.caixa.siacg.comum.to;

import java.math.BigInteger;
import java.util.Date;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

@JsonIgnoreProperties(ignoreUnknown = true)
public class AvaliacaoTO implements Comparable<AvaliacaoTO>{

	private BigInteger identificacaoAvaliacao;
	private String ordemServico;
	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "dd/MM/yyyy", locale = "pt-BR", timezone = "Brazil/East")
	private Date dataAbertura;
	@JsonProperty(value="imovel")
	private ImovelTO imovel;
	
	@JsonIgnoreProperties(ignoreUnknown = true)
	private String codigoSituacaoAvaliacao;
	
	@JsonIgnoreProperties(ignoreUnknown = true)
	private String descricaoSituacaoAvaliacao;
	
	public AvaliacaoTO() {}
	
	public BigInteger getIdentificacaoAvaliacao() {
		return identificacaoAvaliacao;
	}

	public void setIdentificacaoAvaliacao(BigInteger identificacaoAvaliacao) {
		this.identificacaoAvaliacao = identificacaoAvaliacao;
	}

	public String getOrdemServico() {
		return ordemServico;
	}
	public void setOrdemServico(String ordemServico) {
		this.ordemServico = ordemServico;
	}
	public Date getDataAbertura() {
		return dataAbertura;
	}
	public void setDataAbertura(Date dataAbertura) {
		this.dataAbertura = dataAbertura;
	}
	public ImovelTO getImovel() {
		return imovel;
	}
	public void setImovel(ImovelTO imovel) {
		this.imovel = imovel;
	}

	public String getCodigoSituacaoAvaliacao() {
		return codigoSituacaoAvaliacao;
	}

	public void setCodigoSituacaoAvaliacao(String codigoSituacaoAvaliacao) {
		this.codigoSituacaoAvaliacao = codigoSituacaoAvaliacao;
	}

	public String getDescricaoSituacaoAvaliacao() {
		return descricaoSituacaoAvaliacao;
	}

	public void setDescricaoSituacaoAvaliacao(String descricaoSituacaoAvaliacao) {
		this.descricaoSituacaoAvaliacao = descricaoSituacaoAvaliacao;
	}

	@Override
	public int compareTo(AvaliacaoTO o) {
		return  o.getIdentificacaoAvaliacao().compareTo(this.identificacaoAvaliacao);
	}
	
}
