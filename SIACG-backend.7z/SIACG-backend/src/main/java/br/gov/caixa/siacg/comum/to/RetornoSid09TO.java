/*
 * Copyright (c) 2016 Caixa Econômica Federal. Todos os direitos
 * reservados.
 *
 * Caixa Econômica Federal - SIACG_dev
 *
 * Este software foi desenvolvido sob demanda da CAIXA e está
 * protegido por leis de direitos autorais e tratados internacionais. As
 * condições de cópia e utilização do todo ou partes dependem de autorização da
 * pessoa. Cópias não são permitidas sem expressa autorização. Não pode ser
 * comercializado ou utilizado para propósitos particulares.
 *
 * Uso exclusivo da Caixa Econômica Federal. A reprodução ou distribuição não
 * autorizada deste programa ou de parte dele, resultará em punições civis e
 * criminais e os infratores incorrem em sanções previstas na legislação em
 * vigor.
 *
 * Histórico do Subversion:
 *
 * LastChangedRevision: $Revision$
 * LastChangedBy: $Author$
 * LastChangedDate: $Date$
 *
 * HeadURL: $HeadURL$
 *
 */
package br.gov.caixa.siacg.comum.to;

import java.util.ArrayList;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * <p>
 * RetornoSid09TO.
 * </p>
 * <p>
 * Descrição: TO para representar o retorno da consulta de contas do SID 09).
 * </p>
 * <br>
 * <b>Empresa:</b> Cef - Caixa Econômica Federal
 *
 * @author f538462
 * @version 1.0
 */
@JsonIgnoreProperties(ignoreUnknown = true)
public class RetornoSid09TO {

    public static final String CODIGO_SUCESSO = "1";
    

    @JsonProperty(value = "contas")
    private List<ContaSid09TO> contas;
    
    private NegocialSid00TO negocial;
    
    @JsonProperty(value = "controle_paginacao")
    private ControlePaginacaoTO controlePaginacao;

    public List<ContaSid09TO> getContas() {
	if (contas == null) {
	    contas = new ArrayList<>();
	}
	return contas;
    }

    public void setContas(List<ContaSid09TO> contas) {
	this.contas = contas;
    }

    /**
     * <p>Retorna o valor do atributo negocial</p>.
     *
     * @return negocial
    */
    public NegocialSid00TO getNegocial() {
	if (this.negocial == null) {
	    this.negocial = new NegocialSid00TO();
	}
        return this.negocial;
    }

    /**
     * <p>Define o valor do atributo negocial</p>.
     *
     * @param negocial valor a ser atribuído
    */
    public void setNegocial(NegocialSid00TO negocial) {
        this.negocial = negocial;
    }

    public ControlePaginacaoTO getControlePaginacao() {
        return controlePaginacao;
    }

    public void setControlePaginacao(ControlePaginacaoTO controlePaginacao) {
        this.controlePaginacao = controlePaginacao;
    }
    
    
}