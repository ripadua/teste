/*
 * Copyright (c) 2016 Caixa Econômica Federal. Todos os direitos
 * reservados.
 *
 * Caixa Econômica Federal - SIACG_dev
 *
 * Este software foi desenvolvido sob demanda da CAIXA e está
 * protegido por leis de direitos autorais e tratados internacionais. As
 * condições de cópia e utilização do todo ou partes dependem de autorização da
 * pessoa. Cópias não são permitidas sem expressa autorização. Não pode ser
 * comercializado ou utilizado para propósitos particulares.
 *
 * Uso exclusivo da Caixa Econômica Federal. A reprodução ou distribuição não
 * autorizada deste programa ou de parte dele, resultará em punições civis e
 * criminais e os infratores incorrem em sanções previstas na legislação em
 * vigor.
 *
 * Histórico do Subversion:
 *
 * LastChangedRevision: $Revision$
 * LastChangedBy: $Author$
 * LastChangedDate: $Date$
 *
 * HeadURL: $HeadURL$
 *
 */
package br.gov.caixa.siacg.comum.to;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * <p>
 * ErroBloqueioDesbloqueioSifixTO.
 * </p>
 * <p>
 * Descrição: TO  para representar a propriedade de retorno Erro no Bloqueio/Desbloqueio do sistema Sifix.
 * </p>
 * <br>
 * <b>Empresa:</b> Cef - Caixa Econômica Federal
 *
 * @author Leandro Severino
 * @version 1.0
 */
@JsonIgnoreProperties(ignoreUnknown = true)
public class ErroBloqueioDesbloqueioSifixTO {

    /** negocial. */
	@JsonProperty(value="negocial")
    private NegocialSifixTO negocial;

    /** integracao. */
	@JsonProperty(value="integracao")
    private IntegracaoSifixTO integracao;

    /**
     * Construtor.
     *
     */
    public ErroBloqueioDesbloqueioSifixTO() {

    }

    /**
     * Construtor.
     *
     * @param negocial
     *            valor a ser atribuido
     * @param integracao
     *            valor a ser atribuido 
     */
    public ErroBloqueioDesbloqueioSifixTO(final NegocialSifixTO negocial, final IntegracaoSifixTO integracao) {
        this.negocial = negocial;
        this.integracao = integracao;        
    }

    /**
     * Retorna o valor do atributo negocial.
     *
     * @return negocial
     */
    public NegocialSifixTO getNegocial() {
        return this.negocial;
    }

    /**
     * Define o valor do atributo negocial.
     *
     * @param negocial
     *            valor a ser atribuído
     */
    public void setNegocial(final NegocialSifixTO negocial) {
        this.negocial = negocial;
    }
    
    /**
     * Retorna o valor do atributo integracao.
     *
     * @return integracao
     */
    public IntegracaoSifixTO getIntegracao() {
        return this.integracao;
    }

    /**
     * Define o valor do atributo integracao.
     *
     * @param integracao
     *            valor a ser atribuído
     */
    public void setIntegracao(final IntegracaoSifixTO integracao) {
        this.integracao = integracao;
    }
    
}
