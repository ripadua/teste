/**
 * Copyright (c) 2021 Caixa Econômica Federal. Todos os direitos
 * reservados.
 *
 * Caixa Econômica Federal - SIACG - Sistema de Crédito Rural
 *
 * Este software foi desenvolvido sob demanda da CAIXA e está
 * protegido por leis de direitos autorais e tratados internacionais. As
 * condições de cópia e utilização do total ou partes dependem de autorização da
 * empresa. Cópias não são permitidas sem expressa autorização. Não pode ser
 * comercializado ou utilizado para propósitos particulares.
 *
 * Uso exclusivo da Caixa Econômica Federal. A reprodução ou distribuição não
 * autorizada deste programa ou de parte dele, resultará em punições civis e
 * criminais e os infratores incorrem em sanções previstas na legislação em
 * vigor.
 *
 * Histórico do TFS:
 *
 * LastChangedRevision: $Revision$
 * LastChangedBy: $Author$
 * LastChangedDate: $Date$
 *
 * HeadURL: $HeadURL$
 *
 */
package br.gov.caixa.siacg.util;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;

import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.Status;

import br.gov.caixa.pedesgo.arquitetura.util.UtilParametro;
import br.gov.caixa.siacg.commons.AppConstant;
import br.gov.caixa.siacg.model.enums.RotinaEnum;

/**
 * <p>
 * RotinaUtil
 * </p>
 *
 * <p>
 * Descrição: Responsável por criar e monitorar arquivos que irão dizer se uma
 * dada rotina está ou não em execução
 * </p>
 *
 * <br>
 * <b>Empresa:</b> Cef - Caixa Econômica Federal
 *
 *
 * @author f725905
 *
 * @version 1.0
 */
public final class RotinaUtil {

    private static final String RUNNING = ".running";
    private static final String OK = ".ok";
    private static final String ERROR = ".error";

    private static final File rootFolder = Paths.get(UtilParametro.getParametro(AppConstant.PROPRIEDADE_PATH_SAIDA, true)).toFile();

    private RotinaUtil() {
    }

    public static void removeRunningFile(String routine) throws IOException {
	File fileRunning = createFileRunning(routine);
	deleteIfExists(fileRunning);
    }

    public static RotinaEnum getStatus(String routine) {
	File file = createFileRunning(routine);
	if (file.exists()) {
	    return RotinaEnum.RUNNING;
	}
	file = createFile(routine, true);
	if (file.exists()) {
	    return RotinaEnum.FINISHED;
	}
	file = createFile(routine, false);
	if (file.exists()) {
	    return RotinaEnum.ERROR;
	}
	return RotinaEnum.NOT_RUNNING;
    }

    public static boolean isRunning(String routine) {
	return createFileRunning(routine).exists();
    }

    public static Response start(String routine, Runnable runnable) throws IOException {
	if (RotinaUtil.isRunning(routine)) {
	    return Response.status(Status.SERVICE_UNAVAILABLE).build();
	}
	File file = createFile(routine, true);
	deleteIfExists(file);
	file = createFile(routine, false);
	deleteIfExists(file);
	file = createFileRunning(routine);
	
	if (!file.createNewFile()) {
	    throw new IOException("Não foi possível criar o arquivo running para rotina " + routine);
	}
	
	if (!file.setExecutable(true, false) || !file.setReadable(true, false) || !file.setWritable(true, false)) {
	    throw new IOException("Não foi possível setar chmod 777 via java runtime para rotina " + routine);
	}
	
	new Thread(runnable).start();
	return Response.status(Status.CREATED).build();
    }

    public static void terminate(String routine, boolean ok) {
	File file = createFile(routine, ok);
	createFileRunning(routine).renameTo(file);
    }

    private static File createFileRunning(String routine) {
	return new File(rootFolder, routine + RUNNING);
    }

    private static File createFile(String routine, boolean ok) {
	return new File(rootFolder, routine + (ok ? OK : ERROR));
    }

    private static void deleteIfExists(File file) throws IOException {
	if (file.exists()) {
	    Files.delete(file.toPath());
	}
    }

}
