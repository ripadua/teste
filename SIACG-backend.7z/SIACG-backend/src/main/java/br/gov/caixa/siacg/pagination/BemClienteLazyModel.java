/*
 * Copyright (c) 2019 Caixa Econômica Federal. Todos os direitos
 * reservados.
 *
 * Caixa Econômica Federal - SIACG - Sistema de Crédito Rural
 *
 * Este software foi desenvolvido sob demanda da CAIXA e está
 * protegido por leis de direitos autorais e tratados internacionais. As
 * condições de cópia e utilização do todo ou partes dependem de autorização da
 * empresa. Cópias não são permitidas sem expressa autorização. Não pode ser
 * comercializado ou utilizado para propósitos particulares.
 *
 * Uso exclusivo da Caixa Econômica Federal. A reprodução ou distribuição não
 * autorizada deste programa ou de parte dele, resultará em punições civis e
 * criminais e os infratores incorrem em sanções previstas na legislação em
 * vigor.
 *
 * Histórico do TFS:
 *
 * LastChangedRevision: $Revision$
 * LastChangedBy: $Author$
 * LastChangedDate: $Date$
 *
 * HeadURL: $HeadURL$
 *
 */
package br.gov.caixa.siacg.pagination;

import java.util.List;
import java.util.Map;

import javax.ejb.EJB;
import javax.enterprise.context.SessionScoped;
import javax.inject.Named;

import org.primefaces.model.SortOrder;

import br.gov.caixa.pedesgo.arquitetura.paginacao.Paginacao;
import br.gov.caixa.pedesgo.arquitetura.paginacao.PaginacaoDemanda;
import br.gov.caixa.pedesgo.arquitetura.util.UtilObjeto;
import br.gov.caixa.siacg.model.domain.BemCliente;
import br.gov.caixa.siacg.model.vo.FiltroBemClienteVO;
import br.gov.caixa.siacg.service.BemClienteService;

/**
 * <p>
 * BemClienteLazyModel
 * </p>
 *
 * <p>
 * Descrição: Descrição do tipo
 * </p>
 *
 * <br>
 * <b>Empresa:</b> Cef - Caixa Econômica Federal
 *
 *
 * @author f575368
 *
 * @version 1.0
 */
@Named
@SessionScoped
public class BemClienteLazyModel extends Paginacao<BemCliente> {

    /** Atributo serialVersionUID. */
    private static final long serialVersionUID = 1L;

    /** Atributo NOME_MANAGED_BEAN. */
    public static final String NOME_MANAGED_BEAN = "bemClienteLazyModel";

    /** Atributo EL_MANAGED_BEAN. */
    public static final String EL_MANAGED_BEAN = "#{bemClienteLazyModel}";

    /** Atributo de Serviço */
    @EJB
    private transient BemClienteService service;

    /** Atributo Filtro Tela */
    private transient FiltroBemClienteVO filtro;

    @Override
    public List<BemCliente> load(int inicio, int fim, String campoOrdenacao, SortOrder ordenacao, Map<String, String> parametros) {

	final PaginacaoDemanda<BemCliente> resultado = this.service.listarBemCliente(this.filtro, inicio, fim);

	super.setWrappedData(resultado.getLista());
	super.setRowCount(resultado.getQuantidadeRegistros());

	return resultado.getLista();

    }

    /**
     * @see br.gov.caixa.pedesgo.arquitetura.integracao.componente.paginacao.Paginacao#getServico()
     */
    @Override
    @SuppressWarnings("unchecked")
    public BemClienteService getServico() {
	return this.service;

    }

    public void limparFiltro() {
	this.getFiltro().setIcTipoBem(null);
	this.getFiltro().setCpfCnpj(null);
	this.getFiltro().setNomeGrupoGarantia(null);
	this.getFiltro().setCoContrato(null);
    }

    /**
     * <p>
     * Retorna o valor do atributo filtro
     * </p>
     * .
     *
     * @return filtro
     */
    public FiltroBemClienteVO getFiltro() {
	if (!UtilObjeto.isReferencia(this.filtro)) {
	    this.filtro = new FiltroBemClienteVO();
	}

	return this.filtro;
    }

    /**
     * <p>
     * Define o valor do atributo filtro
     * </p>
     * .
     *
     * @param filtro
     *            valor a ser atribuído
     */
    public void setFiltro(FiltroBemClienteVO filtro) {
	this.filtro = filtro;
    }

}
