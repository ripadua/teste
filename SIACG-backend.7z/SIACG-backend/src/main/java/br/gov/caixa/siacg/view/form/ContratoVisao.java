package br.gov.caixa.siacg.view.form;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.List;

import br.gov.caixa.pedesgo.arquitetura.util.UtilObjeto;
import br.gov.caixa.pedesgo.arquitetura.visao.ManutencaoVisao;
import br.gov.caixa.siacg.comum.to.ContratoTO;
import br.gov.caixa.siacg.model.domain.Contrato;
import br.gov.caixa.siacg.model.domain.OperacaoSistema;
import br.gov.caixa.siacg.model.domain.Produto;
import br.gov.caixa.siacg.model.domain.Unidade;
import br.gov.caixa.siacg.model.enums.SegmentacaoEnum;
import br.gov.caixa.siacg.model.enums.SituacaoContratoEnum;
import br.gov.caixa.siacg.model.vo.FiltroAnaliseCarteiraVO;
import br.gov.caixa.siacg.model.vo.SrVO;
import br.gov.caixa.siacg.model.vo.UnidadeVO;

/**
 * <p>
 * ContratoVisao
 * </p>
 * <p>
 * Descrição: Classe responsável por armazenar os dados da visão do caso de uso
 * <code> Pesquisa contrato </code>.
 * </p>
 * <br>
 * <b>Empresa:</b> Cef - Caixa Econômica Federal
 *
 * @author Waltenes junior
 * @version 1.0
 */
public class ContratoVisao extends ManutencaoVisao<Contrato> {

    /** Constante serialVersionUID. */
    private static final long serialVersionUID = 9013390079182736340L;

    /** Atributo restricao abangencia. */
    private boolean restricaoAbangencia;
    // Atributo responsavel por habilitar/desabilitar botão para abrir tela de
    // Parametrização
    /** Atributo exibir botao abrir parametrizacao. */
    private boolean exibirBotaoAbrirParametrizacao;

    /** Atributo lista unidade. */
    private Collection<UnidadeVO> listaUnidade;

    /** Atributo lista suat. */
    private Collection<UnidadeVO> listaSuat;

    /** Atributo lista sr. */
    private Collection<SrVO> srList;

    /** Atributo lista situacao. */
    private Collection<SituacaoContratoEnum> listaSituacao;

    /** Atributo unidade selecionada. */
    private Integer unidadeSelecionada;

    /** Atributo sr selecionada. */
    private Integer srSelecionada;

    /** Atributo suat selecionada. */
    private Integer suatSelecionada;

    /** Atributo habilitar suat. */
    private boolean habilitarSuat;

    /** Atributo habilitar sr. */
    private boolean habilitarSr;

    /** Atributo habilitar unidade. */
    private boolean habilitarUnidade;

    /** Atributo filtro. */
    private FiltroAnaliseCarteiraVO filtro;

    /** Atributo listaSegmento. */
    private Collection<SegmentacaoEnum> listaSegmento;

    /** Atributo listaOperacaoSistema. */
    private List<Produto> listaProduto;

    /** Atributo operacaoSistema. */
    private OperacaoSistema operacaoSistema;

    /** Atributo listaUnidadeContrato. */
    private List<Unidade> listaUnidadeContrato;
    
    /** Atributo listaContratoTO. */
    private List<ContratoTO> listaContratoTO;
    
    private boolean exibirModalSucesso;
    
    private String mensagemInclusaoContrato;
    
    private List<UnidadeVO> listaDires;
    private Integer tipoConfig;
    private Integer nuSuat;
    private Integer unidadeGestoraProcesso;
    
    
    /**
     * Retorna o valor do atributo restricaoAbangencia.
     *
     * @return restricaoAbangencia
     */
    public boolean isRestricaoAbangencia() {
	return this.restricaoAbangencia;
    }

    /**
     * Define o valor do atributo restricaoAbangencia.
     *
     * @param restricaoAbangencia
     *            valor a ser atribuído
     */
    public void setRestricaoAbangencia(final boolean restricaoAbangencia) {
	this.restricaoAbangencia = restricaoAbangencia;
    }

    /**
     * Retorna o valor do atributo exibirBotaoAbrirParametrizacao.
     *
     * @return exibirBotaoAbrirParametrizacao
     */
    public boolean isExibirBotaoAbrirParametrizacao() {

	return this.exibirBotaoAbrirParametrizacao;
    }

    /**
     * Define o valor do atributo exibirBotaoAbrirParametrizacao.
     *
     * @param exibirBotaoAbrirParametrizacao
     *            valor a ser atribuído
     */
    public void setExibirBotaoAbrirParametrizacao(final boolean exibirBotaoAbrirParametrizacao) {

	this.exibirBotaoAbrirParametrizacao = exibirBotaoAbrirParametrizacao;
    }

    /**
     * Retorna o valor do atributo listaUnidade.
     *
     * @return listaUnidade
     */
    public Collection<UnidadeVO> getListaUnidade() {

	if (UtilObjeto.isVazio(this.listaUnidade)) {

	    this.listaUnidade = new ArrayList<>();
	}

	return this.listaUnidade;
    }

    /**
     * Define o valor do atributo listaUnidade.
     *
     * @param listaUnidade
     *            valor a ser atribuído
     */
    public void setListaUnidade(final Collection<UnidadeVO> listaUnidade) {

	this.listaUnidade = listaUnidade;
    }

    /**
     * Retorna o valor do atributo listaSuat.
     *
     * @return listaSuat
     */
    public Collection<UnidadeVO> getListaSuat() {

	if (UtilObjeto.isVazio(this.listaSuat)) {

	    this.listaSuat = new ArrayList<>();
	}

	return this.listaSuat;
    }

    /**
     * Retorna o valor do atributo srList.
     *
     * @return srList
     */
    public Collection<SrVO> getSrList() {

    	if (UtilObjeto.isVazio(this.srList)) {
    
    	    this.srList = new ArrayList<>();
    	}
    
    	return this.srList;
    }

    /**
     * Define o valor do atributo listaSr.
     *
     * @param srList
     *            valor a ser atribuído
     */
    public void setSrList(final Collection<SrVO> srList) {

	this.srList = srList;
    }

    /**
     * Retorna o valor do atributo unidadeSelecionada.
     *
     * @return unidadeSelecionada
     */
    public Integer getUnidadeSelecionada() {

	return this.unidadeSelecionada;
    }

    /**
     * Define o valor do atributo unidadeSelecionada.
     *
     * @param unidadeSelecionada
     *            valor a ser atribuído
     */
    public void setUnidadeSelecionada(final Integer unidadeSelecionada) {

	this.unidadeSelecionada = unidadeSelecionada;
    }

    /**
     * Retorna o valor do atributo srSelecionada.
     *
     * @return srSelecionada
     */
    public Integer getSrSelecionada() {

	return this.srSelecionada;
    }

    /**
     * Define o valor do atributo srSelecionada.
     *
     * @param srSelecionada
     *            valor a ser atribuído
     */
    public void setSrSelecionada(final Integer srSelecionada) {

	this.srSelecionada = srSelecionada;
    }

    /**
     * Retorna o valor do atributo suatSelecionada.
     *
     * @return suatSelecionada
     */
    public Integer getSuatSelecionada() {

	return this.suatSelecionada;
    }

    /**
     * Define o valor do atributo suatSelecionada.
     *
     * @param suatSelecionada
     *            valor a ser atribuído
     */
    public void setSuatSelecionada(final Integer suatSelecionada) {

	this.suatSelecionada = suatSelecionada;
    }

    /**
     * Retorna o valor do atributo habilitarSuat.
     *
     * @return habilitarSuat
     */
    public boolean isHabilitarSuat() {

	return this.habilitarSuat;
    }

    /**
     * Define o valor do atributo habilitarSuat.
     *
     * @param habilitarSuat
     *            valor a ser atribuído
     */
    public void setHabilitarSuat(final boolean habilitarSuat) {

	this.habilitarSuat = habilitarSuat;
    }

    /**
     * Retorna o valor do atributo habilitarSr.
     *
     * @return habilitarSr
     */
    public boolean isHabilitarSr() {

	return this.habilitarSr;
    }

    /**
     * Define o valor do atributo habilitarSr.
     *
     * @param habilitarSr
     *            valor a ser atribuído
     */
    public void setHabilitarSr(final boolean habilitarSr) {

	this.habilitarSr = habilitarSr;
    }

    /**
     * Retorna o valor do atributo habilitarUnidade.
     *
     * @return habilitarUnidade
     */
    public boolean isHabilitarUnidade() {

	return this.habilitarUnidade;
    }

    /**
     * Define o valor do atributo habilitarUnidade.
     *
     * @param habilitarUnidade
     *            valor a ser atribuído
     */
    public void setHabilitarUnidade(final boolean habilitarUnidade) {

	this.habilitarUnidade = habilitarUnidade;
    }

    /**
     * Retorna o valor do atributo filtro.
     *
     * @return filtro
     */
    public FiltroAnaliseCarteiraVO getFiltro() {

	if (!UtilObjeto.isReferencia(this.filtro)) {

	    this.filtro = new FiltroAnaliseCarteiraVO();
	}

	return this.filtro;
    }

    /**
     * Define o valor do atributo filtro.
     *
     * @param filtro
     *            valor a ser atribuído
     */
    public void setFiltro(final FiltroAnaliseCarteiraVO filtro) {

	this.filtro = filtro;
    }

    /**
     * Retorna o valor do atributo listaSituacao.
     *
     * @return listaSituacao
     */
    public Collection<SituacaoContratoEnum> getListaSituacao() {
	if (this.listaSituacao == null) {
	    this.listaSituacao = Arrays.asList(SituacaoContratoEnum.PARAMETRIZADO, SituacaoContratoEnum.NAO_PARAMETRIZADO);
	}
	return this.listaSituacao;
    }

    /**
     * Define o valor do atributo listaSituacao.
     *
     * @param listaSituacao
     *            valor a ser atribuído
     */
    public void setListaSituacao(final Collection<SituacaoContratoEnum> listaSituacao) {
	this.listaSituacao = listaSituacao;
    }

    /**
     * Retorna o valor do atributo listaSegmento.
     *
     * @return listaSegmento
     */
    public Collection<SegmentacaoEnum> getListaSegmento() {
	if (this.listaSegmento == null) {
	    this.listaSegmento = Arrays.asList(SegmentacaoEnum.values());
	}
	return this.listaSegmento;
    }

    /**
     * Define o valor do atributo listaSegmento.
     *
     * @param listaSegmento
     *            valor a ser atribuído
     */
    public void setListaSegmento(final Collection<SegmentacaoEnum> listaSegmento) {
	this.listaSegmento = listaSegmento;
    }

    /**
     * Define o valor do atributo listaSuat.
     *
     * @param listaSuat
     *            valor a ser atribuído
     */
    public void setListaSuat(final Collection<UnidadeVO> listaSuat) {

	this.listaSuat = listaSuat;
    }

    /**
     * <p>
     * Retorna o valor do atributo listaProduto
     * </p>
     * .
     *
     * @return listaProduto
     */
    public List<Produto> getListaProduto() {
	if (this.listaProduto == null) {
	    this.listaProduto = new ArrayList<>();
	}
	return this.listaProduto;
    }

    /**
     * <p>
     * Define o valor do atributo listaProduto
     * </p>
     * .
     *
     * @param listaProduto
     *            valor a ser atribuído
     */
    public void setListaProduto(List<Produto> listaProduto) {
	this.listaProduto = listaProduto;
    }

    /**
     * <p>
     * Retorna o valor do atributo operacaoSistema
     * </p>
     * .
     *
     * @return operacaoSistema
     */
    public OperacaoSistema getOperacaoSistema() {
	return this.operacaoSistema;
    }

    /**
     * <p>
     * Define o valor do atributo operacaoSistema
     * </p>
     * .
     *
     * @param operacaoSistema
     *            valor a ser atribuído
     */
    public void setOperacaoSistema(OperacaoSistema operacaoSistema) {
	this.operacaoSistema = operacaoSistema;
    }
   

    /**
     * <p>
     * Retorna o valor do atributo listaUnidadeContrato
     * </p>
     * .
     *
     * @return listaUnidadeContrato
     */
    public List<Unidade> getListaUnidadeContrato() {
	if (UtilObjeto.isVazio(this.listaUnidadeContrato)) {
	    this.listaUnidadeContrato = new ArrayList<>();
	}
	return this.listaUnidadeContrato;
    }

    /**
     * <p>
     * Define o valor do atributo listaUnidadeContrato
     * </p>
     * .
     *
     * @param listaUnidadeContrato
     *            valor a ser atribuído
     */
    public void setListaUnidadeContrato(List<Unidade> listaUnidadeContrato) {
	this.listaUnidadeContrato = listaUnidadeContrato;
    }

    /**
     * <p>Retorna o valor do atributo listaContratoTO</p>.
     *
     * @return listaContratoTO
    */
    public List<ContratoTO> getListaContratoTO() {
	if(this.listaContratoTO == null) {
	    this.listaContratoTO = new ArrayList<>();
	}
        return this.listaContratoTO;
    }

    /**
     * <p>Define o valor do atributo listaContratoTO</p>.
     *
     * @param listaContratoTO valor a ser atribuído
    */
    public void setListaContratoTO(List<ContratoTO> listaContratoTO) {
        this.listaContratoTO = listaContratoTO;
    }

	/**
	 * <p>Retorna o valor do atributo exibirModalSucesso</p>.
	 *
	 * @return exibirModalSucesso
	*/
	public boolean isExibirModalSucesso() {
		return this.exibirModalSucesso;
	}

	/**
	 * <p>Define o valor do atributo exibirModalSucesso</p>.
	 *
	 * @param exibirModalSucesso valor a ser atribuído
	*/
	public void setExibirModalSucesso(boolean exibirModalSucesso) {
		this.exibirModalSucesso = exibirModalSucesso;
	}

	/**
	 * <p>Retorna o valor do atributo mensagemInclusaoContrato</p>.
	 *
	 * @return mensagemInclusaoContrato
	*/
	public String getMensagemInclusaoContrato() {
		return this.mensagemInclusaoContrato;
	}

	/**
	 * <p>Define o valor do atributo mensagemInclusaoContrato</p>.
	 *
	 * @param mensagemInclusaoContrato valor a ser atribuído
	*/
	public void setMensagemInclusaoContrato(String mensagemInclusaoContrato) {
		this.mensagemInclusaoContrato = mensagemInclusaoContrato;
	}

	/**
	 * <p>Retorna o valor do atributo listaDires</p>.
	 *
	 * @return listaDires
	*/
	public List<UnidadeVO> getListaDires() {
		return this.listaDires;
	}

	/**
	 * <p>Define o valor do atributo listaDires</p>.
	 *
	 * @param listaDires valor a ser atribuído
	*/
	public void setListaDires(List<UnidadeVO> listaDires) {
	this.listaDires = listaDires;}

	/**
	 * <p>Retorna o valor do atributo tipoConfig</p>.
	 *
	 * @return tipoConfig
	*/
	public Integer getTipoConfig() {
		return this.tipoConfig;
	}

	/**
	 * <p>Define o valor do atributo tipoConfig</p>.
	 *
	 * @param tipoConfig valor a ser atribuído
	*/
	public void setTipoConfig(Integer tipoConfig) {
	this.tipoConfig = tipoConfig;}
	
	/**
	 * Retorna o valor do atributo nuSuat.
	 *
	 * @return nuSuat
	 */
	public Integer getNuSuat() {

		return this.nuSuat;
	}

	/**
	 * Define o valor do atributo nuSuat.
	 *
	 * @param nuSuat
	 *            valor a ser atribuído
	 */
	public void setNuSuat(final Integer nuSuat) {
		this.nuSuat = nuSuat;
	}

	public Integer getUnidadeGestoraProcesso() {
		return unidadeGestoraProcesso;
	}

	public void setUnidadeGestoraProcesso(Integer unidadeGestoraProcesso) {
		this.unidadeGestoraProcesso = unidadeGestoraProcesso;
	}
	
}