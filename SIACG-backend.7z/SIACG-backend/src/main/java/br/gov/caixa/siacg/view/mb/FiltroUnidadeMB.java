/**
 * Copyright (c) 2013 Caixa Econômica Federal. Todos os direitos
 * reservados.
 *
 * Caixa Econômica Federal - SIACG - Sistema de Crédito Rural
 *
 * Este software foi desenvolvido sob demanda da CAIXA e está
 * protegido por leis de direitos autorais e tratados internacionais. As
 * condições de cópia e utilização do todo ou partes dependem de autorização da
 * pessoa. Cópias não são permitidas sem expressa autorização. Não pode ser
 * comercializado ou utilizado para propósitos particulares.
 *
 * Uso exclusivo da Caixa Econômica Federal. A reprodução ou distribuição não
 * autorizada deste programa ou de parte dele, resultará em punições civis e
 * criminais e os infratores incorrem em sanções previstas na legislação em
 * vigor.
 *
 * Histórico do Subversion:
 *
 * LastChangedRevision: $Revision$
 * LastChangedBy: $Author$
 * LastChangedDate: $Date$
 *
 * HeadURL: $HeadURL$
 *
 */
package br.gov.caixa.siacg.view.mb;

import java.util.Collection;
import java.util.LinkedList;

import javax.ejb.EJB;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;
import javax.faces.context.FacesContext;
import javax.faces.event.AjaxBehaviorEvent;

import br.gov.caixa.pedesgo.arquitetura.controlador.ManutencaoBean;
import br.gov.caixa.pedesgo.arquitetura.enumerador.EnumAcao;
import br.gov.caixa.pedesgo.arquitetura.enumerador.EnumNomeAbrangenciaRestritaUnidade;
import br.gov.caixa.pedesgo.arquitetura.enumerador.EnumTipoAbrangencia;
import br.gov.caixa.pedesgo.arquitetura.util.UsuarioUtil;
import br.gov.caixa.pedesgo.arquitetura.util.UtilObjeto;
import br.gov.caixa.pedesgo.arquitetura.util.UtilString;
import br.gov.caixa.siacg.model.domain.Mensagem;
import br.gov.caixa.siacg.model.enums.NoFuncionalidadeEnum;
import br.gov.caixa.siacg.model.vo.SrVO;
import br.gov.caixa.siacg.model.vo.UnidadeVO;
import br.gov.caixa.siacg.service.SuatService;
import br.gov.caixa.siacg.service.UnidadeService;
import br.gov.caixa.siacg.service.UnidadeVinculadaSuatService;
import br.gov.caixa.siacg.view.form.FiltroUnidadeVisao;

/**
 * <p>
 * LoginMB
 * </p>
 * <p>
 * Descrição: Maneged bean do filtro de unidade.
 * </p>
 * <br>
 * <b>Empresa:</b> Cef - Caixa Econômica Federal
 *
 * @author guilherme.santos
 * @version 1.0
 */
@ManagedBean(name = FiltroUnidadeMB.NOME_MANAGED_BEAN)
@SessionScoped
public class FiltroUnidadeMB extends ManutencaoBean<Mensagem> {

    private static final long serialVersionUID = -1681211892423968673L;

    public static final String NOME_MANAGED_BEAN = "filtroUnidadeMB";

    public static final String EL_MANAGED_BEAN = "#{filtroUnidadeMB}";

    private static final String SR = "SR";

    private static final String CAIXA = "CAIXA";

    private static final String AGENCIA = "UNIDADE";

    private static final String SUAT = "SUAT";

    @EJB
    private UnidadeVinculadaSuatService service;
    
    @EJB
    private SuatService suatService;
    
    @EJB
    private UnidadeService unidadeService;

    private FiltroUnidadeVisao visao;

    /**
     * @see br.gov.caixa.pedesgo.arquitetura.controlador.AbstractBean#getService()
     */
    @SuppressWarnings("unchecked")
    @Override
    public UnidadeVinculadaSuatService getService() {
        return this.service;
    }

    /**
     * @see br.gov.caixa.pedesgo.arquitetura.controlador.AbstractBean#getVisao()
     */
    @Override
    public FiltroUnidadeVisao getVisao() {
        if (this.visao == null) {
            this.visao = new FiltroUnidadeVisao();
        }
        return this.visao;
    }

    /**
     * @see br.gov.caixa.pedesgo.arquitetura.controlador.AbstractBean#getNomeVarResourceBundle()
     */
    @Override
    protected String getNomeVarResourceBundle() {
        return null;
    }

    /**
     * @see br.gov.caixa.pedesgo.arquitetura.controlador.AbstractBean#getPrefixoCasoDeUso()
     */
    @Override
    protected String getPrefixoCasoDeUso() {
        return null;
    }

    /**
     * <p>
     * Método responsável por configurar a permissão de exibição de componentes
     * na tela.
     * <p>
     *
     * @author guilherme.santos
     */
    public void configurarPermissao() {
        final FacesContext contexto = FacesContext.getCurrentInstance();

        this.limparFiltros();

        if (UtilObjeto.isReferencia(contexto)) {

            final String unidadeUsuario = super.getUnidadeUsuario();

            if (!UtilString.isVazio(unidadeUsuario)) {

                final Integer nuUnidadeusuarioLogado = Integer.valueOf(unidadeUsuario);

                if (UtilObjeto.isReferencia(nuUnidadeusuarioLogado)) {

                    final FiltroUnidadeVisao visao = this.getVisao();

                    if (UsuarioUtil.contemPermissao(NoFuncionalidadeEnum.CONSULTA_UNIDADE.getNoFuncionalidade(), EnumAcao.CONSULTAR.getNoAcao(),
                            EnumTipoAbrangencia.RESTRITA_UNIDADE.getTipoAbrangencia(),
                            EnumNomeAbrangenciaRestritaUnidade.TODAS.getNomeAbrangencia())) {

                        visao.setSuatList(getService().listarSuats());
                        visao.setExibirGestorCaixa(true);

                        this.getVisao().setNivelConsulta(FiltroUnidadeMB.CAIXA);

                        if (this.getVisao().getNuSuat() != null) {
                            visao.setNuSuat(this.getVisao().getNuSuat());
                            this.selecionarSuat();
                        }
                        if (this.getVisao().getNuSr() != null) {
                            visao.setSrList(getService().listarSrsPorNuSuat(this.getVisao().getNuSuat()));
                            visao.setNuSr(this.getVisao().getNuSr());
                            this.selecionarSr(null);
                        }
                        if (this.getVisao().getNuUnidade() != null) {
                            visao.setUnidadeList(getService().listarUnidadesPorNuSr(this.getVisao().getNuSr()));
                            visao.setNuUnidade(this.getVisao().getNuUnidade());
                            this.selecionarUnidade(null);
                        }

                        // Bota para voltar ao nivel inicial
                        this.getVisao().setExibirBotaoVoltarConsulta(true);

                    } else if (UsuarioUtil.contemPermissao(NoFuncionalidadeEnum.CONSULTA_UNIDADE.getNoFuncionalidade(),
                            EnumAcao.CONSULTAR.getNoAcao(), EnumTipoAbrangencia.RESTRITA_UNIDADE.getTipoAbrangencia(),
                            EnumNomeAbrangenciaRestritaUnidade.VINCULADAS.getNomeAbrangencia())) {

                        this.construirBreadCrumbGestorRegional(nuUnidadeusuarioLogado);
                        visao.setExibirGestorRegional(true);
                        visao.setExibirColunaSR(true);
                        visao.setExibirColunaSUAT(true);

                        this.getVisao().setNivelConsulta(FiltroUnidadeMB.SR);

                        if (this.getVisao().getNuUnidade() != null) {
                            visao.setUnidadeList(getService().listarUnidadesPorNuSr(nuUnidadeusuarioLogado));
                            visao.setNuUnidade(this.getVisao().getNuUnidade());
                        }

                    } else if (UsuarioUtil.contemPermissao(NoFuncionalidadeEnum.CONSULTA_UNIDADE.getNoFuncionalidade(),
                            EnumAcao.CONSULTAR.getNoAcao(), EnumTipoAbrangencia.RESTRITA_UNIDADE.getTipoAbrangencia(),
                            EnumNomeAbrangenciaRestritaUnidade.UNIDADE.getNomeAbrangencia())) {

                        this.construirBreadCrumbGestorUnidade(nuUnidadeusuarioLogado);
                        visao.setExibirGestorUnidade(true);
                        visao.setExibirColunaUnidade(true);
                        visao.setExibirColunaSR(true);
                        visao.setExibirColunaSUAT(true);

                        this.getVisao().setNivelConsulta(FiltroUnidadeMB.AGENCIA);
                    }
                }
            }
        }
    }

    /**
     * <p>
     * Método responsável por voltar um nível na consulta.
     * <p>
     *
     * @author Bruno Martins de Carvalho
     */
    public void voltarNivelConsulta() {

        if (this.isNivelConsultaIgual(FiltroUnidadeMB.SUAT)) {
            this.getVisao().setNivelConsulta(FiltroUnidadeMB.CAIXA);
            this.getVisao().setSrList(new LinkedList<SrVO>());
            this.getVisao().setUnidadeList(new LinkedList<UnidadeVO>());
            this.getVisao().setNuSuat(null);
            this.getVisao().setNuSr(null);
            this.getVisao().setNuUnidade(null);
        }

        if (this.isNivelConsultaIgual(FiltroUnidadeMB.SR)) {
            this.getVisao().setNivelConsulta(FiltroUnidadeMB.SUAT);
            this.getVisao().setNuSr(null);
            this.getVisao().setNuUnidade(null);
        }

        if (this.isNivelConsultaIgual(FiltroUnidadeMB.AGENCIA)) {
            this.getVisao().setNivelConsulta(FiltroUnidadeMB.SR);
            this.getVisao().setUnidadeList(new LinkedList<UnidadeVO>());
            this.getVisao().setNuUnidade(null);
        }

    }

    /**
     * <p>
     * Método responsável por verificar se o nivel da consulta corresponde ao
     * nivel informado.
     * <p>
     *
     * @param valor
     *            valor a ser atribuido
     * @return boolean
     * @author Bruno Martins de Carvalho
     */
    public boolean isNivelConsultaIgual(final String valor) {
        return this.getVisao().getNivelConsulta().equals(valor);
    }

    /**
     * <p>
     * Método responsável por limpar os filtros do componente.
     * <p>
     *
     * @author Bruno Martins de Carvalho
     */
    public void limparFiltros() {
        final FiltroUnidadeVisao visao = this.getVisao();

        visao.setNuSuat(null);
        visao.setNuSr(null);
        visao.setNuUnidade(null);
    }

    /**
     * <p>
     * Ação executada quando a combobox de SUAT for selecionada.
     * </p>
     *
     * @param eventoAjax
     * @author guilherme.santos
     */
    public void selecionarSuat() {
        final FiltroUnidadeVisao visao = this.getVisao();

        if (UtilObjeto.isReferencia(visao) && visao.getNuSuat() != null && !visao.getNuSuat().equals(0)) {
            visao.setSrList(getService().listarSrsPorNuSuat(visao.getNuSuat()));
            visao.setUnidadeList(new LinkedList<UnidadeVO>());
            this.getVisao().setNivelConsulta(FiltroUnidadeMB.SUAT);
        } else {
            visao.setSrList(new LinkedList<SrVO>());
            visao.setUnidadeList(new LinkedList<UnidadeVO>());
            this.getVisao().setNuSuat(null);
            this.getVisao().setNivelConsulta(FiltroUnidadeMB.CAIXA);
        }
    }

    /**
     * <p>
     * Ação executada quando a combobox de SR for selecionada.
     * </p>
     *
     * @param eventoAjax
     *            valor a ser atribuído
     * @author guilherme.santos
     */
    public void selecionarSr(final AjaxBehaviorEvent eventoAjax) {
        final FiltroUnidadeVisao visao = this.getVisao();

        if (UtilObjeto.isReferencia(visao) && visao.getNuSr() != null && !visao.getNuSr().equals(0)) {
            visao.setUnidadeList(getService().listarUnidadesPorNuSr(visao.getNuSr()));
            this.getVisao().setNivelConsulta(FiltroUnidadeMB.SR);
        } else {
            this.selecionarSuat();
            visao.setNuSr(null);
            visao.setNuUnidade(null);
            this.getVisao().setNuSr(null);
            this.getVisao().setNuUnidade(null);
            this.getVisao().setNivelConsulta(FiltroUnidadeMB.SUAT);
        }
    }

    /**
     * <p>
     * Ação executada quando a combobox de Unidade for selecionada.
     * <p>
     *
     * @param eventoAjax
     *            valor a ser atribuído
     * @author guilherme.santos
     */
    public void selecionarUnidade(final AjaxBehaviorEvent eventoAjax) {
        final FiltroUnidadeVisao visao = this.getVisao();

        if (UtilObjeto.isReferencia(visao) && visao.getNuUnidade() != null && !visao.getNuUnidade().equals(0)) {
            this.getVisao().setNuUnidade(visao.getNuUnidade());
            this.getVisao().setNivelConsulta(FiltroUnidadeMB.AGENCIA);
        } else {
            this.selecionarSr(eventoAjax);
            visao.setNuUnidade(null);
            this.getVisao().setNuUnidade(null);
            this.getVisao().setNivelConsulta(FiltroUnidadeMB.SR);
        }
    }

    /**
     * <p>
     * Método responsável por contruir o breadcrumb do gestor regional.
     * </p>
     *
     * @param numeroUnidadeUsuarioLogado
     *            valor a ser atribuído
     * @author guilherme.santos
     */
    private void construirBreadCrumbGestorRegional(final Integer numeroUnidadeUsuarioLogado) {

        final FiltroUnidadeVisao visao = this.getVisao();
        final Integer numeroSuatUnidadeUsuarioLogado = getService().getNuSuatPorSR(numeroUnidadeUsuarioLogado);

        visao.setNomeSuat(suatService.getNomeSuat(numeroSuatUnidadeUsuarioLogado));
        visao.setNuSuat(numeroSuatUnidadeUsuarioLogado);

        visao.setNomeSr(unidadeService.getNomeSRPorNuUnidade(numeroUnidadeUsuarioLogado));
        visao.setNuSr(numeroUnidadeUsuarioLogado);

        if (UtilObjeto.isReferencia(numeroUnidadeUsuarioLogado)) {
            final Collection<UnidadeVO> unidadeSrList = getService().listarUnidadesPorNuSr(numeroUnidadeUsuarioLogado);
            visao.setUnidadeList(unidadeSrList);
        }
    }

    /**
     * <p>
     * Método responsável por contruir o breadcrumb do gestor de uma unidade.
     * </p>
     *
     * @param numeroUnidadeUsuarioLogado
     *            valor a ser atribuído
     * @author guilherme.santos
     */
    private void construirBreadCrumbGestorUnidade(final Integer numeroUnidadeUsuarioLogado) {

        final FiltroUnidadeVisao visao = this.getVisao();

        final Integer numeroSuatUnidadeUsuarioLogado = this.service.getNuSuatPorUnidade(numeroUnidadeUsuarioLogado);
        final Integer numeroSrUnidadeUsuarioLogado = this.service.getNuSrPorUnidade(numeroUnidadeUsuarioLogado);

        visao.setNomeUnidade(unidadeService.getNomeUnidade(numeroUnidadeUsuarioLogado));
        visao.setNuUnidade(numeroUnidadeUsuarioLogado);

        visao.setNomeSuat(suatService.getNomeSuat(numeroSuatUnidadeUsuarioLogado));
        visao.setNuSuat(numeroSuatUnidadeUsuarioLogado);

        visao.setNomeSr(unidadeService.getNomeSRPorNuUnidade(numeroUnidadeUsuarioLogado));
        visao.setNuSr(numeroSrUnidadeUsuarioLogado);
    }
}
