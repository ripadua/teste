/**
 * Copyright (c) 2013 Caixa Econômica Federal. Todos os direitos
 * reservados.
 *
 * Caixa Econômica Federal - SIACG - Sistema de Crédito Rural
 *
 * Este software foi desenvolvido sob demanda da CAIXA e está
 * protegido por leis de direitos autorais e tratados internacionais. As
 * condições de cópia e utilização do todo ou partes dependem de autorização da
 * pessoa. Cópias não são permitidas sem expressa autorização. Não pode ser
 * comercializado ou utilizado para propósitos particulares.
 *
 * Uso exclusivo da Caixa Econômica Federal. A reprodução ou distribuição não
 * autorizada deste programa ou de parte dele, resultará em punições civis e
 * criminais e os infratores incorrem em sanções previstas na legislação em
 * vigor.
 *
 * Histórico do Subversion:
 *
 * LastChangedRevision: $Revision$
 * LastChangedBy: $Author$
 * LastChangedDate: $Date$
 *
 * HeadURL: $HeadURL$
 *
 */
package br.gov.caixa.siacg.pagination;

import java.util.List;
import java.util.Map;

import javax.ejb.EJB;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;

import org.primefaces.model.SortOrder;

import br.gov.caixa.pedesgo.arquitetura.paginacao.Paginacao;
import br.gov.caixa.pedesgo.arquitetura.paginacao.PaginacaoDemanda;
import br.gov.caixa.siacg.model.domain.Mensagem;
import br.gov.caixa.siacg.model.vo.MensagemConsultaVO;
import br.gov.caixa.siacg.service.MensagemService;

/**
 * <p>
 * MensagemLazyModel.
 * </p>
 * <p>
 * Descrição: Classe responsável pela paginação por demanda do caso de uso de
 * mensagem
 * </p>
 * <br>
 * <b>Empresa:</b> Cef - Caixa Econômica Federal
 *
 * @author Waltenes Junior
 * @version 1.0
 */
@ManagedBean(name = MensagemLazyModel.NOME_MANAGED_BEAN)
@SessionScoped
public class MensagemLazyModel extends Paginacao<Mensagem> {

    private static final long serialVersionUID = -8038890809886951718L;

    /** Atributo NOME_MANAGED_BEAN. */
    public static final String NOME_MANAGED_BEAN = "mensagemLazyModel";
    /** Atributo EL_MANAGED_BEAN. */
    public static final String EL_MANAGED_BEAN = "#{mensagemLazyModel}";

    /** Atributo service. */
    @EJB
    private transient MensagemService service;

    /** Atributo filtro. */
    private transient MensagemConsultaVO filtro;

    /**
     * @see br.gov.caixa.pedesgo.arquitetura.integracao.componente.paginacao.Paginacao#load(int,
     *      int, java.lang.String, org.primefaces.model.SortOrder,
     *      java.util.Map)
     */
    @Override
    public List<Mensagem> load(final int inicio, final int fim, final String campoOrdenacao, final SortOrder ordenacao,
            final Map<String, String> parametros) {
        this.filtro.setCampoOrdenacao(campoOrdenacao);
        this.filtro.setTipoOrdenacao(ordenacao.name());
        final PaginacaoDemanda<Mensagem> resultado = this.service.listarMensagens(this.filtro, inicio, fim);
        this.setWrappedData(resultado.getLista());
        this.setRowCount(resultado.getQuantidadeRegistros());
        return resultado.getLista();
    }

    /**
     * @see br.gov.caixa.pedesgo.arquitetura.integracao.componente.paginacao.Paginacao#getServico()
     */
    @SuppressWarnings("unchecked")
    @Override
    public MensagemService getServico() {
        return this.service;
    }

    /**
     * Retorna o valor do atributo filtro.
     *
     * @return filtro
     */
    public MensagemConsultaVO getFiltro() {
        if (this.filtro == null) {
            this.filtro = new MensagemConsultaVO();
        }
        return this.filtro;
    }

    /**
     * Define o valor do atributo filtro.
     *
     * @param filtro
     *            valor a ser atribuído
     */
    public void setFiltro(final MensagemConsultaVO filtro) {
        this.filtro = filtro;
    }
}
