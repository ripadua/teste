/**
 * Copyright (c) 2014 Caixa Econômica Federal. Todos os direitos
 * reservados.
 *
 * Caixa Econômica Federal - SIACG - Acompanhamento e Controle de Garantias
 *
 * Este software foi desenvolvido sob demanda da CAIXA e está
 * protegido por leis de direitos autorais e tratados internacionais. As
 * condições de cópia e utilização do todo ou partes dependem de autorização da
 * pessoa. Cópias não são permitidas sem expressa autorização. Não pode ser
 * comercializado ou utilizado para propósitos particulares.
 *
 * Uso exclusivo da Caixa Econômica Federal. A reprodução ou distribuição não
 * autorizada deste programa ou de parte dele, resultará em punições civis e
 * criminais e os infratores incorrem em sanções previstas na legislação em
 * vigor.
 *
 * Histórico do Subversion:
 *
 * LastChangedRevision: $Revision$
 * LastChangedBy: $Author$
 * LastChangedDate: $Date$
 *
 * HeadURL: $HeadURL$
 *
 */
package br.gov.caixa.siacg.view.form;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;

import br.gov.caixa.pedesgo.arquitetura.visao.ManutencaoVisao;
import br.gov.caixa.siacg.model.domain.GrupoGarantia;
import br.gov.caixa.siacg.model.domain.Saldo;
import br.gov.caixa.siacg.model.enums.GrupoGarantiaEnum;
import br.gov.caixa.siacg.model.enums.SegmentacaoEnum;
import br.gov.caixa.siacg.model.vo.SrVO;
import br.gov.caixa.siacg.model.vo.UnidadeVO;

/**
 * <p>
 * RelatorioSaldoLiquidoPessoaVisao
 * </p>
 * <p>
 * Descrição: Visão para o Acompanhamento de Endividamento.
 * </p>
 * <br>
 * <b>Empresa:</b> Cef - Caixa Econômica Federal
 *
 * @author guilherme.santos
 * @version 1.0
 */

public class RelatorioSaldoLiquidoPessoaVisao extends ManutencaoVisao<Saldo> {

    /** Constante serialVersionUID. */
    private static final long serialVersionUID = 3725867756577803030L;

    /** Atributo nu unidade. */
    private Integer nuUnidade;

    /** Atributo nu sr. */
    private Integer nuSr;

    /** Atributo nu suat. */
    private Integer nuSuat;

    /** Atributo habilitar suat. */
    private boolean habilitarSuat;

    /** Atributo habilitar sr. */
    private boolean habilitarSr;

    /** Atributo habilitar unidade. */
    private boolean habilitarUnidade;

    /** Atributo exibir gestor caixa. */
    private boolean exibirGestorCaixa;

    /** Atributo exibir gestor nacional. */
    private boolean exibirGestorNacional;

    /** Atributo exibir gestor regional. */
    private boolean exibirGestorRegional;

    /** Atributo exibir gestor unidade. */
    private boolean exibirGestorUnidade;

    /** Atributo exibir coluna unidade. */
    private boolean exibirColunaUnidade;

    /** Atributo exibir coluna sr. */
    private boolean exibirColunaSR;

    /** Atributo exibir coluna suat. */
    private boolean exibirColunaSUAT;

    /** Atributo nomeSuat. */
    private String nomeSuat;

    /** Atributo nomeSr. */
    private String nomeSr;

    /** Atributo nomeUnidade. */
    private String nomeUnidade;

    // Listas
    /** Atributo garantias. */
    private Collection<GrupoGarantia> garantias;

    /** Atributo listaSegmento. */
    private Collection<SegmentacaoEnum> listaSegmento;

    /** Atributo unidade list. */
    private Collection<UnidadeVO> unidadeList;

    /** Atributo suat list. */
    private Collection<UnidadeVO> suatList;

    /** Atributo sr list. */
    private Collection<SrVO> srList;

    /** Atributo listaGrupoGarantias. */
    private Collection<GrupoGarantia> listaGrupoGarantias;

    /**
     * Retorna o valor do atributo garantias.
     *
     * @return garantias
     */
    public Collection<GrupoGarantia> getGarantias() {
        return this.garantias;
    }

    /**
     * Retorna o valor do atributo listaGrupoGarantias.
     *
     * @return listaGrupoGarantias
     */
    public Collection<GrupoGarantia> getListaGrupoGarantias() {
        if (this.listaGrupoGarantias == null) {
            this.listaGrupoGarantias = new ArrayList<GrupoGarantia>();

            this.listaGrupoGarantias.add(new GrupoGarantia(GrupoGarantiaEnum.DUPLICATA));
            this.listaGrupoGarantias.add(new GrupoGarantia(GrupoGarantiaEnum.APLICACAO_FINANCEIRA));
            this.listaGrupoGarantias.add(new GrupoGarantia(GrupoGarantiaEnum.CHEQUE));
            this.listaGrupoGarantias.add(new GrupoGarantia(GrupoGarantiaEnum.CARTAO_CREDITO));
        }

        return this.listaGrupoGarantias;
    }

    /**
     * Retorna o valor do atributo listaSegmento.
     *
     * @return listaSegmento
     */
    public Collection<SegmentacaoEnum> getListaSegmento() {
        if (this.listaSegmento == null) {
            this.listaSegmento = Arrays.asList(SegmentacaoEnum.values());
        }
        return this.listaSegmento;
    }

    /**
     * <p>
     * Retorna o valor do atributo nomeSr
     * </p>
     * .
     *
     * @return nomeSr
     */
    public String getNomeSr() {
        return this.nomeSr;
    }

    /**
     * <p>
     * Retorna o valor do atributo nomeSuat
     * </p>
     * .
     *
     * @return nomeSuat
     */
    public String getNomeSuat() {
        return this.nomeSuat;
    }

    /**
     * <p>
     * Retorna o valor do atributo nomeUnidade
     * </p>
     * .
     *
     * @return nomeUnidade
     */
    public String getNomeUnidade() {
        return this.nomeUnidade;
    }

    /**
     * Retorna o valor do atributo nuSr.
     *
     * @return nuSr
     */
    public Integer getNuSr() {

        return this.nuSr;
    }

    /**
     * Retorna o valor do atributo nuSuat.
     *
     * @return nuSuat
     */
    public Integer getNuSuat() {

        return this.nuSuat;
    }

    /**
     * Retorna o valor do atributo nuUnidade.
     *
     * @return nuUnidade
     */
    public Integer getNuUnidade() {

        return this.nuUnidade;
    }

    /**
     * Retorna o valor do atributo srList.
     *
     * @return srList
     */
    public Collection<SrVO> getSrList() {

        return this.srList;
    }

    /**
     * Retorna o valor do atributo suatList.
     *
     * @return suatList
     */
    public Collection<UnidadeVO> getSuatList() {

        return this.suatList;
    }

    /**
     * Retorna o valor do atributo unidadeList.
     *
     * @return unidadeList
     */
    public Collection<UnidadeVO> getUnidadeList() {

        return this.unidadeList;
    }

    /**
     * Retorna o valor do atributo exibirColunaSR.
     *
     * @return exibirColunaSR
     */
    public boolean isExibirColunaSR() {

        return this.exibirColunaSR;
    }

    /**
     * Retorna o valor do atributo exibirColunaSUAT.
     *
     * @return exibirColunaSUAT
     */
    public boolean isExibirColunaSUAT() {

        return this.exibirColunaSUAT;
    }

    /**
     * Retorna o valor do atributo exibirColunaUnidade.
     *
     * @return exibirColunaUnidade
     */
    public boolean isExibirColunaUnidade() {

        return this.exibirColunaUnidade;
    }

    /**
     * Retorna o valor do atributo exibirGestorCaixa.
     *
     * @return exibirGestorCaixa
     */
    public boolean isExibirGestorCaixa() {

        return this.exibirGestorCaixa;
    }

    /**
     * Retorna o valor do atributo exibirGestorNacional.
     *
     * @return exibirGestorNacional
     */
    public boolean isExibirGestorNacional() {

        return this.exibirGestorNacional;
    }

    /**
     * Retorna o valor do atributo exibirGestorRegional.
     *
     * @return exibirGestorRegional
     */
    public boolean isExibirGestorRegional() {

        return this.exibirGestorRegional;
    }

    /**
     * Retorna o valor do atributo exibirGestorUnidade.
     *
     * @return exibirGestorUnidade
     */
    public boolean isExibirGestorUnidade() {

        return this.exibirGestorUnidade;
    }

    /**
     * Retorna o valor do atributo habilitarSr.
     *
     * @return habilitarSr
     */
    public boolean isHabilitarSr() {

        return this.habilitarSr;
    }

    /**
     * Retorna o valor do atributo habilitarSuat.
     *
     * @return habilitarSuat
     */
    public boolean isHabilitarSuat() {

        return this.habilitarSuat;
    }

    /**
     * Retorna o valor do atributo habilitarUnidade.
     *
     * @return habilitarUnidade
     */
    public boolean isHabilitarUnidade() {

        return this.habilitarUnidade;
    }

    /**
     * Define o valor do atributo exibirColunaSR.
     *
     * @param exibirColunaSR
     *            valor a ser atribuído
     */
    public void setExibirColunaSR(final boolean exibirColunaSR) {

        this.exibirColunaSR = exibirColunaSR;
    }

    /**
     * Define o valor do atributo exibirColunaSUAT.
     *
     * @param exibirColunaSUAT
     *            valor a ser atribuído
     */
    public void setExibirColunaSUAT(final boolean exibirColunaSUAT) {

        this.exibirColunaSUAT = exibirColunaSUAT;
    }

    /**
     * Define o valor do atributo exibirColunaUnidade.
     *
     * @param exibirColunaUnidade
     *            valor a ser atribuído
     */
    public void setExibirColunaUnidade(final boolean exibirColunaUnidade) {

        this.exibirColunaUnidade = exibirColunaUnidade;
    }

    /**
     * Define o valor do atributo exibirGestorCaixa.
     *
     * @param exibirGestorCaixa
     *            valor a ser atribuído
     */
    public void setExibirGestorCaixa(final boolean exibirGestorCaixa) {

        this.exibirGestorCaixa = exibirGestorCaixa;
    }

    /**
     * Define o valor do atributo exibirGestorNacional.
     *
     * @param exibirGestorNacional
     *            valor a ser atribuído
     */
    public void setExibirGestorNacional(final boolean exibirGestorNacional) {

        this.exibirGestorNacional = exibirGestorNacional;
    }

    /**
     * Define o valor do atributo exibirGestorRegional.
     *
     * @param exibirGestorRegional
     *            valor a ser atribuído
     */
    public void setExibirGestorRegional(final boolean exibirGestorRegional) {

        this.exibirGestorRegional = exibirGestorRegional;
    }

    /**
     * Define o valor do atributo exibirGestorUnidade.
     *
     * @param exibirGestorUnidade
     *            valor a ser atribuído
     */
    public void setExibirGestorUnidade(final boolean exibirGestorUnidade) {

        this.exibirGestorUnidade = exibirGestorUnidade;
    }

    /**
     * Define o valor do atributo garantias.
     *
     * @param garantias
     *            valor a ser atribuído
     */
    public void setGarantias(final Collection<GrupoGarantia> garantias) {
        this.garantias = garantias;
    }

    /**
     * Define o valor do atributo habilitarSr.
     *
     * @param habilitarSr
     *            valor a ser atribuído
     */
    public void setHabilitarSr(final boolean habilitarSr) {

        this.habilitarSr = habilitarSr;
    }

    /**
     * Define o valor do atributo habilitarSuat.
     *
     * @param habilitarSuat
     *            valor a ser atribuído
     */
    public void setHabilitarSuat(final boolean habilitarSuat) {

        this.habilitarSuat = habilitarSuat;
    }

    /**
     * Define o valor do atributo habilitarUnidade.
     *
     * @param habilitarUnidade
     *            valor a ser atribuído
     */
    public void setHabilitarUnidade(final boolean habilitarUnidade) {

        this.habilitarUnidade = habilitarUnidade;
    }

    /**
     * Define o valor do atributo listaGrupoGarantias.
     *
     * @param listaGrupoGarantias
     *            valor a ser atribuído
     */
    public void setListaGrupoGarantias(final Collection<GrupoGarantia> listaGrupoGarantias) {

        this.listaGrupoGarantias = listaGrupoGarantias;
    }

    /**
     * Define o valor do atributo listaSegmento.
     *
     * @param listaSegmento
     *            valor a ser atribuído
     */
    public void setListaSegmento(final Collection<SegmentacaoEnum> listaSegmento) {
        this.listaSegmento = listaSegmento;
    }

    /**
     * <p>
     * Define o valor do atributo nomeSr
     * </p>
     * .
     *
     * @param nomeSr
     *            valor a ser atribuído
     */
    public void setNomeSr(final String nomeSr) {
        this.nomeSr = nomeSr;
    }

    /**
     * <p>
     * Define o valor do atributo nomeSuat
     * </p>
     * .
     *
     * @param nomeSuat
     *            valor a ser atribuído
     */
    public void setNomeSuat(final String nomeSuat) {
        this.nomeSuat = nomeSuat;
    }

    /**
     * <p>
     * Define o valor do atributo nomeUnidade
     * </p>
     * .
     *
     * @param nomeUnidade
     *            valor a ser atribuído
     */
    public void setNomeUnidade(final String nomeUnidade) {
        this.nomeUnidade = nomeUnidade;
    }

    /**
     * Define o valor do atributo nuSr.
     *
     * @param nuSr
     *            valor a ser atribuído
     */
    public void setNuSr(final Integer nuSr) {

        this.nuSr = nuSr;
    }

    /**
     * Define o valor do atributo nuSuat.
     *
     * @param nuSuat
     *            valor a ser atribuído
     */
    public void setNuSuat(final Integer nuSuat) {

        this.nuSuat = nuSuat;
    }

    /**
     * Define o valor do atributo nuUnidade.
     *
     * @param nuUnidade
     *            valor a ser atribuído
     */
    public void setNuUnidade(final Integer nuUnidade) {

        this.nuUnidade = nuUnidade;
    }

    /**
     * Define o valor do atributo srList.
     *
     * @param srList
     *            valor a ser atribuído
     */
    public void setSrList(final Collection<SrVO> srList) {

        this.srList = srList;
    }

    /**
     * Define o valor do atributo suatList.
     *
     * @param suatList
     *            valor a ser atribuído
     */
    public void setSuatList(final Collection<UnidadeVO> suatList) {

        this.suatList = suatList;
    }

    /**
     * Define o valor do atributo unidadeList.
     *
     * @param unidadeList
     *            valor a ser atribuído
     */
    public void setUnidadeList(final Collection<UnidadeVO> unidadeList) {

        this.unidadeList = unidadeList;
    }

}