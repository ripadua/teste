/*
 * Copyright (c) 2013 Caixa Econômica Federal. Todos os direitos reservados.
 *
 * Caixa Econômica Federal - SIACG
 *
 * Este software foi desenvolvido sob demanda da CAIXA e está protegido por leis de direitos autorais e tratados
 * internacionais. As condições de cópia e utilização do todo ou partes dependem de autorização da pessoa. Cópias não
 * são permitidas sem expressa autorização. Não pode ser comercializado ou utilizado para propósitos particulares.
 *
 * Uso exclusivo da Caixa Econômica Federal. A reprodução ou distribuição não autorizada deste programa ou de parte
 * dele, resultará em punições civis e criminais e os infratores incorrem em sanções previstas na legislação em vigor.
 *
 * Histórico do Subversion:
 *
 * LastChangedRevision: $Revision$ LastChangedBy: $Author$ LastChangedDate: $Date$
 *
 * HeadURL: $HeadURL$
 *
 */
package br.gov.caixa.siacg.validator;

import javax.faces.application.FacesMessage;
import javax.faces.component.UIComponent;
import javax.faces.context.FacesContext;
import javax.faces.validator.FacesValidator;
import javax.faces.validator.Validator;
import javax.faces.validator.ValidatorException;

import org.primefaces.context.RequestContext;

import br.gov.caixa.pedesgo.arquitetura.util.UtilObjeto;
import br.gov.caixa.pedesgo.arquitetura.util.UtilString;
import br.gov.caixa.pedesgo.arquitetura.enumerador.EnumTipoFormatacao;
import br.gov.caixa.pedesgo.arquitetura.util.UtilCnpj;
import br.gov.caixa.pedesgo.arquitetura.util.UtilCpf;
import br.gov.caixa.pedesgo.arquitetura.util.UtilFormatacao;

/**
 * <p>
 * ConverterIntegerToString.
 * </p>
 *
 * <p>
 * Descrição: Descrição do tipo
 * </p>
 *
 * <br>
 * <b>Empresa:</b> Cef - Caixa Econômica Federal
 *
 *
 * @author Leandro Santos Oliveira
 *
 * @version 1.0
 */
@FacesValidator(value = "validarCpfCnpj")
public class ValidarCpfCnpj implements Validator {

    /** Atributo msg. */
    private FacesMessage msg;

    /**
     * @see javax.faces.validator.Validator#validate(javax.faces.context.FacesContext,
     *      javax.faces.component.UIComponent, java.lang.Object)
     */
    @Override
    public void validate(final FacesContext context, final UIComponent component, final Object objeto) throws ValidatorException {

        if (UtilObjeto.isReferencia(objeto) && !UtilString.isVazio(objeto.toString())) {

            final int tamanho = objeto.toString().length();

            final String removerMascara = UtilFormatacao.removerMascara(objeto.toString(), EnumTipoFormatacao.CNPJ);

            final int tamanhoSemMascara = removerMascara.length();

            if (!UtilString.isVazio(removerMascara) && tamanho == 18 && tamanhoSemMascara < 14) {

                this.msg = new FacesMessage("CNPJ inválido");
                this.msg.setSeverity(FacesMessage.SEVERITY_WARN);

                resetValueField(component);
                throw new ValidatorException(this.msg);
            }

            if (!UtilString.isVazio(removerMascara) && removerMascara.length() <= UtilFormatacao.TAMANHO_CPF_SEM_FORMATACAO
                    && !UtilCpf.isCPF(removerMascara)) {

                this.msg = new FacesMessage("CPF inválido");
                this.msg.setSeverity(FacesMessage.SEVERITY_WARN);
                
                resetValueField(component);
                throw new ValidatorException(this.msg);

            }

            if (!UtilString.isVazio(removerMascara) && removerMascara.length() == UtilFormatacao.TAMANHO_CNPJ_SEM_FORMATACAO
                    && !UtilCnpj.isCNPJ(removerMascara)) {

                this.msg = new FacesMessage("CNPJ inválido");
                this.msg.setSeverity(FacesMessage.SEVERITY_WARN);

                resetValueField(component);
                throw new ValidatorException(this.msg);
            }
        }
    }
    
    private void resetValueField(final UIComponent component) {
    	RequestContext.getCurrentInstance().execute("$('#"+component.getId()+"').val('');"); 
    	RequestContext.getCurrentInstance().execute("$('#"+component.getId()+"').css('cssText','border-radius: 4px;border: 1px solid red !important; width: 200px;');");    	
    }
}
