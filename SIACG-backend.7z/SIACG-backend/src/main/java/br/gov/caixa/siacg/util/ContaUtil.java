package br.gov.caixa.siacg.util;

/**
 * <p>
 * ContaUtil
 * </p>
 * <p>
 * Descrição: Extrai informações de um conta.
 * </p>
 * <br>
 * <b>Empresa:</b> Cef - Caixa Econômica Federal
 *
 * @author joseroberto@gsgroup.com.br
 * @version 1.0
 */
public final class ContaUtil {

    /** Atributo conta. */
    private transient String conta;

    /**
     * Construtor.
     *
     * @param conta
     *            valor a ser atribuido
     */
    private ContaUtil(final String conta) {
        this.conta = conta;
    }
    
    /**
     * <p>
     * Método responsável por retornar nova instancia.
     * <p>
     *
     * @param conta
     *            valor a ser atribuido
     * @return ContaUtil
     */
    public static ContaUtil getNovaInstancia(final String conta) {
        return new ContaUtil(conta);
    }

    /**
     *
     * <p>
     * Método responsável por verificar se a string só contem números.
     * <p>
     *
     * @param texto
     *            valor a ser atribuido
     * @return boolean
     * @author Caio Graco
     */
    public static boolean soContemNumeros(final String texto) {
        if (texto == null) {
            return false;
        }

        for (final char letra : texto.toCharArray()) {
            if (letra < '0' || letra > '9') {
                return false;
            }
        }

        return true;
    }

    /**
     * <p>
     * Obtém a agência.
     * </p>
     *
     * @return String
     * @author joseroberto@gsgroup.com.br
     */
    public String getAgencia() {
        return this.conta.substring(0, 4);
    }

    /**
     * <p>
     * Obtém a operação.
     * </p>
     *
     * @return String
     * @author joseroberto@gsgroup.com.br
     */
    public String getOp() {
        return this.conta.substring(4, 7);
    }

    /**
     * <p>
     * Obtém a conta.
     * </p>
     *
     * @return String
     * @author joseroberto@gsgroup.com.br
     */
    public String getConta() {
        return this.conta.substring(7, 15);
    }

    /**
     * <p>
     * Obtém o digito.
     * </p>
     *
     * @return String
     * @author joseroberto@gsgroup.com.br
     */
    public String getDigito() {
        return this.conta.substring(15, this.conta.length());
    }
}
