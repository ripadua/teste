/**
 * reservados.
 * Copyright (c) 2009-2011 Caixa Econômica Federal. Todos os direitos
 *
 * Caixa Econômica Federal - SIACG – Sistema de Acompanhamento de Carteiras de Cobrança
 *
 * Este programa de computador foi desenvolvido sob demanda da CAIXA e está
 * protegido por leis de direitos autorais e tratados internacionais. As
 * condições de cópia e utilização do todo ou partes dependem de autorização da
 * pessoa. Cópias não são permitidas sem expressa autorização. Não pode ser
 * comercializado ou utilizado para propósitos particulares.
 *
 * Uso exclusivo da Caixa Econômica Federal. A reprodução ou distribuição não
 * autorizada deste programa ou de parte dele, resultará em punições civis e
 * criminais e os infratores incorrem em sanções previstas na legislação em
 * vigor.
 *
 * Histórico do Subversion:
 *
 * LastChangedRevision:
 * LastChangedBy:
 * LastChangedDate:
 *
 * HeadURL:
 *
 */
package br.gov.caixa.siacg.util;

import java.math.BigDecimal;

/**
 * <p>
 * Matematica
 * </p>
 * <p>
 * Descrição: Classe Matematica
 * </p>
 * <br>
 * <b>Empresa:</b> Cef - Caixa Econômica Federal.
 *
 * @author GS Tecnologia
 * @version 1.0
 */
public class Matematica {

    /** Atributo escala divisoes. */
    private static final int ESCALA_DIVISOES = 2;

    /** Atributo tipo arredondamento. */
    private static final int TIPO_ARREDONDAMENTO = BigDecimal.ROUND_HALF_EVEN;
    
    private Matematica() {
	throw new IllegalStateException("Classe de Utilidade");
    }

    /**
     * Retorna o valor do atributo.
     *
     * @param dividendo
     *            the dividendo
     * @param divisor
     *            the divisor
     * @return divisao
     */
    public static BigDecimal getDivisao(final BigDecimal dividendo, final BigDecimal divisor) {
        BigDecimal nRetorno = BigDecimal.ZERO;
        if (dividendo == null || divisor == null) {
            return nRetorno;
        }
        if (divisor.equals(BigDecimal.ZERO)) {
            return nRetorno;
        }

        nRetorno = dividendo.divide(divisor, Matematica.ESCALA_DIVISOES, Matematica.TIPO_ARREDONDAMENTO);
        return nRetorno;
    }

}
