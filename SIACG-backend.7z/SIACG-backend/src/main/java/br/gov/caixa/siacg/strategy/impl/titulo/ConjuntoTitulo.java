/**
 * Copyright (c) 2018 Caixa Econômica Federal. Todos os direitos
 * reservados.
 *
 * Caixa Econômica Federal - SIACG
 *
 * Este software foi desenvolvido sob demanda da CAIXA e está
 * protegido por leis de direitos autorais e tratados internacionais. As
 * condições de cópia e utilização total ou partes dependem de autorização da
 * empresa. Cópias não são permitidas sem expressa autorização. Não pode ser
 * comercializado ou utilizado para propósitos particulares.
 *
 * Uso exclusivo da Caixa Econômica Federal. A reprodução ou distribuição não
 * autorizada deste programa ou de parte dele, resultará em punições civis e
 * criminais e os infratores incorrem em sanções previstas na legislação em
 * vigor.
 *
 * Histórico do TFS:
 *
 * LastChangedRevision: $Revision$
 * LastChangedBy: $Author$
 * LastChangedDate: $Date$
 *
 * HeadURL: $HeadURL$
 *
 */	
package br.gov.caixa.siacg.strategy.impl.titulo;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Collection;

import br.gov.caixa.siacg.model.domain.Titulo;

/**
 * <p>ConjuntoTitulo</p>
 *
 * <p>Descrição: Classe abstrata que representa um conjunto de titulos para o calculo das garantias</p>
 *
 * <br><b>Empresa:</b> Cef - Caixa Econômica Federal
 *
 *
 * @author p541915
 *
 * @version 1.0
*/
public abstract class ConjuntoTitulo {
	
	/** Atributo qtdConjunto. */
	private Long qtdConjunto = 0L;
	
	/** Atributo vrTotal. */
	private BigDecimal vrTotal = BigDecimal.ZERO;
	
	/** Atributo titulos. */
	private Collection<Titulo> titulos = new ArrayList<>();

	/**
	 * <p>Retorna o valor do atributo vrTotal</p>.
	 *
	 * @return vrTotal
	*/
	public BigDecimal getVrTotal() {
		return this.vrTotal;
	}
	
	/**
	 * <p>Método responsável por adicionar o título no conjunto, somando o valor do título ao total do conjunto</p>.
	 *
	 * @author p541915
	 *
	 * @param titulo
	 */
	public void adicionarTitulo(Titulo titulo, boolean manterLista) {
		if (titulo != null) {
			this.qtdConjunto++;
			this.vrTotal = this.vrTotal.add(titulo.getVrTitulo());
			if (manterLista) {
				this.titulos.add(titulo);				
			}
		}
	}
	
	/**
	 * <p>Método responsável por adicionar o titulo no conjunto</p>.
	 *
	 * @author p541915
	 *
	 * @param titulo
	 */
	public void adicionarTitulo(Titulo titulo) {
		this.adicionarTitulo(titulo, false);
	}
	
	/**
	 * <p>Método responsável por obter a quantidade de títulos existente no conjunto</p>.
	 *
	 * @author p541915
	 *
	 * @return
	 */
	public Long getQtdConjunto() {
		return this.qtdConjunto;
	}
	
	/**
	 * <p>Método responsável por obter a lista de titulos do conjunto</p>.
	 *
	 * @author p541915
	 *
	 * @return
	 */
	public Collection<Titulo> getTitulos() {
		return this.titulos;
	}
	
	/**
	 * <p>Método responsável por somar os valores de dois conjuntos</p>.
	 *
	 * @author p541915
	 *
	 * @param conjuntoTitulo
	 */
	public void somarConjunto(ConjuntoTitulo conjuntoTitulo) {
		this.qtdConjunto = this.qtdConjunto + conjuntoTitulo.getQtdConjunto();
		this.vrTotal = this.vrTotal.add(conjuntoTitulo.getVrTotal());
		this.titulos.addAll(conjuntoTitulo.getTitulos());
	}
	
	/**
	 * @see java.lang.Object#toString()
	*/
	@Override
	public String toString() {
		return this.getClass().getName() + " - Total de titulos: " + getQtdConjunto() + " - Valor total: " + getVrTotal();
	}

}
