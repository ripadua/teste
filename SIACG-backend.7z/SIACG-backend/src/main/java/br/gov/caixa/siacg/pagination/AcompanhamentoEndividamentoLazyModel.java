package br.gov.caixa.siacg.pagination;

import java.util.List;
import java.util.Map;

import javax.ejb.EJB;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;
import javax.inject.Inject;

import org.primefaces.model.SortOrder;

import br.gov.caixa.pedesgo.arquitetura.enumerador.EnumAcao;
import br.gov.caixa.pedesgo.arquitetura.enumerador.EnumTipoAbrangencia;
import br.gov.caixa.pedesgo.arquitetura.paginacao.Paginacao;
import br.gov.caixa.pedesgo.arquitetura.paginacao.PaginacaoDemanda;
import br.gov.caixa.pedesgo.arquitetura.util.UsuarioUtil;
import br.gov.caixa.siacg.commons.UtilPermissao;
import br.gov.caixa.siacg.model.enums.NoFuncionalidadeEnum;
import br.gov.caixa.siacg.model.vo.ContratoParametrizadoVO;
import br.gov.caixa.siacg.model.vo.FiltroContratoVO;
import br.gov.caixa.siacg.service.ContratoService;

/**
 * <p>
 * ContratoLazyModel.
 * </p>
 * <p>
 * Descrição: Classe de paginação sob demanda do acompanhamento de endividamento
 * </p>
 * <br>
 * <b>Empresa:</b> Cef - Caixa Econômica Federal
 *
 * @author Caio Graco
 * @version 1.0
 */

@ManagedBean
@SessionScoped
public class AcompanhamentoEndividamentoLazyModel extends Paginacao<ContratoParametrizadoVO> {

    private static final long serialVersionUID = -6038965454195521432L;

    /** Atributo NOME_MANAGED_BEAN. */
    public static final String NOME_MANAGED_BEAN = "acompanhamentoEndividamentoLazyModel";
    /** Atributo EL_MANAGED_BEAN. */
    public static final String EL_MANAGED_BEAN = "#{acompanhamentoEndividamentoLazyModel}";

    /** Atributo service. */
    @EJB
    private transient ContratoService service;

    /** Atributo permissao. */
    @Inject
    private transient UtilPermissao permissao;

    /** Atributo filtro. */
    private transient FiltroContratoVO filtro;

    /**
     * @see br.gov.caixa.pedesgo.arquitetura.integracao.componente.paginacao.Paginacao#getServico()
     */
    @Override
    @SuppressWarnings("unchecked")
    public ContratoService getServico() {
        return this.service;
    }

    /**
     * @see br.gov.caixa.pedesgo.arquitetura.integracao.componente.paginacao.Paginacao#load(int,
     *      int, java.lang.String, org.primefaces.model.SortOrder,
     *      java.util.Map)
     */
    @Override
    public List<ContratoParametrizadoVO> load(final int inicio, final int fim, final String campoOrdenacao, final SortOrder ordenacao,
            final Map<String, String> parametros) {

        if (this.getFiltro().getListaUnidade().isEmpty()
                && UsuarioUtil.contemPermissao(NoFuncionalidadeEnum.ACOMPANHAMENTO_ENVIDAMENTO.getNoFuncionalidade(), EnumAcao.CONSULTAR.getNoAcao(),
                        EnumTipoAbrangencia.RESTRITA_UNIDADE.getTipoAbrangencia(), null)) {
            this.getFiltro().setListaUnidade(
                    this.permissao.prepararConsultaPorTipoAbrangencia(NoFuncionalidadeEnum.ACOMPANHAMENTO_ENVIDAMENTO.getNoFuncionalidade()));
        }

        this.filtro.setCampoOrdenacao(campoOrdenacao);
        this.filtro.setTipoOrdenacao(ordenacao.name());
        final PaginacaoDemanda<ContratoParametrizadoVO> resultado = this.service.listarContratosEndividamento(this.filtro, inicio, fim);

        super.setWrappedData(resultado.getLista());
        super.setRowCount(resultado.getQuantidadeRegistros());

        return resultado.getLista();
    }

    /**
     * <p>
     * Método responsável por limpar filtro da consulta.
     * <p>
     *
     * @author Waltenes junior
     */
    public void limparFiltro() {
        this.filtro = new FiltroContratoVO();
    }

    /**
     * Retorna o valor do atributo filtro.
     *
     * @return filtro
     */
    public FiltroContratoVO getFiltro() {
        if (this.filtro == null) {
            this.filtro = new FiltroContratoVO();
        }
        return this.filtro;
    }

    /**
     * Define o valor do atributo filtro.
     *
     * @param filtro
     *            valor a ser atribuído
     */
    public void setFiltro(final FiltroContratoVO filtro) {
        this.filtro = filtro;
    }
}