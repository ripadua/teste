package br.gov.caixa.siacg.view.form;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import br.gov.caixa.pedesgo.arquitetura.util.UtilObjeto;
import br.gov.caixa.siacg.comum.to.AvaliacaoTO;
import br.gov.caixa.siacg.comum.to.sifec.RespostaSifecDadosVeiculosTO;
import br.gov.caixa.siacg.model.domain.BemCliente;
import br.gov.caixa.siacg.model.domain.CategoriaImovel;
import br.gov.caixa.siacg.model.domain.GestaoServentia;
import br.gov.caixa.siacg.model.domain.Imovel;
import br.gov.caixa.siacg.model.domain.PapelProprietario;
import br.gov.caixa.siacg.model.domain.Pessoa;
import br.gov.caixa.siacg.model.domain.ProprietarioImovel;
import br.gov.caixa.siacg.model.domain.TipoLogradouroImovel;
import br.gov.caixa.siacg.model.domain.TipoUsoImovel;
import br.gov.caixa.siacg.model.enums.CategoriaVeiculoEnum;
import br.gov.caixa.siacg.model.enums.EstadoOcupacaoImovelEnum;
import br.gov.caixa.siacg.model.enums.TipoBemEnum;
import br.gov.caixa.siacg.model.enums.TipoDocumentoComprobatoriaEnum;
import br.gov.caixa.siacg.model.vo.BemClienteVO;

/**
 * <p>
 * AnaliseVisao
 * </p>
 * <p>
 * Descrição: Classe responsável por armazenar os dados da visão do caso de uso
 * <code>Análise de carteira</code>.
 * </p>
 * 
 * <b>Empresa:</b> Cef - Caixa Econômica Federal
 *
 * @author joseroberto@gsgroup.com.br
 * @version 1.0
 */
public class BemClienteVisao extends TemplateVisao<BemCliente> {

    private static final long serialVersionUID = -1234511708434279698L;

    private boolean desabilitarTodosCampos;
    private boolean desabilitarValorAvaliacao;
    private Integer idGarantiaParaExcluir;
    private Pessoa titularContrato;
    private BemClienteVO bem;
    private List<BemClienteVO> bens;
    private List<GestaoServentia> listaGestaoServentia;
    private Pessoa titularVinculo;
    private RespostaSifecDadosVeiculosTO dadosSifecUfs;
    private RespostaSifecDadosVeiculosTO dadosSifecTipos;
    private RespostaSifecDadosVeiculosTO dadosSifecMarcas;
    private RespostaSifecDadosVeiculosTO dadosSifecModelos;
    private boolean desabilitarEndereco;
    private List<AvaliacaoTO> listaAvaliacaoImoveis;
    private AvaliacaoTO selectedAvaliacao;
    private ProprietarioImovel proprietarioImovelVisao;
    private ProprietarioImovel proprietarioImovelVisaoExclusao;
    private List<ProprietarioImovel> listaProprietarioImovelExclusao;
    private List<ProprietarioImovel> listaHistoricoProprietarioImovel;
    private List<PapelProprietario> listaPapelProprietario;
    private String cpfCnpjAvalicao;

    private List<TipoLogradouroImovel> listaTipoLogradouro;
    private List<TipoUsoImovel> listaTipoUsoImovel;
    private List<CategoriaImovel> listaCategoriaImovel;
    
    private List<EstadoOcupacaoImovelEnum> listaEstadoOcupacao;

    public boolean isDesabilitarTodosCampos() {
	return this.desabilitarTodosCampos;
    }

    public void setDesabilitarTodosCampos(final boolean desabilitarTodosCampos) {
	this.desabilitarTodosCampos = desabilitarTodosCampos;
    }

    /**
     * @return the listaTipoLogradouro
     */
    public List<TipoLogradouroImovel> getListaTipoLogradouro() {
	return listaTipoLogradouro;
    }

    public void setListaTipoLogradouro(List<TipoLogradouroImovel> listaTipoLogradouro) {
	this.listaTipoLogradouro = listaTipoLogradouro;
    }

    public List<TipoUsoImovel> getListaTipoUsoImovel() {
	return this.listaTipoUsoImovel;
    }

    public void setListaTipoUsoImovel(List<TipoUsoImovel> listaTipoUsoImovel) {
	this.listaTipoUsoImovel = listaTipoUsoImovel;
    }

    public List<CategoriaImovel> getListaCategoriaImovel() {
	return this.listaCategoriaImovel;
    }

    public void setListaCategoriaImovel(List<CategoriaImovel> listaCategoriaImovel) {
	this.listaCategoriaImovel = listaCategoriaImovel;
    }

    public List<GestaoServentia> getListaGestaoServentia() {
	if (this.listaGestaoServentia == null) {
	    this.listaGestaoServentia = new ArrayList<>();
	}
	return this.listaGestaoServentia;
    }

    public void setListaGestaoServentia(final List<GestaoServentia> listaGestaoServentia) {
	this.listaGestaoServentia = listaGestaoServentia;
    }

    public Pessoa getTitularContrato() {
	if (this.titularContrato == null) {
	    this.titularContrato = new Pessoa();
	}
	return this.titularContrato;
    }

    public void setTitularContrato(final Pessoa titularContrato) {
	this.titularContrato = titularContrato;
    }

    /**
     * <p>
     * Retorna o valor do atributo desabilitarValorAvaliacao
     * </p>
     * .
     *
     * @return desabilitarValorAvaliacao
     */
    public boolean isDesabilitarValorAvaliacao() {
	return this.desabilitarValorAvaliacao;
    }

    /**
     * <p>
     * Define o valor do atributo desabilitarValorAvaliacao
     * </p>
     * .
     *
     * @param desabilitarValorAvaliacao
     *            valor a ser atribuído
     */
    public void setDesabilitarValorAvaliacao(boolean desabilitarValorAvaliacao) {
	this.desabilitarValorAvaliacao = desabilitarValorAvaliacao;
    }

    /**
     * <p>
     * Define o valor do atributo idGarantiaParaExcluir
     * </p>
     * .
     *
     * @param idGarantiaParaExcluir
     *            valor a ser atribuído
     */
    public Integer getIdGarantiaParaExcluir() {
	return idGarantiaParaExcluir;
    }

    /**
     * <p>
     * Retorna o valor do atributo idGarantiaParaExcluir
     * </p>
     * .
     *
     * @return idGarantiaParaExcluir
     */
    public void setIdGarantiaParaExcluir(Integer idGarantiaParaExcluir) {
	this.idGarantiaParaExcluir = idGarantiaParaExcluir;
    }

    /**
     * <p>
     * Retorna o valor do atributo bem
     * </p>
     * .
     *
     * @return bem
     */
    public BemClienteVO getBem() {
	return this.bem;
    }

    /**
     * <p>
     * Define o valor do atributo bem
     * </p>
     * .
     *
     * @param bem
     *            valor a ser atribuído
     */
    public void setBem(BemClienteVO bem) {
	this.bem = bem;
    }

    /**
     * <p>
     * Retorna o valor do atributo bens
     * </p>
     * .
     *
     * @return bens
     */
    public List<BemClienteVO> getBens() {
	if (bens == null) {
	    setBens(new ArrayList<BemClienteVO>());
	}

	return this.bens;
    }

    /**
     * <p>
     * Define o valor do atributo bens
     * </p>
     * .
     *
     * @param bens
     *            valor a ser atribuído
     */
    public void setBens(List<BemClienteVO> bens) {
	this.bens = bens;
    }

    public List<TipoBemEnum> getTipoBens() {
	return Arrays.asList(TipoBemEnum.values());
    }

    public List<TipoDocumentoComprobatoriaEnum> getDocsComprobatoriaList() {
	return Arrays.asList(TipoDocumentoComprobatoriaEnum.values());
    }

    public List<CategoriaVeiculoEnum> getCategoriaVeiculos() {
	return Arrays.asList(CategoriaVeiculoEnum.values());
    }

    /**
     * <p>
     * Retorna o valor do atributo titularVinculo
     * </p>
     * .
     *
     * @return titularVinculo
     */
    public Pessoa getTitularVinculo() {
	return this.titularVinculo;
    }

    /**
     * <p>
     * Define o valor do atributo titularVinculo
     * </p>
     * .
     *
     * @param titularVinculo
     *            valor a ser atribuído
     */
    public void setTitularVinculo(Pessoa titularVinculo) {
	this.titularVinculo = titularVinculo;
    }

    /**
     * @return the dadosSifecTipos
     */
    public RespostaSifecDadosVeiculosTO getDadosSifecTipos() {
	return dadosSifecTipos;
    }

    /**
     * @param dadosSifecTipos
     *            the dadosSifecTipos to set
     */
    public void setDadosSifecTipos(RespostaSifecDadosVeiculosTO dadosSifecTipos) {
	this.dadosSifecTipos = dadosSifecTipos;
    }

    /**
     * @return the dadosSifecUfs
     */
    public RespostaSifecDadosVeiculosTO getDadosSifecUfs() {
	return dadosSifecUfs;
    }

    /**
     * @param dadosSifecUfs
     *            the dadosSifecUfs to set
     */
    public void setDadosSifecUfs(RespostaSifecDadosVeiculosTO dadosSifecUfs) {
	this.dadosSifecUfs = dadosSifecUfs;
    }

    /**
     * @return the dadosSifecMarcas
     */
    public RespostaSifecDadosVeiculosTO getDadosSifecMarcas() {
	return dadosSifecMarcas;
    }

    /**
     * @param dadosSifecMarcas
     *            the dadosSifecMarcas to set
     */
    public void setDadosSifecMarcas(RespostaSifecDadosVeiculosTO dadosSifecMarcas) {
	this.dadosSifecMarcas = dadosSifecMarcas;
    }

    /**
     * @return the dadosSifecModelos
     */
    public RespostaSifecDadosVeiculosTO getDadosSifecModelos() {
	return dadosSifecModelos;
    }

    /**
     * @param dadosSifecModelos
     *            the dadosSifecModelos to set
     */
    public void setDadosSifecModelos(RespostaSifecDadosVeiculosTO dadosSifecModelos) {
	this.dadosSifecModelos = dadosSifecModelos;
    }

    public boolean isObrigatorioQtdDormitorios() {
	boolean obrigatorioQtdDormitorios = false;

	Imovel imovel = getEntidade().getImovel();
	if (imovel != null && imovel.getUsoImovel() != null && imovel.getUsoImovel().getNuTipoUsoImovel() != null
		&& UtilObjeto.isReferencia(imovel.getCategoriaImovel())) {
	    List<Integer> categoriasNaoPermitidas = Arrays.asList(0, 3, 7);

	    obrigatorioQtdDormitorios = imovel.getUsoImovel().getNuTipoUsoImovel() == 1
		    && (!categoriasNaoPermitidas.contains(imovel.getCategoriaImovel().getNuCategoriaImovel()));
	}

	return obrigatorioQtdDormitorios;
    }

    public boolean isObrigatorioQtdGaragem() {
	boolean obrigatorioQtdGaragem = false;

	Imovel imovel = getEntidade().getImovel();
	if (imovel != null && imovel.getUsoImovel() != null && imovel.getUsoImovel().getNuTipoUsoImovel() != null
		&& UtilObjeto.isReferenciaNumeroPositivo(imovel.getCategoriaImovel())) {
	    List<Integer> categoriasNaoPermitidas = Arrays.asList(0, 3, 7);

	    obrigatorioQtdGaragem = (imovel.getUsoImovel().getNuTipoUsoImovel() == 1 || imovel.getUsoImovel().getNuTipoUsoImovel() == 2)
		    && (!categoriasNaoPermitidas.contains(imovel.getCategoriaImovel().getNuCategoriaImovel()));
	}

	return obrigatorioQtdGaragem;
    }

    public boolean isDesabilitarEndereco() {
	return desabilitarEndereco;
    }

    public void setDesabilitarEndereco(boolean desabilitarEndereco) {
	this.desabilitarEndereco = desabilitarEndereco;
    }

    public List<AvaliacaoTO> getListaAvaliacaoImoveis() {
	return listaAvaliacaoImoveis;
    }

    public void setListaAvaliacaoImoveis(List<AvaliacaoTO> listaAvaliacaoImoveis) {
	this.listaAvaliacaoImoveis = listaAvaliacaoImoveis;
    }

    public AvaliacaoTO getSelectedAvaliacao() {
	return selectedAvaliacao;
    }

    public void setSelectedAvaliacao(AvaliacaoTO selectedAvaliacao) {
	this.selectedAvaliacao = selectedAvaliacao;
    }

    public ProprietarioImovel getProprietarioImovelVisao() {
	if (this.proprietarioImovelVisao == null) {
	    this.proprietarioImovelVisao = new ProprietarioImovel();
	}
	
	if(this.proprietarioImovelVisao.getPapel() == null) {
	    this.proprietarioImovelVisao.setPapel(new PapelProprietario());
	}
	return this.proprietarioImovelVisao;
    }

    public void setProprietarioImovelVisao(final ProprietarioImovel proprietario) {
	this.proprietarioImovelVisao = proprietario;
    }

    public ProprietarioImovel getProprietarioImovelVisaoExclusao() {
	return this.proprietarioImovelVisaoExclusao;
    }

    public void setProprietarioImovelVisaoExclusao(final ProprietarioImovel proprietarioImovelVisaoExclusao) {
	this.proprietarioImovelVisaoExclusao = proprietarioImovelVisaoExclusao;
    }

    public List<ProprietarioImovel> getListaProprietarioImovelExclusao() {
	if (this.listaProprietarioImovelExclusao == null) {
	    this.listaProprietarioImovelExclusao = new ArrayList<>();
	}
	return this.listaProprietarioImovelExclusao;
    }

    public void setListaProprietarioImovelExclusao(final List<ProprietarioImovel> listaProprietarioImovelExclusao) {
	this.listaProprietarioImovelExclusao = listaProprietarioImovelExclusao;
    }

    public List<ProprietarioImovel> getListaHistoricoProprietarioImovel() {
        return this.listaHistoricoProprietarioImovel;
    }

    public void setListaHistoricoProprietarioImovel(List<ProprietarioImovel> listaHistoricoProprietarioImovel) {
        this.listaHistoricoProprietarioImovel = listaHistoricoProprietarioImovel;
    }

    public List<PapelProprietario> getListaPapelProprietario() {
	return this.listaPapelProprietario;
    }

    public void setListaPapelProprietario(List<PapelProprietario> listaPapelProprietario) {
	this.listaPapelProprietario = listaPapelProprietario;
    }

    public String getCpfCnpjAvalicao() {
	return cpfCnpjAvalicao;
    }

    public void setCpfCnpjAvalicao(String cpfCnpjAvalicao) {
	this.cpfCnpjAvalicao = cpfCnpjAvalicao;
    }

    public List<EstadoOcupacaoImovelEnum> getListaEstadoOcupacao() {
	if(UtilObjeto.isVazio(this.listaEstadoOcupacao)) {
	    this.listaEstadoOcupacao = new ArrayList<>();
	    this.listaEstadoOcupacao.addAll(Arrays.asList(EstadoOcupacaoImovelEnum.values()));
	}
        return this.listaEstadoOcupacao;
    }

    public void setListaEstadoOcupacao(final List<EstadoOcupacaoImovelEnum> listaEstadoOcupacao) {
        this.listaEstadoOcupacao = listaEstadoOcupacao;
    }
    
    

}
