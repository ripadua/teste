/**
 * Copyright (c) 2014 Caixa Econômica Federal. Todos os direitos
 * reservados.
 *
 * Caixa Econômica Federal - SIACG - Sistema de Crédito Rural
 *
 * Este software foi desenvolvido sob demanda da CAIXA e está
 * protegido por leis de direitos autorais e tratados internacionais. As
 * condições de cópia e utilização do total ou partes dependem de autorização da
 * pessoa. Cópias não são permitidas sem expressa autorização. Não pode ser
 * comercializado ou utilizado para propósitos particulares.
 *
 * Uso exclusivo da Caixa Econômica Federal. A reprodução ou distribuição não
 * autorizada deste programa ou de parte dele, resultará em punições civis e
 * criminais e os infratores incorrem em sanções previstas na legislação em
 * vigor.
 *
 * Histórico do Subversion:
 *
 * LastChangedRevision: $Revision$
 * LastChangedBy: $Author$
 * LastChangedDate: $Date$
 *
 * HeadURL: $HeadURL$
 *
 */
package br.gov.caixa.siacg.view.form;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;

import br.gov.caixa.pedesgo.arquitetura.util.UtilObjeto;
import br.gov.caixa.pedesgo.arquitetura.visao.ManutencaoVisao;
import br.gov.caixa.siacg.model.domain.Contrato;
import br.gov.caixa.siacg.model.domain.GrupoGarantia;
import br.gov.caixa.siacg.model.enums.SegmentacaoEnum;
import br.gov.caixa.siacg.model.enums.SituacaoEndividamentoEnum;
import br.gov.caixa.siacg.model.vo.SrVO;
import br.gov.caixa.siacg.model.vo.UnidadeVO;

/**
 * <p>
 * AcompanhamentoEndividamentoVisao.
 * </p>
 * <p>
 * Descrição: Visão para o Acompanhamento de Endividamento
 * </p>
 * <br>
 * <b>Empresa:</b> Cef - Caixa Econômica Federal
 *
 * @author Caio Graco
 * @version 1.0
 */

public class AcompanhamentoEndividamentoVisao extends ManutencaoVisao<Contrato> {

    /** Constante serialVersionUID. */
    private static final long serialVersionUID = 3725867756577803030L;

    /** Atributo nu unidade. */
    private Integer nuUnidade;

    /** Atributo nu sr. */
    private Integer nuSr;

    /** Atributo nu suat. */
    private Integer nuSuat;

    /** Atributo habilitar suat. */
    private boolean habilitarSuat;

    /** Atributo habilitar sr. */
    private boolean habilitarSr;

    /** Atributo habilitar unidade. */
    private boolean habilitarUnidade;

    /** Atributo habilitarXLS. */
    private boolean habilitarXLS;

    // Listas
    /** Atributo garantias. */
    private Collection<GrupoGarantia> garantias;

    /** Atributo endividamentos. */
    private Collection<SituacaoEndividamentoEnum> endividamentos;

    /** Atributo listaSegmento. */
    private Collection<SegmentacaoEnum> listaSegmento;

    /** Atributo unidade list. */
    private Collection<UnidadeVO> unidadeList;

    /** Atributo suat list. */
    private Collection<UnidadeVO> suatList;

    /** Atributo sr list. */
    private Collection<SrVO> srList;

    /**
     * Retorna o valor do atributo endividamentos.
     *
     * @return endividamentos
     */
    public Collection<SituacaoEndividamentoEnum> getEndividamentos() {
        if (UtilObjeto.isVazio(this.endividamentos)) {
            this.endividamentos = new ArrayList<>();
            this.endividamentos.addAll(Arrays.asList(SituacaoEndividamentoEnum.values()));
        }

        return this.endividamentos;
    }

    /**
     * Retorna o valor do atributo garantias.
     *
     * @return garantias
     */
    public Collection<GrupoGarantia> getGarantias() {
        return this.garantias;
    }

    /**
     * Retorna o valor do atributo listaSegmento.
     *
     * @return listaSegmento
     */
    public Collection<SegmentacaoEnum> getListaSegmento() {
        if (this.listaSegmento == null) {
            this.listaSegmento = Arrays.asList(SegmentacaoEnum.values());
        }
        return this.listaSegmento;
    }

    /**
     * Retorna o valor do atributo nuSr.
     *
     * @return nuSr
     */
    public Integer getNuSr() {

        return this.nuSr;
    }

    /**
     * Retorna o valor do atributo nuSuat.
     *
     * @return nuSuat
     */
    public Integer getNuSuat() {

        return this.nuSuat;
    }

    /**
     * Retorna o valor do atributo nuUnidade.
     *
     * @return nuUnidade
     */
    public Integer getNuUnidade() {

        return this.nuUnidade;
    }

    /**
     * Retorna o valor do atributo srList.
     *
     * @return srList
     */
    public Collection<SrVO> getSrList() {

        return this.srList;
    }

    /**
     * Retorna o valor do atributo suatList.
     *
     * @return suatList
     */
    public Collection<UnidadeVO> getSuatList() {

        return this.suatList;
    }

    /**
     * Retorna o valor do atributo unidadeList.
     *
     * @return unidadeList
     */
    public Collection<UnidadeVO> getUnidadeList() {

        return this.unidadeList;
    }

    /**
     * Retorna o valor do atributo habilitarSr.
     *
     * @return habilitarSr
     */
    public boolean isHabilitarSr() {

        return this.habilitarSr;
    }

    /**
     * Retorna o valor do atributo habilitarSuat.
     *
     * @return habilitarSuat
     */
    public boolean isHabilitarSuat() {

        return this.habilitarSuat;
    }

    /**
     * Retorna o valor do atributo habilitarUnidade.
     *
     * @return habilitarUnidade
     */
    public boolean isHabilitarUnidade() {

        return this.habilitarUnidade;
    }

    /**
     * Retorna o valor do atributo habilitarXLS.
     *
     * @return habilitarXLS
     */
    public boolean isHabilitarXLS() {

        return this.habilitarXLS;
    }

    /**
     * Define o valor do atributo garantias.
     *
     * @param garantias
     *            valor a ser atribuído
     */
    public void setGarantias(final Collection<GrupoGarantia> garantias) {
        this.garantias = garantias;
    }

    /**
     * Define o valor do atributo habilitarSr.
     *
     * @param habilitarSr
     *            valor a ser atribuído
     */
    public void setHabilitarSr(final boolean habilitarSr) {

        this.habilitarSr = habilitarSr;
    }

    /**
     * Define o valor do atributo habilitarSuat.
     *
     * @param habilitarSuat
     *            valor a ser atribuído
     */
    public void setHabilitarSuat(final boolean habilitarSuat) {

        this.habilitarSuat = habilitarSuat;
    }

    /**
     * Define o valor do atributo habilitarUnidade.
     *
     * @param habilitarUnidade
     *            valor a ser atribuído
     */
    public void setHabilitarUnidade(final boolean habilitarUnidade) {

        this.habilitarUnidade = habilitarUnidade;
    }

    /**
     * Define o valor do atributo habilitarXLS.
     *
     * @param habilitarXLS
     *            valor a ser atribuído
     */
    public void setHabilitarXLS(final boolean habilitarXLS) {

        this.habilitarXLS = habilitarXLS;
    }

    /**
     * Define o valor do atributo listaSegmento.
     *
     * @param listaSegmento
     *            valor a ser atribuído
     */
    public void setListaSegmento(final Collection<SegmentacaoEnum> listaSegmento) {
        this.listaSegmento = listaSegmento;
    }

    /**
     * Define o valor do atributo nuSr.
     *
     * @param nuSr
     *            valor a ser atribuído
     */
    public void setNuSr(final Integer nuSr) {

        this.nuSr = nuSr;
    }

    /**
     * Define o valor do atributo nuSuat.
     *
     * @param nuSuat
     *            valor a ser atribuído
     */
    public void setNuSuat(final Integer nuSuat) {

        this.nuSuat = nuSuat;
    }

    /**
     * Define o valor do atributo nuUnidade.
     *
     * @param nuUnidade
     *            valor a ser atribuído
     */
    public void setNuUnidade(final Integer nuUnidade) {

        this.nuUnidade = nuUnidade;
    }

    /**
     * Define o valor do atributo srList.
     *
     * @param srList
     *            valor a ser atribuído
     */
    public void setSrList(final Collection<SrVO> srList) {

        this.srList = srList;
    }

    /**
     * Define o valor do atributo suatList.
     *
     * @param suatList
     *            valor a ser atribuído
     */
    public void setSuatList(final Collection<UnidadeVO> suatList) {

        this.suatList = suatList;
    }

    /**
     * Define o valor do atributo unidadeList.
     *
     * @param unidadeList
     *            valor a ser atribuído
     */
    public void setUnidadeList(final Collection<UnidadeVO> unidadeList) {

        this.unidadeList = unidadeList;
    }
}