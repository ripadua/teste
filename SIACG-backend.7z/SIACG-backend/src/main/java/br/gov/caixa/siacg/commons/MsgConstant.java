/*
 * Copyright (c) 2019 Caixa Econômica Federal. Todos os direitos
 * reservados.
 *
 * Caixa Econômica Federal - SIACG - Sistema de Crédito Rural
 *
 * Este software foi desenvolvido sob demanda da CAIXA e está
 * protegido por leis de direitos autorais e tratados internacionais. As
 * condições de cópia e utilização do todo ou partes dependem de autorização da
 * empresa. Cópias não são permitidas sem expressa autorização. Não pode ser
 * comercializado ou utilizado para propósitos particulares.
 *
 * Uso exclusivo da Caixa Econômica Federal. A reprodução ou distribuição não
 * autorizada deste programa ou de parte dele, resultará em punições civis e
 * criminais e os infratores incorrem em sanções previstas na legislação em
 * vigor.
 *
 * Histórico do TFS:
 *
 * LastChangedRevision: $Revision$
 * LastChangedBy: $Author$
 * LastChangedDate: $Date$
 *
 * HeadURL: $HeadURL$
 *
 */

package br.gov.caixa.siacg.commons;

/**
 * <p>
 * MsgConstant
 * </p>
 * <p>
 * Descrição: Classe de constantes referentes as mensagens presentes no <code>app-mensagem.properties</code>
 * </p>
 * <br>
 * <b>Empresa:</b> Cef - Caixa Econômica Federal.
 *
 * @author Ludemeula Fernandes
 * @version 1.0
 */
public class MsgConstant {

	public static final String OPERACAO_COM_SUCESSO = "MA002";
	public static final String UH_DUPLICADA = "MN004";
	public static final String CAMPO_OBRIGATORIO = "MA009";
	public static final String ITEM_FORMULA_OBRIGATORIO = "MA018";
	public static final String GERACAO_ARQUIVO_SUCESSO = "MA021";
	public static final String GERACAO_ARQUIVO_ERRO = "MA022";
	
	public static final String CPF_CNPJ_NAO_ENCONTRADO = "MN073";
	public static final String EXCLUSAO_NAO_PERMITIDA_BEM_CLIENTE = "MN071";
	public static final String GARANTIA_VINCULADA_CONTRATO = "MN072";
	public static final String CONTRATO_NAO_LOCALIZADO_SIFEC = "MN074";
	public static final String VINCULO_CONTRATO_NAO_PERMITIDO = "MN075";
	
	public static final String SERVICO_INDISPONIVEL = "MN076";
	public static final String EXLUSAO_NAO_PERMITIDA_PORTE = "MN077";
	public static final String CHASSI_NUMERO_SERIE_DUPLICADO = "MN078";
	public static final String CONTRATO_INVALIDO_PARA_VINCULACAO = "MN079";
	public static final String CONTRATO_POSSUI_GARANTIA_VINCULADA = "MN080";
	public static final String NAO_FORAM_ENCONTRADOS_CONTRATOS_BASE = "MN081";
	public static final String BANDEIRA_DUPLICADA = "MN082";
	public static final String LISTA_PROPONENTES_VAZIA = "MN085";
	public static final String CEP_NAO_CADASTRADO_SIICO = "MN086";
	public static final String TIPO_USO_IMOVEL_OBRIGATORIO = "MN087";
	public static final String DADOS_INVALIDOS = "MN088";
	
	
	private MsgConstant() {
		super();
	}
}
