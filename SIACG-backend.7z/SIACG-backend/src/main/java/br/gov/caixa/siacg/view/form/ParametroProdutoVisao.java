/**
 * Copyright (c) 2015 Caixa Econômica Federal. Todos os direitos
 * reservados.
 *
 * Caixa Econômica Federal - SIACG - Sistema de Crédito Rural
 *
 * Este software foi desenvolvido sob demanda da CAIXA e está
 * protegido por leis de direitos autorais e tratados internacionais. As
 * condições de cópia e utilização do todo ou partes dependem de autorização da
 * pessoa. Cópias não são permitidas sem expressa autorização. Não pode ser
 * comercializado ou utilizado para propósitos particulares.
 *
 * Uso exclusivo da Caixa Econômica Federal. A reprodução ou distribuição não
 * autorizada deste programa ou de parte dele, resultará em punições civis e
 * criminais e os infratores incorrem em sanções previstas na legislação em
 * vigor.
 *
 * Histórico do Subversion:
 *
 * LastChangedRevision: $Revision$
 * LastChangedBy: $Author$
 * LastChangedDate: $Date$
 *
 * HeadURL: $HeadURL$
 *
 */
package br.gov.caixa.siacg.view.form;

import java.util.Collection;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import br.gov.caixa.pedesgo.arquitetura.visao.ManutencaoVisao;
import br.gov.caixa.siacg.model.domain.Garantia;
import br.gov.caixa.siacg.model.domain.ParametroGarantia;
import br.gov.caixa.siacg.model.domain.ParametroProduto;
import br.gov.caixa.siacg.model.domain.ParametroProdutoGestorProduto;
import br.gov.caixa.siacg.model.domain.SegmentoCliente;
import br.gov.caixa.siacg.model.domain.Unidade;
import br.gov.caixa.siacg.model.domain.ViewProdutoSiico;
import br.gov.caixa.siacg.model.vo.NumberNameVO;

/**
 * <p>
 * ParametroProdutoVisao
 * </p>
 * <p>
 * Descrição: Classe de visão para o Bean Gerenciado ParametroProdutoMB.
 * </p>
 * <br>
 * <b>Empresa:</b> Cef - Caixa Econômica Federal
 *
 * @author Leandro Severino -> lseverino@gmail.com
 * @version 1.0
 */
public class ParametroProdutoVisao extends ManutencaoVisao<ParametroProduto> {

    private static final long serialVersionUID = -7731966933957135497L;
    
    private static final String NOT_FOUND = "Não Encontrado";

    /** Atributo temProdutoSelecionado. */
    private Boolean temProdutoSelecionado = Boolean.FALSE;

    /** Atributo temProdutoHomologado. */
    private Boolean temProdutoHomologado = Boolean.FALSE;

    /** Atributo estaEmEdicao. */
    private Boolean estaEmEdicao = Boolean.FALSE;

    /** Atributo estaEmInclusao. */
    private Boolean estaEmInclusao = Boolean.FALSE;

    /** Atributo ehProdutoClonado. */
    private Boolean ehProdutoClonado = Boolean.FALSE;

    /** Atributo temContratoAssociado. */
    private Boolean temContratoAssociado = Boolean.FALSE;

    /** Atributo temNomeModalidadePreenchido. */
    private Boolean temNomeModalidadePreenchido = Boolean.FALSE;

    /** Atributo temProdutoEModalidadeSelecionadosParaClonar. */
    private Boolean temProdutoEModalidadeSelecionadosParaClonar = Boolean.FALSE;

    /** Atributo podeSalvarProduto. */
    private Boolean podeSalvarProduto = Boolean.FALSE;

    /** Atributo msgErroModalidadeExistente. */
    private String msgErroModalidadeExistente;

    /** Atributo msgErroUnidadeGestoraExistente. */
    private String msgErroUnidadeGestoraExistente;

    /** Atributo ViewProdutoSiico. */
    private ViewProdutoSiico viewProdutoSiico;

    /** Atributo produtoSelecionado. */
    private ParametroProduto produtoSelecionado;

    /** Atributo produtoSelecionadoClonar. */
    private ParametroProduto produtoSelecionadoClonar;

    /** Atributo modalidadeProdutoSelecionada. */
    private ParametroProduto modalidadeProdutoSelecionada;

    /** Atributo ehUnidadeGestoraSiico. */
    private String ehUnidadeGestoraSiico;

    /** Atributo modalidadeProdutoSelecionadaClonar. */
    private ParametroProduto modalidadeProdutoSelecionadaClonar;

    /** Atributo unidadeGestora. */
    private ParametroProdutoGestorProduto unidadeGestora;
    
    private List<SegmentoCliente> listaSegmentosCliente;

    /** Atributo unidadeSiicoSelecionada. */
    private Unidade unidadeSiicoSelecionada;

    /** Atributo listaProdutosTipoEmprestimo. */
    private Collection<ViewProdutoSiico> listaProdutosTipoEmprestimo;

    /** Atributo listaProdutosTipoGarantia. */
    private Collection<ViewProdutoSiico> listaProdutosTipoGarantia;

    /** Atributo listaGarantiasBacen. */
    private Collection<Garantia> listaGarantiasBacen;

    /** Atributo listaModalidades. */
    private Collection<ParametroProduto> listaModalidades;

    /** Atributo listaProdutosTipoEmprestimoClonar. */
    private Collection<ViewProdutoSiico> listaProdutosTipoEmprestimoClonar;

    /** Atributo listaModalidadesClonar. */
    private Collection<ParametroProduto> listaModalidadesClonar;

    /** Atributo listaUnidadesGestorasHomologar. */
    private Collection<ParametroProdutoGestorProduto> listaUnidadesGestorasHomologar;

    /** Atributo listaUnidadesGestoras. */
    private Collection<ParametroProdutoGestorProduto> listaUnidadesGestoras;

    /** Atributo listaUnidadesGestorasJaAssociadasAoProduto. */
    private Collection<ParametroProdutoGestorProduto> listaUnidadesGestorasJaAssociadasAoProduto;

    /** Atributo listaUnidadesSiico. */
    private Collection<Unidade> listaUnidadesSiico;

    /** Atributo listaGarantiasJaAssociadasAoProduto. */
    private Collection<ParametroGarantia> listaGarantiasJaAssociadasAoProduto;

    private Map<NumberNameVO, List<NumberNameVO>> mapProdutoPorModalidade;
    
   private boolean carregarTela = false;
    
    
    
    
    
    public void setProdutoSiicoNampeIntoMapProdutoPorModalidade() {
	for (final Entry<NumberNameVO, List<NumberNameVO>> entry : this.mapProdutoPorModalidade.entrySet()) {
	    entry.getKey().setName(this.getNameProdutoSiico(entry.getKey().getNumber()));
	}
    }
    
    private String getNameProdutoSiico (final Integer nuProduto) {
	for (final ViewProdutoSiico item : this.listaProdutosTipoEmprestimo) {
	    if (item.getProdutoSiicoID().getNuProduto().equals(nuProduto)) {
		return item.getNoProduto();
	    }
	}
	
	return NOT_FOUND;
    }

    /**
     * Retorna o valor do atributo msgErroModalidadeExistente.
     *
     * @return msgErroModalidadeExistente
     */
    public String getMsgErroModalidadeExistente() {
	return msgErroModalidadeExistente;
    }

    /**
     * Define o valor do atributo msgErroModalidadeExistente.
     *
     * @param msgErroModalidadeExistente
     *            valor a ser atribuído
     */
    public void setMsgErroModalidadeExistente(String msgErroModalidadeExistente) {
	this.msgErroModalidadeExistente = msgErroModalidadeExistente;
    }

    /**
     * Retorna o valor do atributo msgErroUnidadeGestoraExistente.
     *
     * @return msgErroUnidadeGestoraExistente
     */
    public String getMsgErroUnidadeGestoraExistente() {
	return msgErroUnidadeGestoraExistente;
    }

    /**
     * Define o valor do atributo msgErroUnidadeGestoraExistente.
     *
     * @param msgErroUnidadeGestoraExistente
     *            valor a ser atribuído
     */
    public void setMsgErroUnidadeGestoraExistente(String msgErroUnidadeGestoraExistente) {
	this.msgErroUnidadeGestoraExistente = msgErroUnidadeGestoraExistente;
    }

    /**
     * Retorna o valor do atributo temProdutoSelecionado.
     *
     * @return temProdutoSelecionado
     */
    public Boolean getTemProdutoSelecionado() {
	return temProdutoSelecionado;
    }

    /**
     * Define o valor do atributo temProdutoSelecionado.
     *
     * @param temProdutoSelecionado
     *            valor a ser atribuído
     */
    public void setTemProdutoSelecionado(Boolean temProdutoSelecionado) {
	this.temProdutoSelecionado = temProdutoSelecionado;
    }

    /**
     * Retorna o valor do atributo temProdutoHomologado.
     *
     * @return temProdutoHomologado
     */
    public Boolean getTemProdutoHomologado() {
	return temProdutoHomologado;
    }

    /**
     * Define o valor do atributo temProdutoSelecionado.
     *
     * @param temProdutoHomologado
     *            valor a ser atribuído
     */
    public void setTemProdutoHomologado(Boolean temProdutoHomologado) {
	this.temProdutoHomologado = temProdutoHomologado;
    }

    /**
     * Retorna o valor do atributo estaEmEdicao.
     *
     * @return estaEmEdicao
     */
    public Boolean getEstaEmEdicao() {
	return this.estaEmEdicao;
    }

    /**
     * Define o valor do atributo estaEmEdicao.
     *
     * @param estaEmEdicao
     *            valor a ser atribuído
     */
    public void setEstaEmEdicao(Boolean estaEmEdicao) {
	this.estaEmEdicao = estaEmEdicao;
    }

    /**
     * Retorna o valor do atributo estaEmInclusao.
     *
     * @return estaEmInclusao
     */
    public Boolean getEstaEmInclusao() {
	return this.estaEmInclusao;
    }

    /**
     * Define o valor do atributo estaEmInclusao.
     *
     * @param estaEmInclusao
     *            valor a ser atribuído
     */
    public void setEstaEmInclusao(Boolean estaEmInclusao) {
	this.estaEmInclusao = estaEmInclusao;
    }

    /**
     * Retorna o valor do atributo ehProdutoClonado.
     *
     * @return ehProdutoClonado
     */
    public Boolean getEhProdutoClonado() {
	return this.ehProdutoClonado;
    }

    /**
     * Define o valor do atributo ehProdutoClonado.
     *
     * @param ehProdutoClonado
     *            valor a ser atribuído
     */
    public void setEhProdutoClonado(Boolean ehProdutoClonado) {
	this.ehProdutoClonado = ehProdutoClonado;
    }

    /**
     * Retorna o valor do atributo temContratoAssociado.
     *
     * @return temContratoAssociado
     */
    public Boolean getTemContratoAssociado() {
	return this.temContratoAssociado;
    }

    /**
     * Define o valor do atributo temContratoAssociado.
     *
     * @param temContratoAssociado
     *            valor a ser atribuído
     */
    public void setTemContratoAssociado(Boolean temContratoAssociado) {
	this.temContratoAssociado = temContratoAssociado;
    }

    /**
     * Retorna o valor do atributo temNomeModalidadePreenchido.
     *
     * @return temNomeModalidadePreenchido
     */
    public Boolean getTemNomeModalidadePreenchido() {
	return this.temNomeModalidadePreenchido;
    }

    /**
     * Define o valor do atributo temNomeModalidadePreenchido.
     *
     * @param temNomeModalidadePreenchido
     *            valor a ser atribuído
     */
    public void setTemNomeModalidadePreenchido(Boolean temNomeModalidadePreenchido) {
	this.temNomeModalidadePreenchido = temNomeModalidadePreenchido;
    }

    /**
     * Retorna o valor do atributo temProdutoEModalidadeSelecionadosParaClonar.
     *
     * @return temProdutoEModalidadeSelecionadosParaClonar
     */
    public Boolean getTemProdutoEModalidadeSelecionadosParaClonar() {
	return this.temProdutoEModalidadeSelecionadosParaClonar;
    }

    /**
     * Define o valor do atributo temProdutoEModalidadeSelecionadosParaClonar.
     *
     * @param temProdutoEModalidadeSelecionadosParaClonar
     *            valor a ser atribuído
     */
    public void setTemProdutoEModalidadeSelecionadosParaClonar(Boolean temProdutoEModalidadeSelecionadosParaClonar) {
	this.temProdutoEModalidadeSelecionadosParaClonar = temProdutoEModalidadeSelecionadosParaClonar;
    }

    /**
     * Retorna o valor do atributo podeSalvarProduto.
     *
     * @return podeSalvarProduto
     */
    public Boolean getPodeSalvarProduto() {
	return this.podeSalvarProduto;
    }

    /**
     * Define o valor do atributo podeSalvarProduto.
     *
     * @param podeSalvarProduto
     *            valor a ser atribuído
     */
    public void setPodeSalvarProduto(Boolean podeSalvarProduto) {
	this.podeSalvarProduto = podeSalvarProduto;
    }

    /**
     * Retorna o valor do atributo viewProdutoSiico.
     *
     * @return viewProdutoSiico
     */
    public ViewProdutoSiico getViewProdutoSiico() {

	return this.viewProdutoSiico;
    }

    /**
     * Define o valor do atributo viewProdutoSiico.
     *
     * @param viewProdutoSiico
     *            valor a ser atribuído
     */
    public void setViewProdutoSiico(final ViewProdutoSiico viewProdutoSiico) {

	this.viewProdutoSiico = viewProdutoSiico;
    }

    /**
     * Retorna o valor do atributo produtoSelecionado.
     *
     * @return produtoSelecionado
     */
    public ParametroProduto getProdutoSelecionado() {
	if(this.produtoSelecionado == null) {
	    this.produtoSelecionado = new ParametroProduto();
	}
	return this.produtoSelecionado;
    }

    /**
     * Define o valor do atributo produtoSelecionado.
     *
     * @param produtoSelecionado
     *            valor a ser atribuído
     */
    public void setProdutoSelecionado(final ParametroProduto produtoSelecionado) {

	this.produtoSelecionado = produtoSelecionado;
    }

    /**
     * Retorna o valor do atributo produtoSelecionadoClonar.
     *
     * @return produtoSelecionadoClonar
     */
    public ParametroProduto getProdutoSelecionadoClonar() {

	return this.produtoSelecionadoClonar;
    }

    /**
     * Define o valor do atributo produtoSelecionadoClonar.
     *
     * @param produtoSelecionadoClonar
     *            valor a ser atribuído
     */
    public void setProdutoSelecionadoClonar(final ParametroProduto produtoSelecionadoClonar) {

	this.produtoSelecionadoClonar = produtoSelecionadoClonar;
    }

    /**
     * Retorna o valor do atributo ehUnidadeGestoraSiico.
     *
     * @return ehUnidadeGestoraSiico
     */
    public String getEhUnidadeGestoraSiico() {
	return ehUnidadeGestoraSiico;
    }

    /**
     * Define o valor do atributo ehUnidadeGestoraSiico.
     *
     * @param ehUnidadeGestoraSiico
     *            valor a ser atribuído
     */
    public void setEhUnidadeGestoraSiico(String ehUnidadeGestoraSiico) {
	this.ehUnidadeGestoraSiico = ehUnidadeGestoraSiico;
    }

    /**
     * Retorna o valor do atributo modalidadeProdutoSelecionada.
     *
     * @return modalidadeProdutoSelecionada
     */
    public ParametroProduto getModalidadeProdutoSelecionada() {

	return this.modalidadeProdutoSelecionada;
    }

    /**
     * Define o valor do atributo modalidadeProdutoSelecionada.
     *
     * @param modalidadeProdutoSelecionada
     *            valor a ser atribuído
     */
    public void setModalidadeProdutoSelecionada(final ParametroProduto modalidadeProdutoSelecionada) {

	this.modalidadeProdutoSelecionada = modalidadeProdutoSelecionada;
    }

    /**
     * Retorna o valor do atributo modalidadeProdutoSelecionadaClonar.
     *
     * @return modalidadeProdutoSelecionadaClonar
     */
    public ParametroProduto getModalidadeProdutoSelecionadaClonar() {

	return this.modalidadeProdutoSelecionadaClonar;
    }

    /**
     * Define o valor do atributo modalidadeProdutoSelecionadaClonar.
     *
     * @param modalidadeProdutoSelecionadaClonar
     *            valor a ser atribuído
     */
    public void setModalidadeProdutoSelecionadaClonar(final ParametroProduto modalidadeProdutoSelecionadaClonar) {

	this.modalidadeProdutoSelecionadaClonar = modalidadeProdutoSelecionadaClonar;
    }

    /**
     * Retorna o valor do atributo unidadeGestora.
     *
     * @return unidadeGestora
     */
    public ParametroProdutoGestorProduto getUnidadeGestora() {

	return this.unidadeGestora;
    }

    /**
     * Define o valor do atributo unidadeGestora.
     *
     * @param unidadeGestora
     *            valor a ser atribuído
     */
    public void setUnidadeGestora(final ParametroProdutoGestorProduto unidadeGestora) {

	this.unidadeGestora = unidadeGestora;
    }

    /**
     * Retorna o valor do atributo unidadeSiicoSelecionada.
     *
     * @return unidadeSiicoSelecionada
     */
    public Unidade getUnidadeGestoraSelecionada() {

	return this.unidadeSiicoSelecionada;
    }

    /**
     * Define o valor do atributo unidadeGestora.
     *
     * @param unidadeGestora
     *            valor a ser atribuído
     */
    public void setUnidadeGestoraSelecionada(final Unidade unidadeSiicoSelecionada) {

	this.unidadeSiicoSelecionada = unidadeSiicoSelecionada;
    }

    /**
     * Retorna o valor do atributo listaProdutosTipoEmprestimo.
     *
     * @return listaProdutosTipoEmprestimo
     */
    public Collection<ViewProdutoSiico> getListaProdutosTipoEmprestimo() {

	return this.listaProdutosTipoEmprestimo;
    }

    /**
     * Define o valor do atributo listaProdutosTipoEmprestimo.
     *
     * @param listaProdutosTipoEmprestimo
     *            valor a ser atribuído
     */
    public void setListaProdutosTipoEmprestimo(final Collection<ViewProdutoSiico> listaProdutosTipoEmprestimo) {

	this.listaProdutosTipoEmprestimo = listaProdutosTipoEmprestimo;
    }

    /**
     * Retorna o valor do atributo listaProdutosTipoGarantia.
     *
     * @return listaProdutosTipoGarantia
     */
    public Collection<ViewProdutoSiico> getListaProdutosTipoGarantia() {

	return this.listaProdutosTipoGarantia;
    }

    /**
     * Define o valor do atributo listaProdutosTipoGarantia.
     *
     * @param listaProdutosTipoGarantia
     *            valor a ser atribuído
     */
    public void setListaProdutosTipoGarantia(final Collection<ViewProdutoSiico> listaProdutosTipoGarantia) {

	this.listaProdutosTipoGarantia = listaProdutosTipoGarantia;
    }

    /**
     * Retorna o valor do atributo listaGarantiasBacen.
     *
     * @return listaGarantiasBacen
     */
    public Collection<Garantia> getListaGarantiasBacen() {

	return this.listaGarantiasBacen;
    }

    /**
     * Define o valor do atributo listaGarantiasBacen.
     *
     * @param listaGarantiasBacen
     *            valor a ser atribuído
     */
    public void setListaGarantiasBacen(final Collection<Garantia> listaGarantiasBacen) {

	this.listaGarantiasBacen = listaGarantiasBacen;
    }

    /**
     * Retorna o valor do atributo listaProdutosTipoEmprestimoClonar.
     *
     * @return listaProdutosTipoEmprestimoClonar
     */
    public Collection<ViewProdutoSiico> getListaProdutosTipoEmprestimoClonar() {

	return this.listaProdutosTipoEmprestimoClonar;
    }

    /**
     * Define o valor do atributo listaProdutosTipoEmprestimoClonar.
     *
     * @param listaProdutosTipoEmprestimoClonar
     *            valor a ser atribuído
     */
    public void setListaProdutosTipoEmprestimoClonar(final Collection<ViewProdutoSiico> listaProdutosTipoEmprestimoClonar) {

	this.listaProdutosTipoEmprestimoClonar = listaProdutosTipoEmprestimoClonar;
    }

    /**
     * Retorna o valor do atributo listaModalidades.
     *
     * @return listaModalidades
     */
    public Collection<ParametroProduto> getListaModalidades() {

	return this.listaModalidades;
    }

    /**
     * Define o valor do atributo listaModalidades.
     *
     * @param listaModalidades
     *            valor a ser atribuído
     */
    public void setListaModalidades(final Collection<ParametroProduto> listaModalidades) {

	this.listaModalidades = listaModalidades;
    }

    /**
     * Retorna o valor do atributo listaModalidadesClonar.
     *
     * @return listaModalidadesClonar
     */
    public Collection<ParametroProduto> getListaModalidadesClonar() {

	return this.listaModalidadesClonar;
    }

    /**
     * Define o valor do atributo listaModalidadesClonar.
     *
     * @param listaModalidadesClonar
     *            valor a ser atribuído
     */
    public void setListaModalidadesClonar(final Collection<ParametroProduto> listaModalidadesClonar) {

	this.listaModalidadesClonar = listaModalidadesClonar;
    }

    /**
     * Retorna o valor do atributo listaUnidadesGestoras.
     *
     * @return listaUnidadesGestoras
     */
    public Collection<ParametroProdutoGestorProduto> getListaUnidadesGestoras() {

	return this.listaUnidadesGestoras;
    }

    /**
     * Define o valor do atributo listaUnidadesGestoras.
     *
     * @param listaUnidadesGestoras
     *            valor a ser atribuído
     */
    public void setListaUnidadesGestoras(final Collection<ParametroProdutoGestorProduto> listaUnidadesGestoras) {

	this.listaUnidadesGestoras = listaUnidadesGestoras;
    }

    /**
     * Retorna o valor do atributo listaUnidadesGestorasJaAssociadasAoProduto.
     *
     * @return listaUnidadesGestorasJaAssociadasAoProduto
     */
    public Collection<ParametroProdutoGestorProduto> getListaUnidadesGestorasJaAssociadasAoProduto() {

	return this.listaUnidadesGestorasJaAssociadasAoProduto;
    }

    /**
     * Define o valor do atributo listaUnidadesGestorasJaAssociadasAoProduto.
     *
     * @param listaUnidadesGestorasJaAssociadasAoProduto
     *            valor a ser atribuído
     */
    public void setListaUnidadesGestorasJaAssociadasAoProduto(
	    final Collection<ParametroProdutoGestorProduto> listaUnidadesGestorasJaAssociadasAoProduto) {

	this.listaUnidadesGestorasJaAssociadasAoProduto = listaUnidadesGestorasJaAssociadasAoProduto;
    }

    /**
     * Retorna o valor do atributo listaUnidadesGestorasHomologar.
     *
     * @return listaUnidadesGestorasHomologar
     */
    public Collection<ParametroProdutoGestorProduto> getListaUnidadesGestorasHomologar() {

	return this.listaUnidadesGestorasHomologar;
    }

    /**
     * Define o valor do atributo listaUnidadesGestorasHomologar.
     *
     * @param listaUnidadesGestorasHomologar
     *            valor a ser atribuído
     */
    public void setListaUnidadesGestorasHomologar(final Collection<ParametroProdutoGestorProduto> listaUnidadesGestorasHomologar) {

	this.listaUnidadesGestorasHomologar = listaUnidadesGestorasHomologar;
    }

    /**
     * Retorna o valor do atributo listaGarantiasJaAssociadasAoProduto.
     *
     * @return listaGarantiasJaAssociadasAoProduto
     */
    public Collection<ParametroGarantia> getListaGarantiasJaAssociadasAoProduto() {    	
    	return this.listaGarantiasJaAssociadasAoProduto;
    }

    /**
     * Define o valor do atributo listaGarantiasJaAssociadasAoProduto.
     *
     * @param listaGarantiasJaAssociadasAoProduto
     *            valor a ser atribuído
     */
    public void setListaGarantiasJaAssociadasAoProduto(final Collection<ParametroGarantia> listaGarantiasJaAssociadasAoProduto) {

	this.listaGarantiasJaAssociadasAoProduto = listaGarantiasJaAssociadasAoProduto;
    }

    /**
     * Retorna o valor do atributo listaUnidadesSiico.
     *
     * @return listaUnidadesSiico
     */
    public Collection<Unidade> getListaUnidadesSiico() {

	return this.listaUnidadesSiico;
    }

    /**
     * Define o valor do atributo listaUnidadesSiico.
     *
     * @param listaUnidadesSiico
     *            valor a ser atribuído
     */
    public void setListaUnidadesSiico(final Collection<Unidade> listaUnidadesSiico) {

	this.listaUnidadesSiico = listaUnidadesSiico;
    }

    /**
     * @return the mapProdutoPorModalidade
     */
    public Map<NumberNameVO, List<NumberNameVO>> getMapProdutoPorModalidade() {
	return mapProdutoPorModalidade;
    }

    /**
     * @param mapProdutoPorModalidade
     *            the mapProdutoPorModalidade to set
     */
    public void setMapProdutoPorModalidade(Map<NumberNameVO, List<NumberNameVO>> mapProdutoPorModalidade) {
	this.mapProdutoPorModalidade = mapProdutoPorModalidade;
    }

    /**
     * @see br.gov.caixa.pedesgo.arquitetura.visao.ManutencaoVisao#getEntidade()
     */
    @Override
    public ParametroProduto getEntidade() {
	if (super.getEntidade() == null) {
	    super.setEntidade(new ParametroProduto());
	    // TODO mexi aqui super.getEntidade().setModalidade(new
	    // ParametroProdutoModalidade());
	    // TODO mexi aqui super.getEntidade().setUnidadeGestora(new
	    // ParametroProdutoGestorProduto());
	}
	return super.getEntidade();
    }

    /**
     * <p>Retorna o valor do atributo carregarTela</p>.
     *
     * @return carregarTela
    */
    public boolean isCarregarTela() {
	return this.carregarTela;
    }

    /**
     * <p>Define o valor do atributo carregarTela</p>.
     *
     * @param carregarTela valor a ser atribuído
    */
    public void setCarregarTela(boolean carregarTela) {
	this.carregarTela = carregarTela;
    }
    
    public List<SegmentoCliente> getListaSegmentosCliente() {
		return listaSegmentosCliente;
	}

	public void setListaSegmentosCliente(List<SegmentoCliente> listaSegmentosCliente) {
		this.listaSegmentosCliente = listaSegmentosCliente;
	}

}

