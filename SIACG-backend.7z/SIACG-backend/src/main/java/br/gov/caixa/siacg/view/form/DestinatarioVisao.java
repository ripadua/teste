package br.gov.caixa.siacg.view.form;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import br.gov.caixa.pedesgo.arquitetura.visao.ManutencaoVisao;
import br.gov.caixa.siacg.comum.to.sifec.RelatorioDestinatarioTO;
import br.gov.caixa.siacg.model.domain.Destinatario;
import br.gov.caixa.siacg.model.enums.RelatorioDestinatarioEnum;

/**
 * <p>
 * DestinatarioVisao
 * </p>
 * <p>
 * Descrição: Classe DestinatarioVisao
 * </p>
 * <br>
 * <b>Empresa:</b> Cef - Caixa Econômica Federal.
 *
 * @author GS Tecnologia
 * @version 1.0
 */
public class DestinatarioVisao extends ManutencaoVisao<Destinatario> {

    /** Constante serialVersionUID. */
    private static final long serialVersionUID = 1240145123096667341L;

    /** Atributo destinatario list. */
    private List<Destinatario> destinatarioList;

    /** Atributo destinatario. */
    private Destinatario destinatario;
    
    private List<RelatorioDestinatarioTO> relatorioDestinatarioLists;

    /** Constante PAGINA_DESTINATARIO. */
    public static final String PAGINA_DESTINATARIO = "/pages/destinatario/destinatario.xhtml?faces-redirect=true";

    /**
     * Construtor destinatario visao.
     */
    public DestinatarioVisao() {
        this.destinatarioList = new ArrayList<>();
        this.destinatario = new Destinatario();
    }

    /**
     * Retorna o valor do atributo destinatarioList.
     *
     * @return destinatarioList
     */
    public List<Destinatario> getDestinatarioList() {
        this.destinatarioList = new ArrayList<>(this.destinatarioList);
        return this.destinatarioList;
    }
    
    /**
     * RelatorioDestinatarioEnum as {@link ArrayList}
     * @return
     */
    public List<RelatorioDestinatarioEnum> getRelatorioDestinatario(){
    	return Arrays.asList(RelatorioDestinatarioEnum.values());
    }

    /**
     * Define o valor do atributo destinatarioList.
     *
     * @param destinatarioList
     *            valor a ser atribuído
     */
    public void setDestinatarioList(final List<Destinatario> destinatarioList) {
        this.destinatarioList = destinatarioList;
    }

    /**
     * Retorna o valor do atributo destinatario.
     *
     * @return destinatario
     */
    public Destinatario getDestinatario() {

        return this.destinatario;
    }

    /**
     * Define o valor do atributo destinatario.
     *
     * @param destinatario
     *            valor a ser atribuído
     */
    public void setDestinatario(final Destinatario destinatario) {

        this.destinatario = destinatario;
    }

    /**
     * <p>
     * Método responsável por.
     * <p>
     *
     * @param ic
     *            valor a ser atribuido
     * @return String
     */
    public String mostrarNomeDestinatario(final String ic) {
        String retorno = "";
        if ("01".equals(ic)) {
            retorno = "Gestor do Sistema";
        } else if ("02".equals(ic)) {
            retorno = "Auditoria";
        } else if ("03".equals(ic)) {
            retorno = "Gestor do Risco";
        } else if ("04".equals(ic)) {
            retorno = "BI / Relatórios";
        }

        return retorno;

    }

	/**
	 * @return the relatorioDestinatarioLists
	 */
	public List<RelatorioDestinatarioTO> getRelatorioDestinatarioLists() {
		if(relatorioDestinatarioLists == null) {
			relatorioDestinatarioLists = new ArrayList<RelatorioDestinatarioTO>();
		}
		return relatorioDestinatarioLists;
	}

	/**
	 * @param relatorioDestinatarioLists the relatorioDestinatarioLists to set
	 */
	public void setRelatorioDestinatarioLists(List<RelatorioDestinatarioTO> relatorioDestinatarioLists) {
		this.relatorioDestinatarioLists = relatorioDestinatarioLists;
	}
}
