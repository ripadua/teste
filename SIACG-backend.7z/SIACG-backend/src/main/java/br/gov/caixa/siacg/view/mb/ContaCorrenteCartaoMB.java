/*
 * Copyright (c) 2019 Caixa Econômica Federal. Todos os direitos
 * reservados.
 *
 * Caixa Econômica Federal - SIACG - Sistema de Crédito Rural
 *
 * Este software foi desenvolvido sob demanda da CAIXA e está
 * protegido por leis de direitos autorais e tratados internacionais. As
 * condições de cópia e utilização do todo ou partes dependem de autorização da
 * empresa. Cópias não são permitidas sem expressa autorização. Não pode ser
 * comercializado ou utilizado para propósitos particulares.
 *
 * Uso exclusivo da Caixa Econômica Federal. A reprodução ou distribuição não
 * autorizada deste programa ou de parte dele, resultará em punições civis e
 * criminais e os infratores incorrem em sanções previstas na legislação em
 * vigor.
 *
 * Histórico do TFS:
 *
 * LastChangedRevision: $Revision$
 * LastChangedBy: $Author$
 * LastChangedDate: $Date$
 *
 * HeadURL: $HeadURL$
 *
 */
package br.gov.caixa.siacg.view.mb;

import java.math.BigDecimal;
import java.math.MathContext;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import javax.ejb.EJB;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.RequestScoped;
import javax.faces.context.FacesContext;
import javax.inject.Inject;
import javax.servlet.http.HttpServletRequest;

import br.gov.caixa.pedesgo.arquitetura.controlador.ManutencaoBean;
import br.gov.caixa.pedesgo.arquitetura.util.UtilObjeto;
import br.gov.caixa.siacg.model.domain.BandeiraCartao;
import br.gov.caixa.siacg.model.domain.ContaContrato;
import br.gov.caixa.siacg.model.domain.ContaCorrente;
import br.gov.caixa.siacg.model.domain.GarantiaCartaoCredito;
import br.gov.caixa.siacg.model.domain.GarantiaContrato;
import br.gov.caixa.siacg.model.vo.ContaCorrenteBandeirasVO;
import br.gov.caixa.siacg.service.ParametrizacaoContratoService;
import br.gov.caixa.siacg.service.RelatorioAnaliseService;
import br.gov.caixa.siacg.view.form.ContaCorrenteCartaoVisao;

/**
 * <p>
 * ContaCorrenteCartaoMB
 * </p>
 *
 * <p>
 * Descrição: Managed bean do caso de uso <code>Conta Corrente Cartao</code>.
 * </p>
 *
 * <br>
 * <b>Empresa:</b> Cef - Caixa Econômica Federal
 *
 *
 * @author Mábio Barbosa
 *
 * @version 1.0
 */
@ManagedBean(name = ContaCorrenteCartaoMB.NOME_MANAGED_BEAN)
@RequestScoped
public class ContaCorrenteCartaoMB extends ManutencaoBean<GarantiaContrato> {

    /** Atributo serialVersionUID. */
    private static final long serialVersionUID = -4358735182321964703L;

    /** Atributo PREFIXO_CASO_USO. */
    private static final String PREFIXO_CASO_USO = "contaCorrenteCartao";

    /** Atributo NOME_MANAGED_BEAN. */
    public static final String NOME_MANAGED_BEAN = "contaCorrenteCartaoMB";

    /** Atributo EL_MANAGED_BEAN. */
    public static final String EL_MANAGED_BEAN = "#{contaCorrenteCartaoMB}";

    /** Atributo visao. */
    private ContaCorrenteCartaoVisao visao;

    /** Atributo service. */
    @EJB
    private transient ParametrizacaoContratoService service;

    @Inject
    private RelatorioAnaliseService relatorioAnaliseService;

    @Override
    protected String getPrefixoCasoDeUso() {
	return ContaCorrenteCartaoMB.PREFIXO_CASO_USO;
    }

    @SuppressWarnings("unchecked")
    @Override
    public ParametrizacaoContratoService getService() {
	return this.service;
    }

    /**
     * @see br.gov.caixa.pedesgo.arquitetura.controlador.AbstractBean#getVisao()
     */
    @Override
    public ContaCorrenteCartaoVisao getVisao() {
	if (!UtilObjeto.isReferencia(this.visao)) {
	    this.visao = new ContaCorrenteCartaoVisao();
	}
	return this.visao;
    }

    /**
     * <p>
     * Método responsável por consultar GarantiaCartaoCredito.
     * <p>
     *
     * @param conta
     *            valor a ser atribuido
     * @param idGarantiaContrato
     *            valor a ser atribuido
     * @param bandeira
     *            valor a ser atribuido
     * @return GarantiaCartaoCredito
     * @author guilherme.santos
     * @author Mábio Barbosa
     * @author gerusa.soares
     */
    private GarantiaCartaoCredito consultarGarantiaCartaoCredito(final ContaCorrente conta, final Integer idGarantiaContrato,
	    final BandeiraCartao bandeiraCartao) {
	GarantiaCartaoCredito retorno = null;

	if (idGarantiaContrato != null) {
	    retorno = this.service.obterGarantiaCartaoCredito(conta, idGarantiaContrato, bandeiraCartao);
	}
	
	final boolean isNovaParametrizacao = retorno == null || retorno.getNuGarantiaCartaoCredito() == null;
	
	if (isNovaParametrizacao) {
	    retorno = new GarantiaCartaoCredito();
	    retorno.setBandeiraCartao(bandeiraCartao);
	    retorno.setNuConta(conta);
	    retorno.setGarantiaContrato(this.getVisao().getEntidade());
	} 

	boolean atualizouConformeVisao = false;
	
	//atualiza demais campos conforme o que está na lista da visão, por possuir os dados mais atualizados.
	for(ContaCorrenteBandeirasVO ccb: this.getVisao().getListaContaCorrenteBandeiras()) {
		 for(GarantiaCartaoCredito gcc: ccb.getListaGarantiaCartaoCredito()) {
		     if(gcc.getBandeiraCartao().equals(bandeiraCartao) && gcc.getNuConta().equals(conta)) {
			 retorno.setIcMarcado(gcc.isIcMarcado());
			 retorno.setPcConcentracao(gcc.getPcConcentracao());
			 retorno.setVrConstituido(gcc.getVrConstituido());
			 atualizouConformeVisao = true;
			 break;
		     }
		 }
	    }
	
	if(!isNovaParametrizacao && !atualizouConformeVisao) {
	    retorno.setIcMarcado(Boolean.TRUE);
	    retorno.setVrConstituido(this.obterValorPactuadoCartaoCredito(retorno));
	}
	
	return retorno;
    }

    /**
     * <p>
     * Método responsável por obter o valor pactuado da bandeira
     * </p>
     * .
     *
     * @author Mábio Barbosa
     *
     * @param garantiaCartaoCredito
     */
    private BigDecimal obterValorPactuadoCartaoCredito(GarantiaCartaoCredito garantiaCartaoCredito) {
	BigDecimal vlBandeira = new BigDecimal(0);

	if (isGarantiaContrato(garantiaCartaoCredito) && isPercConcentracao(garantiaCartaoCredito)
		&& isValorFormaGarantia(garantiaCartaoCredito.getGarantiaContrato()) && isPcConcentracao(garantiaCartaoCredito)) {

	    BigDecimal vrFormaGarantia1 = garantiaCartaoCredito.getGarantiaContrato().getVrFormaGarantia1();
	    BigDecimal totalValorPactuado = this.getVisao().getVrTotalPactuadaContratoGarantiaCartao();
	    BigDecimal pcConcentracao = garantiaCartaoCredito.getPcConcentracao();
	    if (vrFormaGarantia1.compareTo(new BigDecimal(0)) > 0) {
		BigDecimal percCalc = pcConcentracao.divide(vrFormaGarantia1, MathContext.DECIMAL128).multiply(new BigDecimal(100));
		vlBandeira = percCalc.divide(new BigDecimal(100)).multiply(totalValorPactuado);
	    }
	}
	return vlBandeira;
    }

	private boolean isPcConcentracao(GarantiaCartaoCredito garantiaCartaoCredito) {
		return garantiaCartaoCredito != null && garantiaCartaoCredito.getPcConcentracao() != null && garantiaCartaoCredito.getPcConcentracao().compareTo(new BigDecimal(0)) > 0;
	}

	private boolean isValorFormaGarantia(GarantiaContrato garantiaContrato) {
		return garantiaContrato != null && garantiaContrato.getVrFormaGarantia1() != null;
	}
	
	private boolean isPercConcentracao(GarantiaCartaoCredito garantiaCartaoCredito) {
		return garantiaCartaoCredito != null && garantiaCartaoCredito.getPcConcentracao() != null;
	}

	private boolean isGarantiaContrato(GarantiaCartaoCredito garantiaCartaoCredito) {
		return garantiaCartaoCredito != null && garantiaCartaoCredito.getGarantiaContrato() != null;
	}

    /**
     * 
     * <p>
     * Método responsável por atualizar o vrConstituido da lista de bandeiras e
     * por fim aciona o metodo que refaz o calculo de totais.
     * </p>
     * .
     *
     * @author Mábio Barbosa
     *
     */
    public void atualizaVrTotalConstituidoPorMudancaNaFormaGarantia() {
	if (this.getVisao().getEntidade() != null && this.getVisao().getEntidade().isGarantiaCartaoCredito()) {
	    
	    this.getVisao().setVrTotalPactuadaContratoGarantiaCartao(relatorioAnaliseService.calcularValorEsperado(this.getVisao().getEntidade()));

	    for (ContaCorrenteBandeirasVO contaCorrenteBandeirasVO : this.getVisao().getListaContaCorrenteBandeiras()) {
		for (GarantiaCartaoCredito garantiaCartaoCredito : contaCorrenteBandeirasVO.getListaGarantiaCartaoCredito()) {
		    garantiaCartaoCredito.setVrConstituido(this.obterValorPactuadoCartaoCredito(garantiaCartaoCredito));
		}
	    }

	    this.somarTotalGarantiaPactuadaPelasBandeiras();
	}
    }

    /**
     * 
     * <p>
     * Método responsável por atualizar o vrConstituidoGarantiaCartaoCredito e
     * por fim aciona o metodo que refaz o calculo de totais.
     * </p>
     * .
     *
     * @author Mábio Barbosa
     *
     * @param garantiaCartaoCredito
     */
    public void atualizaVrConstituidoGarantiaCartaoCredito(GarantiaCartaoCredito garantiaCartaoCredito) {
	atualizarValorFormaGarantia1(garantiaCartaoCredito);
	garantiaCartaoCredito.setVrConstituido(this.obterValorPactuadoCartaoCredito(garantiaCartaoCredito));

	this.somarTotalGarantiaPactuadaPelasBandeiras();
    }

    
    /**
     * 
     * <p>Método responsável por atualizar o valor no objeto garantia contrato</p>.
     *
     *	Valor da forma de garantia deve ser buscado por requisição porque o
     *	valor do objeto garantiaCartaoCredito
     *	e passado estatico e nao confere com o valor caso o mesmo tenha sido
     *  alterado em tela 
     *  
     * @author f585733
     *
     */
    private void atualizarValorFormaGarantia1(GarantiaCartaoCredito garantiaCartaoCredito) {
	String valorAtualizadoDaFormaGarantia = ((HttpServletRequest) FacesContext.getCurrentInstance().getExternalContext().getRequest())
		.getParameter("inputTextVrFormaGarantia1");
	if (valorAtualizadoDaFormaGarantia != null && !valorAtualizadoDaFormaGarantia.trim().isEmpty()) {
	    garantiaCartaoCredito.getGarantiaContrato().setVrFormaGarantia1(new BigDecimal(valorAtualizadoDaFormaGarantia.replaceAll(",", ".")));
	}
    }

    /**
     * 
     * <p>
     * Método responsável por limpar as informações da linha caso a bandeira
     * seja desmarcada e por fim aciona o metodo que refaz o calculo de totais.
     * </p>
     * .
     *
     * @author Mábio Barbosa
     *
     * @param garantiaCartaoCredito
     */
    public void limpaColunasSeEstiverDesmarcado(GarantiaCartaoCredito garantiaCartaoCredito) {
	if (!garantiaCartaoCredito.isIcMarcado()) {
	    garantiaCartaoCredito.setPcConcentracao(null);
	    garantiaCartaoCredito.setVrConstituido(null);
	    
	    this.somarTotalGarantiaPactuadaPelasBandeiras();
	}
    }    

    /**
     * 
     * <p>
     * Método responsável por montar o accordion das contas corrente com o
     * painel interno contendo um grid com as bandeiras permitindo informar o
     * percentual de concentração.
     * </p>
     * .
     *
     * @author Mábio Barbosa
     * @author gerusa.soares
     *
     */
    public void montarArvoreCartaoCreditoV2() {	
		List<ContaContrato> lista = this.getVisao().getListaContaContratoCartao();
		
		this.adicionaContaCorrenteBandeira(lista);
	
		this.somarTotalGarantiaPactuadaPelasBandeiras();
    }

    /**
     * <p>
     * Método responsável por adicionar as contas com a lista de bandeiras de cada uma.
     * </p>
     * .
     *
     * @author Mábio Barbosa
     * @author gerusa.soares
     *
     * @param lista
     */
    private void adicionaContaCorrenteBandeira(List<ContaContrato> lista) {
	final List<ContaCorrenteBandeirasVO> listaContaCorrenteBandeiras = new ArrayList<>();
	
	for (final ContaContrato contaContrato : lista) {
	    listaContaCorrenteBandeiras.add(this.adicionaContaCorrenteBandeira(contaContrato));
	}
	
	this.getVisao().getListaContaCorrenteBandeiras().clear();
	this.getVisao().setListaContaCorrenteBandeiras(listaContaCorrenteBandeiras);
    }


    /**
     * <p>Método responsável por adicionar a conta com a lista de bandeiras</p>.
     *
     * @author Mábio Barbosa
     * @author gerusa.soares
     *
     * @param contaContrato
     * @return ContaCorrenteBandeirasVO
     */
    private ContaCorrenteBandeirasVO adicionaContaCorrenteBandeira(final ContaContrato contaContrato) {
	ContaCorrenteBandeirasVO vo = new ContaCorrenteBandeirasVO();
	vo.setContaContrato(contaContrato);

	this.getVisao()
		.setVrTotalPactuadaContratoGarantiaCartao(relatorioAnaliseService.calcularValorEsperado(this.getVisao().getEntidade()));

	for (BandeiraCartao bandeiraCartao : this.getVisao().getListaBandeiraCartao()) {
	    GarantiaCartaoCredito garantiaCartao = this.retornaSeJaExisteNaLista(contaContrato, this.getVisao().getEntidade(), bandeiraCartao);
	    garantiaCartao = (garantiaCartao == null ? this.consultarGarantiaCartaoCredito(contaContrato.getNuConta(), this.getVisao().getEntidade().getNuGarantia(), bandeiraCartao) : garantiaCartao);

	    vo.getListaGarantiaCartaoCredito().add(garantiaCartao);
	}
	
	vo.setFilteredValues(vo.getListaGarantiaCartaoCredito());
	vo.setGarantiaContrato(this.getVisao().getEntidade());

	this.ordenarListaBandeirasComPercentualPrimeiro(vo.getListaGarantiaCartaoCredito());

	return vo;
    }
    
    /**
     * 
     * <p>Método responsável item caso já exista na lista.</p>.
     *
     * @author Mábio Barbosa
     *
     * @param contaContrato
     * @param garantiaContrato
     * @param bandeiraCartao
     * @return GarantiaCartaoCredito
     */
    public GarantiaCartaoCredito retornaSeJaExisteNaLista(final ContaContrato contaContrato, final GarantiaContrato garantiaContrato, BandeiraCartao bandeiraCartao) {
	for (GarantiaCartaoCredito gccJaAdd : garantiaContrato.getListaGarantiaCartaoCreditoTodosV2()) {
	    if (gccJaAdd.getNuConta().getId().getNuAgencia().equals(contaContrato.getNuConta().getId().getNuAgencia())
		    && gccJaAdd.getNuConta().getId().getNuConta().equals(contaContrato.getNuConta().getId().getNuConta())
		    && gccJaAdd.getNuConta().getId().getNuOperacao().equals(contaContrato.getNuConta().getId().getNuOperacao())
		    && gccJaAdd.getNuConta().getId().getNuVerificador().equals(contaContrato.getNuConta().getId().getNuVerificador())
		    && gccJaAdd.getGarantiaContrato().getGarantia().getNuGarantia() == garantiaContrato.getGarantia().getNuGarantia() 
		    && gccJaAdd.getBandeiraCartao().getNuBandeiraCartao().compareTo(bandeiraCartao.getNuBandeiraCartao()) == 0) {
		return gccJaAdd;
	    }
	}
	
	return null;
    }
    
    /**
     * 
     * <p>Método responsável por remover a conta da lista.</p>.
     *
     * @author Mábio Barbosa
     *
     */
    public void removerContaCorrente() {
	this.getVisao().getListaContaContratoCartao().remove(this.getVisao().getContaCorrenteBandeirasVO().getContaContrato());
	this.getVisao().getListaContaCorrenteBandeiras().remove(this.getVisao().getContaCorrenteBandeirasVO());
	
	this.somarTotalGarantiaPactuadaPelasBandeiras();
	this.getVisao().setContaCorrenteBandeirasVO(null);
    }

    /**
     * <p>
     * Método responsável por ordernar a lista das Bandeiras dos cartões por
     * campo percentual de concentração preenchido e por nome.
     * </p>
     * .
     *
     * @author Mábio Barbosa
     *
     * @param List<GarantiaCartaoCredito>
     */
    private void ordenarListaBandeirasComPercentualPrimeiro(List<GarantiaCartaoCredito> lista) {
		Collections.sort(lista, new Comparator<GarantiaCartaoCredito>() {
		    @Override
		    public int compare(GarantiaCartaoCredito p1, GarantiaCartaoCredito p2) {
		    	return p2.getPcConcentracao().compareTo(p1.getPcConcentracao());
		    }
		});
    }

    /**
     * 
     * <p>
     * Método responsável por somar os totais pactuado (R$) e de concentração
     * (%)
     * </p>
     * .
     *
     * @author Mábio Barbosa
     *
     */
    public void somarTotalGarantiaPactuadaPelasBandeiras() {
		BigDecimal vrPactuado = BigDecimal.ZERO;
		BigDecimal vrPercentualPactuado = BigDecimal.ZERO;
	
		for (ContaCorrenteBandeirasVO contaCorrenteBandeirasVO : this.getVisao().getListaContaCorrenteBandeiras()) {			
		    for (GarantiaCartaoCredito garantiaCartaoCredito : contaCorrenteBandeirasVO.getListaGarantiaCartaoCredito()) {
		    	if (garantiaCartaoCredito.getPcConcentracao().compareTo(new BigDecimal(0)) > 0) {
		    		BigDecimal vrConstituido = garantiaCartaoCredito.getVrConstituido() != null ? garantiaCartaoCredito.getVrConstituido() : BigDecimal.ZERO;
		    		
		    		vrPactuado = vrPactuado.add(vrConstituido);
		    		vrPercentualPactuado = vrPercentualPactuado.add(isPercConcentracao(garantiaCartaoCredito) ? garantiaCartaoCredito.getPcConcentracao() : BigDecimal.ZERO);
		    		
		    	}
		    }
		}
	
		this.getVisao().setVrTotalPactuadaBandeirasGarantiaCartao(vrPactuado);
		this.getVisao().setVrTotalDiferencaPercentualBandeirasContas(this.getVisao().getEntidade().getVrFormaGarantia1().subtract(vrPercentualPactuado));
    }

    /**
     * 
     * <p>
     * Método responsável por retornar a lista de GarantiaCartaoCredito que
     * esteja marcada ou já esteja salva.
     * </p>
     * .
     *
     * @author Mábio Barbosa
     *
     * @return Collection<GarantiaCartaoCredito>
     */
    public Collection<GarantiaCartaoCredito> getListaGarantiaCartaoCreditoSelecionadosV2() {
		final Collection<GarantiaCartaoCredito> listaGarantiaCartaoCredito = new ArrayList<>();
	
		for (ContaCorrenteBandeirasVO contaCorrenteBandeirasVO : this.getVisao().getListaContaCorrenteBandeiras()) {
		    for (GarantiaCartaoCredito garantiaCartaoCredito : contaCorrenteBandeirasVO.getListaGarantiaCartaoCredito()) {
				if (garantiaCartaoCredito.isIcMarcado() && !this.service.isPcConcentracaoInvalido(garantiaCartaoCredito)) {
				    listaGarantiaCartaoCredito.add(garantiaCartaoCredito);
				}
		    }
		}
	
		return listaGarantiaCartaoCredito;
    }
    
    /**
     * 
     * <p>
     * Método responsável por retornar toda a lista de GarantiaCartaoCredito cujo intes estejam marcados ou desmarcados.
     * </p>
     * .
     *
     * @author Mábio Barbosa
     *
     * @return Collection<GarantiaCartaoCredito>
     */
    public Collection<GarantiaCartaoCredito> getListaGarantiaCartaoCreditoTodosV2() {
		final Collection<GarantiaCartaoCredito> listaGarantiaCartaoCredito = new ArrayList<>();
	
		for (ContaCorrenteBandeirasVO contaCorrenteBandeirasVO : this.getVisao().getListaContaCorrenteBandeiras()) {
		    for (GarantiaCartaoCredito garantiaCartaoCredito : contaCorrenteBandeirasVO.getListaGarantiaCartaoCredito()) {
		    	listaGarantiaCartaoCredito.add(garantiaCartaoCredito);
		    }
		}
	
		return listaGarantiaCartaoCredito;
    }
    
    
    /**
     * Método responsável por verificar se a Garantia for cartão de crédito e o TipoGarantia for ESTOQUE para desabilitar todos
     * tipos movimentação do cartão de crédito que não seja Crédito
     * 
     * @author narcieliton.lopes
     * @date 2019/08/26 yyyy/mm/dd
     * @return true caso TipoGarantia for ESTOQUE e tipos de movimentação do cartão não for crédito
     */
    public boolean desabilitarConformeSelecaoTipoGarantiaCartaoCredito(String tipoGarantia, String tipoMovimentacaoCartao){
    	boolean desabilitar = false;
    	
    	if(tipoGarantia != null && tipoMovimentacaoCartao != null && tipoGarantia.equals("ESTOQUE") && !tipoMovimentacaoCartao.equals("1")) {
    		desabilitar = true;
    	}
    	return desabilitar;
    }
    
    /**
     * Método responsável por verificar se a Garantia for cartão de crédito e o TipoGarantia for ESTOQUE para alterar o CSS
     * para desabilitado todos tipos movimentação do cartão de crédito que não seja Crédito
     * 
     * @author narcieliton.lopes
     * @date 2019/08/26 yyyy/mm/dd
     * @return caso TipoGarantia for ESTOQUE e tipos de movimentação do cartão não for crédito retorna o style css
     */
    public String desabilitarStyleCssConformeSelecaoTipoGarantiaCartaoCredito(String tipoGarantia, String tipoMovimentacaoCartao) {
    	boolean desabilitar =  desabilitarConformeSelecaoTipoGarantiaCartaoCredito(tipoGarantia, tipoMovimentacaoCartao);
    	String desabilitarCss = null;
    	if(desabilitar) {
    		desabilitarCss = "tdcontaBandeiraDisable";
    	}
    	return desabilitarCss;
    }
}
