/**
 * Copyright (c) 2020 Caixa Econômica Federal. Todos os direitos
 * reservados.
 *
 * Caixa Econômica Federal - SIACG
 *
 * Este software foi desenvolvido sob demanda da CAIXA e está
 * protegido por leis de direitos autorais e tratados internacionais. As
 * condições de cópia e utilização total ou partes dependem de autorização da
 * empresa. Cópias não são permitidas sem expressa autorização. Não pode ser
 * comercializado ou utilizado para propósitos particulares.
 *
 * Uso exclusivo da Caixa Econômica Federal. A reprodução ou distribuição não
 * autorizada deste programa ou de parte dele, resultará em punições civis e
 * criminais e os infratores incorrem em sanções previstas na legislação em
 * vigor.
 *
 * Histórico do TFS:
 *
 * LastChangedRevision: $Revision$
 * LastChangedBy: $Author$
 * LastChangedDate: $Date$
 *
 * HeadURL: $HeadURL$
 *
 */
package br.gov.caixa.siacg.comum.to;

import java.io.Serializable;
import java.math.BigDecimal;

import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * <p>
 * SaldoCartaoBandeiraCalculoTO
 * </p>
 *
 * <p>
 * Descrição: Representa a entidade de SaldoCartaoBandeira para o calculo
 * </p>
 *
 * <br>
 * <b>Empresa:</b> Cef - Caixa Econômica Federal
 *
 *
 * @author f541915
 *
 * @version 1.0
 */
public class SaldoCartaoBandeiraCalculoTO implements Serializable {

	/** Atributo serialVersionUID. */
	private static final long serialVersionUID = 1L;

	/** Atributo nuSaldoCartaoBandeira. */
	@JsonProperty("nu_saldo_cartao_bandeira")
	private Integer nuSaldoCartaoBandeira;

	/** Atributo nuBandeiraCartao. */
	@JsonProperty("nu_bandeira_cartao")
	private Integer nuBandeiraCartao;

	/** Atributo vrCartaoFluxo. */
	@JsonProperty("vr_cartao_fluxo")
	private BigDecimal vrCartaoFluxo;

	/** Atributo vrCartaoEstoque. */
	@JsonProperty("vr_cartao_estoque")
	private BigDecimal vrCartaoEstoque;
	
	/** Atributo saldo. */
	private SaldoCalculoTO saldo;

	/**
	 * <p>
	 * Retorna o valor do atributo nuSaldoCartaoBandeira
	 * </p>
	 * .
	 *
	 * @return nuSaldoCartaoBandeira
	 */
	public Integer getNuSaldoCartaoBandeira() {
		return this.nuSaldoCartaoBandeira;
	}

	/**
	 * <p>
	 * Define o valor do atributo nuSaldoCartaoBandeira
	 * </p>
	 * .
	 *
	 * @param nuSaldoCartaoBandeira
	 *            valor a ser atribuído
	 */
	public void setNuSaldoCartaoBandeira(Integer nuSaldoCartaoBandeira) {
		this.nuSaldoCartaoBandeira = nuSaldoCartaoBandeira;
	}

	/**
	 * <p>
	 * Retorna o valor do atributo nuBandeiraCartao
	 * </p>
	 * .
	 *
	 * @return nuBandeiraCartao
	 */
	public Integer getNuBandeiraCartao() {
		return this.nuBandeiraCartao;
	}

	/**
	 * <p>
	 * Define o valor do atributo nuBandeiraCartao
	 * </p>
	 * .
	 *
	 * @param nuBandeiraCartao
	 *            valor a ser atribuído
	 */
	public void setNuBandeiraCartao(Integer nuBandeiraCartao) {
		this.nuBandeiraCartao = nuBandeiraCartao;
	}

	/**
	 * <p>
	 * Retorna o valor do atributo vrCartaoFluxo
	 * </p>
	 * .
	 *
	 * @return vrCartaoFluxo
	 */
	public BigDecimal getVrCartaoFluxo() {
		return this.vrCartaoFluxo;
	}

	/**
	 * <p>
	 * Define o valor do atributo vrCartaoFluxo
	 * </p>
	 * .
	 *
	 * @param vrCartaoFluxo
	 *            valor a ser atribuído
	 */
	public void setVrCartaoFluxo(BigDecimal vrCartaoFluxo) {
		this.vrCartaoFluxo = vrCartaoFluxo;
	}

	/**
	 * <p>
	 * Retorna o valor do atributo vrCartaoEstoque
	 * </p>
	 * .
	 *
	 * @return vrCartaoEstoque
	 */
	public BigDecimal getVrCartaoEstoque() {
		return this.vrCartaoEstoque;
	}

	/**
	 * <p>
	 * Define o valor do atributo vrCartaoEstoque
	 * </p>
	 * .
	 *
	 * @param vrCartaoEstoque
	 *            valor a ser atribuído
	 */
	public void setVrCartaoEstoque(BigDecimal vrCartaoEstoque) {
		this.vrCartaoEstoque = vrCartaoEstoque;
	}

	/**
	 * <p>Retorna o valor do atributo saldo</p>.
	 *
	 * @return saldo
	*/
	public SaldoCalculoTO getSaldo() {
		return this.saldo;
	}

	/**
	 * <p>Define o valor do atributo saldo</p>.
	 *
	 * @param saldo valor a ser atribuído
	*/
	public void setSaldo(SaldoCalculoTO saldo) {
		this.saldo = saldo;
	}

}
