/**
 * Copyright (c) 2014 Caixa Econômica Federal. Todos os direitos
 * reservados.
 *
 * Caixa Econômica Federal - SIACG - Sistema de Crédito Rural
 *
 * Este software foi desenvolvido sob demanda da CAIXA e está
 * protegido por leis de direitos autorais e tratados internacionais. As
 * condições de cópia e utilização do todo ou partes dependem de autorização da
 * pessoa. Cópias não são permitidas sem expressa autorização. Não pode ser
 * comercializado ou utilizado para propósitos particulares.
 *
 * Uso exclusivo da Caixa Econômica Federal. A reprodução ou distribuição não
 * autorizada deste programa ou de parte dele, resultará em punições civis e
 * criminais e os infratores incorrem em sanções previstas na legislação em
 * vigor.
 *
 * Histórico do Subversion:
 *
 * LastChangedRevision: $Revision$
 * LastChangedBy: $Author$
 * LastChangedDate: $Date$
 *
 * HeadURL: $HeadURL$
 *
 */
package br.gov.caixa.siacg.view.mb;

import java.util.ArrayList;
import java.util.Collection;
import java.util.LinkedHashMap;
import java.util.Map;

import javax.ejb.EJB;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ManagedProperty;
import javax.faces.bean.SessionScoped;
import javax.faces.context.FacesContext;
import javax.inject.Inject;

import org.primefaces.component.datatable.DataTable;

import br.gov.caixa.pedesgo.arquitetura.controlador.AbstractBean;
import br.gov.caixa.pedesgo.arquitetura.controlador.ManutencaoBean;
import br.gov.caixa.pedesgo.arquitetura.enumerador.EnumAcao;
import br.gov.caixa.pedesgo.arquitetura.enumerador.EnumNomeAbrangenciaRestritaUnidade;
import br.gov.caixa.pedesgo.arquitetura.enumerador.EnumTipoAbrangencia;
import br.gov.caixa.pedesgo.arquitetura.enums.EnumExtensaoArquivo;
import br.gov.caixa.pedesgo.arquitetura.relatorio.UtilRelatorio;
import br.gov.caixa.pedesgo.arquitetura.util.LogCefUtil;
import br.gov.caixa.pedesgo.arquitetura.util.UsuarioUtil;
import br.gov.caixa.pedesgo.arquitetura.util.UtilObjeto;
import br.gov.caixa.siacg.model.domain.Contrato;
import br.gov.caixa.siacg.model.enums.NoFuncionalidadeEnum;
import br.gov.caixa.siacg.model.vo.SrVO;
import br.gov.caixa.siacg.model.vo.UnidadeVO;
import br.gov.caixa.siacg.pagination.AcompanhamentoEndividamentoLazyModel;
import br.gov.caixa.siacg.service.ContratoService;
import br.gov.caixa.siacg.service.EnvioNotificacaoService;
import br.gov.caixa.siacg.service.UnidadeVinculadaSuatService;
import br.gov.caixa.siacg.view.form.AcompanhamentoEndividamentoVisao;

/**
 * <p>
 * AcompanhamentoEndividamentoMB.
 * </p>
 * <p>
 * Descrição: Bean Gerenciado para o Acompanahmento de Endividamento
 * </p>
 * <br>
 * <b>Empresa:</b> Cef - Caixa Econômica Federal
 *
 * @author Caio Graco
 * @version 1.0
 */
@ManagedBean
@SessionScoped
public class AcompanhamentoEndividamentoMB extends ManutencaoBean<Contrato> {

    /** Atributo serialVersionUID. */
    private static final long serialVersionUID = -6313373940518853305L;

    /** Atributo NOME_MANAGED_BEAN. */
    public static final String NOME_MANAGED_BEAN = "acompanhamentoEndividamentoMB";

    /** Atributo EL_MANAGED_BEAN. */
    public static final String EL_MANAGED_BEAN = "#{acompanhamentoEndividamentoMB}";

    /** Atributo VAR_RESOURCE_BUNDLE. */
    private static final String VAR_RESOURCE_BUNDLE = "msgApp";

    /** Atributo DIRETORIO_PAGINAS. */
    private static final String DIRETORIO_PAGINAS = "/pages/";

    /** Atributo PREFIXO_CASO_USO. */
    private static final String PREFIXO_CASO_USO = "acompanhamentoEndividamento";

    /** Atributo IMAGEM_CAIXA_LOGO. */
    private static final String IMAGEM_CAIXA_LOGO = "/resources/img/caixa_logo.jpg";

    /** Atributo CAMINHO_RELATORIO. */
    private static final String CAMINHO_RELATORIO = "/reports/";

    /** Atributo NOME_JASPER_ACOMPANHAMENTO_ENDIVIDAMENTO. */
    private static final String NOME_JASPER_ACOMPANHAMENTO_ENDIVIDAMENTO = "acompanhamento_endividamento.jasper";

    /** Atributo RELATORIO_CONTRATOS_PARAM. */
    private static final String RELATORIO_CONTRATOS_PARAM = "Acompanhamento-de-Endividamento";

    /** Atributo contratoService. */
    @Inject
    private ContratoService contratoService;

    @EJB
    private transient EnvioNotificacaoService envioNotificacaoService;

    @EJB
    private UnidadeVinculadaSuatService unidadeVinculadaSuatService;

    /** Atributo visao. */
    private AcompanhamentoEndividamentoVisao visao;

    /** Atributo paginacaoAcompanhamentoEndividamento. */
    @ManagedProperty(value = AcompanhamentoEndividamentoLazyModel.EL_MANAGED_BEAN)
    private AcompanhamentoEndividamentoLazyModel paginacaoAcompanhamentoEndividamento;

    /** Atributo relatorioAnaliseMB. */
    @ManagedProperty(value = RelatorioAnaliseMB.EL_MANAGED_BEAN)
    private RelatorioAnaliseMB relatorioAnaliseMB;

    /**
     * @see br.gov.caixa.pedesgo.arquitetura.controlador.AbstractBean#getPrefixoCasoDeUso()
     */
    @Override
    protected String getPrefixoCasoDeUso() {
        return AcompanhamentoEndividamentoMB.PREFIXO_CASO_USO;
    }

    /**
     * @see br.gov.caixa.pedesgo.arquitetura.controlador.AbstractBean#getTelaConsulta()
     */
    @Override
    public String getTelaConsulta() {
        this.carregar();
        this.verificarPermissoes();

        return AcompanhamentoEndividamentoMB.DIRETORIO_PAGINAS + this.getPrefixoCasoDeUso() + AbstractBean.SUFIXO_TELA_CONSULTA;
    }

    public void pesquisar() {
        final DataTable dataTable = (DataTable) FacesContext.getCurrentInstance().getViewRoot()
                .findComponent("formularioEndividamento:gridContratosParametrizados");

        if (UtilObjeto.isReferencia(dataTable)) {
            dataTable.setFirst(0);
        }
    }
    /**
     * @see br.gov.caixa.pedesgo.arquitetura.controlador.AbstractBean#carregar()
     */
    @Override
    public void carregar() {
        final Collection<UnidadeVO> listaSuat = unidadeVinculadaSuatService.listarSuats();
        final Integer nuUnidade = Integer.valueOf(super.getUnidadeUsuario());

        final AcompanhamentoEndividamentoVisao visao = this.getVisao();

        if (UsuarioUtil.contemPermissao(NoFuncionalidadeEnum.CONSULTA_UNIDADE.getNoFuncionalidade(), EnumAcao.CONSULTAR.getNoAcao(),
                EnumTipoAbrangencia.RESTRITA_UNIDADE.getTipoAbrangencia(), EnumNomeAbrangenciaRestritaUnidade.TODAS.getNomeAbrangencia())) {

            visao.setHabilitarSuat(Boolean.FALSE);
            visao.setHabilitarSr(Boolean.FALSE);
            visao.setHabilitarUnidade(Boolean.FALSE);

            visao.setSuatList(listaSuat);

        } else if (UsuarioUtil.contemPermissao(NoFuncionalidadeEnum.CONSULTA_UNIDADE.getNoFuncionalidade(), EnumAcao.CONSULTAR.getNoAcao(),
                EnumTipoAbrangencia.RESTRITA_UNIDADE.getTipoAbrangencia(), EnumNomeAbrangenciaRestritaUnidade.VINCULADAS.getNomeAbrangencia())) {

            visao.setHabilitarSuat(Boolean.TRUE);
            visao.setHabilitarSr(Boolean.TRUE);
            visao.setHabilitarUnidade(Boolean.FALSE);

            final Integer nuSR = nuUnidade;
            final Integer nuSuat = unidadeVinculadaSuatService.getNuSuatPorSR(nuSR);

            visao.setSuatList(listaSuat);
            visao.setSrList(unidadeVinculadaSuatService.listarSrsPorNuSuat(nuSuat));
            visao.setUnidadeList(this.unidadeVinculadaSuatService.listarUnidadesPorNuSr(nuSR));
            visao.setNuSuat(nuSuat);
            visao.setNuSr(nuSR);

        } else if (UsuarioUtil.contemPermissao(NoFuncionalidadeEnum.CONSULTA_UNIDADE.getNoFuncionalidade(), EnumAcao.CONSULTAR.getNoAcao(),
                EnumTipoAbrangencia.RESTRITA_UNIDADE.getTipoAbrangencia(), EnumNomeAbrangenciaRestritaUnidade.UNIDADE.getNomeAbrangencia())) {

            visao.setHabilitarSuat(Boolean.TRUE);
            visao.setHabilitarSr(Boolean.TRUE);
            visao.setHabilitarUnidade(Boolean.TRUE);

            final Integer nuSR = unidadeVinculadaSuatService.getNuSrPorUnidade(nuUnidade);
            final Integer nuSuat = unidadeVinculadaSuatService.getNuSuatPorSR(nuSR);

            visao.setSuatList(listaSuat);
            visao.setSrList(unidadeVinculadaSuatService.listarSrsPorNuSuat(nuSuat));
            visao.setUnidadeList(this.unidadeVinculadaSuatService.listarUnidadesPorNuSr(nuSR));
            visao.setNuSuat(nuSuat);
            visao.setNuSr(nuSR);
            visao.setNuUnidade(nuUnidade);
        }
    }

    /**
     * <p>
     * Método responsável por limpar os dados do filtro.
     * <p>
     *
     * @return String
     * @author guilherme.santos
     */
    public String limpar() {
        this.visao = new AcompanhamentoEndividamentoVisao();
        this.getPaginacaoAcompanhamentoEndividamento().setFiltro(null);
        this.carregar();

        return super.MESMA_TELA;
    }

    /**
     * <p>
     * Método responsável por preencher a lista de unidades de acordo com a SR
     * selecionada.
     * <p>
     *
     * @author Caio Graco
     */
    public void selecionarUnidade() {
        this.paginacaoAcompanhamentoEndividamento.getFiltro().setListaUnidade(new ArrayList<Integer>());
        this.paginacaoAcompanhamentoEndividamento.getFiltro().getListaUnidade().add(this.getVisao().getNuUnidade());
    }

    /**
     * <p>
     * Método responsável por preencher a lista de unidades de acordo com a SR
     * selecionada.
     * <p>
     *
     * @author Caio Graco
     */
    public void selecionarSr() {
        this.paginacaoAcompanhamentoEndividamento.getFiltro().getListaUnidade().clear();

        this.getVisao().setUnidadeList(this.unidadeVinculadaSuatService.listarUnidadesPorNuSr(this.getVisao().getNuSr()));

        final Collection<Integer> listaNuUnidade = new ArrayList<>();

        for (final UnidadeVO unidade : this.getVisao().getUnidadeList()) {
            listaNuUnidade.add(unidade.getCoUnidadeVO());
        }

        this.paginacaoAcompanhamentoEndividamento.getFiltro().setListaUnidade(listaNuUnidade);
    }

    /**
     * <p>
     * Método responsável por preencher a lista de unidades de acordo com a suat
     * selecionada.
     * <p>
     *
     * @author Caio Graco
     */
    public void selecionarSuat() {
        this.paginacaoAcompanhamentoEndividamento.getFiltro().getListaUnidade().clear();

        this.getVisao().setSrList(unidadeVinculadaSuatService.listarSrsPorNuSuat(this.getVisao().getNuSuat()));

        final Collection<Integer> listaNuSr = new ArrayList<>();

        for (final SrVO srVO : this.getVisao().getSrList()) {
            listaNuSr.add(srVO.getNuSrVO());
        }

        this.paginacaoAcompanhamentoEndividamento.getFiltro().setListaUnidade(unidadeVinculadaSuatService.getNuUnidadesVinculadasSR(listaNuSr));

        this.getVisao().setUnidadeList(new ArrayList<UnidadeVO>());
    }

    /**
     * <p>
     * Método responsável por exportar os contratos em formato XLS.
     * <p>
     *
     * @author Caio Graco
     */
    public void exportarXLSContratosEndividamento() {

        final Map<String, Object> parametros = new LinkedHashMap<>();

        parametros.put("LOGO_CAIXA", super.getExternalContext().getResourceAsStream(AcompanhamentoEndividamentoMB.IMAGEM_CAIXA_LOGO));
        parametros.put("MATRICULA_USUARIO", super.getMatriculaUsuario());

        try {

            UtilRelatorio.getInstancia()
                    .addCaminhoRelatorio(
                            AcompanhamentoEndividamentoMB.CAMINHO_RELATORIO + AcompanhamentoEndividamentoMB.NOME_JASPER_ACOMPANHAMENTO_ENDIVIDAMENTO)
                    .addColecao(getService().listarContratosEndividamentoPorFiltroSelecionado(this.paginacaoAcompanhamentoEndividamento.getFiltro()))
                    .addExtensaoArquivo(EnumExtensaoArquivo.XLS)
                    .addNomeRelatorio(AcompanhamentoEndividamentoMB.RELATORIO_CONTRATOS_PARAM).addParametros(parametros)
                    .addResposta(super.getResponse()).gerarRelatorio();

        } catch (final Exception e) {
            LogCefUtil.error("Não foi possivel gerar o XLS");
            LogCefUtil.error(e);
        }
    }

    /**
     * @see br.gov.caixa.pedesgo.arquitetura.controlador.AbstractBean#getNomeVarResourceBundle()
     */
    @Override
    protected String getNomeVarResourceBundle() {
        return AcompanhamentoEndividamentoMB.VAR_RESOURCE_BUNDLE;
    }

    /**
     * @see br.gov.caixa.pedesgo.arquitetura.controlador.AbstractBean#getService()
     */
    @SuppressWarnings("unchecked")
    @Override
    public ContratoService getService() {
        return this.contratoService;
    }

    /**
     * @see br.gov.caixa.pedesgo.arquitetura.controlador.AbstractBean#getVisao()
     */
    @Override
    public AcompanhamentoEndividamentoVisao getVisao() {
        if (this.visao == null) {
            this.visao = new AcompanhamentoEndividamentoVisao();
        }
        return this.visao;
    }

    /**
     * Retorna o valor do atributo paginacaoAcompanhamentoEndividamento.
     *
     * @return paginacaoAcompanhamentoEndividamento
     */
    public AcompanhamentoEndividamentoLazyModel getPaginacaoAcompanhamentoEndividamento() {

        return this.paginacaoAcompanhamentoEndividamento;
    }

    /**
     * Define o valor do atributo paginacaoAcompanhamentoEndividamento.
     *
     * @param paginacaoAcompanhamentoEndividamento
     *            valor a ser atribuído
     */
    public void setPaginacaoAcompanhamentoEndividamento(final AcompanhamentoEndividamentoLazyModel paginacaoAcompanhamentoEndividamento) {

        this.paginacaoAcompanhamentoEndividamento = paginacaoAcompanhamentoEndividamento;
    }

    /**
     * Retorna o valor do atributo relatorioAnaliseMB.
     *
     * @return relatorioAnaliseMB
     */
    public RelatorioAnaliseMB getRelatorioAnaliseMB() {

        return this.relatorioAnaliseMB;
    }

    /**
     * Define o valor do atributo relatorioAnaliseMB.
     *
     * @param relatorioAnaliseMB
     *            valor a ser atribuído
     */
    public void setRelatorioAnaliseMB(final RelatorioAnaliseMB relatorioAnaliseMB) {

        this.relatorioAnaliseMB = relatorioAnaliseMB;
    }

    /**
     * <p>
     * Método responsável por consultar permissões do usuário.
     * <p>
     *
     * @author guilherme.santos
     */
    private void verificarPermissoes() {
    	if (UsuarioUtil.contemPermissao(NoFuncionalidadeEnum.ACOMPANHAMENTO_ENVIDAMENTO_EXPORTAR.getNoFuncionalidade(), "exportar", null, null)) {
            this.getVisao().setHabilitarXLS(true);
        } else {
            this.getVisao().setHabilitarXLS(false);
        }
    }
}
