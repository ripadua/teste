/**
 * Copyright (c) 2015 Caixa Econômica Federal. Todos os direitos
 * reservados.
 *
 * Caixa Econômica Federal - SIACG - Sistema de Crédito Rural
 *
 * Este software foi desenvolvido sob demanda da CAIXA e está
 * protegido por leis de direitos autorais e tratados internacionais. As
 * condições de cópia e utilização do todo ou partes dependem de autorização da
 * pessoa. Cópias não são permitidas sem expressa autorização. Não pode ser
 * comercializado ou utilizado para propósitos particulares.
 *
 * Uso exclusivo da Caixa Econômica Federal. A reprodução ou distribuição não
 * autorizada deste programa ou de parte dele, resultará em punições civis e
 * criminais e os infratores incorrem em sanções previstas na legislação em
 * vigor.
 *
 * Histórico do Subversion:
 *
 * LastChangedRevision: $Revision$
 * LastChangedBy: $Author$
 * LastChangedDate: $Date$
 *
 * HeadURL: $HeadURL$
 *
 */
package br.gov.caixa.siacg.view.form;

import java.util.ArrayList;
import java.util.List;

import br.gov.caixa.pedesgo.arquitetura.visao.ManutencaoVisao;
import br.gov.caixa.siacg.model.domain.Garantia;
import br.gov.caixa.siacg.model.domain.GarantiaCaixaProduto;
import br.gov.caixa.siacg.model.domain.GarantiaProduto;
import br.gov.caixa.siacg.model.domain.ViewProdutoSiico;
import br.gov.caixa.siacg.model.vo.ProdutoModalidadeVO;

/**
 * <p>
 * GarantiaProdutoVisao
 * </p>
 * <p>
 * Descrição: Classe de visão para o Bean Gerenciado GarantiaProdutoMB.
 * </p>
 * <br>
 * <b>Empresa:</b> Cef - Caixa Econômica Federal
 *
 * @author Mábio Barbosa
 * @version 1.0
 */
public class GarantiaProdutoVisao extends ManutencaoVisao<GarantiaProduto> {

    private static final long serialVersionUID = 813641756574259628L;

    /** Atributo quantidadeItens. */
    private Integer quantidadeItens;

    /** Atributo produtoModalidadeVOFiltro. */
    private transient ProdutoModalidadeVO produtoModalidadeVOFiltro;

    /** Atributo produtoModalidadeVO. */
    private transient ProdutoModalidadeVO produtoModalidadeVO;

    /** Atributo produtoModalidadeVOExcluir. */
    private transient ProdutoModalidadeVO produtoModalidadeVOExcluir;

    /** Atributo autoCompleteProdutoFiltro. */
    private String autoCompleteProdutoFiltro;

    /** Atributo autoCompleteProduto. */
    private String autoCompleteProduto;

    /** Atributo nuProdutoSelecionadoFiltro. */
    private Integer nuProdutoSelecionadoFiltro;

    /** Atributo nuModalidadeSelecionadaFiltro. */
    private Integer nuModalidadeSelecionadaFiltro;

    /** Atributo nuProdutoSelecionado. */
    private Integer nuProdutoSelecionado;

    /** Atributo nuModalidadeSelecionada. */
    private Integer nuModalidadeSelecionada;

    /** Atributo garantiasProduto. */
    private List<GarantiaProduto> garantiasProduto;

    /** Atributo garantiasCaixaProduto. */
    private List<GarantiaCaixaProduto> garantiasCaixaProduto;

    /** Atributo garantiasProdutoExcluir. */
    private List<GarantiaProduto> garantiasProdutoExcluir;

    /** Atributo garantiasCaixaProdutoExcluir. */
    private List<GarantiaCaixaProduto> garantiasCaixaProdutoExcluir;

    /** Atributo isTelaEdicao. */
    private boolean isTelaEdicao;

    /** Atributo listaProdutoModadalideVOFiltro. */
    private transient List<ProdutoModalidadeVO> listaProdutoModadalideVOFiltro;

    /** Atributo listaGarantiaBacenObrigatorias. */
    private List<Garantia> listaGarantiaBacenObrigatorias;

    /** Atributo listaGarantiaBacenAcessorias. */
    private List<Garantia> listaGarantiaBacenAcessorias;

    /** Atributo listaProdutoCaixa. */
    private List<ViewProdutoSiico> listaProdutoCaixa;

    /** Atributo listaProdutoCaixa. */
    private List<ViewProdutoSiico> listaProdutoCaixaBD;
    
    private Boolean garantiaCaixaNaoSeAplica;

    // **********************
    // Getters e Setters
    // **********************

    public ProdutoModalidadeVO getProdutoModalidadeVOFiltro() {
	this.produtoModalidadeVOFiltro = new ProdutoModalidadeVO(this.getNuProdutoSelecionadoFiltro(), this.getNuModalidadeSelecionadaFiltro());

	return produtoModalidadeVOFiltro;
    }

    public void setProdutoModalidadeVOFiltro(ProdutoModalidadeVO produtoModalidadeVOFiltro) {
	this.produtoModalidadeVOFiltro = produtoModalidadeVOFiltro;
    }
    
    public ProdutoModalidadeVO getProdutoModalidadeVO() {
	this.produtoModalidadeVO = new ProdutoModalidadeVO(this.getNuProdutoSelecionado(), this.getNuModalidadeSelecionada());
	
	return this.produtoModalidadeVO;
    }

    public void setProdutoModalidadeVO(ProdutoModalidadeVO produtoModalidadeVO) {
	this.produtoModalidadeVO = produtoModalidadeVO;
    }

    public ProdutoModalidadeVO getProdutoModalidadeVOExcluir() {
	return this.produtoModalidadeVOExcluir;
    }

    public void setProdutoModalidadeVOExcluir(ProdutoModalidadeVO produtoModalidadeVOExcluir) {
	this.produtoModalidadeVOExcluir = produtoModalidadeVOExcluir;
    }

    public Integer getQuantidadeItens() {
	this.quantidadeItens = 0;

	if (!this.getListaProdutoModadalideVOFiltro().isEmpty()) {
	    this.quantidadeItens = this.getListaProdutoModadalideVOFiltro().size();
	}
	return this.quantidadeItens;
    }

    public void setQuantidadeItens(Integer quantidadeItens) {
	this.quantidadeItens = quantidadeItens;
    }

    public Integer getNuProdutoSelecionadoFiltro() {
	return nuProdutoSelecionadoFiltro;
    }

    public void setNuProdutoSelecionadoFiltro(Integer nuProdutoSelecionadoFiltro) {
	this.nuProdutoSelecionadoFiltro = nuProdutoSelecionadoFiltro;
    }

    public Integer getNuModalidadeSelecionadaFiltro() {
	return nuModalidadeSelecionadaFiltro;
    }

    public void setNuModalidadeSelecionadaFiltro(Integer nuModalidadeSelecionadaFiltro) {
	this.nuModalidadeSelecionadaFiltro = nuModalidadeSelecionadaFiltro;
    }

    public Integer getNuProdutoSelecionado() {
	return nuProdutoSelecionado;
    }

    public void setNuProdutoSelecionado(Integer nuProdutoSelecionado) {
	this.nuProdutoSelecionado = nuProdutoSelecionado;
    }

    public Integer getNuModalidadeSelecionada() {
	return nuModalidadeSelecionada;
    }

    public void setNuModalidadeSelecionada(Integer nuModalidadeSelecionada) {
	this.nuModalidadeSelecionada = nuModalidadeSelecionada;
    }

    public List<GarantiaProduto> getGarantiasProduto() {
	if (this.garantiasProduto == null) {
	    this.garantiasProduto = new ArrayList<>();
	}
	return garantiasProduto;
    }

    public void setGarantiasProduto(List<GarantiaProduto> garantiasProduto) {
	this.garantiasProduto = garantiasProduto;
    }

    public List<GarantiaCaixaProduto> getGarantiasCaixaProduto() {
	if (this.garantiasCaixaProduto == null) {
	    this.garantiasCaixaProduto = new ArrayList<>();
	}
	return garantiasCaixaProduto;
    }

    public void setGarantiasCaixaProduto(List<GarantiaCaixaProduto> garantiasCaixaProduto) {
	this.garantiasCaixaProduto = garantiasCaixaProduto;
    }

    public List<GarantiaProduto> getGarantiasProdutoExcluir() {
	if (this.garantiasProdutoExcluir == null) {
	    this.garantiasProdutoExcluir = new ArrayList<>();
	}
	return garantiasProdutoExcluir;
    }

    public void setGarantiasProdutoExcluir(List<GarantiaProduto> garantiasProdutoExcluir) {
	this.garantiasProdutoExcluir = garantiasProdutoExcluir;
    }

    public List<GarantiaCaixaProduto> getGarantiasCaixaProdutoExcluir() {
	if (this.garantiasCaixaProdutoExcluir == null) {
	    this.garantiasCaixaProdutoExcluir = new ArrayList<>();
	}
	return this.garantiasCaixaProdutoExcluir;
    }

    public void setGarantiasCaixaProdutoExcluir(List<GarantiaCaixaProduto> garantiasCaixaProdutoExcluir) {
	this.garantiasCaixaProdutoExcluir = garantiasCaixaProdutoExcluir;
    }

    public String getAutoCompleteProdutoFiltro() {
	return autoCompleteProdutoFiltro;
    }

    public void setAutoCompleteProdutoFiltro(String autoCompleteProdutoFiltro) {
	this.autoCompleteProdutoFiltro = autoCompleteProdutoFiltro;
    }

    public String getAutoCompleteProduto() {
	return autoCompleteProduto;
    }

    public void setAutoCompleteProduto(String autoCompleteProduto) {
	this.autoCompleteProduto = autoCompleteProduto;
    }

    public List<ProdutoModalidadeVO> getListaProdutoModadalideVOFiltro() {
	if (listaProdutoModadalideVOFiltro == null) {
	    listaProdutoModadalideVOFiltro = new ArrayList<>();
	}
	return listaProdutoModadalideVOFiltro;
    }

    public void setListaProdutoModadalideVOFiltro(List<ProdutoModalidadeVO> listaProdutoModadalideVOFiltro) {
	this.listaProdutoModadalideVOFiltro = listaProdutoModadalideVOFiltro;
    }

    public List<Garantia> getListaGarantiaBacenObrigatorias() {
	return listaGarantiaBacenObrigatorias;
    }

    public void setListaGarantiaBacenObrigatorias(List<Garantia> listaGarantiaBacenObrigatorias) {
	this.listaGarantiaBacenObrigatorias = listaGarantiaBacenObrigatorias;
    }

    public List<Garantia> getListaGarantiaBacenAcessorias() {
	return listaGarantiaBacenAcessorias;
    }

    public void setListaGarantiaBacenAcessorias(List<Garantia> listaGarantiaBacenAcessorias) {
	this.listaGarantiaBacenAcessorias = listaGarantiaBacenAcessorias;
    }

    public List<ViewProdutoSiico> getListaProdutoCaixa() {
	return listaProdutoCaixa;
    }

    public void setListaProdutoCaixa(List<ViewProdutoSiico> listaProdutoCaixa) {
	this.listaProdutoCaixa = listaProdutoCaixa;
    }

    public List<ViewProdutoSiico> getListaProdutoCaixaBD() {
	return listaProdutoCaixaBD;
    }

    public void setListaProdutoCaixaBD(List<ViewProdutoSiico> listaProdutoCaixaBD) {
	this.listaProdutoCaixaBD = listaProdutoCaixaBD;
    }

    public boolean isTelaEdicao() {
	return isTelaEdicao;
    }

    public void setTelaEdicao(boolean isTelaEdicao) {
	this.isTelaEdicao = isTelaEdicao;
    }

    /**
     * @see br.gov.caixa.pedesgo.arquitetura.visao.ManutencaoVisao#getEntidade()
     */
    @Override
    public GarantiaProduto getEntidade() {
	if (super.getEntidade() == null) {
	    super.setEntidade(new GarantiaProduto());
	}
	return super.getEntidade();
    }

    public void limpar() {
	garantiasProduto = new ArrayList<>();
	autoCompleteProduto = null;
	nuProdutoSelecionado = null;
	nuModalidadeSelecionada = null;
    }

	public Boolean getGarantiaCaixaNaoSeAplica() {
		return garantiaCaixaNaoSeAplica;
	}

	public void setGarantiaCaixaNaoSeAplica(Boolean garantiaCaixaNaoSeAplica) {
		this.garantiaCaixaNaoSeAplica = garantiaCaixaNaoSeAplica;
	}
}