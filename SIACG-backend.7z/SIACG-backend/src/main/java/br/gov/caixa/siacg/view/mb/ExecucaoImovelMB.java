/*
 * Copyright (c) 2019 Caixa Econômica Federal. Todos os direitos
 * reservados.
 *
 * Caixa Econômica Federal - SIACG - Sistema de Crédito Rural
 *
 * Este software foi desenvolvido sob demanda da CAIXA e está
 * protegido por leis de direitos autorais e tratados internacionais. As
 * condições de cópia e utilização do todo ou partes dependem de autorização da
 * empresa. Cópias não são permitidas sem expressa autorização. Não pode ser
 * comercializado ou utilizado para propósitos particulares.
 *
 * Uso exclusivo da Caixa Econômica Federal. A reprodução ou distribuição não
 * autorizada deste programa ou de parte dele, resultará em punições civis e
 * criminais e os infratores incorrem em sanções previstas na legislação em
 * vigor.
 *
 * Histórico do TFS:
 *
 * LastChangedRevision: $Revision$
 * LastChangedBy: $Author$
 * LastChangedDate: $Date$
 *
 * HeadURL: $HeadURL$
 *
 */
package br.gov.caixa.siacg.view.mb;

import java.io.IOException;
import java.io.OutputStream;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.logging.Logger;

import javax.ejb.EJB;
import javax.enterprise.context.SessionScoped;
import javax.faces.context.FacesContext;
import javax.inject.Inject;
import javax.inject.Named;

import org.apache.commons.collections.CollectionUtils;

import br.gov.caixa.pedesgo.arquitetura.controlador.ManutencaoBean;
import br.gov.caixa.pedesgo.arquitetura.dao.DAO;
import br.gov.caixa.pedesgo.arquitetura.servico.Servico;
import br.gov.caixa.pedesgo.arquitetura.util.MensagensUtil;
import br.gov.caixa.pedesgo.arquitetura.util.UtilData;
import br.gov.caixa.pedesgo.arquitetura.visao.ManutencaoVisao;
import br.gov.caixa.siacg.commons.AppConstant;
import br.gov.caixa.siacg.commons.MsgConstant;
import br.gov.caixa.siacg.interceptador.Auditoria;
import br.gov.caixa.siacg.interceptador.OperacaoAuditoria;
import br.gov.caixa.siacg.model.domain.ExecucaoImovel;
import br.gov.caixa.siacg.model.domain.Imovel;
import br.gov.caixa.siacg.model.enums.ExecucaoCheckListImovelEnum;
import br.gov.caixa.siacg.model.enums.TipoExecucaoImovelEnum;
import br.gov.caixa.siacg.model.vo.FiltroImovelVO;
import br.gov.caixa.siacg.pagination.ImovelLazyModel;
import br.gov.caixa.siacg.service.BemClienteService;
import br.gov.caixa.siacg.service.ExecucaoImovelService;
import br.gov.caixa.siacg.service.ImovelService;
import br.gov.caixa.siacg.util.LogCEF;
import br.gov.caixa.siacg.util.NumeroUtil;

/**
 * <p>
 * ExecucaoImovelMB
 * </p>
 *
 * <p>
 * Descrição: Managed Bean para Execucao de imovel
 * </p>
 *
 * <br>
 * <b>Empresa:</b> Cef - Caixa Econômica Federal
 *
 *
 * @author marco.isecke
 *
 * @version 1.0
 */
@Named
@SessionScoped
public class ExecucaoImovelMB extends ManutencaoBean<Imovel> {

    /** Atributo serialVersionUID. */
    private static final long serialVersionUID = 1L;

    /** Atributo LOG. */
    @SuppressWarnings("unused")
    private static final Logger LOG = Logger.getLogger(ExecucaoImovelMB.class.getName());

    /** Atributo PREFIXO_CASO_USO. */
    private static final String PREFIXO_CASO_USO = "execucaoImovel";

    /** Atributo NOME_MANAGED_BEAN. */
    public static final String NOME_MANAGED_BEAN = "execucaoImovelMB";

    /** Atributo EL_MANAGED_BEAN. */
    public static final String EL_MANAGED_BEAN = "#{execucaoImovelMB}";

    /** Atributo PAGINA_CONSULTA_CONTRATO. */
    private static final String PAGINA_CONSULTA_DESPESA = "/pages/execucao/imovel/consulta.xhtml?faces-redirect=true";

    private Imovel imovelExecucao;

    @EJB
    private transient ImovelService imovelService;

    @EJB
    private transient ExecucaoImovelService servico;

    @EJB
    private transient BemClienteService bemClienteService;

    @Inject
    private ImovelLazyModel consultaImovel;

    @Override
    protected String getPrefixoCasoDeUso() {
	return ExecucaoImovelMB.PREFIXO_CASO_USO;
    }

    public String abrirConsulta() {
	this.carregar();
	return ExecucaoImovelMB.PAGINA_CONSULTA_DESPESA;
    }

    @Override
    public <S extends Servico<Imovel, DAO<Imovel>>> S getService() {
	return null;
    }

    @Override
    public ManutencaoVisao<Imovel> getVisao() {
	return null;
    }

    /**
     * Metodo responsavel por carregar a combo de
     * {@link TipoExecucaoImovelEnum}.
     * 
     * @param imovel
     */
    @Auditoria
    @OperacaoAuditoria(acao = "TROCAR_SITUACAO_EXECUCAO_IMOVEL", parametros = { "imovel" })
    public void alterarExecucao(Imovel imovel) {
	List<ExecucaoImovel> execucaoImoveis = imovelService.listarExecucaoImovel(imovel.getNuImovel());
	imovel.setExecucaoImoveis(execucaoImoveis);
	setImovelExecucao(imovel);
    }

    /**
     * A opcao de {@link TipoExecucaoImovelEnum} - 'Consolidação' só sera
     * disponivel todos os {@link ExecucaoCheckListImovelEnum} estiverem
     * marcados 'True' em {@link ExecucaoImovel}
     * 
     * @return
     */
    public boolean desabilitaSelecaoCheck(TipoExecucaoImovelEnum tipo) {
	if (tipo.equals(TipoExecucaoImovelEnum.O)) {
	    for (ExecucaoImovel e : getImovelExecucao().getExecucaoImoveis()) {
		if (!e.isIcMarcado()) {
		    return true;
		}
	    }
	}
	if (tipo.equals(TipoExecucaoImovelEnum.O) && CollectionUtils.isEmpty(getImovelExecucao().getExecucaoImoveis())) {
	    return true;
	}
	return false;
    }

    /**
     * Verifica se o {@link TipoExecucaoImovelEnum} é - 'Conformidade' para
     * criação da {@link ExecucaoImovel} no {@link Imovel}
     */
    public void verificaSituacao() {
	if (getImovelExecucao().getIcTipoExecucao().equals(TipoExecucaoImovelEnum.C)) {
	    servico.criaListaExecucaoImovel(getImovelExecucao());
	}
    }

    /**
     * Metodo responsavel por Salvar o {@link ExecucaoImovel}
     */
    public void salvarAlterarImovel() {
	try {
	    String alterar = imovelService.alterar(getImovelExecucao());
	    if (alterar != null && "MN089".equals(alterar)) {
		super.adicionaMensagemDeErro(MensagensUtil.getMensagem("msgApp", "MN089"));
	    } else {
		super.adicionaMensagemDeSucesso(MensagensUtil.getMensagem("msgApp", "MA020"));
	    }
	} catch (final RuntimeException e) {
	    LogCEF.error("Erro ao Salvar Execução do Imóvel: " + e.getMessage());
	    LogCEF.error(e);
	}
    }

    /**
     * Verifica se todos os itens do Chcecklist
     * 
     * @return
     */
    public boolean isMostraCheckConformidade() {
	return getImovelExecucao().getIcTipoExecucao() != null
		&& TipoExecucaoImovelEnum.C.getValor().equals(getImovelExecucao().getIcTipoExecucao().getValor());
    }

    /**
     * Get the {@link ImovelLazyModel}
     * 
     * @return
     */
    public ImovelLazyModel getConsultaImovel() {
	if (this.consultaImovel == null) {
	    this.consultaImovel = new ImovelLazyModel();
	}
	if (consultaImovel.getFiltro() == null) {
	    consultaImovel.setFiltro(new FiltroImovelVO());
	}
	return this.consultaImovel;
    }

    /**
     * @return the imovelExecucao
     */
    public Imovel getImovelExecucao() {
	if (imovelExecucao == null)
	    imovelExecucao = new Imovel();
	return imovelExecucao;
    }

    /**
     * @param imovelExecucao
     *            the imovelExecucao to set
     */
    public void setImovelExecucao(Imovel imovelExecucao) {
	this.imovelExecucao = imovelExecucao;
    }

    /**
     * 
     * @return the {@link List} de {@link TipoExecucaoImovelEnum}
     */
    public List<TipoExecucaoImovelEnum> getListaTipoExecucao() {
	return Arrays.asList(TipoExecucaoImovelEnum.values());
    }

    @Auditoria
    @OperacaoAuditoria(acao = "GERAR_ARQUIVO_SIPGE", parametros = { "imovel" })
    public void gerarArquivoSIPGE(Imovel imovelExecucao) {
	this.servico.gerarArquivoSIPGE(imovelExecucao);
	super.adicionaMensagemDeSucesso(MensagensUtil.getMensagem(AppConstant.RESOURCE_BUNDLE, MsgConstant.GERACAO_ARQUIVO_SUCESSO));
    }

    @Auditoria
    @OperacaoAuditoria(acao = "VISUALIZAR_ARQUIVO_SIPGE", parametros = { "imovel" })
    public void downloadArquivoSelecionadoSIPGE(Imovel imovel) {
	byte[] arquivoZipado = this.servico.gerarArquivoZipadoDownload(imovel);
	if (arquivoZipado != null) {
	    String strDataHora = NumeroUtil.somenteNumeros(UtilData.converterDateParaString(new Date(), "dd-MM-yyyy"));
	    String nomeArquivoZip = "SIPGE_" + strDataHora + ".zip";
	    this.getResponse().setContentType("application/zip");
	    this.getResponse().addHeader("Content-Disposition", "attachment;filename=" + nomeArquivoZip);

	    try {
		OutputStream output = this.getResponse().getOutputStream();
		output.write(arquivoZipado);
		this.getResponse().flushBuffer();
	    } catch (IOException e) {
		LogCEF.info("Erro ao gerar o download do arquivo SIPGE. Detalhes: " + e.getMessage());
		LogCEF.info(e);
	    }
	    FacesContext.getCurrentInstance().responseComplete();
	} else {
	    super.adicionaMensagemDeErro(MensagensUtil.getMensagem(AppConstant.RESOURCE_BUNDLE, MsgConstant.GERACAO_ARQUIVO_ERRO));
	}
    }
}