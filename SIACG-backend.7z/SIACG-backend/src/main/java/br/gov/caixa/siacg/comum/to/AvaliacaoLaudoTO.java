package br.gov.caixa.siacg.comum.to;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public class AvaliacaoLaudoTO {

	private Integer codigoImovel;	
	private String codigoSituacaoAvaliacao;	
	private String descricaoSituacaoAvaliacao;	
	private Integer identificacaoAvaliacao;	
	private String ordemServico;
	
	public AvaliacaoLaudoTO() {
		super();
	}

	public Integer getCodigoImovel() {
		return codigoImovel;
	}

	public void setCodigoImovel(Integer codigoImovel) {
		this.codigoImovel = codigoImovel;
	}

	public String getCodigoSituacaoAvaliacao() {
		return codigoSituacaoAvaliacao;
	}

	public void setCodigoSituacaoAvaliacao(String codigoSituacaoAvaliacao) {
		this.codigoSituacaoAvaliacao = codigoSituacaoAvaliacao;
	}

	public String getDescricaoSituacaoAvaliacao() {
		return descricaoSituacaoAvaliacao;
	}

	public void setDescricaoSituacaoAvaliacao(String descricaoSituacaoAvaliacao) {
		this.descricaoSituacaoAvaliacao = descricaoSituacaoAvaliacao;
	}

	public Integer getIdentificacaoAvaliacao() {
		return identificacaoAvaliacao;
	}

	public void setIdentificacaoAvaliacao(Integer identificacaoAvaliacao) {
		this.identificacaoAvaliacao = identificacaoAvaliacao;
	}

	public String getOrdemServico() {
		return ordemServico;
	}

	public void setOrdemServico(String ordemServico) {
		this.ordemServico = ordemServico;
	}
	
}
