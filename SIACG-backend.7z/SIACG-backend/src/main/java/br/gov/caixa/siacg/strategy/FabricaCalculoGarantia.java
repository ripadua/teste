package br.gov.caixa.siacg.strategy;

import java.time.LocalDateTime;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.logging.Logger;

import javax.annotation.PostConstruct;
import javax.ejb.EJB;
import javax.ejb.Singleton;
import javax.naming.InitialContext;

import br.gov.caixa.pedesgo.arquitetura.util.LogCefUtil;
import br.gov.caixa.pedesgo.arquitetura.util.UtilData;
import br.gov.caixa.pedesgo.arquitetura.util.UtilObjeto;
import br.gov.caixa.siacg.comum.to.GarantiaContratoCalculoTO;
import br.gov.caixa.siacg.dao.SegmentoDAO;
import br.gov.caixa.siacg.model.domain.GarantiaContrato;
import br.gov.caixa.siacg.model.domain.GrupoGarantia;
import br.gov.caixa.siacg.model.domain.Segmento;
import br.gov.caixa.siacg.service.GrupoGarantiaService;
import br.gov.caixa.siacg.service.impl.util.SiacgServiceImpl;

/**
 * <p>
 * FabricaCalculoGarantia
 * </p>
 * <p>
 * Descrição: Classe FabricaCalculoGarantia
 * </p>
 * <br>
 * <b>Empresa:</b> Cef - Caixa Econômica Federal.
 *
 * @author GS Tecnologia
 * @version 1.0
 */
@Singleton
public class FabricaCalculoGarantia {

    /** Atributo calculo garantia aplicacao financeira. */
    private CalculoGarantia calculoGarantiaAplicacaoFinanceira;

    /** Atributo calculo garantia duplicata. */
    private CalculoGarantia calculoGarantiaDuplicata;

    /** Atributo calculo garantia cheque. */
    private CalculoGarantia calculoGarantiaCheque;

    /** Atributo calculo garantia cartao credito. */
    private CalculoGarantia calculoGarantiaCartaoCredito;
    
    /** Atributo calculo garantia cartao credito V2. */
    private CalculoGarantia calculoGarantiaCartaoCreditoV2;

    /** Atributo calculo garantia maquina equipamento. */
    private CalculoGarantia calculoGarantiaMaquinaEquipamento;

    /** Atributo calculo garantia veiculo. */
    private CalculoGarantia calculoGarantiaVeiculo;

    /** Atributo calculo garantia imovel. */
    private CalculoGarantia calculoGarantiaImovel;

    /** Atributo calculo garantia fianca bancaria. */
    private CalculoGarantia calculoGarantiaFiancaBancaria;

    /** Atributo calculo garantia outros. */
    private CalculoGarantia calculoGarantiaOutros;
    
    /** Atributo calculo garantia indice hipotecário. */
    private CalculoGarantia calculoIndiceHipotecario;
    
    /** Atributo calculo garantia produtos agricolas. */
    private CalculoGarantia calculoProdutosAgricolas;
    
    /** Atributo calculo indice garantia. */
    private CalculoGarantia calculoIndiceGarantia;
    
    /** Atributo calculo Garantia Empreendimento Hipoteca. */
    private CalculoGarantia calculoGarantiaEmpreendimentoHipoteca;
    
    /** Atributo para chamar o serviço de Grupo Garantia */
    private GrupoGarantiaService grupoGarantiaService;
    
    private SegmentoDAO segmentoDAO;
    
    // Cache de segmentos
    private static LocalDateTime ultimaAtualizacaoSegmentos = null;
    private static List<Segmento> listaSegmentos = new ArrayList<>();
    private static Integer duracaoCacheSegmentosMinutos = 60;
    
    @EJB
    private SiacgServiceImpl siacgServiceImpl;

    /** Atributo log. */
    private static final Logger LOG = Logger.getLogger(FabricaCalculoGarantia.class.getName());
    
    @PostConstruct
    public void init () {
	try {
            final InitialContext ctx = new InitialContext();
            this.calculoGarantiaAplicacaoFinanceira = (CalculoGarantia) ctx.lookup(this.siacgServiceImpl.getGlobalEJBNaming() + "CalculoGarantiaAplicoesFinanceiras");
            this.calculoGarantiaDuplicata = (CalculoGarantia) ctx.lookup(this.siacgServiceImpl.getGlobalEJBNaming() + "CalculoGarantiaDuplicata");
            this.calculoGarantiaCheque = (CalculoGarantia) ctx.lookup(this.siacgServiceImpl.getGlobalEJBNaming() + "CalculoGarantiaCheques");
            this.calculoGarantiaCartaoCredito = (CalculoGarantia) ctx.lookup(this.siacgServiceImpl.getGlobalEJBNaming() + "CalculoGarantiaCartaoCredito");
            this.calculoGarantiaCartaoCreditoV2 = (CalculoGarantia) ctx.lookup(this.siacgServiceImpl.getGlobalEJBNaming() + "CalculoGarantiaCartaoCreditoV2");
            this.calculoGarantiaMaquinaEquipamento = (CalculoGarantia) ctx.lookup(this.siacgServiceImpl.getGlobalEJBNaming() + "CalculoGarantiaMaquinaEquipamento");
            this.calculoGarantiaVeiculo = (CalculoGarantia) ctx.lookup(this.siacgServiceImpl.getGlobalEJBNaming() + "CalculoGarantiaVeiculo");
            this.calculoGarantiaImovel = (CalculoGarantia) ctx.lookup(this.siacgServiceImpl.getGlobalEJBNaming() + "CalculoGarantiaImovel");
            this.calculoGarantiaFiancaBancaria = (CalculoGarantia) ctx.lookup(this.siacgServiceImpl.getGlobalEJBNaming() + "CalculoGarantiaFiancaBancaria");
            this.calculoGarantiaOutros = (CalculoGarantia) ctx.lookup(this.siacgServiceImpl.getGlobalEJBNaming() + "CalculoGarantiaOutros");
            this.calculoProdutosAgricolas = (CalculoGarantia) ctx.lookup(this.siacgServiceImpl.getGlobalEJBNaming() + "CalculoGarantiaProdutosAgricolas");
            this.calculoIndiceHipotecario = (CalculoGarantia) ctx.lookup(this.siacgServiceImpl.getGlobalEJBNaming() + "CalculoGarantiaIndiceHipotecario");
            this.calculoIndiceGarantia = (CalculoGarantia) ctx.lookup(this.siacgServiceImpl.getGlobalEJBNaming() + "CalculoIndiceGarantia"); 
            this.calculoGarantiaEmpreendimentoHipoteca = (CalculoGarantia) ctx.lookup(this.siacgServiceImpl.getGlobalEJBNaming() + "CalculoGarantiaEmpreendimentoHipoteca");
            this.grupoGarantiaService = (GrupoGarantiaService) ctx.lookup(this.siacgServiceImpl.getGlobalEJBNaming() + "GrupoGarantiaServiceImpl");
            this.segmentoDAO = (SegmentoDAO) ctx.lookup(this.siacgServiceImpl.getGlobalEJBNaming() + "SegmentoDAOImpl");            
        } catch (final Exception e) {
            FabricaCalculoGarantia.LOG.fine(e.getMessage());
            LogCefUtil.error(e);
        }
    }

    /**
     * <p>
     * Método responsável por retornar a interface de acordo com o tipo da
     * garantia.
     * <p>
     *
     * @param garantiaContrato
     *            valor a ser atribuido
     * @return CalculoGarantia
     * @author guilherme.santos
     * @author Mábio Barbosa
     * @author Brunno Antunes
     */
    public CalculoGarantia getCalculo(final GarantiaContratoCalculoTO garantiaContrato) {
        if (garantiaContrato.isGarantiaDuplicata()) {
            return this.calculoGarantiaDuplicata;
        }
        if (garantiaContrato.isGarantiaHabitacional()) {
            return this.calculoIndiceHipotecario;
        }
        if (garantiaContrato.isGarantiaAplicacaoFinanceira()) {
            return this.calculoGarantiaAplicacaoFinanceira;
        }
        if (garantiaContrato.isGarantiaCartaoCredito()) {
            return this.getCalculoCartaoCredito(garantiaContrato);
        }
        if (garantiaContrato.isGarantiaCheque()) {
            return this.calculoGarantiaCheque;
        }
        if (garantiaContrato.isGarantiaVeiculo()) {
            return this.calculoGarantiaVeiculo;
        }
        if (garantiaContrato.isGarantiaFiancaBancaria()) {
            return this.calculoGarantiaFiancaBancaria;
        }
        if(garantiaContrato.isIndiceGarantia()) {
        	return this.calculoIndiceGarantia;
        }
        if(garantiaContrato.isCalculoGarantiaEmpreendimentoHipoteca()) {
        	return this.calculoGarantiaEmpreendimentoHipoteca;
        }
        
        if(garantiaContrato.getContrato() == null || garantiaContrato.getContrato().getDtContrato() == null
        	|| garantiaContrato.getDtTratarAcompanhamento() == null) {
            return this.calculoGarantiaOutros;
        }
		
        boolean passouASerAcompanhada = this.isGarantiaPassouSerAcompanhada(garantiaContrato.getContrato().getDtContrato(),
        		garantiaContrato.getDtTratarAcompanhamento());
        
        if (garantiaContrato.isGarantiaMaquinaEquipamento() && passouASerAcompanhada) {
            return this.calculoGarantiaMaquinaEquipamento;
        }
        if (garantiaContrato.isGarantiaImovel() && passouASerAcompanhada) {
            return this.calculoGarantiaImovel;
        }
        if (garantiaContrato.isGarantiaProdutosAgricolas() && passouASerAcompanhada) {
            return this.calculoProdutosAgricolas;
        }
        
        return this.calculoGarantiaOutros;
    }

    /**
     * 
     * <p>
     * Método responsável por retornar a classe referente o calculo do Cartão de
     * Crédito. Avaliando se deve retornar a versão nova ou a legada.
     * </p>
     * .
     *
     * @author Mábio Barbosa
     *
     * @param garantiaContrato
     * @return CalculoGarantia Se for posterior a data parametrizada, então
     *         retornará o Calculo V2, caso contrário retorna o Calculo já
     *         existente (legado).
     */
    private CalculoGarantia getCalculoCartaoCredito(final GarantiaContratoCalculoTO garantiaContrato) {

	if(garantiaContrato == null || garantiaContrato.getContrato() == null || garantiaContrato.getContrato().getDtContrato() == null) {
	    return this.calculoGarantiaCartaoCredito;
	}
	
	if(garantiaContrato.getContrato().getPessoa().getNuSegmento() == null || garantiaContrato.getDtCorteCalculoGarantia() == null) {
	    return this.calculoGarantiaCartaoCredito;
	}
	
	return this.isGarantiaCartaoCreditoV2(garantiaContrato.getContrato().getDtContrato(), 
		garantiaContrato.getContrato().getPessoa().getNuSegmento(), garantiaContrato.getDtCorteCalculoGarantia())
		? this.calculoGarantiaCartaoCreditoV2
		: this.calculoGarantiaCartaoCredito;
    }
    
    /**
     * 
     * <p>Método responsável por verificar se o calculo da garantia Cartão a ser utilizado é o V2 ou o V1</p>.
     *
     * @author Mábio Barbosa
     * 		   , narcieliton.lopes
     * @param garantiaContrato
     * @return TRUE caso o calculo seja o V2, FALSE caso contrário.
     * 
     * @dataAlteracao 2019-10-17 yyyy-MM-dd
     */
    public boolean isGarantiaCartaoCreditoV2(final GarantiaContrato garantiaContrato) {
    	return isGarantiaCartaoCreditoV2(garantiaContrato.getNuContrato().getDtContrato(), 
    			garantiaContrato.getNuContrato().getNuPessoa().getNuSegmento().getNuSegmento(), 
    			garantiaContrato.getGarantia().getGrupoGarantia().getDataCorteCalculoGarantia());
    }
    
    /**
     * <p>Método responsável por</p>.
     *
     * @author f541915
     *
     * @param dtContrato
     * @param nuSegmento
     * @return
     */
    public boolean isGarantiaCartaoCreditoV2(final Date dtContrato, Integer nuSegmento, Date dataNovoCalculoCartao) {
    	boolean isGarantiaCartaoCreditoVersao2 = false;
    	
    	if(dataNovoCalculoCartao == null)
		    return false;
    	
    	boolean dataMaiorQueParametrizada = UtilData.verificarSeDataEhMaior(dtContrato, dataNovoCalculoCartao);
    
    	if (dataMaiorQueParametrizada) {
    	    isGarantiaCartaoCreditoVersao2 = isGarantiaCartaoCreditoV2PorSegmento(nuSegmento);
    	}
    	return isGarantiaCartaoCreditoVersao2;
    }

    /**
     * <p>Método responsável por verificar se a garantia existente como Não Acompanhada passou a ser Acompanhada. 
     * Se sim, então retornar o calculo específico, caso contrário manter o calculo de Outros (Não Acompanhada).</p>.
     *
     * @author Mábio Barbosa
     *
     * @param garantiaContrato
     * @return TRUE caso a data do contrato seja posterior a data parametrizada, FALSE caso contrário.
     */
    public boolean isGarantiaPassouSerAcompanhada(final GarantiaContrato garantiaContrato) {
    	
	if(!UtilObjeto.isReferencia(garantiaContrato) || !UtilObjeto.isReferencia(garantiaContrato.getGarantia())
		|| !UtilObjeto.isReferencia(garantiaContrato.getNuContrato())){
    	    return false; 
    	}
	
    	GrupoGarantia grupoGarantia = garantiaContrato.getGarantia().getGrupoGarantia();
    	
    	if(!UtilObjeto.isReferencia(grupoGarantia.getNuGrupoGarantia())){
    	    return false;
    	}
		
    	return isGarantiaPassouSerAcompanhada(garantiaContrato.getNuContrato().getDtContrato(), 
    			grupoGarantia.getDataTratarAcompanhamento());
    }
    
    /**
     * <p>Método responsável por verificar se a garantia existente como Não Acompanhada passou a ser Acompanhada. 
     * Se sim, então retornar o calculo específico, caso contrário manter o calculo de Outros (Não Acompanhada).</p>.
     *
     * @author Mábio Barbosa
     *
     * @param garantiaContrato
     * @return TRUE caso a data do contrato seja posterior a data parametrizada, FALSE caso contrário.
     */
    public boolean isGarantiaPassouSerAcompanhada(final Date dtContrato, Date dataGarantiaAC) {
    	if(dataGarantiaAC == null)
    	    return false;
    	
    	return UtilData.verificarSeDataEhMaior(dtContrato, dataGarantiaAC);
    }
    
    /**
     *
     *Verifica se a data do contrato (ultima) é maior que a data de acompanhamento do GrupoGarantia 
     * @author Mábio Barbosa
     *
     * @param garantiaContrato
     * @return TRUE caso a data do contrato seja posterior a data de acompanhamento do grupo garantia, FALSE caso contrário.
     */
    public boolean isGarantiaPassouSerAcompanhada(final GrupoGarantia grupoGarantia, Date dataContrato) {
	
	if(grupoGarantia == null) {
	    LogCefUtil.warn("Grupo garantia nulo.");
	    return false;
	}
	
    	Date dataGarantiaAC = grupoGarantiaService.consultarDataTratarAcompanhamento(grupoGarantia.getNuGrupoGarantia());
    	
    	if(dataGarantiaAC == null) {
    	    LogCefUtil.warn("Data tratar como acompanhada do Grupo garantia está sem valor.");
    	    return false;
    	}
    	
    	return UtilData.verificarSeDataEhMaior(dataContrato, dataGarantiaAC);
    }
    
    /**
     * <p> Método responsável por verificar o segmento do cliente e conforme o segmento deverá mostrar parametrização cartão
     * 		versão 2 ou não. </p>
     * 
     * @author narcieliton.lopes
     * @param pessoa
     * 
     * @return True caso seja para mostrar a tela de parametrização de cartão Versão 2 
     * 			False caso seja Versão 1
     * 
     * @dataCriacao 2019-10-17 yyyy-MM-dd
     * */
    public boolean isGarantiaCartaoCreditoV2PorSegmento(Integer nuSegmento) {
	boolean isValido = false;

	List<Segmento> segmentos = this.obterSegmentosNovoCartao();

	for (Segmento segmento : segmentos) {
	    isValido = segmento.getNuSegmento() == nuSegmento;
	    if (isValido) {
		break;
	    }
	}

	return isValido;
    }
    
    /**
     * <p>Método responsável por obter os segmentos de novo cartao</p>.
     *
     * @author f541915
     *
     * @return
     */
    private List<Segmento> obterSegmentosNovoCartao() {
	if (ultimaAtualizacaoSegmentos != null) {
	    long time = ChronoUnit.MINUTES.between(ultimaAtualizacaoSegmentos, LocalDateTime.now());
	    if (time > duracaoCacheSegmentosMinutos) {
		ultimaAtualizacaoSegmentos = null;
		listaSegmentos.clear();
	    }
	}
	if (!listaSegmentos.isEmpty()) {
	    return listaSegmentos;
	}
	List<Segmento> segmentos = segmentoDAO.listarSegmentosNovoCartao();
	if (ultimaAtualizacaoSegmentos == null) {
	    ultimaAtualizacaoSegmentos = LocalDateTime.now();
	}
	listaSegmentos.addAll(segmentos);
	return segmentos;
    }
}
