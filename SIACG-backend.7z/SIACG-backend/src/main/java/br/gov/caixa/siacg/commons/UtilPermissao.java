package br.gov.caixa.siacg.commons;

import java.util.ArrayList;
import java.util.Collection;

import javax.ejb.EJB;
import javax.ejb.Stateless;

import br.gov.caixa.pedesgo.arquitetura.util.UtilObjeto;
import br.gov.caixa.pedesgo.arquitetura.enumerador.EnumAcao;
import br.gov.caixa.pedesgo.arquitetura.enumerador.EnumNomeAbrangenciaRestritaUnidade;
import br.gov.caixa.pedesgo.arquitetura.enumerador.EnumTipoAbrangencia;
import br.gov.caixa.pedesgo.arquitetura.util.UsuarioUtil;
import br.gov.caixa.siacg.model.enums.TipoPerfilEnum;
import br.gov.caixa.siacg.model.vo.SrVO;
import br.gov.caixa.siacg.model.vo.UnidadeVO;
import br.gov.caixa.siacg.service.UnidadeVinculadaSuatService;

/**
 * <p>
 * UtilPermissao
 * </p>
 * <p>
 * Descrição: Classe responsável por verificar as permissões de acesso do
 * sistema SIACG.
 * </p>
 * <br>
 * <b>Empresa:</b> Cef - Caixa Econômica Federal
 *
 * @author José Roberto
 * @author Waltenes Junior
 * @version 1.0
 */
@Stateless
public final class UtilPermissao {

    /** Atributo unidadeVinculadaSuatService. */
    @EJB
    private UnidadeVinculadaSuatService unidadeVinculadaSuatService;

    /**
     * <p>
     * Método responsável por preparar as unidades para a consulta por tipo de
     * abrangencia.
     * <p>
     *
     * @param nomeFuncionalidade
     *            valor a ser atribuido
     * @return Collection<Integer> coleção de unidades vinculadas ao usuario
     * @author Waltenes Junior
     */
    public Collection<Integer> prepararConsultaPorTipoAbrangencia(final String nomeFuncionalidade) {

        final Integer unidadeUsuarioLogado = Integer.valueOf(UsuarioUtil.getUsuarioLogado().getCoUnidade());

        final Collection<Integer> listaUnidades = new ArrayList<>();

        if (UsuarioUtil.contemPermissao(nomeFuncionalidade, EnumAcao.CONSULTAR.getNoAcao(), EnumTipoAbrangencia.RESTRITA_UNIDADE.getTipoAbrangencia(),
                EnumNomeAbrangenciaRestritaUnidade.UNIDADE.getNomeAbrangencia())) {

            listaUnidades.add(unidadeUsuarioLogado);

        } else if (UsuarioUtil.contemPermissao(nomeFuncionalidade, EnumAcao.CONSULTAR.getNoAcao(),
                EnumTipoAbrangencia.RESTRITA_UNIDADE.getTipoAbrangencia(), EnumNomeAbrangenciaRestritaUnidade.VINCULADAS.getNomeAbrangencia())) {

            final Collection<Integer> listaNuSrs = new ArrayList<>();
            final Collection<Integer> listaUnidadesVinculadas = new ArrayList<>();

            final UnidadeVinculadaSuatService servicoUnidadeVinculada = this.unidadeVinculadaSuatService;

            Integer nuSr = null;
            Integer nuSuat = null;

            if (UsuarioUtil.contemPerfil(TipoPerfilEnum.GESTOR_REGIONAL.getNome())
                    || UsuarioUtil.contemPerfil(TipoPerfilEnum.GESTOR_REGIONAL_2.getNome())) {

                nuSr = unidadeUsuarioLogado;

            } else if (UsuarioUtil.contemPerfil(TipoPerfilEnum.GESTOR_NACIONAL.getNome())) {

                nuSuat = unidadeUsuarioLogado;
            }

            if (UtilObjeto.isReferencia(nuSuat)) {

                for (final SrVO vo : servicoUnidadeVinculada.listarSrsPorNuSuat(nuSuat)) {
                    listaNuSrs.add(vo.getNuSrVO());
                }

                listaUnidadesVinculadas.addAll(servicoUnidadeVinculada.getNuUnidadesVinculadasSR(listaNuSrs));

            } else if (UtilObjeto.isReferencia(nuSr)) {

                for (final UnidadeVO unidadeVO : servicoUnidadeVinculada.listarUnidadesPorNuSr(nuSr)) {
                    listaUnidades.add(unidadeVO.getCoUnidadeVO());
                }
            }

            listaUnidades.addAll(listaUnidadesVinculadas);
        }

        return listaUnidades;
    }
}
