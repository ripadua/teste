package br.gov.caixa.siacg.view.form;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import br.gov.caixa.pedesgo.arquitetura.util.UtilObjeto;
import br.gov.caixa.pedesgo.arquitetura.enumerador.EnumUF;
import br.gov.caixa.siacg.model.domain.GestaoServentia;
import br.gov.caixa.siacg.model.domain.InstituicaoBancaria;

/**
 * <p>
 * GestaoServentiaVisao
 * </p>
 * <p>
 * Descrição: Classe responsável por armazenar os dados da visão do caso de uso <code>Gestão Serventia</code>.
 * </p>
 * 
 * <b>Empresa:</b> Cef - Caixa Econômica Federal
 *
 * @author Leandro Oliveira
 * @version 1.0
 */
public class GestaoServentiaVisao extends TemplateVisao<GestaoServentia> {

    private static final long serialVersionUID = 1L;

    private GestaoServentia gestaoServentia;
    
    private List<EnumUF> listaEstado;
    
    private List<InstituicaoBancaria> listaInstituicaoBancaria;
    
    private boolean mostraDadosBancarios;
    
    

    /**
     * @return the gestaoServentia
     */
    public GestaoServentia getGestaoServentia() {
        return gestaoServentia;
    }

    /**
     * @param gestaoServentia the gestaoServentia to set
     */
    public void setGestaoServentia(GestaoServentia gestaoServentia) {
        this.gestaoServentia = gestaoServentia;
    }

    /**
     * @return the listaEstado
     */
    public List<EnumUF> getListaEstado() {
		if(UtilObjeto.isVazio(this.listaEstado)) {
		    listaEstado = Arrays.asList(EnumUF.values());
		}
        return listaEstado;
    }

    /**
     * @param listaEstado the listaEstado to set
     */
    public void setListaEstado(List<EnumUF> listaEstado) {
        this.listaEstado = listaEstado;
    }

	public List<InstituicaoBancaria> getListaInstituicaoBancaria() {
		if (!UtilObjeto.isReferencia(listaInstituicaoBancaria)) {
			this.listaInstituicaoBancaria = new ArrayList<>();
		}
		return this.listaInstituicaoBancaria;
	}
	
	public void setListaInstituicaoBancaria(List<InstituicaoBancaria> listaInstituicaoBancaria) {
		this.listaInstituicaoBancaria = listaInstituicaoBancaria;
	}

	public boolean isMostraDadosBancarios() {
		return mostraDadosBancarios;
	}

	public void setMostraDadosBancarios(boolean mostraDadosBancarios) {
		this.mostraDadosBancarios = mostraDadosBancarios;
	}
    
}
