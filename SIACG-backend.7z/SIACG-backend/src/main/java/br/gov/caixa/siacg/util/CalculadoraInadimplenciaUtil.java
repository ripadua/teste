package br.gov.caixa.siacg.util;

import java.util.Date;

import br.gov.caixa.pedesgo.arquitetura.util.UtilData;

/**
 * <p>
 * CalculadoraInadimplenciaUtil
 * </p>
 * <p>
 * Descrição: Classe responsável por calcular a inadimplência.
 * </p>
 * <br>
 * <b>Empresa:</b> Cef - Caixa Econômica Federal
 *
 * @author guilherme.santos
 * @version 1.0
 */
public final class CalculadoraInadimplenciaUtil {
    
    /** Atributo trinta dias. */
    private static final int TRINTA_DIAS = 30;

    /** Atributo 1 ano em dias. */
    private static final int UM_ANO_EM_DIAS = 365;
    
    private CalculadoraInadimplenciaUtil() {
	throw new IllegalStateException("Classe de Utilidade");
    }

    /**
     * <p>
     * Método responsável por retornar a descrição do inicio da inadimplência.
     * <p>
     *
     * @param dtMaiorInadimplencia
     *            valor a ser atribuido
     * @return String
     * @author guilherme.santos
     */
    public static String getDescricaoInicioInadimplencia(final Date dtMaiorInadimplencia) {
        final String descricao;

        if (dtMaiorInadimplencia == null) {
            descricao = "Garantia suficiente";
        } else {
            final int diasInadimplencia = UtilData.diferencaEmDiasEntreDatas(dtMaiorInadimplencia, new Date());
            final int anos = diasInadimplencia / CalculadoraInadimplenciaUtil.UM_ANO_EM_DIAS;
            int meses = 0;

            if (anos > 0) {
                meses = (diasInadimplencia - (anos * CalculadoraInadimplenciaUtil.UM_ANO_EM_DIAS)) / CalculadoraInadimplenciaUtil.TRINTA_DIAS;
            }

            if (diasInadimplencia < 1) {
                descricao = "menos de 1 dia";
            } else if (diasInadimplencia >= 1 && diasInadimplencia < CalculadoraInadimplenciaUtil.TRINTA_DIAS) {
                descricao = diasInadimplencia + " dia(s)";
            } else if (diasInadimplencia >= CalculadoraInadimplenciaUtil.TRINTA_DIAS
                    && diasInadimplencia < CalculadoraInadimplenciaUtil.UM_ANO_EM_DIAS) {
                descricao = diasInadimplencia / CalculadoraInadimplenciaUtil.TRINTA_DIAS + " mês(es)";
            } else if (diasInadimplencia >= CalculadoraInadimplenciaUtil.UM_ANO_EM_DIAS && meses == 0) {
                descricao = anos + " ano(s)";
            } else {
                descricao = anos + " ano(s) e " + meses + " mês(es)";
            }
        }

        return descricao;
    }
}
