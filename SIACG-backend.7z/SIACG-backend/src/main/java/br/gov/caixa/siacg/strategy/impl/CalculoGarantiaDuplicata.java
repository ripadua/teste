package br.gov.caixa.siacg.strategy.impl;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;
import java.util.List;

import javax.ejb.EJB;
import javax.ejb.Stateless;

import org.apache.commons.collections.CollectionUtils;
import org.apache.log4j.Logger;
import org.jboss.ejb3.annotation.TransactionTimeout;

import br.gov.caixa.pedesgo.arquitetura.to.FeriadoTO;
import br.gov.caixa.pedesgo.arquitetura.excecao.SistemaException;
import br.gov.caixa.pedesgo.arquitetura.util.UtilData;
import br.gov.caixa.siacg.comum.to.CedenteCalculoTO;
import br.gov.caixa.siacg.comum.to.ContratoCalculoTO;
import br.gov.caixa.siacg.comum.to.GarantiaContratoCalculoTO;
import br.gov.caixa.siacg.dao.DuplicataExcepcionadaDAO;
import br.gov.caixa.siacg.dao.FeriadoDAO;
import br.gov.caixa.siacg.dao.GarantiaContratoDAO;
import br.gov.caixa.siacg.dao.ParametroCalculoDAO;
import br.gov.caixa.siacg.dao.PropriedadeDAO;
import br.gov.caixa.siacg.dao.SacadoExcepcionadoDAO;
import br.gov.caixa.siacg.dao.TituloDAO;
import br.gov.caixa.siacg.dao.UnidadeDAO;
import br.gov.caixa.siacg.model.domain.Cedente;
import br.gov.caixa.siacg.model.domain.DuplicataExcepcionada;
import br.gov.caixa.siacg.model.domain.Sacado;
import br.gov.caixa.siacg.model.domain.Titulo;
import br.gov.caixa.siacg.model.enums.CaracteristicaEnum;
import br.gov.caixa.siacg.model.enums.FormaGarantiaEnum;
import br.gov.caixa.siacg.model.vo.ParametrosCalculoGarantiaVO;
import br.gov.caixa.siacg.model.vo.RelatorioAnaliseContratoVO;
import br.gov.caixa.siacg.service.TituloService;
import br.gov.caixa.siacg.strategy.CalculoGarantia;
import br.gov.caixa.siacg.strategy.impl.titulo.ParametrosCalculoTitulo;
import br.gov.caixa.siacg.strategy.impl.titulo.TotalizadorTituloAnaliseContrato;
import br.gov.caixa.siacg.thread.ConsultaTitulosThread;

/**
 * <p>
 * CalculoGarantiaDuplicata
 * </p>
 * <p>
 * DescriÃ§Ã£o: ImplementaÃ§Ã£o do calculo para Garantia do tipo duplicata.
 * </p>
 * <br>
 * <b>Empresa:</b> Cef - Caixa EconÃ´mica Federal
 *
 * @author guilherme.santos
 * @version 1.0
 */
@Stateless
public class CalculoGarantiaDuplicata implements CalculoGarantia {

    private static final long serialVersionUID = -3988547585377681591L;

    /** Atributo CINCO_HORAS. */
    private static final int CINCO_HORAS = 18000;
    /** Atributo QTD_DIAS_FLUXO_PADRAO. */
    private static final int QTD_DIAS_FLUXO_PADRAO = 60;
    /** Atributo CHAVE_PRAZO_MAXIMO_PERMITIDO. */
    private static final int CHAVE_PRAZO_MAXIMO_PERMITIDO = 1;
    /** Atributo CHAVE_VALOR_MAXIMO_PERMITIDO. */
    private static final int CHAVE_VALOR_MAXIMO_PERMITIDO = 2;
    /** Atributo CHAVE_PERCENTUAL_MAXIMO_PERMITIDO. */
    private static final int CHAVE_PERCENTUAL_MAXIMO_PERMITIDO = 3;

    /** Atributo UMA_SEMANA. */
    private static final int UMA_SEMANA = 7;
    /** Atributo GARANTIA_CONTRATO. */
    private static final String GARANTIA_CONTRATO = "Garantia do contrato: ";
    /** Atributo LOG. */
    private static final Logger LOG = Logger.getLogger(CalculoGarantiaDuplicata.class);

    /** Atributo QTD_MAXIMA_CONSULTA. */
    private static final Integer QTD_MAXIMA_CONSULTA = 100000;

    /** Atributo QTD_THREADS. */
    private static final Integer QTD_THREADS = 5;

    /** Atributo parametroCalculoDAO. */
    @EJB
    private transient ParametroCalculoDAO parametroCalculoDAO;
    /** Atributo duplicataExcepcionadaDAO. */
    @EJB
    private transient DuplicataExcepcionadaDAO duplicataExcepcionadaDAO;
    /** Atributo tituloDao. */
    @EJB
    private transient TituloDAO tituloDao;
    /** Atributo propriedadeDAO. */
    @EJB
    private transient PropriedadeDAO propriedadeDAO;
    /** Atributo garantiaContratoDao. */
    @EJB
    private transient GarantiaContratoDAO garantiaContratoDao;
    /** Atributo sacadoExcepcionadoDao. */
    @EJB
    private transient SacadoExcepcionadoDAO sacadoExcepcionadoDao;
    /** Atributo feriadoDAO. */
    @EJB
    private transient FeriadoDAO feriadoDAO;
    /** Atributo unidadeDAO. */
    @EJB
    private transient UnidadeDAO unidadeDAO;
    /** Atributo tituloService. */
    @EJB
    private transient TituloService tituloService;

    /**
     * @see br.gov.caixa.siacg.strategy.CalculoGarantia#calcular(br.gov.caixa.siacg.model.vo.ParametrosCalculoGarantiaVO,
     *      br.gov.caixa.siacg.model.vo.RelatorioAnaliseContratoVO)
     */
    @Override
    @TransactionTimeout(CalculoGarantiaDuplicata.CINCO_HORAS)
    public RelatorioAnaliseContratoVO calcular(final ParametrosCalculoGarantiaVO parametrosCalculo, RelatorioAnaliseContratoVO relatorio) {

	final GarantiaContratoCalculoTO garantiaContrato = parametrosCalculo.getGarantiaContrato();
	this.atualizarGarantiaParaCalculoAutomatico(parametrosCalculo.getCalculoAutomatico(), garantiaContrato);

	Collection<Titulo> listaDuplicatas = null;
	Integer prazoMaximo = 0;
	BigDecimal valorMaximo;
	BigDecimal percentualMaximoConcentracao;
	
	relatorio.setValorApurado(parametrosCalculo.getValorApurado());

	Collection<CedenteCalculoTO> listaCedente = garantiaContrato.getListaCedente();

	if (listaCedente.isEmpty()) {
	    if (garantiaContrato.getIcCaracteristica() != null) {
		CalculoGarantiaDuplicata.LOG.info(CalculoGarantiaDuplicata.GARANTIA_CONTRATO + garantiaContrato.getIcCaracteristica().name()
			+ " - Lista de cedentes nula ou vazia");
	    }
	} else {

	    // Obtem a quantidade de titulos existentes para os cedentes
	    Long quantidade = this.tituloDao.getQtdTitulosParaCedentes(listaCedente, garantiaContrato.getInstrucaoProtesto());

	    // Se existirem titulos então prepara os parametros para enviar para
	    // o totalizador
	    if (quantidade > 0) {

		// Obtem a data de vencimento do ultimo título dos cedentes
		Date dataUltimoTitulo = this.tituloDao.consultarDataUltimoTitulo(listaCedente, garantiaContrato.getInstrucaoProtesto());

		// Obtem a data de vencimento do titulo mais antigo dos cedentes
		Date dataTituloMaisAntigo = this.tituloDao.consultarDataTituloMaisAntigo(listaCedente, garantiaContrato.getInstrucaoProtesto());

		// Obtem a lista de feriados existentes no periodo entre a data
		// do titulo mais antigo e do ultimo titulo
		final Collection<FeriadoTO> listaFeriado = this.listaFeriadosVencimentoTitulosContrato(dataUltimoTitulo, dataTituloMaisAntigo,
			garantiaContrato.getContrato());

		// Obtem o prazo máximo parametrizado para a garantia ou o
		// parametro geral de prazo máximo
		prazoMaximo = this.consultarPrazoMaximo(garantiaContrato);

		// Obtem o valor máximo parametrizado para a garantia ou o
		// parametro geral de valor máximo
		valorMaximo = this.consultarValorMaximo(garantiaContrato);

		// Obtem o percentual máximo parametrizado para a garantia ou o
		// parametro geral de percentual máximo
		percentualMaximoConcentracao = this.consultarPercentualMaximo(garantiaContrato);

		// Obtem a sigla do estado da unidade do contrato
		String ufContrato = this.unidadeDAO.getEstadoUnidade(garantiaContrato.getContrato().getNuUnidade(),
			garantiaContrato.getContrato().getNuNatural());

		// Obtem o valor maximo sobre o percentual permitido
		BigDecimal valorTotalPermitido = this.calcularValorMaximoSobrePercentualPermitido(percentualMaximoConcentracao,
			parametrosCalculo.getValorEsperado());

		// Consulta duplicatas excepcionadas da garantia
		final Collection<DuplicataExcepcionada> listDuplicatasExcepcionadas = this.duplicataExcepcionadaDAO
			.listDuplicatasPorGarantia(garantiaContrato);

		// Consulta a quantidade de dias do parametro para inclusao em
		// caracteristica fluxo
		final Integer qtdDiasFluxo = this.consultarQtdDiasFluxo();

		// Cria o objeto de parametros necessários para realizar os
		// calculos
		ParametrosCalculoTitulo parametros = new ParametrosCalculoTitulo(relatorio, garantiaContrato, listaFeriado, prazoMaximo, ufContrato,
			valorMaximo, valorTotalPermitido, parametrosCalculo.getValorEsperado(), percentualMaximoConcentracao,
			listDuplicatasExcepcionadas, qtdDiasFluxo);

		// Cria o objeto que realiza os cálculos e faz a totalização da
		// análise do contrato
		TotalizadorTituloAnaliseContrato totalizador = new TotalizadorTituloAnaliseContrato(parametros, tituloDao, sacadoExcepcionadoDao);

		List<Thread> threads = new ArrayList<>();
		List<TotalizadorTituloAnaliseContrato> totalizadores = new ArrayList<>();

		if (quantidade > QTD_MAXIMA_CONSULTA) {

		    int qtdPorThread = quantidade.intValue() / QTD_THREADS;

		    for (int x = 0; x < QTD_THREADS; x++) {
			int offsetMin = (x * qtdPorThread);
			int offsetMax = offsetMin + qtdPorThread;
			ConsultaTitulosThread consultaTitulosThread = new ConsultaTitulosThread(offsetMin, offsetMax, QTD_MAXIMA_CONSULTA,
				totalizador, listaCedente, tituloDao);
			Thread thread = new Thread(consultaTitulosThread);
			thread.start();
			threads.add(thread);
			totalizadores.add(totalizador);

			// Cria o objeto que realiza os cálculos e faz a
			// totalização da análise do contrato
			totalizador = new TotalizadorTituloAnaliseContrato(parametros, tituloDao, sacadoExcepcionadoDao);
		    }

		    try {
			for (int x = 0; x < QTD_THREADS; x++) {
			    threads.get(x).join();
			    totalizador.somarTotalizador(totalizadores.get(x));
			}
		    } catch (InterruptedException e) {
			LOG.error(e);
			Thread.currentThread().interrupt();
			throw new SistemaException(e);
		    }
		} else {
		    listaDuplicatas = this.consultarTitulosParaCalculoDuplicata(listaCedente, 0, quantidade.intValue());

		    if (CollectionUtils.isNotEmpty(listaDuplicatas)) {
			totalizador.adicionarTitulos(listaDuplicatas);
		    }
		}

		// Totaliza, calcula e preenche a analise contrato.
		relatorio.setAnaliseContrato(totalizador.calcularAnaliseContrato());
		relatorio.setValorEsperado(parametrosCalculo.getValorEsperado());

	    } else {
		if (garantiaContrato.getIcCaracteristica() != null) {
		    CalculoGarantiaDuplicata.LOG.info(CalculoGarantiaDuplicata.GARANTIA_CONTRATO + garantiaContrato.getIcCaracteristica().name()
			    + " - Lista de duplicatas nula ou vazia");
		}
	    }
	}

	return relatorio;

    }

    /**
     * <p>
     * Método responsável por consultar o valor do prazo máximo da
     * garantiaContrato, caso o valor seja nulo, consulta os parametros do
     * sistema.
     * <p>
     *
     * @param garantiaContrato
     *            valor a ser atribuido
     * @return Integer
     * @author guilherme.santos
     */
    private Integer consultarPrazoMaximo(final GarantiaContratoCalculoTO garantiaContrato) {
	Integer prazoMaximo;
	if (garantiaContrato.getVrPrazoMaximoPermitido() != null) {
	    prazoMaximo = garantiaContrato.getVrPrazoMaximoPermitido().intValue();
	} else {
	    prazoMaximo = this.parametroCalculoDAO.obter(CalculoGarantiaDuplicata.CHAVE_PRAZO_MAXIMO_PERMITIDO).getVrParametroCalculo().intValue();
	}
	return prazoMaximo;
    }

    /**
     * <p>
     * Método responsável por consultar o valor do valor máximo da
     * garantiaContrato, caso o valor seja nulo, consulta os parametros do
     * sistema.
     * <p>
     *
     * @param garantiaContrato
     *            valor a ser atribuido
     * @return BigDecimal
     * @author guilherme.santos
     */
    private BigDecimal consultarValorMaximo(final GarantiaContratoCalculoTO garantiaContrato) {
	BigDecimal valorMaximo;
	if (garantiaContrato.getVrMaximoPermitido() != null && garantiaContrato.getVrMaximoPermitido().compareTo(BigDecimal.ZERO) > 0) {
	    valorMaximo = garantiaContrato.getVrMaximoPermitido();
	} else {
	    valorMaximo = this.parametroCalculoDAO.obter(CalculoGarantiaDuplicata.CHAVE_VALOR_MAXIMO_PERMITIDO).getVrParametroCalculo();
	}
	return valorMaximo;
    }

    /**
     * <p>
     * Método responsável por consultar o valor do percentual máximo da
     * garantiaContrato, caso o valor seja nulo, consulta os parametros do
     * sistema.
     * <p>
     *
     * @param garantiaContrato
     *            valor a ser atribuido
     * @return BigDecimal
     * @author guilherme.santos
     */
    private BigDecimal consultarPercentualMaximo(final GarantiaContratoCalculoTO garantiaContrato) {
	BigDecimal valorMaximoConcentracao;
	if (garantiaContrato.getVrPercentualMaximoCncno() != null && garantiaContrato.getVrPercentualMaximoCncno().compareTo(BigDecimal.ZERO) > 0) {
	    valorMaximoConcentracao = garantiaContrato.getVrPercentualMaximoCncno();
	} else {
	    valorMaximoConcentracao = this.parametroCalculoDAO.obter(CalculoGarantiaDuplicata.CHAVE_PERCENTUAL_MAXIMO_PERMITIDO)
		    .getVrParametroCalculo();
	}
	return valorMaximoConcentracao;
    }

    /**
     * <p>
     * Método responsável por consultar a quantidade de dias do fluxo.
     * <p>
     *
     * @return Integer
     * @author guilherme.santos
     */
    private Integer consultarQtdDiasFluxo() {
	final String prmQtdDiasFluxo = this.propriedadeDAO.getValorPropriedade("analise.carteira.duplicata.prazo.anterior", "analise.carteira");

	Integer qtdDiasFluxo = null;
	try {
	    qtdDiasFluxo = Integer.valueOf(prmQtdDiasFluxo);
	} catch (final NumberFormatException e) {
	    qtdDiasFluxo = CalculoGarantiaDuplicata.QTD_DIAS_FLUXO_PADRAO;
	}
	return qtdDiasFluxo;
    }

    /**
     * <p>
     * Método responsável por buscar a lista dos feriados no período entre o
     * vencimento do título mais antigo e o mais novo entre os títulos do
     * contrato.
     * <p>
     *
     * @param colecaoTitulos
     *            titulos em garantia para o contrato
     * @param contrato
     *            contrato que está sendo analisado
     * @return listaFeriado
     */
    private Collection<FeriadoTO> listaFeriadosVencimentoTitulosContrato(final Date dataTituloUltimo, final Date dataTituloMaisAntigo,
	    final ContratoCalculoTO contrato) {

	if (contrato == null) {
	    return new ArrayList<>();
	}

	// Consulta feriados dos titulos da carteira
	return this.feriadoDAO.consultarFeriadosEntreDatas(dataTituloMaisAntigo,
		UtilData.somarSubtrairDias(dataTituloUltimo, CalculoGarantiaDuplicata.UMA_SEMANA), contrato.getNuUnidade(), contrato.getNuNatural());
    }

    /**
     * <p>
     * Método responsável por calcular o valor máximo permitido sobre o
     * percentual máximo permitido.
     * <p>
     *
     * @param percentualMaximo
     *            valor a ser atribuido
     * @param vrEsperado
     *            valor a ser atribuido
     * @return BigDecimal
     * @author guilherme.santos
     */
    private BigDecimal calcularValorMaximoSobrePercentualPermitido(final BigDecimal percentualMaximo, final BigDecimal vrEsperado) {
	return percentualMaximo.divide(BigDecimal.valueOf(100)).multiply(vrEsperado);
    }

    /**
     * <p>
     * Método responsável por verifica se o titulo é um sacado não aceito.
     * <p>
     *
     * @param titulo
     *            valor a ser atribuido
     * @return boolean
     * @author Charles Junior, guilherme.santos
     */
    public boolean verificarTituloSacadoNaoAceito(final Titulo titulo) {
	final Sacado sacadoTitulo = titulo.getNuSacado();

	if (sacadoTitulo != null && sacadoTitulo.getIcNaoAceito()
		&& (sacadoTitulo.isAbrangenciaTodaCaixa() || this.verificarAbrangenciaCendenteTitulo(sacadoTitulo, titulo))) {
	    return titulo.getIcNaoAceito().equals(true);
	}

	return false;
    }

    /**
     * <p>
     * Método responsável por verificar se a abrangencia de sacado não aceito é
     * para o cedente do titulo informado.
     * <p>
     *
     * @param sacado
     *            valor a ser atribuido
     * @param titulo
     *            valor a ser atribuido
     * @return boolean
     * @author guilherme.santos
     */
    private boolean verificarAbrangenciaCendenteTitulo(final Sacado sacado, final Titulo titulo) {
	if (sacado.getListaCedenteNaoAceito() != null) {
	    for (final Cedente cedente : sacado.getListaCedenteNaoAceito()) {
		if (cedente.getNuCedente().equals(titulo.getIdentificadorSacado())) {
		    return true;
		}
	    }
	}

	return false;
    }

    /**
     * <p>
     * Método responsável por atualizar dados da garantia para calculo
     * automatico.
     * <p>
     *
     * @param calculoAutomatico
     *            valor a ser atribuido
     * @param garantiaContrato
     *            valor a ser atribuido
     * @author guilherme.santos
     */
    private void atualizarGarantiaParaCalculoAutomatico(final Boolean calculoAutomatico, final GarantiaContratoCalculoTO garantiaContrato) {
	if (calculoAutomatico) {
	    boolean persistir = false;
	    if (garantiaContrato.getIcCaracteristica() == null) {
		garantiaContrato.setIcCaracteristica(CaracteristicaEnum.ESTOQUE);
		persistir = true;
	    }
	    if (garantiaContrato.getIcFormaGarantia1() == null) {
		garantiaContrato.setIcFormaGarantia1(FormaGarantiaEnum.SALDO_DEVEDOR);
		persistir = true;
	    }
	    if (persistir) {
		this.garantiaContratoDao.atualizarCaracteristicaEFormaGarantia(garantiaContrato);
	    }
	}
    }

    /**
     * <p>
     * Método responsável por consultar os Titulo's informando a quantidade
     * limite de registros para o calculo da Duplicata.
     * <p>
     *
     * @param listaCedente
     *            valor a ser atribuido
     * @return Collection<Titulo>
     * @author guilherme.santos
     */
    private Collection<Titulo> consultarTitulosParaCalculoDuplicata(final Collection<CedenteCalculoTO> listaCedente, Integer inicio, Integer limite) {

	// Lista todos os titulos (duplicatas) dos cedentes
	return this.tituloDao.listarTitulosCedentes(listaCedente, inicio, limite);
    }
}