/*
 * Copyright (c) 2016 Caixa Econômica Federal. Todos os direitos
 * reservados.
 *
 * Caixa Econômica Federal - SIACG
 *
 * Este software foi desenvolvido sob demanda da CAIXA e está
 * protegido por leis de direitos autorais e tratados internacionais. As
 * condições de cópia e utilização do todo ou partes dependem de autorização da
 * pessoa. Cópias não são permitidas sem expressa autorização. Não pode ser
 * comercializado ou utilizado para propósitos particulares.
 *
 * Uso exclusivo da Caixa Econômica Federal. A reprodução ou distribuição não
 * autorizada deste programa ou de parte dele, resultará em punições civis e
 * criminais e os infratores incorrem em sanções previstas na legislação em
 * vigor.
 *
 * Histórico do Subversion:
 *
 * LastChangedRevision: $Revision$
 * LastChangedBy: $Author$
 * LastChangedDate: $Date$
 *
 * HeadURL: $HeadURL$
 *
 */
package br.gov.caixa.siacg.funcionalidade;

import java.util.Collection;
import java.util.LinkedHashMap;
import java.util.Map;

import br.gov.caixa.pedesgo.arquitetura.to.TemplateMensageriaTO;
import br.gov.caixa.pedesgo.arquitetura.util.LogCefUtil;
import br.gov.caixa.siacg.dao.OperacaoSistemaDAO;
import br.gov.caixa.siacg.model.vo.ContratoVO;
import br.gov.caixa.siacg.service.ContratoService;
import br.gov.caixa.siacg.service.DestinatarioService;

/**
 * <p>
 * NovosContratosFuncao
 * </p>
 * <p>
 * Descrição: Classe de função para traduzir parametros para envio de email para
 * novos contratos.
 * </p>
 * <br>
 * <b>Empresa:</b> Cef - Caixa Econômica Federal
 *
 * @author Bruno Martins de Carvalho
 * @version 1.0
 */
public class GarantiasNaoParametrizadasFuncionalidade extends FuncionalidadeImplementacao {

    /** Atributo NOME. */
    public static final String NOME = "garantias_nao_parametrizadas";
    /** Atributo NOME_OPCIONAL. */
    public static final String NOME_OPCIONAL = "garantiasNaoParametrizadas";
    /** Atributo DESCRICAO. */
    private static final String DESCRICAO = "Funcao de garantias mão parametrizadas.";

    /** Atributo operacaoSistemaDAO. */
    private final OperacaoSistemaDAO operacaoSistemaDAO;

    /** Atributo contratoService. */
    private final ContratoService contratoService;

    /** Atributo destinatarioService. */
    private DestinatarioService destinatarioService;

    /**
     * Retorna o valor do atributo operacaoSistemaDAO.
     *
     * @return operacaoSistemaDAO
     */
    @Override
    public OperacaoSistemaDAO getOperacaoSistemaDAO() {
        return this.operacaoSistemaDAO;
    }

    /**
     * Retorna o valor do atributo destinatarioService.
     *
     * @return destinatarioService
     */
    @Override
    public DestinatarioService getDestinatarioService() {
        return this.destinatarioService;
    }

    /**
     * Construtor.
     *
     * @param contratoService
     *            valor a ser atribuido
     * @param destinatarioService
     *            valor a ser atribuido
     * @param operacaoSistemaDAO
     *            valor a ser atribuido
     */
    public GarantiasNaoParametrizadasFuncionalidade(final ContratoService contratoService, final DestinatarioService destinatarioService,
            final OperacaoSistemaDAO operacaoSistemaDAO) {
        this.contratoService = contratoService;
        this.destinatarioService = destinatarioService;
        this.operacaoSistemaDAO = operacaoSistemaDAO;
    }

    /**
     * @see br.gov.caixa.siacg.funcionalidade.FuncionalidadeImplementacao#getNome()
     */
    @Override
    public String getNome() {
        return GarantiasNaoParametrizadasFuncionalidade.NOME;
    }

    /**
     * @see br.gov.caixa.siacg.funcionalidade.FuncionalidadeImplementacao#getNomeOpcional()
     */
    @Override
    public String getNomeOpcional() {
        return GarantiasNaoParametrizadasFuncionalidade.NOME_OPCIONAL;
    }

    /**
     * @see br.gov.caixa.siacg.funcionalidade.FuncionalidadeImplementacao#getDescricao()
     */
    @Override
    public String getDescricao() {
        return GarantiasNaoParametrizadasFuncionalidade.DESCRICAO;
    }

    /**
     * @see br.gov.caixa.siacg.funcionalidade.IFuncionalidade#traduzirTemplate(br.gov.caixa.pedesgo.arquitetura.comum.to.TemplateMensageriaTO)
     */
    @Override
    public Collection<TemplateMensageriaTO> traduzirTemplate(final TemplateMensageriaTO templateMensageriaTO) {

        LogCefUtil.info("Buscando contratos não parametrizados... ");
        final Collection<ContratoVO> listaContrato = this.contratoService.listarContratosNaoParametrizados();
        LogCefUtil.info("Término da busca de contratos não parametrizados... ");

        final Map<Integer, TemplateMensageriaTO> mapaTemplates = new LinkedHashMap<>();

        if (!listaContrato.isEmpty()) {
            LogCefUtil.info("Inicio Tradução Template... ");
            mapaTemplates.putAll(this.agruparContratos(listaContrato, templateMensageriaTO));
            LogCefUtil.info("Fim Tradução Template... ");
        }

        return mapaTemplates.values();
    }
}
