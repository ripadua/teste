/**
 * Copyright (c) 2013 Caixa Econômica Federal. Todos os direitos
 * reservados.
 *
 * Caixa Econômica Federal - SIACG - Sistema de Crédito Rural
 *
 * Este software foi desenvolvido sob demanda da CAIXA e está
 * protegido por leis de direitos autorais e tratados internacionais. As
 * condições de cópia e utilização do todo ou partes dependem de autorização da
 * pessoa. Cópias não são permitidas sem expressa autorização. Não pode ser
 * comercializado ou utilizado para propósitos particulares.
 *
 * Uso exclusivo da Caixa Econômica Federal. A reprodução ou distribuição não
 * autorizada deste programa ou de parte dele, resultará em punições civis e
 * criminais e os infratores incorrem em sanções previstas na legislação em
 * vigor.
 *
 * Histórico do Subversion:
 *
 * LastChangedRevision: $Revision$
 * LastChangedBy: $Author$
 * LastChangedDate: $Date$
 *
 * HeadURL: $HeadURL$
 *
 */
package br.gov.caixa.siacg.view.form;

import java.util.ArrayList;
import java.util.Collection;

import br.gov.caixa.siacg.model.domain.Mensagem;

/**
 * <p>
 * LoginVisao
 * </p>
 * <p>
 * Descrição: Classe de visão do login.
 * </p>
 * <br>
 * <b>Empresa:</b> Cef - Caixa Econômica Federal
 *
 * @author Waltenes Junior
 * @version 1.0
 */
public class LoginVisao extends TemplateVisao<Mensagem> {

    private static final long serialVersionUID = 3430660501444995025L;

    private Collection<Mensagem> listaMensagens;

    private Mensagem mensagem;

    private String descricaoMensagem;

    /**
     * Retorna o valor do atributo listaMensagens.
     *
     * @return listaMensagens
     */
    public Collection<Mensagem> getListaMensagens() {
        if (this.listaMensagens == null) {
            this.listaMensagens = new ArrayList<>();
        }
        return this.listaMensagens;
    }

    /**
     * Define o valor do atributo listaMensagens.
     *
     * @param listaMensagens
     *            valor a ser atribuído
     */
    public void setListaMensagens(final Collection<Mensagem> listaMensagens) {
        this.listaMensagens = listaMensagens;
    }

    /**
     * Retorna o valor do atributo descricaoMensagem.
     *
     * @return descricaoMensagem
     */
    public String getDescricaoMensagem() {
        return this.descricaoMensagem;
    }

    /**
     * Define o valor do atributo descricaoMensagem.
     *
     * @param descricaoMensagem
     *            valor a ser atribuído
     */
    public void setDescricaoMensagem(final String descricaoMensagem) {
        this.descricaoMensagem = descricaoMensagem;
    }

    /**
     * Retorna o valor do atributo mensagem.
     *
     * @return mensagem
     */
    public Mensagem getMensagem() {

        return this.mensagem;
    }

    /**
     * Define o valor do atributo mensagem.
     *
     * @param mensagem
     *            valor a ser atribuído
     */
    public void setMensagem(final Mensagem mensagem) {

        this.mensagem = mensagem;
    }
}
