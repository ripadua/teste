/**
 *
 * Caixa Econômica Federal - SIACG – Sistema de Acompanhamento de Carteiras de Cobrança
 *
 * Este programa de computador foi desenvolvido sob demanda da CAIXA e está protegido por leis de direitos autorais e
 * tratados internacionais. As condições de cópia e utilização do todo ou partes dependem de autorização da pessoa.
 * Cópias não são permitidas sem expressa autorização. Não pode ser comercializado ou utilizado para propósitos
 * particulares.
 *
 * Uso exclusivo da Caixa Econômica Federal. A reprodução ou distribuição não autorizada deste programa ou de parte
 * dele, resultará em punições civis e criminais e os infratores incorrem em sanções previstas na legislação em vigor.
 *
 * Histórico do Subversion:
 *
 * LastChangedRevision: LastChangedBy: LastChangedDate:
 *
 * HeadURL:
 *
 */
package br.gov.caixa.siacg.view.mb;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.Date;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import javax.ejb.EJB;
import javax.enterprise.context.SessionScoped;
import javax.faces.bean.ManagedProperty;
import javax.faces.context.FacesContext;
import javax.inject.Inject;
import javax.inject.Named;

import org.apache.commons.collections.CollectionUtils;

import br.gov.caixa.pedesgo.arquitetura.controlador.ManutencaoBean;
import br.gov.caixa.pedesgo.arquitetura.enumerador.EnumAcao;
import br.gov.caixa.pedesgo.arquitetura.enumerador.EnumNomeAbrangenciaRestritaUnidade;
import br.gov.caixa.pedesgo.arquitetura.enumerador.EnumTipoAbrangencia;
import br.gov.caixa.pedesgo.arquitetura.enums.EnumExtensaoArquivo;
import br.gov.caixa.pedesgo.arquitetura.relatorio.UtilRelatorio;
import br.gov.caixa.pedesgo.arquitetura.to.MensagemTO;
import br.gov.caixa.pedesgo.arquitetura.util.LogCefUtil;
import br.gov.caixa.pedesgo.arquitetura.util.MensagensUtil;
import br.gov.caixa.pedesgo.arquitetura.util.UsuarioUtil;
import br.gov.caixa.pedesgo.arquitetura.util.UtilFormatacao;
import br.gov.caixa.pedesgo.arquitetura.util.UtilObjeto;
import br.gov.caixa.pedesgo.arquitetura.util.UtilString;
import br.gov.caixa.siacg.comparator.NumeroContaFormatadoComparator;
import br.gov.caixa.siacg.comum.to.ContaSid09TO;
import br.gov.caixa.siacg.comum.to.ContratoTO;
import br.gov.caixa.siacg.comum.to.RetornoSid09TO;
import br.gov.caixa.siacg.comum.to.sicli.RespostaSicliTO;
import br.gov.caixa.siacg.dao.ProdutoDAO;
import br.gov.caixa.siacg.exception.ParametrosInvalidosException;
import br.gov.caixa.siacg.exception.SaldoWSexception;
import br.gov.caixa.siacg.interceptador.Auditoria;
import br.gov.caixa.siacg.interceptador.OperacaoAuditoria;
import br.gov.caixa.siacg.jms.SolicitaDadosClienteSicli;
import br.gov.caixa.siacg.jms.SolicitaDadosSID09;
import br.gov.caixa.siacg.model.domain.BemCliente;
import br.gov.caixa.siacg.model.domain.Cedente;
import br.gov.caixa.siacg.model.domain.ContaContrato;
import br.gov.caixa.siacg.model.domain.Contrato;
import br.gov.caixa.siacg.model.domain.Empreendimento;
import br.gov.caixa.siacg.model.domain.GarantiaBemCliente;
import br.gov.caixa.siacg.model.domain.GarantiaCartaoCredito;
import br.gov.caixa.siacg.model.domain.GarantiaContrato;
import br.gov.caixa.siacg.model.domain.OperacaoSistema;
import br.gov.caixa.siacg.model.domain.Pessoa;
import br.gov.caixa.siacg.model.domain.Produto;
import br.gov.caixa.siacg.model.domain.ProdutoAgricola;
import br.gov.caixa.siacg.model.domain.Segmento;
import br.gov.caixa.siacg.model.domain.Tipologia;
import br.gov.caixa.siacg.model.domain.Unidade;
import br.gov.caixa.siacg.model.enums.ContaEnum;
import br.gov.caixa.siacg.model.enums.GrupoGarantiaEnum;
import br.gov.caixa.siacg.model.enums.NoFuncionalidadeEnum;
import br.gov.caixa.siacg.model.enums.OrigemParametrizacaoEnum;
import br.gov.caixa.siacg.model.enums.SituacaoEndividamentoEnum;
import br.gov.caixa.siacg.model.enums.TipoEndividamentoEnum;
import br.gov.caixa.siacg.model.enums.TipoOrigemContaContratoEnum;
import br.gov.caixa.siacg.model.json.saldows.RetornoAplicacaoSifix;
import br.gov.caixa.siacg.model.vo.ContratoParametrizadoVO;
import br.gov.caixa.siacg.model.vo.ParametrizacaoContratoVO;
import br.gov.caixa.siacg.model.vo.SrVO;
import br.gov.caixa.siacg.model.vo.UnidadeVO;
import br.gov.caixa.siacg.pagination.ContratoInativoLazyModel;
import br.gov.caixa.siacg.pagination.ContratoLazyModel;
import br.gov.caixa.siacg.service.AplicacaoFinanceiraService;
import br.gov.caixa.siacg.service.BemClienteService;
import br.gov.caixa.siacg.service.ContratoService;
import br.gov.caixa.siacg.service.DWAnaliseContratoService;
import br.gov.caixa.siacg.service.GarantiaBemClienteService;
import br.gov.caixa.siacg.service.OperacaoSistemaService;
import br.gov.caixa.siacg.service.PessoaService;
import br.gov.caixa.siacg.service.PropriedadeService;
import br.gov.caixa.siacg.service.UnidadeService;
import br.gov.caixa.siacg.service.UnidadeVinculadaSuatService;
import br.gov.caixa.siacg.util.ContratoUtil;
import br.gov.caixa.siacg.util.LogCEF;
import br.gov.caixa.siacg.util.NumeroUtil;
import br.gov.caixa.siacg.view.form.ContratoVisao;

/**
 * <p>
 * ContratoMB.
 * </p>
 * <p>
 * Descrição: Managed bean do caso de uso <code> Pesquisa contrato </code>
 * </p>
 * <br>
 * <b>Empresa:</b> Cef - Caixa Econômica Federal
 *
 * @author Waltenes junior
 * @version 1.0
 */
@Named
@SessionScoped
public class ContratoMB extends ManutencaoBean<Contrato> {

	private static final long serialVersionUID = -6553087114236321181L;

	/** Atributo NOME_MANAGED_BEAN. */
	public static final String NOME_MANAGED_BEAN = "contratoMB";

	/** Atributo EL_MANAGED_BEAN. */
	public static final String EL_MANAGED_BEAN = "#{contratoMB}";

	/** Atributo PAGINA_CONSULTA_CONTRATO. */
	private static final String PAGINA_CONSULTA_CONTRATO = "/pages/contrato/consulta.xhtml?faces-redirect=true";

	/** Atributo PAGINA_INCLUSAO_CONTRATO. */
	private static final String PAGINA_INCLUSAO_CONTRATO = "/pages/contrato/edicao.xhtml?faces-redirect=true";

	/** Atributo IMAGEM_CAIXA_LOGO. */
	private static final String IMAGEM_CAIXA_LOGO = "/resources/img/caixa_logo.jpg";

	/** Atributo CAMINHO_RELATORIO. */
	private static final String CAMINHO_RELATORIO = "/reports/";

	/** Atributo NOME_JASPER_CONTRATOS. */
	private static final String NOME_JASPER_CONTRATOS = "contratos.jasper";

	/** Atributo NOME_RELATORIO_CONTRATOS. */
	private static final String NOME_RELATORIO_CONTRATOS = "Contratos";

	private static final String PESSOA_JURIDICA = "PJ";

	private static final String MSG_APP = "msgApp";
	
	public static final String OPERACAO_REALIZADA_ERRO = "MA012";
	
	public static final String CONTRATO_INCLUIDO_SUCESSO = "MA015";
	
	public static final String CLIENTE_NAO_ENCONTRADO = "MA017";
	
	private static final String UNIDADE = "unidade";

	private static final Integer HIERARQUIA=1;

	/** Atributo consulta. */
	@Inject
	private ContratoLazyModel consulta;
	
	@Inject
	private ContratoInativoLazyModel contratosInativos;

	/** Atributo parametrizacaoContratoMB. */
	@Inject
	private ParametrizacaoContratoMB parametrizacaoContratoMB;
	
	/** Atributo desbloqueioGarantiaMB. */
	@ManagedProperty(value = DesbloqueioGarantiaMB.EL_MANAGED_BEAN)
	private DesbloqueioGarantiaMB desbloqueioGarantiaMB;
	
	/** Atributo visao. */
	private transient ContratoVisao visao;

	/** Atributo service. */
	@EJB
	private transient ContratoService service;

	@EJB
	private transient ProdutoDAO produtoDAO;

	/** Atributo solicitaDadosClienteSicli. */
	@EJB
	private SolicitaDadosClienteSicli solicitaDadosClienteSicli;

	/** Atributo pessoaService. */
	@EJB
	private PessoaService pessoaService;

	@EJB
	private transient OperacaoSistemaService operacaoSistemaService;

	@EJB
	private UnidadeService unidadeService;

	/** Atributo solicitaDadosSID09. */
	@EJB
	private SolicitaDadosSID09 solicitaDadosSID09;

	@EJB
	private AplicacaoFinanceiraService aplicacaoFinanceiraService;
	
	@EJB
	private BemClienteService bemClienteService;
	
	@EJB
	private GarantiaBemClienteService garantiaBemClienteService;
	
	@Inject
    private PropriedadeService propriedadeService;
    
    @Inject
    private DWAnaliseContratoService dwAnaliseContratoService;
    
    @Inject
    private UnidadeVinculadaSuatService unidadeVinculadaSuatService;
    
	/**
	 * @see br.gov.caixa.pedesgo.arquitetura.controlador.AbstractBean#carregar()
	 */
	@Override
	public void carregar() {

		this.visao = null;
		
		configurarPermissao();
    	carregarListaUnidades();
	}

	/**
	 * <p>
	 * Método responsável por exportar xls.
	 * <p>
	 */
	public void exportarXLSContratoParametrizado() {
		final Map<String, Object> parametros = new LinkedHashMap<>();

		parametros.put("LOGO_CAIXA", super.getExternalContext().getResourceAsStream(ContratoMB.IMAGEM_CAIXA_LOGO));
		parametros.put("MATRICULA_USUARIO", super.getMatriculaUsuario());

		try {

			UtilRelatorio.getInstancia().addCaminhoRelatorio(ContratoMB.CAMINHO_RELATORIO + ContratoMB.NOME_JASPER_CONTRATOS)
					.addColecao(getService().listarContratoPorFiltroSelecionado(this.consulta.getFiltro()))
					.addExtensaoArquivo(EnumExtensaoArquivo.XLS).addNomeRelatorio(ContratoMB.NOME_RELATORIO_CONTRATOS).addParametros(parametros)
					.addResposta(super.getResponse()).gerarRelatorio();

		} catch (final Exception e) {
			LogCefUtil.error("Não foi possivel gerar o XLS: " + e.getMessage());
			LogCefUtil.error(e);
		}
	}

	/**
	 * <p>
	 * Método responsável por abrir a pagina de consulta do contrato.
	 * <p>
	 *
	 * @return String
	 * @author Waltenes junior
	 */
	public String abrirConsulta() {
		this.getVisao().setSuatSelecionada(null);
		this.getVisao().setSrSelecionada(null);
		this.getVisao().setUnidadeSelecionada(null);
		this.carregar();
		this.consulta.limparFiltro();
		this.contratosInativos.limparFiltro();
		this.restricaoAbrangencia();
		return ContratoMB.PAGINA_CONSULTA_CONTRATO;
	}

	public String abrirInclusao() {
		this.getVisao().setEntidade(new Contrato());
		if (this.getVisao().getListaProduto().isEmpty()) {
			this.visao.setListaProduto((List<Produto>) this.produtoDAO.listarOperacoesProduto());
		}
		if (this.getVisao().getListaUnidadeContrato().isEmpty()) {
			this.getVisao().setListaUnidadeContrato(unidadeService.listarUnidadesSrAg());
		}
		return ContratoMB.PAGINA_INCLUSAO_CONTRATO;
	}

	/**
	 * <p>
	 * Método responsável por executar a consulta do contrato.
	 * <p>
	 *
	 * @return String
	 * @author Leandro Severino - lseverino@gmail.com
	 */
	public String executarConsulta() {
		return ContratoMB.PAGINA_CONSULTA_CONTRATO;
	}

	/**
	 * <p>
	 * Método responsável por abrir a tela de edição da parametrização do
	 * contrato.
	 * <p>
	 *
	 * @param contratoParametrizadoVO
	 *            valor a ser atribuído
	 * @return String
	 * @author guilherme.santos
	 */
	@Auditoria()
	@OperacaoAuditoria(acao = "ABRIR_EDICAO_PARAMETRO_CONTRATO", parametros = {"contrato"})
	public String editarParamentrizacao(final ContratoParametrizadoVO contratoParametrizadoVO) {
		return this.abrirParametrizacao(contratoParametrizadoVO);
	}

	/**
	 * <p>
	 * Método responsável por abrir parametrização contrato.
	 * <p>
	 *
	 * @param contrato
	 *            valor a ser atribuído
	 * @return String
	 * @author guilherme.santos
	 */
	@Auditoria()
	@OperacaoAuditoria(acao = "ABRIR_EDICAO_PARAMETRO_CONTRATO", parametros = {"contrato"})
	public String abrirParametrizacao(final Contrato contrato) {
		return this.processarParametrizacao(contrato, OrigemParametrizacaoEnum.CADASTRO_CONTRATO);
	}

	/**
	 * <p>
	 * Método responsável por abrir parametrização contrato.
	 * <p>
	 *
	 * @param contratoParametrizadoVO
	 *            valor a ser atribuído
	 * @return String
	 * @author Waltenes Junior, guilherme.santos
	 */
	public String abrirParametrizacao(final ContratoParametrizadoVO contratoParametrizadoVO) {
		final Contrato contrato = new Contrato();

		contrato.setNuContrato(contratoParametrizadoVO.getNuContrato());

		return this.processarParametrizacao(contrato, OrigemParametrizacaoEnum.ANALISE_GARANTIA);
	}

	/**
	 * <p>
	 * Método responsável por processa os dados para abertura da tela de
	 * parametrização do contrato.
	 * <p>
	 *
	 * @param contrato
	 *            valor a ser atribuído
	 * @return String
	 * @author guilherme.santos
	 */
	private String processarParametrizacao(Contrato contrato, OrigemParametrizacaoEnum origemParametrizacao) {

	final Collection<ParametrizacaoContratoVO> listaParametrizacao = new ArrayList<>();

	contrato = this.service.obterContratoComRelacionamentosInicializados(contrato.getNuContrato());

		if (contrato.isContratoHabitacional() && contrato.getEmpreendimento() == null) {
			Empreendimento empreendimento = new Empreendimento();
			empreendimento.setDtFimEmpreendimento(null);
			empreendimento.setVrEsperadoHipoteca(null);
			empreendimento.setVrEsperadoRecebivel(null);
			contrato.setEmpreendimento(empreendimento);
		}

		for (final GarantiaContrato garantiaContrato : contrato.getGarantiaContratoList()) {
			
			final ParametrizacaoContratoVO parametrizacaoContratoVO = new ParametrizacaoContratoVO();

			
			if (garantiaContrato.isGarantiaImovel() && CollectionUtils.isNotEmpty(garantiaContrato.getBens())) {
				for (GarantiaBemCliente gbc : garantiaContrato.getBens()) {
					gbc.setIcMarcado(Boolean.TRUE);
					gbc.setVrUtilizadoOutrasGarantias(garantiaBemClienteService.getValorUtilizado(gbc));
				}
			} else {
				garantiaContrato.setBemCliente(garantiaContrato.getBens().isEmpty() ? new BemCliente()
						: this.bemClienteService.obter(garantiaContrato.getBens().iterator().next().getBemCliente().getNuBemCliente()));
			}
			
			
			garantiaContrato.setProdutoAgricola(garantiaContrato.getListGarantiaProdAgricola().isEmpty() ? new ProdutoAgricola()
					: garantiaContrato.getListGarantiaProdAgricola().iterator().next().getGarantiaProdutoAgricolaID().getProdutoAgricola());
	
			
			if (garantiaContrato.isGarantiaCartaoCredito() && CollectionUtils.isNotEmpty(garantiaContrato.getListaGarantiaCartaoCredito())) {
				for (GarantiaCartaoCredito gcc : garantiaContrato.getListaGarantiaCartaoCredito()) {
					gcc.setIcMarcado(Boolean.TRUE);
				}
			}
			
			if(!garantiaContrato.getListGarantiaAplicacao().isEmpty()
					|| garantiaContrato.getGarantia().getGrupoGarantia().getNuGrupoGarantia() == GrupoGarantiaEnum.APLICACAO_FINANCEIRA.getCodigo()) {
					try {
						List<RetornoAplicacaoSifix> listaSaldoAplicacao = this.aplicacaoFinanceiraService.consultarSaldoAplicacaoSifixCpfCnpj(contrato.getNuPessoa().getNuCnpj());
						if(!listaSaldoAplicacao.isEmpty()) {
							this.aplicacaoFinanceiraService.salvarAplicacaoSifixEmLote(listaSaldoAplicacao);
						}
						else {
							LogCefUtil.info("sem retorno do sifix ou lista vazia");	
						}
					} catch (SaldoWSexception e) {
						LogCefUtil.error("Error ao tentar atualizar/inserir aplicacoes sifix: " + e);
					}	
				}
			
			if (garantiaContrato.getDtParametrizacaoManual() == null) {

				if (contrato.getDtUltParametrizacaoManual() != null) {

					garantiaContrato.setDtParametrizacaoManual(contrato.getDtUltParametrizacaoManual());

				} else {

					garantiaContrato.setDtParametrizacaoManual(new Date());

				}

			}

			parametrizacaoContratoVO.setGarantiaContrato(garantiaContrato);
			parametrizacaoContratoVO.setCedenteList(new ArrayList<Cedente>(garantiaContrato.getCedenteList()));
			parametrizacaoContratoVO.setCoResponsavel(UsuarioUtil.getUsuarioLogado().getDeMatricula());

			listaParametrizacao.add(parametrizacaoContratoVO);
		}

		this.parametrizacaoContratoMB.getVisao().setListaTipologia(new ArrayList<Tipologia>());

		this.parametrizacaoContratoMB.getVisao()
				.setListaContaContrato((ArrayList<ContaContrato>) this.filtrarListaContaContratoParaContrato(contrato.getContaContratoList()));
		this.parametrizacaoContratoMB.getVisao()
				.setListaContaContratoCheque((ArrayList<ContaContrato>) this.service.filtrarListaContaContratoParaCheque(contrato.getContaContratoList()));
		this.parametrizacaoContratoMB.getVisao()
				.setListaContaContratoCartao(((ArrayList<ContaContrato>) this.filtrarListaContaContratoParaCartao(contrato.getContaContratoList())));
		// Ordenar lista de ContaContrato pro numero da conta formatado
		Collections.sort(this.parametrizacaoContratoMB.getVisao().getListaContaContrato(), new NumeroContaFormatadoComparator());

		this.parametrizacaoContratoMB.getContaCorrenteCartaoMB().getVisao().getListaContaCorrenteBandeiras().clear();

		this.parametrizacaoContratoMB.getVisao().setParametrizacaoList(listaParametrizacao);
		this.parametrizacaoContratoMB.getVisao().setListaExclusaoParametrizacao(new ArrayList<ParametrizacaoContratoVO>());
		this.parametrizacaoContratoMB.popularComboGarantia();
		this.parametrizacaoContratoMB.limparDadosParametrizacao();
		this.parametrizacaoContratoMB.ocultarCampos(false);
		this.parametrizacaoContratoMB.desabilitarCampos(false);
		this.parametrizacaoContratoMB.getVisao().setExibirCamposEdicao(false);
		this.parametrizacaoContratoMB.getVisao().setDesabilitarComboGarantia(false);
		this.parametrizacaoContratoMB.getVisao().setContratoSelecionadoHabitacional(false);
		this.parametrizacaoContratoMB.getVisao().setGarantiaPassouSerAcompanhada(true);
		return this.parametrizacaoContratoMB.parametrizarContrato(contrato, origemParametrizacao);
	}

	/**
	 * <p>
	 * Método responsável por filtrar conta contrato para visualização no
	 * contrato.
	 * <p>
	 *
	 * @param listaSemTratamento
	 *            valor a ser atribuído
	 * @author guilherme.santos
	 * @return Collection<ContaContrato>
	 */
	private Collection<ContaContrato> filtrarListaContaContratoParaContrato(final Collection<ContaContrato> listaSemTratamento) {
		final Collection<ContaContrato> listaTratada = new ArrayList<>();
		this.parametrizacaoContratoMB.getVisao().setNuContaCorrenteNaoLivreMovimentacao(null);
		for (final ContaContrato contaContrato : listaSemTratamento) {
			if (this.verificarSeOrigemEhContratoOuImportado(contaContrato)) {
				listaTratada.add(contaContrato);
			}
			// Atribui o valor da conta corrente do tipo NORMAL no contrato
			if (contaContrato.getIcConta() != null && contaContrato.getIcConta().equals(ContaEnum.CONTA_PRINCIPAL)) {
				this.parametrizacaoContratoMB.getVisao().setNuContaCorrenteNaoLivreMovimentacao(contaContrato.getNuConta().getNumeroContaFormatado());
			}
		}
		return listaTratada;
	}

	/**
	 * <p>
	 * Método responsável por filtrar conta contrato para visualização na
	 * Garantia Cartao.
	 * <p>
	 *
	 * @param listaSemTratamento
	 *            valor a ser atribuído
	 * @author guilherme.santos
	 * @return Collection<ContaContrato>
	 */
	private Collection<ContaContrato> filtrarListaContaContratoParaCartao(final Collection<ContaContrato> listaSemTratamento) {
		final Collection<ContaContrato> listaTratada = new ArrayList<>();
		for (final ContaContrato contaContrato : listaSemTratamento) {
			if (this.verificarSeOrigemEhCartaoOuImportado(contaContrato)) {
				listaTratada.add(contaContrato);
			}
		}
		return listaTratada;
	}

	/**
	 * <p>
	 * Método responsável por verificar se a origem é do contrato ou importado.
	 * <p>
	 *
	 * @param contaContrato
	 *            valor a ser atribuído
	 * @return boolean
	 * @author guilherme.santos
	 */
	private boolean verificarSeOrigemEhContratoOuImportado(final ContaContrato contaContrato) {
		return contaContrato.getIcOrigem() == null || contaContrato.getIcOrigem().equals(TipoOrigemContaContratoEnum.CONTRATO)
				|| contaContrato.getIcOrigem().equals(TipoOrigemContaContratoEnum.IMPORTADO);
	}

	/**
	 * <p>
	 * Método responsável por verificar se a origem é de Cartão ou importado.
	 * <p>
	 *
	 * @param contaContrato
	 *            valor a ser atribuído
	 * @return boolean
	 * @author guilherme.santos
	 */
	private boolean verificarSeOrigemEhCartaoOuImportado(final ContaContrato contaContrato) {
		return contaContrato.getIcOrigem() == null || contaContrato.getIcOrigem().equals(TipoOrigemContaContratoEnum.CARTAO_CREDITO)
				|| contaContrato.getIcOrigem().equals(TipoOrigemContaContratoEnum.IMPORTADO);
	}

	/**
	 * <p>
	 * Método responsável por atribuir a restrição sobre a abrangência do
	 * usuário logado.
	 * <p>
	 *
	 * @author Waltenes Junior
	 */
	private void restricaoAbrangencia() {
		if (UsuarioUtil.contemPermissao(NoFuncionalidadeEnum.PARAMETRIZA_CONTRATO.getNoFuncionalidade(), EnumAcao.INCLUIR.getNoAcao(), null, null)
				|| UsuarioUtil.contemPermissao(NoFuncionalidadeEnum.PARAMETRIZA_CONTRATO.getNoFuncionalidade(), EnumAcao.ALTERAR.getNoAcao(), null,
						null)) {

			this.getVisao().setRestricaoAbangencia(true);
		}
	}

	/**
	 * @see br.gov.caixa.pedesgo.arquitetura.controlador.AbstractBean#getService()
	 */
	@SuppressWarnings("unchecked")
	@Override
	public ContratoService getService() {
		return this.service;
	}

	/**
	 * Retorna o valor do atributo visao.
	 *
	 * @return visao
	 */
	@Override
	public ContratoVisao getVisao() {

		if (!UtilObjeto.isReferencia(this.visao)) {

			this.visao = new ContratoVisao();
		}

		return this.visao;
	}

	/**
	 * Retorna o valor do atributo consulta.
	 *
	 * @return consulta
	 */
	public ContratoLazyModel getConsulta() {
		if (this.consulta == null) {
			this.consulta = new ContratoLazyModel();
		}

		return this.consulta;
	}

	/**
	 * Define o valor do atributo consulta.
	 *
	 * @param consulta
	 *            valor a ser atribuído
	 */
	public void setConsulta(final ContratoLazyModel consulta) {
		this.consulta = consulta;
	}

	/**
	 * Retorna o valor do atributo parametrizacaoContratoMB.
	 *
	 * @return parametrizacaoContratoMB
	 */
	public ParametrizacaoContratoMB getParametrizacaoContratoMB() {
		return this.parametrizacaoContratoMB;
	}

	/**
	 * Define o valor do atributo parametrizacaoContratoMB.
	 *
	 * @param parametrizacaoContratoMB
	 *            valor a ser atribuído
	 */
	public void setParametrizacaoContratoMB(final ParametrizacaoContratoMB parametrizacaoContratoMB) {
		this.parametrizacaoContratoMB = parametrizacaoContratoMB;
	}
	
	/**
	 * <p>Retorna o valor do atributo desbloqueioGarantiaMB</p>.
	 *
	 * @return desbloqueioGarantiaMB
	*/
	public DesbloqueioGarantiaMB getDesbloqueioGarantiaMB() {
	    return this.desbloqueioGarantiaMB;
	}

	/**
	 * <p>Define o valor do atributo desbloqueioGarantiaMB</p>.
	 *
	 * @param desbloqueioGarantiaMB valor a ser atribuído
	*/
	public void setDesbloqueioGarantiaMB(final DesbloqueioGarantiaMB desbloqueioGarantiaMB) {
	    this.desbloqueioGarantiaMB = desbloqueioGarantiaMB;
	}

	/**
	 * @see br.gov.caixa.pedesgo.arquitetura.controlador.AbstractBean#getNomeVarResourceBundle()
	 */
	@Override
    protected String getNomeVarResourceBundle() {
		return "msgApp";
    }

	/**
	 * @see br.gov.caixa.pedesgo.arquitetura.controlador.AbstractBean#getPrefixoCasoDeUso()
	 */
	@Override
	public String getPrefixoCasoDeUso() {
		return null;

	}

	/**
	 * <p>
	 * Realiza a ordenação por situação de contrato.
	 * <p>
	 *
	 * @param contrato1
	 *            valor a ser atribuído
	 * @param contrato2
	 *            valor a ser atribuído
	 * @return int
	 * @author Ricardo Crispim
	 */
	public int ordenarPorSituacao(final Contrato contrato1, final Contrato contrato2) {
		if (contrato1.getGarantiaContratoList().size() > contrato2.getGarantiaContratoList().size()) {
			return 1;
		} else if (contrato1.getGarantiaContratoList().size() == contrato2.getGarantiaContratoList().size()) {
			return 0;
		} else {
			return -1;
		}
	}
	
	private void carregarListaUnidades() {
		List<UnidadeVO> listaDires = new ArrayList<>();
		
		Integer tipoConfig = HIERARQUIA; 
		Integer unidadeGestora = null; 
		try {
			List<Integer> codigos = new ArrayList<>();
			String dados = propriedadeService.getPropriedadeBanco("unidade.lista", UNIDADE);
			tipoConfig = Integer.parseInt(propriedadeService.getPropriedadeBanco("unidade.tipoconfig", UNIDADE));
			unidadeGestora = Integer.parseInt(this.propriedadeService.getPropriedadeBanco("unidade.unidadeGestora", UNIDADE));
			String[] lista = dados.split(";");
			for (String item : lista) {
				codigos.add(Integer.parseInt(item));
			}
			
			listaDires = new ArrayList<>(unidadeVinculadaSuatService.listarDiresPorCodigo(codigos));
		} catch (ParametrosInvalidosException e) {
			LogCEF.error("Erro ao carregar propriedades de unidades. Detalhes: ");
			LogCEF.error(e);
		}
			
		this.getVisao().setListaDires(listaDires);
		this.getVisao().setTipoConfig(tipoConfig);
		this.getVisao().setUnidadeGestoraProcesso(unidadeGestora);
	}

	private void configurarPermissao() {
		final FacesContext contexto = FacesContext.getCurrentInstance();

		if (UtilObjeto.isReferencia(contexto)) {
			final String unidadeUsuario = super.getUnidadeUsuario();

			if (!UtilString.isVazio(unidadeUsuario)) {

				final Integer nuUnidadeusuarioLogado = Integer.valueOf(unidadeUsuario);

				if (UtilObjeto.isReferencia(nuUnidadeusuarioLogado)) {
					if (UsuarioUtil.contemPermissao(NoFuncionalidadeEnum.CONSULTA_UNIDADE.getNoFuncionalidade(), EnumAcao.CONSULTAR.getNoAcao(),
							EnumTipoAbrangencia.RESTRITA_UNIDADE.getTipoAbrangencia(),
							EnumNomeAbrangenciaRestritaUnidade.TODAS.getNomeAbrangencia())) {

						getVisao().setHabilitarSuat(Boolean.FALSE);
						getVisao().setHabilitarSr(Boolean.FALSE);
					    getVisao().setHabilitarUnidade(Boolean.FALSE);
					} else if (UsuarioUtil.contemPermissao(NoFuncionalidadeEnum.CONSULTA_UNIDADE.getNoFuncionalidade(),
							EnumAcao.CONSULTAR.getNoAcao(), EnumTipoAbrangencia.RESTRITA_UNIDADE.getTipoAbrangencia(),
							EnumNomeAbrangenciaRestritaUnidade.VINCULADAS.getNomeAbrangencia())) {

						getVisao().setHabilitarSuat(Boolean.TRUE);
						getVisao().setHabilitarSr(Boolean.TRUE);
						getVisao().setHabilitarUnidade(Boolean.FALSE);
					} else if (UsuarioUtil.contemPermissao(NoFuncionalidadeEnum.CONSULTA_UNIDADE.getNoFuncionalidade(),
							EnumAcao.CONSULTAR.getNoAcao(), EnumTipoAbrangencia.RESTRITA_UNIDADE.getTipoAbrangencia(),
							EnumNomeAbrangenciaRestritaUnidade.UNIDADE.getNomeAbrangencia())) {

						getVisao().setHabilitarSuat(Boolean.TRUE);
						getVisao().setHabilitarSr(Boolean.TRUE);
						getVisao().setHabilitarUnidade(Boolean.TRUE);
					}
				}
			}
		}
	}
	
        /**
         * <p>
         * Método responsável por executar a ação quando a combobox de DIRE -
         * anteriormente chamada de SUAT - for selecionada.
         * <p>
         *
         * @author Waltenes Junior
         * @author gerusa.soares
         */
	public void selecionarDire() {
		this.limparSrSelecionada();
		this.limparUnidadeSelecionada();
		this.limparListaUnidadeFiltro();
		getVisao().setListaUnidade(null);
		
		getVisao().setNuSuat(getVisao().getSuatSelecionada());
		
		if (getVisao().getNuSuat() != null && !getVisao().getNuSuat().equals(0)) {
			getVisao().setSrList(dwAnaliseContratoService.listarSrsPorNuSuat(getVisao().getNuSuat()));
			
			final Collection<Integer> listaNuSr = new ArrayList<>();
			for (final SrVO srVO : getVisao().getSrList()) {
			    listaNuSr.add(srVO.getNuSrVO());
			}
			
			final Collection<Integer> nuUnidadesVinculadasSR = unidadeVinculadaSuatService.getNuUnidadesVinculadasSR(listaNuSr);
			
			final Collection<Integer> listaUnidadeFiltro = this.getListaNuUnidade(nuUnidadesVinculadasSR, listaNuSr, visao.getNuSuat());
			
			getConsulta().getFiltro().setListaUnidade(listaUnidadeFiltro);
			
		} else {
			getVisao().setSrList(new LinkedList<SrVO>());
			getVisao().setListaUnidade(null);
		}
	}
	
	/**
	 * <p>Método responsável por retornar uma lista com números de unidades.</p>
	 *
	 * @author gerusa.soares
	 *
	 * @param listUnidadePrioridadeUm
	 * @param listUnidadePrioridadeDois
	 * @param nuUnidade
	 * @return
	 */
	private Collection<Integer> getListaNuUnidade(Collection<Integer> listUnidadePrioridadeUm, Collection<Integer> listUnidadePrioridadeDois, Integer nuUnidade) {
	    
	    final Collection<Integer> listaUnidadeFiltro = CollectionUtils.isNotEmpty(listUnidadePrioridadeUm) ? listUnidadePrioridadeUm : listUnidadePrioridadeDois;
	    
	    return CollectionUtils.isNotEmpty(listaUnidadeFiltro) ? listaUnidadeFiltro : Arrays.asList(nuUnidade);
	}
	
	/**
	 * <p>
	 * Método responsável por preencher a lista de unidades de acordo com a SR
	 * selecionada.
	 * <p>
	 *
	 * @author Waltenes Junior
	 * @author gerusa.soares
	 */
	public void selecionarSr() {
		this.limparListaUnidadeFiltro();
		this.limparUnidadeSelecionada();
		
		if (getVisao().getSrSelecionada() != null && !getVisao().getSrSelecionada().equals(0)) {
			getVisao().setListaUnidade(unidadeVinculadaSuatService.listarUnidadesPorNuSr(getVisao().getSrSelecionada()));
			
			final Collection<Integer> listaNuUnidade = new ArrayList<>();
			for (final UnidadeVO unidade : getVisao().getListaUnidade()) {
			    listaNuUnidade.add(unidade.getCoUnidadeVO());
			}
			
			getConsulta().getFiltro().setListaUnidade(this.getListaNuUnidade(listaNuUnidade, null, visao.getSrSelecionada()));
			
		} else {
			this.selecionarDire();
		}

	}

	/**
	 * <p>Método responsável por limpar a unidade selecionada.</p>
	 *
	 * @author gerusa.soares
	 *
	 */
	private void limparUnidadeSelecionada() {
	    getVisao().setUnidadeSelecionada(null);
	}

	/**
	 * <p>Método responsável por limpar a unidade sr selecionada.</p>
	 *
	 * @author gerusa.soares
	 *
	 */
	private void limparSrSelecionada() {
	    getVisao().setSrSelecionada(null);
	}

        /**
         * <p>
         * Método responsável por limpar a lista de unidades, utilizada como filtro
         * na consulta aos contratos.
         * </p>
         *
         * @author gerusa.soares
         *
         */
        private void limparListaUnidadeFiltro() {
    		getConsulta().getFiltro().setListaUnidade(new ArrayList<Integer>());
        }

        /**
         * <p>
         * Método responsável por preencher a lista de unidades utilizada como
         * filtro na consulta de contratos, de acordo com a SR selecionada.
         * <p>
         *
         * @author Waltenes Junior
         * @author gerusa.soares
         */
        public void selecionarUnidade() {
		this.limparListaUnidadeFiltro();
		
    	        if(getVisao().getUnidadeSelecionada() != null && !getVisao().getUnidadeSelecionada().equals(0)) {
    	            getConsulta().getFiltro().getListaUnidade().add(getVisao().getUnidadeSelecionada());
    	            
    	        } else {
    	            this.limparUnidadeSelecionada();
    	            this.selecionarSr();
    	        }
	}

	public void salvarContrato() {
		try {
    		final Contrato contrato = this.getVisao().getEntidade();
    		this.getService().validarDados(contrato);
    
    		if (contrato.hasMensagens()) {
    			for (final MensagemTO mensagem : this.visao.getEntidade().getMensagens()) {
    				MensagensUtil.adicionaMensagemDeAlerta(ContratoMB.MSG_APP, mensagem.getChaveMensagem(), mensagem.getArgumentos());
    				
    			}
    			getVisao().setExibirModalSucesso(Boolean.FALSE);
    		} else {
    			contrato.setCoContrato(
    					ContratoUtil.montarNumeroContrato(this.getVisao().getOperacaoSistema().getDeMascara(), contrato.getNuUnidade().toString(),
    							contrato.getNuOperacao().toString(), contrato.getNumeroConta().toString(), contrato.getDigito().toString()));
    			getService().validarContratoDuplicado(contrato);
    			
    			if (contrato.hasMensagens()) {
        			for (final MensagemTO mensagem : this.visao.getEntidade().getMensagens()) {
        				MensagensUtil.adicionaMensagemDeAlerta(ContratoMB.MSG_APP, mensagem.getChaveMensagem(), mensagem.getArgumentos());
        				
        			}
        			getVisao().setExibirModalSucesso(Boolean.FALSE);
        		} else {
        			this.getService().salvar(contrato, this.getVisao().getListaContratoTO());
        			getVisao().setExibirModalSucesso(Boolean.TRUE);
        			this.getVisao().setMensagemInclusaoContrato(MensagensUtil.getMensagem(this.getNomeVarResourceBundle(), CONTRATO_INCLUIDO_SUCESSO));
        		}
    		}
    		
		} catch (final RuntimeException e) {
			getVisao().setExibirModalSucesso(Boolean.FALSE);
			LogCEF.error("Erro ao salvar o contrato " + getVisao().getEntidade().getNuContrato() + ": " + e.getMessage());
			LogCEF.error(e);
	    }
	}

	public void consultarDadosPessoaSicli() {
		Pessoa pessoa = this.getVisao().getEntidade().getNuPessoa();
		if (UtilObjeto.isReferencia(pessoa) && !UtilString.isVazio(pessoa.getNuCnpj())) {
			String cpfCnpj = pessoa.getNuCnpj();
			final RespostaSicliTO resposta = this.solicitaDadosClienteSicli.consultarContasCliente(cpfCnpj);
			final boolean retornoValido = resposta != null && resposta.getDado() != null
					&& (resposta.getDado().getNome() != null || resposta.getDado().getRazaoSocial() != null);

			Pessoa pessoaExistente = this.pessoaService.obterPessoaPorCnpj(cpfCnpj);

			if (retornoValido) {
				this.verificarTipoPessoaAtribuirInfomacoesBasicas(cpfCnpj, resposta, pessoaExistente);
			} else if (pessoaExistente != null) {
				this.visao.getEntidade().setNuPessoa(pessoaExistente);
			} else {
				super.adicionaMensagemDeAlerta(CLIENTE_NAO_ENCONTRADO);
			}
			if (UtilObjeto.isReferencia(pessoa.getNuCnpj())) {
				this.getVisao().getListaContratoTO().clear();
				RetornoSid09TO sid09 = solicitaDadosSID09.consumirSID(NumeroUtil.somenteNumeros(pessoa.getNuCnpj()));
				if (sid09 != null && !UtilObjeto.isVazio(sid09.getContas())) {
					for (ContaSid09TO conta : sid09.getContas()) {
						ContratoTO contrato = new ContratoTO();
						contrato.setNuProduto(conta.getProduto());
						contrato.setNuNaturalSistema(conta.getNumero());
						contrato.setNuCrto(conta.getTipoConta());
						contrato.setNumero(conta.getNumero());
						contrato.setUnidade(conta.getUnidade());
						contrato.setDigito(conta.getDv());
						this.getVisao().getListaContratoTO().add(contrato);
					}
				}
			}
		} else {
			this.visao.getEntidade().getNuPessoa().setNoPessoa(null);
		}
	}

	/**
	 * @param cpfCnpj
	 * @param resposta
	 * @param pessoaExistente
	 */
	public void verificarTipoPessoaAtribuirInfomacoesBasicas(final String cpfCnpj, final RespostaSicliTO resposta, Pessoa pessoaExistente) {
		Pessoa pessoa = this.atribuirInformacoesComumPessoa(cpfCnpj, resposta);
		if (ContratoMB.PESSOA_JURIDICA.equals(pessoa.getIcPfPj())) {
			pessoa.setNoPessoa(resposta.getDado().getRazaoSocial());
			pessoa.setVrFaturamentoApurado(BigDecimal.ZERO);
		} else {
			pessoa.setNoPessoa(resposta.getDado().getNome());
		}
		if (pessoaExistente == null) {
			this.pessoaService.inserir(pessoa);
		} else {
			pessoa.setNuPessoa(pessoaExistente.getNuPessoa());
		}

		this.visao.getEntidade().setNuPessoa(pessoa);
	}

	/**
	 * @param cpfCnpj
	 * @param resposta
	 * @return
	 */
	public Pessoa atribuirInformacoesComumPessoa(final String cpfCnpj, final RespostaSicliTO resposta) {
		Pessoa pessoa = new Pessoa();
		pessoa.setNuCnpj(cpfCnpj);
		pessoa.setCoCliente(resposta.getDado().getCocli());
		pessoa.setIcTipoEndividamento(TipoEndividamentoEnum.C);
		pessoa.setNuSegmento(new Segmento());
		pessoa.getNuSegmento().setNuSegmento(1);
		pessoa.setTsUltimaAlteracao(new Date());
		pessoa.setCoResponsavelAlteracao("c".concat(UtilFormatacao.completarComZeroEsquerda(UsuarioUtil.getMatriculaUsuarioLogado().toString(), 6)));
		pessoa.setIcPfPj(resposta.getDado().getTipoPessoa());
		pessoa.setIcAlertaEndividamento(SituacaoEndividamentoEnum.NENHUM.getValor());
		return pessoa;
	}

	public void recuperarMascaraPorOperacao() {
		for (final Produto produto : visao.getListaProduto()) {
			if (produto.getNuProduto().equals(visao.getEntidade().getNuOperacao())) {
				this.visao.getEntidade().setNumeroConta(null);
				this.visao.getEntidade().setDigito(null);
				OperacaoSistema operacaoSistema = this.operacaoSistemaService.obter(produto.getNuProduto().toString(), produto.getSgSistema());
				if (operacaoSistema == null) {
					operacaoSistema = new OperacaoSistema();
					operacaoSistema.setNoSistema(produto.getSgSistema());
					operacaoSistema.setNuOperacao(produto.getNuProdutoFormatado());
					operacaoSistema.setDeMascara(operacaoSistemaService.recuperarMascaraPorSistema(produto.getSgSistema()));
					this.operacaoSistemaService.salvar(operacaoSistema);
				}
				operacaoSistema.getTamanhoConta();
				operacaoSistema.getTamanhoDigito();
				visao.setOperacaoSistema(operacaoSistema);
			}
		}
	}

	/**
	 * <p>
	 * Método responsável por verificar qual unidade selecionada para recuperar
	 * o nuNatural para o contrato e nuUnidadeContratacao.
	 * </p>
	 * .
	 *
	 * @author f754687
	 *
	 */
	public void recuperarNuNaturalSelecao() {
		final Contrato contrato = this.getVisao().getEntidade();
		if (UtilObjeto.isReferencia(contrato.getNuUnidade()) && contrato.getNuUnidade() > 0) {
			for (final Unidade unidade : this.getVisao().getListaUnidadeContrato()) {
				if (unidade.getUnidadeID().getNuUnidade().equals(contrato.getNuUnidade())) {
					contrato.setNuNatural(unidade.getUnidadeID().getNuNatural());
					contrato.setNuUnidadeContratacao(unidade.getUnidadeID().getNuUnidade());
					break;
				}
			}
		}
	}

	public ContratoInativoLazyModel getContratosInativos() {
		if (this.contratosInativos == null) {
			this.contratosInativos = new ContratoInativoLazyModel();
		}

		return contratosInativos;
	}

	public void setContratosInativos(ContratoInativoLazyModel contratosInativos) {
		this.contratosInativos = contratosInativos;
	}
	
	public Boolean getApresentarContratosInativos() {
        if (this.consulta != null) {
        	return !UtilString.isVazio(this.consulta.getFiltro().getCnpjPessoaVO());
        }
        return false;
    }
	
}
