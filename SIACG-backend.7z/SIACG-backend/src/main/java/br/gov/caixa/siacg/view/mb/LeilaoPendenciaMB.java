/*
 * Copyright (c) 2021 Caixa Econômica Federal. Todos os direitos
 * reservados.
 *
 * Caixa Econômica Federal - SIACG - Sistema de Crédito Rural
 *
 * Este software foi desenvolvido sob demanda da CAIXA e está
 * protegido por leis de direitos autorais e tratados internacionais. As
 * condições de cópia e utilização do todo ou partes dependem de autorização da
 * empresa. Cópias não são permitidas sem expressa autorização. Não pode ser
 * comercializado ou utilizado para propósitos particulares.
 *
 * Uso exclusivo da Caixa Econômica Federal. A reprodução ou distribuição não
 * autorizada deste programa ou de parte dele, resultará em punições civis e
 * criminais e os infratores incorrem em sanções previstas na legislação em
 * vigor.
 *
 * Histórico do TFS:
 *
 * LastChangedRevision: $Revision$
 * LastChangedBy: $Author$
 * LastChangedDate: $Date$
 *
 * HeadURL: $HeadURL$
 *
 */	
package br.gov.caixa.siacg.view.mb;

import java.util.ArrayList;
import java.util.List;

import javax.enterprise.context.SessionScoped;
import javax.inject.Inject;
import javax.inject.Named;

import org.primefaces.context.RequestContext;

import br.gov.caixa.pedesgo.arquitetura.controlador.ManutencaoBean;
import br.gov.caixa.pedesgo.arquitetura.dao.DAO;
import br.gov.caixa.pedesgo.arquitetura.servico.Servico;
import br.gov.caixa.pedesgo.arquitetura.util.UtilObjeto;
import br.gov.caixa.pedesgo.arquitetura.util.UtilString;
import br.gov.caixa.siacg.model.domain.leilao.Leilao;
import br.gov.caixa.siacg.model.domain.leilao.LeilaoCampoPendencia;
import br.gov.caixa.siacg.model.domain.leilao.LeilaoCampoPendenciaValor;
import br.gov.caixa.siacg.model.domain.leilao.LeilaoPendencia;
import br.gov.caixa.siacg.model.domain.leilao.LeilaoPendenciaResposta;
import br.gov.caixa.siacg.model.domain.leilao.TipoPendenciaLeilao;
import br.gov.caixa.siacg.model.enums.SimNaoEnum;
import br.gov.caixa.siacg.model.enums.leilao.SituacaoLeilaoEnum;
import br.gov.caixa.siacg.model.enums.leilao.TipoCampoPendenciaEnum;
import br.gov.caixa.siacg.service.LeilaoCampoPendenciaService;
import br.gov.caixa.siacg.service.LeilaoCampoPendenciaValorService;
import br.gov.caixa.siacg.service.LeilaoPendenciaRespostaService;
import br.gov.caixa.siacg.service.LeilaoPendenciaService;
import br.gov.caixa.siacg.service.LeilaoService;
import br.gov.caixa.siacg.service.TipoPendenciaLeilaoService;
import br.gov.caixa.siacg.util.LogCEF;
import br.gov.caixa.siacg.view.form.LeilaoPendenciaVisao;

/**
 * <p>LeilaoPendenciaMB</p>
 *
 * <p>Descrição: Descrição do tipo</p>
 *
 * <br><b>Empresa:</b> Cef - Caixa Econômica Federal
 *
 *
 * @author gerusa.soares
 *
 * @version 1.0
*/
@Named
@SessionScoped
public class LeilaoPendenciaMB extends ManutencaoBean<Leilao> implements LeilaoOpcoesLancamentoService {
    
    /** Atributo serialVersionUID. */
    private static final long serialVersionUID = 1L;

    private LeilaoPendenciaVisao visao;
    
    @Inject
    private TipoPendenciaLeilaoService tipoPendenciaLeilaoService;
    
    @Inject
    private LeilaoCampoPendenciaService leilaoCampoPendenciaService;
    
    @Inject
    private LeilaoCampoPendenciaValorService leilaoCampoPendenciaValorService;
    
    @Inject
    private LeilaoPendenciaService leilaoPendenciaService;
    
    @Inject
    private LeilaoPendenciaRespostaService leilaoPendenciaRespostaService;
    
    @Inject
    private LeilaoService leilaoService;
    
    /**
     * @see br.gov.caixa.pedesgo.arquitetura.controlador.AbstractBean#getPrefixoCasoDeUso()
    */
    @Override
    protected String getPrefixoCasoDeUso() {
	return null;
    }

    /**
     * @see br.gov.caixa.pedesgo.arquitetura.controlador.AbstractBean#getService()
    */
    @Override
    public <S extends Servico<Leilao, DAO<Leilao>>> S getService() {
	return null;
    }
    
    public LeilaoPendenciaVisao getVisao() {
	if(this.visao == null) {
	    this.visao = new LeilaoPendenciaVisao();
	}
        return this.visao;
    }

    public void setVisao(LeilaoPendenciaVisao visao) {
        this.visao = visao;
    }
    
    /**
     * @see br.gov.caixa.siacg.view.mb.LeilaoOpcoesLancamentoService#iniciar(br.gov.caixa.siacg.model.domain.leilao.Leilao)
    */
    @Override
    public void iniciar(final Leilao leilao) {
	
	this.getVisao().setEntidade(leilao);
	
	final LeilaoPendencia pendencia = new LeilaoPendencia();
	pendencia.setTipoPendenciaLeilao(new TipoPendenciaLeilao());
	this.getVisao().setPendencia(pendencia);
	
	this.getVisao().setListaCampoPendencia(new ArrayList<>());
	this.limparTextArea();
	
	RequestContext.getCurrentInstance().execute("modalSelecionarTipoPendenciaWidget.show();");
	
	if(UtilObjeto.isVazio(this.getVisao().getListaTipoPendenciaLeilao())) {
	    this.getVisao().setListaTipoPendenciaLeilao((List<TipoPendenciaLeilao>)this.tipoPendenciaLeilaoService.listar());
	}
	
	if(!UtilObjeto.isVazio(this.getVisao().getListaTipoPendenciaLeilao())) {
	    this.getVisao().getPendencia().setTipoPendenciaLeilao(this.getVisao().getListaTipoPendenciaLeilao().get(0));
	    this.carregarCamposPendenciaPorTipoPendencia();
	}
	
	this.limparRespostaCamposPendencia();
    }
    
    private void limparRespostaCamposPendencia() {
	if(!UtilObjeto.isVazio(this.getVisao().getListaCampoPendencia())) {
	    this.getVisao().getListaCampoPendencia().stream().forEach(campoPendencia -> campoPendencia.setResposta(new LeilaoPendenciaResposta()));
	}
    }

    public void carregarCamposPendenciaPorTipoPendencia() {
	this.getVisao().setListaCampoPendencia(new ArrayList<>());
	
	final TipoPendenciaLeilao tipoPendencia = this.getVisao().getPendencia().getTipoPendenciaLeilao();
	if(UtilObjeto.isReferencia(tipoPendencia)) {
	    
		List<LeilaoCampoPendencia> listaCampoTipoPendencia = this.getVisao().getMapCampoPendencia().get(tipoPendencia);
		
		if(UtilObjeto.isVazio(listaCampoTipoPendencia)) {
		    listaCampoTipoPendencia = this.leilaoCampoPendenciaService.listarPorIdTipoPendencia(tipoPendencia.getId());
		    
		    this.getVisao().getMapCampoPendencia().put(tipoPendencia, listaCampoTipoPendencia);
		}
		
		this.getVisao().setListaCampoPendencia(listaCampoTipoPendencia);
		
		this.carregarCombos();
		
	}
	
	this.limparRespostaCamposPendencia();
	RequestContext.getCurrentInstance().update("modalSelecionarTipoPendenciaWidget");
    }
    
    private void carregarCombos() {

	this.getVisao().setListaCampoPendenciaValor(new ArrayList<>());
	this.getVisao().setIcExibirTextArea(false);

	if (!UtilObjeto.isVazio(this.getVisao().getListaCampoPendencia())) {

	    this.getVisao().getListaCampoPendencia().stream().forEach(campo -> {

		if (campo.getIcTipo() == TipoCampoPendenciaEnum.COMBO) {

		    List<LeilaoCampoPendenciaValor> listaCampoPendenciaValor = this.getVisao().getMapCampoPendenciaValor().get(campo);

		    if (UtilObjeto.isVazio(listaCampoPendenciaValor)) {
			listaCampoPendenciaValor = this.leilaoCampoPendenciaValorService.listarPorIdCampoPendencia(campo.getId());
			this.getVisao().getMapCampoPendenciaValor().put(campo, listaCampoPendenciaValor);
		    }

		    this.getVisao().setListaCampoPendenciaValor(listaCampoPendenciaValor);
		}
	    });
	    
	}
    }

    /**
     * <p>Método responsável por</p>
     *
     * @author gerusa.soares
     *
     * @param campoValor
     * @return
     */
    private boolean isAbrirCampoTexto(LeilaoCampoPendenciaValor campoValor) {
	return campoValor.getIcAberto() == SimNaoEnum.S;
    }
    
    public void verificarSeExibeTextArea(final LeilaoCampoPendenciaValor campoValor) {
	this.limparTextArea();
	
	if(UtilObjeto.isReferencia(campoValor) && this.isAbrirCampoTexto(campoValor)) {
	    this.getVisao().setIcExibirTextArea(true);
	}
	
	RequestContext.getCurrentInstance().update("modalSelecionarTipoPendenciaWidget");
    }

    private void limparTextArea() {
	this.getVisao().setDeRespostaComboIcAberto(null);
	this.getVisao().setIcExibirTextArea(false);
    }

    public void salvarPendencia() {
	final LeilaoPendencia leilaoPendencia = this.getVisao().getPendencia();

	if (!UtilObjeto.isReferencia(leilaoPendencia.getTipoPendenciaLeilao())) {
	    this.adicionaMensagemDeAlerta("Selecione o Tipo de Pendência.");
	    return;
	}
	
	if(!this.validarCamposPendencia()) {
	    return;
	}
	
	final Leilao leilao = this.getVisao().getEntidade();
	leilaoPendencia.setLeilao(leilao);
	
	this.getDeRespostaComboIcAberto();
	
	try {
	    this.leilaoPendenciaService.salvarLeilaoPendencia(leilaoPendencia);
	    this.leilaoPendenciaRespostaService.salvarListaRespostaCampoPendencia(this.getVisao().getListaCampoPendencia(), leilaoPendencia);
	    this.leilaoService.alterarSituacaoSalvarHistorico(leilao, SituacaoLeilaoEnum.EM_PENDENCIA);
	    
	    RequestContext.getCurrentInstance().execute("modalSelecionarTipoPendenciaWidget.hide();");
	    this.adicionaMensagemDeSucesso("Operação realizada com sucesso!");
	} catch (Exception e) {
	    final String msgErro = "Operação não realizada. Ocorreu um erro ao salvar os dados da pendência.";
	    LogCEF.error(msgErro);
	    LogCEF.error(e);
	    this.adicionaMensagemDeErro(msgErro);
	}
    }
    
    /**
     * <p>
     * Alguns valores selecionados nas combos, permitem ao usuário inserir texto
     * descritivo. Este método é responsável por obter o valor digitado pelo usuário, e inserir na
     * reposta a ser salva.
     * </p>
     *
     * @author gerusa.soares
     *
     */
    private void getDeRespostaComboIcAberto() {
	this.getVisao().getListaCampoPendencia().stream().forEach(campo -> {
	    final LeilaoPendenciaResposta resposta = campo.getResposta();
	    if(resposta != null && resposta.getLeilaoCampoPendenciaValor() != null && resposta.getLeilaoCampoPendenciaValor().getIcAberto() == SimNaoEnum.S) {
		resposta.setDeReposta(this.getVisao().getDeRespostaComboIcAberto());
	    }
	});
    }

    private boolean validarCamposPendencia() {
	boolean isValido = true;
	
	for (LeilaoCampoPendencia campoPendencia : this.getVisao().getListaCampoPendencia()) {

	    final LeilaoPendenciaResposta resposta = campoPendencia.getResposta();

	    final boolean isObrigatorio = campoPendencia.getIcObrigatorio() == SimNaoEnum.S;

	    if (isObrigatorio && resposta.getLeilaoCampoPendenciaValor() == null && UtilString.isVazio(resposta.getDeReposta())) {
		isValido = false;
		this.adicionaMensagemDeAlerta("Campo obrigatório: " + campoPendencia.getNoCampo());
	    }
	}

	return isValido;
    }
    
}
