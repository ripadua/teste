/**
 * reservados. Copyright (c) 2009-2011 Caixa Econômica Federal. Todos os direitos
 *
 * Caixa Econômica Federal - SIACG – Sistema de Acompanhamento de Carteiras de Cobrança
 *
 * Este programa de computador foi desenvolvido sob demanda da CAIXA e está protegido por leis de direitos autorais e
 * tratados internacionais. As condições de cópia e utilização do todo ou partes dependem de autorização da pessoa.
 * Cópias não são permitidas sem expressa autorização. Não pode ser comercializado ou utilizado para propósitos
 * particulares.
 *
 * Uso exclusivo da Caixa Econômica Federal. A reprodução ou distribuição não autorizada deste programa ou de parte
 * dele, resultará em punições civis e criminais e os infratores incorrem em sanções previstas na legislação em vigor.
 *
 * Histórico do Subversion:
 *
 * LastChangedRevision: LastChangedBy: LastChangedDate:
 *
 * HeadURL:
 *
 */
package br.gov.caixa.siacg.view.mb;

import java.util.Collection;
import java.util.Date;
import java.util.LinkedHashMap;
import java.util.Map;

import javax.enterprise.context.SessionScoped;
import javax.faces.context.FacesContext;
import javax.inject.Inject;
import javax.inject.Named;
import javax.servlet.http.HttpServletRequest;

import org.apache.commons.collections.CollectionUtils;

import br.gov.caixa.pedesgo.arquitetura.controlador.ManutencaoBean;
import br.gov.caixa.pedesgo.arquitetura.enums.EnumExtensaoArquivo;
import br.gov.caixa.pedesgo.arquitetura.relatorio.UtilRelatorio;
import br.gov.caixa.pedesgo.arquitetura.util.LogCefUtil;
import br.gov.caixa.pedesgo.arquitetura.util.UsuarioUtil;
import br.gov.caixa.pedesgo.arquitetura.util.UtilData;
import br.gov.caixa.pedesgo.arquitetura.util.UtilObjeto;
import br.gov.caixa.pedesgo.arquitetura.util.UtilString;
import br.gov.caixa.siacg.model.domain.Cheque;
import br.gov.caixa.siacg.model.domain.GarantiaContrato;
import br.gov.caixa.siacg.service.ChequeService;
import br.gov.caixa.siacg.service.ContratoService;
import br.gov.caixa.siacg.view.form.DetalheChequeVisao;

/**
 * <p>
 * DetalheChequeMB.
 * </p>
 * <p>
 * Descrição: Managed bean de detalhamento de cheques
 * </p>
 * <br>
 * <b>Empresa:</b> Cef - Caixa Econômica Federal
 *
 * @author Caio Graco
 * @version 1.0
 */
@Named
@SessionScoped
public class DetalheChequeMB extends ManutencaoBean<Cheque> {

    /** Atributo UM. */
    private static final int UM = 1;

    /** Atributo serialVersionUID. */
    private static final long serialVersionUID = 509553705294132803L;

    /** Atributo NOME_MANAGED_BEAN. */
    public static final String NOME_MANAGED_BEAN = "detalheChequeMB";

    /** Atributo EL_MANAGED_BEAN. */
    public static final String EL_MANAGED_BEAN = "#{detalheChequeMB}";

    /** Atributo PAGINA_DETALHE_CHEQUES. */
    private static final String PAGINA_DETALHE_CHEQUES = "/pages/analise/detalheCheque.xhtml?faces-redirect=true";

    /** Atributo NOME_RELATORIO_CHEQUE. */
    private static final String NOME_RELATORIO_CHEQUE = "relatorio_cheques";

    /** Atributo CAMINHO_RELATORIO_CHEQUE_XLS. */
    private static final String CAMINHO_RELATORIO_CHEQUE_XLS = "/reports/cheques_xls.jasper";

    /** Atributo visao. */
    private transient DetalheChequeVisao visao;

    /** Atributo chequeService. */
    @Inject
    private transient ChequeService chequeService;

    /** Atributo contratoService. */
    @Inject
    private transient ContratoService contratoService;

    /**
     * @see br.gov.caixa.pedesgo.arquitetura.controlador.AbstractBean#getPrefixoCasoDeUso()
     */
    @Override
    protected String getPrefixoCasoDeUso() {

        return null;
    }

    /**
     * @see br.gov.caixa.pedesgo.arquitetura.controlador.AbstractBean#getVisao()
     */
    @Override
    public DetalheChequeVisao getVisao() {

        if (!UtilObjeto.isReferencia(this.visao)) {

            this.visao = new DetalheChequeVisao();
        }

        return this.visao;
    }

    /**
     * @see br.gov.caixa.pedesgo.arquitetura.controlador.AbstractBean#getService()
     */
    @SuppressWarnings("unchecked")
    @Override
    public ChequeService getService() {

        return this.chequeService;
    }

    /**
     * <p>
     * Abre a tela pra detalhar os cheques.
     * <p>
     *
     * @return String
     * @author Caio Graco
     */
    public String abrirDetalheCheques() {

        this.carregarDadosVisao();

        this.listarCheques();

        return DetalheChequeMB.PAGINA_DETALHE_CHEQUES;
    }

    /**
     * <p>
     * Método responsável por carregar os dados da visão.
     * <p>
     *
     * @author Caio Graco
     */
    private void carregarDadosVisao() {

        final DetalheChequeVisao visao = this.getVisao();

        visao.setMostrarChequesUtilizados(false);

        visao.setForaPrazoMaximo(false);

        visao.setForaPrazoMinimo(false);

        visao.setForaValorMaximo(false);

        visao.getListaChequesUtilizados().clear();

        visao.getListaChequesBackup().clear();

    }

    /**
     * @see br.gov.caixa.pedesgo.arquitetura.controlador.AbstractBean#getNomeVarResourceBundle()
     */
    @Override
    protected String getNomeVarResourceBundle() {
        return "msgApp";
    }

    /**
     * <p>
     * Método responsável por verificar os cheques que estão com os itens fora
     * dos parametros.
     * <p>
     *
     * @param garantiaContrato
     *            valor a ser atribuído
     * @param prazoMinimoPermitido
     *            valor a ser atribuído
     * @param dataMaximaPermitida
     *            valor a ser atribuído
     * @author Caio Graco, guilherme.santos
     */
    private void verificarItensForaDosParametros(final GarantiaContrato garantiaContrato, final int prazoMinimoPermitido,
            final Date dataMaximaPermitida) {

        // Define os itens fora dos parâmetros para cada cheque
        for (final Cheque cheque : this.getVisao().getLista()) {

            if (cheque.getVrCheque().compareTo(garantiaContrato.getVrMaximoPermitido()) == DetalheChequeMB.UM) {

                cheque.setForaValorMaximo(Boolean.TRUE);

            } else {

                cheque.setForaValorMaximo(Boolean.FALSE);
            }

            if (cheque.consultarDiasVigencia() < prazoMinimoPermitido) {

                cheque.setForaPrazoMinimo(Boolean.TRUE);

                continue;
            }

            cheque.setForaPrazoMinimo(Boolean.FALSE);

            if (UtilObjeto.isReferencia(dataMaximaPermitida)
                    && UtilData.verificarSeDataEhMaior(UtilData.converterDataSemHoras(cheque.getDtVencimento()), dataMaximaPermitida)) {

                cheque.setForaPrazoMaximo(Boolean.TRUE);

                continue;
            }

            cheque.setForaPrazoMaximo(false);
        }
    }

    /**
     * <p>
     * Método responsável por gerar relatorio no formato xls.
     * <p>
     *
     * @author Waltenes Junior
     */
    public void gerarXlsCheques() {
        if (CollectionUtils.isNotEmpty(this.getVisao().getLista())) {
            
            this.getVisao().setTipoArquivo(EnumExtensaoArquivo.XLS);
            this.getVisao().setColecaoRelatorio(this.getVisao().getLista());
            this.getVisao().setNomeRelatorio(DetalheChequeMB.NOME_RELATORIO_CHEQUE);
            this.getVisao().setCaminhoRelatorio(DetalheChequeMB.CAMINHO_RELATORIO_CHEQUE_XLS);
            this.getVisao().setMapaParametros(this.montarMapaParametrosCheques());
            
            this.geraRelatorio();
            
        } else {
            super.adicionaMensagemInformativa("MN021");
        }
    }

    /**
     * <p>
     * Método responsável por gerar relatorios de cheques.
     * <p>
     *
     * @author Waltenes Junior
     */
    public void geraRelatorio() {
        final DetalheChequeVisao visao = this.getVisao();

        try {
            UtilRelatorio.getInstancia().addCaminhoRelatorio(visao.getCaminhoRelatorio()).addColecao(visao.getColecaoRelatorio())
                    .addResposta(this.getResponse()).addParametros(visao.getMapaParametros()).addNomeRelatorio(visao.getNomeRelatorio())
                    .addExtensaoArquivo(visao.getTipoArquivo()).gerarRelatorio();
        } catch (final Exception e) {
            LogCefUtil.error("Erro: " + e.getMessage() + " - Causa: " + e.getCause());
            LogCefUtil.error(e);
        }
    }

    /**
     * <p>
     * Método responsável por montar o mapa de parametros passado para o
     * relatorio de cheques.
     * <p>
     *
     * @return Map<String, Object>
     * @author Waltenes Junior
     */
    private Map<String, Object> montarMapaParametrosCheques() {
        final Map<String, Object> parametros = new LinkedHashMap<>();
        parametros.put("LOGO_CAIXA", FacesContext.getCurrentInstance().getExternalContext().getResourceAsStream("/resources/img/caixa_logo.jpg"));
        parametros.put("MATRICULA_USUARIO", UsuarioUtil.getUsuarioLogado().getDeMatricula());

        final HttpServletRequest request = (HttpServletRequest) FacesContext.getCurrentInstance().getExternalContext().getRequest();
        @SuppressWarnings("unchecked")
        final Map<String, String> mapaOperacaoSistema = (Map<String, String>) request.getSession().getAttribute("mapaOperacaoSistema");
        this.getVisao().getPessoaVO()
                .setContrato(this.getService().atribuirMascaraCodigoContrato(this.getVisao().getPessoaVO().getContrato(), mapaOperacaoSistema));

        parametros.put("pessoa", this.getVisao().getPessoaVO().getPessoa());
        parametros.put("contrato", this.getVisao().getPessoaVO().getContrato());
        parametros.put("valor", this.getVisao().getPessoaVO().getVrContrato());
        parametros.put("devedor", this.getVisao().getPessoaVO().getSaldoDevedor());

        return parametros;
    }

    /**
     * <p>
     * Método responsável por atualizar a grid de cheques de acordo com o item
     * fora do parâmetro selecionado.
     * <p>
     *
     * @author Caio Graco
     */
    public void atualizarGridCheques() {

        final DetalheChequeVisao visao = this.getVisao();

        visao.setListaChequesUtilizados(null);

        this.restaurarListaChequePrincipal(visao);

        this.verificarFPMininoTrueFPMaximoFalseFVMFalse(visao, visao.isForaPrazoMinimo(), visao.isForaPrazoMaximo(), visao.isForaValorMaximo(),
                visao.isMostrarChequesUtilizados());

        this.verificarFPMaximoTrueFVMFalseFPMFalse(visao, visao.isForaPrazoMinimo(), visao.isForaPrazoMaximo(), visao.isForaValorMaximo(),
                visao.isMostrarChequesUtilizados());

        this.verificarFPMininoTrueFPMaximoTrueFVMFalse(visao, visao.isForaPrazoMinimo(), visao.isForaPrazoMaximo(), visao.isForaValorMaximo(),
                visao.isMostrarChequesUtilizados());

        this.verificarFPMininoTrueFPmaximoTrueFVMaximoTrue(visao, visao.isForaPrazoMinimo(), visao.isForaPrazoMaximo(), visao.isForaValorMaximo(),
                visao.isMostrarChequesUtilizados());

        this.verificarFVMaximoTrueFPMinimoFalseFPMaximoFalse(visao, visao.isForaPrazoMinimo(), visao.isForaPrazoMaximo(), visao.isForaValorMaximo(),
                visao.isMostrarChequesUtilizados());

        this.verificarFVmaximoTrueFPminimoTrueFPMaximoFalse(visao, visao.isForaPrazoMinimo(), visao.isForaPrazoMaximo(), visao.isForaValorMaximo(),
                visao.isMostrarChequesUtilizados());

        this.verificarFVMaximoTrueFPMinimoFalseFPmaximoTrue(visao, visao.isForaPrazoMinimo(), visao.isForaPrazoMaximo(), visao.isForaValorMaximo(),
                visao.isMostrarChequesUtilizados());

        if (visao.isMostrarChequesUtilizados() && !visao.isForaPrazoMaximo() && !visao.isForaPrazoMinimo() && !visao.isForaValorMaximo()) {

            this.carregarCheques(visao);
        }

        if (visao.isMostrarChequesUtilizados() && (visao.isForaPrazoMaximo() || visao.isForaPrazoMinimo() || visao.isForaValorMaximo())) {

            visao.getLista().clear();
        }
    }

    /**
     * <p>
     * Método responsável por verificar o cheque está foraValorMaximo eq True
     * foraPrazominimo eq False e foraPrazoMaximo eq true.
     * <p>
     *
     * @param visao
     *            valor a ser atribuído
     * @param foraPrazoMinimo
     *            valor a ser atribuído
     * @param foraPrazoMaximo
     *            valor a ser atribuído
     * @param foraValorMaximo
     *            valor a ser atribuído
     * @param mostarChequesUtilizados
     *            valor a ser atribuído
     * @author Leandro S. Oliveira
     */
    private void verificarFVMaximoTrueFPMinimoFalseFPmaximoTrue(final DetalheChequeVisao visao, final boolean foraPrazoMinimo,
            final boolean foraPrazoMaximo, final boolean foraValorMaximo, final boolean mostarChequesUtilizados) {

        if (foraValorMaximo && !foraPrazoMinimo && foraPrazoMaximo && !mostarChequesUtilizados) {

            visao.getListaChequesBackup().clear();

            visao.getListaChequesBackup().addAll(UtilObjeto.clone(visao.getLista()));

            for (final Cheque cheque : visao.getListaChequesBackup()) {

                if (cheque.isForaValorMaximo() && cheque.isForaPrazoMaximo() && !cheque.isForaPrazoMinimo()
                        && UtilString.isVazio(cheque.getCoContrato())) {

                    visao.getListaChequesUtilizados().add(UtilObjeto.clone(cheque));
                }
            }

            visao.getLista().clear();

            visao.getLista().addAll(visao.getListaChequesUtilizados());
        }
    }

    /**
     * <p>
     * Método responsável por verificar o cheque está foraValorMaximo eq True
     * foraPrazominimo eq true e foraPrazoMaximo eq false.
     * <p>
     *
     * @param visao
     *            valor a ser atribuído
     * @param foraPrazoMinimo
     *            valor a ser atribuído
     * @param foraPrazoMaximo
     *            valor a ser atribuído
     * @param foraValorMaximo
     *            valor a ser atribuído
     * @param mostarChequesUtilizados
     *            valor a ser atribuído
     * @author Leandro S. Oliveira
     */
    private void verificarFVmaximoTrueFPminimoTrueFPMaximoFalse(final DetalheChequeVisao visao, final boolean foraPrazoMinimo,
            final boolean foraPrazoMaximo, final boolean foraValorMaximo, final boolean mostarChequesUtilizados) {

        if (foraValorMaximo && foraPrazoMinimo && !foraPrazoMaximo && !mostarChequesUtilizados) {

            visao.getListaChequesBackup().clear();

            visao.getListaChequesBackup().addAll(UtilObjeto.clone(visao.getLista()));

            for (final Cheque cheque : visao.getListaChequesBackup()) {

                if (cheque.isForaValorMaximo() && cheque.isForaPrazoMinimo() && !cheque.isForaPrazoMaximo()
                        && UtilString.isVazio(cheque.getCoContrato())) {

                    visao.getListaChequesUtilizados().add(UtilObjeto.clone(cheque));
                }
            }

            visao.getLista().clear();

            visao.getLista().addAll(visao.getListaChequesUtilizados());
        }
    }

    /**
     * <p>
     * Método responsável por verificar o cheque está foraValorMaximo eq True
     * foraPrazominimo eq False e foraPrazoMaximo eq false.
     * <p>
     *
     * @param visao
     *            valor a ser atribuído
     * @param foraPrazoMinimo
     *            valor a ser atribuído
     * @param foraPrazoMaximo
     *            valor a ser atribuído
     * @param foraValorMaximo
     *            valor a ser atribuído
     * @param mostarChequesUtilizados
     *            valor a ser atribuído
     * @author Leandro S. Oliveira
     */
    private void verificarFVMaximoTrueFPMinimoFalseFPMaximoFalse(final DetalheChequeVisao visao, final boolean foraPrazoMinimo,
            final boolean foraPrazoMaximo, final boolean foraValorMaximo, final boolean mostarChequesUtilizados) {

        if (foraValorMaximo && !foraPrazoMinimo && !foraPrazoMaximo && !mostarChequesUtilizados) {

            visao.getListaChequesBackup().clear();

            visao.getListaChequesBackup().addAll(UtilObjeto.clone(visao.getLista()));

            for (final Cheque cheque : visao.getListaChequesBackup()) {

                if (cheque.isForaValorMaximo() && !cheque.isForaPrazoMinimo() && !cheque.isForaPrazoMaximo()
                        && UtilString.isVazio(cheque.getCoContrato())) {

                    visao.getListaChequesUtilizados().add(UtilObjeto.clone(cheque));
                }
            }

            visao.getLista().clear();

            visao.getLista().addAll(visao.getListaChequesUtilizados());
        }
    }

    /**
     * <p>
     * Método responsável por verificar o cheque está foraValorMaximo eq True
     * foraPrazominimo eq true e foraPrazoMaximo eq true.
     * <p>
     *
     * @param visao
     *            valor a ser atribuído
     * @param foraPrazoMinimo
     *            valor a ser atribuído
     * @param foraPrazoMaximo
     *            valor a ser atribuído
     * @param foraValorMaximo
     *            valor a ser atribuído
     * @param mostarChequesUtilizados
     *            valor a ser atribuído
     * @author Leandro S. Oliveira
     */
    private void verificarFPMininoTrueFPmaximoTrueFVMaximoTrue(final DetalheChequeVisao visao, final boolean foraPrazoMinimo,
            final boolean foraPrazoMaximo, final boolean foraValorMaximo, final boolean mostarChequesUtilizados) {

        if (foraPrazoMinimo && foraPrazoMaximo && foraValorMaximo && !mostarChequesUtilizados) {

            visao.getListaChequesBackup().clear();

            visao.getListaChequesBackup().addAll(UtilObjeto.clone(visao.getLista()));

            for (final Cheque cheque : visao.getListaChequesBackup()) {

                if (cheque.isForaPrazoMaximo() && cheque.isForaPrazoMinimo() && cheque.isForaValorMaximo()
                        && UtilString.isVazio(cheque.getCoContrato())) {

                    visao.getListaChequesUtilizados().add(UtilObjeto.clone(cheque));
                }
            }

            visao.getLista().clear();

            visao.getLista().addAll(visao.getListaChequesUtilizados());
        }
    }

    /**
     * <p>
     * Método responsável por verificar o cheque está foraValorMaximo eq false
     * foraPrazominimo eq true e foraPrazoMaximo eq true.
     * <p>
     *
     * @param visao
     *            valor a ser atribuído
     * @param foraPrazoMinimo
     *            valor a ser atribuído
     * @param foraPrazoMaximo
     *            valor a ser atribuído
     * @param foraValorMaximo
     *            valor a ser atribuído
     * @param mostarChequesUtilizados
     *            valor a ser atribuído
     * @author Leandro S. Oliveira
     */
    private void verificarFPMininoTrueFPMaximoTrueFVMFalse(final DetalheChequeVisao visao, final boolean foraPrazoMinimo,
            final boolean foraPrazoMaximo, final boolean foraValorMaximo, final boolean mostarChequesUtilizados) {

        if (foraPrazoMinimo && foraPrazoMaximo && !foraValorMaximo && !mostarChequesUtilizados) {

            visao.getListaChequesBackup().clear();

            visao.getListaChequesBackup().addAll(UtilObjeto.clone(visao.getLista()));

            for (final Cheque cheque : visao.getListaChequesBackup()) {

                if (cheque.isForaPrazoMaximo() && cheque.isForaPrazoMinimo() && !cheque.isForaValorMaximo()
                        && UtilString.isVazio(cheque.getCoContrato())) {

                    visao.getListaChequesUtilizados().add(UtilObjeto.clone(cheque));
                }
            }

            visao.getLista().clear();

            visao.getLista().addAll(visao.getListaChequesUtilizados());
        }
    }

    /**
     * <p>
     * Método responsável por verificar o cheque está foraValorMaximo eq false
     * foraPrazominimo eq False e foraPrazoMaximo eq true.
     * <p>
     *
     * @param visao
     *            valor a ser atribuído
     * @param foraPrazoMinimo
     *            valor a ser atribuído
     * @param foraPrazoMaximo
     *            valor a ser atribuído
     * @param foraValorMaximo
     *            valor a ser atribuído
     * @param mostarChequesUtilizados
     *            valor a ser atribuído
     * @author Leandro S. Oliveira
     */
    private void verificarFPMaximoTrueFVMFalseFPMFalse(final DetalheChequeVisao visao, final boolean foraPrazoMinimo, final boolean foraPrazoMaximo,
            final boolean foraValorMaximo, final boolean mostarChequesUtilizados) {

        if (foraPrazoMaximo && !foraValorMaximo && !foraPrazoMinimo && !mostarChequesUtilizados) {

            visao.getListaChequesBackup().clear();

            visao.getListaChequesBackup().addAll(UtilObjeto.clone(visao.getLista()));

            for (final Cheque cheque : visao.getListaChequesBackup()) {

                if (cheque.isForaPrazoMaximo() && !cheque.isForaValorMaximo() && !cheque.isForaPrazoMinimo()
                        && UtilString.isVazio(cheque.getCoContrato())) {

                    visao.getListaChequesUtilizados().add(UtilObjeto.clone(cheque));
                }
            }

            visao.getLista().clear();

            visao.getLista().addAll(visao.getListaChequesUtilizados());
        }
    }

    /**
     * <p>
     * Método responsável por verificar o cheque está foraValorMaximo eq false
     * foraPrazominimo eq true e foraPrazoMaximo eq false.
     * <p>
     *
     * @param visao
     *            valor a ser atribuído
     * @param foraPrazoMinimo
     *            valor a ser atribuído
     * @param foraPrazoMaximo
     *            valor a ser atribuído
     * @param foraValorMaximo
     *            valor a ser atribuído
     * @param mostarChequesUtilizados
     *            valor a ser atribuído
     * @author Leandro S. Oliveira
     */
    private void verificarFPMininoTrueFPMaximoFalseFVMFalse(final DetalheChequeVisao visao, final boolean foraPrazoMinimo,
            final boolean foraPrazoMaximo, final boolean foraValorMaximo, final boolean mostarChequesUtilizados) {

        if (foraPrazoMinimo && !foraPrazoMaximo && !foraValorMaximo && !mostarChequesUtilizados) {

            visao.getListaChequesBackup().clear();

            visao.getListaChequesBackup().addAll(UtilObjeto.clone(visao.getLista()));

            // verifica se os cheques estão fora do prazo minimo permitido
            for (final Cheque cheque : visao.getListaChequesBackup()) {

                if (cheque.isForaPrazoMinimo() && !cheque.isForaPrazoMaximo() && !cheque.isForaValorMaximo()
                        && UtilString.isVazio(cheque.getCoContrato())) {

                    visao.getListaChequesUtilizados().add(UtilObjeto.clone(cheque));
                }
            }

            visao.getLista().clear();

            visao.getLista().addAll(visao.getListaChequesUtilizados());
        }
    }

    /**
     * <p>
     * Método responsável por verificar se a listaChequesBackup está mais
     * completa que a listaCheque original.
     * <p>
     *
     * <p>
     * e atribui a listaBackup para a listaCheque
     * <p>
     *
     * @param visao
     *            valor a ser atribuído
     * @author Leandro S. Oliveira
     */
    private void restaurarListaChequePrincipal(final DetalheChequeVisao visao) {

        if (visao.getListaChequesBackup().size() > visao.getLista().size()) {

            visao.getLista().clear();

            visao.getLista().addAll(UtilObjeto.clone(visao.getListaChequesBackup()));

        }
    }

    /**
     * <p>
     * Método responsável por retornar a lista de cheques de acordo com as
     * contas correntes do contrato.
     * <p>
     *
     * @author Caio Graco
     */
    private void listarCheques() {

        final DetalheChequeVisao visao = this.getVisao();
        final int prazoMinimoPermitido;
        final HttpServletRequest request;
        Date dataMaximaPermitida;
        final Collection<GarantiaContrato> listaGarantiaCheque = this.getService()
                .validarGarantiaCheque(visao.getContrato().getGarantiaContratoList());

        GarantiaContrato garantiaContrato = null;

        if (!UtilObjeto.isVazio(listaGarantiaCheque)) {
            garantiaContrato = listaGarantiaCheque.iterator().next();
        }

        if (garantiaContrato != null) {
            prazoMinimoPermitido = garantiaContrato.getVrPrazoMinimoPermitido().intValue();
            dataMaximaPermitida = this.getDataMaximaPermitida(visao.isForaPrazoMaximo(), garantiaContrato);
            visao.getLista().clear();
            visao.setLista(this.getService()
                    .listarPorContaCorrente(this.contratoService.listarContaContratoPorNumeroContrato(visao.getContrato().getNuContrato())));

            if (!visao.isForaPrazoMinimo() && !visao.isForaPrazoMaximo()) {
                dataMaximaPermitida = this.getDataMaximaPermitida(Boolean.TRUE, garantiaContrato);
            }

            this.verificarItensForaDosParametros(garantiaContrato, prazoMinimoPermitido, dataMaximaPermitida);

            request = (HttpServletRequest) FacesContext.getCurrentInstance().getExternalContext().getRequest();
            @SuppressWarnings("unchecked")
            final Map<String, String> mapaOperacaoSistema = (Map<String, String>) request.getSession().getAttribute("mapaOperacaoSistema");
            this.getService().atribuirContratoCheque(visao.getLista(), mapaOperacaoSistema);
        }
    }

    /**
     * <p>
     * Método responsável por retornar a Data máxima Permitida para o Cheque.
     * <p>
     *
     * @param foraPrazoMaximo
     *            valor a ser atribuído
     * @param garantiaContrato
     *            valor a ser atribuído
     * @return <code>Date</code>
     * @author Leandro S. Oliveira
     */
    private Date getDataMaximaPermitida(final Boolean foraPrazoMaximo, final GarantiaContrato garantiaContrato) {

        if (foraPrazoMaximo && UtilObjeto.isReferencia(garantiaContrato) && UtilObjeto.isReferencia(garantiaContrato.getVrPrazoMaximoPermitido())) {

            return UtilData.somarSubtrairDias(UtilData.converterDataSemHoras(new Date()), garantiaContrato.getVrPrazoMaximoPermitido().intValue());
        }

        return null;
    }

    /**
     * <p>
     * Retorna para a página de análise do contrato.
     * <p>
     *
     * @return String
     * @author Caio Graco
     */
    public String voltarRelatorio() {
        return this.getVisao().getPaginaOrigem();
    }

    /**
     * <p>
     * Método responsável por carregar os cheques de acordo com a seleção da
     * checkbox.
     * <p>
     *
     * @param visao
     *            valor a ser atribuído
     * @author Caio Graco
     */
    public void carregarCheques(final DetalheChequeVisao visao) {

        this.restaurarListaChequePrincipal(visao);

        visao.getListaChequesBackup().clear();

        visao.getListaChequesBackup().addAll(UtilObjeto.clone(visao.getLista()));

        visao.getListaChequesUtilizados().clear();

        for (final Cheque cheque : visao.getLista()) {

            if (!UtilString.isVazio(cheque.getCoContrato()) && !visao.isForaPrazoMaximo() && !visao.isForaPrazoMinimo()
                    && !visao.isForaValorMaximo()) {

                visao.getListaChequesUtilizados().add(UtilObjeto.clone(cheque));
            }
        }

        visao.getLista().clear();

        visao.getLista().addAll(visao.getListaChequesUtilizados());
    }
}
