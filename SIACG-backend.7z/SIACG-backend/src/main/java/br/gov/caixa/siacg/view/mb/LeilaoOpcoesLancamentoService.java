package br.gov.caixa.siacg.view.mb;

import java.io.Serializable;

import br.gov.caixa.siacg.model.domain.leilao.Leilao;

public interface LeilaoOpcoesLancamentoService extends Serializable {

    public void iniciar(Leilao leilao);

}
