/**
 * Copyright (c) 2015 Caixa Econômica Federal. Todos os direitos
 * reservados.
 *
 * Caixa Econômica Federal - SIACG - Sistema de Crédito Rural
 *
 * Este software foi desenvolvido sob demanda da CAIXA e está
 * protegido por leis de direitos autorais e tratados internacionais. As
 * condições de cópia e utilização do todo ou partes dependem de autorização da
 * pessoa. Cópias não são permitidas sem expressa autorização. Não pode ser
 * comercializado ou utilizado para propósitos particulares.
 *
 * Uso exclusivo da Caixa Econômica Federal. A reprodução ou distribuição não
 * autorizada deste programa ou de parte dele, resultará em punições civis e
 * criminais e os infratores incorrem em sanções previstas na legislação em
 * vigor.
 *
 * Histórico do Subversion:
 *
 * LastChangedRevision: $Revision$
 * LastChangedBy: $Author$
 * LastChangedDate: $Date$
 *
 * HeadURL: $HeadURL$
 *
 */
package br.gov.caixa.siacg.view.form;

import java.util.Arrays;
import java.util.List;

import br.gov.caixa.pedesgo.arquitetura.visao.ManutencaoVisao;
import br.gov.caixa.siacg.model.domain.GrupoGarantia;
import br.gov.caixa.siacg.model.enums.AcompanhadaEnum;
import br.gov.caixa.siacg.model.enums.TrueFalseEnum;
import br.gov.caixa.siacg.model.vo.FiltroGrupoGarantiaVO;
import br.gov.caixa.siacg.view.mb.GrupoGarantiaMB;

/**
 * <p>
 * GrupoGarantiaVisao
 * </p>
 * <p>
 * Descrição: classe de visão auxiliar da classe bean
 * {@link GrupoGarantiaMB}.
 * </p>
 * <br>
 * <b>Empresa:</b> Cef - Caixa Econômica Federal
 *
 * @author Marco Isecke
 * @version 1.0
 */
public class GrupoGarantiaVisao extends ManutencaoVisao<GrupoGarantia> {

    private static final long serialVersionUID = 593582620800212276L;

    private List<GrupoGarantia> listaGrupoGarantia;
    private FiltroGrupoGarantiaVO filtro;

    /**
     * @see br.gov.caixa.pedesgo.arquitetura.visao.ManutencaoVisao#getEntidade()
     */
    @Override
    public GrupoGarantia getEntidade() {
        if (super.getEntidade() == null) {
            super.setEntidade(new GrupoGarantia());
        }
        return super.getEntidade();
    }

	/**
	 * @return the listaGrupoGarantia
	 */
	public List<GrupoGarantia> getListaGrupoGarantia() {
		return listaGrupoGarantia;
	}

	/**
	 * @param listaGrupoGarantia the listaGrupoGarantia to set
	 */
	public void setListaGrupoGarantia(List<GrupoGarantia> listaGrupoGarantia) {
		this.listaGrupoGarantia = listaGrupoGarantia;
	}

	/**
	 * @return the isAtivoOpcoes
	 */
	public List<TrueFalseEnum> getAtivoOpcoes() {
		return Arrays.asList(TrueFalseEnum.values());
	}
	
	/**
	 * @return the isAcompanhadasOpcoes
	 */
	public List<AcompanhadaEnum> getAcompanhadaOpcoes() {
		return Arrays.asList(AcompanhadaEnum.values());
	}

	/**
	 * @return the filtro
	 */
	public FiltroGrupoGarantiaVO getFiltro() {
		if(this.filtro == null) {
			filtro = new FiltroGrupoGarantiaVO();
		}
		return filtro;
	}

	/**
	 * @param filtro the filtro to set
	 */
	public void setFiltro(FiltroGrupoGarantiaVO filtro) {
		this.filtro = filtro;
	}
	
	
}