package br.gov.caixa.siacg.view.form;

import java.util.List;

import org.apache.commons.collections.CollectionUtils;

import br.gov.caixa.pedesgo.arquitetura.visao.ManutencaoVisao;
import br.gov.caixa.siacg.model.domain.Titulo;

/**
 * <p>
 * TituloVisao
 * </p>
 * <p>
 * Descrição: Classe de visão para o Bean Gerenciado TituloMB.
 * </p>
 * <br>
 * <b>Empresa:</b> Cef - Caixa Econômica Federal
 *
 * @author Brunno Antunes
 * @version 1.0
 */

public class TituloVisao extends ManutencaoVisao<Titulo> {

	private static final long serialVersionUID = 813641756574259628L;
	
	/** Atributo cedente. */
	private String cedente;
	/** Atributo sacado. */
	private String sacado;
	/** Atributo nossoNumero. */
	private String nossoNumero;
	/** Atributo Filtro Selecionado. */
	private Integer nuFiltroSelecionado;
	/** Atributo lista de titulos. */
	private List<Titulo> listaConsultaTitulos;	
	 /** Atributo quantidadeItens. */
    private Integer quantidadeItens;
    /** Atributo opcao cedente. */
    private String opcaoCedente = "1";
    /** Atributo opcao sacado. */
    private String opcaoSacado = "1";
    /** Atributo ativa Campo. */
    private boolean ativaCampo = true;
    /** Atributo ativa Campo sacado. */
    private boolean ativaCampoSacado = true;

	public String getCedente() {
		return cedente;
	}

	public void setCedente(String cedente) {
		this.cedente = cedente;
	}

	public String getSacado() {
		return sacado;
	}

	public void setSacado(String sacado) {
		this.sacado = sacado;
	}

	public String getNossoNumero() {
		return nossoNumero;
	}

	public void setNossoNumero(String nossoNumero) {
		this.nossoNumero = nossoNumero;
	}

	public Integer getNuFiltroSelecionado() {
		return nuFiltroSelecionado;
	}

	public void setNuFiltroSelecionado(Integer nuFiltroSelecionado) {
		this.nuFiltroSelecionado = nuFiltroSelecionado;
	}
	
	public List<Titulo> getListaConsultaTitulos() {
		return listaConsultaTitulos;
	}

	public void setListaConsultaTitulos(List<Titulo> listaConsultaTitulos) {
		this.listaConsultaTitulos = listaConsultaTitulos;
	}

	public String getOpcaoCedente() {
		return this.opcaoCedente;
	}

	public void setOpcaoCedente(String opcaoCedente) {
	this.opcaoCedente = opcaoCedente;}

	
	 public boolean isAtivaCampo() {
		return this.ativaCampo;
	}

	public void setAtivaCampo(boolean ativaCampo) {
	this.ativaCampo = ativaCampo;}

	/**
	 * <p>Retorna o valor do atributo opcaoSacado</p>.
	 *
	 * @return opcaoSacado
	*/
	public String getOpcaoSacado() {
		return this.opcaoSacado;
	}

	/**
	 * <p>Define o valor do atributo opcaoSacado</p>.
	 *
	 * @param opcaoSacado valor a ser atribuído
	*/
	public void setOpcaoSacado(String opcaoSacado) {
		this.opcaoSacado = opcaoSacado;}
	
	

	/**
	 * <p>Retorna o valor do atributo ativaCampoSacado</p>.
	 *
	 * @return ativaCampoSacado
	*/
	public boolean isAtivaCampoSacado() {
		return this.ativaCampoSacado;
	}

	/**
	 * <p>Define o valor do atributo ativaCampoSacado</p>.
	 *
	 * @param ativaCampoSacado valor a ser atribuído
	*/
	public void setAtivaCampoSacado(boolean ativaCampoSacado) {
	this.ativaCampoSacado = ativaCampoSacado;}

	/**
     * <p>
     * Método responsável por mostrar a quantidade de itens da tabela.
     * <p>
     *
     * @author Brunno Antunes
     */
	public Integer getQuantidadeItens() {
	    if (CollectionUtils.isNotEmpty(this.listaConsultaTitulos)) {
	        this.quantidadeItens = this.listaConsultaTitulos.size();
	    } else {
	        this.quantidadeItens = 0;
	    }
	
	    return this.quantidadeItens;
    }

	public void setQuantidadeItens(Integer quantidadeItens) {
		this.quantidadeItens = quantidadeItens;
	}
	
    /**
     * <p>
     * Método responsável por selecionar o tipo de cedente.
     * <p>
     *
     * @author Brunno Antunes
     */
	
	public void campoCedente() {
		if(this.opcaoCedente.equals("1")) {
			this.ativaCampo = true;
		} else {
			this.ativaCampo = false;
		}
	}
	
	/**
	 * <p>
	 * Método responsável por selecionar o tipo de busca campo Sacado.
	 * <p>
	 *
	 * @author Brunno Antunes
	 */
	
	public void campoSacado() {
		if(this.opcaoSacado.equals("1")) {
			this.ativaCampoSacado = true;
		} else {
			this.ativaCampoSacado = false;
		}
	}
	
		
}
