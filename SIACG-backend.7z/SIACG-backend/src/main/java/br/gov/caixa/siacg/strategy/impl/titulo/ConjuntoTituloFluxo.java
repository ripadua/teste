/**
 * Copyright (c) 2018 Caixa Econômica Federal. Todos os direitos
 * reservados.
 *
 * Caixa Econômica Federal - SIACG
 *
 * Este software foi desenvolvido sob demanda da CAIXA e está
 * protegido por leis de direitos autorais e tratados internacionais. As
 * condições de cópia e utilização total ou partes dependem de autorização da
 * empresa. Cópias não são permitidas sem expressa autorização. Não pode ser
 * comercializado ou utilizado para propósitos particulares.
 *
 * Uso exclusivo da Caixa Econômica Federal. A reprodução ou distribuição não
 * autorizada deste programa ou de parte dele, resultará em punições civis e
 * criminais e os infratores incorrem em sanções previstas na legislação em
 * vigor.
 *
 * Histórico do TFS:
 *
 * LastChangedRevision: $Revision$
 * LastChangedBy: $Author$
 * LastChangedDate: $Date$
 *
 * HeadURL: $HeadURL$
 *
 */
package br.gov.caixa.siacg.strategy.impl.titulo;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import br.gov.caixa.siacg.comum.to.ContratoCalculoTO;
import br.gov.caixa.siacg.model.domain.Contrato;
import br.gov.caixa.siacg.model.domain.Titulo;

/**
 * <p>
 * ConjuntoTituloFluxo
 * </p>
 *
 * <p>
 * Descrição: Classe que representa um conjunto de titulos de fluxo
 * </p>
 *
 * <br>
 * <b>Empresa:</b> Cef - Caixa Econômica Federal
 *
 *
 * @author p541915
 *
 * @version 1.0
 */
public class ConjuntoTituloFluxo extends ConjuntoTitulo {

    /** Atributo totalDuplicatasNaoPagas. */
    private BigDecimal totalDuplicatasNaoPagas = BigDecimal.ZERO;

    /** Atributo totalValorApurado. */
    private BigDecimal totalValorApurado = BigDecimal.ZERO;

    /** Atributo totalValorOutrosContratos. */
    private BigDecimal totalValorOutrosContratos = BigDecimal.ZERO;

    /** Atributo valorDuplicatasForaValorMaximo. */
    private BigDecimal valorDuplicatasForaValorMaximo = BigDecimal.ZERO;

    /** Atributo valorDuplicatasForaPercentualMaximo. */
    private BigDecimal valorDuplicatasForaPercentualMaximo = BigDecimal.ZERO;

    /** Atributo listaTituloASalvar. */
    private List<Titulo> listaTituloASalvar = new ArrayList<>();

    /** Atributo contrato. */
    private ContratoCalculoTO contrato;

    /** Atributo vrEsperado. */
    private BigDecimal vrEsperado;

    /**
     * Responsável pela criação de novas instâncias desta classe.
     *
     * @param contrato
     * @param vrEsperado
     *
     */
    public ConjuntoTituloFluxo(ContratoCalculoTO contrato, BigDecimal vrEsperado) {
	this.contrato = contrato;
	this.vrEsperado = vrEsperado;
    }

    /**
     * <p>
     * Método responsável por realizar os calculos de titulos de fluxo
     * </p>
     * .
     *
     * @author p541915
     *
     */
    public void calcular() {
	for (Titulo titulo : getTitulos()) {
	    if (validarTituloParaContratoInformado(contrato, titulo)) {
		// Verfica se o titulo não está pago
		if (!titulo.isTituloLiquidado()) {
		    totalDuplicatasNaoPagas = totalDuplicatasNaoPagas.add(titulo.getVrTitulo());
		} else {
		    // Consome o valor do titulo
		    if (!contrato.isPreAnalise() && totalValorApurado.compareTo(vrEsperado) < 0) {
			titulo.setContrato(new Contrato(contrato.getNuContrato()));

			listaTituloASalvar.add(titulo);

			totalValorApurado = totalValorApurado.add(titulo.getVrTitulo());
		    }
		}
	    } else {
		totalValorOutrosContratos = totalValorOutrosContratos.add(titulo.getVrTitulo());
	    }
	}
    }

    /**
     * <p>
     * Método responsável por validar se o titulo está marcado para algum
     * contrato diferente do informado.
     * <p>
     *
     * @param contrato
     *            valor a ser atribuido
     * @param titulo
     *            valor a ser atribuido
     * @return boolean
     * @author guilherme.santos
     */
    private boolean validarTituloParaContratoInformado(final ContratoCalculoTO contrato, final Titulo titulo) {
	return titulo.getNuContrato() == null || titulo.getNuContrato().equals(contrato.getNuContrato());
    }

    /**
     * Retorna o valor do atributo listaTituloASalvar.
     *
     * @return valor
     */
    public List<Titulo> getListaTituloASalvar() {
	return this.listaTituloASalvar;
    }

    /**
     * <p>
     * Método responsável por obter o valor dos itens fora dos parametros
     * </p>
     * .
     *
     * @author p541915
     *
     * @return
     */
    public BigDecimal getValorItensForaParametros() {
	return this.valorDuplicatasForaValorMaximo.add(this.valorDuplicatasForaPercentualMaximo);
    }

    /**
     * Retorna o valor do atributo totalDuplicatasNaoPagas.
     *
     * @return valor
     */
    public BigDecimal getTotalDuplicatasNaoPagas() {
	return this.totalDuplicatasNaoPagas;
    }

    /**
     * Retorna o valor do atributo totalValorOutrosContratos.
     *
     * @return valor
     */
    public BigDecimal getTotalValorOutrosContratos() {
	return this.totalValorOutrosContratos;
    }

    /**
     * Retorna o valor do atributo totalValorApurado.
     *
     * @return valor
     */
    public BigDecimal getTotalValorApurado() {
	return this.totalValorApurado;
    }
}
