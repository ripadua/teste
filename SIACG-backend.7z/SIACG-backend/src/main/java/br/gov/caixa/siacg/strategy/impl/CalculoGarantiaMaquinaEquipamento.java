package br.gov.caixa.siacg.strategy.impl;

import java.math.BigDecimal;
import java.util.Date;

import javax.ejb.Stateless;

import br.gov.caixa.pedesgo.arquitetura.util.UtilData;
import br.gov.caixa.siacg.model.vo.ParametrosCalculoGarantiaVO;
import br.gov.caixa.siacg.model.vo.RelatorioAnaliseContratoVO;
import br.gov.caixa.siacg.strategy.CalculoGarantia;

/**
 * <p>
 * CalculoGarantiaMaquinaEquipamento
 * </p>
 * <p>
 * Descrição: Implementação do calculo para Garantia do tipo
 * Máquina/Equipamento.
 * </p>
 * <br>
 * <b>Empresa:</b> Cef - Caixa Econômica Federal
 *
 * @author guilherme.santos
 * @author Mábio Barbosa
 * @version 1.0
 */
@Stateless(mappedName = "CalculoGarantiaMaquinaEquipamento")
public class CalculoGarantiaMaquinaEquipamento implements CalculoGarantia {

    private static final long serialVersionUID = 7170040531431287763L;

    private static final BigDecimal VR_FIXO = BigDecimal.valueOf(0.009489);

    /**
     * @see br.gov.caixa.siacg.strategy.CalculoGarantia#calcular(br.gov.caixa.siacg.model.vo.ParametrosCalculoGarantiaVO)
     */
    @Override
    public RelatorioAnaliseContratoVO calcular(final ParametrosCalculoGarantiaVO parametrosCalculo, final RelatorioAnaliseContratoVO relatorio) {
	// ----------------------------------------------------------------------
	// Calculo de depreciação do bem
	// ----------------------------------------------------------------------
	// DM = Diferença de meses entre Data da Contratação e Data da Apuração
	// (Potência. Ex.: - x³)
	// VP = Valor Pactuado da garantia (valor garantia informado)
	// VC = Valor Constituído (valor apurado após o cálculo)
	// ----------------------------------------------------------------------
	// VC = VP - (VP * (1 - (1 - 0,009489) DM))
	// ----------------------------------------------------------------------

	Long diferenca = UtilData.diferencaEmMesesEntreDatas(parametrosCalculo.getContrato().getDtContrato(), new Date());
	BigDecimal vrGarantia = parametrosCalculo.getGarantiaContrato().getVrGarantia();

	if (BigDecimal.valueOf(diferenca).compareTo(BigDecimal.ZERO) == 0) {
	    relatorio.setValorApurado(vrGarantia);

	} else {
	    BigDecimal vrApurado = vrGarantia
		    .subtract(vrGarantia.multiply(BigDecimal.ONE.subtract(BigDecimal.ONE.subtract(VR_FIXO).pow(diferenca.intValue()))));
	    relatorio.setValorApurado(vrApurado);
	}

	relatorio.setValorAlienacaoEquipamentos(
		relatorio.getValorAlienacaoEquipamentos().add(relatorio.getValorApurado()));

	return relatorio;
    }
}
