package br.gov.caixa.siacg.util.xsd;

import java.io.IOException;
import java.io.StringReader;
import java.io.StringWriter;
import java.io.Writer;
import java.util.Calendar;

import javax.xml.XMLConstants;
import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;
import javax.xml.bind.Unmarshaller;
import javax.xml.datatype.DatatypeConfigurationException;
import javax.xml.datatype.DatatypeConstants;
import javax.xml.datatype.DatatypeFactory;
import javax.xml.datatype.XMLGregorianCalendar;
import javax.xml.transform.Source;
import javax.xml.transform.stream.StreamSource;
import javax.xml.validation.Schema;
import javax.xml.validation.SchemaFactory;
import javax.xml.validation.Validator;

import org.xml.sax.SAXException;

import br.gov.caixa.pedesgo.arquitetura.util.UtilObjeto;
import br.gov.caixa.siacg.commons.XMLInvalidoException;
import br.gov.caixa.siacg.util.LogCEF;

/**
 * <p>
 * XmlUtil
 * </p>
 * <p>
 * Descrição: Classe útil responsável por manipular xmls - <i>converte-los em
 * objeto e vice-versa, ou validá-los </i> - bem como armazenar os xsds
 * utilizados na validação dos mesmos.
 * </p>
 * <br>
 * <b>Empresa:</b> Cef - Caixa Econômica Federal
 *
 * @author guilherme.santos
 * @version 1.0
 */
public class XmlUtil {

    /** Constante XSD_CONSULTA_CLIENTE. */
    public static final String XSD_CONSULTA_CLIENTE = "sicli/sibar/consultacliente/ServicoConsultaCliente.xsd";

    private XmlUtil() {
	throw new IllegalStateException("Classe de Utilidade");
    }

    /**
     *
     * <p>
     * étodo responsável por validar o arquivo xml com o respectivo xsd
     * infomado.
     * <p>
     *
     * @param xml
     *            - xml a ser validado.
     * @param nomeArquivoXsd
     *            - nome do arquivo xsd que será utilizado para validação.
     * @throws XMLInvalidoException
     *             lanca excecao
     * @author guilherme.santos
     */
    public static void validarXml(final String xml, final String nomeArquivoXsd) throws XMLInvalidoException {

	if (!UtilObjeto.isReferencia(xml) || !UtilObjeto.isReferencia(nomeArquivoXsd)) {
	    throw new XMLInvalidoException("Não foi possível validar o xml, pois o mesmo está vazio ou o nome do arquivo xsd não foi informado.");
	}

	final Source arquivoSource = new StreamSource(new StringReader(xml));

	final SchemaFactory schemaFactory = SchemaFactory.newInstance(XMLConstants.W3C_XML_SCHEMA_NS_URI);

	try {

	    final Schema schema = schemaFactory.newSchema(XmlUtil.class.getResource(nomeArquivoXsd));
	    final Validator validator = schema.newValidator();
	    validator.validate(arquivoSource);

	} catch (SAXException | IOException e) {
	    throw new XMLInvalidoException("Xml inválido pelo motivo: ".concat(e.getMessage()), e);
	}
    }

    /**
     *
     * <p>
     * Método responsável por realizar o marshal: converter o objeto passado por
     * parâmetro em xml.
     * <p>
     *
     * @param object
     *            valor a ser atribuido
     * @return string xml
     * @author guilherme.santos
     */
    public static String converterParaXml(final Object object) {
	String xml = null;

	try {
	    final Writer writer = new StringWriter();
	    final JAXBContext context = JAXBContext.newInstance(object.getClass());
	    final Marshaller marshaller = context.createMarshaller();
	    marshaller.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, true);

	    writer.append("<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n");

	    marshaller.setProperty(Marshaller.JAXB_FRAGMENT, true);
	    marshaller.marshal(object, writer);

	    xml = writer.toString();


	} catch (JAXBException | IOException e) {
	    LogCEF.error(e);
	}

	return xml;
    }

    /**
     *
     * <p>
     * Método responsável por realizar o unMarshal: converter um xml em um
     * objeto do tipo passado por parâmetro.
     * <p>
     *
     * @param xml
     *            valor a ser atribuido
     * @param objeto
     *            valor a ser atribuido
     * @return objeto do tipo passado por parâmetro
     * @throws JAXBException
     * @author guilherme.santos
     */
    @SuppressWarnings("unchecked")
    public static <T> T converterParaObjeto(final String xml, final Class<T> objeto) {

	if (UtilObjeto.isReferencia(xml) && UtilObjeto.isReferencia(objeto)) {

	    try {

		final JAXBContext jaxbContext = JAXBContext.newInstance(objeto);
		final Unmarshaller jaxbUnmarshaller = jaxbContext.createUnmarshaller();
		final Object object = jaxbUnmarshaller.unmarshal(new StringReader(xml));

		return (T) object;

	    } catch (final JAXBException e) {
		LogCEF.error(e);
	    }
	}
	return null;
    }

    /**
     * <p>Método responsável por obter um XMLGregorianCalendar hoje</p>.
     *
     * @author p575337
     *
     * @return XMLGregorianCalendar
     */
    public static XMLGregorianCalendar getHojeSemHoras(){
	Calendar calendar = Calendar.getInstance();
	return getXMLGregorianCalendar(calendar.get(Calendar.DAY_OF_MONTH), (calendar.get(Calendar.MONTH)+1), calendar.get(Calendar.YEAR));
    }

    /**
     * <p>Método responsável por obter um novo XMLGregorianCalendar</p>.
     *
     * @author p575337
     *
     * @param dia 
     * @param mes 1 - Janeiro ... 12 -Dezembro
     * @param ano
     * @return XMLGregorianCalendar
     */
    public static XMLGregorianCalendar getXMLGregorianCalendar(int dia, int mes, int ano){
	XMLGregorianCalendar data;
	try {
	    data = DatatypeFactory.newInstance().newXMLGregorianCalendar(ano, mes, dia, 0, 0, 0, 0, DatatypeConstants.FIELD_UNDEFINED);
	} catch (DatatypeConfigurationException e) {
	    LogCEF.error(e);
	    data = null;
	}
	return data;
    }
}
