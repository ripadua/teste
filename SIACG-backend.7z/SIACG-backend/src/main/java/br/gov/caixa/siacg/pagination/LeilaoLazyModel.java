package br.gov.caixa.siacg.pagination;

import java.util.List;
import java.util.Map;

import javax.ejb.EJB;
import javax.enterprise.context.SessionScoped;
import javax.inject.Named;

import org.primefaces.model.SortOrder;

import br.gov.caixa.pedesgo.arquitetura.paginacao.Paginacao;
import br.gov.caixa.pedesgo.arquitetura.paginacao.PaginacaoDemanda;
import br.gov.caixa.pedesgo.arquitetura.util.UtilObjeto;
import br.gov.caixa.siacg.model.domain.leilao.Leilao;
import br.gov.caixa.siacg.model.vo.FiltroLeilaoVO;
import br.gov.caixa.siacg.service.LeilaoService;

@Named
@SessionScoped
public class LeilaoLazyModel extends Paginacao<Leilao> {

    private static final long serialVersionUID = 1L;

    public static final String NOME_MANAGED_BEAN = "leilaoLazyModel";

    public static final String EL_MANAGED_BEAN = "#{leilaoLazyModel}";

    @EJB
    private transient LeilaoService service;

    private transient FiltroLeilaoVO filtro;

    @Override
    public List<Leilao> load(int inicio, int fim, String campoOrdenacao, SortOrder ordenacao, Map<String, String> parametros) {

	final PaginacaoDemanda<Leilao> resultado = this.service.listarLeilao(this.filtro, inicio, fim);

	super.setWrappedData(resultado.getLista());
	super.setRowCount(resultado.getQuantidadeRegistros());

	return resultado.getLista();

    }

    @Override
    public LeilaoService getServico() {
	return this.service;

    }

    public void limparFiltro() {
	this.getFiltro().setCpfCnpj(null);
	this.getFiltro().setCoContrato(null);
    }

    public FiltroLeilaoVO getFiltro() {
	if (!UtilObjeto.isReferencia(this.filtro)) {
	    this.filtro = new FiltroLeilaoVO();
	}

	return this.filtro;
    }

    public void setFiltro(FiltroLeilaoVO filtro) {
	this.filtro = filtro;
    }

}
