package br.gov.caixa.siacg.view.form;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

import br.gov.caixa.pedesgo.arquitetura.util.UtilObjeto;
import br.gov.caixa.siacg.model.domain.TemplateMensageria;
import br.gov.caixa.siacg.model.enums.CampoSelecionavelEnum;
import br.gov.caixa.siacg.model.enums.DestinatarioEnum;
import br.gov.caixa.siacg.model.enums.NivelEnum;
import br.gov.caixa.siacg.view.mb.TemplateMensageriaMB;

/**
 * <p>
 * TemplateMensageriaVisao
 * </p>
 * <p>
 * Descrição: Classe de visao auxiliar da classe bean
 * {@link TemplateMensageriaMB} responsável por armazenar os objetos(gets e
 * sets).
 * </p>
 * <br>
 * <b>Empresa:</b> Cef - Caixa Econômica Federal
 *
 * @author Waltenes Junior
 * @version 1.0
 */
public class TemplateMensageriaVisao extends TemplateVisao<TemplateMensageria> {

    private static final long serialVersionUID = 7326131024521848735L;

    private String campoSelecionavelSelecionado;

    private Collection<String> listaAEnviar;

    private Collection<String> listaCopiaAEnviar;

    private TemplateMensageria entidadeExclusao;

    private String migalha;

    private String urlSemsgServicoMensageria;

    private List<NivelEnum> listaNivelEnum;

    /**
     * Retorna o valor do atributo listaNivelEnum.
     *
     * @return listaNivelEnum
     */
    public List<NivelEnum> getListaNivelEnum() {

        if (UtilObjeto.isVazio(this.listaNivelEnum)) {

            this.listaNivelEnum = new ArrayList<NivelEnum>();

            for (final NivelEnum nivelEnum : NivelEnum.values()) {

                if (!"0".equals(nivelEnum.getCodigo())) {

                    this.listaNivelEnum.add(nivelEnum);
                }
            }

        }

        return this.listaNivelEnum;
    }

    /**
     * <p>
     * Método responsável por obter o array de destinatarios.
     * <p>
     *
     * @return DestinatarioEnum[]
     * @author Waltenes Junior
     */
    public DestinatarioEnum[] getArrayDestinatario() {
        return DestinatarioEnum.values();
    }

    /**
     * <p>
     * Método responsável por obter o array de destinatarios.
     * <p>
     *
     * @return DestinatarioEnum[]
     * @author Waltenes Junior
     */
    public DestinatarioEnum[] getArrayDestinatarioCopia() {
        return DestinatarioEnum.values();
    }

    /**
     * <p>
     * Método responsável por obter o array de campo selacionavel.
     * <p>
     *
     * @return CampoSelecionavelEnum[]
     * @author Waltenes Junior
     */
    public CampoSelecionavelEnum[] getArrayCampoSelecionavel() {
        return CampoSelecionavelEnum.values();
    }

    /**
     * Retorna o valor do atributo campoSelecionavelSelecionado.
     *
     * @return campoSelecionavelSelecionado
     */
    public String getCampoSelecionavelSelecionado() {

        if (!UtilObjeto.isReferencia(this.campoSelecionavelSelecionado)) {

            this.campoSelecionavelSelecionado = "";
        }

        return this.campoSelecionavelSelecionado;
    }

    /**
     * Define o valor do atributo campoSelecionavelSelecionado.
     *
     * @param campoSelecionavelSelecionado
     *            valor a ser atribuído
     */
    public void setCampoSelecionavelSelecionado(final String campoSelecionavelSelecionado) {
        this.campoSelecionavelSelecionado = campoSelecionavelSelecionado;
    }

    /**
     * Retorna o valor do atributo listaAEnviar.
     *
     * @return listaAEnviar
     */
    public Collection<String> getListaAEnviar() {
        if (!UtilObjeto.isReferencia(this.listaAEnviar)) {
            this.listaAEnviar = new ArrayList<String>();
        }
        return this.listaAEnviar;
    }

    /**
     * Define o valor do atributo listaAEnviar.
     *
     * @param listaAEnviar
     *            valor a ser atribuído
     */
    public void setListaAEnviar(final Collection<String> listaAEnviar) {
        this.listaAEnviar = listaAEnviar;
    }

    /**
     * Retorna o valor do atributo listaCopiaAEnviar.
     *
     * @return listaCopiaAEnviar
     */
    public Collection<String> getListaCopiaAEnviar() {
        if (!UtilObjeto.isReferencia(this.listaCopiaAEnviar)) {
            this.listaCopiaAEnviar = new ArrayList<String>();
        }

        return this.listaCopiaAEnviar;
    }

    /**
     * Define o valor do atributo listaCopiaAEnviar.
     *
     * @param listaCopiaAEnviar
     *            valor a ser atribuído
     */
    public void setListaCopiaAEnviar(final Collection<String> listaCopiaAEnviar) {
        this.listaCopiaAEnviar = listaCopiaAEnviar;
    }

    /**
     * Retorna o valor do atributo entidadeExclusao.
     *
     * @return entidadeExclusao
     */
    public TemplateMensageria getEntidadeExclusao() {

        return this.entidadeExclusao;
    }

    /**
     * Define o valor do atributo entidadeExclusao.
     *
     * @param entidadeExclusao
     *            valor a ser atribuído
     */
    public void setEntidadeExclusao(final TemplateMensageria entidadeExclusao) {

        this.entidadeExclusao = entidadeExclusao;
    }

    /**
     * Retorna o valor do atributo migalha.
     *
     * @return migalha
     */
    public String getMigalha() {
        return this.migalha;
    }

    /**
     * Define o valor do atributo migalha.
     *
     * @param migalha
     *            valor a ser atribuído
     */
    public void setMigalha(final String migalha) {
        this.migalha = migalha;
    }

    /**
     * Retorna o valor do atributo urlSemsgServicoMensageria.
     *
     * @return urlSemsgServicoMensageria
     */
    public String getUrlSemsgServicoMensageria() {
        return this.urlSemsgServicoMensageria;
    }

    /**
     * Define o valor do atributo urlSemsgServicoMensageria.
     *
     * @param urlSemsgServicoMensageria
     *            valor a ser atribuído
     */
    public void setUrlSemsgServicoMensageria(final String urlSemsgServicoMensageria) {
        this.urlSemsgServicoMensageria = urlSemsgServicoMensageria;
    }
}
