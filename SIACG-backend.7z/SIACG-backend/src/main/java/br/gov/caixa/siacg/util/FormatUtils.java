/**
 * reservados.
 * Copyright (c) 2009-2011 Caixa Econômica Federal. Todos os direitos
 *
 * Caixa Econômica Federal - SIACG – Sistema de Acompanhamento de Carteiras de Cobrança
 *
 * Este programa de computador foi desenvolvido sob demanda da CAIXA e está
 * protegido por leis de direitos autorais e tratados internacionais. As
 * condições de cópia e utilização do total ou partes dependem de autorização da
 * pessoa. Cópias não são permitidas sem expressa autorização. Não pode ser
 * comercializado ou utilizado para propósitos particulares.
 *
 * Uso exclusivo da Caixa Econômica Federal. A reprodução ou distribuição não
 * autorizada deste programa ou de parte dele, resultará em punições civis e
 * criminais e os infratores incorrem em sanções previstas na legislação em
 * vigor.
 *
 * Histórico do Subversion:
 *
 * LastChangedRevision:
 * LastChangedBy:
 * LastChangedDate:
 *
 * HeadURL:
 *
 */
package br.gov.caixa.siacg.util;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

/**
 * <p>
 * FormatUtils
 * </p>
 * <p>
 * Descrição: Classe FormatUtils
 * </p>
 * <br>
 * <b>Empresa:</b> Cef - Caixa Econômica Federal.
 *
 * @author GS Tecnologia
 * @version 1.0
 */
public class FormatUtils {

    /** Constante logger. */
    private static final Log LOGGER = LogFactory.getLog(FormatUtils.class);
    
    private FormatUtils() {
	throw new IllegalStateException("Classe de Utilidade");
    }

    /**
     * Retorna o nome abreviado da unidade (PADRÃO).
     *
     * @param paramSgUf
     *            valor a ser atribuido
     * @param paramTpUnidade
     *            valor a ser atribuido
     * @param paramSgUnidade
     *            valor a ser atribuido
     * @param paramSgLocalizacao
     *            valor a ser atribuido
     * @param paramNoUnidade
     *            valor a ser atribuido
     * @param paramSgTpUnidade
     *            valor a ser atribuido
     * @return String
     */
    public static String getNameForUnidade(final String paramSgUf, final Short paramTpUnidade, final String paramSgUnidade,
            final String paramSgLocalizacao, final String paramNoUnidade, final String paramSgTpUnidade) {
        final String sNoUnidade = (paramNoUnidade == null) ? "" : paramNoUnidade.trim();
        final String sSgTpUnidade = (paramSgTpUnidade == null) ? "" : paramSgTpUnidade.trim();
        final Short nTpUnidade = paramTpUnidade;
        final String sSgUf = (paramSgUf == null) ? "" : paramSgUf.trim();
        final String sSgUnidade = (paramSgUnidade == null) ? "" : paramSgUnidade.trim();
        final String sSgLocalizacao = (paramSgLocalizacao == null) ? "" : paramSgLocalizacao.trim();

        if (sNoUnidade.isEmpty()) {
            FormatUtils.LOGGER.error("Para formatar o nome de uma Unidade, o parâmetro noUnidade não pode ser vazio.");
            return "";
        }
        if (sSgTpUnidade.isEmpty()) {
            FormatUtils.LOGGER.error("Para formatar o nome de uma Unidade, o parâmetro sgTpUnidade não pode ser vazio.");
            return sNoUnidade.toUpperCase();
        }
        if (nTpUnidade < 1) {
            FormatUtils.LOGGER.error("Para formatar o nome de uma Unidade, o parâmetro tpUnidade não pode ser negativo.");
            return sNoUnidade.toUpperCase();
        }

        String strRetorno = "";

        if (nTpUnidade == 12 || nTpUnidade == 22 || nTpUnidade == 23 || nTpUnidade == 28 || nTpUnidade == 38 || nTpUnidade == 37 || nTpUnidade == 41
                || nTpUnidade == 43 || nTpUnidade == 44 || nTpUnidade == 46) {
            strRetorno = sSgUnidade.isEmpty() ? sNoUnidade : sSgUnidade;
        } else {
            if (nTpUnidade == 5 || nTpUnidade == 14 || nTpUnidade == 15 || nTpUnidade == 16 || nTpUnidade == 29 || nTpUnidade == 30
                    || nTpUnidade == 48 || nTpUnidade == 49) {
                final String retUF = sSgUf.isEmpty() ? sNoUnidade : sSgUf;
                final String retSgLocalizacao = sSgLocalizacao.isEmpty() ? sNoUnidade : sSgLocalizacao;
                final String retEsquerda = sSgUnidade.isEmpty() ? sNoUnidade : sSgUnidade;
                final String retDireita = sSgLocalizacao.isEmpty() ? retUF : retSgLocalizacao;

                strRetorno = String.format("%s/%s", retEsquerda, retDireita);
            } else {
                strRetorno = String.format("%s %s", sSgTpUnidade, sNoUnidade);
            }
        }

        return strRetorno.toUpperCase();
    }

    /**
     * Retorna o nome completo da unidade (conforme RN010 SIIAC).
     *
     * @param paramSgTpUnidade
     *            valor a ser atribuido
     * @param paramNoUnidade
     *            valor a ser atribuido
     * @return String
     */
    public static String getNameForUnidadeComplete(final String paramSgTpUnidade, final String paramNoUnidade) {
        final String sNoUnidade = (paramNoUnidade == null) ? "" : paramNoUnidade.trim();
        final String sSgTpUnidade = (paramSgTpUnidade == null) ? "" : paramSgTpUnidade.trim();
        if (sNoUnidade.isEmpty()) {
            FormatUtils.LOGGER.error("Para formatar o nome de uma Unidade, o parâmetro noUnidade não pode ser vazio.");
            return "";
        }
        if (sSgTpUnidade.isEmpty()) {
            FormatUtils.LOGGER.error("Para formatar o nome de uma Unidade, o parâmetro sgTpUnidade não pode ser vazio.");
            return sNoUnidade.toUpperCase();
        }
        return String.format("%s %s", sSgTpUnidade, sNoUnidade);
    }

    /**
     * Este metodo aplica a mascara em uma string (ex. maskApply("__.___-__*_",
     * "1234567891234") resulta: 12.345-67*891234
     *
     * @param mask
     *            valor a ser atribuido
     * @param value
     *            valor a ser atribuido
     * @return String
     */
    public static String applyMask(final String mask, final String value) {
        if (mask == null || mask.isEmpty()) {
            return value;
        }
        if (value == null || value.isEmpty()) {
            return "";
        }
        final int max = value.length() < (mask.length() - mask.replace("_", "").length()) ? value.length() : mask.length();
        final StringBuilder result = new StringBuilder(value);
        for (int i = 0; i < max; i++) {
            if (mask.charAt(i) != '_') {
                result.insert(i, mask.charAt(i));
            }
        }
        return result.toString();
    }

    /**
     * Método que recebe um número e a quantidade de zeros à esquerda que deve
     * conter.
     *
     * @param numero
     *            valor a ser atribuido
     * @param qtdZeros
     *            valor a ser atribuido
     * @return String
     */
    public static String numeroFormatado(final Integer numero, final Integer qtdZeros) {
        String retorno = "";

        final String aux = numero.toString();

        for (int m = 0; m < (qtdZeros - aux.length()); m++) {
            retorno = retorno.concat("0");
        }

        retorno = retorno.concat(numero.toString());

        return retorno;
    }

    /**
     * Método Formata matricula.
     *
     * @param matricula
     *            the matricula
     * @return string
     */
    public static String formataMatricula(final String matricula) {
        String matriculaFormatada = "c";
        for (int i = matricula.length(); i < 6; i++) {
            matriculaFormatada = matriculaFormatada.concat("0");
        }
        return matriculaFormatada + matricula;
    }
    /**
     * 
     * <p>Método responsável por formatar campo para arquivos</p>.
     *
     * @author p575337
     *
     * @param numero a ser formatado
     * @param tamanho do campo, caso ultrapasse o campo será cortado até o tamanho máximo
     * @return
     */
    public static String numerico(Integer numero, int tamanho) {
		return numerico((numero != null ? numero.toString() : ""), tamanho);
	}
	/**
	 * 
	 * <p>Método responsável por formatar campo para arquivos, completa com "0" a esquerda até chegar ao tamanho definido</p>.
	 *
	 * @author p575337
	 *
	 * @param numero  campo a ser formatado
	 * @param tamanho do campo, caso ultrapasse o campo será cortado até o tamanho máximo
	 * @return
	 */
    public static String numerico(String numero, int tamanho) {
		String retorno;
		if (numero != null) {
			if (numero.length() > tamanho) {
				retorno = numero.substring(0, tamanho);
			} else {
				retorno = StringUtils.leftPad(numero, tamanho, "0");
			}
		} else {
			retorno =  StringUtils.leftPad("", tamanho, "0");
		}
		return retorno;
	}
	/**
	 * 
	 * <p>Método responsável por formatar campo alfanumerico para arquivo, completa com campos em branco até chegar ao tamanho certo</p>.
	 *
	 * @author p575337
	 *
	 * @param alfanumerico campo a ser formatado
	 * @param tamanho do campo, caso ultrapasse o campo será cortado até o tamanho máximo
	 * @return
	 */
    public static String alfanumerico(String alfanumerico, int tamanho) {
		String retorno;
		if (alfanumerico != null) {
			if (alfanumerico.length() > tamanho) {
				retorno = alfanumerico.substring(0, tamanho);
			} else {
				retorno = StringUtils.rightPad(alfanumerico, tamanho);
			}
		} else {
			retorno =  StringUtils.rightPad("", tamanho);
		}
		return retorno;
	}

}
