/**
 * Copyright (c) 2014 Caixa Econômica Federal. Todos os direitos
 * reservados.
 *
 * Caixa Econômica Federal - SIACG - Sistema de Crédito Rural
 *
 * Este software foi desenvolvido sob demanda da CAIXA e está
 * protegido por leis de direitos autorais e tratados internacionais. As
 * condições de cópia e utilização do todo ou partes dependem de autorização da
 * pessoa. Cópias não são permitidas sem expressa autorização. Não pode ser
 * comercializado ou utilizado para propósitos particulares.
 *
 * Uso exclusivo da Caixa Econômica Federal. A reprodução ou distribuição não
 * autorizada deste programa ou de parte dele, resultará em punições civis e
 * criminais e os infratores incorrem em sanções previstas na legislação em
 * vigor.
 *
 * Histórico do Subversion:
 *
 * LastChangedRevision: $Revision$
 * LastChangedBy: $Author$
 * LastChangedDate: $Date$
 *
 * HeadURL: $HeadURL$
 *
 */
package br.gov.caixa.siacg.view.form;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.List;

import org.primefaces.model.DefaultTreeNode;
import org.primefaces.model.TreeNode;

import br.gov.caixa.pedesgo.arquitetura.util.UtilObjeto;
import br.gov.caixa.pedesgo.arquitetura.visao.ManutencaoVisao;
import br.gov.caixa.siacg.model.domain.BandeiraCartao;
import br.gov.caixa.siacg.model.domain.Cedente;
import br.gov.caixa.siacg.model.domain.ContaContrato;
import br.gov.caixa.siacg.model.domain.ContaCorrente;
import br.gov.caixa.siacg.model.domain.ContaCorrenteID;
import br.gov.caixa.siacg.model.domain.Contrato;
import br.gov.caixa.siacg.model.domain.DuplicataExcepcionada;
import br.gov.caixa.siacg.model.domain.Garantia;
import br.gov.caixa.siacg.model.domain.GarantiaAplicacao;
import br.gov.caixa.siacg.model.domain.GarantiaContrato;
import br.gov.caixa.siacg.model.domain.ParametroCalculo;
import br.gov.caixa.siacg.model.domain.Pessoa;
import br.gov.caixa.siacg.model.domain.PreAnalise;
import br.gov.caixa.siacg.model.domain.Suat;
import br.gov.caixa.siacg.model.enums.CaracteristicaEnum;
import br.gov.caixa.siacg.model.enums.SegmentacaoEnum;
import br.gov.caixa.siacg.model.enums.SituacaoPreAnaliseEnum;
import br.gov.caixa.siacg.model.vo.DuplicataVO;
import br.gov.caixa.siacg.model.vo.ParametrizacaoContratoVO;
import br.gov.caixa.siacg.model.vo.SrEUnidadeVO;
import br.gov.caixa.siacg.model.vo.SrVO;
import br.gov.caixa.siacg.model.vo.UnidadeVO;

/**
 * <p>
 * PreAnaliseVisao
 * </p>
 * <p>
 * Descrição: Classe de Visão para o Bean Gerenciado PreAnaliseMB.
 * </p>
 * <br>
 * <b>Empresa:</b> Cef - Caixa Econômica Federal
 *
 * @author Caio Graco
 * @version 1.0
 */

public class PreAnaliseVisao extends ManutencaoVisao<PreAnalise> {

	/** Constante serialVersionUID. */
	private static final long serialVersionUID = 2755745014673461623L;

	/** Atributo ocultar valor. */
	private boolean ocultarValor;

	/** Atributo desabilitar tipo garantia. */
	private boolean desabilitarTipoGarantia;

	/** Atributo ocultar instrucao protesto. */
	private boolean ocultarInstrucaoProtesto;

	/** Atributo ocultar percentual maximo. */
	private boolean ocultarPercentualMaximo;

	/** Atributo ocultar prazo maximo. */
	private boolean ocultarPrazoMaximo;

	/** Atributo ocultar valor maximo. */
	private boolean ocultarValorMaximo;

	/** Atributo exibir aplicacao financeira. */
	private boolean exibirAplicacaoFinanceira;

	/** Atributo ocultar tipo garantia. */
	private boolean ocultarTipoGarantia;

	/** Atributo exibir campos edicao. */
	private boolean exibirCamposEdicao = false;

	/** Atributo exibir cartao credito. */
	private boolean exibirCartaoCredito;

	/** Atributo exibir botao incluir garantia. */
	private boolean exibirBotaoIncluirGarantia;

	/** Atributo exibir botao editar garantia. */
	private boolean exibirBotaoEditarGarantia;

	/** Atributo exibir botao excluir garantia. */
	private boolean exibirBotaoExcluirGarantia;

	/** Atributo exibir botao duplicata excepcionada garantia. */
	private boolean exibirBotaoDuplicataExcepcionadaGarantia;

	/** Atributo desabilitar campos. */
	private boolean desabilitarCampos;

	/** Atributo exibir modal operacao realizada com sucesso. */
	private boolean exibirModalOperacaoRealizadaComSucesso;

	/** Atributo edicao. */
	private boolean edicao;

	/** Atributo desabilitar combo garantia. */
	private boolean desabilitarComboGarantia;

	/** Atributo exibir modal exclusao. */
	private boolean exibirModalExclusao;

	/** Atributo quantidade registros. */
	private Integer quantidadeRegistros;

	/** Atributo unidade selecionada. */
	private Integer unidadeSelecionada;

	/** Atributo sr selecionada. */
	private Integer srSelecionada;

	/** Atributo suat selecionada. */
	private Integer suatSelecionada;

	/** Atributo pessoa. */
	private String pessoa;

	/**
	 * 
	 */
	private String cpfCnpj;

	/** Atributo identificador garantia. */
	private String identificadorGarantia;

	/** Atributo mensagem salvar parametrizacao. */
	private String mensagemSalvarParametrizacao;

	/** Atributo identificador remocao. */
	private String identificadorRemocao;

	/** Atributo identificador excepcionar. */
	private String identificadorExcepcionar;

	/** Atributo conta corrente. */
	private ContaCorrente contaCorrente;

	/** Atributo cedente incluido. */
	private Cedente cedenteIncluido;

	/** Atributo conta contrato. */
	private ContaContrato contaContrato;

	/** Atributo conta contrato cartao. */
	private ContaContrato contaContratoCartao;

	/** Atributo contrato pre analise. */
	private Contrato contratoPreAnalise;

	/** Atributo pessoa obj. */
	private Pessoa pessoaObj;

	/** Atributo duplicata excepcionada. */
	private DuplicataExcepcionada duplicataExcepcionada;

	/** Atributo garantia contrato edicao. */
	private GarantiaContrato garantiaContratoEdicao;

	/** Atributo conta corrente cartao credito. */
	private transient TreeNode contaCorrenteCartaoCredito;

	/** Atributo cartoes selecionados. */
	private transient TreeNode[] cartoesSelecionados;

	/** Atributo parametrizacao edicao. */
	private ParametrizacaoContratoVO parametrizacaoEdicao;

	/** Atributo parametrizacao contrato vo temp. */
	private ParametrizacaoContratoVO parametrizacaoContratoVOTemp;

	/** Atributo lista aplicacao selecionadas. */
	private Collection<GarantiaAplicacao> listaAplicacaoSelecionadas;

	/** Atributo lista unidade. */
	private Collection<UnidadeVO> listaUnidade;

	/** Atributo lista suat. */
	private Collection<Suat> listaSuat;

	/** Atributo lista sr. */
	private Collection<SrVO> listaSr;

	/** Atributo lista situacoes. */
	private List<SituacaoPreAnaliseEnum> listaSituacoes;

	/** Atributo lista conta corrente. */
	private ArrayList<ContaCorrente> listaContaCorrente;

	/** Atributo garantias. */
	private Collection<Garantia> garantias;

	/** Atributo caracteristica list. */
	private Collection<CaracteristicaEnum> caracteristicaList;

	/** Atributo garantia list. */
	private Collection<Garantia> garantiaList;

	/** Atributo lista cedentes. */
	private Collection<Cedente> listaCedentes;

	/** Atributo parametrizacao list. */
	private Collection<ParametrizacaoContratoVO> parametrizacaoList;

	/** Atributo lista exclusao parametrizacao. */
	private Collection<ParametrizacaoContratoVO> listaExclusaoParametrizacao;

	/** Atributo lista conta contrato. */
	private List<ContaContrato> listaContaContrato;

	/** Atributo lista conta contrato cartao. */
	private ArrayList<ContaContrato> listaContaContratoCartao;

	/** Atributo duplicatas encontradas. */
	private Collection<DuplicataVO> duplicatasEncontradas;

	/** Atributo duplicatas para excepcionar. */
	private Collection<DuplicataVO> duplicatasParaExcepcionar;

	/** Atributo lista parametro calculo. */
	private Collection<ParametroCalculo> listaParametroCalculo;

	/** Atributo conta contrato list. */
	private Collection<ContaContrato> contaContratoList;

	/** Atributo lista unidade filtro. */
	private Collection<Integer> listaUnidadeFiltro;

	/** Atributo listaSegmento. */
	private Collection<SegmentacaoEnum> listaSegmento;

	/** Atributo segmento. */
	private List<Integer> listaSegmentoSelecionados;

	/** Atributo nu unidade. */
	private Integer nuUnidade;

	/** Atributo nu sr. */
	private Integer nuSr;

	/** Atributo nu suat. */
	private Integer nuSuat;

	/** Atributo sr list. */
	private Collection<SrVO> srList;

	/** Atributo habilitar suat. */
	private boolean habilitarSuat;

	/** Atributo habilitar sr. */
	private boolean habilitarSr;

	/** Atributo habilitar unidade. */
	private boolean habilitarUnidade;

	/** Atributo contem permissao botao novo. */
	private boolean contemPermissaoBotaoNovo;

	/** Atributo contem permissao botao consultar. */
	private boolean contemPermissaoBotaoConsultar;

	/** Atributo contem permissao botao editar. */
	private boolean contemPermissaoBotaoEditar;

	/** Atributo contem permissao editar parametro. */
	private boolean contemPermissaoEditarParametro;

	/** Atributo garantia. */
	private Garantia garantia;

	/** Atributo nome suat. */
	private String nomeSuat;

	/** Atributo nome sr. */
	private String nomeSr;

	/** Atributo nome unidade. */
	private String nomeUnidade;
	
	private List<UnidadeVO> listaDires;

	/** Atributo exibir gestor caixa. */
	private boolean exibirGestorCaixa;

	/** Atributo exibir gestor nacional. */
	private boolean exibirGestorNacional;

	/** Atributo exibir gestor regional. */
	private boolean exibirGestorRegional;

	/** Atributo exibir gestor unidade. */
	private boolean exibirGestorUnidade;

	/** Atributo exibir coluna unidade. */
	private boolean exibirColunaUnidade;

	/** Atributo exibir coluna sr. */
	private boolean exibirColunaSR;

	/** Atributo exibir coluna suat. */
	private boolean exibirColunaSUAT;

	/** Atributo bread crumb analise garantia. */
	private boolean breadCrumbAnaliseGarantia;

	/** Atributo listaBandeiraCartao. */
	private List<BandeiraCartao> listaBandeiraCartao;

	private SrEUnidadeVO srUnidade;

	private Collection<SrEUnidadeVO> srUnidadesList;
	
	private Integer codSuvSelecionado;
	private Integer tipoConfig;
	private Integer unidadeGestoraProcesso;

	/**
	 * Retorna o valor do atributo quantidadeRegistros.
	 *
	 * @return quantidadeRegistros
	 */
	public Integer getQuantidadeRegistros() {
		if (super.getLista() != null) {
			this.quantidadeRegistros = super.getLista().size();
		} else {
			this.quantidadeRegistros = 0;
		}
		return this.quantidadeRegistros;
	}

	/**
	 * Define o valor do atributo quantidadeRegistros.
	 *
	 * @param quantidadeRegistros
	 *            valor a ser atribuído
	 */
	public void setQuantidadeRegistros(final Integer quantidadeRegistros) {
		this.quantidadeRegistros = quantidadeRegistros;
	}

	/**
	 * Retorna o valor do atributo pessoa.
	 *
	 * @return pessoa
	 */
	public String getPessoa() {
		return this.pessoa;
	}

	/**
	 * Define o valor do atributo pessoa.
	 *
	 * @param pessoa
	 *            valor a ser atribuído
	 */
	public void setPessoa(final String pessoa) {
		this.pessoa = pessoa;
	}

	/**
	 * Retorna o valor do atributo listaSituacoes.
	 *
	 * @return listaSituacoes
	 */
	public List<SituacaoPreAnaliseEnum> getListaSituacoes() {

		return this.listaSituacoes;
	}

	/**
	 * Define o valor do atributo listaSituacoes.
	 *
	 * @param listaSituacoes
	 *            valor a ser atribuído
	 */
	public void setListaSituacoes(final List<SituacaoPreAnaliseEnum> listaSituacoes) {

		this.listaSituacoes = listaSituacoes;
	}

	/**
	 * Retorna o valor do atributo contaCorrente.
	 *
	 * @return contaCorrente
	 */
	public ContaCorrente getContaCorrente() {

		return this.contaCorrente;
	}

	/**
	 * Define o valor do atributo contaCorrente.
	 *
	 * @param contaCorrente
	 *            valor a ser atribuído
	 */
	public void setContaCorrente(final ContaCorrente contaCorrente) {

		this.contaCorrente = contaCorrente;
	}

	/**
	 * Retorna o valor do atributo listaContaCorrente.
	 *
	 * @return listaContaCorrente
	 */
	public ArrayList<ContaCorrente> getListaContaCorrente() {

		return this.listaContaCorrente;
	}

	/**
	 * Define o valor do atributo listaContaCorrente.
	 *
	 * @param listaContaCorrente
	 *            valor a ser atribuído
	 */
	public void setListaContaCorrente(final ArrayList<ContaCorrente> listaContaCorrente) {

		this.listaContaCorrente = listaContaCorrente;
	}

	/**
	 * Retorna o valor do atributo ocultarValor.
	 *
	 * @return ocultarValor
	 */
	public boolean isOcultarValor() {

		return this.ocultarValor;
	}

	/**
	 * Define o valor do atributo ocultarValor.
	 *
	 * @param ocultarValor
	 *            valor a ser atribuído
	 */
	public void setOcultarValor(final boolean ocultarValor) {

		this.ocultarValor = ocultarValor;
	}

	/**
	 * Retorna o valor do atributo desabilitarTipoGarantia.
	 *
	 * @return desabilitarTipoGarantia
	 */
	public boolean isDesabilitarTipoGarantia() {

		return this.desabilitarTipoGarantia;
	}

	/**
	 * Define o valor do atributo desabilitarTipoGarantia.
	 *
	 * @param desabilitarTipoGarantia
	 *            valor a ser atribuído
	 */
	public void setDesabilitarTipoGarantia(final boolean desabilitarTipoGarantia) {

		this.desabilitarTipoGarantia = desabilitarTipoGarantia;
	}

	/**
	 * Retorna o valor do atributo ocultarInstrucaoProtesto.
	 *
	 * @return ocultarInstrucaoProtesto
	 */
	public boolean isOcultarInstrucaoProtesto() {

		return this.ocultarInstrucaoProtesto;
	}

	/**
	 * Define o valor do atributo ocultarInstrucaoProtesto.
	 *
	 * @param ocultarInstrucaoProtesto
	 *            valor a ser atribuído
	 */
	public void setOcultarInstrucaoProtesto(final boolean ocultarInstrucaoProtesto) {

		this.ocultarInstrucaoProtesto = ocultarInstrucaoProtesto;
	}

	/**
	 * Retorna o valor do atributo ocultarPercentualMaximo.
	 *
	 * @return ocultarPercentualMaximo
	 */
	public boolean isOcultarPercentualMaximo() {

		return this.ocultarPercentualMaximo;
	}

	/**
	 * Define o valor do atributo ocultarPercentualMaximo.
	 *
	 * @param ocultarPercentualMaximo
	 *            valor a ser atribuído
	 */
	public void setOcultarPercentualMaximo(final boolean ocultarPercentualMaximo) {

		this.ocultarPercentualMaximo = ocultarPercentualMaximo;
	}

	/**
	 * Retorna o valor do atributo ocultarPrazoMaximo.
	 *
	 * @return ocultarPrazoMaximo
	 */
	public boolean isOcultarPrazoMaximo() {

		return this.ocultarPrazoMaximo;
	}

	/**
	 * Define o valor do atributo ocultarPrazoMaximo.
	 *
	 * @param ocultarPrazoMaximo
	 *            valor a ser atribuído
	 */
	public void setOcultarPrazoMaximo(final boolean ocultarPrazoMaximo) {

		this.ocultarPrazoMaximo = ocultarPrazoMaximo;
	}

	/**
	 * Retorna o valor do atributo ocultarValorMaximo.
	 *
	 * @return ocultarValorMaximo
	 */
	public boolean isOcultarValorMaximo() {

		return this.ocultarValorMaximo;
	}

	/**
	 * Define o valor do atributo ocultarValorMaximo.
	 *
	 * @param ocultarValorMaximo
	 *            valor a ser atribuído
	 */
	public void setOcultarValorMaximo(final boolean ocultarValorMaximo) {

		this.ocultarValorMaximo = ocultarValorMaximo;
	}

	/**
	 * Retorna o valor do atributo exibirAplicacaoFinanceira.
	 *
	 * @return exibirAplicacaoFinanceira
	 */
	public boolean isExibirAplicacaoFinanceira() {

		return this.exibirAplicacaoFinanceira;
	}

	/**
	 * Define o valor do atributo exibirAplicacaoFinanceira.
	 *
	 * @param exibirAplicacaoFinanceira
	 *            valor a ser atribuído
	 */
	public void setExibirAplicacaoFinanceira(final boolean exibirAplicacaoFinanceira) {

		this.exibirAplicacaoFinanceira = exibirAplicacaoFinanceira;
	}

	/**
	 * Retorna o valor do atributo ocultarTipoGarantia.
	 *
	 * @return ocultarTipoGarantia
	 */
	public boolean isOcultarTipoGarantia() {

		return this.ocultarTipoGarantia;
	}

	/**
	 * Define o valor do atributo ocultarTipoGarantia.
	 *
	 * @param ocultarTipoGarantia
	 *            valor a ser atribuído
	 */
	public void setOcultarTipoGarantia(final boolean ocultarTipoGarantia) {

		this.ocultarTipoGarantia = ocultarTipoGarantia;
	}

	/**
	 * Retorna o valor do atributo exibirCamposEdicao.
	 *
	 * @return exibirCamposEdicao
	 */
	public boolean isExibirCamposEdicao() {

		return this.exibirCamposEdicao;
	}

	/**
	 * Define o valor do atributo exibirCamposEdicao.
	 *
	 * @param exibirCamposEdicao
	 *            valor a ser atribuído
	 */
	public void setExibirCamposEdicao(final boolean exibirCamposEdicao) {

		this.exibirCamposEdicao = exibirCamposEdicao;
	}

	/**
	 * Retorna o valor do atributo exibirCartaoCredito.
	 *
	 * @return exibirCartaoCredito
	 */
	public boolean isExibirCartaoCredito() {

		return this.exibirCartaoCredito;
	}

	/**
	 * Define o valor do atributo exibirCartaoCredito.
	 *
	 * @param exibirCartaoCredito
	 *            valor a ser atribuído
	 */
	public void setExibirCartaoCredito(final boolean exibirCartaoCredito) {

		this.exibirCartaoCredito = exibirCartaoCredito;
	}

	/**
	 * Retorna o valor do atributo exibirBotaoIncluirGarantia.
	 *
	 * @return exibirBotaoIncluirGarantia
	 */
	public boolean isExibirBotaoIncluirGarantia() {

		return this.exibirBotaoIncluirGarantia;
	}

	/**
	 * Define o valor do atributo exibirBotaoIncluirGarantia.
	 *
	 * @param exibirBotaoIncluirGarantia
	 *            valor a ser atribuído
	 */
	public void setExibirBotaoIncluirGarantia(final boolean exibirBotaoIncluirGarantia) {

		this.exibirBotaoIncluirGarantia = exibirBotaoIncluirGarantia;
	}

	/**
	 * Retorna o valor do atributo exibirBotaoEditarGarantia.
	 *
	 * @return exibirBotaoEditarGarantia
	 */
	public boolean isExibirBotaoEditarGarantia() {

		return this.exibirBotaoEditarGarantia;
	}

	/**
	 * Define o valor do atributo exibirBotaoEditarGarantia.
	 *
	 * @param exibirBotaoEditarGarantia
	 *            valor a ser atribuído
	 */
	public void setExibirBotaoEditarGarantia(final boolean exibirBotaoEditarGarantia) {

		this.exibirBotaoEditarGarantia = exibirBotaoEditarGarantia;
	}

	/**
	 * Retorna o valor do atributo exibirBotaoExcluirGarantia.
	 *
	 * @return exibirBotaoExcluirGarantia
	 */
	public boolean isExibirBotaoExcluirGarantia() {

		return this.exibirBotaoExcluirGarantia;
	}

	/**
	 * Define o valor do atributo exibirBotaoExcluirGarantia.
	 *
	 * @param exibirBotaoExcluirGarantia
	 *            valor a ser atribuído
	 */
	public void setExibirBotaoExcluirGarantia(final boolean exibirBotaoExcluirGarantia) {

		this.exibirBotaoExcluirGarantia = exibirBotaoExcluirGarantia;
	}

	/**
	 * Retorna o valor do atributo exibirBotaoDuplicataExcepcionadaGarantia.
	 *
	 * @return exibirBotaoDuplicataExcepcionadaGarantia
	 */
	public boolean isExibirBotaoDuplicataExcepcionadaGarantia() {

		return this.exibirBotaoDuplicataExcepcionadaGarantia;
	}

	/**
	 * Define o valor do atributo exibirBotaoDuplicataExcepcionadaGarantia.
	 *
	 * @param exibirBotaoDuplicataExcepcionadaGarantia
	 *            valor a ser atribuído
	 */
	public void setExibirBotaoDuplicataExcepcionadaGarantia(final boolean exibirBotaoDuplicataExcepcionadaGarantia) {

		this.exibirBotaoDuplicataExcepcionadaGarantia = exibirBotaoDuplicataExcepcionadaGarantia;
	}

	/**
	 * Retorna o valor do atributo desabilitarCampos.
	 *
	 * @return desabilitarCampos
	 */
	public boolean isDesabilitarCampos() {

		return this.desabilitarCampos;
	}

	/**
	 * Define o valor do atributo desabilitarCampos.
	 *
	 * @param desabilitarCampos
	 *            valor a ser atribuído
	 */
	public void setDesabilitarCampos(final boolean desabilitarCampos) {

		this.desabilitarCampos = desabilitarCampos;
	}

	/**
	 * Retorna o valor do atributo unidadeSelecionada.
	 *
	 * @return unidadeSelecionada
	 */
	public Integer getUnidadeSelecionada() {

		return this.unidadeSelecionada;
	}

	/**
	 * Define o valor do atributo unidadeSelecionada.
	 *
	 * @param unidadeSelecionada
	 *            valor a ser atribuído
	 */
	public void setUnidadeSelecionada(final Integer unidadeSelecionada) {

		this.unidadeSelecionada = unidadeSelecionada;
	}

	/**
	 * Retorna o valor do atributo srSelecionada.
	 *
	 * @return srSelecionada
	 */
	public Integer getSrSelecionada() {

		return this.srSelecionada;
	}

	/**
	 * Define o valor do atributo srSelecionada.
	 *
	 * @param srSelecionada
	 *            valor a ser atribuído
	 */
	public void setSrSelecionada(final Integer srSelecionada) {

		this.srSelecionada = srSelecionada;
	}

	/**
	 * Retorna o valor do atributo suatSelecionada.
	 *
	 * @return suatSelecionada
	 */
	public Integer getSuatSelecionada() {

		return this.suatSelecionada;
	}

	/**
	 * Define o valor do atributo suatSelecionada.
	 *
	 * @param suatSelecionada
	 *            valor a ser atribuído
	 */
	public void setSuatSelecionada(final Integer suatSelecionada) {

		this.suatSelecionada = suatSelecionada;
	}

	/**
	 * Retorna o valor do atributo identificadorGarantia.
	 *
	 * @return identificadorGarantia
	 */
	public String getIdentificadorGarantia() {

		return this.identificadorGarantia;
	}

	/**
	 * Define o valor do atributo identificadorGarantia.
	 *
	 * @param identificadorGarantia
	 *            valor a ser atribuído
	 */
	public void setIdentificadorGarantia(final String identificadorGarantia) {

		this.identificadorGarantia = identificadorGarantia;
	}

	/**
	 * Retorna o valor do atributo mensagemSalvarParametrizacao.
	 *
	 * @return mensagemSalvarParametrizacao
	 */
	public String getMensagemSalvarParametrizacao() {

		return this.mensagemSalvarParametrizacao;
	}

	/**
	 * Define o valor do atributo mensagemSalvarParametrizacao.
	 *
	 * @param mensagemSalvarParametrizacao
	 *            valor a ser atribuído
	 */
	public void setMensagemSalvarParametrizacao(final String mensagemSalvarParametrizacao) {

		this.mensagemSalvarParametrizacao = mensagemSalvarParametrizacao;
	}

	/**
	 * Retorna o valor do atributo identificadorRemocao.
	 *
	 * @return identificadorRemocao
	 */
	public String getIdentificadorRemocao() {

		return this.identificadorRemocao;
	}

	/**
	 * Define o valor do atributo identificadorRemocao.
	 *
	 * @param identificadorRemocao
	 *            valor a ser atribuído
	 */
	public void setIdentificadorRemocao(final String identificadorRemocao) {

		this.identificadorRemocao = identificadorRemocao;
	}

	/**
	 * Retorna o valor do atributo identificadorExcepcionar.
	 *
	 * @return identificadorExcepcionar
	 */
	public String getIdentificadorExcepcionar() {

		return this.identificadorExcepcionar;
	}

	/**
	 * Define o valor do atributo identificadorExcepcionar.
	 *
	 * @param identificadorExcepcionar
	 *            valor a ser atribuído
	 */
	public void setIdentificadorExcepcionar(final String identificadorExcepcionar) {

		this.identificadorExcepcionar = identificadorExcepcionar;
	}

	/**
	 * Retorna o valor do atributo cedenteIncluido.
	 *
	 * @return cedenteIncluido
	 */
	public Cedente getCedenteIncluido() {

		return this.cedenteIncluido;
	}

	/**
	 * Define o valor do atributo cedenteIncluido.
	 *
	 * @param cedenteIncluido
	 *            valor a ser atribuído
	 */
	public void setCedenteIncluido(final Cedente cedenteIncluido) {

		this.cedenteIncluido = cedenteIncluido;
	}

	/**
	 * Retorna o valor do atributo contaContrato.
	 *
	 * @return contaContrato
	 */
	public ContaContrato getContaContrato() {

		if (this.contaContrato == null) {
			this.contaContrato = new ContaContrato();
			this.contaContrato.setNuConta(new ContaCorrente());
			this.contaContrato.getNuConta().setId(new ContaCorrenteID());
		}

		return this.contaContrato;
	}

	/**
	 * Define o valor do atributo contaContrato.
	 *
	 * @param contaContrato
	 *            valor a ser atribuído
	 */
	public void setContaContrato(final ContaContrato contaContrato) {

		this.contaContrato = contaContrato;
	}

	/**
	 * Retorna o valor do atributo contaContratoCartao.
	 *
	 * @return contaContratoCartao
	 */
	public ContaContrato getContaContratoCartao() {

		return this.contaContratoCartao;
	}

	/**
	 * Define o valor do atributo contaContratoCartao.
	 *
	 * @param contaContratoCartao
	 *            valor a ser atribuído
	 */
	public void setContaContratoCartao(final ContaContrato contaContratoCartao) {

		this.contaContratoCartao = contaContratoCartao;
	}

	/**
	 * Retorna o valor do atributo contratoPreAnalise.
	 *
	 * @return contratoPreAnalise
	 */
	public Contrato getContratoPreAnalise() {
		if (this.getEntidade() != null && this.getEntidade().getContrato() != null && this.getEntidade().getContrato().getNuContrato() != null) {
			this.contratoPreAnalise = this.getEntidade().getContrato();
		}
		return null == this.contratoPreAnalise ? new Contrato() : this.contratoPreAnalise;
	}

	/**
	 * Define o valor do atributo contratoPreAnalise.
	 *
	 * @param contratoPreAnalise
	 *            valor a ser atribuído
	 */
	public void setContratoPreAnalise(final Contrato contratoPreAnalise) {

		this.contratoPreAnalise = contratoPreAnalise;
	}

	/**
	 * Retorna o valor do atributo pessoaObj.
	 *
	 * @return pessoaObj
	 */
	public Pessoa getPessoaObj() {

		return this.pessoaObj;
	}

	/**
	 * Define o valor do atributo pessoaObj.
	 *
	 * @param pessoaObj
	 *            valor a ser atribuído
	 */
	public void setPessoaObj(final Pessoa pessoaObj) {

		this.pessoaObj = pessoaObj;
	}

	/**
	 * Retorna o valor do atributo duplicataExcepcionada.
	 *
	 * @return duplicataExcepcionada
	 */
	public DuplicataExcepcionada getDuplicataExcepcionada() {

		return this.duplicataExcepcionada;
	}

	/**
	 * Define o valor do atributo duplicataExcepcionada.
	 *
	 * @param duplicataExcepcionada
	 *            valor a ser atribuído
	 */
	public void setDuplicataExcepcionada(final DuplicataExcepcionada duplicataExcepcionada) {

		this.duplicataExcepcionada = duplicataExcepcionada;
	}

	/**
	 * Retorna o valor do atributo contaCorrenteCartaoCredito.
	 *
	 * @return contaCorrenteCartaoCredito
	 */
	public TreeNode getContaCorrenteCartaoCredito() {

		if (!UtilObjeto.isReferencia(this.contaCorrenteCartaoCredito)) {

			this.contaCorrenteCartaoCredito = new DefaultTreeNode("", null);
		}

		return this.contaCorrenteCartaoCredito;
	}

	/**
	 * Define o valor do atributo contaCorrenteCartaoCredito.
	 *
	 * @param contaCorrenteCartaoCredito
	 *            valor a ser atribuído
	 */
	public void setContaCorrenteCartaoCredito(final TreeNode contaCorrenteCartaoCredito) {

		this.contaCorrenteCartaoCredito = contaCorrenteCartaoCredito;
	}

	/**
	 * Retorna o valor do atributo cartoesSelecionados.
	 *
	 * @return cartoesSelecionados
	 */
	public TreeNode[] getCartoesSelecionados() {

		return this.cartoesSelecionados;
	}

	/**
	 * Define o valor do atributo cartoesSelecionados.
	 *
	 * @param cartoesSelecionados
	 *            valor a ser atribuído
	 */
	public void setCartoesSelecionados(final TreeNode[] cartoesSelecionados) {

		this.cartoesSelecionados = cartoesSelecionados;
	}

	/**
	 * Retorna o valor do atributo parametrizacaoEdicao.
	 *
	 * @return parametrizacaoEdicao
	 */
	public ParametrizacaoContratoVO getParametrizacaoEdicao() {

		return this.parametrizacaoEdicao;
	}

	/**
	 * Define o valor do atributo parametrizacaoEdicao.
	 *
	 * @param parametrizacaoEdicao
	 *            valor a ser atribuído
	 */
	public void setParametrizacaoEdicao(final ParametrizacaoContratoVO parametrizacaoEdicao) {

		this.parametrizacaoEdicao = parametrizacaoEdicao;
	}

	/**
	 * Retorna o valor do atributo parametrizacaoContratoVOTemp.
	 *
	 * @return parametrizacaoContratoVOTemp
	 */
	public ParametrizacaoContratoVO getParametrizacaoContratoVOTemp() {

		return this.parametrizacaoContratoVOTemp;
	}

	/**
	 * Define o valor do atributo parametrizacaoContratoVOTemp.
	 *
	 * @param parametrizacaoContratoVOTemp
	 *            valor a ser atribuído
	 */
	public void setParametrizacaoContratoVOTemp(final ParametrizacaoContratoVO parametrizacaoContratoVOTemp) {

		this.parametrizacaoContratoVOTemp = parametrizacaoContratoVOTemp;
	}

	/**
	 * Retorna o valor do atributo listaAplicacaoSelecionadas.
	 *
	 * @return listaAplicacaoSelecionadas
	 */
	public Collection<GarantiaAplicacao> getListaAplicacaoSelecionadas() {

		return this.listaAplicacaoSelecionadas;
	}

	/**
	 * Define o valor do atributo listaAplicacaoSelecionadas.
	 *
	 * @param listaAplicacaoSelecionadas
	 *            valor a ser atribuído
	 */
	public void setListaAplicacaoSelecionadas(final Collection<GarantiaAplicacao> listaAplicacaoSelecionadas) {

		this.listaAplicacaoSelecionadas = listaAplicacaoSelecionadas;
	}

	/**
	 * Retorna o valor do atributo listaUnidade.
	 * FIXME remover
	 * @return listaUnidade
	 */
	public Collection<UnidadeVO> getListaUnidade() {

		return this.listaUnidade;
	}

	/**
	 * Define o valor do atributo listaUnidade.
	 *
	 * @param listaUnidade
	 *            valor a ser atribuído
	 */
	public void setListaUnidade(final Collection<UnidadeVO> listaUnidade) {

		this.listaUnidade = listaUnidade;
	}

	/**
	 * Retorna o valor do atributo listaSuat.
	 *
	 * @return listaSuat
	 */
	public Collection<Suat> getListaSuat() {

		return this.listaSuat;
	}

	/**
	 * Define o valor do atributo listaSuat.
	 *
	 * @param listaSuat
	 *            valor a ser atribuído
	 */
	public void setListaSuat(final Collection<Suat> listaSuat) {

		this.listaSuat = listaSuat;
	}

	/**
	 * Retorna o valor do atributo listaSr.
	 *
	 * @return listaSr
	 */
	public Collection<SrVO> getListaSr() {

		return this.listaSr;
	}

	/**
	 * Define o valor do atributo listaSr.
	 *
	 * @param listaSr
	 *            valor a ser atribuído
	 */
	public void setListaSr(final Collection<SrVO> listaSr) {

		this.listaSr = listaSr;
	}

	/**
	 * Retorna o valor do atributo garantias.
	 *
	 * @return garantias
	 */
	public Collection<Garantia> getGarantias() {

		return this.garantias;
	}

	/**
	 * Define o valor do atributo garantias.
	 *
	 * @param garantias
	 *            valor a ser atribuído
	 */
	public void setGarantias(final Collection<Garantia> garantias) {

		this.garantias = garantias;
	}

	/**
	 * Retorna o valor do atributo caracteristicaList.
	 *
	 * @return caracteristicaList
	 */
	public Collection<CaracteristicaEnum> getCaracteristicaList() {

		return this.caracteristicaList;
	}

	/**
	 * Define o valor do atributo caracteristicaList.
	 *
	 * @param caracteristicaList
	 *            valor a ser atribuído
	 */
	public void setCaracteristicaList(final Collection<CaracteristicaEnum> caracteristicaList) {

		this.caracteristicaList = caracteristicaList;
	}

	/**
	 * Retorna o valor do atributo garantiaList.
	 *
	 * @return garantiaList
	 */
	public Collection<Garantia> getGarantiaList() {

		return this.garantiaList;
	}

	/**
	 * Define o valor do atributo garantiaList.
	 *
	 * @param garantiaList
	 *            valor a ser atribuído
	 */
	public void setGarantiaList(final Collection<Garantia> garantiaList) {

		this.garantiaList = garantiaList;
	}

	/**
	 * Retorna o valor do atributo listaCedentes.
	 *
	 * @return listaCedentes
	 */
	public Collection<Cedente> getListaCedentes() {

		if (UtilObjeto.isVazio(this.listaCedentes)) {

			this.listaCedentes = new ArrayList<Cedente>();
		}

		return this.listaCedentes;
	}

	/**
	 * Define o valor do atributo listaCedentes.
	 *
	 * @param listaCedentes
	 *            valor a ser atribuído
	 */
	public void setListaCedentes(final Collection<Cedente> listaCedentes) {

		this.listaCedentes = listaCedentes;
	}

	/**
	 * Retorna o valor do atributo parametrizacaoList.
	 *
	 * @return parametrizacaoList
	 */
	public Collection<ParametrizacaoContratoVO> getParametrizacaoList() {

		return this.parametrizacaoList;
	}

	/**
	 * Define o valor do atributo parametrizacaoList.
	 *
	 * @param parametrizacaoList
	 *            valor a ser atribuído
	 */
	public void setParametrizacaoList(final Collection<ParametrizacaoContratoVO> parametrizacaoList) {

		this.parametrizacaoList = parametrizacaoList;
	}

	/**
	 * Retorna o valor do atributo listaExclusaoParametrizacao.
	 *
	 * @return listaExclusaoParametrizacao
	 */
	public Collection<ParametrizacaoContratoVO> getListaExclusaoParametrizacao() {

		if (this.listaExclusaoParametrizacao == null) {
			this.listaExclusaoParametrizacao = new ArrayList<ParametrizacaoContratoVO>();
		}

		return this.listaExclusaoParametrizacao;
	}

	/**
	 * Define o valor do atributo listaExclusaoParametrizacao.
	 *
	 * @param listaExclusaoParametrizacao
	 *            valor a ser atribuído
	 */
	public void setListaExclusaoParametrizacao(final Collection<ParametrizacaoContratoVO> listaExclusaoParametrizacao) {

		this.listaExclusaoParametrizacao = listaExclusaoParametrizacao;
	}

	/**
	 * Retorna o valor do atributo listaContaContrato.
	 *
	 * @return listaContaContrato
	 */
	public List<ContaContrato> getListaContaContrato() {

		if (this.listaContaContrato == null) {

			this.listaContaContrato = new ArrayList<ContaContrato>();
		}

		return this.listaContaContrato;
	}

	/**
	 * Define o valor do atributo listaContaContrato.
	 *
	 * @param listaContaContrato
	 *            valor a ser atribuído
	 */
	public void setListaContaContrato(final List<ContaContrato> listaContaContrato) {

		this.listaContaContrato = listaContaContrato;
	}

	/**
	 * Retorna o valor do atributo listaContaContratoCartao.
	 *
	 * @return listaContaContratoCartao
	 */
	public ArrayList<ContaContrato> getListaContaContratoCartao() {

		if (UtilObjeto.isVazio(this.listaContaContratoCartao)) {

			this.listaContaContratoCartao = new ArrayList<ContaContrato>();
		}

		return this.listaContaContratoCartao;
	}

	/**
	 * Define o valor do atributo listaContaContratoCartao.
	 *
	 * @param listaContaContratoCartao
	 *            valor a ser atribuído
	 */
	public void setListaContaContratoCartao(final ArrayList<ContaContrato> listaContaContratoCartao) {

		this.listaContaContratoCartao = listaContaContratoCartao;
	}

	/**
	 * Retorna o valor do atributo duplicatasEncontradas.
	 *
	 * @return duplicatasEncontradas
	 */
	public Collection<DuplicataVO> getDuplicatasEncontradas() {

		return this.duplicatasEncontradas;
	}

	/**
	 * Define o valor do atributo duplicatasEncontradas.
	 *
	 * @param duplicatasEncontradas
	 *            valor a ser atribuído
	 */
	public void setDuplicatasEncontradas(final Collection<DuplicataVO> duplicatasEncontradas) {

		this.duplicatasEncontradas = duplicatasEncontradas;
	}

	/**
	 * Retorna o valor do atributo duplicatasParaExcepcionar.
	 *
	 * @return duplicatasParaExcepcionar
	 */
	public Collection<DuplicataVO> getDuplicatasParaExcepcionar() {

		return this.duplicatasParaExcepcionar;
	}

	/**
	 * Define o valor do atributo duplicatasParaExcepcionar.
	 *
	 * @param duplicatasParaExcepcionar
	 *            valor a ser atribuído
	 */
	public void setDuplicatasParaExcepcionar(final Collection<DuplicataVO> duplicatasParaExcepcionar) {

		this.duplicatasParaExcepcionar = duplicatasParaExcepcionar;
	}

	/**
	 * Retorna o valor do atributo listaParametroCalculo.
	 *
	 * @return listaParametroCalculo
	 */
	public Collection<ParametroCalculo> getListaParametroCalculo() {

		return this.listaParametroCalculo;
	}

	/**
	 * Define o valor do atributo listaParametroCalculo.
	 *
	 * @param listaParametroCalculo
	 *            valor a ser atribuído
	 */
	public void setListaParametroCalculo(final Collection<ParametroCalculo> listaParametroCalculo) {

		this.listaParametroCalculo = listaParametroCalculo;
	}

	/**
	 * Retorna o valor do atributo contaContratoList.
	 *
	 * @return contaContratoList
	 */
	public Collection<ContaContrato> getContaContratoList() {

		return this.contaContratoList;
	}

	/**
	 * Define o valor do atributo contaContratoList.
	 *
	 * @param contaContratoList
	 *            valor a ser atribuído
	 */
	public void setContaContratoList(final Collection<ContaContrato> contaContratoList) {

		this.contaContratoList = contaContratoList;
	}

	/**
	 * Retorna o valor do atributo cedentesSelecionados.
	 *
	 * @return cedentesSelecionados
	 */
	public final List<Cedente> getCedentesSelecionados() {
		final List<Cedente> cedentesSelecionados = new ArrayList<Cedente>();

		if (UtilObjeto.isReferencia(this.listaCedentes)) {
			for (final Cedente cedente : this.listaCedentes) {
				if (cedente.isUtilizado()) {
					cedentesSelecionados.add(cedente);
				}
			}
		}
		return cedentesSelecionados;
	}

	/**
	 * Retorna o valor do atributo exibirModalOperacaoRealizadaComSucesso.
	 *
	 * @return exibirModalOperacaoRealizadaComSucesso
	 */
	public boolean isExibirModalOperacaoRealizadaComSucesso() {

		return this.exibirModalOperacaoRealizadaComSucesso;
	}

	/**
	 * Define o valor do atributo exibirModalOperacaoRealizadaComSucesso.
	 *
	 * @param exibirModalOperacaoRealizadaComSucesso
	 *            valor a ser atribuído
	 */
	public void setExibirModalOperacaoRealizadaComSucesso(final boolean exibirModalOperacaoRealizadaComSucesso) {

		this.exibirModalOperacaoRealizadaComSucesso = exibirModalOperacaoRealizadaComSucesso;
	}

	/**
	 * Retorna o valor do atributo edicao.
	 *
	 * @return edicao
	 */
	public boolean isEdicao() {

		return this.edicao;
	}

	/**
	 * Define o valor do atributo edicao.
	 *
	 * @param edicao
	 *            valor a ser atribuído
	 */
	public void setEdicao(final boolean edicao) {

		this.edicao = edicao;
	}

	/**
	 * Retorna o valor do atributo garantiaContratoEdicao.
	 *
	 * @return garantiaContratoEdicao
	 */
	public GarantiaContrato getGarantiaContratoEdicao() {

		if (this.garantiaContratoEdicao == null) {
			this.garantiaContratoEdicao = new GarantiaContrato();
		}

		return this.garantiaContratoEdicao;
	}

	/**
	 * Define o valor do atributo garantiaContratoEdicao.
	 *
	 * @param garantiaContratoEdicao
	 *            valor a ser atribuído
	 */
	public void setGarantiaContratoEdicao(final GarantiaContrato garantiaContratoEdicao) {

		this.garantiaContratoEdicao = garantiaContratoEdicao;
	}

	/**
	 * Retorna o valor do atributo desabilitarComboGarantia.
	 *
	 * @return desabilitarComboGarantia
	 */
	public boolean isDesabilitarComboGarantia() {

		return this.desabilitarComboGarantia;
	}

	/**
	 * Define o valor do atributo desabilitarComboGarantia.
	 *
	 * @param desabilitarComboGarantia
	 *            valor a ser atribuído
	 */
	public void setDesabilitarComboGarantia(final boolean desabilitarComboGarantia) {

		this.desabilitarComboGarantia = desabilitarComboGarantia;
	}

	/**
	 * Retorna o valor do atributo nuUnidade.
	 *
	 * @return nuUnidade
	 */
	public Integer getNuUnidade() {

		return this.nuUnidade;
	}

	/**
	 * Define o valor do atributo nuUnidade.
	 *
	 * @param nuUnidade
	 *            valor a ser atribuído
	 */
	public void setNuUnidade(final Integer nuUnidade) {

		this.nuUnidade = nuUnidade;
	}

	/**
	 * Retorna o valor do atributo nuSr.
	 *
	 * @return nuSr
	 */
	public Integer getNuSr() {

		return this.nuSr;
	}

	/**
	 * Define o valor do atributo nuSr.
	 *
	 * @param nuSr
	 *            valor a ser atribuído
	 */
	public void setNuSr(final Integer nuSr) {

		this.nuSr = nuSr;
	}

	/**
	 * Retorna o valor do atributo nuSuat.
	 *
	 * @return nuSuat
	 */
	public Integer getNuSuat() {

		return this.nuSuat;
	}

	/**
	 * Define o valor do atributo nuSuat.
	 *
	 * @param nuSuat
	 *            valor a ser atribuído
	 */
	public void setNuSuat(final Integer nuSuat) {

		this.nuSuat = nuSuat;
	}

	/**
	 * Retorna o valor do atributo srList.
	 *
	 * @return srList
	 */
	public Collection<SrVO> getSrList() {

		return this.srList;
	}

	/**
	 * Define o valor do atributo srList.
	 *
	 * @param srList
	 *            valor a ser atribuído
	 */
	public void setSrList(final Collection<SrVO> srList) {

		this.srList = srList;
	}

	/**
	 * Retorna o valor do atributo habilitarSuat.
	 *
	 * @return habilitarSuat
	 */
	public boolean isHabilitarSuat() {

		return this.habilitarSuat;
	}

	/**
	 * Define o valor do atributo habilitarSuat.
	 *
	 * @param habilitarSuat
	 *            valor a ser atribuído
	 */
	public void setHabilitarSuat(final boolean habilitarSuat) {

		this.habilitarSuat = habilitarSuat;
	}

	/**
	 * Retorna o valor do atributo habilitarSr.
	 *
	 * @return habilitarSr
	 */
	public boolean isHabilitarSr() {

		return this.habilitarSr;
	}

	/**
	 * Define o valor do atributo habilitarSr.
	 *
	 * @param habilitarSr
	 *            valor a ser atribuído
	 */
	public void setHabilitarSr(final boolean habilitarSr) {

		this.habilitarSr = habilitarSr;
	}

	/**
	 * Retorna o valor do atributo habilitarUnidade.
	 *
	 * @return habilitarUnidade
	 */
	public boolean isHabilitarUnidade() {

		return this.habilitarUnidade;
	}

	/**
	 * Define o valor do atributo habilitarUnidade.
	 *
	 * @param habilitarUnidade
	 *            valor a ser atribuído
	 */
	public void setHabilitarUnidade(final boolean habilitarUnidade) {

		this.habilitarUnidade = habilitarUnidade;
	}

	/**
	 * Retorna o valor do atributo listaUnidadeFiltro.
	 *
	 * @return listaUnidadeFiltro
	 */
	public Collection<Integer> getListaUnidadeFiltro() {

		final List<Integer> lista = (List<Integer>) this.listaUnidadeFiltro;

		if (!UtilObjeto.isVazio(lista) && lista.get(0) == 0) {

			this.listaUnidadeFiltro = null;
		}

		return this.listaUnidadeFiltro;
	}

	/**
	 * Define o valor do atributo listaUnidadeFiltro.
	 *
	 * @param listaUnidadeFiltro
	 *            valor a ser atribuído
	 */
	public void setListaUnidadeFiltro(final Collection<Integer> listaUnidadeFiltro) {

		this.listaUnidadeFiltro = listaUnidadeFiltro;

	}

	/**
	 * Retorna o valor do atributo exibirModalExclusao.
	 *
	 * @return exibirModalExclusao
	 */
	public boolean isExibirModalExclusao() {

		return this.exibirModalExclusao;
	}

	/**
	 * Define o valor do atributo exibirModalExclusao.
	 *
	 * @param exibirModalExclusao
	 *            valor a ser atribuído
	 */
	public void setExibirModalExclusao(final boolean exibirModalExclusao) {

		this.exibirModalExclusao = exibirModalExclusao;
	}

	/**
	 * Retorna o valor do atributo contemPermissaoBotaoNovo.
	 *
	 * @return contemPermissaoBotaoNovo
	 */
	public boolean isContemPermissaoBotaoNovo() {

		return this.contemPermissaoBotaoNovo;
	}

	/**
	 * Define o valor do atributo contemPermissaoBotaoNovo.
	 *
	 * @param contemPermissaoBotaoNovo
	 *            valor a ser atribuído
	 */
	public void setContemPermissaoBotaoNovo(final boolean contemPermissaoBotaoNovo) {

		this.contemPermissaoBotaoNovo = contemPermissaoBotaoNovo;
	}

	/**
	 * Retorna o valor do atributo contemPermissaoBotaoConsultar.
	 *
	 * @return contemPermissaoBotaoConsultar
	 */
	public boolean isContemPermissaoBotaoConsultar() {

		return this.contemPermissaoBotaoConsultar;
	}

	/**
	 * Define o valor do atributo contemPermissaoBotaoConsultar.
	 *
	 * @param contemPermissaoBotaoConsultar
	 *            valor a ser atribuído
	 */
	public void setContemPermissaoBotaoConsultar(final boolean contemPermissaoBotaoConsultar) {

		this.contemPermissaoBotaoConsultar = contemPermissaoBotaoConsultar;
	}

	/**
	 * Retorna o valor do atributo contemPermissaoBotaoEditar.
	 *
	 * @return contemPermissaoBotaoEditar
	 */
	public boolean isContemPermissaoBotaoEditar() {

		return this.contemPermissaoBotaoEditar;
	}

	/**
	 * Define o valor do atributo contemPermissaoBotaoEditar.
	 *
	 * @param contemPermissaoBotaoEditar
	 *            valor a ser atribuído
	 */
	public void setContemPermissaoBotaoEditar(final boolean contemPermissaoBotaoEditar) {

		this.contemPermissaoBotaoEditar = contemPermissaoBotaoEditar;
	}

	/**
	 * Retorna o valor do atributo contemPermissaoEditarParametro.
	 *
	 * @return contemPermissaoEditarParametro
	 */
	public boolean isContemPermissaoEditarParametro() {

		return this.contemPermissaoEditarParametro;
	}

	/**
	 * Define o valor do atributo contemPermissaoEditarParametro.
	 *
	 * @param contemPermissaoEditarParametro
	 *            valor a ser atribuído
	 */
	public void setContemPermissaoEditarParametro(final boolean contemPermissaoEditarParametro) {

		this.contemPermissaoEditarParametro = contemPermissaoEditarParametro;
	}

	/**
	 * Retorna o valor do atributo garantia.
	 *
	 * @return garantia
	 */
	public Garantia getGarantia() {

		return this.garantia;
	}

	/**
	 * Define o valor do atributo garantia.
	 *
	 * @param garantia
	 *            valor a ser atribuído
	 */
	public void setGarantia(final Garantia garantia) {

		this.garantia = garantia;
	}

	/**
	 * Retorna o valor do atributo nomeSuat.
	 *
	 * @return nomeSuat
	 */
	public String getNomeSuat() {

		return this.nomeSuat;
	}

	/**
	 * Define o valor do atributo nomeSuat.
	 *
	 * @param nomeSuat
	 *            valor a ser atribuído
	 */
	public void setNomeSuat(final String nomeSuat) {

		this.nomeSuat = nomeSuat;
	}

	/**
	 * Retorna o valor do atributo nomeSr.
	 *
	 * @return nomeSr
	 */
	public String getNomeSr() {

		return this.nomeSr;
	}

	/**
	 * Define o valor do atributo nomeSr.
	 *
	 * @param nomeSr
	 *            valor a ser atribuído
	 */
	public void setNomeSr(final String nomeSr) {

		this.nomeSr = nomeSr;
	}

	/**
	 * Retorna o valor do atributo nomeUnidade.
	 *
	 * @return nomeUnidade
	 */
	public String getNomeUnidade() {

		return this.nomeUnidade;
	}

	/**
	 * Define o valor do atributo nomeUnidade.
	 *
	 * @param nomeUnidade
	 *            valor a ser atribuído
	 */
	public void setNomeUnidade(final String nomeUnidade) {

		this.nomeUnidade = nomeUnidade;
	}

	/**
	 * Retorna o valor do atributo exibirGestorCaixa.
	 *
	 * @return exibirGestorCaixa
	 */
	public boolean isExibirGestorCaixa() {

		return this.exibirGestorCaixa;
	}

	/**
	 * Define o valor do atributo exibirGestorCaixa.
	 *
	 * @param exibirGestorCaixa
	 *            valor a ser atribuído
	 */
	public void setExibirGestorCaixa(final boolean exibirGestorCaixa) {

		this.exibirGestorCaixa = exibirGestorCaixa;
	}

	/**
	 * Retorna o valor do atributo exibirGestorNacional.
	 *
	 * @return exibirGestorNacional
	 */
	public boolean isExibirGestorNacional() {

		return this.exibirGestorNacional;
	}

	/**
	 * Define o valor do atributo exibirGestorNacional.
	 *
	 * @param exibirGestorNacional
	 *            valor a ser atribuído
	 */
	public void setExibirGestorNacional(final boolean exibirGestorNacional) {

		this.exibirGestorNacional = exibirGestorNacional;
	}

	/**
	 * Retorna o valor do atributo exibirGestorRegional.
	 *
	 * @return exibirGestorRegional
	 */
	public boolean isExibirGestorRegional() {

		return this.exibirGestorRegional;
	}

	/**
	 * Define o valor do atributo exibirGestorRegional.
	 *
	 * @param exibirGestorRegional
	 *            valor a ser atribuído
	 */
	public void setExibirGestorRegional(final boolean exibirGestorRegional) {

		this.exibirGestorRegional = exibirGestorRegional;
	}

	/**
	 * Retorna o valor do atributo exibirGestorUnidade.
	 *
	 * @return exibirGestorUnidade
	 */
	public boolean isExibirGestorUnidade() {

		return this.exibirGestorUnidade;
	}

	/**
	 * Define o valor do atributo exibirGestorUnidade.
	 *
	 * @param exibirGestorUnidade
	 *            valor a ser atribuído
	 */
	public void setExibirGestorUnidade(final boolean exibirGestorUnidade) {

		this.exibirGestorUnidade = exibirGestorUnidade;
	}

	/**
	 * Retorna o valor do atributo exibirColunaUnidade.
	 *
	 * @return exibirColunaUnidade
	 */
	public boolean isExibirColunaUnidade() {

		return this.exibirColunaUnidade;
	}

	/**
	 * Define o valor do atributo exibirColunaUnidade.
	 *
	 * @param exibirColunaUnidade
	 *            valor a ser atribuído
	 */
	public void setExibirColunaUnidade(final boolean exibirColunaUnidade) {

		this.exibirColunaUnidade = exibirColunaUnidade;
	}

	/**
	 * Retorna o valor do atributo exibirColunaSR.
	 *
	 * @return exibirColunaSR
	 */
	public boolean isExibirColunaSR() {

		return this.exibirColunaSR;
	}

	/**
	 * Define o valor do atributo exibirColunaSR.
	 *
	 * @param exibirColunaSR
	 *            valor a ser atribuído
	 */
	public void setExibirColunaSR(final boolean exibirColunaSR) {

		this.exibirColunaSR = exibirColunaSR;
	}

	/**
	 * Retorna o valor do atributo exibirColunaSUAT.
	 *
	 * @return exibirColunaSUAT
	 */
	public boolean isExibirColunaSUAT() {

		return this.exibirColunaSUAT;
	}

	/**
	 * Define o valor do atributo exibirColunaSUAT.
	 *
	 * @param exibirColunaSUAT
	 *            valor a ser atribuído
	 */
	public void setExibirColunaSUAT(final boolean exibirColunaSUAT) {

		this.exibirColunaSUAT = exibirColunaSUAT;
	}

	/**
	 * Retorna o valor do atributo breadCrumbAnaliseGarantia.
	 *
	 * @return breadCrumbAnaliseGarantia
	 */
	public boolean isBreadCrumbAnaliseGarantia() {

		return this.breadCrumbAnaliseGarantia;
	}

	/**
	 * Define o valor do atributo breadCrumbAnaliseGarantia.
	 *
	 * @param breadCrumbAnaliseGarantia
	 *            valor a ser atribuído
	 */
	public void setBreadCrumbAnaliseGarantia(final boolean breadCrumbAnaliseGarantia) {

		this.breadCrumbAnaliseGarantia = breadCrumbAnaliseGarantia;
	}

	/**
	 * Retorna o valor do atributo listaSegmento.
	 *
	 * @return listaSegmento
	 */
	public Collection<SegmentacaoEnum> getListaSegmento() {
		if (this.listaSegmento == null) {
			this.listaSegmento = Arrays.asList(SegmentacaoEnum.values());
		}
		return this.listaSegmento;
	}

	/**
	 * Define o valor do atributo listaSegmento.
	 *
	 * @param listaSegmento
	 *            valor a ser atribuído
	 */
	public void setListaSegmento(final Collection<SegmentacaoEnum> listaSegmento) {
		this.listaSegmento = listaSegmento;
	}

	/**
	 * Retorna o valor do atributo listaSegmentoSelecionados.
	 *
	 * @return listaSegmentoSelecionados
	 */
	public List<Integer> getListaSegmentoSelecionados() {

		return this.listaSegmentoSelecionados;
	}

	/**
	 * Define o valor do atributo listaSegmentoSelecionados.
	 *
	 * @param listaSegmentoSelecionados
	 *            valor a ser atribuído
	 */
	public void setListaSegmentoSelecionados(final List<Integer> listaSegmentoSelecionados) {

		this.listaSegmentoSelecionados = listaSegmentoSelecionados;
	}

	/**
	 * <p>
	 * Retorna o valor do atributo listaBandeiraCartao
	 * </p>
	 * .
	 *
	 * @return listaBandeiraCartao
	 */
	public List<BandeiraCartao> getListaBandeiraCartao() {
		if (this.listaBandeiraCartao == null) {
			this.listaBandeiraCartao = new ArrayList<BandeiraCartao>();
		}
		return this.listaBandeiraCartao;
	}

	/**
	 * <p>
	 * Define o valor do atributo listaBandeiraCartao
	 * </p>
	 * .
	 *
	 * @param listaBandeiraCartao
	 *            valor a ser atribuído
	 */
	public void setListaBandeiraCartao(List<BandeiraCartao> listaBandeiraCartao) {
		this.listaBandeiraCartao = listaBandeiraCartao;
	}

	/**
	 * @return the cpfCnpj
	 */
	public String getCpfCnpj() {
		return cpfCnpj;
	}

	/**
	 * @param cpfCnpj
	 *            the cpfCnpj to set
	 */
	public void setCpfCnpj(String cpfCnpj) {
		this.cpfCnpj = cpfCnpj;
	}

	/**
	 * @return the srUnidade
	 */
	public SrEUnidadeVO getSrUnidade() {
		return srUnidade;
	}

	/**
	 * @param srUnidade the srUnidade to set
	 */
	public void setSrUnidade(SrEUnidadeVO srUnidade) {
		this.srUnidade = srUnidade;
	}

	/**
	 * @return the srUnidadesList
	 */
	public Collection<SrEUnidadeVO> getSrUnidadesList() {
		return srUnidadesList;
	}

	/**
	 * @param srUnidadesList the srUnidadesList to set
	 */
	public void setSrUnidadesList(Collection<SrEUnidadeVO> srUnidadesList) {
		this.srUnidadesList = srUnidadesList;
	}

	/**
	 * <p>Retorna o valor do atributo listaDires</p>.
	 *
	 * @return listaDires
	*/
	public List<UnidadeVO> getListaDires() {
		return this.listaDires;
	}

	/**
	 * <p>Define o valor do atributo listaDires</p>.
	 *
	 * @param listaDires valor a ser atribuído
	*/
	public void setListaDires(List<UnidadeVO> listaDires) {
	this.listaDires = listaDires;}

	/**
	 * <p>Retorna o valor do atributo tipoConfig</p>.
	 *
	 * @return tipoConfig
	*/
	public Integer getTipoConfig() {
		return this.tipoConfig;
	}

	/**
	 * <p>Define o valor do atributo tipoConfig</p>.
	 *
	 * @param tipoConfig valor a ser atribuído
	*/
	public void setTipoConfig(Integer tipoConfig) {
		this.tipoConfig = tipoConfig;
	}
	
	public Integer getCodSuvSelecionado() {
		return codSuvSelecionado;
	}

	public void setCodSuvSelecionado(Integer codSuvSelecionado) {
		this.codSuvSelecionado = codSuvSelecionado;
	}

	public Integer getUnidadeGestoraProcesso() {
		return unidadeGestoraProcesso;
	}

	public void setUnidadeGestoraProcesso(Integer unidadeGestoraProcesso) {
		this.unidadeGestoraProcesso = unidadeGestoraProcesso;
	}
	
	
}