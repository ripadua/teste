/*
 * Copyright (c) 2016 Caixa Econômica Federal. Todos os direitos
 * reservados.
 *
 * Caixa Econômica Federal - SIACG_dev
 *
 * Este software foi desenvolvido sob demanda da CAIXA e está
 * protegido por leis de direitos autorais e tratados internacionais. As
 * condições de cópia e utilização do todo ou partes dependem de autorização da
 * pessoa. Cópias não são permitidas sem expressa autorização. Não pode ser
 * comercializado ou utilizado para propósitos particulares.
 *
 * Uso exclusivo da Caixa Econômica Federal. A reprodução ou distribuição não
 * autorizada deste programa ou de parte dele, resultará em punições civis e
 * criminais e os infratores incorrem em sanções previstas na legislação em
 * vigor.
 *
 * Histórico do Subversion:
 *
 * LastChangedRevision: $Revision$
 * LastChangedBy: $Author$
 * LastChangedDate: $Date$
 *
 * HeadURL: $HeadURL$
 *
 */
package br.gov.caixa.siacg.view.mb;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Collection;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import javax.faces.bean.ManagedBean;
import javax.faces.bean.ManagedProperty;
import javax.faces.bean.ViewScoped;
import javax.faces.component.UIComponent;
import javax.inject.Inject;

import org.apache.commons.collections.CollectionUtils;

import br.gov.caixa.pedesgo.arquitetura.controlador.AbstractBean;
import br.gov.caixa.pedesgo.arquitetura.controlador.ManutencaoBean;
import br.gov.caixa.pedesgo.arquitetura.enumerador.EnumAcao;
import br.gov.caixa.pedesgo.arquitetura.enums.EnumExtensaoArquivo;
import br.gov.caixa.pedesgo.arquitetura.relatorio.UtilRelatorio;
import br.gov.caixa.pedesgo.arquitetura.util.LogCefUtil;
import br.gov.caixa.pedesgo.arquitetura.util.UsuarioUtil;
import br.gov.caixa.pedesgo.arquitetura.util.UtilObjeto;
import br.gov.caixa.siacg.comum.to.PainelGarantiaTO;
import br.gov.caixa.siacg.comum.to.RelatorioBasePainelGarantiaTO;
import br.gov.caixa.siacg.model.domain.DWAnaliseContrato;
import br.gov.caixa.siacg.model.domain.Segmento;
import br.gov.caixa.siacg.model.enums.NoFuncionalidadeEnum;
import br.gov.caixa.siacg.model.vo.SrVO;
import br.gov.caixa.siacg.model.vo.UnidadeVO;
import br.gov.caixa.siacg.service.DWAnaliseContratoService;
import br.gov.caixa.siacg.view.form.FiltroUnidadeVisao;
import br.gov.caixa.siacg.view.form.PainelGarantiaVisao;

/**
 * <p>
 * PainelGarantiaMB.
 * </p>
 * <p>
 * Descrição: Managed bean do painel de garantias.
 * </p>
 * <br>
 * <b>Empresa:</b> Cef - Caixa Econômica Federal
 *
 * @author Bruno Martins de Carvalho
 * @version 1.0
 */
/**
 * <p>
 * PainelGarantiaMB.
 * </p>
 * <p>
 * Descrição: ManagedBean para tela de painel de Garantias.
 * </p>
 * <br>
 * <b>Empresa:</b> Cef - Caixa Econômica Federal
 *
 * @author Bruno Martins de Carvalho
 * @version 1.0
 */
@ViewScoped
@ManagedBean
public class PainelGarantiaMB extends ManutencaoBean<DWAnaliseContrato> {

    /** serialVersionUID. */
    private static final long serialVersionUID = 3592961702405688182L;

    /** NOME_MANAGED_BEAN. */
    public static final String NOME_MANAGED_BEAN = "painelGarantiaMB";
    /** EL_MANAGED_BEAN. */
    public static final String EL_MANAGED_BEAN = "#{painelGarantiaMB}";

    /** DIRETORIO_PAGINAS. */
    private static final String DIRETORIO_PAGINAS = "/pages/";
    /** PREFIXO_CASO_USO. */
    private static final String PREFIXO_CASO_USO = "relatorioPainelGarantia";

    /** COLUMN_95_CONSTITUIDO. */
    private static final String COLUMN_95_CONSTITUIDO = "idNoventacincoConstituido";

    /** COLUMN_MENOR_95_ATE_7_DIAS. */
    private static final String COLUMN_MENOR_95_ATE_7_DIAS = "idNoventacincoAteSeteDias";

    /** COLUMN_MENOR_95_MAIOR_7_DIAS. */
    private static final String COLUMN_MENOR_95_MAIOR_7_DIAS = "idColumnNoventaCincoConstituidoSeteDiasMais";

    /** COLUMN_GARANTIAS_NAO_CONSTITUIDAS. */
    private static final String COLUMN_GARANTIAS_NAO_CONSTITUIDAS = "idColumnGarantiasNaoConstituidas";

    /** COLUMN_NAO_PARAMETRIZADO. */
    private static final String COLUMN_NAO_PARAMETRIZADO = "idColumnNaoParametrizado";

    /** COLUMN_NAO_ACOMPANHA. */
    private static final String COLUMN_NAO_ACOMPANHA = "idColumnNaoAcompanha";

    /** CAIXA. */
    private static final String CAIXA = "Caixa";
    /** SUAT. */
    private static final String DIRE = "DIRE";
    /** SR. */
    private static final String SR = "SR";
    /** UNIDADE. */
    private static final String UNIDADE = "UNIDADE";
    /** CONTRATO. */
    private static final String CONTRATO = "CONTRATO";

    /** CAMINHO_RELATORIO. */
    private static final String CAMINHO_RELATORIO = "/reports/";
    /** NOME_JASPER_PAINEL_GARANTIAS_RESUMO. */
    private static final String NOME_JASPER_PAINEL_GARANTIAS_RESUMO = "relatorio_painel_garantias_resumo.jasper";
    /** NOME_JASPER_PAINEL_GARANTIAS_BASE. */
    private static final String NOME_JASPER_PAINEL_GARANTIAS_BASE = "relatorio_painel_garantias_base.jasper";
    /** NOME_RELATORIO_PAINEL_GARANTIA. */
    private static final String NOME_RELATORIO_PAINEL_GARANTIA = "Relatorio_Painel_Garantia";
    /** NOME_ABA_RESUMO_RELATORIO. */
    private static final String NOME_ABA_RESUMO_RELATORIO = "RESUMO";
    /** NOME_ABA_BASE_RELATORIO. */
    private static final String NOME_ABA_BASE_RELATORIO = "BASE";
    /** QTDE_MAX_LINHAS. */
    private static final Integer QTDE_MAX_LINHAS = 10;

    /** NAO_EXISTEM_DADOS_PARA_GERAR_RELATORIO. */
    private static final String NAO_EXISTEM_DADOS_PARA_GERAR_RELATORIO = "MA011";

    /** service. */
    @Inject
    private DWAnaliseContratoService service;

    /** visao. */
    private PainelGarantiaVisao visao;

    /** Atributo filtroUnidadeMB. */
    @ManagedProperty(value = FiltroUnidadeMB.EL_MANAGED_BEAN)
    private FiltroUnidadeMB filtroUnidadeMB;

    /**
     * @see br.gov.caixa.pedesgo.arquitetura.controlador.AbstractBean#iniciar()
     */
    @Override
    public String iniciar() {

        this.getVisao().setFiltro(new PainelGarantiaTO());

        return PainelGarantiaMB.DIRETORIO_PAGINAS + this.getPrefixoCasoDeUso() + AbstractBean.SUFIXO_TELA_CONSULTA;
    }

    /**
     * <p>
     * Método responsável por atualizar os graficos ao iniciar a tela de painel
     * de garantias.
     * <p>
     *
     * @author Bruno Martins de Carvalho
     */
    public void atualizarGraficosInicio() {

        this.getFiltroUnidadeMB().configurarPermissao();

        this.iniciarListaComboSegmento();
        this.filtrarByCombo();
    }

    /**
     * <p>
     * Método responsável por realizar as consultas dos paineis.
     * <p>
     *
     * @author Bruno Martins de Carvalho
     */
    public void realizarConsultas() {

        final PainelGarantiaVisao visao = this.getVisao();

        this.limparListas();

        visao.setVrTotalConstituido(this.service.obterVrTotalPactuadoGeralContratos(visao.getFiltro()));

        if (UsuarioUtil.contemPermissao(NoFuncionalidadeEnum.PAINEL_GARANTIA_CONSTITUIDA_SATISFATORIO.getNoFuncionalidade(),
                EnumAcao.CONSULTAR.getNoAcao(), null, null)) {
            visao.setContratosNoventaCincoMaisConstituido(this.service.listarContratosConstituidosSatisfatorios(visao.getFiltro()));
        }

        if (UsuarioUtil.contemPermissao(NoFuncionalidadeEnum.PAINEL_GARANTIA_CONSTITUIDA_MEDIANA.getNoFuncionalidade(),
                EnumAcao.CONSULTAR.getNoAcao(), null, null)) {
            visao.setContratosNoventaCincoMenosSeteDiasConstituido(this.service.listarContratosConstituidosMedianos(visao.getFiltro()));
        }

        if (UsuarioUtil.contemPermissao(NoFuncionalidadeEnum.PAINEL_GARANTIA_CONSTITUIDA_INSATISFATORIO.getNoFuncionalidade(),
                EnumAcao.CONSULTAR.getNoAcao(), null, null)) {
            visao.setContratosNoventaCincoMaisSeteDiasConstituido(this.service.listarContratosConstituidosInsatisfatorios(visao.getFiltro()));
        }

        if (UsuarioUtil.contemPermissao(NoFuncionalidadeEnum.PAINEL_GARANTIA_CONSTITUIDA_INSATISFATORIO.getNoFuncionalidade(),
                EnumAcao.CONSULTAR.getNoAcao(), null, null)) {
            visao.setContratosGarantiasNaoConstituidas(this.service.listarContratosGarantiasNaoConstituidas(visao.getFiltro()));
        }

        if (UsuarioUtil.contemPermissao(NoFuncionalidadeEnum.PAINEL_CONTRATO_NAO_PARAMETRIZADO.getNoFuncionalidade(), EnumAcao.CONSULTAR.getNoAcao(),
                null, null)) {
            visao.setContratosNaoParametrizados(this.service.listarContratosNaoParametrizados(visao.getFiltro()));
        }

        if (UsuarioUtil.contemPermissao(NoFuncionalidadeEnum.PAINEL_GARANTIA_CONSTITUIDA_SATISFATORIO.getNoFuncionalidade(),
                EnumAcao.CONSULTAR.getNoAcao(), null, null)) {
            visao.setContratosNaoAcompanhados(this.service.listarContratosNaoAcompanhados(visao.getFiltro()));
        }
    }

    /**
     * <p>
     * Método responsável por filtrar de acordo com os dados informados no
     * filtro de unidade.
     * <p>
     *
     * @author Bruno Martins de Carvalho
     */
    public void filtrarByCombo() {

        final PainelGarantiaVisao visaoPainelGarantia = this.getVisao();
        final FiltroUnidadeVisao visaoFiltroUnidade = this.getFiltroUnidadeMB().getVisao();

        if (UtilObjeto.isReferencia(visaoFiltroUnidade.getNuUnidade()) && visaoFiltroUnidade.getNuUnidade() > 0) {
            visaoPainelGarantia.setTituloGrid(PainelGarantiaMB.CONTRATO);
            visaoPainelGarantia.setNivelConsulta(PainelGarantiaMB.UNIDADE);

            this.getFiltroUnidadeMB().selecionarUnidade(null);

        } else if (UtilObjeto.isReferencia(visaoFiltroUnidade.getNuSr()) && visaoFiltroUnidade.getNuSr() > 0) {
            visaoPainelGarantia.setTituloGrid(PainelGarantiaMB.UNIDADE);
            visaoPainelGarantia.setNivelConsulta(PainelGarantiaMB.SR);

            this.getFiltroUnidadeMB().selecionarSr(null);

        } else if (UtilObjeto.isReferencia(visaoFiltroUnidade.getNuSuat()) && visaoFiltroUnidade.getNuSuat() > 0) {
            visaoPainelGarantia.setTituloGrid(PainelGarantiaMB.SR);
            visaoPainelGarantia.setNivelConsulta(PainelGarantiaMB.DIRE);

            this.getFiltroUnidadeMB().selecionarSuat();

        } else {
            visaoPainelGarantia.setTituloGrid(PainelGarantiaMB.DIRE);
            visaoPainelGarantia.setNivelConsulta(PainelGarantiaMB.CAIXA);
        }

        this.atribuirCamposFiltro();

        this.realizarConsultas();
        this.atualizarGraficos();

    }

    /**
     * <p>
     * Método responsável por atribuir os campos do filtro de unidade para o
     * {@link PainelGarantiaTO} que é utilizado na consulta como filtro.
     * <p>
     *
     * @author Bruno Martins de Carvalho
     */
    private void atribuirCamposFiltro() {

        final PainelGarantiaVisao visaoPainelGarantia = this.getVisao();
        final FiltroUnidadeVisao visaoFiltroUnidade = this.getFiltroUnidadeMB().getVisao();

        visaoPainelGarantia.getFiltro().setNuSuat(
                UtilObjeto.isReferencia(visaoFiltroUnidade.getNuSuat()) && visaoFiltroUnidade.getNuSuat() != 0 ? String.valueOf(visaoFiltroUnidade
                        .getNuSuat()) : null);
        visaoPainelGarantia.getFiltro().setNuSr(
                UtilObjeto.isReferencia(visaoFiltroUnidade.getNuSr()) && visaoFiltroUnidade.getNuSr() != 0 ? String.valueOf(visaoFiltroUnidade
                        .getNuSr()) : null);
        visaoPainelGarantia.getFiltro().setNuUnidade(
                UtilObjeto.isReferencia(visaoFiltroUnidade.getNuUnidade()) && visaoFiltroUnidade.getNuUnidade() != 0 ? String
                        .valueOf(visaoFiltroUnidade.getNuUnidade()) : null);

    }

    /**
     * <p>
     * Método responsável por limpar as listas antes de cada execução das
     * consultas.
     * <p>
     *
     * @author Bruno Martins de Carvalho
     */
    private void limparListas() {
        final PainelGarantiaVisao visao = this.getVisao();

        visao.setContratosNoventaCincoMaisConstituido(null);
        visao.setContratosNoventaCincoMenosSeteDiasConstituido(null);
        visao.setContratosNoventaCincoMaisSeteDiasConstituido(null);
        visao.setContratosNaoParametrizados(null);
        visao.setContratosNaoAcompanhados(null);

    }

    /**
     * <p>
     * Método responsável por atualizar os valores dos gráficos.
     * <p>
     *
     * @author Bruno Martins de Carvalho
     */
    public void atualizarGraficos() {

        final PainelGarantiaVisao visao = this.getVisao();

        final BigDecimal qtdeNoventaCincoConst = visao.getContratosNoventaCincoMaisConstituido().isEmpty() ? BigDecimal.ZERO : visao
                .getContratosNoventaCincoMaisConstituido().get(0).getVrTotalConstituido();
        final BigDecimal qtdeMenorNoventaCincoAteSeteDias = visao.getContratosNoventaCincoMenosSeteDiasConstituido().isEmpty() ? BigDecimal.ZERO
                : visao.getContratosNoventaCincoMenosSeteDiasConstituido().get(0).getVrTotalConstituido();
        final BigDecimal qtdeMenorNoventaCincoMaisSeteDias = visao.getContratosNoventaCincoMaisSeteDiasConstituido().isEmpty() ? BigDecimal.ZERO
                : visao.getContratosNoventaCincoMaisSeteDiasConstituido().get(0).getVrTotalConstituido();
        final BigDecimal qtdeGarantiasNaoConstituidas = visao.getContratosGarantiasNaoConstituidas().isEmpty() ? BigDecimal.ZERO : visao
                .getContratosGarantiasNaoConstituidas().get(0).getVrTotalConstituido();

        final Integer qtdeNaoParametrizado = visao.getContratosNaoParametrizados().isEmpty() ? 0 : visao.getContratosNaoParametrizados().get(0)
                .getQtContratoTotal();
        final Integer qtdeNaoAcompanhado = visao.getContratosNaoAcompanhados().isEmpty() ? 0 : visao.getContratosNaoAcompanhados().get(0)
                .getQtContratoTotal();

        final BigDecimal totalGeral = visao.getVrTotalConstituido();

        for (final UIComponent coluna : this.getVisao().getListaColunas()) {
            if (coluna.getId().equalsIgnoreCase(PainelGarantiaMB.COLUMN_95_CONSTITUIDO) && coluna.isRendered()) {
                this.service.executaFuncaoJavaScript("graficoPainelGarantia('noventacinco_constituido'," + qtdeNoventaCincoConst + "," + totalGeral
                        + ");");
                continue;
            }
            if (coluna.getId().equalsIgnoreCase(PainelGarantiaMB.COLUMN_MENOR_95_ATE_7_DIAS) && coluna.isRendered()) {
                this.service.executaFuncaoJavaScript("graficoPainelGarantia('noventa_cinco_ate_sete_dias'," + qtdeMenorNoventaCincoAteSeteDias + ","
                        + totalGeral + ");");
                continue;
            }
            if (coluna.getId().equalsIgnoreCase(PainelGarantiaMB.COLUMN_MENOR_95_MAIOR_7_DIAS) && coluna.isRendered()) {
                this.service.executaFuncaoJavaScript("graficoPainelGarantia('noventacinco_mais_sete_dias'," + qtdeMenorNoventaCincoMaisSeteDias + ","
                        + totalGeral + ");");
                continue;
            }
            if (coluna.getId().equalsIgnoreCase(PainelGarantiaMB.COLUMN_GARANTIAS_NAO_CONSTITUIDAS) && coluna.isRendered()) {
                this.service.executaFuncaoJavaScript("graficoPainelGarantia('garantias_nao_constituidas'," + qtdeGarantiasNaoConstituidas + ","
                        + totalGeral + ");");
                continue;
            }
            if (coluna.getId().equalsIgnoreCase(PainelGarantiaMB.COLUMN_NAO_PARAMETRIZADO) && coluna.isRendered()) {
                this.service.executaFuncaoJavaScript("imprimeTotal('nao_parametrizado'," + qtdeNaoParametrizado + ");");
                continue;
            }
            if (coluna.getId().equalsIgnoreCase(PainelGarantiaMB.COLUMN_NAO_ACOMPANHA) && coluna.isRendered()) {
                this.service.executaFuncaoJavaScript("imprimeTotal('nao_acompanha'," + qtdeNaoAcompanhado + ");");
            }
        }

        this.atualizarGrid();

    }

    /**
     * <p>
     * Método responsável por fazer a chamada às consultas ao DW quando é feito
     * o click na linha do grid. É informado "grid" para saber a origem da ação.
     * Pois a origem da consulta também pode ser o "combo".
     * </p>
     *
     * @param painelGarantiaTO
     *            valor a ser atribuido
     * @author Bruno Martins de Carvalho
     */
    public void chamarConsultaPeloGrid(final PainelGarantiaTO painelGarantiaTO) {

        final FiltroUnidadeVisao visaoFiltroUnidade = this.getFiltroUnidadeMB().getVisao();

        if (painelGarantiaTO.getCoIdentificador() != null) {
        	if (this.visao.getNivelConsulta().equals(PainelGarantiaMB.CAIXA)) {
        		visaoFiltroUnidade.setNuSuat(Integer.valueOf(painelGarantiaTO.getCoIdentificador()));
        	} else if (this.visao.getNivelConsulta().equals(PainelGarantiaMB.DIRE)) {
        		visaoFiltroUnidade.setNuSr(Integer.valueOf(painelGarantiaTO.getCoIdentificador()));
        	} else if (this.visao.getNivelConsulta().equals(PainelGarantiaMB.SR)) {
        		visaoFiltroUnidade.setNuUnidade(Integer.valueOf(painelGarantiaTO.getCoIdentificador()));
        	}
        }

        this.filtrarByCombo();

    }

    /**
     * <p>
     * Método responsável por atualizar a quantidade de linhas dos paineis para
     * ficarem do mesmo tamanho.
     * <p>
     *
     * @author Bruno Martins de Carvalho
     */
    public void atualizarGrid() {

        final PainelGarantiaVisao visao = this.getVisao();

        final Integer garantiasSatisfatorias = visao.getContratosNoventaCincoMaisConstituido().size();
        final Integer garantiasMedianas = visao.getContratosNoventaCincoMenosSeteDiasConstituido().size();
        final Integer garantiasInsatisfatorias = visao.getContratosNoventaCincoMaisSeteDiasConstituido().size();
        final Integer garantiasNaoConstituidas = visao.getContratosGarantiasNaoConstituidas().size();
        final Integer garantiasNaoParametrizadas = visao.getContratosNaoParametrizados().size();
        final Integer garantiasNaoAcompanhadas = visao.getContratosNaoAcompanhados().size();

        Integer maiorGrid = 0;

        final PainelGarantiaTO painelGarantiaTO = new PainelGarantiaTO();

        if (garantiasSatisfatorias > maiorGrid) {
            maiorGrid = garantiasSatisfatorias;
        }

        if (garantiasMedianas > maiorGrid) {
            maiorGrid = garantiasMedianas;
        }

        if (garantiasInsatisfatorias > maiorGrid) {
            maiorGrid = garantiasInsatisfatorias;
        }

        if (garantiasNaoConstituidas > maiorGrid) {
            maiorGrid = garantiasInsatisfatorias;
        }

        if (garantiasNaoParametrizadas > maiorGrid) {
            maiorGrid = garantiasNaoParametrizadas;
        }

        if (garantiasNaoAcompanhadas > maiorGrid) {
            maiorGrid = garantiasNaoAcompanhadas;
        }

        if (maiorGrid > 0) {
            if (garantiasSatisfatorias < maiorGrid) {
                for (int i = garantiasSatisfatorias; i < maiorGrid && i < PainelGarantiaMB.QTDE_MAX_LINHAS; i++) {
                    visao.getContratosNoventaCincoMaisConstituido().add(painelGarantiaTO);
                }
            }

            if (garantiasMedianas < maiorGrid) {
                for (int i = garantiasMedianas; i < maiorGrid && i < PainelGarantiaMB.QTDE_MAX_LINHAS; i++) {
                    visao.getContratosNoventaCincoMenosSeteDiasConstituido().add(painelGarantiaTO);
                }
            }

            if (garantiasInsatisfatorias < maiorGrid) {
                for (int i = garantiasInsatisfatorias; i < maiorGrid && i < PainelGarantiaMB.QTDE_MAX_LINHAS; i++) {
                    visao.getContratosNoventaCincoMaisSeteDiasConstituido().add(painelGarantiaTO);
                }
            }

            if (garantiasNaoConstituidas < maiorGrid) {
                for (int i = garantiasNaoConstituidas; i < maiorGrid && i < PainelGarantiaMB.QTDE_MAX_LINHAS; i++) {
                    visao.getContratosGarantiasNaoConstituidas().add(painelGarantiaTO);
                }
            }

            if (garantiasNaoParametrizadas < maiorGrid) {
                for (int i = garantiasNaoParametrizadas; i < maiorGrid && i < PainelGarantiaMB.QTDE_MAX_LINHAS; i++) {
                    visao.getContratosNaoParametrizados().add(painelGarantiaTO);
                }
            }

            if (garantiasNaoAcompanhadas < maiorGrid) {
                for (int i = garantiasNaoAcompanhadas; i < maiorGrid && i < PainelGarantiaMB.QTDE_MAX_LINHAS; i++) {
                    visao.getContratosNaoAcompanhados().add(painelGarantiaTO);
                }
            }
        }
    }

    /**
     * <p>
     * Método responsável por inicializar a lista de segmentos de acordo com as
     * permissões do usuário logado.
     * <p>
     *
     * @author Bruno Martins de Carvalho
     */
    private void iniciarListaComboSegmento() {
        final PainelGarantiaVisao visao = this.getVisao();

        final Collection<Segmento> listaSegmento = this.service.listarSegmentos();

        visao.setSegmentoList(new ArrayList<Segmento>());

        for (final Segmento segmento : listaSegmento) {
            if (UsuarioUtil.contemPermissao(segmento.getDeFuncionalidade(), EnumAcao.CONSULTAR.getNoAcao(), null, null)) {
                visao.getSegmentoList().add(segmento);
            }
        }
    }

    /**
     * <p>
     * Método responsável por realizar novas consultas de acordo com os
     * segmentos selecionados.
     * <p>
     *
     * @author Bruno Martins de Carvalho
     */
    public void selecionarSegmento() {
        this.realizarConsultas();

        this.atualizarGraficos();
    }

    /**
     * <p>
     * Método responsável por exportar o relatorio de painel de garantias.
     * <p>
     *
     * @author Bruno Martins de Carvalho
     */
    public void exportarRelatorio() {

        final Map<String, Object> parametros = new LinkedHashMap<>();

        List<PainelGarantiaTO> colecaoPainelGarantiaResumo = new ArrayList<>();

        parametros.put("NIVEL_CONSULTA", this.obterNoUnidadeConsulta());

        if (!this.getVisao().getNivelConsulta().equals(PainelGarantiaMB.UNIDADE)) {
            colecaoPainelGarantiaResumo = this.service.listarUnidadesPainelGarantia(this.getVisao().getFiltro());
        }

        List<RelatorioBasePainelGarantiaTO> colecaoPainelGarantiaBase = this.service.listarAnaliseContratoParaRelatorio(this.getVisao().getFiltro());

        if (CollectionUtils.isNotEmpty(colecaoPainelGarantiaBase)) {
            try {
                final String[] nomesAba = { PainelGarantiaMB.NOME_ABA_RESUMO_RELATORIO, PainelGarantiaMB.NOME_ABA_BASE_RELATORIO };

                UtilRelatorio
                        .getInstancia()
                        .addNomesAba(nomesAba)
                        .addCaminhoColecaoAListaCaminhoRelatorioColecao(
                                PainelGarantiaMB.CAMINHO_RELATORIO + PainelGarantiaMB.NOME_JASPER_PAINEL_GARANTIAS_RESUMO,
                                colecaoPainelGarantiaResumo)
                        .addCaminhoColecaoAListaCaminhoRelatorioColecao(
                                PainelGarantiaMB.CAMINHO_RELATORIO + PainelGarantiaMB.NOME_JASPER_PAINEL_GARANTIAS_BASE, colecaoPainelGarantiaBase)
                        .addNomeRelatorio(PainelGarantiaMB.NOME_RELATORIO_PAINEL_GARANTIA).addExtensaoArquivo(EnumExtensaoArquivo.XLSX)
                        .addParametros(parametros).addResposta(super.getResponse()).gerarRelatorioComAbas();

            } catch (final Exception e) {
                LogCefUtil.error("Não foi possivel gerar o XLS Painel de Garantias - " + e.getMessage());
                LogCefUtil.error(e);
            }
        } else {
            super.adicionaMensagemDeAlerta(PainelGarantiaMB.NAO_EXISTEM_DADOS_PARA_GERAR_RELATORIO);
        }
    }

    /**
     * <p>
     * Método responsável por obter o nome da unidade, sr ou suat que está sendo
     * consultada no nivel atual.
     * <p>
     *
     * @return String
     * @author Bruno Martins de Carvalho
     */
    private String obterNoUnidadeConsulta() {

        final PainelGarantiaVisao visaoPainelGarantia = this.getVisao();
        final FiltroUnidadeVisao visaoFiltroUnidade = this.getFiltroUnidadeMB().getVisao();

        String noUnidade = "";

        if (UtilObjeto.isReferencia(visaoFiltroUnidade.getNuUnidade()) && visaoFiltroUnidade.getNuUnidade() > 0) {

            if (UtilObjeto.isReferencia(visaoFiltroUnidade.getNomeUnidade()) && !visaoFiltroUnidade.getNomeUnidade().isEmpty()) {
                noUnidade = visaoFiltroUnidade.getNomeUnidade();
            } else {
                for (final UnidadeVO unidade : visaoFiltroUnidade.getUnidadeList()) {
                    if (unidade.getCoUnidadeVO().equals(Integer.valueOf(visaoPainelGarantia.getFiltro().getNuUnidade()))) {
                        noUnidade = unidade.getNoUnidadeVO();
                        break;
                    }
                }
            }
        } else if (UtilObjeto.isReferencia(visaoFiltroUnidade.getNuSr()) && visaoFiltroUnidade.getNuSr() > 0) {
            if (UtilObjeto.isReferencia(visaoFiltroUnidade.getNomeSr()) && !visaoFiltroUnidade.getNomeSr().isEmpty()) {
                noUnidade = visaoFiltroUnidade.getNomeSr();
            } else {
                for (final SrVO unidade : visaoFiltroUnidade.getSrList()) {
                    if (unidade.getNuSrVO().equals(Integer.valueOf(visaoPainelGarantia.getFiltro().getNuSr()))) {
                        noUnidade = unidade.getSgSrVO();
                        break;
                    }
                }
            }
        } else if (UtilObjeto.isReferencia(visaoFiltroUnidade.getNuSuat()) && visaoFiltroUnidade.getNuSuat() > 0) {
            if (UtilObjeto.isReferencia(visaoFiltroUnidade.getNomeSuat()) && !visaoFiltroUnidade.getNomeSuat().isEmpty()) {
                noUnidade = visaoFiltroUnidade.getNomeSuat();
            } else {
                for (final UnidadeVO unidade : visaoFiltroUnidade.getSuatList()) {
                    if (unidade.getCoUnidadeVO().equals(Integer.valueOf(visaoPainelGarantia.getFiltro().getNuSuat()))) {
                        noUnidade = unidade.getNoUnidadeVO();
                        break;
                    }
                }
            }
        } else {
            noUnidade = PainelGarantiaMB.CAIXA;
        }

        return noUnidade;
    }

    /**
     * @see br.gov.caixa.pedesgo.arquitetura.controlador.AbstractBean#getPrefixoCasoDeUso()
     */
    @Override
    protected String getPrefixoCasoDeUso() {
        return PainelGarantiaMB.PREFIXO_CASO_USO;
    }

    /**
     * @see br.gov.caixa.pedesgo.arquitetura.controlador.AbstractBean#getService()
     */
    @Override
    @SuppressWarnings("unchecked")
    public DWAnaliseContratoService getService() {
        return this.service;
    }

    /**
     * @see br.gov.caixa.pedesgo.arquitetura.controlador.AbstractBean#getVisao()
     */
    @Override
    public PainelGarantiaVisao getVisao() {
        if (!UtilObjeto.isReferencia(this.visao)) {
            this.visao = new PainelGarantiaVisao();
        }
        return this.visao;
    }

    /**
     * Retorna o valor do atributo filtroUnidadeMB.
     *
     * @return filtroUnidadeMB
     */
    public FiltroUnidadeMB getFiltroUnidadeMB() {
        return this.filtroUnidadeMB;
    }

    /**
     * Define o valor do atributo filtroUnidadeMB.
     *
     * @param filtroUnidadeMB
     *            valor a ser atribuído
     */
    public void setFiltroUnidadeMB(final FiltroUnidadeMB filtroUnidadeMB) {
        this.filtroUnidadeMB = filtroUnidadeMB;
    }

    /**
     * @see br.gov.caixa.pedesgo.arquitetura.controlador.AbstractBean#getNomeVarResourceBundle()
     */
    @Override
    public String getNomeVarResourceBundle() {
        return "msgApp";
    }
}
