/*
 * Copyright (c) 2016 Caixa Econômica Federal. Todos os direitos
 * reservados.
 *
 * Caixa Econômica Federal - SIACG_dev
 *
 * Este software foi desenvolvido sob demanda da CAIXA e está
 * protegido por leis de direitos autorais e tratados internacionais. As
 * condições de cópia e utilização do total ou partes dependem de autorização da
 * pessoa. Cópias não são permitidas sem expressa autorização. Não pode ser
 * comercializado ou utilizado para propósitos particulares.
 *
 * Uso exclusivo da Caixa Econômica Federal. A reprodução ou distribuição não
 * autorizada deste programa ou de parte dele, resultará em punições civis e
 * criminais e os infratores incorrem em sanções previstas na legislação em
 * vigor.
 *
 * Histórico do Subversion:
 *
 * LastChangedRevision: $Revision$
 * LastChangedBy: $Author$
 * LastChangedDate: $Date$
 *
 * HeadURL: $HeadURL$
 *
 */
package br.gov.caixa.siacg.comum.to;

import java.util.ArrayList;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

/**
 * 
 * <p>RespostaAcaoPreventivaTO</p>
 *
 * <p>Retorno do Serviço de Bloqueio e desbloqueio de garantias</p>
 *
 * <br><b>Empresa:</b> Cef - Caixa Econômica Federal
 *
 *
 * @author p575337
 *
 * @version 1.0
 */
@JsonIgnoreProperties(ignoreUnknown = true)
@ApiModel(value="RespostaAcaoPreventiva")
public class RespostaAcaoPreventivaTO {

    @ApiModelProperty(value = "Código da mensagem retornada pelo SIACG.", example="00")
    private String codigoRetorno;
    @ApiModelProperty(value = "Mensagem retornada pelo SIACG.", example="SUCESSO")
    private String mensagem;
    
    List<GarantiaAcaoPreventivaTO> garantias;

    /**
     * <p>Retorna o valor do atributo codigoRetorno</p>.
     *
     * @return codigoRetorno
    */
    public String getCodigoRetorno() {
        return this.codigoRetorno;
    }

    /**
     * <p>Define o valor do atributo codigoRetorno</p>.
     *
     * @param codigoRetorno valor a ser atribuído
    */
    public void setCodigoRetorno(String codigoRetorno) {
        this.codigoRetorno = codigoRetorno;
    }

    /**
     * <p>Retorna o valor do atributo mensagem</p>.
     *
     * @return mensagem
    */
    public String getMensagem() {
        return this.mensagem;
    }

    /**
     * <p>Define o valor do atributo mensagem</p>.
     *
     * @param mensagem valor a ser atribuído
    */
    public void setMensagem(String mensagem) {
        this.mensagem = mensagem;
    }

    /**
     * <p>Retorna o valor do atributo garantias</p>.
     *
     * @return garantias
    */
    public List<GarantiaAcaoPreventivaTO> getGarantias() {
	if (garantias == null) {
	    garantias = new ArrayList<>();
	}
        return this.garantias;
    }

    /**
     * <p>Define o valor do atributo garantias</p>.
     *
     * @param garantias valor a ser atribuído
    */
    public void setGarantias(List<GarantiaAcaoPreventivaTO> garantias) {
        this.garantias = garantias;
    }
}