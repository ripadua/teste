package br.gov.caixa.siacg.util;

import java.util.Collection;

/**
 * <p>
 * ValidacaoUtil.
 * </p>
 * <p>
 * Descrição: ValidacaoUtil
 * </p>
 * <br>
 * <b>Empresa:</b> Cef - Caixa Econômica Federal
 *
 * @version 1.0
 */
public final class ValidacaoUtil {

    /**
     * Construtor.
     *
     */
    private ValidacaoUtil() {
    	throw new IllegalStateException("Classe de Utilidade");
    }

    /**
     * <p>
     * Método responsável por .
     * <p>
     *
     * @param objeto
     *            valor a ser atribuido
     * @return boolean
     */
    public static boolean isNaoNulo(final Object objeto) {
        return !ValidacaoUtil.isNulo(objeto);
    }

    /**
     * <p>
     * Método responsável por .
     * <p>
     *
     * @param objeto
     *            valor a ser atribuido
     * @return boolean
     */
    public static boolean isNulo(final Object objeto) {
        return objeto == null;
    }

    /**
     * <p>
     * Método responsável por .
     * <p>
     *
     * @param objeto
     *            valor a ser atribuido
     * @return boolean
     */
    public static boolean isNaoVazio(final Object objeto) {
        return !ValidacaoUtil.isVazio(objeto);
    }

    /**
     * <p>
     * Método responsável por .
     * <p>
     *
     * @param objeto
     *            valor a ser atribuido
     * @return boolean
     */
    @SuppressWarnings("rawtypes")
    public static boolean isVazio(final Object objeto) {
        if (ValidacaoUtil.isNulo(objeto)) {
            return Boolean.TRUE;
        } else if (objeto instanceof Collection) {
            return ((Collection) objeto).isEmpty();
        } else if (objeto instanceof Object[]) {
            return ((Object[]) objeto).length == 0;
        } else {
            return objeto.toString().trim().isEmpty();
        }
    }

    /**
     * <p>
     * Método responsável por .
     * <p>
     *
     * @param valores
     *            valor a ser atribuido
     * @return boolean
     */
    public static boolean isPeloMenosUmVerdadeiro(final boolean... valores) {
        boolean isPeloMenosUmVerdadeiro = false;
        for (final boolean valor : valores) {
            if (valor) {
                isPeloMenosUmVerdadeiro = true;
                break;
            }
        }
        return isPeloMenosUmVerdadeiro;
    }

    /**
     * <p>
     * Método responsável por .
     * <p>
     *
     * @param valores
     *            valor a ser atribuido
     * @return boolean
     */
    public static boolean isTodosVerdadeiros(final boolean... valores) {
        boolean isTodosVerdadeiros = true;
        for (final boolean valor : valores) {
            if (!valor) {
                isTodosVerdadeiros = false;
                break;
            }
        }
        return isTodosVerdadeiros;
    }

    /**
     * <p>
     * Método responsável por .
     * <p>
     *
     * @param valores
     *            valor a ser atribuido
     * @return boolean
     */
    public static boolean isPeloMenosUmFalso(final boolean... valores) {
        return !ValidacaoUtil.isTodosVerdadeiros(valores);
    }

    /**
     * <p>
     * Método responsável por .
     * <p>
     *
     * @param valores
     *            valor a ser atribuido
     * @return boolean
     */
    public static boolean isTodosFalsos(final boolean... valores) {
        return !ValidacaoUtil.isPeloMenosUmVerdadeiro(valores);
    }

    /**
     * <p>
     * Método responsável por .
     * <p>
     *
     * @param valor
     *            valor a ser atribuido
     * @return boolean
     */
    public static boolean isValorZerado(final Long valor) {
        return ValidacaoUtil.isNaoNulo(valor) && valor.equals(Long.valueOf(0));
    }

    /**
     * <p>
     * Método responsável por .
     * <p>
     *
     * @param valor
     *            valor a ser atribuido
     * @return boolean
     */
    public static boolean isValorZerado(final Integer valor) {
        return ValidacaoUtil.isNaoNulo(valor) && valor.equals(Integer.valueOf(0));
    }

}
