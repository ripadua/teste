package br.gov.caixa.siacg.util;

import br.gov.caixa.pedesgo.arquitetura.util.UtilString;
import br.gov.caixa.pedesgo.arquitetura.enumerador.EnumTipoFormatacao;
import br.gov.caixa.pedesgo.arquitetura.util.UtilCnpj;
import br.gov.caixa.pedesgo.arquitetura.util.UtilCpf;
import br.gov.caixa.pedesgo.arquitetura.util.UtilFormatacao;
import br.gov.caixa.siacg.model.enums.TipoPessoaEnum;

/**
 * Classe utilitária responsável por formatar CPF/CNPJ.
 * Utilizada como intermediária entre a {@link UtilFormatacao} verificando o tipo da pessoa e chamando a formatação correspondente.
 * 
 * @author f503697
 */
public class TipoPessoaUtil {
	
	/**
	 * Formata o número informado verificando o tipo da pessoa.
	 * 
	 * @param numero a ser formatado.
	 * @param tipo a ser verificado.
	 * @return número da pessoa formatado.
	 */
	public static String formatar(String numero, String tipo) {
		try {
		    if (TipoPessoaEnum.J.equals(TipoPessoaEnum.toTipoPessoa(tipo))) {
			return UtilFormatacao.formatar(numero, EnumTipoFormatacao.CNPJ);
		    }
		    
		    return UtilFormatacao.formatar(numero, EnumTipoFormatacao.CPF);
		    
		} catch (Exception e) {
		    LogCEF.error(String.format("Ocorreu erro ao formatar o identificador %s para o tipo de pessoa %s", numero, tipo));
		    return numero;
		}
	}
	

	/**
	 * Formata o número informado verificando o tipo da pessoa.
	 * 
	 * @param numero a ser formatado.
	 * @return número da pessoa formatado.
	 */
	public static String formatar(String numero) {
		return UtilCnpj.isCNPJSemFormatacao(numero) ? formatar(numero, "PJ") : formatar(numero, "PF");
	}
	
	/**
	 * Remove a formatação do CPF/CNPJ informado.
	 * 
	 * @param numero a ser verificado
	 * @return numero serm formatação
	 */
	public static String removerFormatacao(String numero) {
		if (!UtilString.isVazio(numero)) {
			if (UtilCpf.isCPF(numero)) {
				return UtilFormatacao.removerMascara(numero, EnumTipoFormatacao.CPF);
			} else {
				return UtilFormatacao.removerMascara(numero, EnumTipoFormatacao.CNPJ);
			}
		}
		
		return null;
	}
}
