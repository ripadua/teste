/**
 * Copyright (c) 2020 Caixa Econômica Federal. Todos os direitos
 * reservados.
 *
 * Caixa Econômica Federal - SIACG
 *
 * Este software foi desenvolvido sob demanda da CAIXA e está
 * protegido por leis de direitos autorais e tratados internacionais. As
 * condições de cópia e utilização total ou partes dependem de autorização da
 * empresa. Cópias não são permitidas sem expressa autorização. Não pode ser
 * comercializado ou utilizado para propósitos particulares.
 *
 * Uso exclusivo da Caixa Econômica Federal. A reprodução ou distribuição não
 * autorizada deste programa ou de parte dele, resultará em punições civis e
 * criminais e os infratores incorrem em sanções previstas na legislação em
 * vigor.
 *
 * Histórico do TFS:
 *
 * LastChangedRevision: $Revision$
 * LastChangedBy: $Author$
 * LastChangedDate: $Date$
 *
 * HeadURL: $HeadURL$
 *
 */
package br.gov.caixa.siacg.comum.to;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;

import br.gov.caixa.pedesgo.arquitetura.util.UtilObjeto;
import br.gov.caixa.siacg.model.domain.BandeiraCartao;
import br.gov.caixa.siacg.model.domain.Saldo;
import br.gov.caixa.siacg.model.domain.SaldoCartaoBandeira;

/**
 * <p>
 * SaldoCalculoTO
 * </p>
 *
 * <p>
 * Descrição: Representa a entidade de saldo no calculo de garantias
 * </p>
 *
 * <br>
 * <b>Empresa:</b> Cef - Caixa Econômica Federal
 *
 *
 * @author f541915
 *
 * @version 1.0
 */
public class SaldoCalculoTO implements Serializable {

	/** Atributo serialVersionUID. */
	private static final long serialVersionUID = 1L;

	@JsonProperty("nu_saldo")
	private Integer nuSaldo;

	/** Atributo valor saldo líquido duplicata estoque. */
	@JsonProperty("vr_duplicata_estoque")
	private BigDecimal vrDuplicataEstoque;

	/** Atributo valor saldo líquido duplicata fluxo. */
	@JsonProperty("vr_duplicata_fluxo")
	private BigDecimal vrDuplicataFluxo;

	/** Atributo valor saldo líquido aplicação financeira estoque. */
	@JsonProperty("vr_aplicacao_estoque")
	private BigDecimal vrAplicacaoEstoque;

	/** Atributo valor saldo líquido de cheque estoque. */
	@JsonProperty("vr_cheque_estoque")
	private BigDecimal vrChequeEstoque;

	/** Atributo valor saldo líquido de contas não livre de movimentação. */
	@JsonProperty("vr_conta_nlm")
	private BigDecimal vrContaNLM;

	/** Atributo saldosCartaoBandeira. */
	@JsonProperty("lista_saldo_cartao_bandeira")
	private List<SaldoCartaoBandeiraCalculoTO> listaSaldosCartaoBandeira;

	/**
	 * <p>
	 * Retorna o valor do atributo nuSaldo
	 * </p>
	 * .
	 *
	 * @return nuSaldo
	 */
	public Integer getNuSaldo() {
		return this.nuSaldo;
	}

	/**
	 * <p>
	 * Define o valor do atributo nuSaldo
	 * </p>
	 * .
	 *
	 * @param nuSaldo
	 *            valor a ser atribuído
	 */
	public void setNuSaldo(Integer nuSaldo) {
		this.nuSaldo = nuSaldo;
	}

	/**
	 * <p>
	 * Retorna o valor do atributo vrDuplicataEstoque
	 * </p>
	 * .
	 *
	 * @return vrDuplicataEstoque
	 */
	public BigDecimal getVrDuplicataEstoque() {
		return this.vrDuplicataEstoque;
	}

	/**
	 * <p>
	 * Define o valor do atributo vrDuplicataEstoque
	 * </p>
	 * .
	 *
	 * @param vrDuplicataEstoque
	 *            valor a ser atribuído
	 */
	public void setVrDuplicataEstoque(BigDecimal vrDuplicataEstoque) {
		this.vrDuplicataEstoque = vrDuplicataEstoque;
	}

	/**
	 * <p>
	 * Retorna o valor do atributo vrDuplicataFluxo
	 * </p>
	 * .
	 *
	 * @return vrDuplicataFluxo
	 */
	public BigDecimal getVrDuplicataFluxo() {
		return this.vrDuplicataFluxo;
	}

	/**
	 * <p>
	 * Define o valor do atributo vrDuplicataFluxo
	 * </p>
	 * .
	 *
	 * @param vrDuplicataFluxo
	 *            valor a ser atribuído
	 */
	public void setVrDuplicataFluxo(BigDecimal vrDuplicataFluxo) {
		this.vrDuplicataFluxo = vrDuplicataFluxo;
	}

	/**
	 * <p>
	 * Retorna o valor do atributo vrAplicacaoEstoque
	 * </p>
	 * .
	 *
	 * @return vrAplicacaoEstoque
	 */
	public BigDecimal getVrAplicacaoEstoque() {
		return this.vrAplicacaoEstoque;
	}

	/**
	 * <p>
	 * Define o valor do atributo vrAplicacaoEstoque
	 * </p>
	 * .
	 *
	 * @param vrAplicacaoEstoque
	 *            valor a ser atribuído
	 */
	public void setVrAplicacaoEstoque(BigDecimal vrAplicacaoEstoque) {
		this.vrAplicacaoEstoque = vrAplicacaoEstoque;
	}

	/**
	 * <p>
	 * Retorna o valor do atributo vrChequeEstoque
	 * </p>
	 * .
	 *
	 * @return vrChequeEstoque
	 */
	public BigDecimal getVrChequeEstoque() {
		return this.vrChequeEstoque;
	}

	/**
	 * <p>
	 * Define o valor do atributo vrChequeEstoque
	 * </p>
	 * .
	 *
	 * @param vrChequeEstoque
	 *            valor a ser atribuído
	 */
	public void setVrChequeEstoque(BigDecimal vrChequeEstoque) {
		this.vrChequeEstoque = vrChequeEstoque;
	}

	/**
	 * <p>
	 * Retorna o valor do atributo vrContaNLM
	 * </p>
	 * .
	 *
	 * @return vrContaNLM
	 */
	public BigDecimal getVrContaNLM() {
		return this.vrContaNLM;
	}

	/**
	 * <p>
	 * Define o valor do atributo vrContaNLM
	 * </p>
	 * .
	 *
	 * @param vrContaNLM
	 *            valor a ser atribuído
	 */
	public void setVrContaNLM(BigDecimal vrContaNLM) {
		this.vrContaNLM = vrContaNLM;
	}

	/**
	 * <p>
	 * Retorna o valor do atributo listaSaldosCartaoBandeira
	 * </p>
	 * .
	 *
	 * @return listaSaldosCartaoBandeira
	 */
	public List<SaldoCartaoBandeiraCalculoTO> getListaSaldosCartaoBandeira() {
		if (this.listaSaldosCartaoBandeira == null) {
			this.listaSaldosCartaoBandeira = new ArrayList<>();
		}
		return this.listaSaldosCartaoBandeira;
	}

	/**
	 * <p>
	 * Define o valor do atributo listaSaldosCartaoBandeira
	 * </p>
	 * .
	 *
	 * @param listaSaldosCartaoBandeira
	 *            valor a ser atribuído
	 */
	public void setListaSaldosCartaoBandeira(List<SaldoCartaoBandeiraCalculoTO> listaSaldosCartaoBandeira) {
		this.listaSaldosCartaoBandeira = listaSaldosCartaoBandeira;
	}

	/**
	 * @see java.lang.Object#toString()
	*/
	@Override
	public String toString() {
		return "SaldoCalculoTO [nuSaldo=" + nuSaldo + ", vrDuplicataEstoque=" + vrDuplicataEstoque + ", vrDuplicataFluxo=" + vrDuplicataFluxo
				+ ", vrAplicacaoEstoque=" + vrAplicacaoEstoque + ", vrChequeEstoque=" + vrChequeEstoque + ", vrContaNLM=" + vrContaNLM + "]";
	}
	
	  public Saldo converterDeSaldoCalculoTO() {

		Saldo saldo = null;

		if (UtilObjeto.isReferencia(this.getNuSaldo())) {

		    saldo = new Saldo();
		    saldo.setNuSaldo(this.getNuSaldo());
		    saldo.setVrDuplicataEstoque(this.getVrDuplicataEstoque());
		    saldo.setVrDuplicataFluxo(this.getVrDuplicataFluxo());
		    saldo.setVrAplicacaoEstoque(this.getVrAplicacaoEstoque());
		    saldo.setVrChequeEstoque(this.getVrChequeEstoque());
		    saldo.setVrContaNLM(this.getVrContaNLM());

		    for (SaldoCartaoBandeiraCalculoTO saldoCartaoBandeiraTO : this.getListaSaldosCartaoBandeira()) {
			SaldoCartaoBandeira saldoCartaoBandeira = new SaldoCartaoBandeira();
			saldoCartaoBandeira.setNuSaldoCartaoBandeira(saldoCartaoBandeiraTO.getNuSaldoCartaoBandeira());
			saldoCartaoBandeira.setSaldo(saldo);
			saldoCartaoBandeira.setVrCartaoEstoque(saldoCartaoBandeiraTO.getVrCartaoEstoque());
			saldoCartaoBandeira.setVrCartaoFluxo(saldoCartaoBandeiraTO.getVrCartaoFluxo());
			BandeiraCartao bandeiraCartao = new BandeiraCartao();
			bandeiraCartao.setNuBandeiraCartao(saldoCartaoBandeiraTO.getNuBandeiraCartao());
			saldoCartaoBandeira.setBandeiraCartao(bandeiraCartao);
			saldo.getSaldosCartaoBandeira().add(saldoCartaoBandeira);
		    }

		}

		return saldo;
	    }
}
