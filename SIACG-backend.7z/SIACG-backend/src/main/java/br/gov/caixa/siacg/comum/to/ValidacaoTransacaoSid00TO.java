/*
 * Copyright (c) 2016 Caixa Econômica Federal. Todos os direitos
 * reservados.
 *
 * Caixa Econômica Federal - SIACG_dev
 *
 * Este software foi desenvolvido sob demanda da CAIXA e está
 * protegido por leis de direitos autorais e tratados internacionais. As
 * condições de cópia e utilização do total ou partes dependem de autorização da
 * pessoa. Cópias não são permitidas sem expressa autorização. Não pode ser
 * comercializado ou utilizado para propósitos particulares.
 *
 * Uso exclusivo da Caixa Econômica Federal. A reprodução ou distribuição não
 * autorizada deste programa ou de parte dele, resultará em punições civis e
 * criminais e os infratores incorrem em sanções previstas na legislação em
 * vigor.
 *
 * Histórico do Subversion:
 *
 * LastChangedRevision: $Revision$
 * LastChangedBy: $Author$
 * LastChangedDate: $Date$
 *
 * HeadURL: $HeadURL$
 *
 */
package br.gov.caixa.siacg.comum.to;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * 
 * <p>ValidacaoTransacaoSid00TO</p>
 *
 * <p>Descrição: Descrição do tipo</p>
 *
 * <br><b>Empresa:</b> Cef - Caixa Econômica Federal
 *
 *
 * @author p575337
 *
 * @version 1.0
 */
@JsonIgnoreProperties(ignoreUnknown = true)
public class ValidacaoTransacaoSid00TO {

	@JsonProperty(value="validar_saldo")
    private boolean validarSaldo;

	@JsonProperty(value="validar_marcas")
    private boolean validarMarcas;

	/**
	 * <p>Retorna o valor do atributo validarSaldo</p>.
	 *
	 * @return validarSaldo
	*/
	public boolean isValidarSaldo() {
		return this.validarSaldo;
	}

	/**
	 * <p>Define o valor do atributo validarSaldo</p>.
	 *
	 * @param validarSaldo valor a ser atribuído
	*/
	public void setValidarSaldo(boolean validarSaldo) {
		this.validarSaldo = validarSaldo;
	}

	/**
	 * <p>Retorna o valor do atributo validarMarcas</p>.
	 *
	 * @return validarMarcas
	*/
	public boolean isValidarMarcas() {
		return this.validarMarcas;
	}

	/**
	 * <p>Define o valor do atributo validarMarcas</p>.
	 *
	 * @param validarMarcas valor a ser atribuído
	*/
	public void setValidarMarcas(boolean validarMarcas) {
		this.validarMarcas = validarMarcas;
	}
}