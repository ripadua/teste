/*
 * Copyright (c) 2019 Caixa Econômica Federal. Todos os direitos
 * reservados.
 *
 * Caixa Econômica Federal - SIACG - Sistema de Crédito Rural
 *
 * Este software foi desenvolvido sob demanda da CAIXA e está
 * protegido por leis de direitos autorais e tratados internacionais. As
 * condições de cópia e utilização do todo ou partes dependem de autorização da
 * empresa. Cópias não são permitidas sem expressa autorização. Não pode ser
 * comercializado ou utilizado para propósitos particulares.
 *
 * Uso exclusivo da Caixa Econômica Federal. A reprodução ou distribuição não
 * autorizada deste programa ou de parte dele, resultará em punições civis e
 * criminais e os infratores incorrem em sanções previstas na legislação em
 * vigor.
 *
 * Histórico do TFS:
 *
 * LastChangedRevision: $Revision$
 * LastChangedBy: $Author$
 * LastChangedDate: $Date$
 *
 * HeadURL: $HeadURL$
 *
 */
package br.gov.caixa.siacg.view.mb;

import java.io.IOException;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;
import javax.inject.Inject;

import org.primefaces.component.tabview.TabView;
import org.primefaces.event.TabChangeEvent;

import br.gov.caixa.pedesgo.arquitetura.controlador.ManutencaoBean;
import br.gov.caixa.pedesgo.arquitetura.util.MensagensUtil;
import br.gov.caixa.pedesgo.arquitetura.util.UtilObjeto;
import br.gov.caixa.siacg.model.domain.FonteExpressao;
import br.gov.caixa.siacg.model.domain.Formula;
import br.gov.caixa.siacg.model.domain.FormulaItem;
import br.gov.caixa.siacg.model.domain.ParametroFormulaItem;
import br.gov.caixa.siacg.model.domain.ParametroFuncao;
import br.gov.caixa.siacg.model.domain.TipoExpressao;
import br.gov.caixa.siacg.model.domain.VinculoCalculo;
import br.gov.caixa.siacg.service.EmpreendimentoService;
import br.gov.caixa.siacg.service.FonteExpressaoService;
import br.gov.caixa.siacg.service.FormulaItemService;
import br.gov.caixa.siacg.service.FormulaService;
import br.gov.caixa.siacg.service.ParametroFuncaoService;
import br.gov.caixa.siacg.service.TipoExpressaoService;
import br.gov.caixa.siacg.service.TipologiaService;
import br.gov.caixa.siacg.service.UnidadeHabitacionalService;
import br.gov.caixa.siacg.service.VinculoCalculoService;
import br.gov.caixa.siacg.util.LogCEF;
import br.gov.caixa.siacg.view.form.ParametrizacaoFormulaVisao;

/**
 * <p>
 * ParametrizacaoFormulaMB
 * </p>
 * <p>
 * Descrição: Managed bean do caso de uso <code>Formula</code>.
 * </p>
 * <br>
 * <b>Empresa:</b> Cef - Caixa Econômica Federal
 *
 * @author Ludemeula Fernandes de Sá
 * @version 1.0
 */
@ManagedBean
@SessionScoped
public class ParametrizacaoFormulaMB extends ManutencaoBean<Formula> {

	private static final long serialVersionUID = 1495616769630209119L;

	private static final String RESOURCE_BUNDLE = "msgApp"; // TODO remover
	private static final String PREFIXO_CASO_USO = "parametrizacaoFormulaMB";
	private static final String PATH_CONSULTA = "/pages/parametro/consulta.cef";
	private static final String PAGINA_CONSULTA = "/pages/parametro/consulta.xhtml?faces-redirect=true";
	private static final String PAGINA_CADASTRO = "/pages/parametro/edicao.xhtml?faces-redirect=true";

	@Inject
	private FormulaService service;
	
	@Inject
	private FonteExpressaoService fonteExpressaoService;
	
	@Inject
	private FormulaItemService formulaItemService;
	
	@Inject
	private TipoExpressaoService tipoExpressaoService;
	
	@Inject
	private ParametroFuncaoService parametroFuncaoService;
	
	@Inject
	private EmpreendimentoService empreendimentoService;
	
	@Inject
	private UnidadeHabitacionalService unidadeHabitacionalService;
	
	@Inject
	private VinculoCalculoService vinculoCalculoService;
	
	@Inject
	private TipologiaService tipologiaService;
	
	private ParametrizacaoFormulaVisao visao;
	
	public String abrirFormula() {
		return abrirFormula(PAGINA_CONSULTA);
	}
	
	public String abrirVinculo() {
		return abrirVinculo(PAGINA_CONSULTA);
	}
	
	public String novaFormula() {
		return abrirPagina(new Formula());
	}
	
	public String novoVinculo() {
		return abrirPagina(new VinculoCalculo());
	}
	
	public String editar(final Formula formula) {
		return abrirPagina(formula);
	}
	
	public String editar(final VinculoCalculo vinculo) {
		return abrirPagina(vinculo);
	}
	
	public void pesquisarFormula() {
		getVisao().setLista(getService().consultar(getVisao().getNomeFormula()));
	}
	
	public void pesquisarVinculo() {
		getVisao().getVinculos().clear();
		getVisao().getVinculos().addAll(vinculoCalculoService.consultar(getVisao().getVinculoFiltro()));
	}
	
	public void limparFiltros() {
		visao = null;
		getVisao().getLista().clear();
		getVisao().getFonteExpressoes().clear();
		getVisao().setEntidade(new Formula());
		getVisao().setFormulaItem(new FormulaItem());
		getVisao().setVinculoCalculo(new VinculoCalculo());
		getVisao().setVinculoFiltro(new VinculoCalculo());
	}
	
	/**
	 * <p>Método responsável por carregar as Fontes de Expressão ao ser selecionado um Tipo de Expressão.</p>
	 *
	 * @author Ludemeula Fernandes
	 *
	 */
	public void onChangeExpressao() {
		onChangeExpressao(getVisao().getFonteExpressoes(), getVisao().getFormulaItem().getTipoExpressao(), getVisao().getEntidade().getFonteExpressao());
	}

	public void onChangeExpressaoFormula(ParametroFormulaItem item) {
		onChangeExpressao(item.getFontes(), item.getTipoExpressao(), null);
	}

	/**
	 * <p>Método responsável por carregar o template dos parâmetros da função ao ser selecionado uma Fonte de Expressão.</p>
	 *
	 * @author Ludemeula Fernandes
	 *
	 */
	public void onChangeFonte() {
		getVisao().getParametroFuncoes().clear();
		if (getVisao().getFormulaItem().getTipoExpressaoEnum().isFuncao() && getVisao().getFormulaItem().getFonteExpressao() != null) {
			getVisao().getParametroFuncoes().addAll(parametroFuncaoService.porFonteExpressao(getVisao().getFormulaItem().getFonteExpressao()));
			getVisao().getTipoExpressoesFuncao().addAll(tipoExpressaoService.daFuncao());
			
			getVisao().getFuncoes().clear();
			
			for (ParametroFuncao parametroFuncao : getVisao().getParametroFuncoes()) {
				ParametroFormulaItem item = new ParametroFormulaItem();
				item.setParametroFuncao(parametroFuncao);
				item.setFormulaItem(getVisao().getFormulaItem());
				
				getVisao().getFuncoes().add(item);
			}
		}
	}
	
	public void onBlurEmpreendimento() {
		if (getVisao().getCoApf() != null && getVisao().getCoApf().length() >= 8) {
			getVisao().getVinculoCalculo().setEmpreendimento(empreendimentoService.porApf(getVisao().getCoApf()));
			getVisao().getTipologias().addAll(tipologiaService.listarTipologias(getVisao().getVinculoCalculo().getEmpreendimento()));
		}
	}
	
	public void onChangeTipologia() {
		if (getVisao().getVinculoCalculo().getTipologia() != null) {
			getVisao().setUnidades(unidadeHabitacionalService.porTipologia(getVisao().getVinculoCalculo().getTipologia()));
		}
	}
	
	public void onTabChange(TabChangeEvent event) {
		try {
			int index = ((TabView) event.getSource()).getActiveIndex();
			
			if (ParametrizacaoFormulaVisao.TipoPagina.PARAMETRIZACAO.ordinal() == index) {
				getExternalContext().redirect(getExternalContext().getRequestContextPath() + abrirFormula(PATH_CONSULTA));
			} else {
				getExternalContext().redirect(getExternalContext().getRequestContextPath() + abrirVinculo(PATH_CONSULTA));
			}
		} catch (IOException e) {
			LogCEF.error("Erro ao selecionar a aba." + e);
		}
    }
	
	public void adicionarItemFormula() {  // FIXME refatorar
		getVisao().getFormulaItem().setNuOrdem(getVisao().getEntidade().getItens().size() + 1);
		formulaItemService.validar(getVisao().getFormulaItem());
		if (this.getVisao().getFormulaItem().hasMensagens()) {
			adicionaListaMensagemDeAlerta(this.getVisao().getFormulaItem().getMensagens());
		} else {
			getVisao().getFormulaItem().setFormula(getVisao().getEntidade());
			adicionarFuncoes();
			getVisao().getEntidade().getItens().add(getVisao().getFormulaItem());
			getVisao().setFormulaItem(new FormulaItem());
			getVisao().getFuncoes().clear();
		}
	}
	
	public void adicionarItemFormulaAcima() {  // FIXME refatorar
		formulaItemService.validar(getVisao().getFormulaItem());
		if (this.getVisao().getFormulaItem().hasMensagens()) {
			adicionaListaMensagemDeAlerta(this.getVisao().getFormulaItem().getMensagens());
		} else {
			getVisao().getFormulaItem().setFormula(getVisao().getEntidade());
			getVisao().getFormulaItem().setNuOrdem(getVisao().getItemSelecionado().getNuOrdem());
			
			for (FormulaItem item : getVisao().getEntidade().getItens()) {
				if (item.getNuOrdem() >= getVisao().getItemSelecionado().getNuOrdem()) { 
					item.setNuOrdem(item.getNuOrdem() + 1);
				}
			}
			
			adicionarFuncoes();
			getVisao().getEntidade().getItens().add(getVisao().getFormulaItem());
			getVisao().setFormulaItem(new FormulaItem());
			getVisao().getFuncoes().clear();
			
			Collections.sort(getVisao().getEntidade().getItens(), new Comparator<FormulaItem>() {
				@Override
				public int compare(FormulaItem o1, FormulaItem o2) {
					return o1.getNuOrdem().compareTo(o2.getNuOrdem());
				}
			});
		}
	}
	
	public void adicionarItemFormulaAbaixo() {
		formulaItemService.validar(getVisao().getFormulaItem()); // FIXME refatorar
		if (this.getVisao().getFormulaItem().hasMensagens()) {
			adicionaListaMensagemDeAlerta(this.getVisao().getFormulaItem().getMensagens());
		} else {
			getVisao().getFormulaItem().setFormula(getVisao().getEntidade());
			getVisao().getFormulaItem().setNuOrdem(getVisao().getItemSelecionado().getNuOrdem() + 1);
			
			for (FormulaItem item : getVisao().getEntidade().getItens()) {
				if (item.getNuOrdem() > getVisao().getItemSelecionado().getNuOrdem()) { 
					item.setNuOrdem(item.getNuOrdem() + 1);
				}
			}
			
			adicionarFuncoes();
			getVisao().getEntidade().getItens().add(getVisao().getFormulaItem());
			getVisao().setFormulaItem(new FormulaItem());
			getVisao().getFuncoes().clear();
			
			Collections.sort(getVisao().getEntidade().getItens(), new Comparator<FormulaItem>() {
				@Override
				public int compare(FormulaItem o1, FormulaItem o2) {
					return o1.getNuOrdem().compareTo(o2.getNuOrdem());
				}
			});
		}
	}
	
	public void subirItemFormula() {  // FIXME refatorar
		if (!getVisao().getItemSelecionado().getNuOrdem().equals(1)) {
			getVisao().getItemSelecionado().setNuOrdem(getVisao().getItemSelecionado().getNuOrdem() - 1);
			for (FormulaItem item : getVisao().getEntidade().getItens()) {
				if (item.getNuOrdem().equals(getVisao().getItemSelecionado().getNuOrdem()) && !item.equals(getVisao().getItemSelecionado())) { 
					item.setNuOrdem(item.getNuOrdem() + 1);
				}
			}
			
			Collections.sort(getVisao().getEntidade().getItens(), new Comparator<FormulaItem>() {
			    @Override
			    public int compare(FormulaItem o1, FormulaItem o2) {
			        return o1.getNuOrdem().compareTo(o2.getNuOrdem());
			    }
			});
		}
	}
	
	public void descerItemFormula() {  // FIXME refatorar
		if (!getVisao().getItemSelecionado().getNuOrdem().equals(getVisao().getEntidade().getItens().size())) {
			getVisao().getItemSelecionado().setNuOrdem(getVisao().getItemSelecionado().getNuOrdem() + 1);
			for (FormulaItem item : getVisao().getEntidade().getItens()) {
				if (item.getNuOrdem().equals(getVisao().getItemSelecionado().getNuOrdem()) && !item.equals(getVisao().getItemSelecionado())) { 
					item.setNuOrdem(item.getNuOrdem() - 1);
				}
			}
			
			Collections.sort(getVisao().getEntidade().getItens(), new Comparator<FormulaItem>() {
			    @Override
			    public int compare(FormulaItem o1, FormulaItem o2) {
			        return o1.getNuOrdem().compareTo(o2.getNuOrdem());
			    }
			});
		}
	}
	
	public void removerItemFormula(FormulaItem item) {
		if (item != null) {
			getVisao().getEntidade().getItens().remove(item);
		}
	}
	
	public void salvarFormula() {
		String msg = getService().salvar(getVisao().getEntidade());
		if (this.getVisao().getEntidade().hasMensagens()) {
			adicionaListaMensagemDeAlerta(getVisao().getEntidade().getMensagens());
		} else {
			getVisao().setMensagemModal(MensagensUtil.getMensagem(getNomeVarResourceBundle(), msg));
		}
	}

	public void salvarVinculo() {
		String msg = vinculoCalculoService.salvar(getVisao().getVinculoCalculo());
		if (this.getVisao().getVinculoCalculo().hasMensagens()) {
			adicionaListaMensagemDeAlerta(getVisao().getVinculoCalculo().getMensagens());
		} else {
			getVisao().setMensagemModal(MensagensUtil.getMensagem(getNomeVarResourceBundle(), msg));
		}
	}
	
	public boolean isInclusaoValida() {
		return getVisao().getFormulaItem().getTipoExpressao() != null && getVisao().getFormulaItem().getFonteExpressao() != null;
	}
	
	/**
	 * <p>Método responsável por atualizar a marcação do checkbox vinculado aos itens. 
	 * Quando um item for marcado, os demais serão desmarcados</p>.
	 *
	 * @author Ludemeula Fernandes de Sá.
	 */
	public void atualizarCheckbox(final FormulaItem formulaItem) {
		getVisao().setItemSelecionado(formulaItem.isIcMarcado() ? formulaItem : null);
		
		if (getVisao().getItemSelecionado() != null) {
			for (FormulaItem item : getVisao().getEntidade().getItens()) {
				if (!getVisao().getItemSelecionado().getNuOrdem().equals(item.getNuOrdem())) {
					item.setIcMarcado(false);
				}
			}
		}
	}
	
	private String abrirPagina(final Formula formula) {
		getVisao().setEntidade(formula);
		getVisao().getTipoExpressoes().addAll(tipoExpressaoService.listar());
		
		return PAGINA_CADASTRO;
	}
	
    private String abrirPagina(final VinculoCalculo vinculo) {
    	getVisao().setVinculoCalculo(vinculo);
    	getVisao().getFormulas().addAll(getService().listar());
    	
    	if (getVisao().getVinculoCalculo().getFormula() != null) {
    		getVisao().setCoApf(getVisao().getVinculoCalculo().getEmpreendimento().getCoAPF());
    		onBlurEmpreendimento();
    		onChangeTipologia();
    	}
    
    	return PAGINA_CADASTRO;
    }
    
	private String abrirFormula(final String pagina) {
		limparFiltros();
		pesquisarFormula();
		return pagina;
	}
	
	private String abrirVinculo(final String pagina) {
		limparFiltros();
		getVisao().setIndexAba(ParametrizacaoFormulaVisao.TipoPagina.VINCULO.ordinal());
		getVisao().setVinculoCalculo(new VinculoCalculo());
		getVisao().setVinculoFiltro(new VinculoCalculo());
		pesquisarVinculo();
		return pagina;
	}

	private void onChangeExpressao(List<FonteExpressao> lista, final TipoExpressao tipo, final FonteExpressao fonte) {
		lista.clear();
		if (tipo != null) {
			lista.addAll(fonteExpressaoService.porTipoExpressao(tipo.getNuTipoExpressao(), fonte != null ? fonte.getNuFonteExpressao() : null));
		}
	}
	
	private void adicionarFuncoes() {
		for (ParametroFormulaItem parametro : getVisao().getFuncoes()) {
			if (parametro.getTipoExpressao() != null) {
				getVisao().getFormulaItem().getFuncoes().add(parametro);
			}
		}
	}
	/************************************* GETTERS && SETTERS ************************************/
    @Override
    protected String getNomeVarResourceBundle() {
    	return RESOURCE_BUNDLE;
    }

	@Override
	protected String getPrefixoCasoDeUso() {
		return PREFIXO_CASO_USO;
	}
    
	@SuppressWarnings("unchecked")
	@Override
	public FormulaService getService() {
		return this.service;
	}
	
	/**
	 * @see br.gov.caixa.pedesgo.arquitetura.controlador.AbstractBean#getVisao()
	 */
	@Override
	public ParametrizacaoFormulaVisao getVisao() {
		if (!UtilObjeto.isReferencia(visao)) {
			this.visao = new ParametrizacaoFormulaVisao();
		}
		
		return visao;
	}
}