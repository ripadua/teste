/**
 * Copyright (c) 2018 Caixa Econômica Federal. Todos os direitos
 * reservados.
 *
 * Caixa Econômica Federal - SIACG
 *
 * Este software foi desenvolvido sob demanda da CAIXA e está
 * protegido por leis de direitos autorais e tratados internacionais. As
 * condições de cópia e utilização total ou partes dependem de autorização da
 * empresa. Cópias não são permitidas sem expressa autorização. Não pode ser
 * comercializado ou utilizado para propósitos particulares.
 *
 * Uso exclusivo da Caixa Econômica Federal. A reprodução ou distribuição não
 * autorizada deste programa ou de parte dele, resultará em punições civis e
 * criminais e os infratores incorrem em sanções previstas na legislação em
 * vigor.
 *
 * Histórico do TFS:
 *
 * LastChangedRevision: $Revision$
 * LastChangedBy: $Author$
 * LastChangedDate: $Date$
 *
 * HeadURL: $HeadURL$
 *
 */
package br.gov.caixa.siacg.thread;

import java.util.Collection;

import br.gov.caixa.siacg.comum.to.CedenteCalculoTO;
import br.gov.caixa.siacg.dao.TituloDAO;
import br.gov.caixa.siacg.model.domain.Titulo;
import br.gov.caixa.siacg.strategy.impl.titulo.TotalizadorTituloAnaliseContrato;

/**
 * <p>
 * ConsultaTitulosThread
 * </p>
 *
 * <p>
 * Descrição: Classe responsavel por implementar o paralelismo na consulta de
 * títulos para realização de calculo de analise do contrato
 * </p>
 *
 * <br>
 * <b>Empresa:</b> Cef - Caixa Econômica Federal
 *
 *
 * @author p541915
 *
 * @version 1.0
 */
public class ConsultaTitulosThread implements Runnable {

	/** Atributo offsetMin. */
	private Integer offsetMin;
	
	/** Atributo offSetMax. */
	private Integer offSetMax;
	
	/** Atributo blockSize. */
	private Integer blockSize;
	
	/** Atributo totalizador. */
	private TotalizadorTituloAnaliseContrato totalizador;
	
	/** Atributo listaCedente. */
	private Collection<CedenteCalculoTO> listaCedente;
	
	/** Atributo tituloDao. */
	private TituloDAO tituloDao;
	
	/**
	 * Responsável pela criação de novas instâncias desta classe.
	 *
	 * @param offsetMin
	 * @param offSetMax
	 * @param blockSize
	 * @param totalizador
	 * @param listaCedente
	 * @param tituloDao
	 *
	 */
	public ConsultaTitulosThread(Integer offsetMin, Integer offSetMax, Integer blockSize,
			TotalizadorTituloAnaliseContrato totalizador, Collection<CedenteCalculoTO> listaCedente, TituloDAO tituloDao) {
		super();
		this.offsetMin = offsetMin;
		this.offSetMax = offSetMax;
		this.blockSize = blockSize;
		this.totalizador = totalizador;
		this.listaCedente = listaCedente;
		this.tituloDao = tituloDao;
	}

	/**
	 * @see java.lang.Runnable#run()
	 */
	@Override
	public void run() {
		Collection<Titulo> listaDuplicatas;
		//Consulta os titulo de acordo com o blockSize 
		for (int x = offsetMin; x < offSetMax; x = x + blockSize) {
			int qtdregistros = blockSize;
			if ((x + blockSize) > offSetMax) {
				qtdregistros = offSetMax - x;
			}
			listaDuplicatas = this.tituloDao.listarTitulosCedentes(listaCedente, x, qtdregistros);	
			totalizador.adicionarTitulos(listaDuplicatas);        			
			listaDuplicatas.clear();
			this.tituloDao.flushEClear();
			System.gc();
		}
	}	

}
