/**
 * reservados. Copyright (c) 2009-2011 Caixa Econômica Federal. Todos os direitos
 *
 * Caixa Econômica Federal - SIACG – Sistema de Acompanhamento de Carteiras de Cobrança
 *
 * Este programa de computador foi desenvolvido sob demanda da CAIXA e está protegido por leis de direitos autorais e
 * tratados internacionais. As condições de cópia e utilização do todo ou partes dependem de autorização da pessoa.
 * Cópias não são permitidas sem expressa autorização. Não pode ser comercializado ou utilizado para propósitos
 * particulares.
 *
 * Uso exclusivo da Caixa Econômica Federal. A reprodução ou distribuição não autorizada deste programa ou de parte
 * dele, resultará em punições civis e criminais e os infratores incorrem em sanções previstas na legislação em vigor.
 *
 * Histórico do Subversion:
 *
 * LastChangedRevision: LastChangedBy: LastChangedDate:
 *
 * HeadURL:
 *
 */
package br.gov.caixa.siacg.view.mb;

import java.io.IOException;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.enterprise.context.SessionScoped;
import javax.faces.context.FacesContext;
import javax.inject.Inject;
import javax.inject.Named;
import javax.servlet.ServletOutputStream;

import org.apache.commons.collections.CollectionUtils;

import br.com.christ.jsf.html2pdf.listener.PDFConverterConfig;
import br.gov.caixa.pedesgo.arquitetura.controlador.ManutencaoBean;
import br.gov.caixa.pedesgo.arquitetura.enums.EnumExtensaoArquivo;
import br.gov.caixa.pedesgo.arquitetura.util.LogCefUtil;
import br.gov.caixa.siacg.comparator.TotalDuplicatasMaioresSacadosComparator;
import br.gov.caixa.siacg.model.domain.AnaliseCartaoBandeira;
import br.gov.caixa.siacg.model.domain.AnaliseCartaoCredito;
import br.gov.caixa.siacg.model.domain.AnaliseContrato;
import br.gov.caixa.siacg.model.domain.BandeiraCartao;
import br.gov.caixa.siacg.model.domain.Contrato;
import br.gov.caixa.siacg.model.domain.GarantiaContrato;
import br.gov.caixa.siacg.model.domain.PreAnalise;
import br.gov.caixa.siacg.model.domain.TotalizadorMaiorSacado;
import br.gov.caixa.siacg.model.enums.CaracteristicaEnum;
import br.gov.caixa.siacg.model.vo.PessoaVO;
import br.gov.caixa.siacg.model.vo.RelatorioPreAnaliseContratoVO;
import br.gov.caixa.siacg.service.AnaliseCartaoCreditoService;
import br.gov.caixa.siacg.service.PreAnaliseService;
import br.gov.caixa.siacg.service.RelatorioAnaliseService;
import br.gov.caixa.siacg.util.FormatUtils;
import br.gov.caixa.siacg.view.form.DetalheDuplicatasVisao;
import br.gov.caixa.siacg.view.form.RelatorioPreAnaliseVisao;

/**
 * <p>
 * RelatorioPrePreAnaliseMB
 * </p>
 * <p>
 * <code>Descrição: Bean Gerenciado para gerar o relatório de PreAnalise
 * carteira</code>.
 * </p>
 * <br>
 * <b>Empresa:</b> Cef - Caixa Econômica Federal
 *
 * @author Caio Graco
 * @version 1.0
 */
@Named
@SessionScoped
public class RelatorioPreAnaliseMB extends ManutencaoBean<PreAnalise> {

    /** Atributo RELATORIO. */
    private static final String RELATORIO = "relatorio";

    /** Atributo serialVersionUID. */
    private static final long serialVersionUID = 5252924655713915763L;

    /** Atributo VAZIO. */
    private static final String VAZIO = "";

    /** Atributo NOME_MANAGED_BEAN. */
    public static final String NOME_MANAGED_BEAN = "relatorioPreAnaliseMB";

    /** Atributo EL_MANAGED_BEAN. */
    public static final String EL_MANAGED_BEAN = "#{relatorioPreAnaliseMB}";

    /** Atributo PREFIXO_CASO_DE_USO. */
    private static final String PREFIXO_CASO_DE_USO = "preanalise";

    /** Atributo DIRETORIO_PAGINAS. */
    private static final String DIRETORIO_PAGINAS = "/pages/";

    /** Atributo PAGINA_RELATORIO. */
    private static final String PAGINA_RELATORIO = "/relatorio.xhtml?faces-redirect=true";

    /** Atributo PAGINA_RELATORIO_PRE_ANALISE. */
    public static final String PAGINA_RELATORIO_PRE_ANALISE = "/pages/preanalise/relatorio.xhtml?faces-redirect=true";

    /** Atributo pdfConverterConfig. */
    @Inject
    private PDFConverterConfig pdfConverterConfig;

    /** Atributo visao. */
    private RelatorioPreAnaliseVisao visao;

    /** Atributo preAnaliseService. */
    @Inject
    private PreAnaliseService preAnaliseService;

    /** Atributo relatorioAnaliseService. */
    @Inject
    private transient RelatorioAnaliseService relatorioAnaliseService;
    
    @Inject
    private AnaliseCartaoCreditoService analiseCartaoCreditoService;

    /** Atributo detalheDuplicatasMB. */
    @Inject
    private DetalheDuplicatasMB detalheDuplicatasMB;

    /**
     * Carrega os dados do relatório de pré análise.
     *
     * @param contrato
     *            valor a ser atribuído
     * @author Caio Graco
     */
    private void carregarDados(final Contrato contrato) {

        RelatorioPreAnaliseContratoVO relatorio = null;

        final RelatorioPreAnaliseVisao visao = this.getVisao();

        visao.setCedentesUtilizadosFluxo(null);
        visao.setCedentesUtilizadosEstoque(null);

        final AnaliseContrato analiseContrato = this.relatorioAnaliseService.obterUltimaAnaliseContrato(contrato.getNuContrato());

        visao.getPreAnaliseSelecionada().getContrato()
                .setGarantiaContratoList(this.relatorioAnaliseService.listarGarantiaContratoDuplicata(contrato, null));

        relatorio = this.relatorioAnaliseService.preencherRelatorioPreAnaliseContratoVO();

        visao.getPreAnaliseSelecionada().getContrato().setAnaliseContrato(analiseContrato);

        visao.setContemGarantiaCartao(false);
        visao.setContemGarantiaDuplicata(false);
        visao.setContemGarantiaCartaoEstoque(false);
        visao.setContemGarantiaCartaoFluxo(false);
        visao.setContemGarantiaCaracteristicaFluxo(false);
        visao.setContemGarantiaCaracteristicaEstoque(false);
        visao.setValorMaximoPermitidoDuplicata(BigDecimal.ZERO);
        visao.setPrazoMaximoPermitidoDuplicata(0);

        for (final GarantiaContrato garantiaContrato : contrato.getGarantiaContratoList()) {

            // Habilita dados da garantia do tipo Duplicata
            if (garantiaContrato.isGarantiaDuplicata() && garantiaContrato.getIcCaracteristica() != null) {
                visao.setContemGarantiaDuplicata(true);

                if (garantiaContrato.getIcCaracteristica().getValor().equals(CaracteristicaEnum.ESTOQUE.getValor())) {
                    visao.setContemGarantiaCaracteristicaEstoque(true);
                    visao.setCedentesUtilizadosEstoque(garantiaContrato.getListaCedentesUtilizados());
                    visao.setValorMaximoPermitidoDuplicata(garantiaContrato.getVrMaximoPermitido());
                    visao.setPrazoMaximoPermitidoDuplicata(
                            garantiaContrato.getVrPrazoMaximoPermitido() == null ? 0 : garantiaContrato.getVrPrazoMaximoPermitido().intValue());
                    visao.setPercentualMaximoPermitidoDuplicata(
                            garantiaContrato.getVrPercentualMaximoCncno() == null ? BigDecimal.ZERO : garantiaContrato.getVrPercentualMaximoCncno());
                } else if (garantiaContrato.getIcCaracteristica().getValor().equals(CaracteristicaEnum.FLUXO.getValor())) {
                    visao.setContemGarantiaCaracteristicaFluxo(true);
                    visao.setCedentesUtilizadosFluxo(garantiaContrato.getListaCedentesUtilizados());
                }

            }

            // Habilita dados da garantia do tipo Cartão de Crédito
            if (!visao.isContemGarantiaCartao() && garantiaContrato.isGarantiaCartaoCredito()) {
                visao.setContemGarantiaCartao(true);

                visao.setListaCartaoCreditoEstoque(
                		analiseCartaoCreditoService.listarAnaliseCartaoCredito(contrato.getNuContrato(), "02"));
                visao.setListaCartaoCreditoFluxo(
                		analiseCartaoCreditoService.listarAnaliseCartaoCredito(contrato.getNuContrato(), "01"));
                
                this.categorizarCartaoEstoquePorBandeira();
                this.categorizarCartaoFluxoPorBandeira();
                
                // Habilita grid's que contenham dados
                if (CollectionUtils.isNotEmpty(visao.getListaCartaoCreditoEstoque())) {
                    visao.setContemGarantiaCartaoEstoque(true);
                }
                if (CollectionUtils.isNotEmpty(visao.getListaCartaoCreditoFluxo())) {
                    visao.setContemGarantiaCartaoFluxo(true);
                }

                visao.somaTotalizadores();
            }
        }

        visao.setRelatorio(relatorio);

        final List<TotalizadorMaiorSacado> listMaioresSacados = (List<TotalizadorMaiorSacado>) this.relatorioAnaliseService
                .listarDezMaioresSacados(this.relatorioAnaliseService
                        .listarCedentesGarantiacontrato(visao.getPreAnaliseSelecionada().getContrato().getGarantiaContratoList()));

        Collections.sort(listMaioresSacados, new TotalDuplicatasMaioresSacadosComparator());

        visao.setListaMaioresSacados(listMaioresSacados);
    }

    /**
     * <p>
     * Método responsável por abrir o detalhe das duplicatas estoque.
     * <p>
     *
     * @return String
     * @author Caio Graco
     */
    public String abrirDetalheDuplicatasEstoque() {
        return this.abrirDetalheDuplicatas(CaracteristicaEnum.ESTOQUE);
    }

    /**
     * <p>
     * Método responsável por abrir o detalhe das duplicatas fluxo.
     * <p>
     *
     * @return String
     * @author Caio Graco
     */
    public String abrirDetalheDuplicatasFluxo() {
        return this.abrirDetalheDuplicatas(CaracteristicaEnum.FLUXO);
    }

    /**
     * <p>
     * Abre a tela de detalhe de duplicatas.
     * <p>
     *
     * @param caracteristicaEnum
     *            valor a ser atribuído
     * @return String
     * @author Ricardo Crispim
     */
    public String abrirDetalheDuplicatas(final CaracteristicaEnum caracteristicaEnum) {
        final DetalheDuplicatasVisao visao = new DetalheDuplicatasVisao();
        visao.setPaginaOrigem(RelatorioPreAnaliseMB.PAGINA_RELATORIO_PRE_ANALISE);
        visao.setValorBreadcrumb("Relatório Pré-Análise Carteira");
        visao.setMostrarDuplicatasValidas(Boolean.FALSE);

        visao.setPessoaVO(this.atribuirValoresPessoa());

        final GarantiaContrato garantia = this.getGarantiaContrato(this.getVisao().getPreAnaliseSelecionada().getContrato().getGarantiaContratoList(),
                caracteristicaEnum);
        visao.setCedentesSelecionados(garantia.getCedenteList());
        visao.setValorMaximo(garantia.getVrMaximoPermitido());
        visao.setPrazoMaximo(garantia.getVrPrazoMaximoPermitido() == null ? 0 : garantia.getVrPrazoMaximoPermitido().intValue());
        visao.setConcentracaoMaximaValor(garantia.getVrPercentualMaximoCncno());
        if (garantia.getInstrucaoProtesto() != null) {
            visao.setIcInstrucaoProtesto(garantia.getInstrucaoProtesto());
        } else {
            visao.setIcInstrucaoProtesto(false);
        }
        this.getDetalheDuplicatasMB().setVisao(visao);

        return this.getDetalheDuplicatasMB().abrirDetalheDuplicatas();
    }

    /**
     * <p>
     * Método responsável por atribuir valor a garantia de duplicata do contrato
     * quando na lista contiver uma com o tipo de caracteristica ESTOQUE.
     * <p>
     *
     * @param listaGarantiaContrato
     *            valor a ser atribuído
     * @param caracteristicaEnum
     *            valor a ser atribuído
     * @return GarantiaContrato
     * @author Waltenes Junior
     */
    private GarantiaContrato getGarantiaContrato(final Collection<GarantiaContrato> listaGarantiaContrato,
            final CaracteristicaEnum caracteristicaEnum) {
        GarantiaContrato garantiaContratoRetorno = new GarantiaContrato();
        if (listaGarantiaContrato != null) {
            for (final GarantiaContrato garantiaContrato : listaGarantiaContrato) {
                if (garantiaContrato.isGarantiaDuplicata() && caracteristicaEnum.equals(garantiaContrato.getIcCaracteristica())) {
                    garantiaContratoRetorno = garantiaContrato;
                }
            }
        }
        return garantiaContratoRetorno;
    }

    /**
     * <p>
     * Método responsável por atribuir os valores da pessoa que aparecerá no
     * cabeçalho.
     * <p>
     *
     * @return PessoaVO
     * @author Caio Graco
     */
    private PessoaVO atribuirValoresPessoa() {
        final PessoaVO vo = new PessoaVO();

        vo.setPessoa(FormatUtils.applyMask("__.___.___/____-__", this.getVisao().getPreAnaliseSelecionada().getContrato().getNuPessoa().getNuCnpj())
                .concat(this.getVisao().getPreAnaliseSelecionada().getContrato().getNuPessoa().getNoPessoa() == null ? RelatorioPreAnaliseMB.VAZIO
                        : " - ")
                .concat(this.getVisao().getPreAnaliseSelecionada().getContrato().getNuPessoa().getNoPessoa() == null ? RelatorioPreAnaliseMB.VAZIO
                        : this.getVisao().getPreAnaliseSelecionada().getContrato().getNuPessoa().getNoPessoa()));
        vo.setContrato(this.getVisao().getPreAnaliseSelecionada().getContrato().getCoContrato());

        return vo;
    }

    /**
     * <p>
     * Método responsável por gerar um byte[] e passar para o método
     * <code>salvarBytePdfAnalise(byte[] bytesPDFRelatorio)</code> como
     * parametro.
     * <p>
     *
     * @return String
     * @author Leandro Santos Oliveira
     */
    public String gerarImagemPdf() {

        this.pdfConverterConfig.setEnablePdf(true);
        this.pdfConverterConfig.setFileName("Analise_contrato_N_.pdf");
        this.pdfConverterConfig.setPdfAction("#{relatorioPreAnaliseMB.salvarBytePdfAnalise}");

        return RelatorioPreAnaliseMB.RELATORIO;
    }

    /**
     * <p>
     * Método responsável por salvar o byte[] do pdf na base de dados e chamar o
     * método de impressão do pdf.
     * <p>
     *
     * @param bytesPDFRelatorio
     *            valor a ser atribuído
     * @return String com a mesma tela
     * @author Leandro Santos Oliveira
     */
    public String salvarBytePdfAnalise(final byte[] bytesPDFRelatorio) {

        try {
            this.imprimirPdf(bytesPDFRelatorio, "Pre_analise_contrato_N_" + EnumExtensaoArquivo.PDF.getExtensao());
        } catch (final IOException e) {
            LogCefUtil.error("PDF não pode ser gerado");
            LogCefUtil.error(e);
        }

        return super.MESMA_TELA;
    }

    /**
     * <p>
     * Método responsável por imprimir um pdf de acordo com o
     * <code>byte[]</code> passado por parâmetro.
     * <p>
     *
     * @param bytes
     *            valor a ser atribuído
     * @param nomeArquivo
     *            valor a ser atribuído
     * @throws IOException
     *             valor a ser atribuído
     * @author Leandro Santos Oliveira
     */
    private void imprimirPdf(final byte[] bytes, final String nomeArquivo) throws IOException {

        this.getResponse().addHeader("Content-disposition", "attachment; filename=" + nomeArquivo);
        this.getResponse().setContentType(EnumExtensaoArquivo.PDF.getContentType());
        this.getResponse().setContentLength(bytes.length);

        final ServletOutputStream saida = this.getResponse().getOutputStream();
        saida.write(bytes, 0, bytes.length);
        saida.flush();
        saida.close();
        FacesContext.getCurrentInstance().responseComplete();
    }

    /**
     * @see br.gov.caixa.pedesgo.arquitetura.controlador.AbstractBean#getPrefixoCasoDeUso()
     */
    @Override
    public String getPrefixoCasoDeUso() {
        return RelatorioPreAnaliseMB.PREFIXO_CASO_DE_USO;
    }

    /**
     * @see br.gov.caixa.pedesgo.arquitetura.controlador.AbstractBean#getTelaConsulta()
     */
    @Override
    public String getTelaConsulta() {
        this.carregar();

        return RelatorioPreAnaliseMB.DIRETORIO_PAGINAS + this.getPrefixoCasoDeUso() + RelatorioPreAnaliseMB.PAGINA_RELATORIO;
    }

    /**
     * @see br.gov.caixa.pedesgo.arquitetura.controlador.AbstractBean#carregar()
     */
    @Override
    public void carregar() {
        this.carregarDados(this.getVisao().getPreAnaliseSelecionada().getContrato());
    }

    /**
     * @see br.gov.caixa.pedesgo.arquitetura.controlador.AbstractBean#getService()
     */
    @SuppressWarnings("unchecked")
    @Override
    public PreAnaliseService getService() {
        return this.preAnaliseService;
    }

    /**
     * @see br.gov.caixa.pedesgo.arquitetura.controlador.AbstractBean#getVisao()
     */
    @Override
    public RelatorioPreAnaliseVisao getVisao() {
        if (this.visao == null) {
            this.visao = new RelatorioPreAnaliseVisao();
        }

        return this.visao;
    }

    /**
     * Retorna o valor do atributo detalheDuplicatasMB.
     *
     * @return detalheDuplicatasMB
     */
    public DetalheDuplicatasMB getDetalheDuplicatasMB() {

        return this.detalheDuplicatasMB;
    }

    /**
     * Define o valor do atributo detalheDuplicatasMB.
     *
     * @param detalheDuplicatasMB
     *            valor a ser atribuído
     */
    public void setDetalheDuplicatasMB(final DetalheDuplicatasMB detalheDuplicatasMB) {

        this.detalheDuplicatasMB = detalheDuplicatasMB;
    }
    
    /**
     * <p>Método responsável por popular o mapa das bandeiras com as analises de estoque</p>.
     *
     * @author p541915
     *
     */
    private void categorizarCartaoEstoquePorBandeira() {
    	Map<BandeiraCartao,Collection<AnaliseCartaoBandeira>> mapaCartaoPorBandeira = new HashMap<>();
    	for (AnaliseCartaoCredito analise : this.getVisao().getListaCartaoCreditoEstoque()) {
    		for (AnaliseCartaoBandeira analiseBandeira : analise.getAnalisesCartaoBandeira()) {
    			BandeiraCartao bandeiraCartao = analiseBandeira.getBandeiraCartao();
				if (mapaCartaoPorBandeira.containsKey(bandeiraCartao)) {
    				mapaCartaoPorBandeira.get(bandeiraCartao).add(analiseBandeira);
    			} else {
    				Collection<AnaliseCartaoBandeira> listaAnaliseCartaoBandeira = new ArrayList<>();
    				listaAnaliseCartaoBandeira.add(analiseBandeira);
    				mapaCartaoPorBandeira.put(bandeiraCartao, listaAnaliseCartaoBandeira);
    			}
    			bandeiraCartao.setVrAnaliseEstoqueTotal(bandeiraCartao.getVrAnaliseEstoqueTotal().add(analiseBandeira.getVrSaldoTotal()));
    			bandeiraCartao.setVrAnaliseEstoqueGarantiaOutrosContratosTotal(bandeiraCartao.getVrAnaliseEstoqueGarantiaOutrosContratosTotal().add(analiseBandeira.getVrOutrosContratos()));
    			bandeiraCartao.setVrAnaliseEstoqueGarantiaContratoTotal(bandeiraCartao.getVrAnaliseEstoqueGarantiaContratoTotal().add(analiseBandeira.getVrConsumidoContrato()));
    			bandeiraCartao.setVrAnaliseEstoquePreAnaliseTotal(bandeiraCartao.getVrAnaliseEstoquePreAnaliseTotal().add(analiseBandeira.getVrSaldoDisponivel()));
    		}
    	}
    	this.getVisao().setMapaCartaoPorBandeiraEstoque(mapaCartaoPorBandeira);
	}
    
    /**
     * <p>Método responsável por popular o mapa das bandeiras com as analises de fluxo</p>.
     *
     * @author p541915
     *
     */
    private void categorizarCartaoFluxoPorBandeira() {
    	Map<BandeiraCartao,Collection<AnaliseCartaoBandeira>> mapaCartaoPorBandeira = new HashMap<>();
    	for (AnaliseCartaoCredito analise : this.getVisao().getListaCartaoCreditoFluxo()) {
    		for (AnaliseCartaoBandeira analiseBandeira : analise.getAnalisesCartaoBandeira()) {
    			BandeiraCartao bandeiraCartao = analiseBandeira.getBandeiraCartao();
				if (mapaCartaoPorBandeira.containsKey(bandeiraCartao)) {
    				mapaCartaoPorBandeira.get(bandeiraCartao).add(analiseBandeira);
    			} else {
    				Collection<AnaliseCartaoBandeira> listaAnaliseCartaoBandeira = new ArrayList<>();
    				listaAnaliseCartaoBandeira.add(analiseBandeira);
    				mapaCartaoPorBandeira.put(bandeiraCartao, listaAnaliseCartaoBandeira);
    			}
    			bandeiraCartao.setVrAnaliseFluxoTotal(bandeiraCartao.getVrAnaliseFluxoTotal().add(analiseBandeira.getVrSaldoTotal()));
    			bandeiraCartao.setVrAnaliseFluxoGarantiaOutrosContratosTotal(bandeiraCartao.getVrAnaliseFluxoGarantiaOutrosContratosTotal().add(analiseBandeira.getVrOutrosContratos()));
    			bandeiraCartao.setVrAnaliseFluxoGarantiaContratoTotal(bandeiraCartao.getVrAnaliseFluxoGarantiaContratoTotal().add(analiseBandeira.getVrConsumidoContrato()));
    			bandeiraCartao.setVrAnaliseFluxoPreAnaliseTotal(bandeiraCartao.getVrAnaliseFluxoPreAnaliseTotal().add(analiseBandeira.getVrSaldoDisponivel()));
    		}
    	}
    	this.getVisao().setMapaCartaoPorBandeiraFluxo(mapaCartaoPorBandeira);
	}
}
