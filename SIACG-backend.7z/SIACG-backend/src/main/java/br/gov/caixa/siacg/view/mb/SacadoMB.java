/**
 * reservados. Copyright (c) 2009-2011 Caixa Econômica Federal. Todos os direitos
 *
 * Caixa Econômica Federal - SIACG – Sistema de Acompanhamento de Carteiras de Cobrança
 *
 * Este programa de computador foi desenvolvido sob demanda da CAIXA e está protegido por leis de direitos autorais e
 * tratados internacionais. As condições de cópia e utilização do todo ou partes dependem de autorização da pessoa.
 * Cópias não são permitidas sem expressa autorização. Não pode ser comercializado ou utilizado para propósitos
 * particulares.
 *
 * Uso exclusivo da Caixa Econômica Federal. A reprodução ou distribuição não autorizada deste programa ou de parte
 * dele, resultará em punições civis e criminais e os infratores incorrem em sanções previstas na legislação em vigor.
 *
 * Histórico do Subversion:
 *
 * LastChangedRevision: LastChangedBy: LastChangedDate:
 *
 * HeadURL:
 *
 */
package br.gov.caixa.siacg.view.mb;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.EnumSet;

import javax.ejb.EJB;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ManagedProperty;
import javax.faces.bean.SessionScoped;

import org.apache.commons.collections.CollectionUtils;

import br.gov.caixa.pedesgo.arquitetura.controlador.ManutencaoBean;
import br.gov.caixa.pedesgo.arquitetura.enumerador.EnumAcao;
import br.gov.caixa.pedesgo.arquitetura.enumerador.EnumTipoFormatacao;
import br.gov.caixa.pedesgo.arquitetura.to.MensagemTO;
import br.gov.caixa.pedesgo.arquitetura.util.MensagensUtil;
import br.gov.caixa.pedesgo.arquitetura.util.UsuarioUtil;
import br.gov.caixa.pedesgo.arquitetura.util.UtilCnpj;
import br.gov.caixa.pedesgo.arquitetura.util.UtilCpf;
import br.gov.caixa.pedesgo.arquitetura.util.UtilFormatacao;
import br.gov.caixa.pedesgo.arquitetura.util.UtilObjeto;
import br.gov.caixa.pedesgo.arquitetura.util.UtilString;
import br.gov.caixa.siacg.model.domain.Cedente;
import br.gov.caixa.siacg.model.domain.Sacado;
import br.gov.caixa.siacg.model.enums.AbrangenciaSacadoEnum;
import br.gov.caixa.siacg.model.enums.NoFuncionalidadeEnum;
import br.gov.caixa.siacg.model.enums.TipoPessoaEnum;
import br.gov.caixa.siacg.model.vo.FiltroSacadoVO;
import br.gov.caixa.siacg.pagination.SacadoLazyModel;
import br.gov.caixa.siacg.service.SacadoService;
import br.gov.caixa.siacg.view.form.SacadoVisao;

/**
 * <p>
 * SacadoMB
 * </p>
 * <p>
 * Descrição: Managed bean do caso de uso <code>Sacado</code>.
 * </p>
 * <br>
 * <b>Empresa:</b> Cef - Caixa Econômica Federal
 *
 * @author Waltenes Junior
 * @version 1.0
 */
@ManagedBean
@SessionScoped
public class SacadoMB extends ManutencaoBean<Sacado> {

    /** Atributo serialVersionUID. */
    private static final long serialVersionUID = 1133316313004308593L;

    /** Atributo NOME_MANAGED_BEAN. */
    public static final String NOME_MANAGED_BEAN = "sacadoMB";

    /** Atributo EL_MANAGED_BEAN. */
    public static final String EL_MANAGED_BEAN = "#{sacadoMB}";

    /** Atributo PAGINA_SACADO_CONSULTA. */
    private static final String PAGINA_SACADO_CONSULTA = "/pages/manutencao/consulta.xhtml?faces-redirect=true";

    /** Atributo MENSAGEM_CNPJ_CPF_EXISTE. */
    private static final String MENSAGEM_CNPJ_CPF_EXISTE = "MN007";

    /** Atributo PROPERTIE_MENSAGEM_APP. */
    private static final String PROPERTIE_MENSAGEM_APP = "msgApp";

    /** Atributo STRING_VAZIA. */
    private static final String STRING_VAZIA = "";

    /** Atributo CEDENTE_INEXISTENTE. */
    private static final String CEDENTE_INEXISTENTE = "MN034";

    /** Atributo CEDENTE_EXISTENTE. */
    private static final String CEDENTE_EXISTENTE = "MN033";

    /** Atributo OPERACAO_REALIZADA_SUCESSO. */
    private static final String OPERACAO_REALIZADA_SUCESSO = "MA002";

    /** Atributo consulta. */
    @ManagedProperty(value = SacadoLazyModel.EL_MANAGED_BEAN)
    private SacadoLazyModel consulta;

    /** Atributo service. */
    @EJB
    private transient SacadoService service;

    /** Atributo visao. */
    private SacadoVisao visao;

    /**
     * @see br.gov.caixa.pedesgo.arquitetura.controlador.AbstractBean#getNomeVarResourceBundle()
     */
    @Override
    protected String getNomeVarResourceBundle() {
	return SacadoMB.PROPERTIE_MENSAGEM_APP;
    }

    /**
     * <p>
     * Método responsável por carregar os dados da visão.
     * <p>
     *
     * @author Waltenes Junior
     */
    private void carregarDadosVisaoConsulta() {
	this.setVisao(new SacadoVisao());
	this.visao.setListaTipoPessoa(EnumSet.allOf(TipoPessoaEnum.class));
	this.visao.setListaAbrangenciaSacadoEnum(Arrays.asList(AbrangenciaSacadoEnum.values()));
	this.visao.setCedente(new Cedente());
	this.getVisao().setCedenteParaRemover(new Cedente());
	this.consulta.setFiltroSacadoVO(new FiltroSacadoVO());
	this.consulta.getFiltroSacadoVO().setTipoPessoaTO(TipoPessoaEnum.F);
	this.consulta.getFiltroSacadoVO().setAbrangenciaSacado(AbrangenciaSacadoEnum.CAIXA);
	this.getVisao().setRenderizaBotaoInclui(Boolean.TRUE);
	this.visao.setSacadoParaExcluir(new Sacado());
    }

    /**
     * <p>
     * Método responsável por remover o cedente selecionado da lista.
     * <p>
     *
     * @author Caio Graco
     */
    public void removerCedente() {
	final Cedente cedenteParaRemover = this.getVisao().getCedenteParaRemover();

	final Collection<Cedente> listaCedente = this.consulta.getFiltroSacadoVO().getListaCedente();
	final Collection<Cedente> listaCedenteParaRemover = new ArrayList<>();

	for (final Cedente cedente : listaCedente) {
	    if (cedente.getCoCedente().equals(cedenteParaRemover.getCoCedente())) {
		listaCedenteParaRemover.add(cedente);
	    }
	}

	listaCedente.removeAll(listaCedenteParaRemover);

	this.consulta.getFiltroSacadoVO().setListaCedente(listaCedente);

	this.getVisao().setCedenteParaRemover(new Cedente());
    }

    /**
     * <p>
     * Método responsável por carregar os dados necessarios para a edição do
     * sacado não aceito.
     * <p>
     *
     * @param sacado
     *            valor a ser atribuído
     * @param filtro
     *            valor a ser atribuído
     * @author Waltenes Junior
     */
    private void carregarEdicao(Sacado sacado, final FiltroSacadoVO filtro) {
		sacado = this.service.obterComRelacionamentoInicializado(sacado);
		filtro.setApelidoTO(sacado.getNoApelido());
		filtro.setTipoPessoaTO(sacado.getIcPessoa());
		filtro.setNuSacado(sacado.getNuSacado());
		filtro.setAbrangenciaSacado(AbrangenciaSacadoEnum.getEnumPorCodigo(sacado.getIcAbrangencia()));
		this.verificarListaCedentes(sacado, filtro);
		
		String cnpjPessoaVO = sacado.getCoDocumento();		
		if (cnpjPessoaVO.length() == 14 && UtilCnpj.isCNPJ(cnpjPessoaVO)) {
			 filtro.setCpfTO(UtilFormatacao.formatar(cnpjPessoaVO,  EnumTipoFormatacao.CNPJ));
		} else if (cnpjPessoaVO.length() == 14 && !UtilCnpj.isCNPJ(cnpjPessoaVO)) {
			filtro.setCpfTO(UtilFormatacao.formatar(cnpjPessoaVO.substring(3, 14),  EnumTipoFormatacao.CPF));
		} else if (cnpjPessoaVO.length() == 11) {
			filtro.setCpfTO(UtilFormatacao.formatar(cnpjPessoaVO,  EnumTipoFormatacao.CPF));
		}
		filtro.setRazaoSocialSacadoTO(sacado.getNoSacado());	
	
		this.visao.setEdicao(true);
    }

    /**
     * <p>
     * Método responsável por verificar a lista de cedentes.
     * <p>
     *
     * @param sacado
     *            valor a ser atribuído
     * @param filtro
     *            valor a ser atribuído
     * @author Caio Graco
     */
    private void verificarListaCedentes(final Sacado sacado, final FiltroSacadoVO filtro) {
	final Collection<String> listaCodigoCedente = new ArrayList<>();
	final Collection<Cedente> listaCedenteNaoRepetido = new ArrayList<>();

	for (final Cedente cedente : sacado.getListaCedenteNaoAceito()) {
	    if (!listaCodigoCedente.contains(cedente.getCoCedente())) {
		listaCodigoCedente.add(cedente.getCoCedente());
	    }
	}

	for (final String codigo : listaCodigoCedente) {
	    final Collection<Cedente> listaCedente = this.service.obterListaCedentePorCodigo(codigo);

	    listaCedenteNaoRepetido.add(listaCedente.iterator().next());
	}

	filtro.setListaCedente(listaCedenteNaoRepetido);
    }

    /**
     * <p>
     * Método responsável por abrir a tela de consutla do sacado.
     * <p>
     *
     * @param filtro
     * @return <code>String</code>
     * @author Waltenes Junior
     */
    public String abrirConsulta() {
	this.carregarDadosVisaoConsulta();
	this.limparCampoFiltro();
	this.verificarPermissoes();
	return SacadoMB.PAGINA_SACADO_CONSULTA;
    }

    /**
     * <p>
     * Método responsável por abrir a tela de edição do Sacado.
     * <p>
     *
     * @param sacado
     *            valor a ser atribuído
     * @return <code>String</code>
     * @author Waltenes Junior
     */
    public String abrirEdicao(final Sacado sacado) {
	this.carregarEdicao(sacado, this.consulta.getFiltroSacadoVO());
	this.visao.setRenderizaBotaoEdita(true);
	this.visao.setRenderizaBotaoInclui(false);
	return super.MESMA_TELA;
    }

    /**
     * <p>
     * Método responsável por filtrar a consulta de acordo com os dados passados
     * por parêmetro.
     * <p>
     *
     * @return <code>String</code>
     * @author Waltenes Junior
     */
    public void filtraConsulta() {
	this.visao.setEdicao(Boolean.FALSE);
	this.limparCampoFiltro();
	this.visao.setRenderizaBotaoInclui(Boolean.TRUE);
	this.visao.setRenderizaBotaoEdita(Boolean.FALSE);
    }

    /**
     * <p>
     * Método responsável por incluir um sacado na base.
     * <p>
     *
     * @param filtroSacadoVO
     *            valor a ser atribuído
     * @return <code>String</code>
     * @author Waltenes Junior, Ronnie Mikihiro
     */
    public void incluirSacado(final FiltroSacadoVO filtroSacadoVO) {
	if (!this.getVisao().isEdicao()) {
	    filtroSacadoVO.setNuSacado(null);
	}

	final Sacado sacadoNovo = this.atribuirValorSacado(filtroSacadoVO);

	if (UtilString.isVazio(sacadoNovo.getCoDocumento()) || UtilString.isVazio(sacadoNovo.getNoSacado())
		|| (sacadoNovo.getIcAbrangencia().equals(AbrangenciaSacadoEnum.CEDENTE.getCodigo())
			&& CollectionUtils.isEmpty(sacadoNovo.getListaCedenteNaoAceito()))) {
	    this.service.validarCamposObrigatorios(sacadoNovo);
	    
	    if (sacadoNovo.hasMensagens()){
		    for (final MensagemTO mensagem : sacadoNovo.getMensagens()){
		    	MensagensUtil.adicionaMensagemDeAlerta( "msgApp", mensagem.getChaveMensagem(), mensagem.getArgumentos());
		    }
		}
	} else {
	    final Sacado sacadoAlterar = this.service.obterSacadoPorCoDocumento(sacadoNovo.getCoDocumento());
	    if (sacadoAlterar != null) {
		this.atribuirValoresSacadoParaAlteracao(filtroSacadoVO, sacadoAlterar);
	    }

	    if (!this.visao.isEdicao() && sacadoAlterar != null && sacadoAlterar.getCoDocumento().trim().equals(sacadoNovo.getCoDocumento().trim())
		    && sacadoAlterar.getIcNaoAceito().equals(true)) {
		super.adicionaMensagemInformativa(SacadoMB.MENSAGEM_CNPJ_CPF_EXISTE);
	    } else {
		if (sacadoAlterar != null) {
		    this.salvarSacado(sacadoAlterar);
		} else {
		    this.salvarSacado(sacadoNovo);
		}

		this.limparCampoFiltro();
		this.getVisao().setEdicao(Boolean.FALSE);
		this.getVisao().setRenderizaBotaoEdita(Boolean.FALSE);
		this.getVisao().setRenderizaBotaoInclui(Boolean.TRUE);
	    }
	}
    }

    /**
     * <p>
     * Método responsável por atribuir os valores do sacado para alteração.
     * <p>
     *
     * @param filtroSacadoVO
     *            valor a ser atribuído
     * @param sacadoAlterar
     *            valor a ser atribuído
     * @author Caio Graco
     */
    private void atribuirValoresSacadoParaAlteracao(final FiltroSacadoVO filtroSacadoVO, final Sacado sacadoAlterar) {
	if (sacadoAlterar.getIcNaoAceito() == null) {
	    sacadoAlterar.setIcNaoAceito(false);
	}
	if (!filtroSacadoVO.getApelidoTO().isEmpty()) {
	    sacadoAlterar.setNoApelido(filtroSacadoVO.getApelidoTO());
	}
	if (!UtilString.isVazio(filtroSacadoVO.getCnpjTO())) {
	    sacadoAlterar.setCoDocumento(UtilCnpj.removerFormatacao(filtroSacadoVO.getCnpjTO()));
	}
	if (!UtilString.isVazio(filtroSacadoVO.getCpfTO())) {
	    sacadoAlterar.setCoDocumento(UtilFormatacao.completarComZeroEsquerda(UtilCnpj.removerFormatacao(filtroSacadoVO.getCpfTO()), 14));
	}
	if (filtroSacadoVO.getTipoPessoaTO() != null) {
	    sacadoAlterar.setIcPessoa(filtroSacadoVO.getTipoPessoaTO());
	}
	if (filtroSacadoVO.getTituloList() != null) {
	    sacadoAlterar.setTituloList(filtroSacadoVO.getTituloList());
	}
	if (!UtilString.isVazio(filtroSacadoVO.getRazaoSocialSacadoTO())) {
	    sacadoAlterar.setNoSacado(filtroSacadoVO.getRazaoSocialSacadoTO());
	}
	if (!UtilString.isVazio(filtroSacadoVO.getNomeSacadoTO())) {
	    sacadoAlterar.setNoSacado(filtroSacadoVO.getNomeSacadoTO());
	}
	if (filtroSacadoVO.getAbrangenciaSacado() != null) {
	    sacadoAlterar.setIcAbrangencia(filtroSacadoVO.getAbrangenciaSacado().getCodigo());
	}
	if (CollectionUtils.isNotEmpty(filtroSacadoVO.getListaCedente())) {
	    sacadoAlterar.setListaCedenteNaoAceito(filtroSacadoVO.getListaCedente());
	}
    }

    /**
     * <p>
     * Método responsável por salvar o sacado.
     * <p>
     *
     * @param sacado
     *            valor a ser atribuído
     * @author Caio Graco
     */
    private void salvarSacado(final Sacado sacado) {
	sacado.setIcNaoAceito(true);

	final Collection<Cedente> listaFinal = new ArrayList<>();

	for (final Cedente cedente : sacado.getListaCedenteNaoAceito()) {
	    final Collection<Cedente> listaCedente = this.service.obterListaCedentePorCodigo(cedente.getCoCedente());

	    listaFinal.addAll(listaCedente);
	}

	if (sacado.getIcAbrangencia().equals(AbrangenciaSacadoEnum.CAIXA.getCodigo())) {
	    sacado.setListaCedenteNaoAceito(null);
	} else {
	    sacado.setListaCedenteNaoAceito(listaFinal);
	}

	super.salvar(sacado);
	this.limparCampoFiltro();
    }

    /**
     * <p>
     * Método responsável por atribuir valor a um sacado.
     * <p>
     *
     * @param filtro
     *            valor a ser atribuído
     * @return Sacado
     * @author Waltenes Junior
     */
    private Sacado atribuirValorSacado(final FiltroSacadoVO filtro) {
	final Sacado sacado = new Sacado();

	if (!UtilString.isVazio(filtro.getCpfTO())) {
	    String documento = UtilCnpj.removerFormatacao(filtro.getCpfTO());
	    sacado.setCoDocumento(documento);
	    sacado.setNoSacado(filtro.getRazaoSocialSacadoTO());
	    sacado.setIcPessoa(UtilCpf.isCPF(documento) ? TipoPessoaEnum.F : TipoPessoaEnum.J);
	}

	if (UtilObjeto.isReferencia(filtro.getNuSacado())) {
	    sacado.setNuSacado(filtro.getNuSacado());
	}

	if (!UtilString.isVazio(filtro.getApelidoTO())) {
	    sacado.setNoApelido(filtro.getApelidoTO());
	} else {
	    sacado.setNoApelido(null);
	}

	sacado.setIcAbrangencia(filtro.getAbrangenciaSacado().getCodigo());
	sacado.setListaCedenteNaoAceito(filtro.getListaCedente());

	return sacado;
    }

    /**
     * <p>
     * Método responsável por excluir tarefa: #3030.
     * <p>
     *
     * @return <code>String</code>
     * @author Thales Ribeiro, guilherme.santos
     */
    public String excluirSacado() {
	final Sacado sacado = this.getVisao().getSacadoParaExcluir();

	sacado.setIcNaoAceito(false);
	sacado.setListaCedenteNaoAceito(null);

	this.service.alterar(sacado);

	this.limparCampoFiltro();
	this.visao.setEdicao(false);

	super.adicionaMensagemDeSucesso(SacadoMB.OPERACAO_REALIZADA_SUCESSO);

	return super.MESMA_TELA;
    }

    /**
     * <p>
     * Método responsável por limpar dados da entidade na inclusao.
     * <p>
     *
     * @author Waltenes Junior
     */
    public void limparCampoEntidade() {
	final Sacado entidade = this.visao.getEntidade();
	entidade.setCoDocumento(null);
	entidade.setNoApelido(null);
	entidade.setNoSacado(null);
	entidade.setIcAbrangencia(AbrangenciaSacadoEnum.CAIXA.getCodigo());
	entidade.setListaCedenteNaoAceito(new ArrayList<Cedente>());
	this.getVisao().setCedente(new Cedente());
	this.getVisao().setCedenteParaRemover(new Cedente());
	this.getVisao().setSacadoParaExcluir(new Sacado());
    }

    /**
     * <p>
     * Método responsável por executar ações após a troca de abrangencia.
     * <p>
     *
     * @author Caio Graco
     */
    public void alterarTipoAbrangencia() {
	this.getVisao().setCedente(new Cedente());
	this.consulta.getFiltroSacadoVO().setListaCedente(new ArrayList<Cedente>());
    }

    /**
     * <p>
     * Método responsável por adicionar o cedente na lista.
     * <p>
     *
     * @author Caio Graco
     */
    public void adicionarCedente() {
	final Cedente cedenteInserido = this.getVisao().getCedente();

	if (cedenteInserido != null && !UtilString.isVazio(cedenteInserido.getCoCedente())) {
	    final Collection<Cedente> listaCedenteConsultado = this.service.obterListaCedentePorCodigo(cedenteInserido.getCoCedente());

	    if (CollectionUtils.isEmpty(listaCedenteConsultado)) {
		super.adicionaMensagemDeAlerta(SacadoMB.CEDENTE_INEXISTENTE);
	    } else {
		final Collection<Cedente> listaCedente = this.consulta.getFiltroSacadoVO().getListaCedente();

		if (this.verificarCedenteExiste(listaCedenteConsultado, listaCedente)) {
		    super.adicionaMensagemDeAlerta(SacadoMB.CEDENTE_EXISTENTE);
		} else {
		    listaCedente.add(listaCedenteConsultado.iterator().next());

		    this.consulta.getFiltroSacadoVO().setListaCedente(listaCedente);

		    this.getVisao().setCedente(new Cedente());
		}
	    }
	}
    }

    /**
     * <p>
     * Método responsável por verificar se o cedente já existe na lista.
     * <p>
     *
     * @param listaCedenteConsultado
     *            valor a ser atribuído
     * @param listaCedente
     *            valor a ser atribuído
     * @return boolean
     * @author Caio Graco
     */
    private boolean verificarCedenteExiste(final Collection<Cedente> listaCedenteConsultado, final Collection<Cedente> listaCedente) {
	boolean existe = false;

	for (final Cedente cedente : listaCedenteConsultado) {
	    if (listaCedente.contains(cedente)) {
		existe = true;

		break;
	    }
	}

	return existe;
    }

    /**
     * <p>
     * Método responsável por limpar campos do filtro da tela de consulta.
     * <p>
     *
     * @author Waltenes Junior
     */
    public void limparCampoFiltro() {
	final FiltroSacadoVO filtro = this.consulta.getFiltroSacadoVO();
	filtro.setApelidoTO(null);
	filtro.setCnpjTO(null);
	filtro.setCpfTO(null);
	filtro.setNomeSacadoTO(null);
	filtro.setRazaoSocialSacadoTO(null);
	filtro.setAbrangenciaSacado(AbrangenciaSacadoEnum.CAIXA);
	filtro.setListaCedente(new ArrayList<Cedente>());
	this.getVisao().setCedente(new Cedente());
	this.getVisao().setCedenteParaRemover(new Cedente());
	this.getVisao().setSacadoParaExcluir(new Sacado());
    }

    /**
     * <p>
     * Método responsável por buscar um sacado de acordo com o numero do
     * documento e se existir atribuir valores ao sacado.
     * <p>
     *
     * @param evento
     *            valor a ser atribuído
     * @author Waltenes Junior
     */
    public void buscarAtribuirValorSacado() {
	final FiltroSacadoVO filtro = this.consulta.getFiltroSacadoVO();
	if (UtilObjeto.isReferencia(filtro.getCpfTO())) {
	    String documento = filtro.getCpfTO();
	    Sacado sacado = this.service.obterSacadoPorCoDocumento(documento);
	    sacado = this.service.obterComRelacionamentoInicializado(sacado);

	    if (UtilObjeto.isReferencia(sacado)) {
		this.atribuirValoresSacadoAjax(filtro, sacado);
	    } else {
		filtro.setNomeSacadoTO(SacadoMB.STRING_VAZIA);
		filtro.setApelidoTO(SacadoMB.STRING_VAZIA);
		filtro.setAbrangenciaSacado(AbrangenciaSacadoEnum.CAIXA);
	    }
	}

    }

    /**
     * <p>
     * Método responsável por atribuir os valores do sacado de acordo com a
     * função ajax da tela.
     * <p>
     *
     * @param filtro
     *            valor a ser atribuído
     * @param sacado
     *            valor a ser atribuído
     * @author Caio Graco
     */
    private void atribuirValoresSacadoAjax(final FiltroSacadoVO filtro, final Sacado sacado) {
	if (!UtilString.isVazio(sacado.getNoSacado())) {
	    filtro.setRazaoSocialSacadoTO(sacado.getNoSacado());
	}

	filtro.setApelidoTO(sacado.getNoApelido());
	filtro.setTituloList(sacado.getTituloList());
	filtro.setNuSacado(sacado.getNuSacado());
	filtro.setAbrangenciaSacado(AbrangenciaSacadoEnum.getEnumPorCodigo(sacado.getIcAbrangencia()));

	this.verificarListaCedentes(sacado, filtro);
    }

    /**
     * @see br.gov.caixa.pedesgo.arquitetura.controlador.AbstractBean#getService()
     */
    @SuppressWarnings("unchecked")
    @Override
    public SacadoService getService() {
	return this.service;
    }

    /**
     * Retorna o valor do atributo consulta.
     *
     * @return <code>consulta</code>
     */
    public SacadoLazyModel getConsulta() {
	if (this.consulta == null) {
	    this.consulta = new SacadoLazyModel();
	}
	return this.consulta;
    }

    /**
     * Retorna o valor do atributo visao.
     *
     * @return <code>visao</code>
     */
    @Override
    public SacadoVisao getVisao() {
	if (this.visao == null) {
	    this.visao = new SacadoVisao();
	}
	return this.visao;
    }

    /**
     * Define o valor do atributo consulta.
     *
     * @param consulta
     *            valor a ser atribuído
     */
    public void setConsulta(final SacadoLazyModel consulta) {
	this.consulta = consulta;
    }

    /**
     * Define o valor do atributo visao.
     *
     * @param visao
     *            valor a ser atribuído
     */
    public void setVisao(final SacadoVisao visao) {
	this.visao = visao;
    }

    /**
     * @see br.gov.caixa.pedesgo.arquitetura.controlador.AbstractBean#getPrefixoCasoDeUso()
     */
    @Override
    protected String getPrefixoCasoDeUso() {
	return null;
    }

    /**
     * <p>
     * Método responsável por verificar permissões do usuario logado.
     * <p>
     *
     * @author guilherme.santos
     */
    private void verificarPermissoes() {
	// Controle de permissões da funcionalidade Editar Sacado Não Aceito
	this.getVisao().setExibirBotaoEditar(UsuarioUtil.contemPermissao(NoFuncionalidadeEnum.MANTEM_SACADO_NAO_ACEITO.getNoFuncionalidade(),
		EnumAcao.ALTERAR.getNoAcao(), null, null));
	// Controle de permissões da funcionalidade Editar Sacado Não Aceito
	this.getVisao().setExibirBotaoIncluir(UsuarioUtil.contemPermissao(NoFuncionalidadeEnum.MANTEM_SACADO_NAO_ACEITO.getNoFuncionalidade(),
		EnumAcao.INCLUIR.getNoAcao(), null, null));
	// Controle de permissões da funcionalidade Editar Sacado Não Aceito
	this.getVisao().setExibirBotaoExcluir(UsuarioUtil.contemPermissao(NoFuncionalidadeEnum.MANTEM_SACADO_NAO_ACEITO.getNoFuncionalidade(),
		EnumAcao.EXCLUIR.getNoAcao(), null, null));
    }
}
