package br.gov.caixa.siacg.pagination;

import java.util.List;
import java.util.Map;

import javax.ejb.EJB;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;

import org.primefaces.model.SortOrder;

import br.gov.caixa.pedesgo.arquitetura.paginacao.Paginacao;
import br.gov.caixa.pedesgo.arquitetura.paginacao.PaginacaoDemanda;
import br.gov.caixa.siacg.model.vo.AcompanhamentoControleGarantiasVO;
import br.gov.caixa.siacg.model.vo.EmpreendimentoVO;
import br.gov.caixa.siacg.service.EmpreendimentoService;

/**
 * <p>
 * ContratoLazyModel.
 * </p>
 * <p>
 * Descrição: Classe de paginação sob demanda do acompanhamento de endividamento
 * </p>
 * <br>
 * <b>Empresa:</b> Cef - Caixa Econômica Federal
 *
 * @author Caio Graco
 * @version 1.0
 */

@ManagedBean
@SessionScoped
public class AcompanhamentoControleGarantiasLazyModel extends Paginacao<AcompanhamentoControleGarantiasVO> {

    private static final long serialVersionUID = -6038965454195521432L;

    /** Atributo NOME_MANAGED_BEAN. */
    public static final String NOME_MANAGED_BEAN = "acompanhamentoControleGarantiasLazyModel";
    /** Atributo EL_MANAGED_BEAN. */
    public static final String EL_MANAGED_BEAN = "#{acompanhamentoControleGarantiasLazyModel}";

    /** Atributo service. */
    @EJB
    private transient EmpreendimentoService service;
    
    private transient EmpreendimentoVO filtro;


    /**
     * @see br.gov.caixa.pedesgo.arquitetura.integracao.componente.paginacao.Paginacao#getServico()
     */
    @Override
    @SuppressWarnings("unchecked")
    public EmpreendimentoService getServico() {
        return this.service;
    }

    /**
     * @see br.gov.caixa.pedesgo.arquitetura.integracao.componente.paginacao.Paginacao#load(int,
     *      int, java.lang.String, org.primefaces.model.SortOrder,
     *      java.util.Map)
     */

	@Override
    public List<AcompanhamentoControleGarantiasVO> load(final int inicio, final int fim, final String campoOrdenacao, final SortOrder ordenacao,
            final Map<String, String> parametros) {
    	
        final PaginacaoDemanda<AcompanhamentoControleGarantiasVO> resultado =  this.getServico().listaTitulosPorNumEmpreendimento(this.getFiltro().getNuEmpreendimento(), inicio, fim, parametros);
        
        this.filtro.setQtdRegistro(resultado.getQuantidadeRegistros());
        
        super.setWrappedData(resultado.getLista());
        super.setRowCount(resultado.getQuantidadeRegistros());

        return resultado.getLista();
    }

    /**
     * <p>
     * Método responsável por limpar filtro da consulta.
     * <p>
     *
     * @author Waltenes junior
     */
    public void limparFiltro() {
        this.filtro = new EmpreendimentoVO();
    }

    /**
     * Retorna o valor do atributo filtro.
     *
     * @return filtro
     */
    public EmpreendimentoVO getFiltro() {
        if (this.filtro == null) {
            this.filtro = new EmpreendimentoVO();
        }
        return this.filtro;
    }

    /**
     * Define o valor do atributo filtro.
     *
     * @param filtro
     *            valor a ser atribuído
     */
    public void setFiltro(final EmpreendimentoVO filtro) {
        this.filtro = filtro;
    }
}