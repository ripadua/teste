/*
 * Copyright (c) 2019 Caixa Econômica Federal. Todos os direitos
 * reservados.
 *
 * Caixa Econômica Federal - SIACG - Sistema de Crédito Rural
 *
 * Este software foi desenvolvido sob demanda da CAIXA e está
 * protegido por leis de direitos autorais e tratados internacionais. As
 * condições de cópia e utilização do todo ou partes dependem de autorização da
 * empresa. Cópias não são permitidas sem expressa autorização. Não pode ser
 * comercializado ou utilizado para propósitos particulares.
 *
 * Uso exclusivo da Caixa Econômica Federal. A reprodução ou distribuição não
 * autorizada deste programa ou de parte dele, resultará em punições civis e
 * criminais e os infratores incorrem em sanções previstas na legislação em
 * vigor.
 *
 * Histórico do TFS:
 *
 * LastChangedRevision: $Revision$
 * LastChangedBy: $Author$
 * LastChangedDate: $Date$
 *
 * HeadURL: $HeadURL$
 *
 */
package br.gov.caixa.siacg.view.form;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import org.apache.commons.collections.CollectionUtils;

import br.gov.caixa.pedesgo.arquitetura.visao.ManutencaoVisao;
import br.gov.caixa.siacg.model.domain.BandeiraCartao;
import br.gov.caixa.siacg.model.domain.ContaContrato;
import br.gov.caixa.siacg.model.domain.GarantiaCartaoCredito;
import br.gov.caixa.siacg.model.domain.GarantiaContrato;
import br.gov.caixa.siacg.model.vo.ContaCorrenteBandeirasVO;

/**
 * <p>
 * ContaCorrenteCartaoVisao
 * </p>
 *
 * <p>
 * Descrição: Classe responsável por armazenar os dados da visão do caso de uso
 * <code>Conta Corrente Cartão</code>.
 * </p>
 *
 * <br>
 * <b>Empresa:</b> Cef - Caixa Econômica Federal
 *
 *
 * @author Mábio Barbosa
 *
 * @version 1.0
 */
public class ContaCorrenteCartaoVisao extends ManutencaoVisao<GarantiaContrato> {

    /** Atributo serialVersionUID. */
    private static final long serialVersionUID = -8001710467838787362L;
    
    private GarantiaCartaoCredito garantiaCartaoCreditoSelecionado;

    /** Atributo vrTotalPactuadaGarantiaContratoCartao. */
    private BigDecimal vrTotalPactuadaContratoGarantiaCartao;

    /** Atributo vrTotalPactuadaGarantiaContratoCartao. */
    private BigDecimal vrTotalPactuadaBandeirasGarantiaCartao;

    /** Atributo vrTotalPactuadaGarantiaContratoCartao. */
    private BigDecimal vrTotalDiferencaPercentualBandeirasContas;

    /** Atributo preAnalise. */
    private boolean preAnalise;
    
    /** Atributo exibir botao incluir garantia. */
    private boolean exibirBotaoIncluirGarantia;

    /** Atributo contaCorrenteBandeirasVO. */
    private transient ContaCorrenteBandeirasVO contaCorrenteBandeirasVO;

    /** Atributo lista conta contrato cartao. */
    private List<ContaContrato> listaContaContratoCartao;

    private transient List<ContaCorrenteBandeirasVO> listaContaCorrenteBandeiras;

    /** Atributo listaBandeiraCartao. */
    private List<BandeiraCartao> listaBandeiraCartao;

    /**
     * <p>Retorna o valor do atributo garantiaCartaoCreditoSelecionado</p>.
     *
     * @return garantiaCartaoCreditoSelecionado
    */
    public GarantiaCartaoCredito getGarantiaCartaoCreditoSelecionado() {
        return this.garantiaCartaoCreditoSelecionado;
    }

    /**
     * <p>Define o valor do atributo garantiaCartaoCreditoSelecionado</p>.
     *
     * @param garantiaCartaoCreditoSelecionado valor a ser atribuído
    */
    public void setGarantiaCartaoCreditoSelecionado(GarantiaCartaoCredito garantiaCartaoCreditoSelecionado) {
        this.garantiaCartaoCreditoSelecionado = garantiaCartaoCreditoSelecionado;
    }

    /**
     * <p>
     * Retorna o valor do atributo vrTotalPactuadaContratoGarantiaCartao
     * </p>
     * .
     *
     * @return vrTotalPactuadaContratoGarantiaCartao
     */
    public BigDecimal getVrTotalPactuadaContratoGarantiaCartao() {
	return this.vrTotalPactuadaContratoGarantiaCartao;
    }

    /**
     * <p>
     * Define o valor do atributo vrTotalPactuadaContratoGarantiaCartao
     * </p>
     * .
     *
     * @param vrTotalPactuadaContratoGarantiaCartao
     *            valor a ser atribuído
     */
    public void setVrTotalPactuadaContratoGarantiaCartao(BigDecimal vrTotalPactuadaContratoGarantiaCartao) {
	this.vrTotalPactuadaContratoGarantiaCartao = vrTotalPactuadaContratoGarantiaCartao;
    }

    /**
     * <p>
     * Retorna o valor do atributo vrTotalPactuadaBandeirasGarantiaCartao
     * </p>
     * .
     *
     * @return vrTotalPactuadaBandeirasGarantiaCartao
     */
    public BigDecimal getVrTotalPactuadaBandeirasGarantiaCartao() {
	return this.vrTotalPactuadaBandeirasGarantiaCartao;
    }

    /**
     * <p>
     * Define o valor do atributo vrTotalPactuadaBandeirasGarantiaCartao
     * </p>
     * .
     *
     * @param vrTotalPactuadaBandeirasGarantiaCartao
     *            valor a ser atribuído
     */
    public void setVrTotalPactuadaBandeirasGarantiaCartao(BigDecimal vrTotalPactuadaBandeirasGarantiaCartao) {
	this.vrTotalPactuadaBandeirasGarantiaCartao = vrTotalPactuadaBandeirasGarantiaCartao;
    }

    /**
     * <p>
     * Retorna o valor do atributo
     * vrTotalDiferencaPercentualBandeirasContas
     * </p>
     * .
     *
     * @return vrTotalDiferencaPercentualBandeirasContas
     */
    public BigDecimal getVrTotalDiferencaPercentualBandeirasContas() {
	return this.vrTotalDiferencaPercentualBandeirasContas;
    }

    /**
     * <p>
     * Define o valor do atributo
     * vrTotalDiferencaPercentualBandeirasContas
     * </p>
     * .
     *
     * @param vrTotalDiferencaPercentualBandeirasContas
     *            valor a ser atribuído
     */
    public void setVrTotalDiferencaPercentualBandeirasContas(BigDecimal vrTotalDiferencaPercentualBandeirasContas) {
	this.vrTotalDiferencaPercentualBandeirasContas = vrTotalDiferencaPercentualBandeirasContas;
    }

    /**
     * <p>
     * Retorna o valor do atributo preAnalise
     * </p>
     * .
     *
     * @return preAnalise
     */
    public boolean isPreAnalise() {
	return this.preAnalise;
    }

    /**
     * <p>
     * Define o valor do atributo preAnalise
     * </p>
     * .
     *
     * @param preAnalise
     *            valor a ser atribuído
     */
    public void setPreAnalise(boolean preAnalise) {
	this.preAnalise = preAnalise;
    }

    /**
     * <p>Retorna o valor do atributo exibirBotaoIncluirGarantia</p>.
     *
     * @return exibirBotaoIncluirGarantia
    */
    public boolean isExibirBotaoIncluirGarantia() {
        return this.exibirBotaoIncluirGarantia;
    }

    /**
     * <p>Define o valor do atributo exibirBotaoIncluirGarantia</p>.
     *
     * @param exibirBotaoIncluirGarantia valor a ser atribuído
    */
    public void setExibirBotaoIncluirGarantia(boolean exibirBotaoIncluirGarantia) {
        this.exibirBotaoIncluirGarantia = exibirBotaoIncluirGarantia;
    }

    /**
     * <p>Retorna o valor do atributo contaCorrenteBandeirasVO</p>.
     *
     * @return contaCorrenteBandeirasVO
    */
    public ContaCorrenteBandeirasVO getContaCorrenteBandeirasVO() {
        return this.contaCorrenteBandeirasVO;
    }

    /**
     * <p>Define o valor do atributo contaCorrenteBandeirasVO</p>.
     *
     * @param contaCorrenteBandeirasVO valor a ser atribuído
    */
    public void setContaCorrenteBandeirasVO(ContaCorrenteBandeirasVO contaCorrenteBandeirasVO) {
        this.contaCorrenteBandeirasVO = contaCorrenteBandeirasVO;
    }

    /**
     * <p>
     * Retorna o valor do atributo listaContaCorrenteBandeiras
     * </p>
     * .
     *
     * @return listaContaCorrenteBandeiras
     */
    public List<ContaCorrenteBandeirasVO> getListaContaCorrenteBandeiras() {
	if (CollectionUtils.isEmpty(this.listaContaCorrenteBandeiras)) {
	    this.listaContaCorrenteBandeiras = new ArrayList<>();
	}

	return this.listaContaCorrenteBandeiras;
    }

    /**
     * <p>
     * Define o valor do atributo listaContaCorrenteBandeiras
     * </p>
     * .
     *
     * @param listaContaCorrenteBandeiras
     *            valor a ser atribuído
     */
    public void setListaContaCorrenteBandeiras(List<ContaCorrenteBandeirasVO> listaContaCorrenteBandeiras) {
	this.listaContaCorrenteBandeiras = listaContaCorrenteBandeiras;
    }

    /**
     * Retorna o valor do atributo listaContaContratoCartao.
     *
     * @return listaContaContratoCartao
     */
    public List<ContaContrato> getListaContaContratoCartao() {
	if (this.listaContaContratoCartao == null) {
	    this.listaContaContratoCartao = new ArrayList<>();
	}

	return this.listaContaContratoCartao;
    }

    /**
     * Define o valor do atributo listaContaContratoCartao.
     *
     * @param listaContaContratoCartao
     *            valor a ser atribuído
     */
    public void setListaContaContratoCartao(final List<ContaContrato> listaContaContratoCartao) {
	this.listaContaContratoCartao = listaContaContratoCartao;
    }

    /**
     * <p>
     * Retorna o valor do atributo listaBandeiraCartao
     * </p>
     * .
     *
     * @return listaBandeiraCartao
     */
    public List<BandeiraCartao> getListaBandeiraCartao() {
	if (this.listaBandeiraCartao == null) {
	    this.listaBandeiraCartao = new ArrayList<>();
	}
	return this.listaBandeiraCartao;
    }

    /**
     * <p>
     * Define o valor do atributo listaBandeiraCartao
     * </p>
     * .
     *
     * @param listaBandeiraCartao
     *            valor a ser atribuído
     */
    public void setListaBandeiraCartao(List<BandeiraCartao> listaBandeiraCartao) {
	this.listaBandeiraCartao = listaBandeiraCartao;
    }
}
