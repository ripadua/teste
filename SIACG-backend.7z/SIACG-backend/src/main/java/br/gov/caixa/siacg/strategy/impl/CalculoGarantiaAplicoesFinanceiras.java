package br.gov.caixa.siacg.strategy.impl;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import javax.ejb.EJB;
import javax.ejb.Stateless;

import br.gov.caixa.siacg.dao.AplicacaoFinanceiraDAO;
import br.gov.caixa.siacg.dao.GarantiaAplicacaoDAO;
import br.gov.caixa.siacg.dao.GarantiaContratoDAO;
import br.gov.caixa.siacg.model.domain.GarantiaAplicacao;
import br.gov.caixa.siacg.model.domain.GarantiaContrato;
import br.gov.caixa.siacg.model.vo.ParametrosCalculoGarantiaVO;
import br.gov.caixa.siacg.model.vo.RelatorioAnaliseContratoVO;
import br.gov.caixa.siacg.strategy.CalculoGarantia;

/**
 * <p>
 * CalculoGarantiaDuplicata
 * </p>
 * <p>
 * Descrição: Implementação do calculo para Garantia do tipo Aplicoes
 * Financeiras.
 * </p>
 * <br>
 * <b>Empresa:</b> Cef - Caixa Econômica Federal
 *
 * @author guilherme.santos
 * @version 1.0
 */
@Stateless(mappedName = "CalculoGarantiaAplicoesFinanceiras")
public class CalculoGarantiaAplicoesFinanceiras implements CalculoGarantia {

    private static final long serialVersionUID = -8396591055606104655L;

    /** Atributo garantiaContratoDao. */
    @EJB
    private GarantiaContratoDAO garantiaContratoDao;
    /** Atributo aplicacaoFinanceiraDAO. */
    @EJB
    private AplicacaoFinanceiraDAO aplicacaoFinanceiraDAO;
    /** Atributo garantiaAplicacaoDao. */
    @EJB
    private GarantiaAplicacaoDAO garantiaAplicacaoDao; 
    /**
     * @see br.gov.caixa.siacg.strategy.CalculoGarantia#calcular(br.gov.caixa.siacg.model.vo.ParametrosCalculoGarantiaVO,
     *      br.gov.caixa.siacg.model.vo.RelatorioAnaliseContratoVO)
     */
    @Override
    public RelatorioAnaliseContratoVO calcular(final ParametrosCalculoGarantiaVO parametrosCalculo, final RelatorioAnaliseContratoVO relatorio) {

        final BigDecimal vrApurado = BigDecimal.ZERO;

        List<GarantiaAplicacao> listaGarantiaAplicacao = new ArrayList<>(
        		this.garantiaAplicacaoDao.listarGarantiaAplicacaoComRelacionamentosInicializados(parametrosCalculo.getGarantiaContrato()));
        // Ordenar a lista de aplicações financeiras para o calculo
        listaGarantiaAplicacao = this.ordenarAplicacoesFinanceiras(listaGarantiaAplicacao);
        // Devolve o credito da garantia, quando exite para refazer os
        // calculos
        this.devolverCreditoConsumidoDasAplicacoes(listaGarantiaAplicacao);
        // Realizar calculos
        relatorio.setValorApurado(this.realizarCalculoAplicacaoFinanceira(vrApurado, parametrosCalculo.getValorEsperado(), listaGarantiaAplicacao));

        // Calcula o saldo liquido da aplicação financeira
        relatorio.setValorLiquidoAplicacaoFinanceira(this.calcularSaldoLiquido(listaGarantiaAplicacao));

        return relatorio;
    }

    /**
     * <p>
     * Método responsável por calcular o saldo liquido das aplicações
     * financeiras da {@link GarantiaContrato}.
     * <p>
     *
     * @param listaGarantiaAplicacao
     *            valor a ser atribuido
     * @return BigDecimal
     * @author guilherme.santos
     */
    private BigDecimal calcularSaldoLiquido(final List<GarantiaAplicacao> listaGarantiaAplicacao) {
        BigDecimal saldo = BigDecimal.ZERO;

        for (final GarantiaAplicacao garantiaAplicacao : listaGarantiaAplicacao) {
            saldo = saldo.add(garantiaAplicacao.getId().getAplicacaoFinanceira().getVrSaldoDisponivel());
        }

        return saldo;

    }

    /**
     * <p>
     * Método responsável por ordenar a lista de aplicações financeiras para o
     * calculo.
     * <p>
     * Criterios de ordenação: 1 - A quantidade de contratos que uma aplicação
     * participa, 2 - Menor valor da aplicação.
     *
     * @param listaGarantiaAplicacao
     *            valor a ser atribuido
     * @return List<GarantiaAplicacao>
     * @author guilherme.santos
     */
    private List<GarantiaAplicacao> ordenarAplicacoesFinanceiras(final List<GarantiaAplicacao> listaGarantiaAplicacao) {
        // Ordena a lista pela quantidade de contatos que a aplicação participa
        Collections.sort(listaGarantiaAplicacao, new Comparator<GarantiaAplicacao>() {
            @Override
            public int compare(final GarantiaAplicacao aplicacao1, final GarantiaAplicacao aplicacao2) {
                return aplicacao1.getId().getAplicacaoFinanceira().getNuConta().getContaContratoList().size() < aplicacao2.getId()
                        .getAplicacaoFinanceira().getNuConta().getContaContratoList().size() ? -1
                                : aplicacao1.getId().getAplicacaoFinanceira().getNuConta().getContaContratoList().size() > aplicacao2.getId()
                                        .getAplicacaoFinanceira().getNuConta().getContaContratoList().size() ? +1 : 0;
            }
        });
        // Re-ordena apenas os registros cuja a quantidade de contratos que a
        // aplicação participa sejam iguais.
        Collections.sort(listaGarantiaAplicacao, new Comparator<GarantiaAplicacao>() {
            @Override
            public int compare(final GarantiaAplicacao aplicacao1, final GarantiaAplicacao aplicacao2) {
                if (aplicacao1.getId().getAplicacaoFinanceira().getNuConta().getContaContratoList().size() == aplicacao2.getId()
                        .getAplicacaoFinanceira().getNuConta().getContaContratoList().size()) {
                    return aplicacao1.getId().getAplicacaoFinanceira().getVrSaldo()
                            .compareTo(aplicacao2.getId().getAplicacaoFinanceira().getVrSaldo());
                }
                return 0;
            }
        });
        return listaGarantiaAplicacao;
    }

    /**
     * <p>
     * Método responsável por devolver todos os valores consumidos pela garantia
     * das aplicações financeiras.
     * <p>
     *
     * @param listaGarantiaAplicacao
     *            valor a ser atribuido
     * @author guilherme.santos
     */
    private void devolverCreditoConsumidoDasAplicacoes(final List<GarantiaAplicacao> listaGarantiaAplicacao) {
        for (final GarantiaAplicacao garantiaAplicacao : listaGarantiaAplicacao) {
            if (garantiaAplicacao.getVrConsumidoAplicacaoFinanceira().compareTo(BigDecimal.ZERO) > 0) {
                final BigDecimal valorADevolver = garantiaAplicacao.getVrConsumidoAplicacaoFinanceira();
                garantiaAplicacao.getId().getAplicacaoFinanceira()
                        .setVrSaldoDisponivel(garantiaAplicacao.getId().getAplicacaoFinanceira().getVrSaldoDisponivel().add(valorADevolver));
                garantiaAplicacao.setVrConsumidoAplicacaoFinanceira(BigDecimal.ZERO);

                this.aplicacaoFinanceiraDAO.salvar(garantiaAplicacao.getId().getAplicacaoFinanceira());
            }
        }
    }

    /**
     * <p>
     * Método responsável por realizar o calculo da aplicação financeira.
     * <p>
     *
     * @param vrApurado
     *            valor a ser atribuido
     * @param vrEsperado
     *            valor a ser atribuido
     * @param listaGarantiaAplicacao
     *            valor a ser atribuido
     * @return BigDeciaml
     * @author guilherme.santos
     */
    private BigDecimal realizarCalculoAplicacaoFinanceira(BigDecimal vrApurado, final BigDecimal vrEsperado,
            final List<GarantiaAplicacao> listaGarantiaAplicacao) {
        for (final GarantiaAplicacao garantiaAplicacao : listaGarantiaAplicacao) {
            final BigDecimal diferencaVrApuradoVrEsperado = vrEsperado.subtract(vrApurado);
            // Verifica se a Aplicação tem saldo disponivel e se o valor apurado
            // ainda esta abaixo do esperado
            if (this.verificarExistenciaSaldoDisponivelAplicacao(garantiaAplicacao)
                    && this.verificarSeVrApuradoJaAtendeVrEsperado(diferencaVrApuradoVrEsperado)) {
                // Consome o saldo da aplicação financeira
                vrApurado = this.consumirSaldoDisponivelAplicacaoFinanceira(vrApurado, garantiaAplicacao, diferencaVrApuradoVrEsperado);
            }
        }
        return vrApurado;
    }

    /**
     * <p>
     * Método responsável por verificar se existe saldo disponivel na aplicação
     * financeira.
     * <p>
     *
     * @param garantiaAplicacao
     *            valor a ser atribuido
     * @return boolean
     * @author guilherme.santos
     */
    private boolean verificarExistenciaSaldoDisponivelAplicacao(final GarantiaAplicacao garantiaAplicacao) {
        return garantiaAplicacao.getId().getAplicacaoFinanceira().getVrSaldoDisponivel().compareTo(BigDecimal.ZERO) > 0;
    }

    /**
     * <p>
     * Método responsável por consumir o valor da aplicação financeira.
     * <p>
     *
     * @param vrApurado
     *            valor a ser atribuido
     * @param garantiaAplicacao
     *            valor a ser atribuido
     * @param diferencaVrApuradoVrEsperado
     *            valor a ser atribuido
     * @return BigDecimal
     * @author guilherme.santos
     */
    private BigDecimal consumirSaldoDisponivelAplicacaoFinanceira(BigDecimal vrApurado, final GarantiaAplicacao garantiaAplicacao,
            final BigDecimal diferencaVrApuradoVrEsperado) {
        // Verifica se o saldo disponivel da aplicação é suficiente para cobrir
        // o valor esperado
        if (garantiaAplicacao.getId().getAplicacaoFinanceira().getVrSaldoDisponivel().compareTo(diferencaVrApuradoVrEsperado) > -1) {
            garantiaAplicacao
                    .setVrConsumidoAplicacaoFinanceira(garantiaAplicacao.getVrConsumidoAplicacaoFinanceira().add(diferencaVrApuradoVrEsperado));
            garantiaAplicacao.getId().getAplicacaoFinanceira()
                    .setVrSaldoDisponivel(this.calcularSaldoDisponivel(garantiaAplicacao, diferencaVrApuradoVrEsperado));
            vrApurado = vrApurado.add(diferencaVrApuradoVrEsperado);
        } else {
            // A aplicação ainda possue valor mais não o suficiente para cobrir
            // o valor esperado
            garantiaAplicacao.setVrConsumidoAplicacaoFinanceira(garantiaAplicacao.getVrConsumidoAplicacaoFinanceira()
                    .add(garantiaAplicacao.getId().getAplicacaoFinanceira().getVrSaldoDisponivel()));
            vrApurado = vrApurado.add(garantiaAplicacao.getId().getAplicacaoFinanceira().getVrSaldoDisponivel());
            garantiaAplicacao.getId().getAplicacaoFinanceira().setVrSaldoDisponivel(BigDecimal.ZERO);
        }
        // Salva a aplicação financeira
        this.aplicacaoFinanceiraDAO.salvar(garantiaAplicacao.getId().getAplicacaoFinanceira());
        return vrApurado;
    }

    /**
     * <p>
     * Método responsável por verificar se o valor apurado é igual ao valor
     * esperado.
     * <p>
     *
     * @param diferencaVrApuradoVrEsperado
     *            valor a ser atribuido
     * @return boolean
     * @author guilherme.santos
     */
    private boolean verificarSeVrApuradoJaAtendeVrEsperado(final BigDecimal diferencaVrApuradoVrEsperado) {
        return diferencaVrApuradoVrEsperado.compareTo(BigDecimal.ZERO) > 0;
    }

    /**
     * <p>
     * Método responsável por calcular o calculo do saldo disponivel.
     * <p>
     *
     * @param garantiaAplicacao
     *            valor a ser atribuido
     * @param diferencaVrApuradoVrEsperado
     *            valor a ser atribuido
     * @return BigDecimal
     * @author guilherme.santos
     */
    private BigDecimal calcularSaldoDisponivel(final GarantiaAplicacao garantiaAplicacao, final BigDecimal diferencaVrApuradoVrEsperado) {
        return garantiaAplicacao.getId().getAplicacaoFinanceira().getVrSaldoDisponivel().subtract(diferencaVrApuradoVrEsperado);
    }

}
