/**
 * Copyright (c) 2018 Caixa Econômica Federal. Todos os direitos
 * reservados.
 *
 * Caixa Econômica Federal - SIACG
 *
 * Este software foi desenvolvido sob demanda da CAIXA e está
 * protegido por leis de direitos autorais e tratados internacionais. As
 * condições de cópia e utilização total ou partes dependem de autorização da
 * empresa. Cópias não são permitidas sem expressa autorização. Não pode ser
 * comercializado ou utilizado para propósitos particulares.
 *
 * Uso exclusivo da Caixa Econômica Federal. A reprodução ou distribuição não
 * autorizada deste programa ou de parte dele, resultará em punições civis e
 * criminais e os infratores incorrem em sanções previstas na legislação em
 * vigor.
 *
 * Histórico do TFS:
 *
 * LastChangedRevision: $Revision$
 * LastChangedBy: $Author$
 * LastChangedDate: $Date$
 *
 * HeadURL: $HeadURL$
 *
 */	
package br.gov.caixa.siacg.strategy.impl.titulo;

import br.gov.caixa.siacg.model.domain.Titulo;

/**
 * <p>ConjuntoTituloOutrosContratos</p>
 *
 * <p>Descrição: Classe que representa um conjunto de titulos de outros contratos</p>
 *
 * <br><b>Empresa:</b> Cef - Caixa Econômica Federal
 *
 *
 * @author p541915
 *
 * @version 1.0
*/
public class ConjuntoTituloOutrosContratos extends ConjuntoTitulo {
	
	/** Atributo nuContratoAtual. */
	private Integer nuContratoAtual;

	/**
	 * Responsável pela criação de novas instâncias desta classe.
	 *
	 * @param nuContratoAtual
	 *
	 */
	public ConjuntoTituloOutrosContratos(Integer nuContratoAtual) {
		this.nuContratoAtual = nuContratoAtual;
	}
	
	/**
	 * <p>Retorna o valor do atributo nuContratoAtual</p>.
	 *
	 * @return nuContratoAtual
	*/
	public Integer getNuContratoAtual() {
		return this.nuContratoAtual;
	}

	/**
	 * <p>Define o valor do atributo nuContratoAtual</p>.
	 *
	 * @param nuContratoAtual valor a ser atribuído
	*/
	public void setNuContratoAtual(Integer nuContratoAtual) {
		this.nuContratoAtual = nuContratoAtual;
	}
	
	/**
	 * @see br.gov.caixa.siacg.strategy.impl.titulo.ConjuntoTitulo#adicionarTitulo(br.gov.caixa.siacg.model.domain.Titulo)
	*/
	@Override
	public void adicionarTitulo(Titulo titulo) {
		if (titulo.getNuContrato() != null && !titulo.getNuContrato().equals(this.nuContratoAtual)) {
			super.adicionarTitulo(titulo);			
		}
	}
	
}
