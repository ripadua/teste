/**
 * Copyright (c) 2014 Caixa Econômica Federal. Todos os direitos
 * reservados.
 *
 * Caixa Econômica Federal - SIACG - Sistema de Crédito Rural
 *
 * Este software foi desenvolvido sob demanda da CAIXA e está
 * protegido por leis de direitos autorais e tratados internacionais. As
 * condições de cópia e utilização do todo ou partes dependem de autorização da
 * pessoa. Cópias não são permitidas sem expressa autorização. Não pode ser
 * comercializado ou utilizado para propósitos particulares.
 *
 * Uso exclusivo da Caixa Econômica Federal. A reprodução ou distribuição não
 * autorizada deste programa ou de parte dele, resultará em punições civis e
 * criminais e os infratores incorrem em sanções previstas na legislação em
 * vigor.
 *
 * Histórico do Subversion:
 *
 * LastChangedRevision: $Revision$
 * LastChangedBy: $Author$
 * LastChangedDate: $Date$
 *
 * HeadURL: $HeadURL$
 *
 */
package br.gov.caixa.siacg.view.form;

import java.util.ArrayList;
import java.util.List;

import javax.faces.model.SelectItem;

import org.apache.commons.collections.CollectionUtils;

import br.gov.caixa.pedesgo.arquitetura.visao.ManutencaoVisao;
import br.gov.caixa.siacg.model.domain.Empreendimento;

/**
 * <p>
 * AcompanhamentoEndividamentoVisao.
 * </p>
 * <p>
 * Descrição: Visão para o Acompanhamento de Endividamento
 * </p>
 * <br>
 * <b>Empresa:</b> Cef - Caixa Econômica Federal
 *
 * @author Caio Graco
 * @version 1.0
 */

public class AcompanhamentoControleGarantiasVisao extends ManutencaoVisao<Empreendimento> {

    /** Constante serialVersionUID. */
    private static final long serialVersionUID = 3725867756577803030L;

    /** Atributo nu unidade. */
    private String nomeEmpreendimento;


    /** Atributo quantidade registros. */
    private Integer quantidadeRegistros;
    
    private List<SelectItem> listaTipoParcela;
    
    private String tipoParcela;
    
	public String getNomeEmpreendimento() {
		return nomeEmpreendimento;
	}

	public void setNomeEmpreendimento(String nomeEmpreendimento) {
		this.nomeEmpreendimento = nomeEmpreendimento;
	}

	public Integer getQuantidadeRegistros() {
		return quantidadeRegistros;
	}

	public void setQuantidadeRegistros(Integer quantidadeRegistros) {
		this.quantidadeRegistros = quantidadeRegistros;
	}

	public List<SelectItem> getListaTipoParcela() {
		if(CollectionUtils.isEmpty(this.listaTipoParcela)) {
			this.listaTipoParcela = new ArrayList<>();
		}
		return listaTipoParcela;
	}

	public void setListaTipoParcela(List<SelectItem> listaTipoParcela) {
		this.listaTipoParcela = listaTipoParcela;
	}

	public String getTipoParcela() {
		return tipoParcela;
	}

	public void setTipoParcela(String tipoParcela) {
		this.tipoParcela = tipoParcela;
	}
	
	

	
	
}