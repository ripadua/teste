/*
 * Copyright (c) 2019 Caixa Econômica Federal. Todos os direitos
 * reservados.
 *
 * Caixa Econômica Federal - SIACG - Sistema de Crédito Rural
 *
 * Este software foi desenvolvido sob demanda da CAIXA e está
 * protegido por leis de direitos autorais e tratados internacionais. As
 * condições de cópia e utilização do todo ou partes dependem de autorização da
 * empresa. Cópias não são permitidas sem expressa autorização. Não pode ser
 * comercializado ou utilizado para propósitos particulares.
 *
 * Uso exclusivo da Caixa Econômica Federal. A reprodução ou distribuição não
 * autorizada deste programa ou de parte dele, resultará em punições civis e
 * criminais e os infratores incorrem em sanções previstas na legislação em
 * vigor.
 *
 * Histórico do TFS:
 *
 * LastChangedRevision: $Revision$
 * LastChangedBy: $Author$
 * LastChangedDate: $Date$
 *
 * HeadURL: $HeadURL$
 *
 */
package br.gov.caixa.siacg.view.mb;

import java.util.HashMap;

import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;
import javax.inject.Inject;

import org.primefaces.context.RequestContext;

import br.gov.caixa.pedesgo.arquitetura.controlador.ManutencaoBean;
import br.gov.caixa.pedesgo.arquitetura.util.UtilObjeto;
import br.gov.caixa.siacg.commons.AppConstant;
import br.gov.caixa.siacg.model.domain.Contrato;
import br.gov.caixa.siacg.model.domain.OperacaoSistema;
import br.gov.caixa.siacg.pagination.ContratoInativoLazyModel;
import br.gov.caixa.siacg.service.ContratoService;
import br.gov.caixa.siacg.service.OperacaoSistemaService;
import br.gov.caixa.siacg.view.form.ContratoVisao;

/**
 * <p>
 * BemClienteMB
 * </p>
 * <p>
 * Descrição: Managed bean do caso de uso de Reabertura de Contratos, conforme US 164265.
 * </p>
 * <br>
 * <b>Empresa:</b> Cef - Caixa Econômica Federal
 *
 * @author ludemeula.sa
 * @version 1.0
 */
@ManagedBean
@SessionScoped
public class ReaberturaContratoMB extends ManutencaoBean<Contrato> {

	private static final long serialVersionUID = 8006052854374337565L;
	
	private static final String PAGINA_CONSULTA = "/pages/manutencao/contrato/consulta.xhtml?faces-redirect=true";
	private static final String NOME_MANAGED_BEAN = "reaberturaContratoMB";
	private static final String MAPA_OPERACAO_SISTEMA = "mapaOperacaoSistema";

	@Inject
	private ContratoService service;
	
	@Inject
	private ContratoInativoLazyModel consulta;
	
	@Inject
	private OperacaoSistemaService operacaoSistemaService;
	
	private ContratoVisao visao;
	
	private String justificativa;

	public String abrir() {
		if (super.getHttpSession().getAttribute(MAPA_OPERACAO_SISTEMA) == null) {
			final HashMap<String, String> mapaOperacaoSistema = new HashMap<>();

			for (final OperacaoSistema operacaoSistema : operacaoSistemaService.listar()) {
				mapaOperacaoSistema.put(operacaoSistema.getNuOperacao(), operacaoSistema.getDeMascara());
			}

			super.getSession().setAttribute(MAPA_OPERACAO_SISTEMA, mapaOperacaoSistema);
		}
		
		visao = new ContratoVisao();
		
		getConsulta().limparFiltro();
		return PAGINA_CONSULTA;
	}

	public String pesquisar() {
		return PAGINA_CONSULTA;
	}

	public void salvar() {
		getService().reabrir(getVisao().getEntidade(), getJustificativa());
		if (!getVisao().getEntidade().hasMensagens()) {
			RequestContext.getCurrentInstance().execute("modalReabertura.hide();modalJustificativa.hide()");
			
			getConsulta().limparFiltro();
		} else {
			adicionaListaMensagemDeAlerta(getVisao().getEntidade().getMensagens());
		}
	}
	
	/*******************************************************************
	 * GETTERS && SETTERS
	 ******************************************************************/
	@Override
	protected String getNomeVarResourceBundle() {
		return AppConstant.RESOURCE_BUNDLE;
	}

	@Override
	protected String getPrefixoCasoDeUso() {
		return NOME_MANAGED_BEAN;
	}

	@SuppressWarnings("unchecked")
	@Override
	public ContratoService getService() {
		return this.service;
	}

	@Override
	public ContratoVisao getVisao() {
		if (!UtilObjeto.isReferencia(visao)) {
			this.visao = new ContratoVisao();
		}

		return visao;
	}
	
	/**
	 * Retorna o valor do atributo consulta.
	 *
	 * @return consulta
	 */
	public ContratoInativoLazyModel getConsulta() {
		if (this.consulta == null) {
			this.consulta = new ContratoInativoLazyModel();
		}

		return this.consulta;
	}

	/**
	 * Define o valor do atributo consulta.
	 *
	 * @param consulta
	 *            valor a ser atribuído
	 */
	public void setConsulta(final ContratoInativoLazyModel consulta) {
		this.consulta = consulta;
	}

	/**
	 * <p>Retorna o valor do atributo justificativa</p>.
	 *
	 * @return justificativa
	*/
	public String getJustificativa() {
		return this.justificativa;
	}

	/**
	 * <p>Define o valor do atributo justificativa</p>.
	 *
	 * @param justificativa valor a ser atribuído
	*/
	public void setJustificativa(String justificativa) {
		this.justificativa = justificativa;
	}
}