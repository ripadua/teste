/**
 * Copyright (c) 2015 Caixa Econômica Federal. Todos os direitos
 * reservados.
 *
 * Caixa Econômica Federal - SIACG - Sistema de Crédito Rural
 *
 * Este software foi desenvolvido sob demanda da CAIXA e está
 * protegido por leis de direitos autorais e tratados internacionais. As
 * condições de cópia e utilização do todo ou partes dependem de autorização da
 * pessoa. Cópias não são permitidas sem expressa autorização. Não pode ser
 * comercializado ou utilizado para propósitos particulares.
 *
 * Uso exclusivo da Caixa Econômica Federal. A reprodução ou distribuição não
 * autorizada deste programa ou de parte dele, resultará em punições civis e
 * criminais e os infratores incorrem em sanções previstas na legislação em
 * vigor.
 *
 * Histórico do Subversion:
 *
 * LastChangedRevision: $Revision$
 * LastChangedBy: $Author$
 * LastChangedDate: $Date$
 *
 * HeadURL: $HeadURL$
 *
 */
package br.gov.caixa.siacg.view.form;

import java.util.Collection;

import org.apache.commons.collections.CollectionUtils;

import br.gov.caixa.pedesgo.arquitetura.visao.ManutencaoVisao;
import br.gov.caixa.siacg.model.domain.Garantia;
import br.gov.caixa.siacg.model.domain.GrupoGarantia;

/**
 * <p>
 * GarantiaVisao
 * </p>
 * <p>
 * Descrição: Classe de visão para o Bean Gerenciado GarantiaMB.
 * </p>
 * <br>
 * <b>Empresa:</b> Cef - Caixa Econômica Federal
 *
 * @author Caio Graco
 * @version 1.0
 */
public class GarantiaVisao extends ManutencaoVisao<Garantia> {

    private static final long serialVersionUID = -7731966933957135497L;

    /** Atributo quantidadeItens. */
    private Integer quantidadeItens;

    /** Atributo listaGarantia. */
    private Collection<Garantia> listaGarantia;
    /** Atributo listaGrupoGarantia. */
    private Collection<GrupoGarantia> listaGrupoGarantia;

    /** Atributo garantiaParaExcluir. */
    private Garantia garantiaParaExcluir;
    
    /** Atributo isPossuiCedente. */
    private boolean isPossuiCedente;

    /**
     * Retorna o valor do atributo listaGarantia.
     *
     * @return listaGarantia
     */
    public Collection<Garantia> getListaGarantia() {

        return this.listaGarantia;
    }

    /**
     * Define o valor do atributo listaGarantia.
     *
     * @param listaGarantia
     *            valor a ser atribuído
     */
    public void setListaGarantia(final Collection<Garantia> listaGarantia) {

        this.listaGarantia = listaGarantia;
    }

    /**
     * Retorna o valor do atributo quantidadeItens.
     *
     * @return quantidadeItens
     */
    public Integer getQuantidadeItens() {
        if (CollectionUtils.isNotEmpty(this.listaGarantia)) {
            this.quantidadeItens = this.listaGarantia.size();
        } else {
            this.quantidadeItens = 0;
        }

        return this.quantidadeItens;
    }

    /**
     * Define o valor do atributo quantidadeItens.
     *
     * @param quantidadeItens
     *            valor a ser atribuído
     */
    public void setQuantidadeItens(final Integer quantidadeItens) {

        this.quantidadeItens = quantidadeItens;
    }

    /**
     * Retorna o valor do atributo listaGrupoGarantia.
     *
     * @return listaGrupoGarantia
     */
    public Collection<GrupoGarantia> getListaGrupoGarantia() {

        return this.listaGrupoGarantia;
    }

    /**
     * Define o valor do atributo listaGrupoGarantia.
     *
     * @param listaGrupoGarantia
     *            valor a ser atribuído
     */
    public void setListaGrupoGarantia(final Collection<GrupoGarantia> listaGrupoGarantia) {

        this.listaGrupoGarantia = listaGrupoGarantia;
    }

    /**
     * Retorna o valor do atributo garantiaParaExcluir.
     *
     * @return garantiaParaExcluir
     */
    public Garantia getGarantiaParaExcluir() {

        return this.garantiaParaExcluir;
    }

    /**
     * Define o valor do atributo garantiaParaExcluir.
     *
     * @param garantiaParaExcluir
     *            valor a ser atribuído
     */
    public void setGarantiaParaExcluir(final Garantia garantiaParaExcluir) {

        this.garantiaParaExcluir = garantiaParaExcluir;
    }

    /**
     * @see br.gov.caixa.pedesgo.arquitetura.visao.ManutencaoVisao#getEntidade()
     */
    @Override
    public Garantia getEntidade() {
        if (super.getEntidade() == null) {
            super.setEntidade(new Garantia());
            super.getEntidade().setGrupoGarantia(new GrupoGarantia());
        }
        return super.getEntidade();
    }
    
	/**
	 * <p>Retorna o valor do atributo isPossuiCedente</p>.
	 *
	 * @return isPossuiCedente
	*/
	public boolean isPossuiCedente() {
		return this.isPossuiCedente;
	}

	/**
	 * <p>Define o valor do atributo isPossuiCedente</p>.
	 *
	 * @param isPossuiCedente valor a ser atribuído
	 */
	public void setPossuiCedente(boolean isPossuiCedente) {
		this.isPossuiCedente = isPossuiCedente;}
}