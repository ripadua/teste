/**
 * Copyright (c) 2018 Caixa Econômica Federal. Todos os direitos
 * reservados.
 *
 * Caixa Econômica Federal - SIACG
 *
 * Este software foi desenvolvido sob demanda da CAIXA e está
 * protegido por leis de direitos autorais e tratados internacionais. As
 * condições de cópia e utilização total ou partes dependem de autorização da
 * empresa. Cópias não são permitidas sem expressa autorização. Não pode ser
 * comercializado ou utilizado para propósitos particulares.
 *
 * Uso exclusivo da Caixa Econômica Federal. A reprodução ou distribuição não
 * autorizada deste programa ou de parte dele, resultará em punições civis e
 * criminais e os infratores incorrem em sanções previstas na legislação em
 * vigor.
 *
 * Histórico do TFS:
 *
 * LastChangedRevision: $Revision$
 * LastChangedBy: $Author$
 * LastChangedDate: $Date$
 *
 * HeadURL: $HeadURL$
 *
 */
package br.gov.caixa.siacg.strategy.impl.titulo;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collection;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.List;

import org.apache.log4j.Logger;
import org.jboss.ejb3.annotation.TransactionTimeout;
import org.joda.time.DateTime;
import org.joda.time.Days;

import br.gov.caixa.siacg.comum.to.ContratoCalculoTO;
import br.gov.caixa.siacg.dao.SacadoExcepcionadoDAO;
import br.gov.caixa.siacg.dao.TituloDAO;
import br.gov.caixa.siacg.model.domain.AnaliseContrato;
import br.gov.caixa.siacg.model.domain.Titulo;
import br.gov.caixa.siacg.model.enums.CaracteristicaEnum;
import br.gov.caixa.siacg.model.enums.UtilizacaoTituloEnum;
import br.gov.caixa.siacg.model.vo.DadosEstatisticaCarteiraVO;

/**
 * <p>
 * TotalizadorAnaliseContrato
 * </p>
 *
 * <p>
 * Descrição: Classe que calcula e totaliza os valores dos titulos para serem
 * retornados na AnaliseContrato
 * </p>
 *
 * <br>
 * <b>Empresa:</b> Cef - Caixa Econômica Federal
 *
 *
 * @author p541915
 *
 * @version 1.0
 */
public class TotalizadorTituloAnaliseContrato {

    /** Atributo LOG. */
    private static final Logger LOG = Logger.getLogger(TotalizadorTituloAnaliseContrato.class);

    /** Atributo tituloDao. */
    private TituloDAO tituloDao;

    /** Atributo analiseContrato. */
    private AnaliseContrato analiseContrato;

    /** Atributo titulosOutrosContratos. */
    private ConjuntoTituloOutrosContratos titulosOutrosContratos;

    /** Atributo titulosLiquidados. */
    private ConjuntoTituloLiquidado titulosLiquidados;

    /** Atributo titulosProtestados. */
    private ConjuntoTituloProtestado titulosProtestados;

    /** Atributo titulosBaixados. */
    private ConjuntoTituloBaixado titulosBaixados;

    /** Atributo titulosVencidos. */
    private ConjuntoTituloVencido titulosVencidos;

    /** Atributo titulosAVencer. */
    private ConjuntoTituloAVencer titulosAVencer;

    /** Atributo titulosFluxo. */
    private ConjuntoTituloFluxo titulosFluxo;

    /** Atributo titulosIndiceLiquidez. */
    private ConjuntoTituloIndiceLiquidez titulosIndiceLiquidez;

    /** Atributo titulosComposicaoCarteira. */
    private ConjuntoTituloComposicaoCarteira titulosComposicaoCarteira;

    /** Atributo parametros. */
    private ParametrosCalculoTitulo parametros;

    /**
     * Responsável pela criação de novas instâncias desta classe.
     *
     * @param contrato
     * @param vrEsperado
     *
     */
    public TotalizadorTituloAnaliseContrato(final ParametrosCalculoTitulo parametros, final TituloDAO tituloDao,
	    final SacadoExcepcionadoDAO sacadoExcepcionadoDao) {
	this.parametros = parametros;
	this.analiseContrato = parametros.getRelatorio().getAnaliseContrato();
	this.tituloDao = tituloDao;
	this.titulosOutrosContratos = new ConjuntoTituloOutrosContratos(parametros.getContrato().getNuContrato());
	this.titulosLiquidados = new ConjuntoTituloLiquidado();
	this.titulosProtestados = new ConjuntoTituloProtestado();
	this.titulosBaixados = new ConjuntoTituloBaixado();
	this.titulosVencidos = new ConjuntoTituloVencido();
	this.titulosAVencer = new ConjuntoTituloAVencer(parametros, tituloDao, sacadoExcepcionadoDao);
	this.titulosFluxo = new ConjuntoTituloFluxo(parametros.getContrato(), parametros.getVrEsperado());
	this.titulosIndiceLiquidez = new ConjuntoTituloIndiceLiquidez();
	this.titulosComposicaoCarteira = new ConjuntoTituloComposicaoCarteira(parametros.getRelatorio().getDadosAnaliseFluxoVO(),
		parametros.getRelatorio().getDadosComposicaoCarteiraVO());
    }

    /**
     * <p>
     * Retorna o valor do atributo titulosOutrosContratos
     * </p>
     * .
     *
     * @return titulosOutrosContratos
     */
    public ConjuntoTituloOutrosContratos getTitulosOutrosContratos() {
	return this.titulosOutrosContratos;
    }

    /**
     * <p>
     * Retorna o valor do atributo titulosLiquidados
     * </p>
     * .
     *
     * @return titulosLiquidados
     */
    public ConjuntoTituloLiquidado getTitulosLiquidados() {
	return this.titulosLiquidados;
    }

    /**
     * <p>
     * Retorna o valor do atributo titulosProtestados
     * </p>
     * .
     *
     * @return titulosProtestados
     */
    public ConjuntoTituloProtestado getTitulosProtestados() {
	return this.titulosProtestados;
    }

    /**
     * <p>
     * Retorna o valor do atributo titulosBaixados
     * </p>
     * .
     *
     * @return titulosBaixados
     */
    public ConjuntoTituloBaixado getTitulosBaixados() {
	return this.titulosBaixados;
    }

    /**
     * <p>
     * Retorna o valor do atributo titulosVencidos
     * </p>
     * .
     *
     * @return titulosVencidos
     */
    public ConjuntoTituloVencido getTitulosVencidos() {
	return this.titulosVencidos;
    }

    /**
     * <p>
     * Retorna o valor do atributo titulosAVencer
     * </p>
     * .
     *
     * @return titulosAVencer
     */
    public ConjuntoTituloAVencer getTitulosAVencer() {
	return this.titulosAVencer;
    }

    /**
     * <p>
     * Retorna o valor do atributo titulosFluxo
     * </p>
     * .
     *
     * @return titulosFluxo
     */
    public ConjuntoTituloFluxo getTitulosFluxo() {
	return this.titulosFluxo;
    }

    /**
     * <p>
     * Retorna o valor do atributo titulosIndiceLiquidez
     * </p>
     * .
     *
     * @return titulosIndiceLiquidez
     */
    public ConjuntoTituloIndiceLiquidez getTitulosIndiceLiquidez() {
	return this.titulosIndiceLiquidez;
    }

    /**
     * <p>
     * Retorna o valor do atributo titulosComposicaoCarteira
     * </p>
     * .
     *
     * @return titulosComposicaoCarteira
     */
    public ConjuntoTituloComposicaoCarteira getTitulosComposicaoCarteira() {
	return this.titulosComposicaoCarteira;
    }

    /**
     * <p>
     * Retorna o valor do atributo parametros
     * </p>
     * .
     *
     * @return parametros
     */
    public ParametrosCalculoTitulo getParametros() {
	return this.parametros;
    }

    /**
     * <p>
     * Método responsável por adicionar um titulo no totalizador
     * </p>
     * .
     *
     * @author p541915
     *
     * @param titulo
     */
    public void adicionarTitulo(Titulo titulo) {
	ConjuntoTituloFabrica.identificarConjuntoTitulo(this, titulo);

	this.popularDadosEstatisticaCarteira(titulo);

	// Setando atributos que não serão mais utilizados para liberar memória
	titulo.setNuCanalRecebedor(null);
	titulo.setDtLiquidacao(null);
    }

    /**
     * <p>
     * Método responsável por popular os dados para calculo das estatisticas da
     * carteira
     * </p>
     * .
     *
     * @author p541915
     *
     * @param titulo
     */
    private void popularDadosEstatisticaCarteira(Titulo titulo) {
	DadosEstatisticaCarteiraVO dadosEstatistica = this.parametros.getRelatorio().getDadosEstatisticaCarteiraVO();

	dadosEstatistica.incrementaQtdTitulosCarteira();

	final GregorianCalendar dataProcessamento = new GregorianCalendar();
	// O calculo deve iniciar do dia anterior
	dataProcessamento.add(Calendar.DAY_OF_MONTH, -1);

	BigDecimal diferencaDias = BigDecimal.valueOf(this.obterDiferencaDeDias(dataProcessamento.getTime(), titulo.getDtVencimentoTitulo()));

	if (diferencaDias.compareTo(BigDecimal.ZERO) < 0) {
	    diferencaDias = diferencaDias.multiply(BigDecimal.valueOf(-1));
	}

	// Adiciona um nadiferença de dias, pois a diferença não considera a
	// data final
	diferencaDias = diferencaDias.add(BigDecimal.ONE);

	dadosEstatistica.addPrazoMedio(diferencaDias);
	dadosEstatistica.addPrazoMedioPonderado(titulo.getVrTitulo().multiply(diferencaDias));
	dadosEstatistica.addValorMedio(titulo.getVrTitulo());

	if (titulo.getVrTitulo().compareTo(dadosEstatistica.getValorMinimo()) < 0) {
	    dadosEstatistica.setValorMinimo(titulo.getVrTitulo());
	}

	if (titulo.getVrTitulo().compareTo(dadosEstatistica.getValorMaximo()) > 0) {
	    dadosEstatistica.setValorMaximo(titulo.getVrTitulo());
	}
    }

    /**
     * Obtem a diferença de dias entre as datas.
     *
     * @param dataInicio
     *            valor a ser atribuido
     * @param dataFim
     *            valor a ser atribuido
     * @return long
     * @author Ricardo Crispim
     */
    private long obterDiferencaDeDias(final Date dataInicio, final Date dataFim) {
	final DateTime dadaInicial = new DateTime(dataInicio);
	final DateTime dataFinal = new DateTime(dataFim);
	return Days.daysBetween(dadaInicial, dataFinal).getDays();
    }

    /**
     * <p>
     * Método responsável por
     * </p>
     * .
     *
     * @author p541915
     *
     * @param listaTitulos
     */
    public void adicionarTitulos(Collection<Titulo> listaTitulos) {
	for (Titulo titulo : listaTitulos) {
	    adicionarTitulo(titulo);
	}
    }

    /**
     * <p>
     * Método responsável por realizar o calculo e popular o objeto de
     * AnaliseContrato
     * </p>
     * .
     *
     * @author p541915
     *
     * @return AnaliseContrato
     */
    public AnaliseContrato calcularAnaliseContrato() {

	this.titulosFluxo.calcular();
	this.titulosAVencer.calcular();

	if (CaracteristicaEnum.FLUXO.equals(this.parametros.getGarantiaContrato().getIcCaracteristica())) {
	    if (this.titulosFluxo.getQtdConjunto() == 0) {
		LOG.info("Garantia do contrato: " + CaracteristicaEnum.FLUXO.name() + " - Lista de duplicatas fluxo nula ou vazia");
	    }

	    // Salva todos os titulos validos da carteira com a marcacao do
	    // contrato
	    this.salvarTitulos(this.titulosFluxo.getListaTituloASalvar(), this.parametros.getContrato(), UtilizacaoTituloEnum.GN);

	    // Guarda o valor consumido pela garantia do contrato
	    this.parametros.getRelatorio().setValorApurado(this.titulosFluxo.getTotalValorApurado());

	    // Resumo da Carteira
	    analiseContrato.setVrTotalDuplicataFluxo(this.titulosFluxo.getVrTotal());
	    analiseContrato.setVrLimiteDuplicataValorMaximoFluxo(this.parametros.getValorMaximo());
	    analiseContrato.setVrDuplicataNaoPagaFluxo(this.titulosFluxo.getTotalDuplicatasNaoPagas());
	    analiseContrato.setVrItemForaParametroFluxo(this.titulosFluxo.getValorItensForaParametros());
	    analiseContrato.setVrDuplicataFluxoOutrosContratos(this.titulosFluxo.getTotalValorOutrosContratos());

	} else if (CaracteristicaEnum.ESTOQUE.equals(this.parametros.getGarantiaContrato().getIcCaracteristica())) {

	    // Salva todos os titulos validos da carteira com a marcacao do
	    // contrato
	    this.salvarTitulos(this.titulosAVencer.getListaTituloASalvar(), this.parametros.getContrato(), UtilizacaoTituloEnum.GN);

	    // Remove marcação de consumo dos titulos
	    this.limparConsumoTitulos(this.titulosAVencer.getListaTituloForaParametros(), this.parametros.getContrato().getNuContrato());

	    // Totalizadores

	    analiseContrato.setVrDplcsInadimplenteProtestadas(this.titulosProtestados.getVrTotal());
	    analiseContrato.setVrDplcsInadimplenteBaixadas(this.titulosBaixados.getVrTotal());
	    analiseContrato.setVrDplcsInadimplenteVencidas(this.titulosVencidos.getVrTotal());

	    // Resumo da carteira
	    analiseContrato.setVrTotalDuplicatasCarteira(this.getVrTotalTitulo());
	    analiseContrato.setVrDplcsProtestadas(this.titulosProtestados.getVrTotal());
	    analiseContrato.setVrDplcsBaixadas(this.titulosBaixados.getVrTotal());
	    analiseContrato.setVrDplcsVencidas(this.titulosVencidos.getVrTotal());
	    analiseContrato.setVrLiquidoCarteira(titulosAVencer.getVrLiquidoCarteira());
	    analiseContrato.setVrPagoCaixa(this.titulosLiquidados.getVrPagoCaixa());
	    analiseContrato.setVrPagoCompensacao(this.titulosLiquidados.getVrPagoCompensacao());
	    analiseContrato.setVrPagoResumoCarteira(this.titulosLiquidados.getVrPagoCaixa().add(this.titulosLiquidados.getVrPagoCompensacao()));
	    analiseContrato.setVrItensForaParametro(this.titulosAVencer.getVrTituloForaParametros());
	    analiseContrato.setVrDuplicataEstoqueOutrosContratos(this.titulosOutrosContratos.getVrTotal());

	    // Itens fora do parametro
	    analiseContrato.setVrDplcsForaPrazoMaximo(this.titulosAVencer.getVrTituloForaPrazoMaximoPermitido());
	    analiseContrato.setVrDplcsForaValorMaximo(this.titulosAVencer.getVrTituloForaValorMaximoPermitido());
	    analiseContrato.setVrDplcsForaValorPrcnlMax(this.titulosAVencer.getVrTituloForaPercentualMaximoConcentracao());
	    analiseContrato.setVrTituloSacadoNaoAceito(this.titulosAVencer.getVrTituloSacadoNaoAceito());
	    analiseContrato.setVrDuplicataPrazoMaximoPermitido(this.parametros.getPrazoMaximo());
	    analiseContrato.setVrDuplicataValorMaximoPermitido(this.parametros.getValorMaximo());
	    analiseContrato.setVrDuplicataPercentualMaximoPermitido(this.parametros.getPercentualMaximo());

	    analiseContrato.setQtDplcsProtestadas(this.titulosProtestados.getQtdConjunto().intValue());
	    analiseContrato.setQtdPlcsBaixadas(this.titulosBaixados.getQtdConjunto().intValue());
	    analiseContrato.setQtDplcsVencidas(this.titulosVencidos.getQtdConjunto().intValue());
	    analiseContrato.setQuantidadeDuplicataForaPrazoPermitido(this.titulosAVencer.getQtdTituloForaPrazoMaximoPermitido());
	    analiseContrato.setQuantidadeDuplicataForaValorMaximoPermitido(this.titulosAVencer.getQtdTituloForaValorMaximoPermitido());
	    analiseContrato
		    .setQuantidadeDuplicataForaPercentualMaximoConcentracaoValor(this.titulosAVencer.getQtdTituloForaPercentualMaximoConcentracao());
	    analiseContrato.setQtTituloSacadoNaoAceito(this.titulosAVencer.getQtdTituloSacadoNaoAceito());
	}

	// Calcula o indice de liquidez
	analiseContrato.setPercentualIndiceLiquidez(this.titulosIndiceLiquidez.calcularIndiceLiquidez());

	return this.analiseContrato;
    }

    /**
     * <p>
     * Método responsável por salvar lista de titulos.
     * <p>
     *
     * @param listaTituloASalvar
     *            valor a ser atribuido
     * @param contrato
     *            valor a ser atribuido
     * @param icUtilizacaoEnum
     *            valor a ser atribuido
     * @author guilherme.santos
     * @param contrato
     */
    @TransactionTimeout(7200)
    private void salvarTitulos(final Collection<Titulo> listaTituloASalvar, final ContratoCalculoTO contrato, final UtilizacaoTituloEnum icUtilizacaoEnum) {
	if (!listaTituloASalvar.isEmpty()) {
	    final List<Integer> listaNuTitulos = new ArrayList<>();

	    for (final Titulo titulo : listaTituloASalvar) {
		listaNuTitulos.add(titulo.getNuTitulo());
	    }

	    if (!contrato.isPreAnalise()) {
		this.tituloDao.salvarContratoNaListaTitulo(listaNuTitulos, contrato, icUtilizacaoEnum);
	    }
	}
    }

    /**
     * <p>
     * Método responsável por limpar o consumo dos titulos informados que
     * pertença ao contrato.
     * <p>
     *
     * @param listaTitulo
     *            valor a ser atribuido
     * @param nuContrato
     *            valor a ser atribuido
     * @author guilherme.santos
     */
    private void limparConsumoTitulos(final Collection<Titulo> listaTitulo, final Integer nuContrato) {
	final List<Integer> listaTitulosComConsumo = new ArrayList<>();

	for (final Titulo titulo : listaTitulo) {
	    if (titulo.getNuContrato() != null && titulo.getNuContrato().equals(nuContrato)) {
		listaTitulosComConsumo.add(titulo.getNuTitulo());
	    }
	}

	if (!listaTitulosComConsumo.isEmpty()) {
	    this.tituloDao.removerConsumo(listaTitulosComConsumo);
	}
    }

    /**
     * <p>
     * Método responsável por obter o valor total dos titulos
     * </p>
     * .
     *
     * @author p541915
     *
     * @return valor total titulo
     */
    private BigDecimal getVrTotalTitulo() {
	return titulosOutrosContratos.getVrTotal().add(titulosLiquidados.getVrTotal()).add(titulosProtestados.getVrTotal())
		.add(titulosBaixados.getVrTotal()).add(titulosVencidos.getVrTotal()).add(titulosAVencer.getVrTotal());
    }

    /**
     * <p>
     * Método responsável por somar os valores totalizados do totalizador do
     * parametro com o totalizador atual
     * </p>
     * .
     *
     * @author p541915
     *
     * @param totalizador
     */
    public void somarTotalizador(TotalizadorTituloAnaliseContrato totalizador) {
	this.titulosFluxo.somarConjunto(totalizador.titulosFluxo);
	this.titulosAVencer.somarConjunto(totalizador.titulosAVencer);
	this.titulosProtestados.somarConjunto(totalizador.titulosProtestados);
	this.titulosBaixados.somarConjunto(totalizador.titulosBaixados);
	this.titulosVencidos.somarConjunto(totalizador.titulosVencidos);
	this.titulosOutrosContratos.somarConjunto(totalizador.titulosOutrosContratos);
	this.titulosLiquidados.somarConjunto(totalizador.titulosLiquidados);
	this.titulosIndiceLiquidez.somarConjunto(totalizador.titulosIndiceLiquidez);
	this.titulosComposicaoCarteira.somarConjunto(totalizador.titulosComposicaoCarteira);
    }

    /**
     * @see java.lang.Object#toString()
     */
    @Override
    public String toString() {
	return "TotalizadorTituloAnaliseContrato [" + "\ntitulosOutrosContratos=" + titulosOutrosContratos + "\n titulosLiquidados="
		+ titulosLiquidados + "\n titulosProtestados=" + titulosProtestados + "\n titulosBaixados=" + titulosBaixados + "\n titulosVencidos="
		+ titulosVencidos + "\n titulosAVencer=" + titulosAVencer + "\n titulosFluxo=" + titulosFluxo + "\n titulosIndiceLiquidez="
		+ titulosIndiceLiquidez + "\n titulosComposicaoCarteira=" + titulosComposicaoCarteira + "]";
    }

}
