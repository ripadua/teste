package br.gov.caixa.siacg.thread;

import java.util.concurrent.ForkJoinPool;
import java.util.concurrent.RecursiveTask;

import br.gov.caixa.siacg.comum.to.sicli.RespostaSicliTO;
import br.gov.caixa.siacg.jms.SolicitaDadosClienteSicli;

/**
 * <p>
 * AtualizaFaturamentoThread.
 * </p>
 * <p>
 * Descrição: Classe responsável por gerenciar o pool de thread.
 * </p>
 * <br>
 * <b>Empresa:</b> Cef - Caixa Econômica Federal
 *
 * @author guilherme.santos
 * @version 1.0
 */
public class AtualizaFaturamentoThread {

    /**
     * Construtor.
     *
     */
    private AtualizaFaturamentoThread() {
    }
    
    /**
     * <p>
     * AtualizaFaturamentoThreadImplementacao.
     * </p>
     * <p>
     * Descrição: Classe responsável por implementar a tarefa do pool de thread
     * do {@link ForkJoinPool}.
     * </p>
     * <br>
     * <b>Empresa:</b> Cef - Caixa Econômica Federal
     *
     * @author guilherme.santos
     * @version 1.0
     */
    private static class AtualizaFaturamentoThreadImplementacao extends RecursiveTask<RespostaSicliTO> {

	/** Atributo serialVersionUID. */
	private static final long serialVersionUID = -196522408291343951L;
	/** Atributo cnpj. */
	private final transient String cnpj;
	/** Atributo solicitaDadosClienteSicli. */
	private final transient SolicitaDadosClienteSicli solicitaDadosClienteSicli;
	private final transient String tokenSso;

	/**
	 * Construtor.
	 *
	 * @param paramSolicitaDadosClienteSicli
	 *            - {@link SolicitaDadosClienteSicli}.
	 * @param paramCnpj
	 *            - cnpj a ser consultado no SECLI.
	 */
	public AtualizaFaturamentoThreadImplementacao(final SolicitaDadosClienteSicli paramSolicitaDadosClienteSicli, final String paramCnpj,
		final String tokenSso) {
	    super();
	    this.cnpj = paramCnpj;
	    this.solicitaDadosClienteSicli = paramSolicitaDadosClienteSicli;
	    this.tokenSso = tokenSso;
	}

	/**
	 * Implementação do metodo responsável por conter a execução da thread.
	 * 
	 * @return BigDecimal - valor do faturamento atualizado.
	 */
	@Override
	protected RespostaSicliTO compute() {
	    return this.solicitaDadosClienteSicli.consultarFaturamentoAnualClienteSicli(this.cnpj, this.tokenSso);
	}
    }

    /**
     * <p>
     * Método responsável por criar o pool de thread.
     * </p>
     *
     * @param solicitaDadosClienteSicli
     *            - {@link SolicitaDadosClienteSicli}.
     * @param parametroCnpj
     *            - cnpj da pessoa a ser consultada.
     * @return BigDecimal - valor do faturamento consultado no SECLI.
     * @author guilherme.santos
     */
    public static RespostaSicliTO atualizarFaturamento(final SolicitaDadosClienteSicli solicitaDadosClienteSicli, final String parametroCnpj,
	    final String tokenSso) {
	final ForkJoinPool pool = new ForkJoinPool();
	try {
	    return pool.invoke(new AtualizaFaturamentoThreadImplementacao(solicitaDadosClienteSicli, parametroCnpj, tokenSso));
	} finally {
	    pool.shutdown();
	}
    }
}
