/*
 * Copyright (c) 2016 Caixa Econômica Federal. Todos os direitos
 * reservados.
 *
 * Caixa Econômica Federal - SIACG_dev
 *
 * Este software foi desenvolvido sob demanda da CAIXA e está
 * protegido por leis de direitos autorais e tratados internacionais. As
 * condições de cópia e utilização do total ou partes dependem de autorização da
 * pessoa. Cópias não são permitidas sem expressa autorização. Não pode ser
 * comercializado ou utilizado para propósitos particulares.
 *
 * Uso exclusivo da Caixa Econômica Federal. A reprodução ou distribuição não
 * autorizada deste programa ou de parte dele, resultará em punições civis e
 * criminais e os infratores incorrem em sanções previstas na legislação em
 * vigor.
 *
 * Histórico do Subversion:
 *
 * LastChangedRevision: $Revision$
 * LastChangedBy: $Author$
 * LastChangedDate: $Date$
 *
 * HeadURL: $HeadURL$
 *
 */
package br.gov.caixa.siacg.comum.to;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * <p>
 * NegocialSifixTO.
 * </p>
 * <p>
 * Descrição: TO para representar a propriedade de retorno Negocial do sistema Sifix.
 * </p>
 * <br>
 * <b>Empresa:</b> Cef - Caixa Econômica Federal
 *
 * @author Leandro Severino
 * @version 1.0
 */
@JsonIgnoreProperties(ignoreUnknown = true)
public class NegocialSifixTO {
	/** origem. */
	@JsonProperty(value="origem")
	private String origem;

    /** codigo. */
	@JsonProperty(value="codigo_retorno")
	private Integer codigoRetorno;

    /** mensagem. */
	@JsonProperty(value="mensagem")
    private String mensagem;


    /**
     * Construtor.
     *
     */
    public NegocialSifixTO() {
    	super();
    }

    /**
     * Construtor.
     *
     * @param codigo
     *            valor a ser atribuido
     * @param mensagem
     *            valor a ser atribuido
     * @param origem
     *            valor a ser atribuido 
     */
    public NegocialSifixTO(final String origem, final Integer codigo, final String mensagem) {
    	this();
    	this.origem = origem;
        this.codigoRetorno = codigo;
        this.mensagem = mensagem;
    }

    /**
     * Retorna o valor do atributo mensagem.
     *
     * @return mensagem
     */
	public String getMensagem() {
		return mensagem;
	}

	/**
     * Define o valor do atributo mensagem.
     *
     * @param mensagem
     *            valor a ser atribuído
     */
	public void setMensagem(String mensagem) {
		this.mensagem = mensagem;
	}

	/**
     * Retorna o valor do atributo origem.
     *
     * @return origem
     */
	public String getOrigem() {
		return origem;
	}

	/**
     * Define o valor do atributo origem.
     *
     * @param origem
     *            valor a ser atribuído
     */
	public void setOrigem(String origem) {
		this.origem = origem;
	}

	/**
	 * <p>Retorna o valor do atributo codigoRetorno</p>.
	 *
	 * @return codigoRetorno
	*/
	public Integer getCodigoRetorno() {
		return this.codigoRetorno;
	}

	/**
	 * <p>Define o valor do atributo codigoRetorno</p>.
	 *
	 * @param codigoRetorno valor a ser atribuído
	*/
	public void setCodigoRetorno(Integer codigoRetorno) {
		this.codigoRetorno = codigoRetorno;
	}
}