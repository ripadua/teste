/*
 * Copyright (c) 2016 Caixa Econômica Federal. Todos os direitos
 * reservados.
 *
 * Caixa Econômica Federal - SIACG – Sistema de Acompanhamento de Carteiras de Cobrança
 *
 * Este programa de computador foi desenvolvido sob demanda da CAIXA e está protegido por leis de direitos autorais e
 * tratados internacionais. As condições de cópia e utilização do todo ou partes dependem de autorização da pessoa.
 * Cópias não são permitidas sem expressa autorização. Não pode ser comercializado ou utilizado para propósitos
 * particulares.
 *
 * Uso exclusivo da Caixa Econômica Federal. A reprodução ou distribuição não autorizada deste programa ou de parte
 * dele, resultará em punições civis e criminais e os infratores incorrem em sanções previstas na legislação em vigor.
 *
 * Histórico do Subversion:
 *
 * LastChangedRevision: LastChangedBy: LastChangedDate:
 *
 * HeadURL:
 *
 */
package br.gov.caixa.siacg.view.mb;

import java.math.BigDecimal;
import java.text.NumberFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.EnumSet;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.logging.Logger;

import javax.annotation.PostConstruct;
import javax.ejb.EJB;
import javax.ejb.ObjectNotFoundException;
import javax.enterprise.context.SessionScoped;
import javax.faces.bean.ManagedProperty;
import javax.faces.context.FacesContext;
import javax.faces.event.ActionEvent;
import javax.inject.Inject;
import javax.inject.Named;
import javax.servlet.http.HttpServletRequest;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang.NotImplementedException;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang3.SerializationUtils;
import org.apache.commons.lang3.math.NumberUtils;
import org.primefaces.component.datatable.DataTable;
import org.primefaces.component.tabview.TabView;
import org.primefaces.context.RequestContext;
import org.primefaces.event.RowEditEvent;
import org.primefaces.event.SelectEvent;
import org.primefaces.event.TabChangeEvent;
import org.primefaces.event.UnselectEvent;
import org.primefaces.model.DefaultTreeNode;
import org.primefaces.model.TreeNode;

import br.gov.caixa.pedesgo.arquitetura.controlador.ManutencaoBean;
import br.gov.caixa.pedesgo.arquitetura.enumerador.EnumAcao;
import br.gov.caixa.pedesgo.arquitetura.enums.EnumExtensaoArquivo;
import br.gov.caixa.pedesgo.arquitetura.relatorio.UtilRelatorio;
import br.gov.caixa.pedesgo.arquitetura.to.MensagemTO;
import br.gov.caixa.pedesgo.arquitetura.util.LogCefUtil;
import br.gov.caixa.pedesgo.arquitetura.util.MensagensUtil;
import br.gov.caixa.pedesgo.arquitetura.util.UsuarioUtil;
import br.gov.caixa.pedesgo.arquitetura.util.UtilCnpj;
import br.gov.caixa.pedesgo.arquitetura.util.UtilFormatacao;
import br.gov.caixa.pedesgo.arquitetura.util.UtilObjeto;
import br.gov.caixa.pedesgo.arquitetura.util.UtilString;
import br.gov.caixa.pedesgo.keycloak.services.CaixaKeycloakService;
import br.gov.caixa.pedesgo.keycloak.services.vo.GenericVO;
import br.gov.caixa.siacg.commons.AppConstant;
import br.gov.caixa.siacg.commons.MsgConstant;
import br.gov.caixa.siacg.comparator.DataProspectoComparator;
import br.gov.caixa.siacg.comum.to.sicli.RespostaSicliTO;
import br.gov.caixa.siacg.exception.ParametrosInvalidosException;
import br.gov.caixa.siacg.interceptador.Auditoria;
import br.gov.caixa.siacg.interceptador.OperacaoAuditoria;
import br.gov.caixa.siacg.model.domain.AplicacaoFinanceira;
import br.gov.caixa.siacg.model.domain.BandeiraCartao;
import br.gov.caixa.siacg.model.domain.BemCliente;
import br.gov.caixa.siacg.model.domain.Cedente;
import br.gov.caixa.siacg.model.domain.ChequeExcepcionado;
import br.gov.caixa.siacg.model.domain.ContaContrato;
import br.gov.caixa.siacg.model.domain.ContaCorrente;
import br.gov.caixa.siacg.model.domain.ContaCorrenteID;
import br.gov.caixa.siacg.model.domain.Contrato;
import br.gov.caixa.siacg.model.domain.DuplicataExcepcionada;
import br.gov.caixa.siacg.model.domain.Empreendimento;
import br.gov.caixa.siacg.model.domain.Garantia;
import br.gov.caixa.siacg.model.domain.GarantiaAplicacao;
import br.gov.caixa.siacg.model.domain.GarantiaAplicacaoID;
import br.gov.caixa.siacg.model.domain.GarantiaBemCliente;
import br.gov.caixa.siacg.model.domain.GarantiaCartaoCredito;
import br.gov.caixa.siacg.model.domain.GarantiaContrato;
import br.gov.caixa.siacg.model.domain.GrupoGarantia;
import br.gov.caixa.siacg.model.domain.ParametroComercializacao;
import br.gov.caixa.siacg.model.domain.Pessoa;
import br.gov.caixa.siacg.model.domain.ProdutoAgricola;
import br.gov.caixa.siacg.model.domain.ProponenteHabitacional;
import br.gov.caixa.siacg.model.domain.Propriedade;
import br.gov.caixa.siacg.model.domain.Prospecto;
import br.gov.caixa.siacg.model.domain.ProspectoTipoParcela;
import br.gov.caixa.siacg.model.domain.Recebido;
import br.gov.caixa.siacg.model.domain.SacadoExcepcionado;
import br.gov.caixa.siacg.model.domain.Tipologia;
import br.gov.caixa.siacg.model.domain.UnidadeHabitacional;
import br.gov.caixa.siacg.model.domain.UnidadeHabitacionalComercializacao;
import br.gov.caixa.siacg.model.enums.CaracteristicaEnum;
import br.gov.caixa.siacg.model.enums.ContaCorrenteEnum;
import br.gov.caixa.siacg.model.enums.ContaEnum;
import br.gov.caixa.siacg.model.enums.FormaGarantiaEnum;
import br.gov.caixa.siacg.model.enums.GrupoGarantiaEnum;
import br.gov.caixa.siacg.model.enums.NoFuncionalidadeEnum;
import br.gov.caixa.siacg.model.enums.OrigemParametrizacaoEnum;
import br.gov.caixa.siacg.model.enums.ParametroCalculoEnum;
import br.gov.caixa.siacg.model.enums.TipoEndividamentoEnum;
import br.gov.caixa.siacg.model.enums.TipoMovimentacaoEnum;
import br.gov.caixa.siacg.model.enums.TipoOrigemContaContratoEnum;
import br.gov.caixa.siacg.model.enums.TipoPessoaEnum;
import br.gov.caixa.siacg.model.enums.TipoPlanoPagamentoEnum;
import br.gov.caixa.siacg.model.json.saldows.RetornoAplicacaoSifix;
import br.gov.caixa.siacg.model.vo.ChequeExcepcionadoVO;
import br.gov.caixa.siacg.model.vo.ContaCorrenteBandeirasVO;
import br.gov.caixa.siacg.model.vo.DuplicataVO;
import br.gov.caixa.siacg.model.vo.ParametrizacaoContratoVO;
import br.gov.caixa.siacg.model.vo.SacadoExcepcionadoVO;
import br.gov.caixa.siacg.model.vo.UnidadeVO;
import br.gov.caixa.siacg.pagination.UnidadeHabitacionalLazyModel;
import br.gov.caixa.siacg.service.AnaliseContratoService;
import br.gov.caixa.siacg.service.AplicacaoFinanceiraService;
import br.gov.caixa.siacg.service.BandeiraCartaoService;
import br.gov.caixa.siacg.service.BemClienteService;
import br.gov.caixa.siacg.service.ContratoService;
import br.gov.caixa.siacg.service.EmpreendimentoService;
import br.gov.caixa.siacg.service.GarantiaBemClienteService;
import br.gov.caixa.siacg.service.ParametrizacaoContratoService;
import br.gov.caixa.siacg.service.ParametroComercializacaoService;
import br.gov.caixa.siacg.service.ParametroProdutoService;
import br.gov.caixa.siacg.service.PessoaService;
import br.gov.caixa.siacg.service.ProponenteHabitacionalService;
import br.gov.caixa.siacg.service.PropriedadeService;
import br.gov.caixa.siacg.service.ProspectoService;
import br.gov.caixa.siacg.service.ProspectoTipoParcelaService;
import br.gov.caixa.siacg.service.RecebidoService;
import br.gov.caixa.siacg.service.TipologiaService;
import br.gov.caixa.siacg.service.UnidadeHabitacionalComercializacaoService;
import br.gov.caixa.siacg.service.UnidadeHabitacionalHistoricoService;
import br.gov.caixa.siacg.service.UnidadeHabitacionalService;
import br.gov.caixa.siacg.service.UnidadeVinculadaSuatService;
import br.gov.caixa.siacg.service.impl.ParametrizacaoContratoServiceImpl;
import br.gov.caixa.siacg.strategy.FabricaCalculoGarantia;
import br.gov.caixa.siacg.util.ContratoUtil;
import br.gov.caixa.siacg.util.LogCEF;
import br.gov.caixa.siacg.view.form.ParametrizacaoContratoVisao;
import br.gov.caixa.siacg.view.form.ParametroProdutoVisao;

/**
 * <p>
 * ParametrizacaoContratoMB
 * </p>
 * <p>
 * Descrição: Managed bean do caso de uso <code>Parametrização do
 * contrato</code>.
 * </p>
 * <br>
 * <b>Empresa:</b> Cef - Caixa Econômica Federal
 *
 * @author joseroberto@gsgroup.com.br
 * @version 1.0
 */
@Named
@SessionScoped
public class ParametrizacaoContratoMB extends ManutencaoBean<GarantiaContrato> {

    private static final String PF = "PF";

	private static final long serialVersionUID = 509553705294132803L;

	private static final String UNIDADE = "unidade";
	
	private static final String PF_MODAL_SUCESSO_SHOW = "PF('modalSucesso').show();";

	private static final String MSG_CONTA_CORRENTE_INVALIDA = "MN011";

	private static final String MSG_CONTA_CORRENTE_JA_INSERIDA = "MN012";

	private static final String MSG_CHEQUE_JA_INSERIDO = "MN020";

	private static final String MSG_VALOR_GARANTIA_EXCEDE_VALOR_PERMITIDO_PARA_GARANTIAS_EXCEPCIONADAS = "MN019";

	/** Atributo NOME_MANAGED_BEAN. */
	public static final String NOME_MANAGED_BEAN = "parametrizacaoContratoMB";

	/** Atributo EL_MANAGED_BEAN. */
	public static final String EL_MANAGED_BEAN = "#{parametrizacaoContratoMB}";

	/** Atributo PAGINA_PARAMETRIZACAO_CONTRATO. */
	private static final String PAGINA_PARAMETRIZACAO_CONTRATO = "/pages/parametrizacao-contrato/parametrizacao.xhtml?faces-redirect=true";

	/** Atributo PAGINA_CONSULTA_PARAMETROS. */
	private static final String PAGINA_CONSULTA_PARAMETROS = "/pages/manutencao/parametros.xhtml?faces-redirect=true";

	/** Atributo CAMPO_OBRIGATORIO. */
	public static final String CAMPO_OBRIGATORIO = "MA005";

	/** Atributo DUPLICATAS_ADICIONADAS_MESMO_TIPO. */
	public static final String DUPLICATAS_ADICIONADAS_MESMO_TIPO = "MN003";

	/** Atributo OPERACAO_REALIZADA_SUCESSO. */
	public static final String OPERACAO_REALIZADA_SUCESSO = "MA002";

	/** Atributo OPERACAO_REALIZADA_ERRO. */
	public static final String OPERACAO_REALIZADA_ERRO = "MA012";
	public static final String ERRO_ATUALIAZACAO_VALOR_FATURAMENTO = "MN051";
	
	private static final Integer HIERARQUIA=1;

	/** Atributo de Ic contrato Habitacional */
	public static final Character CONTRATO_HABITACIONAL = '2';

	private static final String NOME_RELATORIO_UNIDADE_HABITACIONAL = "relatorio_unidade_habitacional";
	private static final String CAMINHO_RELATORIO_UNIDADE_HABITACIONAL = "/reports/unidade_habitacional_xls.jasper";
	private static final String NOME_RELATORIO_PROSPECTO = "relatorio_unidade_habitacional_historico";
	private static final String CAMINHO_RELATORIO_PROSPECTO = "/reports/unidade_habitacional_historico_xls.jasper";

	private static final Logger LOG = Logger.getLogger(ParametrizacaoContratoMB.class.getName());

	/** Atributo service. */
	@EJB
	private transient ParametrizacaoContratoService service;

	/** Atributo contratoService. */
	@EJB
	private ContratoService contratoService;

	/* Atriburo Empreendimento Service */
	@EJB
	private EmpreendimentoService empreendimentoService;

	@EJB
	private ProspectoTipoParcelaService tipoParcelaService;

	/** Atributo tipologiaService. */
	@EJB
	private TipologiaService tipologiaService;

	/** Atributo unidadeHabitacionalService. */
	@EJB
	private UnidadeHabitacionalService unidadeHabitacionalService;

	/** Atributo unidadeHabitacionalComercializacaoService. */
	@EJB
	private UnidadeHabitacionalComercializacaoService unidadeHabitacionalComercializacaoService;

	@EJB
	private PessoaService pessoaService;

	/** Atributo proponenteHabitacionalService. */
	@EJB
	private ProponenteHabitacionalService proponenteHabitacionalService;

	/** Atributo proponenteHabitacionalService. */
	@EJB
	private ProspectoTipoParcelaService prospectoTipoParcelaService;

	/** Atributo parametroComercializacaoService. */
	@EJB
	private ParametroComercializacaoService parametroComercializacaoService;


    /** Atributo propriedadeService. */
    @EJB
    private transient PropriedadeService propriedadeService;

	/** Atributo prospectoService. */
	@EJB
	private ProspectoService prospectoService;

	/** Atributo recebidoService. */
	@EJB
	private RecebidoService recebidoService;

	/** Atributo bandeiraCartaoService. */
	@Inject
	private BandeiraCartaoService bandeiraCartaoService;

	@Inject
	private AnaliseContratoService analiseContratoService;

	@Inject
	private UnidadeHabitacionalLazyModel unidadesHabitacionaisPaginada;

	@Inject
	private CaixaKeycloakService caixaKeycloakService;
	
    @EJB
    private transient ParametroProdutoService parametroProdutoService;

	/** Atributo visao. */
	private ParametrizacaoContratoVisao visao;

	@ManagedProperty(value = ParametroProdutoMB.EL_MANAGED_BEAN)
	private ParametroProdutoMB parametroProdutoMB;

	private ParametroProdutoVisao parametroProdutoVisao;

	@ManagedProperty(value = ContaCorrenteCartaoMB.EL_MANAGED_BEAN)
	private ContaCorrenteCartaoMB contaCorrenteCartaoMB;

	private String msgAlert;

	/** Atributo idxTipologia. */
	private Integer idxTipologia;

	/** Atributo vrCV. */
	private BigDecimal vrCV;

	/** Atributo idxRecebido. */
	private Integer idxRecebido;

	/** Atributo motivoInativacaoRegistro. */
	private String motivoInativacaoRegistro;

	/** Atributo idxAmortizacao. */
	private Integer idxAmortizacao;

	/** Atributo motivoInativacaoAmortizacao. */
	private String motivoInativacaoAmortizacao;

	/** Atributo TIPO_PARCELA_AMORTIZACAO. */
	public static final Integer TIPO_PARCELA_AMORTIZACAO = 43;

	/** Atributo SITUACAO_CONCILIACAO_AMORTIZACAO. */
	public static final Integer SITUACAO_CONCILIACAO_AMORTIZACAO = 5;

	private Integer nuRecebido;

	@EJB
	private AplicacaoFinanceiraService aplicacaoFinanceiraService;

	private boolean isGarantiaVeiculoAcompanhado;

	@EJB
	private BemClienteService bemClienteService;

	@EJB
	private GarantiaBemClienteService garantiaBemClienteService;

	@Inject
	private UnidadeHabitacionalHistoricoService unidadeHabitacionalHistoricoService;
	
	@EJB
	private UnidadeVinculadaSuatService unidadeVinculadaSuatService;
	
	@EJB
	private FabricaCalculoGarantia fabricaCalculoGarantia;
	
	/**
	 * <p>
	 * Método responsável por carregar os dados da visão.
	 * <p>
	 *
	 * @author Waltenes Junior
	 */
	@PostConstruct
	public void carregarDadosVisao() {
		if (this.getContaCorrenteCartaoMB() == null) {
			final FacesContext context = FacesContext.getCurrentInstance();
			this.setContaCorrenteCartaoMB(
					context.getApplication().evaluateExpressionGet(context, "#{contaCorrenteCartaoMB}", ContaCorrenteCartaoMB.class));
		}

		this.popularComboGarantia();
		this.popularComboTipoParcela();
		this.inicializarQtdDias();
		this.getVisao().getEntidade().setGarantia(new Garantia());

		this.getVisao().setFormaGarantia2List(EnumSet.of(FormaGarantiaEnum.PMT));
		this.getVisao().setCaracteristicaList(EnumSet.allOf(CaracteristicaEnum.class));
		this.getVisao().setCedenteIncluido(new Cedente());

		this.getVisao().setContaContratoCheque(new ContaContrato());
		this.getVisao().getContaContratoCheque().setNuConta(new ContaCorrente());

		this.getVisao().setContaContratoAplicacaoFinanceira(new ContaContrato());
		this.getVisao().getContaContratoAplicacaoFinanceira().setNuConta(new ContaCorrente());
		this.getVisao().setContaCorrenteDaArvore(new DefaultTreeNode("Contas", null));

		this.getVisao().setContaContrato(new ContaContrato());
		this.getVisao().getContaContrato().setNuConta(new ContaCorrente());
		this.getVisao().setDuplicataExcepcionada(new DuplicataExcepcionada());

		this.getVisao().setSacadoExcepcionado(new SacadoExcepcionadoVO());
		this.getVisao().getCedentesSelecionados().clear();

		this.idxTipologia = 0;
		this.idxRecebido = 0;
		this.idxAmortizacao = 0;

		final UnidadeHabitacional uh = new UnidadeHabitacional();
		uh.setNuEmpreendimento(new Empreendimento());
		uh.setNuTipologia(new Tipologia());

		this.getVisao().setUnidadeHabitacionalEmEdicao(uh);
		this.getVisao().setUnidadeHabitacionalComercializacao(new UnidadeHabitacionalComercializacao());
		this.carregarListaBandeiraCartao();
		this.getVisao().getPessoaTerceiro();
	}
	
	@Override
	public void carregar() {
		if (this.visao == null) {
			this.visao = new ParametrizacaoContratoVisao();
		}
		this.carregarDadosConfigUnidades();
	}
	
	public void prepararUnidades() {		
		this.getVisao().setUnidadesSelecionadas(new ArrayList<UnidadeVO>());
		this.getVisao().setListaDires(new ArrayList<UnidadeVO>());
		if (this.getVisao().getTipoConfig().equals(HIERARQUIA)) {
			this.getVisao().setUnidadeGestoraSeleciona(null);
			this.getVisao().setListaDires(new ArrayList<>(unidadeVinculadaSuatService.listarDires()));
		} else {
			this.getVisao().setListaDires(new ArrayList<>(unidadeVinculadaSuatService.listarProcessos()));
		}
	}

	private void carregarDadosConfigUnidades() {        
        try {
        	List<UnidadeVO> unidades = new ArrayList<>();
			String dados = this.propriedadeService.getPropriedadeBanco("unidade.lista", UNIDADE);
			String tipoConfig = this.propriedadeService.getPropriedadeBanco("unidade.tipoconfig", UNIDADE);
			String numeroProcesso = this.propriedadeService.getPropriedadeBanco("unidade.unidadeGestora", UNIDADE);
			
			String[] lista = dados.split(";");
			for (String item : lista) {
				int codUnidade = Integer.parseInt(item);
				UnidadeVO unidade = null;
				unidade = this.unidadeVinculadaSuatService.obterPorNuSuat(codUnidade);
				if (unidade != null) {
					unidades.add(unidade);
				}
			}
			this.getVisao().setUnidadesSelecionadas(new ArrayList<>(unidades));			
			this.getVisao().setUnidadesTemp(unidades);			
			this.getVisao().setTipoConfig(NumberUtils.toInt(tipoConfig, 1));
			this.getVisao().setUnidadeGestoraSeleciona(NumberUtils.toInt(numeroProcesso));
			if (this.getVisao().getTipoConfig().equals(HIERARQUIA)) {
				this.getVisao().setListaDires(new ArrayList<>(unidadeVinculadaSuatService.listarDires()));
			} else {
				this.getVisao().setListaDires(new ArrayList<>(unidadeVinculadaSuatService.listarProcessos()));
			}
		} catch (ParametrosInvalidosException e) {
			this.getVisao().setTipoConfig(HIERARQUIA);
			LogCEF.error("Erro ao carregar propriedades de unidades. Detalhes: ");
			LogCEF.error(e);
		}
		
	}

	/**
	 *
	 * <p>
	 * Método responsável por popular a combo de garantias.
	 * <p>
	 *
	 * @author Caio Graco
	 */
	public void popularComboGarantia() {
		final List<Garantia> garantias = new ArrayList<>(this.getService().getGarantiasAtivas());
		Collections.sort(garantias);
		this.getVisao().setGarantias(garantias);
	}
	
	public void removeItemListaCaixa(UnselectEvent event) {
		this.visao.getUnidadesRemocao().add((UnidadeVO)event.getObject());
	}
	
	public void addItemLista(SelectEvent event) {
		UnidadeVO item = (UnidadeVO)event.getObject();
		// Gambi para não duplicar item na lista
		if (achouNaLista(item)) {
			this.visao.getUnidadesSelecionadas().remove(item);
		}
	}
	
	private boolean achouNaLista(UnidadeVO item) {
		List<UnidadeVO> lista = this.visao.getUnidadesSelecionadas();
		int cont = 0;
		
		for (UnidadeVO unidadeVO : lista) {
			if (item.getCoUnidadeVO().equals(unidadeVO.getCoUnidadeVO())) {
				cont++;
			}
			if (cont > 1) {
				return true;
			}
		}
		return false;
	}

	public List<UnidadeVO> listarPorNome(String nome) {
		List<UnidadeVO> retorno = new ArrayList<>();
		if (nome != null && !nome.isEmpty()) {
			retorno = new ArrayList<>(this.unidadeVinculadaSuatService.listarDiresPorNome(nome, null));
			this.ordenarPorCodigo(retorno);
		}
	    return retorno;
	}

	private void ordenarPorCodigo(List<UnidadeVO> retorno) {		
		if (CollectionUtils.isNotEmpty(retorno)) {
			Collections.sort(retorno, new Comparator<UnidadeVO>() {

				@Override
				public int compare(UnidadeVO o1, UnidadeVO o2) {
					Integer cod1 = o1.getCoUnidadeVO();
					Integer cod2 = o2.getCoUnidadeVO();
					if (cod1 != null && cod2 != null) {
						return cod1.compareTo(cod2);
					} 
					return -1;
				}
			});
		}
		
	}

	public void popularComboTipoParcela() {
		this.getVisao().getListaTipoParcelaConsulta().addAll(this.tipoParcelaService.obterListaTipoParcela());
	}

	/**
	 * <p>
	 * Método responsável por carregar a lista de bandeiras de cartões
	 * </p>
	 * .
	 *
	 * @author p541915
	 *
	 */
	private void carregarListaBandeiraCartao() {
		this.getVisao().setListaBandeiraCartao(this.getBandeiraCartaoService().listarTodasBandeirasAtivas());
	}

	/**
	 * <p>
	 * Método responsável por carregar os logs de faturamento da pessoa do contrato.
	 * <p>
	 *
	 * @author Caio Graco
	 */
	public void carregarLogFaturamentoPessoa() {
		this.getVisao().setListaHistoricoFaturamentoPessoa(this.service
				.listarHistoricoFaturamentoPessoa(this.getVisao().getContratoSelecionadoParaParametrizacao().getNuPessoa().getNuPessoa()));
	}

	/**
	 * <p>
	 * Método responsável por iniciar a página de Manutenção de Parâmetros.
	 * <p>
	 *
	 * @return String
	 * @author Caio Graco
	 */
	@Auditoria
	@OperacaoAuditoria(acao = "ABRIR_MANUTENCAO_PARAMETROS")
	public String abrirPaginaParametros() {
		this.getVisao().setListaParametroCalculo(this.getService().listaTodosParametrosCalculo());
		this.verificarPermissoes();
		return ParametrizacaoContratoMB.PAGINA_CONSULTA_PARAMETROS;
	}

	/**
	 * <p>
	 * Método responsável por salvar os parametros para calculo.
	 * <p>
	 *
	 * @return
	 * @author Caio Graco
	 */
	public void salvarParametrosCalculo() {
		this.getService().salvarParametrosCalculo(this.getVisao().getListaParametroCalculo());

		super.adicionaMensagemDeSucesso("MN014");
	}

	/**
	 * <p>
	 * Método responsável por inicializar o atributo qtdDias.
	 * <p>
	 *
	 * @author Robson Oliveira
	 */
	private void inicializarQtdDias() {
		try {
			this.getVisao().setQtdDias(UtilObjeto.isReferencia(this.getService().obterQtdDias()) ? Integer.valueOf(this.getService().obterQtdDias())
					: Integer.valueOf(0));
		} catch (final Exception e) {
			LogCEF.debug(e);
		}
	}

	/**
	 * <p>
	 * Método responsável por salvar a quantidade de dias que será utilizado para o
	 * intervalo permitido para gerar o relatório de log de auditoria.
	 * <p>
	 *
	 * @author robson.oliveira
	 */
	public void salvarParametroQtdDias() {
		try {
			this.getService().salvarQtdDiasPropriedade(this.getVisao().getQtdDias());
			super.adicionaMensagemDeSucesso("MN040");

		} catch (final ObjectNotFoundException e) {
			super.adicionaMensagemInformativa("MN050");
			LogCefUtil.error(e);
		}
	}
	
	/**
	 * 
	 */
	public void salvarConfigUnidadade() {
		List<Propriedade> propriedades = new ArrayList<>();
		Propriedade prop1 = criarPropriedade("unidade.lista", UNIDADE, prepararValorPropriedade(this.getVisao().getUnidadesSelecionadas()));
		prop1.setDeComentario("Lista de SUAT/Processos que serão utilizados no SIACG");
		
		Propriedade prop2 = criarPropriedade("unidade.tipoconfig", UNIDADE, this.getVisao().getTipoConfig().toString());
		prop2.setDeComentario("1 - Parametrização por Hierarquia; 2 - Parametrização por processo.");
		
		if (this.getVisao().getUnidadeGestoraSeleciona() != null && this.getVisao().getUnidadeGestoraSeleciona() > 0) {
			Propriedade prop3 = criarPropriedade("unidade.unidadeGestora", UNIDADE, this.getVisao().getUnidadeGestoraSeleciona().toString());
			prop3.setDeComentario("Unidade gestora do processo.");
			
			propriedades.add(prop3);
		}
		
        propriedades.add(prop1);
        propriedades.add(prop2);
        
        this.propriedadeService.salvar(propriedades);
        super.adicionaMensagemDeSucesso(ParametrizacaoContratoMB.OPERACAO_REALIZADA_SUCESSO);
	}

	private Propriedade criarPropriedade(String noProp, String grupo, String valor) {
		Propriedade prop1 = new Propriedade();
		prop1.setNoPropriedade(noProp);
		prop1.setNoGrupo(grupo);
		prop1.setNoValorPropriedade(valor);
		return prop1;
	}

	private String prepararValorPropriedade(List<UnidadeVO> lista) {
		StringBuilder retorno = new StringBuilder();
		if (lista != null && !lista.isEmpty()) {
			for (UnidadeVO item : lista) {
				if (item.isProcesso()) {
					retorno.append(item.getNuProcesso());
				} else {
					retorno.append(item.getCoUnidadeVO());
				}
				retorno.append(";");
			}
		}
		
		return retorno.toString();
	}

	/**
	 * <p>
	 * Método responsável por montar a arvore de conta corrente e aplicação
	 * financeira.
	 * <p>
	 *
	 * @author Caio Graco
	 */
	public void montarArvoreAplicacaoFinanceira() {
		final Collection<GarantiaAplicacao> listaGarantiaAplicacao = this.getVisao().getListaAplicacaoSelecionadas();

		final TreeNode treeAplicacoes = new DefaultTreeNode(new ContaContrato(), null);

		TreeNode conta = null;

		for (final ContaContrato contaContrato : this.getVisao().getListaContaContratoDasAplicacoes()) {

			conta = new DefaultTreeNode(contaContrato, treeAplicacoes);

			conta.setExpanded(true);
			conta.setSelectable(false);

			for (final AplicacaoFinanceira aplicacaoFinanceira : contaContrato.getNuConta().getAplicacaoFinanceiraList()) {
				final TreeNode aplicacao = new DefaultTreeNode(aplicacaoFinanceira, conta);

				aplicacao.setExpanded(true);

				for (final GarantiaAplicacao garantia : listaGarantiaAplicacao) {
					if (garantia.getId().getAplicacaoFinanceira().equals(aplicacaoFinanceira)) {
						aplicacao.setSelected(true);
						break;
					}
				}
			}
		}

		this.getVisao().setContaCorrenteDaArvore(treeAplicacoes);
	}

	/**
	 * <p>
	 * Método responsável por montar a Arvore de Cartao de Credito.
	 * <p>
	 *
	 * @author guilherme.santos
	 * @author gerusa.soares
	 */
	public void montarArvoreCartaoCredito() {
	    	final List<ContaCorrenteBandeirasVO> listaContaCorrenteBandeiras = new ArrayList<>();
		List<ContaContrato> listaContaContratoCartao = this.getVisao().getListaContaContratoCartao();
		List<BandeiraCartao> listaBandeiraCartao = this.visao.getListaBandeiraCartao();

		for (final ContaContrato contaContrato : listaContaContratoCartao) {
			ContaCorrenteBandeirasVO vo = new ContaCorrenteBandeirasVO();
			vo.setContaContrato(contaContrato);
			for (final BandeiraCartao bandeiraCartao : listaBandeiraCartao) {
				if (bandeiraCartao.getIcTipoMovimentacao().equals(TipoMovimentacaoEnum.CREDITO.getValor())) {
					GarantiaCartaoCredito garantiaCartao = this.getContaCorrenteCartaoMB().retornaSeJaExisteNaLista(contaContrato,this.getVisao().getEntidade(), bandeiraCartao);
					garantiaCartao = (garantiaCartao == null 
						? this.consultarGarantiaCartaoCredito(contaContrato.getNuConta(), this.getVisao().getEntidade().getNuGarantia(),bandeiraCartao)
						: garantiaCartao);

					vo.getListaGarantiaCartaoCredito().add(garantiaCartao);
				}
			}
			vo.setFilteredValues(vo.getListaGarantiaCartaoCredito());
			vo.setGarantiaContrato(this.getVisao().getEntidade());

			listaContaCorrenteBandeiras.add(vo);
		}
		
		this.getVisao().getListaContaCorrenteBandeiras().clear();
		this.getVisao().setListaContaCorrenteBandeiras(listaContaCorrenteBandeiras);
		
	}

	public boolean isMostrarContasBandeirasCartaoCredito() {
		return this.getVisao().isExibirCartaoCredito() && this.getVisao().isExibirCamposEdicao() && !this.isGarantiaHabitacional();
	}

	public boolean isMostrarContasBandeirasCartaoCreditoV1() {
		return this.isMostrarContasBandeirasCartaoCredito() && !this.fabricaCalculoGarantia.isGarantiaCartaoCreditoV2(this.getVisao().getEntidade());
	}

	public boolean isMostrarContasBandeirasCartaoCreditoV2() {
		return this.isMostrarContasBandeirasCartaoCredito() && this.fabricaCalculoGarantia.isGarantiaCartaoCreditoV2(this.getVisao().getEntidade());
	}

	/**
	 * <p>
	 * Método responsável por consultar GarantiaCartaoCredito.
	 * <p>
	 *
	 * @param conta
	 *            valor a ser atribuido
	 * @param idGarantiaContrato
	 *            valor a ser atribuido
	 * @param bandeira
	 *            valor a ser atribuido
	 * @return GarantiaCartaoCredito
	 * @author guilherme.santos
	 * @author Mábio Barbosa
	 * @author gerusa.soares
	 */
	private GarantiaCartaoCredito consultarGarantiaCartaoCredito(final ContaCorrente conta, final Integer idGarantiaContrato, final BandeiraCartao bandeiraCartao) {
		GarantiaCartaoCredito retorno = null;

		if (idGarantiaContrato != null) {
			retorno = this.service.obterGarantiaCartaoCredito(conta, idGarantiaContrato, bandeiraCartao);
		}
		
		final boolean isNovaParametrizacao = retorno == null || retorno.getNuGarantiaCartaoCredito() == null;
		
		if (isNovaParametrizacao) {
			retorno = new GarantiaCartaoCredito();
			retorno.setBandeiraCartao(bandeiraCartao);
			retorno.setNuConta(conta);
			retorno.setGarantiaContrato(this.getVisao().getEntidade());
		}
		
		boolean atualizouConformeVisao = false;
		
		//atualiza icMarcado conforme o que está na lista da visão, para o caso do usuário ter alterado.
		for(ContaCorrenteBandeirasVO ccb: this.getVisao().getListaContaCorrenteBandeiras()) {
			 for(GarantiaCartaoCredito gcc: ccb.getListaGarantiaCartaoCredito()) {
			     if(gcc.getBandeiraCartao().equals(bandeiraCartao) && gcc.getNuConta().equals(conta)) {
				 retorno.setIcMarcado(gcc.isIcMarcado());
				 atualizouConformeVisao = true;
				 break;
			     }
			 }
		    }
		
		if(!isNovaParametrizacao && !atualizouConformeVisao) {
		    retorno.setIcMarcado(Boolean.TRUE);
		}

		return retorno;
	}

	/**
	 * <p>
	 * Método responsável por remover a conta corrente da aplicação financeira.
	 * <p>
	 *
	 * @author Caio Graco
	 */
	public void removerContaCorrenteAplicacaoFinanceira() {
		final ContaContrato contaContrato = this.getVisao().getContaContratoAplicacaoFinanceira();

		this.getVisao().getListaContaContratoDasAplicacoes().remove(contaContrato);

		this.getVisao().setContaContratoAplicacaoFinanceira(new ContaContrato());
		this.getVisao().getContaContratoAplicacaoFinanceira().setNuConta(new ContaCorrente());

		final Collection<ContaContrato> contaContratosParaRemover = new ArrayList<>();
		contaContratosParaRemover.add(contaContrato);
		this.service.removerContasContrato(contaContratosParaRemover);

		this.montarArvoreAplicacaoFinanceira();
	}

	/**
	 * <p>
	 * Método responsável por remover elemento da lista de ContaContrato de Cheque.
	 * <p>
	 *
	 * @author guilherme.santos
	 */
	public void removerContaCorrenteCheque() {
		final ContaContrato contaContrato = this.getVisao().getContaContratoCheque();

		this.getVisao().getListaContaContratoCheque().remove(contaContrato);

		this.getVisao().setContaContratoCheque(new ContaContrato());
		this.getVisao().getContaContratoCheque().setNuConta(new ContaCorrente());
	}

	/**
	 * <p>
	 * Método responsável por remover elemento da lista de ContaContrato de Cheque.
	 * <p>
	 *
	 * @author guilherme.santos
	 */
	public void removerContaCorrenteCartaoCredito() {
		final ContaContrato contaContrato = this.getVisao().getContaContratoCartao();

		this.getVisao().getListaContaContratoCartao().remove(contaContrato);

		this.getVisao().setContaContratoCartao(new ContaContrato());
		this.getVisao().getContaContratoCartao().setNuConta(new ContaCorrente());

		if (this.getVisao().getCartoesSelecionados() != null) {
			// Remove os cartoes selecionados da conta removida
			final List<TreeNode> itensParaManter = new LinkedList<>();

			for (final TreeNode contaNode : this.getVisao().getCartoesSelecionados()) {
				if (contaNode.getData() instanceof GarantiaCartaoCredito) {
					final GarantiaCartaoCredito garantiaCartaoCredito = (GarantiaCartaoCredito) contaNode.getData();
					if (!garantiaCartaoCredito.getNuConta().equals(contaContrato.getNuConta())) {
						itensParaManter.add(contaNode);
					}
				}
			}

			this.getVisao().setCartoesSelecionados(itensParaManter.toArray(new TreeNode[0]));
		}

		this.montarArvoreCartaoCredito();
	}

	/**
	 * <p>
	 * Método responsável por adicionar a conta corrente da aplicação financeira.
	 * <p>
	 *
	 * @author Caio Graco
	 */
	public void adicionarContaCorrenteAplicacaoFinanceira() {
		if (this.service.validarContaCorrente(this.getVisao().getContaContratoAplicacaoFinanceira().getNuConta())) {
			if (this.verificarSeListaContemContaCorrente(this.getVisao().getListaContaContratoDasAplicacoes(),
					this.getVisao().getContaContratoAplicacaoFinanceira())) {
				super.adicionaMensagemDeAlerta(ParametrizacaoContratoMB.MSG_CONTA_CORRENTE_JA_INSERIDA);
			} else if (this.service.obterContaContratoPorContratoEContaCorrenteOrigem(
					this.getVisao().getContaContratoAplicacaoFinanceira().getNuConta(), this.getVisao().getContratoSelecionadoParaParametrizacao(),
					TipoOrigemContaContratoEnum.APLICACAO_FINANCEIRA) != null) {
				this.getVisao().getContaContratoAplicacaoFinanceira().getNuConta().setFormaInsercao(ContaCorrenteEnum.INSERIDO);
				this.getVisao().getListaContaContratoDasAplicacoes().add(this.getVisao().getContaContratoAplicacaoFinanceira());
				this.montarArvoreAplicacaoFinanceira();
				this.getVisao().setContaContratoAplicacaoFinanceira(new ContaContrato());
				this.getVisao().getContaContratoAplicacaoFinanceira().setNuConta(new ContaCorrente());
			} else {
				final Collection<AplicacaoFinanceira> listaAplicacaoFinanceiraExistente = this.service
						.listaAplicacaoFinanceiraPorContaCorrente(this.getVisao().getContaContratoAplicacaoFinanceira().getNuConta());

				if (!listaAplicacaoFinanceiraExistente.isEmpty()) {
					this.getVisao().getContaContratoAplicacaoFinanceira().getNuConta().setAplicacaoFinanceiraList(listaAplicacaoFinanceiraExistente);
				}

				this.getVisao().getContaContratoAplicacaoFinanceira().setIcOrigem(TipoOrigemContaContratoEnum.APLICACAO_FINANCEIRA);
				this.getVisao().getListaContaContratoDasAplicacoes().add(this.getVisao().getContaContratoAplicacaoFinanceira());
				this.getVisao().getContaContratoAplicacaoFinanceira().setIcUtilizarSaldoCheque(false);

				this.service.inserirContasNaoExistentes(this.getVisao().getListaContaContratoDasAplicacoes(),
						this.getVisao().getContratoSelecionadoParaParametrizacao(), TipoOrigemContaContratoEnum.APLICACAO_FINANCEIRA);

				this.montarArvoreAplicacaoFinanceira();

				this.getVisao().setContaContratoAplicacaoFinanceira(new ContaContrato());
				this.getVisao().getContaContratoAplicacaoFinanceira().setNuConta(new ContaCorrente());
			}
		} else {
			super.adicionaMensagemInformativa(ParametrizacaoContratoMB.MSG_CONTA_CORRENTE_INVALIDA);
		}
	}

	/**
	 * <p>
	 * Método responsável por adicionar a conta corrente a arvore de cartão de
	 * crédito.
	 * <p>
	 *
	 * @author guilherme.santos
	 */
	public void adicionarContaCorrenteCartaoCredito() {
		if (this.service.validarContaCorrente(this.getVisao().getContaContratoCartao().getNuConta())) {
			if (this.verificarSeListaContemContaCorrente(this.getVisao().getListaContaContratoCartao(), this.getVisao().getContaContratoCartao())) {
				super.adicionaMensagemDeAlerta(ParametrizacaoContratoMB.MSG_CONTA_CORRENTE_JA_INSERIDA);

			} else if (this.service.obterContaContratoPorContratoEContaCorrenteOrigem(this.getVisao().getContaContratoCartao().getNuConta(),
					this.getVisao().getContratoSelecionadoParaParametrizacao(), TipoOrigemContaContratoEnum.CARTAO_CREDITO) != null) {
				this.getVisao().getContaContratoCartao().getNuConta().setFormaInsercao(ContaCorrenteEnum.INSERIDO);
				this.getVisao().getListaContaContratoCartao().add(this.getVisao().getContaContratoCartao());
				this.montarArvoreCreditoPelaVersao();
				this.getVisao().setContaContratoCartao(new ContaContrato());
				this.getVisao().getContaContratoCartao().setNuConta(new ContaCorrente());
			} else {
				this.getVisao().getContaContratoCartao().setIcUtilizarSaldo(false);
				this.getVisao().getContaContratoCartao().setIcUtilizarSaldoCheque(false);
				this.getVisao().getContaContratoCartao().setIcOrigem(TipoOrigemContaContratoEnum.CARTAO_CREDITO);
				this.getVisao().getContaContratoCartao().setIcConta(ContaEnum.NORMAL);
				this.getVisao().getContaContratoCartao().setNuContrato(this.getVisao().getContratoSelecionadoParaParametrizacao());
				this.getVisao().getListaContaContratoCartao().add(this.getVisao().getContaContratoCartao());

				this.service.inserirContasNaoExistentes(this.getVisao().getListaContaContratoCartao(),
						this.getVisao().getContratoSelecionadoParaParametrizacao(), TipoOrigemContaContratoEnum.CARTAO_CREDITO);

				this.getContaCorrenteCartaoMB().getVisao().getListaContaContratoCartao().add(this.getVisao().getContaContratoCartao());
				this.montarArvoreCreditoPelaVersao();

				this.getVisao().setContaContratoCartao(new ContaContrato());
				this.getVisao().getContaContratoCartao().setNuConta(new ContaCorrente());
			}
		} else {
			super.adicionaMensagemInformativa(ParametrizacaoContratoMB.MSG_CONTA_CORRENTE_INVALIDA);
		}
	}

	/**
	 * <p>
	 * Método executado quando a forma de garantia é selecionada.
	 * </p>
	 *
	 * @author joseroberto@gsgroup.com.br
	 * @author Ronnie Mikihiro
	 * @author Mábio Barbosa
	 */
	public void onSelectIcFormaGarantia1() {
		final ParametrizacaoContratoVisao visao = this.getVisao();
		visao.setExibirNovaFormaGarantia(Boolean.FALSE);
		visao.setExibirBtnOu(Boolean.FALSE);

		final FormaGarantiaEnum formaGarantiaSelecionada = visao.getEntidade().getIcFormaGarantia1();
		if (UtilObjeto.isReferencia(formaGarantiaSelecionada)) {
			switch (formaGarantiaSelecionada) {
			case PMT:
				visao.setFormaGarantia2List(EnumSet.of(FormaGarantiaEnum.SALDO_DEVEDOR));
				visao.setExibirBtnOu(Boolean.TRUE);
				break;

			case SALDO_DEVEDOR:
				visao.setFormaGarantia2List(EnumSet.of(FormaGarantiaEnum.PMT));
				visao.setExibirBtnOu(Boolean.TRUE);
				break;

			default:
				visao.getEntidade().setIdentificadorFormaGarantia2(null);
				visao.getEntidade().setIcFormaGarantia2(null);
				visao.getEntidade().setVrFormaGarantia2(null);
				visao.setExibirBtnOu(Boolean.FALSE);
				break;
			}
		}

		this.getContaCorrenteCartaoMB().atualizaVrTotalConstituidoPorMudancaNaFormaGarantia();
	}

	/**
	 * <p>
	 * Método responsável por adicionar a conta corrente na lista.
	 * <p>
	 *
	 * @author Caio Graco
	 */
	public void adicionarContaCorrente() {
		if (this.validarContaCorrenteVerificandoSegmento()) {
			if (this.verificarSeListaContemContaCorrente(this.getVisao().getListaContaContrato(), this.getVisao().getContaContrato())) {
				super.adicionaMensagemDeAlerta(ParametrizacaoContratoMB.MSG_CONTA_CORRENTE_JA_INSERIDA);
			} else {
				this.getVisao().getContaContrato().setIcOrigem(TipoOrigemContaContratoEnum.CONTRATO);
				this.getVisao().getContaContrato().setIcUtilizarSaldo(false);
				this.getVisao().getContaContrato().setIcUtilizarSaldoCheque(false);
				if (this.getVisao().getContaContrato().getIcConta() != null) {
					this.getVisao().getContaContrato().setIdentificadorConta(this.getVisao().getContaContrato().getIcConta().getValor());
				}
				this.getVisao().getListaContaContrato().add(this.getVisao().getContaContrato());
				this.getVisao().setContaContrato(new ContaContrato());
				this.getVisao().getContaContrato().setNuConta(new ContaCorrente());
			}
		} else {
			super.adicionaMensagemInformativa(ParametrizacaoContratoMB.MSG_CONTA_CORRENTE_INVALIDA);
		}
	}

	private boolean validarContaCorrenteVerificandoSegmento() {
		if (this.getVisao().isSegmentoMPE() && ContaEnum.NORMAL.equals(this.getVisao().getContaContrato().getIcConta())) {
			return this.service.validarContaCorrente(this.getVisao().getContaContrato().getNuConta());
		}
		return this.service.validarContaCorrenteNLM(this.getVisao().getContaContrato().getNuConta());
	}

	/**
	 * <p>
	 * Método responsável por Adicionar uma nova Conta Corrente na grid de contas do
	 * Cheque.
	 * <p>
	 *
	 * @author guilherme.santos
	 */
	public void adicionarContaCorrenteCheque() {
		if (this.service.validarContaCorrente(this.getVisao().getContaContratoCheque().getNuConta())) {
			if (this.verificarSeListaContemContaCorrente(this.getVisao().getListaContaContratoCheque(), this.getVisao().getContaContratoCheque())) {
				super.adicionaMensagemDeAlerta(ParametrizacaoContratoMB.MSG_CONTA_CORRENTE_JA_INSERIDA);
			} else if (this.service.obterContaContratoPorContratoEContaCorrenteOrigem(this.getVisao().getContaContratoCheque().getNuConta(),
					this.getVisao().getContratoSelecionadoParaParametrizacao(), TipoOrigemContaContratoEnum.CHEQUE) != null) {
				this.getVisao().getContaContratoCheque().setIcOrigem(TipoOrigemContaContratoEnum.CHEQUE);
				this.getVisao().getListaContaContratoCheque().add(this.getVisao().getContaContratoCheque());
				this.getVisao().setContaContratoCheque(new ContaContrato());
				this.getVisao().getContaContratoCheque().setNuConta(new ContaCorrente());
			} else {
				this.getVisao().getContaContratoCheque().setIcUtilizarSaldo(false);
				this.getVisao().getContaContratoCheque().setIcUtilizarSaldoCheque(false);
				this.getVisao().getContaContratoCheque().setIcOrigem(TipoOrigemContaContratoEnum.CHEQUE);
				this.getVisao().getListaContaContratoCheque().add(this.getVisao().getContaContratoCheque());
				this.getVisao().setContaContratoCheque(new ContaContrato());
				this.getVisao().getContaContratoCheque().setNuConta(new ContaCorrente());

				this.service.inserirContasNaoExistentes(this.getVisao().getListaContaContratoCheque(),
						this.getVisao().getContratoSelecionadoParaParametrizacao(), TipoOrigemContaContratoEnum.CHEQUE);
			}
		} else {
			super.adicionaMensagemInformativa(ParametrizacaoContratoMB.MSG_CONTA_CORRENTE_INVALIDA);
		}
	}

	/**
	 * <p>
	 * Método responsável por verificar se a conta corrente esta contida na lista de
	 * conta contrato.
	 * <p>
	 *
	 * @param listaContaContrato
	 *            valor a ser atribuido
	 * @param contaContrato
	 *            valor a ser atribuido
	 * @return boolean
	 * @author guilherme.santos
	 */
	private boolean verificarSeListaContemContaCorrente(final Collection<ContaContrato> listaContaContrato, final ContaContrato contaContrato) {
		for (final ContaContrato conta : listaContaContrato) {
			if (conta.getNuConta().getId().equals(contaContrato.getNuConta().getId())) {
				return Boolean.TRUE;
			}
		}

		return Boolean.FALSE;
	}

    /**
     * <p>
     * Método responsável por adicionar o cedente na lista e salvar no banco.
     * <p>
     *
     * @author Caio Graco
     * @author Gilberto Nery
     * 
     */
    public void adicionarCedente() {
	final Cedente cedente = this.getVisao().getCedenteIncluido();
	
	final Pessoa pessoaContrato = this.getVisao().getContratoSelecionadoParaParametrizacao().getNuPessoa();
	
	Cedente cedenteIncluido = this.service.adicionarCedente(cedente, (List<Cedente>) this.getVisao().getListaCedentes(), pessoaContrato);

	if(cedenteIncluido == null) {
	    super.adicionaMensagemInformativa("MN083");
	} else if(cedenteIncluido.getNuCedente() == null && cedenteIncluido.getCoCedente() == null) {
	    super.adicionaMensagemDeErro("MN018");
	} 
				
	this.getVisao().setCedenteIncluido(new Cedente());
    }

    /**
     * <p>
     * Método responsável por inativar o cedente selecionado.
     * <p>
     *
     * @author Caio Graco
     * @author Gilberto Nery
     * 
     */
    public void removerCedente() {
	final Cedente cedente = this.getVisao().getCedenteIncluido();

	Integer nuGarantia = 0;
	if(this.getVisao().getParametrizacaoEdicao() != null && this.getVisao().getParametrizacaoEdicao().getGarantiaContrato() != null
		&& this.getVisao().getParametrizacaoEdicao().getGarantiaContrato().getNuGarantia() != null) {
	    nuGarantia = this.getVisao().getParametrizacaoEdicao().getGarantiaContrato().getNuGarantia();
	}
	
	String msg = getService().removerCedente(cedente, nuGarantia);

	if(msg != null && !msg.isEmpty()) {
	    super.adicionaMensagemInformativa(msg);
	}

	this.getVisao().setCedenteIncluido(new Cedente());
    }

	/**
	 * <p>
	 * Método responsável por remover a conta corrente da lista.
	 * <p>
	 *
	 * @author Caio Graco
	 */
	public void removerContaCorrente() {
		this.getVisao().getListaContaContrato().remove(this.getVisao().getContaContrato());
	}

	/**
	 * <p>
	 * Método responsável por pesquisar duplicatas.
	 * <p>
	 *
	 * @author Caio Graco
	 */
	public void pesquisarDuplicata() {
		this.getVisao().setDuplicatasEncontradas(this.service.pesquisarDuplicata(this.getVisao().getDuplicataExcepcionada()));

		this.getVisao().setDuplicataExcepcionada(new DuplicataExcepcionada());
	}

	/**
	 * <p>
	 * Método responsável por pesquisar cheques.
	 * <p>
	 *
	 * @author guilherme.santos
	 */
	public void pesquisarCheque() {
		this.getVisao().setChequesExcepcionadosEncontrados(this.service.pesquisarCheques(this.getVisao().getChequeExcepcionado()));

		this.getVisao().setChequeExcepcionado(new ChequeExcepcionado());
	}

	/**
	 * <p>
	 * Método responsável por adicionar na lista as duplicatas a serem
	 * excepcionadas.
	 * <p>
	 *
	 * @author Caio Graco
	 */
	public void adicionarDuplicataExcepcionada() {
		final BigDecimal vrMaximoDuplicataExcepcionada = this.service
				.consultarParametroCalculo(ParametroCalculoEnum.VALOR_MAXIMO_DUPLICATA_EXCEPCIONADA);

		if (vrMaximoDuplicataExcepcionada.compareTo(this.getVisao().getDuplicataVO().getVrDuplicata()) < 0) {
			super.adicionaMensagemDeAlerta(ParametrizacaoContratoMB.MSG_VALOR_GARANTIA_EXCEDE_VALOR_PERMITIDO_PARA_GARANTIAS_EXCEPCIONADAS,
					vrMaximoDuplicataExcepcionada.toString());
		} else if (this.getVisao().getDuplicatasParaExcepcionar().contains(this.getVisao().getDuplicataVO())) {
			super.adicionaMensagemDeAlerta("MN015");
		} else {
			this.getVisao().getDuplicatasParaExcepcionar().add(this.getVisao().getDuplicataVO());
			// Remover Duplicata da lista de consultada
			this.getVisao().getDuplicatasEncontradas().remove(this.getVisao().getDuplicataVO());
		}
	}

	/**
	 * <p>
	 * Método responsável por adicionar o cheque a excepcionação.
	 * <p>
	 *
	 * @author guilherme.santos
	 */
	public void adicionarChequeExcepcionado() {
		final BigDecimal vrMaximoChequeExcepcionado = this.service.consultarParametroCalculo(ParametroCalculoEnum.VALOR_MAXIMO_CHEQUE_EXCEPCIONADO);

		if (vrMaximoChequeExcepcionado.compareTo(this.getVisao().getChequeVO().getVrCheque()) < 0) {
			super.adicionaMensagemDeAlerta(ParametrizacaoContratoMB.MSG_VALOR_GARANTIA_EXCEDE_VALOR_PERMITIDO_PARA_GARANTIAS_EXCEPCIONADAS,
					vrMaximoChequeExcepcionado.toString());
		} else if (this.getVisao().getChequesParaExcepcionar().contains(this.getVisao().getChequeVO())) {
			super.adicionaMensagemDeAlerta(ParametrizacaoContratoMB.MSG_CHEQUE_JA_INSERIDO);
		} else {
			this.getVisao().getChequesParaExcepcionar().add(this.getVisao().getChequeVO());
			// Remover Duplicata da lista de consultada
			this.getVisao().getChequesExcepcionadosEncontrados().remove(this.getVisao().getChequeVO());
		}
	}

	/**
	 * <p>
	 * Método responsável por salvar as duplicatas excepcionadas.
	 * <p>
	 *
	 * @author Caio Graco
	 */
	public void salvarDuplicatasExcepcionadas() {
		final Collection<DuplicataExcepcionada> listaDuplicatasExcepcionadas = new ArrayList<>();
		DuplicataExcepcionada excepcionada;

		final GarantiaContrato garantiaContrato = this.service.obterGarantiaContrato(this.getVisao().getIdentificadorExcepcionar());

		for (final DuplicataVO vo : this.getVisao().getDuplicatasParaExcepcionar()) {
			excepcionada = new DuplicataExcepcionada();

			excepcionada.setNuDuplicata(vo.getNuDuplicata());
			excepcionada.setCoNossoNumero(vo.getCoNossoNumero());
			excepcionada.setVrDuplicata(vo.getVrDuplicata());
			excepcionada.setDtDuplicata(new Date());
			excepcionada.setCoResponsavel(super.getMatriculaUsuario());
			excepcionada.setGarantiaContrato(garantiaContrato);

			listaDuplicatasExcepcionadas.add(excepcionada);
		}

		this.service.salvarDuplicatasExcepcionadas(listaDuplicatasExcepcionadas, garantiaContrato);

		super.adicionaMensagemDeSucesso(ParametrizacaoContratoMB.OPERACAO_REALIZADA_SUCESSO);
	}

	/**
	 * <p>
	 * Método responsável por salvar Cheques Excepcionados.
	 * <p>
	 *
	 * @author guilherme.santos
	 */
	public void salvarChequesExcepcionados() {
		final Collection<ChequeExcepcionado> listaChequeExcepcionados = new ArrayList<>();

		final GarantiaContrato garantiaContrato = this.service.obterGarantiaContrato(this.getVisao().getIdentificadorExcepcionar());

		ChequeExcepcionado excepcionado;

		for (final ChequeExcepcionadoVO vo : this.getVisao().getChequesParaExcepcionar()) {
			excepcionado = new ChequeExcepcionado();

			excepcionado.setNuChequeExcepcionado(vo.getNuCheque());
			excepcionado.setCoCheque(vo.getCoCheque());
			excepcionado.setVrCheque(vo.getVrCheque());
			excepcionado.setDtEntrada(new Date());
			excepcionado.setGarantiaContrato(garantiaContrato);
			excepcionado.setCoResponsavel(UsuarioUtil.getUsuarioLogado().getNuMatricula().toString());

			listaChequeExcepcionados.add(excepcionado);
		}

		this.service.salvarChequesExcepcionados(listaChequeExcepcionados, garantiaContrato);

		super.adicionaMensagemDeSucesso(ParametrizacaoContratoMB.OPERACAO_REALIZADA_SUCESSO);
	}

	/**
	 * <p>
	 * Método responsável por verificar se a ultima atualização do faturamento da
	 * pessoa foi manual ou automática.
	 * <p>
	 *
	 * @author Caio Graco
	 */
	public void verificarSituacaoFaturamento() {
		final Pessoa pessoaSelecionada = this.getVisao().getContratoSelecionadoParaParametrizacao().getNuPessoa();

		if (pessoaSelecionada.getIcTipoEndividamento() == null || pessoaSelecionada.getIcTipoEndividamento().equals(TipoEndividamentoEnum.G)) {
			RequestContext.getCurrentInstance().execute("modalConfirmacaoPessoaManualWV.show();");
		} else {
			this.atualizarValorFaturamentoPessoa();
		}
	}

	/**
	 * <p>
	 * Método responsável por buscar as duplicatas da garantia delecionada.
	 * <p>
	 *
	 * @param idGarantia
	 *            valor a ser atribuido
	 * @author Caio Graco
	 */
	public void buscarDuplicatasGarantia(final Integer idGarantia) {

		final ParametrizacaoContratoVisao visao = this.getVisao();

		final Collection<DuplicataExcepcionada> duplicataContratos = this.service.listarDuplicatasPorGarantia(this.service.obter(idGarantia));

		visao.setDuplicatasEncontradas(new ArrayList<DuplicataVO>());
		visao.setDuplicataExcepcionada(new DuplicataExcepcionada());

		if (duplicataContratos.isEmpty()) {
			visao.setDuplicatasParaExcepcionar(new ArrayList<DuplicataVO>());
		} else {
			final Collection<DuplicataVO> vos = new ArrayList<>();
			DuplicataVO duplicataVO;

			for (final DuplicataExcepcionada duplicataExcepcionada : duplicataContratos) {
				duplicataVO = new DuplicataVO();

				duplicataVO.setCoNossoNumero(duplicataExcepcionada.getCoNossoNumero());
				duplicataVO.setNuDuplicata(duplicataExcepcionada.getNuDuplicata());
				duplicataVO.setVrDuplicata(duplicataExcepcionada.getVrDuplicata());

				vos.add(duplicataVO);
			}

			visao.setDuplicatasParaExcepcionar(vos);
		}
	}

	/**
	 * <p>
	 * Método responsável por buscar todos os cheques excepcionados da garantia.
	 * <p>
	 *
	 * @param idGarantia
	 *            valor a ser atribuido
	 * @author guilherme.santos
	 */
	public void buscarChequesExcepcionadosGarantia(final Integer idGarantia) {
		final Collection<ChequeExcepcionado> chequesExcepcionadosContrato = this.service.listarChequesPorGarantia(idGarantia);

		this.getVisao().setChequesExcepcionadosEncontrados(new ArrayList<ChequeExcepcionadoVO>());
		this.getVisao().setChequeExcepcionado(new ChequeExcepcionado());

		if (chequesExcepcionadosContrato.isEmpty()) {
			this.getVisao().setChequesParaExcepcionar(new ArrayList<ChequeExcepcionadoVO>());
		} else {
			final Collection<ChequeExcepcionadoVO> vos = new ArrayList<>();
			ChequeExcepcionadoVO chequeVO;

			for (final ChequeExcepcionado chequeExcepcionado : chequesExcepcionadosContrato) {
				chequeVO = new ChequeExcepcionadoVO();

				chequeVO.setNucheque(chequeExcepcionado.getNuChequeExcepcionado());
				chequeVO.setCoCheque(chequeExcepcionado.getCoCheque());
				chequeVO.setVrCheque(chequeExcepcionado.getVrCheque());

				vos.add(chequeVO);
			}

			this.getVisao().setChequesParaExcepcionar(vos);
		}
	}

	/**
	 * <p>
	 * Método responsável por remover duplicata excepcionada da lista.
	 * <p>
	 *
	 * @author Caio Graco
	 */
	public void removerDuplicataExcepcionada() {
		this.getVisao().getDuplicatasParaExcepcionar().remove(this.getVisao().getDuplicataVO());
	}

	/**
	 * <p>
	 * Método responsável por cheque excepcionado.
	 * <p>
	 *
	 * @author guilherme.santos
	 */
	public void removerChequeExcepcionado() {
		this.getVisao().getChequesParaExcepcionar().remove(this.getVisao().getChequeVO());
	}

	/**
	 * <p>
	 * Método responsável por adicionar uma forma de garantia.
	 * </p>
	 *
	 * @param evento
	 *            valor a ser atribuido
	 * @author joseroberto@gsgroup.com.br
	 */
	public void adicionarFormaGarantia(final ActionEvent evento) {
		final ParametrizacaoContratoVisao visao = this.getVisao();
		final FormaGarantiaEnum formaGarantiaSelecionada = visao.getEntidade().getIcFormaGarantia1();
		if (UtilObjeto.isReferencia(formaGarantiaSelecionada)) {
			if (formaGarantiaSelecionada.equals(FormaGarantiaEnum.PMT) || formaGarantiaSelecionada.equals(FormaGarantiaEnum.SALDO_DEVEDOR)) {
				if (formaGarantiaSelecionada.equals(FormaGarantiaEnum.PMT)) {
					visao.setFormaGarantia2List(EnumSet.of(FormaGarantiaEnum.SALDO_DEVEDOR));
				} else if (formaGarantiaSelecionada.equals(FormaGarantiaEnum.SALDO_DEVEDOR)) {
					visao.setFormaGarantia2List(EnumSet.of(FormaGarantiaEnum.PMT));
				}
				visao.setExibirNovaFormaGarantia(Boolean.TRUE);
			} else {
				visao.setExibirNovaFormaGarantia(Boolean.FALSE);
			}
		} else {
			visao.setExibirNovaFormaGarantia(Boolean.FALSE);
		}
	}

	/**
	 * <p>
	 * Método executado quando a garantia e selecionada.
	 * </p>
	 *
	 * @param evento
	 * @author Caio Graco
	 */
	public void onSelectIcGarantia() {
		final ParametrizacaoContratoVisao visao = this.getVisao();
		final Garantia garantia = this.getService().obterGarantiaPorCodigoOperacao(visao.getIdentificadorGarantia());

		visao.setGarantia(garantia);
		visao.setEntidade(new GarantiaContrato());
		visao.getEntidade().setDtParametrizacaoManual(new Date());
		visao.getEntidade().setNuContrato(this.getVisao().getContratoSelecionadoParaParametrizacao());
		visao.getEntidade().setGarantia(garantia);
		visao.setListaBemCliente(null);
		visao.setPessoaTerceiro(null);
		if (visao.getGarantia() != null) {
			visao.setCartoesSelecionados(null);
			if (this.fabricaCalculoGarantia.isGarantiaCartaoCreditoV2(this.getVisao().getEntidade())) {
				this.getContaCorrenteCartaoMB().getVisao().getListaContaCorrenteBandeiras().clear();
			}

			// Tratar Garantias
			this.Duplicata(visao.getGarantia());
			this.tratarAplicacaoFinanceira(visao.getGarantia());
			this.cartaoCredito(visao.getGarantia());
			this.Outros(visao.getGarantia());
			this.MaquinaEquipamento(visao.getGarantia());
			this.Veiculo(visao.getGarantia());
			this.Imovel(visao.getGarantia());
			this.FiancaBancaria(visao.getGarantia());
			this.Cheque(visao.getGarantia());
			this.tratarProdutosAgricolas(visao.getGarantia());
			this.EmpreendimentosRecebiveis(visao.getGarantia());
			this.EmpreendimentosHipoteca(visao.getGarantia());

			// Habilitar campos para edição
			visao.setExibirCamposEdicao(true);
			this.carregarFormaGarantia();
			visao.getEntidade().setIdentificadorFormaGarantia2(null);
			visao.getEntidade().setIcFormaGarantia2(null);
			visao.getEntidade().setVrFormaGarantia2(null);
			visao.setExibirNovaFormaGarantia(Boolean.FALSE);
			visao.setExibirBtnOu(Boolean.FALSE);
		} else {
			// Inicia a parametrização se a garantia for nula
			this.iniciarParametrizacao(visao);
		}
	}

	/**
	 * <p>
	 * Carrega as Formas de Garantia conforme o grupo de garantia.
	 * <p>
	 *
	 * @author Ludemeula Fernandes
	 */
	public void carregarFormaGarantia() {
		if (this.getVisao().getGarantia().isGrupoGarantia(GrupoGarantiaEnum.EMPREENDIMENTOS_HIPOTECA)
				|| this.getVisao().getGarantia().isGrupoGarantia(GrupoGarantiaEnum.EMPREENDIMENTOS_RECEBIVEIS)) {
			this.getVisao().setFormaGarantiaList(EnumSet.of(FormaGarantiaEnum.SALDO_DEVEDOR_SALDO_CREDOR));
		} else {
			this.getVisao()
					.setFormaGarantiaList(EnumSet.of(FormaGarantiaEnum.SALDO_DEVEDOR, FormaGarantiaEnum.PMT, FormaGarantiaEnum.VALOR_CONTRATO));
		}
	}

	/**
	 * <p>
	 * Método responsável por iniciar os dados da parametrização, exceto a lista de
	 * garantias.
	 * <p>
	 *
	 * @param visao
	 *            valor a ser atribuido
	 * @author Caio Graco
	 */
	private void iniciarParametrizacao(final ParametrizacaoContratoVisao visao) {
		this.limparDadosParametrizacao();
		this.ocultarCampos(false);
		this.desabilitarCampos(false);
		visao.setExibirCamposEdicao(false);
		visao.setDesabilitarComboGarantia(false);
	}

	/**
	 * <p>
	 * Método responsável por tratar os campos de Garantia Cartão.
	 * <p>
	 *
	 * @param garantia
	 *            valor a ser atribuido
	 * @author guilherme.santos
	 */
	private void cartaoCredito(final Garantia garantia) {
		if (garantia.isGrupoGarantia(GrupoGarantiaEnum.CARTAO_CREDITO)) {
			this.ocultarCamposCartaoCredito();
			this.getVisao().setExibirCartaoCredito(true);

			this.getVisao().getListaContaContratoCartao().clear();
			this.getVisao().getListaContaContratoCartao().addAll(this.contratoService
					.listarContaContratoCartaoCredito(this.getVisao().getContratoSelecionadoParaParametrizacao().getNuContrato()));

			if (this.fabricaCalculoGarantia.isGarantiaCartaoCreditoV2(this.getVisao().getEntidade())) {
				this.getContaCorrenteCartaoMB().getVisao().setEntidade(this.getVisao().getEntidade());
				this.getContaCorrenteCartaoMB().getVisao().setExibirBotaoIncluirGarantia(this.getVisao().isExibirBotaoIncluirGarantia());

				this.getContaCorrenteCartaoMB().getVisao().getListaContaContratoCartao().clear();
				this.getContaCorrenteCartaoMB().getVisao().getListaContaContratoCartao().addAll(this.getVisao().getListaContaContratoCartao());

				this.getContaCorrenteCartaoMB().getVisao().getListaBandeiraCartao().clear();
				this.getContaCorrenteCartaoMB().getVisao().getListaBandeiraCartao().addAll(this.getVisao().getListaBandeiraCartao());
			}

			this.montarArvoreCreditoPelaVersao();

		} else {
			this.getVisao().setExibirCartaoCredito(false);
		}
	}

	/**
	 * <p>
	 * Método responsável por montar a arvore de contas com as bandeiras verificando
	 * a versão.
	 * </p>
	 * .
	 *
	 * @author Mábio Barbosa
	 *
	 */
	private void montarArvoreCreditoPelaVersao() {
		if (this.fabricaCalculoGarantia.isGarantiaCartaoCreditoV2(this.getVisao().getEntidade())) {
			this.getContaCorrenteCartaoMB().montarArvoreCartaoCreditoV2();
		} else {
			this.montarArvoreCartaoCredito();
		}
	}

	/**
	 * <p>
	 * Método responsável por tratar os campos da Garantia Outros.
	 * <p>
	 *
	 * @param garantia
	 *            valor a ser atribuido
	 * @author guilherme.santos
	 */
	private void Outros(final Garantia garantia) {
		if (garantia.isGrupoGarantia(GrupoGarantiaEnum.OUTROS)) {

			this.getVisao().setCedenteIncluido(new Cedente());
			this.desabilitarCampos(false);
			this.ocultarCamposOutrasGarantias(garantia);

		}
	}

	private void EmpreendimentosRecebiveis(final Garantia garantia) {
		if (garantia.isGrupoGarantia(GrupoGarantiaEnum.EMPREENDIMENTOS_RECEBIVEIS)) {
			this.getVisao().setCedenteIncluido(new Cedente());
			this.desabilitarCampos(false);
			this.ocultarCamposEmpreendimentos(garantia);
			this.visao.setExibirBtnOu(Boolean.FALSE);
		}
	}

	private void EmpreendimentosHipoteca(final Garantia garantia) {
		if (garantia.isGrupoGarantia(GrupoGarantiaEnum.EMPREENDIMENTOS_HIPOTECA)) {
			this.getVisao().setCedenteIncluido(new Cedente());
			this.desabilitarCampos(false);
			this.ocultarCamposEmpreendimentos(garantia);
			this.visao.setExibirBtnOu(Boolean.FALSE);
		}
	}

	/**
	 * <p>
	 * Método responsável por tratar os campos de Máquinas e Equipamentos.
	 * <p>
	 *
	 * @param garantia
	 *            valor a ser atribuido
	 * @author guilherme.santos
	 */
	private void MaquinaEquipamento(final Garantia garantia) {
		if (garantia.isGrupoGarantia(GrupoGarantiaEnum.MAQUINAS_EQUIPAMENTOS)) {
			// if (this.getVisao().getEntidade().getMaquinaEquipamento() ==
			// null) {
			// this.getVisao().getEntidade().setMaquinaEquipamento(new
			// MaquinaEquipamento());
			// }
			this.ocultarCamposOutrasGarantias(garantia);
			// this.getVisao().setOcultarFormaGarantia(!garantia.getGrupoGarantia().isIcAcompanha()
			// || !getVisao().isGarantiaPassouSerAcompanhada());
		}
	}

	/**
	 * <p>
	 * Método responsável por tratar os campos da Garantia Veiculo.
	 * <p>
	 *
	 * @param garantia
	 *            valor a ser atribuido
	 * @author guilherme.santos
	 */
	private void Veiculo(final Garantia garantia) {
		if (garantia.isGrupoGarantia(GrupoGarantiaEnum.VEICULO)) {
			this.ocultarCamposOutrasGarantias(garantia);
		}
	}

	/**
	 * <p>
	 * Método responsável por tratar os campos da Garantia Imovel.
	 * <p>
	 *
	 * @param garantia
	 *            valor a ser atribuido
	 * @author guilherme.santos
	 */
	private void Imovel(final Garantia garantia) {
		if (garantia.isGrupoGarantia(GrupoGarantiaEnum.IMOVEL)) {
			this.ocultarCamposOutrasGarantias(garantia);
		}
	}

	/**
	 * <p>
	 * Método responsável por tratar os campos da Garantia Fiança Bancaria.
	 * <p>
	 *
	 * @param garantia
	 *            valor a ser atribuido
	 * @author guilherme.santos
	 */
	private void FiancaBancaria(final Garantia garantia) {
		if (garantia.isGrupoGarantia(GrupoGarantiaEnum.FIANCA_BANCARIA)) {
			this.ocultarCamposOutrasGarantias(garantia);
		}
	}

	/**
	 * <p>
	 * Método responsável por tratar os campos da Garantia Cheque.
	 * <p>
	 *
	 * @param garantia
	 *            valor a ser atribuido
	 * @author guilherme.santos
	 */
	private void Cheque(final Garantia garantia) {
		if (garantia.isGrupoGarantia(GrupoGarantiaEnum.CHEQUE)) {
			this.configurarCamposGarantiaCheque();

			// Recupera os parametros automaticos para os campos nulos, caso nao
			// seja uma edição
			if (this.visao.getParametrizacaoEdicao() == null) {
				this.recuperarParametrosCalculoCheque();
			}
		} else {
			this.getVisao().setExibirCheque(false);
		}
	}

	/**
	 * <p>
	 * Método responsável por habilitar/desabilitar e ocultar/mostrar campos para
	 * garantia CHEQUE.
	 * <p>
	 *
	 * @author guilherme.santos
	 */
	private void configurarCamposGarantiaCheque() {
		this.getVisao().setExibirCheque(true);
		this.ocultarCampos(false);
		this.getVisao().setOcultarPercentualMaximo(true);
		this.getVisao().setOcultarValor(true);
		this.getVisao().setOcultarInstrucaoProtesto(true);
		this.getVisao().getEntidade().setIcCaracteristica(CaracteristicaEnum.ESTOQUE);
		this.getVisao().setDesabilitarTipoGarantia(true);
	}

	/**
	 * <p>
	 * Método responsável por tratar os campos para Garantia Aplicação Financeira.
	 * <p>
	 *
	 * @param garantia
	 *            valor a ser atribuido
	 * @author guilherme.santos
	 */
	private void tratarAplicacaoFinanceira(final Garantia garantia) {
		if (garantia.isGrupoGarantia(GrupoGarantiaEnum.APLICACAO_FINANCEIRA)) {
			this.getVisao().getEntidade().setIcCaracteristica(CaracteristicaEnum.ESTOQUE);

			this.getVisao().setDesabilitarTipoGarantia(true);

			if (this.getVisao().getEntidade().getIcFormaGarantia1() == null) {
				this.getVisao().setExibirBtnOu(false);
			} else {
				this.getVisao().setExibirBtnOu(true);
			}

			this.ocultarCampos(true);

			this.getVisao().getListaContaContratoDasAplicacoes().clear();

			this.getVisao().getListaContaContratoDasAplicacoes().addAll(this.contratoService
					.listarContaContratoAplicacaoFinaceira(this.getVisao().getContratoSelecionadoParaParametrizacao().getNuContrato()));

			this.montarArvoreAplicacaoFinanceira();

		}
	}

	/**
	 * <p>
	 * Método responsável por tratar os campos para Garantia Duplicata.
	 * <p>
	 *
	 * @param garantia
	 *            valor a ser atribuido
	 * @author guilherme.santos
	 */
	private void Duplicata(final Garantia garantia) {
		if (garantia.isGrupoGarantia(GrupoGarantiaEnum.DUPLICATA)) {

			this.getVisao().getEntidade().setIcCaracteristica(null);
			this.getVisao().getEntidade().setIcFormaGarantia1(null);
			this.getVisao().setCedenteIncluido(new Cedente());

			this.desabilitarCampos(false);
			this.ocultarCampos(false);
			this.getVisao().setOcultarValor(true);

			// Recupera os parametros automaticos para os campos nulos, caso nao
			// seja uma edição
			if (this.visao.getParametrizacaoEdicao() == null) {
				this.recuperarParametrosCalculoDuplicata();
			}
		}
	}

	/**
	 * <p>
	 * Método responsável por tratar os campos de Produtos Agricolas.
	 * <p>
	 *
	 * @param garantia
	 *            valor a ser atribuido
	 * @author brunno antunes
	 */
	private void tratarProdutosAgricolas(final Garantia garantia) {
		if (garantia.isGrupoGarantia(GrupoGarantiaEnum.PRODUTOS_AGRICOLAS)) {
			this.getVisao().getEntidade().setProdutoAgricola(new ProdutoAgricola());
			this.ocultarCamposOutrasGarantias(garantia);
		}
	}

	/**
	 * <p>
	 * Método responsável por desabilitar os campos tipo garantia e forma garantia.
	 * <p>
	 *
	 * @param desabilitar
	 *            valor a ser atribuido
	 * @author Caio Graco
	 */
	public void desabilitarCampos(final boolean desabilitar) {
		this.getVisao().setDesabilitarTipoGarantia(desabilitar);
		this.getVisao().setDesabilitarFormaGarantia(desabilitar);
	}

	/**
	 * <p>
	 * Método responsável por renderizar ou não os campos da tela.
	 * <p>
	 *
	 * @param valor
	 *            valor a ser atribuido
	 * @author Caio Graco
	 */
	public void ocultarCampos(final boolean valor) {
		this.getVisao().setOcultarInstrucaoProtesto(valor);
		this.getVisao().setOcultarPercentualMaximo(valor);
		this.getVisao().setOcultarPrazoMaximo(valor);
		this.getVisao().setOcultarValor(valor);
		this.getVisao().setOcultarValorMaximo(valor);
		this.getVisao().setExibirAplicacaoFinanceira(valor);
		// Exceção para garantias diferentes de Cheque e Cartão
		this.getVisao().setOcultarTipoGarantia(false);
		this.getVisao().setOcultarFormaGarantia(false);
	}

	/**
	 * <p>
	 * Método responsável por tratar os campos da Garantia Cheque e Cartão.
	 * <p>
	 *
	 * @author guilherme.santos
	 */
	public void ocultarCamposCartaoCredito() {
		this.getVisao().setOcultarInstrucaoProtesto(true);
		this.getVisao().setOcultarTipoGarantia(false);
		this.getVisao().setOcultarFormaGarantia(false);
		this.getVisao().setExibirBtnOu(true);
		this.getVisao().setOcultarPercentualMaximo(true);
		this.getVisao().setOcultarPrazoMaximo(true);
		this.getVisao().setOcultarValor(true);
		this.getVisao().setOcultarValorMaximo(true);
		this.getVisao().setExibirAplicacaoFinanceira(false);
		this.getVisao().setDesabilitarTipoGarantia(false);
	}

    /**
     * <p>
     * Método responsável por tratar os campos da Garantia Outros.
     * <p>
     *
     * @author guilherme.santos
     */
    public void ocultarCamposOutrasGarantias(final Garantia garantia) {

	if (ParametrizacaoContratoServiceImpl.CESSAO_FIDUCIARIA_DE_DIREITOS_CREDITORIOS_OUTROS.equals(garantia.getCoOperacao())) {
	    this.getVisao().setOcultarInstrucaoProtesto(true);
	    this.getVisao().setOcultarPercentualMaximo(false);
	    this.getVisao().setOcultarPrazoMaximo(false);
	    this.getVisao().setOcultarValorMaximo(false);
	    this.getVisao().setOcultarTipoGarantia(false);
	    this.getVisao().setOcultarFormaGarantia(false);
	    this.getVisao().setOcultarValor(true);
	    this.getVisao().setExibirAplicacaoFinanceira(false);
	    this.getVisao().setExibirCheque(false);
	} else {
	    this.getVisao().setOcultarInstrucaoProtesto(true);
	    this.getVisao().setOcultarPercentualMaximo(true);
	    this.getVisao().setOcultarPrazoMaximo(true);
	    this.getVisao().setOcultarValorMaximo(true);
	    this.getVisao().setOcultarTipoGarantia(true);
	    this.getVisao().setOcultarFormaGarantia(!garantia.getGrupoGarantia().isIcAcompanha());
	    this.getVisao().setOcultarValor(false);
	    this.getVisao().setExibirAplicacaoFinanceira(false);
	    this.getVisao().setExibirCheque(false);
	}

    }

	/**
	 * 
	 * <p>
	 * Método responsável por tratar os campos da Garantia Empreendimentos
	 * </p>
	 * .
	 *
	 * @author p566506
	 *
	 * @param garantia
	 */
	public void ocultarCamposEmpreendimentos(final Garantia garantia) {
		this.getVisao().setOcultarInstrucaoProtesto(true);
		this.getVisao().setOcultarPercentualMaximo(true);
		this.getVisao().setOcultarPrazoMaximo(true);
		this.getVisao().setOcultarValorMaximo(true);
		this.getVisao().setOcultarTipoGarantia(true);
		this.getVisao().setOcultarFormaGarantia(!garantia.getGrupoGarantia().isIcAcompanha());
		this.getVisao().setOcultarValor(true);
		this.getVisao().setExibirAplicacaoFinanceira(false);
		this.getVisao().setExibirCheque(false);
	}

	/**
	 * <p>
	 * Método executado quando a combo de Caracteristica/Tipo Garantia e
	 * selecionada.
	 * </p>
	 *
	 * @param evento
	 * @author joseroberto@gsgroup.com.br / leandro.oliveira / narcieliton.lopes
	 * @dataAlteracao 2019/08/29 yyyy/MM/dd
	 */
	public void onSelectIcCaracteristica() {
		final ParametrizacaoContratoVisao visao = this.getVisao();

		if (visao.getGarantia().isGrupoGarantia(GrupoGarantiaEnum.CARTAO_CREDITO)
				|| (UtilObjeto.isReferencia(visao.getEntidade().getIcCaracteristica())
						&& visao.getEntidade().getIcCaracteristica().equals(CaracteristicaEnum.FLUXO)
						&& visao.getGarantia().isGrupoGarantia(GrupoGarantiaEnum.DUPLICATA))) {

			visao.setOcultarPrazoMaximo(Boolean.TRUE);
			visao.setOcultarValorMaximo(Boolean.TRUE);
			visao.setOcultarPercentualMaximo(Boolean.TRUE);
			visao.setOcultarInstrucaoProtesto(Boolean.TRUE);
			if (visao.getGarantia().isGrupoGarantia(GrupoGarantiaEnum.CARTAO_CREDITO)) {

				for (ContaCorrenteBandeirasVO contaCorrenteBandeira : this.getContaCorrenteCartaoMB().getVisao().getListaContaCorrenteBandeiras()) {
					for (GarantiaCartaoCredito garantiaCartaoCredito : contaCorrenteBandeira.getListaGarantiaCartaoCredito()) {
						if (garantiaCartaoCredito.isIcMarcado()) {
							garantiaCartaoCredito.setPcConcentracao(null);
							garantiaCartaoCredito.setVrConstituido(null);
							garantiaCartaoCredito.setIcMarcado(Boolean.FALSE);
						}
					}
				}
				this.getContaCorrenteCartaoMB().getVisao().setVrTotalPactuadaBandeirasGarantiaCartao(BigDecimal.ZERO);
				this.getContaCorrenteCartaoMB().getVisao().setVrTotalDiferencaPercentualBandeirasContas(BigDecimal.ZERO);
			}
		} else {
			visao.setOcultarPrazoMaximo(Boolean.FALSE);
			visao.setOcultarValorMaximo(Boolean.FALSE);
			visao.setOcultarPercentualMaximo(Boolean.FALSE);
			visao.setOcultarInstrucaoProtesto(Boolean.FALSE);
		}

		visao.setOcultarFormaGarantia(Boolean.FALSE);
		visao.getEntidade().setVrGarantia(null);
		visao.setExibirBtnOu(Boolean.TRUE);
		visao.setExibirNovaFormaGarantia(Boolean.FALSE);
		visao.getEntidade().setVrFormaGarantia1(null);
		visao.getEntidade().setIcFormaGarantia2(null);
		visao.getEntidade().setVrFormaGarantia2(null);

	}

	/**
	 * 
	 * <p>
	 * Método responsável por validar a adição da composição de garantia
	 * </p>
	 * .
	 * 
	 * @param parametrizacao
	 *
	 * @return TRUE caso passe na validação, FALSE caso contrário.
	 */
	private boolean validarAdicionar(final ParametrizacaoContratoVO parametrizacao) {
		this.getService().validarDadosParametrizacaoContrato(this.getVisao().getEntidade(), this.getVisao().getListaCedentes(),
				this.getVisao().getListaContaContratoCheque(), this.visao.getEntidade().getListaGarantiaCartaoCredito());

		// Caso não tenha passado na validação apresenta mensagem e retorna para
		// mesma tela
		if (this.getVisao().getEntidade().hasMensagens()) {
			super.adicionaListaMensagemDeAlerta(this.getVisao().getEntidade().getMensagens());
			return Boolean.FALSE;
		}

		// Valida a inclusao de duplicatas do mesmo tipo
		final Boolean isDuplicatasAdicionadasMesmoTipo = this.service.validarDuplicatasAdicionadasMesmoTipo(this.getVisao().getParametrizacaoList(),
				this.getVisao().getEntidade());

		if (isDuplicatasAdicionadasMesmoTipo && !this.getVisao().isEditing()) {
			super.adicionaMensagemInformativa(ParametrizacaoContratoMB.DUPLICATAS_ADICIONADAS_MESMO_TIPO);
			return Boolean.FALSE;
		}

		return Boolean.TRUE;
	}

	/**
	 * 
	 * <p>
	 * Método responsável por parametrizar contrato.
	 * </p>
	 * .
	 *
	 * @author joseroberto@gsgroup.com.br
	 * @author Ronnie Mikihiro
	 * @author Mábio Barbosa
	 *
	 * @return String
	 */
	public String adicionar() {
		// Se o objeto de edicao nao for nulo significa que é uma edição
		final ParametrizacaoContratoVO parametrizacao = this.getVisao().getParametrizacaoEdicao() != null ? this.getVisao().getParametrizacaoEdicao()
				: new ParametrizacaoContratoVO();

		this.atualizarParamentrizacaoContratoVO(this.getVisao());

		if (this.validarAdicionar(parametrizacao)) {
			// Preenche os dados basicos da garantia parametrizada
			
			parametrizacao.setGarantiaContrato(this.getVisao().getEntidade());

			this.adicionaParametrizacaoListCasoNaoExista(parametrizacao);
			super.adicionaMensagemDeSucesso(ParametrizacaoContratoMB.OPERACAO_REALIZADA_SUCESSO);
			this.limparVisao();
			this.getVisao().setParametrizacaoContratoVOTemp(null);
			this.getVisao().setExibirCamposEdicao(false);
			this.getVisao().setDesabilitarComboGarantia(false);
			this.getVisao().setEditing(false);
			getVisao().setGarantiaContratoClone(null);
		}

		return super.MESMA_TELA;
	}

	private void adicionarValorConsumido() {
		//ow, desculpa por esse codigo, era domingo e e eu tava podre de cansada :'( FIXME
		if (getVisao().getEntidade().isGarantiaImovel()) {
			for (GarantiaBemCliente garantia : getVisao().getEntidade().getBens()) {
				if (garantia.isIcMarcado()) {
					if (getVisao().getValorUtilizadoOutrasGarantias().containsKey(garantia.getBemCliente().getNuBemCliente())) {
						BigDecimal vrOutrasGarantias = getVisao().getValorUtilizadoOutrasGarantias().get(garantia.getBemCliente().getNuBemCliente());
						
						getVisao().getValorUtilizadoOutrasGarantias().put(garantia.getBemCliente().getNuBemCliente(), vrOutrasGarantias.add(garantia.getVrUtilizado()));
					} else {
						getVisao().getValorUtilizadoOutrasGarantias().put(garantia.getBemCliente().getNuBemCliente(), garantia.getVrUtilizado());
					}
				}
			}
		}
	}

	/**
	 * <p>
	 * Método responsável por adicionar {@link ParametrizacaoContratoVO} na
	 * parametrizacaoList caso ainda não exista
	 * </p>
	 * .
	 *
	 * @param parametrizacao
	 * @return Retorna true caso a Parametrização tiver sido adicionada com sucesso.
	 */
	private void adicionaParametrizacaoListCasoNaoExista(final ParametrizacaoContratoVO parametrizacao) {

		if (null != this.getVisao().getEntidade() && null != this.getVisao().getEntidade().getIcCaracteristica()) {
			parametrizacao.getGarantiaContrato().setIdentificadorCaracteristica(this.getVisao().getEntidade().getIcCaracteristica().getValor());
		}
		// Remover da lista objeto editado
		if (!this.getVisao().isEditing()) {
			adicionarValorConsumido();
			
			this.getVisao().getParametrizacaoList().add(parametrizacao);
		} else {
			alterarValorConsumido();
		}
	}

	private void alterarValorConsumido() {
		
		//ow, desculpa por esse codigo, era domingo e e eu tava podre de cansada :'( FIXME
		if (getVisao().getEntidade().isGarantiaImovel()) {
			for (GarantiaBemCliente garantia : getVisao().getEntidade().getBens()) {
				if (garantia.isIcMarcado()) {
					
					for (GarantiaBemCliente garantiaClone : getVisao().getGarantiaContratoClone().getBens()) {
						if (garantiaClone.getBemCliente().getNuBemCliente().equals(garantia.getBemCliente().getNuBemCliente())) {
							BigDecimal valorOutrasGarantiasClone = garantiaClone.getVrUtilizado();
							
							if (getVisao().getValorUtilizadoOutrasGarantias().containsKey(garantia.getBemCliente().getNuBemCliente())) {
								BigDecimal valorOutrasGarantias = getVisao().getValorUtilizadoOutrasGarantias().get(garantia.getBemCliente().getNuBemCliente());
								
								getVisao().getValorUtilizadoOutrasGarantias().put(garantia.getBemCliente().getNuBemCliente(), valorOutrasGarantias.subtract(
										valorOutrasGarantiasClone.subtract(garantia.getSaldoDisponivel()).negate()));
							} else {
								getVisao().getValorUtilizadoOutrasGarantias().put(garantia.getBemCliente().getNuBemCliente(), valorOutrasGarantiasClone.subtract(garantia.getSaldoDisponivel()).negate());
							}
						}
					}
				} else {
					if (getVisao().getValorUtilizadoOutrasGarantias().containsKey(garantia.getBemCliente().getNuBemCliente())) {
						BigDecimal valorOutrasGarantias = getVisao().getValorUtilizadoOutrasGarantias().get(garantia.getBemCliente().getNuBemCliente());
						
						getVisao().getValorUtilizadoOutrasGarantias().put(garantia.getBemCliente().getNuBemCliente(), valorOutrasGarantias.subtract(BigDecimal.ZERO));
					} else {
						getVisao().getValorUtilizadoOutrasGarantias().put(garantia.getBemCliente().getNuBemCliente(), BigDecimal.ZERO);
					}
				}
			}
		}
	}

	/**
	 * <p>
	 * Método responsável por atualizar os dados da visão com as informações em
	 * tela.
	 * <p>
	 *
	 * @param visao
	 *            valor a ser atribuido
	 * @author Leandro S. Oliveira
	 */
	private void atualizarParamentrizacaoContratoVO(final ParametrizacaoContratoVisao visao) {
		// Se na garantiacontrato não tiver a garantia então adiciona
		if (!UtilObjeto.isReferencia(visao.getEntidade().getGarantia())) {
			visao.getEntidade().setGarantia(this.service.obterGarantiaPorCodigoOperacao(visao.getIdentificadorGarantia()));
		}

		// Preenche lista de cedentes da parametrizacao com os cedentes
		// selecionados
		if (visao.getEntidade().isGarantiaDuplicata() || visao.getEntidade().isGarantiaHabitacional() || visao.getEntidade().isGarantiaOutros()) {
			visao.getEntidade().setCedenteList(visao.getCedentesSelecionados());
		}
		// Limpa os campos para garantia Aplicação Financeira, Outros e Cartão
		// de Credito
	if (visao.getEntidade().isGarantiaAplicacaoFinanceira()
		|| (visao.getEntidade().isGarantiaOutros() && !ParametrizacaoContratoServiceImpl.CESSAO_FIDUCIARIA_DE_DIREITOS_CREDITORIOS_OUTROS
			.equals(visao.getEntidade().getGarantia().getCoOperacao()))
				|| visao.getEntidade().isGarantiaCartaoCredito() || visao.getEntidade().isGarantiaMaquinaEquipamento()
				|| visao.getEntidade().isGarantiaVeiculo() || visao.getEntidade().isGarantiaImovel()
		|| visao.getEntidade().isGarantiaFiancaBancaria()) {
		   
			visao.getEntidade().setVrPrazoMaximoPermitido(null);
			visao.getEntidade().setVrMaximoPermitido(null);
			visao.getEntidade().setVrPercentualMaximoCncno(null);
			
		}
		// Limpa campos para garantia Cheque
		if (visao.getEntidade().isGarantiaCheque()) {
			visao.getEntidade().setVrPercentualMaximoCncno(null);
		}

		// Preenche a lista com as garantias aplicação selecionadas
		if (visao.getEntidade().isGarantiaAplicacaoFinanceira()) {
			visao.getEntidade().setListGarantiaAplicacao(this.getListaGarantiaAplicacaoSelecionadas());
		}

		FabricaCalculoGarantia fabricaCalculoGarantia = this.fabricaCalculoGarantia;
		// Preenche a lista com as GarantiaCartaoCredito selecionadas
		if (visao.getEntidade().isGarantiaCartaoCredito()) {
			visao.getEntidade().getListaGarantiaCartaoCredito().clear();
			visao.getEntidade().getListaGarantiaCartaoCreditoTodosV2().clear();

			if (fabricaCalculoGarantia.isGarantiaCartaoCreditoV2(visao.getEntidade())) {
				visao.getEntidade().getListaGarantiaCartaoCredito()
						.addAll(this.getContaCorrenteCartaoMB().getListaGarantiaCartaoCreditoSelecionadosV2());
			} else {
				visao.getEntidade().getListaGarantiaCartaoCredito().addAll(this.getListaGarantiaCartaoCreditoSelecionados());
			}
		}
	}

	/**
	 * <p>
	 * Método responsável por tratar o enum da garantia e retornar a descrição do
	 * grupo da garantia.
	 * <p>
	 *
	 * @param grupoGarantia
	 *            valor a ser atribuido
	 * @return string
	 * @author Caio Graco
	 */
	public String tratarGrupoGarantia(final GrupoGarantia grupoGarantia) {
		if (grupoGarantia != null) {
			return GrupoGarantiaEnum.obterDescricao(GrupoGarantiaEnum.obterDeValor(grupoGarantia.getNuGrupoGarantia()));
		}
		return "";
	}

	/**
	 * <p>
	 * Método responsável por cancelar a edição da garantia.
	 * <p>
	 *
	 * @author Caio Graco
	 */
	public void cancelarEdicao() {
		this.popularComboGarantia();
		this.popularComboTipoParcela();
		this.limparDadosParametrizacao();
		this.ocultarCampos(false);
		this.desabilitarCampos(false);
		this.getVisao().setExibirCamposEdicao(false);
		this.getVisao().setDesabilitarComboGarantia(false);
		this.verificarPermissoes();
		this.getVisao().setEntidade(new GarantiaContrato());
		this.getVisao().setEditing(false);
		this.setMsgAlert(null);
	}

	/**
	 * <p>
	 * Método responsável por limpar os dados da tela de uma parametrização para o
	 * contrato.
	 * </p>
	 *
	 * @author joseroberto@gsgroup.com.br
	 *
	 */
	public void limparDadosParametrizacao() {
		this.limparVisao();
		
		this.getContaCorrenteCartaoMB().getVisao().getListaContaCorrenteBandeiras().clear();
	}
	
	private void limparVisao() {
		final ParametrizacaoContratoVisao visao = this.getVisao();
		visao.setIdentificadorGarantia(null);
		visao.setEntidade(new GarantiaContrato());
		visao.setIdentificadorEdicao(null);
		visao.setIdentificadorRemocao(null);
		visao.setParametrizacaoEdicao(null);
		visao.setDesabilitarCampos(Boolean.FALSE);
		visao.setExibirNovaFormaGarantia(Boolean.FALSE);
		visao.setExibirBtnOu(Boolean.FALSE);
		visao.setExibirModalValidacao(Boolean.FALSE);
		visao.setExibirModalExclusao(Boolean.FALSE);
		// Aplicação Financeira
		visao.setListaAplicacaoSelecionadas(new ArrayList<GarantiaAplicacao>());
		visao.setExibirAplicacaoFinanceira(Boolean.FALSE);
		visao.setContaContratoAplicacaoFinanceira(new ContaContrato());
		visao.getContaContratoAplicacaoFinanceira().setNuConta(new ContaCorrente());
		visao.getContaContratoAplicacaoFinanceira().getNuConta().setId(new ContaCorrenteID());
		// Cheque
		visao.setExibirCheque(Boolean.FALSE);
		visao.setContaContratoCheque(new ContaContrato());
		visao.getContaContratoCheque().setNuConta(new ContaCorrente());
		visao.getContaContratoCheque().getNuConta().setId(new ContaCorrenteID());
		// Cartao de credito
		visao.setExibirCartaoCredito(Boolean.FALSE);
		visao.setContaContratoCartao(new ContaContrato());
		visao.getContaContratoCartao().setNuConta(new ContaCorrente());
		visao.getContaContratoCartao().getNuConta().setId(new ContaCorrenteID());

		// Maquina Equipamento
		visao.setNuMaquinaEquipamento(null);
		visao.setNuVeiculoAcompanhado(null);
	}

	/**
	 *
	 * <p>
	 * Método responsável por limpar os dados da tela de uma parametrização para o
	 * contrato ao carregar os dados.
	 * <p>
	 *
	 * @author Ronnie Mikihiro
	 */
	private void limparDadosParametrizacaoAoCarregar() {
		final ParametrizacaoContratoVisao visao = this.getVisao();
		visao.setEntidade(new GarantiaContrato());
		visao.setIdentificadorEdicao(null);
		visao.setIdentificadorRemocao(null);
		visao.setDesabilitarCampos(Boolean.FALSE);
		visao.setExibirNovaFormaGarantia(Boolean.FALSE);
		visao.setExibirBtnOu(Boolean.FALSE);
		visao.setExibirModalValidacao(Boolean.FALSE);
		visao.setExibirModalExclusao(Boolean.FALSE);
		visao.setSacadoExcepcionado(new SacadoExcepcionadoVO());
		visao.setSacadosParaExcepcionar(new ArrayList<SacadoExcepcionadoVO>());
	}

	/**
	 * <p>
	 * Método responsável por remover uma parametrização do contrato.
	 * </p>
	 *
	 * @param evento
	 *            valor a ser atribuido
	 * @return String
	 * @author joseroberto@gsgroup.com.br
	 */
	public String remover(final ActionEvent evento) {
		for (final ParametrizacaoContratoVO parametrizacao : getVisao().getParametrizacaoList()) {
			if (parametrizacao.getIdentificador().equals(getVisao().getIdentificadorRemocao())) {
				getVisao().getListaExclusaoParametrizacao().add(parametrizacao);
				getVisao().getParametrizacaoList().remove(parametrizacao);
				
				removerValorConsumido(parametrizacao);
				
				break;
			}
		}
		super.adicionaMensagemInformativa(ParametrizacaoContratoMB.OPERACAO_REALIZADA_SUCESSO);
		this.limparDadosParametrizacao();
		return super.MESMA_TELA;
	}

	private void removerValorConsumido(final ParametrizacaoContratoVO parametrizacao) {
		//ow, desculpa por esse codigo, era domingo e e eu tava podre de cansada :'( FIXME
		if (parametrizacao.getGarantiaContrato().isGarantiaImovel()) {
			for (GarantiaBemCliente garantia : parametrizacao.getGarantiaContrato().getBens()) {
				if (garantia.isIcMarcado()) {
					
					if (getVisao().getValorUtilizadoOutrasGarantias().containsKey(garantia.getBemCliente().getNuBemCliente())) {
						BigDecimal valorOutrasGarantias = getVisao().getValorUtilizadoOutrasGarantias().get(garantia.getBemCliente().getNuBemCliente());
						
						getVisao().getValorUtilizadoOutrasGarantias().put(garantia.getBemCliente().getNuBemCliente(), valorOutrasGarantias.subtract(garantia.getVrUtilizado()));
					} else {
						getVisao().getValorUtilizadoOutrasGarantias().put(garantia.getBemCliente().getNuBemCliente(), garantia.getVrUtilizadoOutrasGarantias().subtract(garantia.getVrUtilizado()));
					}
				}
			}
		}
	}

	/**
	 * 
	 * <p>
	 * Método responsável por editar uma parametrização.
	 * </p>
	 *
	 * @author joseroberto@gsgroup.com.br
	 * @author Ronnie Mikihiro
	 * @author Leandro Santos Oliveira
	 * @author Mábio Barbosa
	 *
	 * @param parametrizacaoEdicao
	 * @return String
	 */
	public String carregaDadosGarantiaContratoEdicao(final ParametrizacaoContratoVO parametrizacaoEdicao) {
		final ParametrizacaoContratoVisao visao = this.getVisao();
		visao.setCartoesSelecionados(null);
		final GarantiaContrato garantiaContratoClonado = UtilObjeto.clone(parametrizacaoEdicao.getGarantiaContrato());
		
		getVisao().setGarantiaContratoClone(SerializationUtils.clone(parametrizacaoEdicao.getGarantiaContrato()));

		visao.setEntidade(garantiaContratoClonado);
		visao.setGarantia(garantiaContratoClonado.getGarantia());
		visao.setIdentificadorGarantia(garantiaContratoClonado.getGarantia().getCoOperacao());
		visao.setParametrizacaoEdicao(parametrizacaoEdicao);
		this.getVisao().setListaAplicacaoSelecionadas(garantiaContratoClonado.getListGarantiaAplicacao());
		

		this.adicionarCendentesGarantia(garantiaContratoClonado);

		final boolean isExibirNovaFormaGarantiaEBthOu = this.isExibirNovaFormaGarantiaEBthOu(garantiaContratoClonado);
		visao.setExibirNovaFormaGarantia(isExibirNovaFormaGarantiaEBthOu);
		visao.setExibirBtnOu(isExibirNovaFormaGarantiaEBthOu);

		if (garantiaContratoClonado.isGarantiaDuplicata()) {
			this.desabilitarCampos(Boolean.FALSE);
			this.ocultarCampos(Boolean.FALSE);
			this.getVisao().setOcultarValor(Boolean.TRUE);

			if (CaracteristicaEnum.FLUXO.equals(garantiaContratoClonado.getIcCaracteristica())) {
				visao.setOcultarPrazoMaximo(Boolean.TRUE);
				visao.setOcultarValorMaximo(Boolean.TRUE);
				visao.setOcultarPercentualMaximo(Boolean.TRUE);
				visao.setOcultarInstrucaoProtesto(Boolean.TRUE);
			}
		}

		// Habilita Forma Garantia 2 se existir
		if (garantiaContratoClonado.getIcFormaGarantia2() == null && garantiaContratoClonado.getVrFormaGarantia2() == null) {
			this.getVisao().setExibirNovaFormaGarantia(Boolean.FALSE);
		}

		// Tratar Garantias
		this.tratarAplicacaoFinanceira(garantiaContratoClonado.getGarantia());
		this.cartaoCredito(garantiaContratoClonado.getGarantia());
		this.Outros(garantiaContratoClonado.getGarantia());
		this.MaquinaEquipamento(garantiaContratoClonado.getGarantia());
		this.Veiculo(garantiaContratoClonado.getGarantia());
		this.Imovel(garantiaContratoClonado.getGarantia());
		this.FiancaBancaria(garantiaContratoClonado.getGarantia());
		this.Cheque(garantiaContratoClonado.getGarantia());
		this.tratarProdutosAgricolas(garantiaContratoClonado.getGarantia());
		this.EmpreendimentosRecebiveis(visao.getGarantia());
		this.EmpreendimentosHipoteca(visao.getGarantia());

		// Habilita os campos para serem mostrados.
		this.getVisao().setExibirCamposEdicao(Boolean.TRUE);
		// Desabilita a combo de garantias
		this.getVisao().setDesabilitarComboGarantia(Boolean.TRUE);

		if (CollectionUtils.isNotEmpty(garantiaContratoClonado.getListGarantiaProdAgricola())) {
			garantiaContratoClonado.setProdutoAgricola(
					garantiaContratoClonado.getListGarantiaProdAgricola().iterator().next().getGarantiaProdutoAgricolaID().getProdutoAgricola());
		}

		if (UtilObjeto.isReferencia(garantiaContratoClonado.getBemCliente())
				&& UtilObjeto.isReferencia(garantiaContratoClonado.getBemCliente().getMaquinaEquipamento())) {
			this.getVisao().setNuMaquinaEquipamento(garantiaContratoClonado.getBemCliente().getMaquinaEquipamento().getNuMaquinaEquipamento());
		}

		if (!UsuarioUtil.contemPermissao(NoFuncionalidadeEnum.PARAMETRIZA_CONTRATO_GARANTIA_CONTRATO.getNoFuncionalidade(),
				EnumAcao.INCLUIR.getNoAcao(), null, null) || !this.verificarMesmoSegmentoPessoa()) {
			this.getVisao().setDesabilitarTipoGarantia(Boolean.TRUE);
			this.getVisao().setDesabilitarCampos(Boolean.TRUE);
			this.getVisao().setDesabilitarFormaGarantia(Boolean.TRUE);
		}

		if (UtilObjeto.isReferencia(garantiaContratoClonado.getBemCliente())
				&& UtilObjeto.isReferencia(garantiaContratoClonado.getBemCliente().getVeiculo())) {
			this.getVisao().setNuVeiculoAcompanhado(garantiaContratoClonado.getBemCliente().getVeiculo().getNuVeiculo());

		}

		if (garantiaContratoClonado.isGarantiaImovel()) {
			montarListaGarantiaBemCliente();
		}

		this.carregarFormaGarantia();
		this.getVisao().setEditing(Boolean.TRUE);

		return null;
	}

	/**
	 * <p>
	 * Método responsável por verificar se deve exibir a Nova Forma Garantia e o
	 * botão Ou
	 * </p>
	 * .
	 *
	 * @param garantiaContratoClonado
	 * @return boolean
	 */
	private boolean isExibirNovaFormaGarantiaEBthOu(final GarantiaContrato garantiaContratoClonado) {
		return UtilObjeto.isReferencia(garantiaContratoClonado.getIcFormaGarantia2())
				|| (UtilObjeto.isReferencia(garantiaContratoClonado) && UtilObjeto.isReferencia(garantiaContratoClonado.getIcFormaGarantia1())
						&& (garantiaContratoClonado.getIcFormaGarantia1().equals(FormaGarantiaEnum.SALDO_DEVEDOR)
								|| garantiaContratoClonado.getIcFormaGarantia1().equals(FormaGarantiaEnum.PMT)));
	}

	/**
	 * <p>
	 * Método responsável por adicionar os Cedentes não existentes na lista.
	 * <p>
	 *
	 * @param garantiaContratoClonado
	 *            valor a ser atribuido
	 * @author guilherme.santos
	 */
	private void adicionarCendentesGarantia(final GarantiaContrato garantiaContratoClonado) {
		for (final Cedente cedenteGarantia : garantiaContratoClonado.getCedenteList()) {
			boolean cedenteEncontrado = false;

			cedenteGarantia.setUtilizado(Boolean.TRUE);

			for (final Cedente cedentePessoa : this.getVisao().getListaCedentes()) {
				if (cedenteGarantia.getCoCedente().equals(cedentePessoa.getCoCedente())) {
					cedentePessoa.setUtilizado(cedenteGarantia.isUtilizado());
					cedenteEncontrado = true;
					break;
				}
			}

			if (!cedenteEncontrado) {
				this.getVisao().getListaCedentes().add(cedenteGarantia);
			}
		}
	}

	/**
	 * 
	 * <p>
	 * Método responsável por validar a parametrização.
	 * </p>
	 * .
	 *
	 * @author joseroberto@gsgroup.com.br
	 * @author Mábio Barbosa
	 *
	 * @param contrato
	 * @return TRUE se estiver ok, FALSE caso contrário.
	 */
	private boolean validaSalvarParametrizacao(final Contrato contrato) {
		this.getVisao().setExibirModalOperacaoRealizadaComSucesso(Boolean.FALSE);
		
        	if (contrato.isIcTratamentoEspecial()) {
        
        	    final String deMotivo = contrato.getDeMotivoTratamentoEspecial();
        	    if (UtilString.isVazio(deMotivo) || deMotivo.trim().length() < 2) {
        		this.adicionaMensagemDeAlerta("Informe o Motivo do Tratamento Especial.");
        		return Boolean.FALSE;
        
        	    } else {
        		contrato.setDeMotivoTratamentoEspecial(deMotivo.trim());
        	    }
        
        	}

		if (!this.validaContratohabitacional(contrato)) {
			this.adicionaMensagemDeErroDeSistema("MN054");
			return Boolean.FALSE;
		}

		this.validaCedentesHabitacionais(contrato);

		this.atualizarParamentrizacaoContratoVO(this.getVisao());

		if (this.verificarAltercaoVrFaturamento()) {
			this.atualizarPessoa();
			this.service.gerarHistoricoFaturamentoPessoa(this.getVisao().getContratoSelecionadoParaParametrizacao().getNuPessoa(),
					TipoEndividamentoEnum.G);
		}

		this.getVisao().getListaSacadosAlterados()
				.addAll(this.converterListaSacadoExcepcionadoVOEmListaSacadoExcepcionado(this.getVisao().getSacadosParaExcepcionar()));

		if (!this.validarComposicaoGarantias(this.getVisao())) {
			return Boolean.FALSE;
		}

		if (!this.contratoService.validarContratoParametrizacao(this.getVisao().getContratoSelecionadoParaParametrizacao())) {
			this.adicionaListaMensagemDeErro(this.getVisao().getContratoSelecionadoParaParametrizacao().getMensagens());
			return Boolean.FALSE;
		}

		this.getVisao().setExibirModalOperacaoRealizadaComSucesso(Boolean.TRUE);
		return Boolean.TRUE;
	}

	/**
	 * <p>
	 * Método responsável por salvar a parametrização.
	 * </p>
	 *
	 * @return String
	 * @author joseroberto@gsgroup.com.br
	 */
	public String salvarParametrizacao() {
		final Contrato contratoSelecParametrizacao = this.getVisao().getContratoSelecionadoParaParametrizacao();
		this.getVisao().setExibirModalValidacao(Boolean.FALSE);

		if (this.validaSalvarParametrizacao(contratoSelecParametrizacao)) {
			try {
				this.contratoService.alterar(contratoSelecParametrizacao);

				this.service.salvarParametrizacao(this.getVisao().getParametrizacaoList(), this.getVisao().getListaExclusaoParametrizacao(),
						contratoSelecParametrizacao, this.getVisao().getListaContaContrato(), this.getVisao().getListaContaContratoDasAplicacoes(),
						this.getVisao().getListaContaContratoCheque(), this.getVisao().getListaContaContratoCartao());

				this.service.removerSacadosExcepcionados(this.getVisao().getSacadosExcepcionadosRemover());

				final String message = this.service.salvarSacadosExcepcionados(this.getVisao().getListaSacadosAlterados());
				if (!UtilString.isVazio(message)) {
					this.getVisao().setExibirModalOperacaoRealizadaComSucesso(Boolean.FALSE);
					super.adicionaMensagemDeAlerta("MA003");
					return "";
				}

				if (contratoSelecParametrizacao.hasMensagens()) {
					super.adicionaListaMensagemDeAlerta(contratoSelecParametrizacao.getMensagens());
				}

				this.getVisao().setMensagemSalvarParametrizacao(
						MensagensUtil.getMensagem(this.getNomeVarResourceBundle(), ParametrizacaoContratoMB.OPERACAO_REALIZADA_SUCESSO));
				this.adicionaMensagemAlertaAuxiliar();
				
				getVisao().setValorUtilizadoOutrasGarantias(new HashMap<Integer, BigDecimal>());

			} catch (final RuntimeException e) {
				this.getVisao().setMensagemSalvarParametrizacao(
						MensagensUtil.getMensagem(this.getNomeVarResourceBundle(), ParametrizacaoContratoMB.OPERACAO_REALIZADA_ERRO));
				LogCEF.error("Erro ao salvar a parametrização do contrato " + contratoSelecParametrizacao.getNuContrato() + ": " + e.getMessage());
				LogCEF.error(e);
			}
		}

		return super.MESMA_TELA;
	}

	private void adicionaMensagemAlertaAuxiliar() {
		// Caso contenha garantias de aplicação financeira, cria mensagem
		if (this.verificarSeExisteGarantiaAplicacaoFinanceira()) {
			this.adicionaMensagemDeAlerta("uc_parametrizacao_contrato_msg_calculo_aplicacao_financeira_d_mais_1");
		}
		// Caso seja Tratamento especial, cria mensagem
		if (this.getVisao().getContratoSelecionadoParaParametrizacao().isIcTratamentoEspecial()) {
			this.adicionaMensagemDeAlerta("info_tratamento_especial");
		}
	}

	/**
	 * 
	 * <p>
	 * Método responsável por validar a Composicão das garantias antes de salvar.
	 * </p>
	 * .
	 *
	 * @author Mábio Barbosa
	 *
	 * @param visao
	 * @return TRUE caso as garantias estejam válidas, FALSE caso contrário.
	 */
	private boolean validarComposicaoGarantias(final ParametrizacaoContratoVisao visao) {
		for (final ParametrizacaoContratoVO pVO : visao.getParametrizacaoList()) {
			this.adicionarCendentesGarantia(pVO.getGarantiaContrato());

			this.getService().validarDadosParametrizacaoContrato(pVO.getGarantiaContrato(), visao.getListaCedentes(),
					visao.getListaContaContratoCheque(), pVO.getGarantiaContrato().getListaGarantiaCartaoCredito());

			// Caso não tenha passado na validação apresenta mensagem e retorna
			// para mesma tela
			if (pVO.getGarantiaContrato().hasMensagens()) {
				super.adicionaMensagemDeAlerta("MN061", pVO.getGarantiaContrato().getGarantia().getNoGarantia());
				this.limparDadosParametrizacao();
				visao.setExibirModalOperacaoRealizadaComSucesso(Boolean.FALSE);
				return Boolean.FALSE;
			} else {
				this.limparDadosParametrizacao();
			}
		}

		return Boolean.TRUE;
	}

	/**
	 * <p>
	 * Método responsável por verificar os Atributos do Empreendimento e atualizar
	 * em Empreendimentos de acordo com que esta preenchido e alterações realizadas;
	 * 
	 * @author Winston
	 *
	 * @param contrato
	 */
	private boolean validaContratohabitacional(final Contrato contrato) {
		if (contrato.getIcCategoria() == ParametrizacaoContratoMB.CONTRATO_HABITACIONAL) {
			if (contrato.getEmpreendimento() == null || UtilString.isVazio(contrato.getEmpreendimento().getNoEmpreendimento())) {
				return false;
			}

			this.empreendimentoService.alterar(contrato.getEmpreendimento());
		}

		return true;
	}

	/**
	 * 
	 * <p>
	 * Método responsável por verificar se é contrato do tipo habitacional e se
	 * exite cedente pra salvar na parametrização e salva
	 * </p>
	 * .
	 * 
	 * @author f799837
	 *
	 * @param contrato
	 * @return
	 */
	private boolean validaCedentesHabitacionais(final Contrato contrato) {
		if (contrato.getIcCategoria() == ParametrizacaoContratoMB.CONTRATO_HABITACIONAL) {
			if (contrato.getEmpreendimento() == null || UtilString.isVazio(contrato.getEmpreendimento().getNoEmpreendimento())
					|| this.visao.getCedentesSelecionados().isEmpty()) {
				return false;
			}

			contrato.getEmpreendimento().setListaCedentes(this.visao.getCedentesSelecionados());
			this.empreendimentoService.alterar(contrato.getEmpreendimento());
			this.getVisao().getCedentesSelecionados().clear();
		}

		return true;
	}

	/**
	 * <p>
	 * Método responsável por atualizar o valor de faturamento da pessoa, informado
	 * manualmente pelo sistema.
	 * <p>
	 *
	 * @author guilherme.santos
	 */
	public void atualizarPessoa() {
		this.getVisao().getContratoSelecionadoParaParametrizacao().getNuPessoa().setVrFaturamentoApurado(this.getVisao().getVrFaturamentoApurado());
		this.getVisao().getContratoSelecionadoParaParametrizacao().getNuPessoa()
				.setCoResponsavelAlteracao(UsuarioUtil.getMatriculaUsuarioLogado().toString());
		this.getVisao().getContratoSelecionadoParaParametrizacao().getNuPessoa().setTsUltimaAlteracao(new Date());
		this.getVisao().getContratoSelecionadoParaParametrizacao().getNuPessoa().setIcTipoEndividamento(TipoEndividamentoEnum.G);
		this.getVisao().getContratoSelecionadoParaParametrizacao().getNuPessoa()
				.setNuSegmento(this.service.consultarSegmento(this.getVisao().getVrFaturamentoApurado()));

		try {
			this.service.atualizarPessoa(this.getVisao().getContratoSelecionadoParaParametrizacao().getNuPessoa());
		} catch (final Exception e) {
			LogCefUtil.error(e);
		}
	}

	/**
	 * <p>
	 * Método responsável por verificar se houve alteração no valor do faturamento
	 * da pessoa.
	 * <p>
	 *
	 * @return boolean
	 * @author guilherme.santos
	 */
	private boolean verificarAltercaoVrFaturamento() {
		return this.getVisao().getContratoSelecionadoParaParametrizacao() != null && this.getVisao().getContratoSelecionadoParaParametrizacao()
				.getNuPessoa().getVrFaturamentoApurado().compareTo(this.getVisao().getVrFaturamentoApurado()) != 0;
	}

	/**
	 * <p>
	 * Método responsável por verificar se existe garantias do tipo aplicação
	 * financeira.
	 * <p>
	 *
	 * @return boolean
	 * @author guilherme.santos
	 */
	private boolean verificarSeExisteGarantiaAplicacaoFinanceira() {
		for (final ParametrizacaoContratoVO garantia : this.getVisao().getParametrizacaoList()) {
			if (garantia.getGarantiaContrato().getGarantia().isGrupoGarantia(GrupoGarantiaEnum.APLICACAO_FINANCEIRA)) {
				return Boolean.TRUE;
			}
		}
		return Boolean.FALSE;
	}

	/**
	 * <p>
	 * Método responsável por verificar se a garantia é do tipo duplicata.
	 * <p>
	 *
	 * @return boolean
	 * @author Caio Graco
	 */
	public boolean isGarantiaDuplicata() {
		return this.service.isGarantiaDuplicata(this.getVisao().getIdentificadorGarantia());
	}

	/**
	 * <p>
	 * Método responsável por verificar se a garantia habitacional
	 * <p>
	 *
	 * @return boolean
	 * @author Leandro Severino - lseverino@gmail.com
	 */
	public boolean isGarantiaHabitacional() {
		return this.service.isGarantiaHabitacional(this.getVisao().getIdentificadorGarantia());
	}

	/**
	 * <p>
	 * Método responsável por verificar se a garantia é do tipo aplicação
	 * financeira.
	 * <p>
	 *
	 * @return boolean
	 * @author Caio Graco
	 */
	public boolean isGarantiaAplicacaoFinanceira() {
		return this.service.isGarantiaAplicacaoFinanceira(this.getVisao().getIdentificadorGarantia());
	}

	/**
	 * <p>
	 * Método responsável por
	 * </p>
	 * .
	 *
	 * @author f799837
	 *
	 */
	public boolean isGarantiasOutros() {
		return this.service.isGarantiaOutros(this.getVisao().getIdentificadorGarantia());

	}

	/**
	 * 
	 * <p>
	 * Método responsável por
	 * </p>
	 * .
	 *
	 * @author p566506
	 *
	 * @return
	 */
	public boolean isGarantiaEmpreendimentos() {
		return this.service.isGarantiaEmpreendimentosRecebiveis(this.getVisao().getIdentificadorGarantia());
	}

	/**
	 * <p>
	 * Método responsável por verificar se a garantia Bacen é máquinas e
	 * equipamentos
	 * </p>
	 * e .
	 *
	 * @author p575337, narcieliton.lopes
	 *
	 * @return true se for máquina e equipamento
	 */
	public boolean isGarantiaMaquinasEquipamentos() {
	    	this.msgAlert = null;
		boolean isGarantiaMaquinaEquipamento = false;
		if (this.service.isGarantiaMaquinaEquipamento(this.getVisao().getIdentificadorGarantia()) && getVisao().isGarantiaPassouSerAcompanhada()) {
			try {
				this.visao.setGarantiaPassouSerAcompanhada(this.fabricaCalculoGarantia.isGarantiaPassouSerAcompanhada(
						visao.getGarantia().getGrupoGarantia(), this.getVisao().getContratoSelecionadoParaParametrizacao().getDtContrato()));

			} catch (Exception e) {
				LogCefUtil.error(e);
				this.visao.setGarantiaPassouSerAcompanhada(false);
			}
			if (this.visao.isGarantiaPassouSerAcompanhada()) {
				this.visao.setListaBemCliente(prepararListaBemClienteMaquinaEquipamento());
				if (this.visao.getListaBemCliente().isEmpty()) {
					this.apresentarAlertaBemCliente("Máquina/Equipamento");
				}
			}
			isGarantiaMaquinaEquipamento = true;
		}
		return isGarantiaMaquinaEquipamento;
	}

	/**
	 * <p>
	 * Método responsável por definir se é um produto agrícola
	 * </p>
	 * .
	 *
	 * @author p575337
	 *
	 * @return true se for produto agrícola.
	 */
	public boolean isGarantiaProdutoAgricola() {
		return this.service.isGarantiaProdutoAgricola(this.getVisao().getIdentificadorGarantia()) && getVisao().isGarantiaPassouSerAcompanhada();
	}

	/**
	 * <p>
	 * Método responsável por verificar se garantia precisa de cedente.
	 * </p>
	 * .
	 *
	 * @author p566506
	 *
	 */
	public boolean getGarantiaPossuiCedente() {
		return this.service.isGarantiaPossuiCedente(this.getVisao().getIdentificadorGarantia());
	}

    /**
     * <p>
     * Método responsável por redirecionar para página de parametrização do
     * contrato.
     * </p>
     *
     * @param contratoParaParametrizacao
     *            valor a ser atribuido
     * @return String
     * @author joseroberto@gsgroup.com.br
     */
    public String parametrizarContrato(final Contrato contratoParaParametrizacao, final OrigemParametrizacaoEnum origemParametrizacao) {
	this.limparDadosParametrizacaoAoCarregar();
	Boolean icPJ = PF.equals(contratoParaParametrizacao.getNuPessoa().getIcPfPj()) ? Boolean.FALSE : Boolean.TRUE;
	this.getVisao().setTipoPessoaEnum(icPJ ? TipoPessoaEnum.J : TipoPessoaEnum.F);
	this.getVisao().setListaSacadosAlterados(null);
	this.getVisao().setContratoSelecionadoParaParametrizacao(contratoParaParametrizacao);
	this.getVisao().getContratoSelecionadoParaParametrizacao().setContratoPessoa(this.service.listarContratoPessoa(contratoParaParametrizacao));
	this.getVisao().getContratoSelecionadoParaParametrizacao()
		.setGarantiaContratoList(this.service.listarGarantiaContrato(contratoParaParametrizacao));
	this.getVisao().setIndiceHipotecario(this.analiseContratoService.obterUltimoIndiceHipotecario(contratoParaParametrizacao.getNuContrato()));
	this.getVisao().setIndiceRecebiveis(this.analiseContratoService.obterUltimoIndiceRecebiveis(contratoParaParametrizacao.getNuContrato()));
	this.getVisao().setSegmentoMPE(this.service.isSegmentoMPE(this.getVisao().getContratoSelecionadoParaParametrizacao()));

	this.getVisao().setSacadosExcepcionadorRemover(new ArrayList<SacadoExcepcionadoVO>());
	this.getVisao().setSacadosExcepcionadosIncluir(new ArrayList<SacadoExcepcionadoVO>());
	getVisao().setUnidadeHabitacionalEmEdicao(new UnidadeHabitacional());
	getVisao().getUnidadeHabitacionalEmEdicao().setNuTipologia(new Tipologia());
	getVisao().setProspectoTipoParcelaEmEdicao(new ProspectoTipoParcela());
	getVisao().getProspectoTipoParcelaEmEdicao().setIcPeriodicidadePrevista(0);
	getVisao().setProponenteEmEdicao(new ProponenteHabitacional());
	getVisao().getProponenteEmEdicao().setIcTipo(TipoPessoaEnum.F);
	getVisao().setOrigemParametrizacao(origemParametrizacao);
	getVisao().setEditing(false);

	if (UtilObjeto.isReferencia(contratoParaParametrizacao.getNuPessoa())
		&& UtilObjeto.isReferencia(contratoParaParametrizacao.getNuPessoa().getNuPessoa())) {

	    if (UtilObjeto.isReferencia(contratoParaParametrizacao.getEmpreendimento())
		    && UtilObjeto.isReferencia(contratoParaParametrizacao.getEmpreendimento().getNuEmpreendimento())) {
		final Collection<Cedente> consultaCedentesPorNuEmpreendimento = this.empreendimentoService
			.listarCedentesHabitacionais(contratoParaParametrizacao.getEmpreendimento().getNuEmpreendimento());
		this.getVisao().setListaCedentes(consultaCedentesPorNuEmpreendimento);
	    } else {
		final Collection<Cedente> consultaCedentesPorNuPessoa = this.getService()
			.listarCedentesPorNuPessoa(contratoParaParametrizacao.getNuPessoa().getNuPessoa());
		this.getVisao().setListaCedentes(consultaCedentesPorNuPessoa);
	    }
	}

	final Collection<ContaContrato> contaContratos = this.contratoService
		.listarContaContratoPorNumeroContrato(contratoParaParametrizacao.getNuContrato());

	for (final ContaContrato contaContrato : contaContratos) {
	    if (contaContrato.getNuConta() != null) {
		final String numeroContaFormatado = contaContrato.getNuConta().getNumeroContaFormatado();
		if (ContaEnum.NORMAL.equals(contaContrato.getIcConta())) {
		    this.getVisao().setNuContaContrato(numeroContaFormatado);
		}
	    }
	}

	// Inicializa a lista de exclusão
	this.getVisao().setListaExclusaoParametrizacao(new ArrayList<ParametrizacaoContratoVO>());
	getVisao().setValorUtilizadoOutrasGarantias(new HashMap<Integer, BigDecimal>());

	this.verificarPermissoes();

	return ParametrizacaoContratoMB.PAGINA_PARAMETRIZACAO_CONTRATO;
    }

	/**
	 * <p>
	 * Método responsável por retornar a string com o valor da forma da
	 * parametrização.
	 * <p>
	 *
	 * @param parametrizacaoContratoVO
	 *            valor a ser atribuido
	 * @return String
	 * @author Waltenes Junior
	 */
	public String criarStringFormaParametrizacao(final ParametrizacaoContratoVO parametrizacaoContratoVO) {
		if (null != parametrizacaoContratoVO && parametrizacaoContratoVO.getGarantiaContrato().getIcFormaGarantia1() != null) {
			String porcentagem = "";

			if (parametrizacaoContratoVO.getGarantiaContrato().getGarantia().getGrupoGarantia().getNuGrupoGarantia() == GrupoGarantiaEnum.DUPLICATA
					.getCodigo() && parametrizacaoContratoVO.getGarantiaContrato().getIcFormaGarantia1().equals(FormaGarantiaEnum.PMT)) {

				final BigDecimal valor = parametrizacaoContratoVO.getGarantiaContrato().getVrFormaGarantia1();
				String numero = "";

				try {
					numero = String.valueOf(valor.intValueExact());
				} catch (final Exception e) {
					LogCEF.debug(e);
					numero = valor.toString();
				}

				porcentagem = numero.replace(".", ",").concat("%");
			} else {
				if (parametrizacaoContratoVO.getGarantiaContrato().getVrFormaGarantia1() != null) {
					porcentagem = parametrizacaoContratoVO.getGarantiaContrato().getVrFormaGarantia1().toString().replace(".", ",").concat("%");
				}
			}
			final CaracteristicaEnum icCaracteristica = parametrizacaoContratoVO.getGarantiaContrato().getIcCaracteristica();
			final String caracteristica = icCaracteristica != null ? icCaracteristica.toString().toLowerCase() : "";
			final String forma = parametrizacaoContratoVO.getGarantiaContrato().getIcFormaGarantia1().toString().replace("_", " ").toLowerCase();

			return porcentagem.concat(" ").concat(forma).concat(" ").concat(caracteristica);
		}
		return "";
	}

	/**
	 * <p>
	 * Método responsável por retornar a String com o valor da forma garantia 2 da
	 * parametrização.
	 * <p>
	 *
	 * @param parametrizacaoContratoVO
	 *            valor a ser atribuido
	 * @return String
	 * @author Ronnie Mikihiro
	 */
	public String criarStringForma2Parametrizacao(final ParametrizacaoContratoVO parametrizacaoContratoVO) {
		if (parametrizacaoContratoVO != null && parametrizacaoContratoVO.getGarantiaContrato().getIcFormaGarantia2() != null) {
			if (parametrizacaoContratoVO.getGarantiaContrato().getGarantia() != null) {
				if (parametrizacaoContratoVO.getGarantiaContrato().getGarantia().getGrupoGarantia()
						.getNuGrupoGarantia() == GrupoGarantiaEnum.DUPLICATA.getCodigo()) {
					final String porcentagem2 = parametrizacaoContratoVO.getGarantiaContrato().getVrFormaGarantia2().toString().replace(".", ",")
							.concat("%");
					final String caracteristica2 = parametrizacaoContratoVO.getGarantiaContrato().getIcCaracteristica().toString().toLowerCase();
					final String forma2 = parametrizacaoContratoVO.getGarantiaContrato().getIcFormaGarantia2().toString().replace("_", " ")
							.toLowerCase();
					return porcentagem2.concat(" ").concat(forma2).concat(" ").concat(caracteristica2);
				}
				return null;
			}
			return null;
		}
		return null;
	}

	/**
	 * <p>
	 * Método responsável por retornar a lista de garantiaaplicacao das aplicações
	 * financeiras selecionadas na treetable.
	 * <p>
	 *
	 * @return Collection<GarantiaAplicacao>
	 * @author Ricardo Crispim
	 */
	public Collection<GarantiaAplicacao> getListaGarantiaAplicacaoSelecionadas() {

		final Collection<GarantiaAplicacao> listaGarantiaAplicacao = new ArrayList<>();
		if (this.getVisao().getAplicacoesSelecionadas() != null) {
			for (final TreeNode treeNode : this.getVisao().getAplicacoesSelecionadas()) {
				if (treeNode.getData() instanceof AplicacaoFinanceira) {
					GarantiaAplicacao garantiaAplicacao = null;

					if (this.getVisao().getEntidade().getNuContrato() != null && this.getVisao().getEntidade().getNuGarantia() != null) {
						final GarantiaAplicacaoID id = new GarantiaAplicacaoID();
						id.setAplicacaoFinanceira((AplicacaoFinanceira) treeNode.getData());
						id.setGarantiaContrato(this.getVisao().getEntidade());
						garantiaAplicacao = this.service.consultarGarantiaAplicacaoPorId(id);
					}

					if (garantiaAplicacao == null) {
						garantiaAplicacao = new GarantiaAplicacao();
						garantiaAplicacao.setVrConsumidoAplicacaoFinanceira(BigDecimal.ZERO);
						garantiaAplicacao.getId().setAplicacaoFinanceira((AplicacaoFinanceira) treeNode.getData());
						garantiaAplicacao.getId().setGarantiaContrato(this.getVisao().getEntidade());
					}

					listaGarantiaAplicacao.add(garantiaAplicacao);
				}
			}
		}

		return listaGarantiaAplicacao;
	}

	public void marcarDesmarcadoGarantiaCartaoCredito(GarantiaCartaoCredito garantiaCartaoCredito) {
		boolean isMarcado = garantiaCartaoCredito.isIcMarcado();
		super.adicionaMensagemDeAlerta(isMarcado ? "Marcou" : "Desmarcou");
	}

	/**
	 * <p>
	 * Método responsável por retornar as GarantiaCartaoCredito da arvore.
	 * <p>
	 *
	 * @return Collection<GarantiaCartaoCredito>
	 * @author guilherme.santos
	 */
	public Collection<GarantiaCartaoCredito> getListaGarantiaCartaoCreditoSelecionados() {
		final Collection<GarantiaCartaoCredito> listaGarantiaCartaoCredito = new ArrayList<>();

		for (ContaCorrenteBandeirasVO contaCorrenteBandeirasVO : this.getVisao().getListaContaCorrenteBandeiras()) {
			for (GarantiaCartaoCredito garantiaCartaoCredito : contaCorrenteBandeirasVO.getListaGarantiaCartaoCredito()) {
				if (garantiaCartaoCredito.isIcMarcado()) {
					listaGarantiaCartaoCredito.add(garantiaCartaoCredito);
				}
			}
		}

		// if (this.getVisao().getCartoesSelecionados() != null) {
		// for (final TreeNode treeNode : this.getVisao().getCartoesSelecionados()) {
		// if (treeNode.getData() instanceof GarantiaCartaoCredito) {
		// final GarantiaCartaoCredito novaGarantiaCartao = (GarantiaCartaoCredito)
		// treeNode.getData();
		// GarantiaCartaoCredito garantiaCartaoCreditoSelecionada = null;
		//
		// if (this.getVisao().getEntidade().getNuContrato() != null &&
		// this.getVisao().getEntidade().getNuGarantia() != null
		// && novaGarantiaCartao.getNuGarantiaCartaoCredito() != null) {
		//
		// garantiaCartaoCreditoSelecionada = this.service
		// .consultarGarantiaCartaoCreditoPorId(novaGarantiaCartao.getNuGarantiaCartaoCredito());
		// }
		//
		// if (garantiaCartaoCreditoSelecionada == null) {
		// garantiaCartaoCreditoSelecionada = new GarantiaCartaoCredito();
		// garantiaCartaoCreditoSelecionada.setVrConsumido(BigDecimal.ZERO);
		// garantiaCartaoCreditoSelecionada.setBandeiraCartao(novaGarantiaCartao.getBandeiraCartao());
		// garantiaCartaoCreditoSelecionada.setNuConta(novaGarantiaCartao.getNuConta());
		// garantiaCartaoCreditoSelecionada.setGarantiaContrato(this.getVisao().getEntidade());
		// }
		// garantiaCartaoCreditoSelecionada.setIcMarcado(Boolean.TRUE);
		//
		// listaGarantiaCartaoCredito.add(garantiaCartaoCreditoSelecionada);
		// }
		// }
		// }

		return listaGarantiaCartaoCredito;
	}

	/**
	 * @see br.gov.caixa.pedesgo.arquitetura.controlador.AbstractBean#getService()
	 */
	@SuppressWarnings("unchecked")
	@Override
	public ParametrizacaoContratoService getService() {
		return this.service;
	}

	/**
	 * @see br.gov.caixa.pedesgo.arquitetura.controlador.AbstractBean#getVisao()
	 */
	@Override
	public ParametrizacaoContratoVisao getVisao() {
		if (!UtilObjeto.isReferencia(this.visao)) {
			this.visao = new ParametrizacaoContratoVisao();
		}
		return this.visao;
	}

	/**
	 * Define o valor do atributo visao.
	 *
	 * @param visao
	 *            valor a ser atribuído
	 */
	public void setVisao(final ParametrizacaoContratoVisao visao) {
		this.visao = visao;
	}

	/**
	 * Retorna o valor do atributo contratoService.
	 *
	 * @return contratoService
	 */
	public ContratoService getContratoService() {
		return this.contratoService;
	}

	/**
	 * Define o valor do atributo contratoService.
	 *
	 * @param contratoService
	 *            valor a ser atribuído
	 */
	public void setContratoService(final ContratoService contratoService) {
		this.contratoService = contratoService;
	}

	/**
	 * @see br.gov.caixa.pedesgo.arquitetura.controlador.AbstractBean#getNomeVarResourceBundle()
	 */
	@Override
	protected String getNomeVarResourceBundle() {
		return "msgApp";
	}

	/**
	 * @see br.gov.caixa.pedesgo.arquitetura.controlador.AbstractBean#getPrefixoCasoDeUso()
	 */
	@Override
	protected String getPrefixoCasoDeUso() {
		return null;
	}

	/**
	 * <p>
	 * Método responsável por inicializar os valores parametrizados dos calculos.
	 * <p>
	 *
	 * @author guilherme.santos
	 */
	public void recuperarParametrosCalculoDuplicata() {

		if (this.getVisao().getEntidade().getVrPrazoMaximoPermitido() == null) {
			this.getVisao().getEntidade()
					.setVrPrazoMaximoPermitido(this.service.consultarParametroCalculo(ParametroCalculoEnum.PRAZO_MAXIMO_DUPLICATA));
		}
		if (this.getVisao().getEntidade().getVrMaximoPermitido() == null) {
			this.getVisao().getEntidade().setVrMaximoPermitido(this.service.consultarParametroCalculo(ParametroCalculoEnum.VALOR_MAXIMO_DUPLICATA));
		}
		if (this.getVisao().getEntidade().getVrPercentualMaximoCncno() == null) {
			this.getVisao().getEntidade()
					.setVrPercentualMaximoCncno(this.service.consultarParametroCalculo(ParametroCalculoEnum.PERCENTUAL_MAXIMO_DUPLICATA));
		}
	}

	/**
	 * <p>
	 * Método responsável por inicializar os valores parametrizados dos calculos.
	 * <p>
	 *
	 * @author guilherme.santos
	 */
	public void recuperarParametrosCalculoCheque() {

		if (this.getVisao().getEntidade().getVrPrazoMaximoPermitido() == null) {
			this.getVisao().getEntidade().setVrPrazoMaximoPermitido(this.service.consultarParametroCalculo(ParametroCalculoEnum.PRAZO_MAXIMO_CHEQUE));
		}
		if (this.getVisao().getEntidade().getVrPrazoMinimoPermitido() == null) {
			this.getVisao().getEntidade().setVrPrazoMinimoPermitido(this.service.consultarParametroCalculo(ParametroCalculoEnum.PRAZO_MINIMO_CHEQUE));
		}
		if (this.getVisao().getEntidade().getVrMaximoPermitido() == null) {
			this.getVisao().getEntidade().setVrMaximoPermitido(this.service.consultarParametroCalculo(ParametroCalculoEnum.VALOR_MAXIMO_CHEQUE));
		}
	}

	/**
	 * <p>
	 * Método responsável por verificar se o usuário logado tem a credencial exigida
	 * pelo segmento do contrato.
	 * <p>
	 *
	 * @return boolean
	 * @author admin
	 */
	private boolean verificarMesmoSegmentoPessoa() {
		boolean mesmoSegmentoPessoa = false;

		if (this.getVisao().getContratoSelecionadoParaParametrizacao() != null
				&& this.getVisao().getContratoSelecionadoParaParametrizacao().getNuPessoa() != null
				&& this.getVisao().getContratoSelecionadoParaParametrizacao().getNuPessoa().getNuSegmento() != null
				&& UsuarioUtil.contemPermissao(
						this.getVisao().getContratoSelecionadoParaParametrizacao().getNuPessoa().getNuSegmento().getDeFuncionalidade(),
						this.getVisao().getContratoSelecionadoParaParametrizacao().getNuPessoa().getNuSegmento().getDeAcao(), null, null)) {
			mesmoSegmentoPessoa = true;
		}
		this.getVisao().setMesmoSegmentoPessoa(mesmoSegmentoPessoa);
		return mesmoSegmentoPessoa;
	}

	/**
	 * <p>
	 * Método responsável por verificar permissões do usuario logado.
	 * <p>
	 *
	 * @author guilherme.santos
	 */
	public void verificarPermissoes() {
		boolean mesmoSegmentoPessoa = false;

		// Controle de permissão para editar uma garantia pelo segmento da
		// pessoa
		mesmoSegmentoPessoa = this.verificarMesmoSegmentoPessoa();

		// Controle de permissões da funcionalidade Conta Livre de Movimentação
		this.getVisao().setExibirBotaoIncluirContaNLMContrato(
				UsuarioUtil.contemPermissao(NoFuncionalidadeEnum.PARAMETRIZA_CONTRATO_CONTA_CORRENTE.getNoFuncionalidade(),
						EnumAcao.INCLUIR.getNoAcao(), null, null) && mesmoSegmentoPessoa);
		this.getVisao().setExibirBotaoConsultarContaNLMContrato(UsuarioUtil.contemPermissao(
				NoFuncionalidadeEnum.PARAMETRIZA_CONTRATO_CONTA_CORRENTE.getNoFuncionalidade(), EnumAcao.CONSULTAR.getNoAcao(), null, null));
		this.getVisao().setExibirBotaoMarcarContaNLMContrato(
				UsuarioUtil.contemPermissao(NoFuncionalidadeEnum.PARAMETRIZA_CONTRATO_CONTA_CORRENTE_MARCAR.getNoFuncionalidade(),
						EnumAcao.CONSULTAR.getNoAcao(), null, null) && mesmoSegmentoPessoa);
		this.getVisao().setExibirBotaoExcluirContaNLMContrato(
				UsuarioUtil.contemPermissao(NoFuncionalidadeEnum.PARAMETRIZA_CONTRATO_CONTA_CORRENTE.getNoFuncionalidade(),
						EnumAcao.EXCLUIR.getNoAcao(), null, null) && mesmoSegmentoPessoa);
		// Controle de permissões da funcionalidade Garantia
		this.getVisao().setExibirBotaoIncluirGarantia(
				UsuarioUtil.contemPermissao(NoFuncionalidadeEnum.PARAMETRIZA_CONTRATO_GARANTIA_CONTRATO.getNoFuncionalidade(),
						EnumAcao.INCLUIR.getNoAcao(), null, null) && mesmoSegmentoPessoa);
		this.getVisao().setExibirBotaoEditarGarantia(UsuarioUtil.contemPermissao(
				NoFuncionalidadeEnum.PARAMETRIZA_CONTRATO_GARANTIA_CONTRATO.getNoFuncionalidade(), EnumAcao.ALTERAR.getNoAcao(), null, null));
		this.getVisao().setExibirBotaoExcluirGarantia(
				UsuarioUtil.contemPermissao(NoFuncionalidadeEnum.PARAMETRIZA_CONTRATO_GARANTIA_CONTRATO.getNoFuncionalidade(),
						EnumAcao.EXCLUIR.getNoAcao(), null, null) && mesmoSegmentoPessoa);
		this.getVisao().setExibirBotaoDuplicataExcepcionadaGarantia(UsuarioUtil.contemPermissao(
				NoFuncionalidadeEnum.PARAMETRIZA_CONTRATO_EXCEPCIONAR_GARANTIA.getNoFuncionalidade(), EnumAcao.CONSULTAR.getNoAcao(), null, null));
		// Controle de permissões da funcionalidade Editar Parametros de
		// calculos
		this.getVisao().setExibirBotaoEditarParametrosCalculo(UsuarioUtil
				.contemPermissao(NoFuncionalidadeEnum.MANTEM_PARAMETROS_CALCULO.getNoFuncionalidade(), EnumAcao.ALTERAR.getNoAcao(), null, null));

		// Controle de permissões da funcionalidade Excepcionar Duplicatas
		this.getVisao().setExibirBotaoIncluirDuplicataExcepcionadaGarantia(UsuarioUtil.contemPermissao(
				NoFuncionalidadeEnum.PARAMETRIZA_CONTRATO_EXCEPCIONAR_GARANTIA.getNoFuncionalidade(), EnumAcao.INCLUIR.getNoAcao(), null, null));
		this.getVisao().setExibirBotaoExcluirDuplicataExcepcionadaGarantia(UsuarioUtil.contemPermissao(
				NoFuncionalidadeEnum.PARAMETRIZA_CONTRATO_EXCEPCIONAR_GARANTIA.getNoFuncionalidade(), EnumAcao.EXCLUIR.getNoAcao(), null, null));

		this.getVisao().setExibirBotaoChequeExcepcionadoGarantia(UsuarioUtil.contemPermissao(
				NoFuncionalidadeEnum.PARAMETRIZA_CONTRATO_EXCEPCIONAR_GARANTIA.getNoFuncionalidade(), EnumAcao.CONSULTAR.getNoAcao(), null, null));

		this.getVisao().setExibirBotaoIncluirChequeExcepcionadoGarantia(UsuarioUtil.contemPermissao(
				NoFuncionalidadeEnum.PARAMETRIZA_CONTRATO_EXCEPCIONAR_GARANTIA.getNoFuncionalidade(), EnumAcao.INCLUIR.getNoAcao(), null, null));
		this.getVisao().setExibirBotaoExcluirChequeExcepcionadoGarantia(UsuarioUtil.contemPermissao(
				NoFuncionalidadeEnum.PARAMETRIZA_CONTRATO_EXCEPCIONAR_GARANTIA.getNoFuncionalidade(), EnumAcao.EXCLUIR.getNoAcao(), null, null));

		this.getVisao().setExibirBotaoExcepcionarSacado(UsuarioUtil.contemPermissao(
				NoFuncionalidadeEnum.PARAMETRIZA_CONTRATO_EXCEPCIONAR_SACADO.getNoFuncionalidade(), EnumAcao.INCLUIR.getNoAcao(), null, null));

	}

	/**
	 * <p>
	 * Método responsável por setar os campos do modal sacado excepcionado.
	 * <p>
	 *
	 * @param garantiaContrato
	 *            valor a ser atribuído
	 * @author Bruno Martins de Carvalho
	 */
	public void abrirSacadoExcepcionado(final GarantiaContrato garantiaContrato) {
		final ParametrizacaoContratoVisao visao = this.getVisao();

		visao.setListaSacadosAExcepcionarAlterada(false);
		visao.setExibirBotaoLimparSacadoExcepcionado(true);
		visao.setExibirBotaoSalvarSacado(false);
		visao.setExibirBotaoIncluirSacado(true);
		visao.setExibirBotaoExcepcionarSacadoDetalheVoltar(false);

		visao.setListaSacadosAlterados(null);
		visao.setSacadosExcepcionadorRemover(null);
		visao.setSacadoExcepcionado(new SacadoExcepcionadoVO());
		visao.getSacadoExcepcionado().setNuGarantiaContrato(garantiaContrato);

		visao.setGarantiaContrato(garantiaContrato);

		final Collection<SacadoExcepcionadoVO> listaSacadoExcepcionadoVO = this
				.converterListaSacadoExcepcionadoEmListaSacadoExcepcionadoVO(garantiaContrato.getListaSacadoExcepcionado());

		if (!UtilObjeto.isVazio(listaSacadoExcepcionadoVO)) {
			visao.setSacadosParaExcepcionar(listaSacadoExcepcionadoVO);
		} else {
			visao.setSacadosParaExcepcionar(new ArrayList<SacadoExcepcionadoVO>());
		}
	}

	/**
	 * <p>
	 * Método responsável por limpar os campos do modal sacado excepcionado.
	 * <p>
	 *
	 * @author Bruno Martins de Carvalho
	 */
	public void limparCamposSacadoExcepcionado() {
		final ParametrizacaoContratoVisao visao = this.getVisao();

		visao.setSacadoExcepcionado(new SacadoExcepcionadoVO());

		visao.setExibirBotaoLimparSacadoExcepcionado(true);
		visao.setExibirBotaoIncluirSacado(true);
		visao.setExibirBotaoSalvarSacado(false);
		visao.setExibirBotaoExcepcionarSacadoDetalheVoltar(false);
	}

	/**
	 * <p>
	 * Método responsável por adicionar um sacado na lista de sacados para
	 * excepcionar.
	 * <p>
	 *
	 * @author Bruno Martins de Carvalho
	 */
	public void adicionarSacadoParaListaSacados() {

		final ParametrizacaoContratoVisao visao = this.getVisao();

		final GarantiaContrato garantiaContrato = visao.getGarantiaContrato();

		visao.getEntidade().setMensagens(new ArrayList<MensagemTO>());

		if (this.service.validarSacado(visao.getSacadoExcepcionado(), visao.getEntidade())
				&& !visao.getSacadosParaExcepcionar().contains(visao.getSacadoExcepcionado())) {

			final SacadoExcepcionadoVO sacadoExcepcionado = new SacadoExcepcionadoVO();

			sacadoExcepcionado.setPrazoMaximoTitulo(visao.getSacadoExcepcionado().getPrazoMaximoTitulo());
			sacadoExcepcionado.setVrMaximoTitulo(visao.getSacadoExcepcionado().getVrMaximoTitulo());
			sacadoExcepcionado.setPercentualMaximo(visao.getSacadoExcepcionado().getPercentualMaximo());
			sacadoExcepcionado.setIcInstrucaoProtesto(visao.getSacadoExcepcionado().isIcInstrucaoProtesto());
			sacadoExcepcionado.setObservacao(visao.getSacadoExcepcionado().getObservacao());
			sacadoExcepcionado.setNuGarantiaContrato(garantiaContrato);

			sacadoExcepcionado.setSacado(this.service.getSacadoPorCoDocumento(visao.getSacadoExcepcionado().getCoDocumentoSemFormatacao()));
			sacadoExcepcionado.setCoDocumento(visao.getSacadoExcepcionado().getCoDocumento());
			sacadoExcepcionado.setTipoPessoa(visao.getTipoPessoaEnum());

			visao.getSacadosParaExcepcionar().add(sacadoExcepcionado);
			visao.getSacadosExcepcionadosIncluir().add(sacadoExcepcionado);
			super.adicionaMensagemDeSucesso(ParametrizacaoContratoMB.OPERACAO_REALIZADA_SUCESSO);
			visao.setSacadoExcepcionado(new SacadoExcepcionadoVO());
			visao.getSacadoExcepcionado().setNuGarantiaContrato(garantiaContrato);

			visao.setListaSacadosAExcepcionarAlterada(true);
		} else if (visao.getSacadosParaExcepcionar().contains(visao.getSacadoExcepcionado())) {
			super.adicionaMensagemDeAlerta("MN027");
		} else {
			super.adicionaListaMensagemDeAlerta(visao.getEntidade().getMensagens());
		}
	}

	/**
	 * <p>
	 * Método responsável por remover um sacado da lista de sacados para
	 * excepcionar.
	 * <p>
	 *
	 * @param sacadoExcepcionado
	 * @author Bruno Martins de Carvalho
	 */
	public void removerSacadoDaListaSacados() {

		final ParametrizacaoContratoVisao visao = this.getVisao();

		for (final SacadoExcepcionado sacadoExcepcionado : visao.getListaSacadosAlterados()) {
			if (sacadoExcepcionado.getNuSacado().getCoDocumento().equals(visao.getIdentificacaoSacadoRemover())) {
				visao.getListaSacadosAlterados().remove(sacadoExcepcionado);
			}
		}

		for (final SacadoExcepcionadoVO sacadoExcepcionado : visao.getSacadosParaExcepcionar()) {
			if (sacadoExcepcionado.getCoDocumento().equals(visao.getIdentificacaoSacadoRemover())) {
				visao.getSacadosExcepcionadosRemoverTemporaria().add(sacadoExcepcionado);
				visao.setListaSacadosAExcepcionarAlterada(true);
				super.adicionaMensagemDeSucesso(ParametrizacaoContratoMB.OPERACAO_REALIZADA_SUCESSO);
			}
		}

		visao.getSacadosParaExcepcionar().removeAll(visao.getSacadosExcepcionadosRemoverTemporaria());

		visao.setSacadoExcepcionado(new SacadoExcepcionadoVO());
		this.limparCamposSacadoExcepcionado();
	}

	/**
	 * <p>
	 * Método responsável por setar os campos do sacado a ser editado.
	 * <p>
	 *
	 * @param sacadoExcepcionado
	 *            valor a ser atribuído
	 * @author Bruno Martins de Carvalho
	 */
	public void editarSacadoDaListaSacados(final SacadoExcepcionadoVO sacadoExcepcionado) {

		final ParametrizacaoContratoVisao visao = this.getVisao();

		visao.setSacadoExcepcionadoVOBackup(UtilObjeto.clone(sacadoExcepcionado));
		visao.setTipoPessoaEnum(sacadoExcepcionado.getTipoPessoa());

		visao.setSacadoExcepcionado(visao.getSacadoExcepcionadoVOBackup());
		visao.setExibirBotaoLimparSacadoExcepcionado(false);
		visao.setExibirBotaoSalvarSacado(true);
		visao.setExibirBotaoIncluirSacado(false);
		visao.setExibirBotaoExcepcionarSacadoDetalheVoltar(false);
	}

	/**
	 * <p>
	 * Método responsável por salvar a edicao do sacado.
	 * <p>
	 *
	 * @author Bruno Martins de Carvalho
	 */
	public void salvarEdicaoSacado() {
		final ParametrizacaoContratoVisao visao = this.getVisao();

		final GarantiaContrato garantiaContrato = visao.getSacadoExcepcionado().getNuGarantiaContrato();

		visao.getEntidade().setMensagens(new ArrayList<MensagemTO>());

		if (this.service.validarSacado(visao.getSacadoExcepcionado(), visao.getEntidade())) {
			for (final SacadoExcepcionadoVO sacadoExcepcionado : visao.getSacadosParaExcepcionar()) {
				if (sacadoExcepcionado.equals(visao.getSacadoExcepcionado())) {
					sacadoExcepcionado.setCoDocumento(visao.getSacadoExcepcionado().getCoDocumento());
					sacadoExcepcionado.setSacado(this.service.getSacadoPorCoDocumento(visao.getSacadoExcepcionado().getCoDocumento()));

					sacadoExcepcionado.setPrazoMaximoTitulo(visao.getSacadoExcepcionado().getPrazoMaximoTitulo());
					sacadoExcepcionado.setVrMaximoTitulo(visao.getSacadoExcepcionado().getVrMaximoTitulo());
					sacadoExcepcionado.setPercentualMaximo(visao.getSacadoExcepcionado().getPercentualMaximo());
					sacadoExcepcionado.setIcInstrucaoProtesto(visao.getSacadoExcepcionado().isIcInstrucaoProtesto());
					sacadoExcepcionado.setObservacao(visao.getSacadoExcepcionado().getObservacao());
					sacadoExcepcionado.setNuGarantiaContrato(garantiaContrato);

					visao.setListaSacadosAExcepcionarAlterada(true);
				}
			}
			super.adicionaMensagemDeSucesso(ParametrizacaoContratoMB.OPERACAO_REALIZADA_SUCESSO);

			visao.setSacadoExcepcionado(new SacadoExcepcionadoVO());
			visao.setExibirBotaoLimparSacadoExcepcionado(true);
			visao.setExibirBotaoSalvarSacado(false);
			visao.setExibirBotaoIncluirSacado(true);
			visao.setExibirBotaoExcepcionarSacadoDetalheVoltar(false);
		} else {
			super.adicionaListaMensagemDeAlerta(visao.getEntidade().getMensagens());
		}
		visao.setSacadoExcepcionadoVOBackup(null);
	}

	/**
	 * <p>
	 * Método responsável por salvar lista de sacados para excepcionar.
	 * <p>
	 *
	 * @author Bruno Martins de Carvalho
	 */
	public void salvarListaSacados() {

		final ParametrizacaoContratoVisao visao = this.getVisao();

		if (visao.isListaSacadosAExcepcionarAlterada()) {

			final Collection<SacadoExcepcionado> listaSacadoExcepcionado = new ArrayList<>();

			for (final SacadoExcepcionadoVO sacadoExcepcionadoVO : visao.getSacadosParaExcepcionar()) {

				final SacadoExcepcionado sacadoExcepcionado = this.converterSacadoExcepcionadoVOemSacadoExcepcionado(sacadoExcepcionadoVO);
				listaSacadoExcepcionado.add(sacadoExcepcionado);
			}

			for (final ParametrizacaoContratoVO parametrizacaoContratoVO : visao.getParametrizacaoList()) {
				if (parametrizacaoContratoVO.getGarantiaContrato().getNuGarantia().equals(visao.getGarantiaContrato().getNuGarantia())) {
					parametrizacaoContratoVO.getGarantiaContrato().setListaSacadoExcepcionado(listaSacadoExcepcionado);
				}
			}

			visao.getSacadosExcepcionadosRemover().addAll(visao.getSacadosExcepcionadosRemoverTemporaria());
			visao.getSacadosExcepcionadosRemoverTemporaria().clear();

			visao.setGarantiaContrato(null);
			super.adicionaMensagemDeSucesso(ParametrizacaoContratoMB.OPERACAO_REALIZADA_SUCESSO);
		}
	}

	/**
	 * <p>
	 * Método responsável por salvar lista de tipologias.
	 * <p>
	 *
	 * @author leandro.severino - lseverino@gmail.com
	 */
	public void salvarTipologias() {

		final ParametrizacaoContratoVisao visao = this.getVisao();
		final Empreendimento empreendimento = visao.getContratoSelecionadoParaParametrizacao().getEmpreendimento();

		final Collection<Tipologia> listaTipologiaPersistida = this.tipologiaService.listarTipologias(empreendimento);
		final Collection<Tipologia> listaTipologiaVisao = visao.getListaTipologia();

		if (listaTipologiaPersistida.isEmpty()) {
			// É inclusão
			for (final Tipologia tipologia : listaTipologiaVisao) {
				tipologia.setNuEmpreendimento(empreendimento);
				tipologia.setDhAtualizacaoValor(new Date());
				this.tipologiaService.inserir(tipologia);
			}
		} else {
			// Tipologias foram incluidas, excluidas ou alteradas.
			for (final Iterator<Tipologia> iteratorPersistida = listaTipologiaPersistida.iterator(); iteratorPersistida.hasNext();) {
				final Tipologia tipologiaPersistida = iteratorPersistida.next();

				// Se Tipologia não está em memória então foi excluída.
				if (!listaTipologiaVisao.contains(tipologiaPersistida)) {
					this.tipologiaService.remover(tipologiaPersistida);
					iteratorPersistida.remove();
				}
			}

			for (final Iterator<Tipologia> iteratorVisao = listaTipologiaVisao.iterator(); iteratorVisao.hasNext();) {
				final Tipologia tipologiaVisao = iteratorVisao.next();

				// Se a topologia em memória não está na lista persistida, então
				// é uma inclusão.
				if (!listaTipologiaPersistida.contains(tipologiaVisao)) {
					tipologiaVisao.setNuEmpreendimento(empreendimento);
				}
				tipologiaVisao.setDhAtualizacaoValor(new Date());
				this.tipologiaService.salvar(tipologiaVisao);
			}
		}

		// Exibe a mensagem de sucesso !
		// RequestContext.getCurrentInstance().execute("PF('modalTipologiaAlterada').hide()");
		RequestContext.getCurrentInstance().execute("PF('modalTipologiasEmpreendimentoWV').hide()");
		RequestContext.getCurrentInstance().execute(ParametrizacaoContratoMB.PF_MODAL_SUCESSO_SHOW);

	}

	public void needToCallModalSuccess() {
		if (this.getVisao().isEditingTipologia()) {
			this.getVisao().setEditingTipologia(false);
			RequestContext.getCurrentInstance().execute(ParametrizacaoContratoMB.PF_MODAL_SUCESSO_SHOW);
		}
	}

	/**
	 * <p>
	 * Método responsável por voltar a lista de SacadosExcepcionados anterior as
	 * edições.
	 * <p>
	 *
	 * @author Bruno Martins de Carvalho
	 */
	public void cancelarSacadoExcepcionado() {

		final ParametrizacaoContratoVisao visao = this.getVisao();

		if (UtilObjeto.isReferencia(visao.getSacadoExcepcionadoVOBackup().getCoDocumento())) {
			visao.setSacadoExcepcionado(visao.getSacadoExcepcionadoVOBackup());
		}

		for (final SacadoExcepcionadoVO sacadoExcepcionadoVO : visao.getSacadosExcepcionadosIncluir()) {
			if (visao.getSacadosParaExcepcionar().contains(sacadoExcepcionadoVO)) {
				visao.getSacadosParaExcepcionar().remove(sacadoExcepcionadoVO);
			}
		}

		visao.getSacadosParaExcepcionar().addAll(visao.getSacadosExcepcionadosRemoverTemporaria());
		visao.setSacadosExcepcionadosRemoverTemporaria(null);
		visao.setGarantiaContrato(null);
	}

	/**
	 * <p>
	 * Método responsável por atribuir um sacadoExcepcionado para exclusão da lista.
	 * <p>
	 *
	 * @param coIdentificadorSacado
	 *            valor a ser atribuído
	 * @author Bruno Martins de Carvalho
	 */
	public void atribuirSacadoParaExclusao(final String coIdentificadorSacado) {

		this.getVisao().setIdentificacaoSacadoRemover(coIdentificadorSacado);
	}

	/**
	 * <p>
	 * Método responsável por abrir o detalhamento de um sacadoExcepcionado.
	 * <p>
	 *
	 * @param sacadoExcepcionado
	 *            valor a ser atribuído
	 * @author Bruno Martins de Carvalho
	 */
	public void abrirDetalhamentoSacadoExcepcionado(final SacadoExcepcionadoVO sacadoExcepcionado) {
		final ParametrizacaoContratoVisao visao = this.getVisao();

		visao.setSacadoExcepcionadoVOBackup(UtilObjeto.clone(sacadoExcepcionado));
		visao.setTipoPessoaEnum(sacadoExcepcionado.getTipoPessoa());

		visao.setSacadoExcepcionado(visao.getSacadoExcepcionadoVOBackup());

		visao.setExibirBotaoLimparSacadoExcepcionado(false);
		visao.setExibirBotaoSalvarSacado(false);
		visao.setExibirBotaoIncluirSacado(false);
		visao.setExibirBotaoExcepcionarSacadoDetalheVoltar(true);
	}

	/**
	 * <p>
	 * Método responsável por voltar para a inclusao de sacadoExcepcionado.
	 * <p>
	 *
	 * @author Bruno Martins de Carvalho
	 */
	public void voltarParaSacadoExcepcionado() {
		final ParametrizacaoContratoVisao visao = this.getVisao();

		visao.setSacadoExcepcionado(new SacadoExcepcionadoVO());

		visao.setExibirBotaoLimparSacadoExcepcionado(true);
		visao.setExibirBotaoSalvarSacado(false);
		visao.setExibirBotaoIncluirSacado(true);
		visao.setExibirBotaoExcepcionarSacadoDetalheVoltar(false);

	}

	/**
	 * <p>
	 * Método responsável por converter um sacadoExcepcionadoVO em um
	 * SacadoExcepcionado.
	 * <p>
	 *
	 * @param sacadoExcepcionadoVO
	 *            valor a ser atribuído
	 * @return SacadoExcepcionado
	 * @author Bruno Martins
	 */
	public SacadoExcepcionado converterSacadoExcepcionadoVOemSacadoExcepcionado(final SacadoExcepcionadoVO sacadoExcepcionadoVO) {

		final SacadoExcepcionado sacadoExcepcionado = new SacadoExcepcionado();

		sacadoExcepcionado.setNuGarantiaContrato(sacadoExcepcionadoVO.getNuGarantiaContrato());
		sacadoExcepcionado.setNuSacado(sacadoExcepcionadoVO.getSacado());
		sacadoExcepcionado.setNuSacadoExcepcionado(sacadoExcepcionadoVO.getNuSacadoExcepcionado());
		sacadoExcepcionado.setObservacao(sacadoExcepcionadoVO.getObservacao());
		sacadoExcepcionado.setPercentualMaximo(sacadoExcepcionadoVO.getPercentualMaximo());
		sacadoExcepcionado.setPrazoMaximoTitulo(sacadoExcepcionadoVO.getPrazoMaximoTitulo());
		sacadoExcepcionado.setVrMaximoTitulo(sacadoExcepcionadoVO.getVrMaximoTitulo());
		sacadoExcepcionado.setIcInstrucaoProtesto(sacadoExcepcionadoVO.isIcInstrucaoProtesto());

		return sacadoExcepcionado;
	}

	/**
	 * <p>
	 * Método responsável por converter uma lista de sacadoExcepcionado em uma lista
	 * de SacadoExcepcionadoVO.
	 * <p>
	 *
	 * @param listaSacadoExcepcionado
	 *            valor a ser atribuído
	 * @return Collection<SacadoExcepcionadoVO>
	 * @author Bruno Martins
	 */
	public Collection<SacadoExcepcionadoVO> converterListaSacadoExcepcionadoEmListaSacadoExcepcionadoVO(
			final Collection<SacadoExcepcionado> listaSacadoExcepcionado) {

		final Collection<SacadoExcepcionadoVO> listaSacadoExcepcionadoVO = new ArrayList<>();

		for (final SacadoExcepcionado sacadoExcepcionado : listaSacadoExcepcionado) {
			final SacadoExcepcionadoVO sacadoExcepcionadoVO = new SacadoExcepcionadoVO();

			sacadoExcepcionadoVO.setNuGarantiaContrato(sacadoExcepcionado.getNuGarantiaContrato());
			sacadoExcepcionadoVO.setSacado(sacadoExcepcionado.getNuSacado());
			sacadoExcepcionadoVO.setCoDocumento(sacadoExcepcionado.getNuSacado().getCoDocumento());
			sacadoExcepcionadoVO.setNuSacadoExcepcionado(sacadoExcepcionado.getNuSacadoExcepcionado());
			sacadoExcepcionadoVO.setObservacao(sacadoExcepcionado.getObservacao());
			sacadoExcepcionadoVO.setPercentualMaximo(sacadoExcepcionado.getPercentualMaximo());
			sacadoExcepcionadoVO.setPrazoMaximoTitulo(sacadoExcepcionado.getPrazoMaximoTitulo());
			sacadoExcepcionadoVO.setVrMaximoTitulo(sacadoExcepcionado.getVrMaximoTitulo());
			sacadoExcepcionadoVO.setIcInstrucaoProtesto(sacadoExcepcionado.isIcInstrucaoProtesto());

			listaSacadoExcepcionadoVO.add(sacadoExcepcionadoVO);
		}

		return listaSacadoExcepcionadoVO;
	}

	/**
	 * <p>
	 * Método responsável por converter uma lista de {@link SacadoExcepcionadoVO} em
	 * uma lista de {@link SacadoExcepcionado}.
	 * <p>
	 *
	 * @param listaSacadoExcepcionadoVO
	 *            valor a ser atribuído
	 * @return Collection<SacadoExcepcionado>
	 * @author guilherme.santos
	 */
	public Collection<SacadoExcepcionado> converterListaSacadoExcepcionadoVOEmListaSacadoExcepcionado(
			final Collection<SacadoExcepcionadoVO> listaSacadoExcepcionadoVO) {

		final Collection<SacadoExcepcionado> listaSacadoExcepcionado = new ArrayList<>();

		for (final SacadoExcepcionadoVO sacadoExcepcionadoVO : listaSacadoExcepcionadoVO) {
			final SacadoExcepcionado sacadoExcepcionado = new SacadoExcepcionado();

			sacadoExcepcionado.setNuGarantiaContrato(sacadoExcepcionadoVO.getNuGarantiaContrato());
			sacadoExcepcionado.setNuSacado(sacadoExcepcionadoVO.getSacado());
			sacadoExcepcionado.setNuSacadoExcepcionado(sacadoExcepcionadoVO.getNuSacadoExcepcionado());
			sacadoExcepcionado.setObservacao(sacadoExcepcionadoVO.getObservacao());
			sacadoExcepcionado.setPercentualMaximo(sacadoExcepcionadoVO.getPercentualMaximo());
			sacadoExcepcionado.setPrazoMaximoTitulo(sacadoExcepcionadoVO.getPrazoMaximoTitulo());
			sacadoExcepcionado.setVrMaximoTitulo(sacadoExcepcionadoVO.getVrMaximoTitulo());
			sacadoExcepcionado.setIcInstrucaoProtesto(sacadoExcepcionadoVO.isIcInstrucaoProtesto());

			listaSacadoExcepcionado.add(sacadoExcepcionado);
		}

		return listaSacadoExcepcionado;
	}

	/**
	 * <p>
	 * Método responsável por recuperar a unidadeVinculadaSuat.
	 * <p>
	 *
	 * @author Bruno Martins de Carvalho
	 */
	public void recuperarNomeUnidade() {

		final ParametrizacaoContratoVisao visao = this.getVisao();

		visao.getContratoSelecionadoParaParametrizacao()
				.setUnidade(this.service.recuperarUnidadeVinculadaSuat(visao.getContratoSelecionadoParaParametrizacao().getNuUnidade()));
	}

	/**
	 * <p>
	 * Método responsável por atualizar o valor do faturamento.
	 * <p>
	 *
	 * @author guilherme.santos
	 */
	@Auditoria
	@OperacaoAuditoria(acao = "ATUALIZAR_FATURAMENTO")
	public void atualizarValorFaturamentoPessoa() {

		final String cliSerAcg = System.getProperty(AppConstant.PROPRIEDADE_CLI_SER_ACG);
		final String token = System.getProperty(AppConstant.PROPRIEDADE_TOKEN_SSO);
		final GenericVO generic = this.caixaKeycloakService.getServiceTokenSSO(cliSerAcg, token);
		this.getVisao().getContratoSelecionadoParaParametrizacao().getNuPessoa()
				.setCoResponsavelAlteracao(UsuarioUtil.getUsuarioLogado().getDeMatricula());

		final RespostaSicliTO resposta = this.getService().atualizarFaturamentoSegmentoPessoa(
				this.getVisao().getContratoSelecionadoParaParametrizacao().getNuPessoa().getNuCnpj(), generic.getMsg());
		if (resposta.isValido()) {
			super.adicionaMensagemDeSucesso(ParametrizacaoContratoMB.OPERACAO_REALIZADA_SUCESSO);
			this.getVisao().setContratoSelecionadoParaParametrizacao(this.service
					.obterContratoComRelacionamentosInicializados(this.getVisao().getContratoSelecionadoParaParametrizacao().getNuContrato()));
		} else {			
			//super.adicionaMensagemDeErro(resposta.getRetorno().getCodSituacao().concat(" - ").concat(resposta.getRetorno().getMensagem()));
			super.adicionaMensagemDeErro(ERRO_ATUALIAZACAO_VALOR_FATURAMENTO);
		}
	}

	/**
	 * <p>
	 * Método responsável por aplicar a máscara ao número de APF.
	 * </p>
	 * 
	 * @param nuApf
	 *            - Long número de APF.
	 * @return String - Número de APF com a máscara aplicada.
	 */
	public String formatarAPF(final Long nuApf) {

		if (nuApf == null) {
			return "";
		}

		final String apfComZeros = StringUtils.leftPad(String.valueOf(nuApf), 9, "0");

		final StringBuilder numeroAPFFormatado = new StringBuilder();
		numeroAPFFormatado.append(apfComZeros.substring(0, 1));
		numeroAPFFormatado.append(UtilFormatacao.PONTO);
		numeroAPFFormatado.append(apfComZeros.substring(1, 4));
		numeroAPFFormatado.append(UtilFormatacao.PONTO);
		numeroAPFFormatado.append(apfComZeros.substring(4, 7));
		numeroAPFFormatado.append(UtilFormatacao.HIFFEN);
		numeroAPFFormatado.append(apfComZeros.substring(7, 9));
		return numeroAPFFormatado.toString();
	}

	/**
	 * <p>
	 * Método responsável por carregar a lista de Tipologias de um Empreendimento.
	 * </p>
	 * 
	 * @param empreendimento
	 *            - Empreendimento a ser pesquisado.
	 */
	public void carregarTipologiasEmprendimento(final Empreendimento empreendimento) {
		this.getVisao().setFiltroPorNoTipologia("");
		final List<Tipologia> tipologias = new ArrayList<>(this.tipologiaService.listarTipologias(empreendimento));
		Collections.sort(tipologias);
		this.idxTipologia = 0;
		for (final Tipologia tipologia : tipologias) {
			tipologia.setIdxTipologia(this.idxTipologia);
			this.idxTipologia++;
		}

		this.visao.setListaTipologia(tipologias);

		if (!tipologias.isEmpty()) {
			this.habilitaSalvarELimpaMensagem();
		} else {
			this.getVisao().setPodeSalvarTipologias(Boolean.FALSE);
		}

	}

	/**
	 * Método utilitário para Habilitar o botão de Salvar e Limpar as mensagens de
	 * erro.
	 */
	private void habilitaSalvarELimpaMensagem() {
		this.getVisao().setCampoComErro(false);
		this.getVisao().setMensagemDeErroNaValidacaoCampo("");
		this.getVisao().setPodeSalvarTipologias(Boolean.TRUE);

	}

	/**
	 * <p>
	 * Método responsável por tratar o evento de edição em uma linha na tabela de
	 * Tipologias.
	 * </p>
	 * 
	 * @param event
	 *            - Evento de Edição de uma linha na tabela de Tipologias.
	 * @throws Exception
	 */
	public void onTipologiaEdit(final RowEditEvent event) {
		Tipologia tipologiaEditada = null;
		final FacesContext contexto = FacesContext.getCurrentInstance();

		try {
			tipologiaEditada = (Tipologia) ((DataTable) event.getComponent()).getRowData();

		} catch (final Exception e) {
			LogCEF.debug(e);
			return;

		}

		// Valida os novos valores inseridos na linha em relação aos existentes
		// na linha.

		if (UtilString.isVazio(tipologiaEditada.getNoTipologia())) {
			this.getVisao().setPodeSalvarTipologias(Boolean.FALSE);
			this.getVisao().setCampoComErro(true);
			this.getVisao().setMensagemDeErroNaValidacaoCampo("Nome da Tipologia precisa ser informada, para a linha editada !");
			contexto.validationFailed();
			return;
		} else {
			this.getVisao().setCampoComErro(false);
			this.getVisao().setMensagemDeErroNaValidacaoCampo("");
		}

		if (tipologiaEditada.getVrContratacao() == null || tipologiaEditada.getVrContratacao().compareTo(BigDecimal.ZERO) == 0) {
			this.getVisao().setPodeSalvarTipologias(Boolean.FALSE);
			this.getVisao().setCampoComErro(true);
			this.getVisao().setMensagemDeErroNaValidacaoCampo("Valor Contratação informado é inválido, para a linha editada !");
			contexto.validationFailed();
			return;
		} else {
			this.getVisao().setCampoComErro(false);
			this.getVisao().setMensagemDeErroNaValidacaoCampo("");
		}

		if (tipologiaEditada.getVrAtualizado() == null || tipologiaEditada.getVrAtualizado().compareTo(BigDecimal.ZERO) == 0) {
			this.getVisao().setPodeSalvarTipologias(Boolean.FALSE);
			this.getVisao().setCampoComErro(true);
			this.getVisao().setMensagemDeErroNaValidacaoCampo("Valor Atualizado informado é inválido, para a linha editada !");
			contexto.validationFailed();
			return;
		} else {
			this.getVisao().setCampoComErro(false);
			this.getVisao().setMensagemDeErroNaValidacaoCampo("");
		}

		// Valida os novos valores inseridos na linha em relação aos existentes
		// na tabela.
		final Collection<Tipologia> tipologiasParaProcurar = this.getVisao().getListaTipologia();

		if (tipologiasParaProcurar.size() > 1) {
			boolean podeFiltrar = false;
			if (tipologiaEditada.getNoTipologia() != null) {
				podeFiltrar = true;
			}
			if (podeFiltrar) {
				final List<Tipologia> encontrados = new ArrayList<>();
				for (final Tipologia procurado : tipologiasParaProcurar) {
					try {
						if ((procurado.getNoTipologia().equals(tipologiaEditada.getNoTipologia())
								&& (procurado.getIdxTipologia().intValue() != tipologiaEditada.getIdxTipologia().intValue()))) {
							encontrados.add(procurado);
						}
					} catch (final Exception e) {
						LogCefUtil.error(e);
					}
				}
				if (!encontrados.isEmpty()) {
					for (final Tipologia encontrado : encontrados) {
						if (encontrado.getNoTipologia().equals(tipologiaEditada.getNoTipologia())) {
							this.getVisao().setCampoComErro(true);
							this.getVisao().setMensagemDeErroNaValidacaoCampo("Já existe uma Tipologia com este nome Informado !");
							this.getVisao().setPodeSalvarTipologias(Boolean.FALSE);
							contexto.validationFailed();
							return;
						}
					}
				}
			}

			for (final Tipologia tipologiaParaValidar : tipologiasParaProcurar) {
				if (tipologiaParaValidar.getNoTipologia() != null) {
					if (UtilString.isVazio(tipologiaParaValidar.getNoTipologia())) {
						this.getVisao().setCampoComErro(true);
						this.getVisao().setMensagemDeErroNaValidacaoCampo(
								"O Nome da Tipologia informada é inválida em alguma linha da tabela, por favor verifique !");
						this.getVisao().setPodeSalvarTipologias(Boolean.FALSE);
						contexto.validationFailed();
						return;
					}
				} else {
					this.getVisao().setCampoComErro(true);
					this.getVisao().setMensagemDeErroNaValidacaoCampo(
							"O Nome da Tipologia informada é inválida em alguma linha da tabela, por favor verifique !");
					this.getVisao().setPodeSalvarTipologias(Boolean.FALSE);
					contexto.validationFailed();
					return;
				}

				if (tipologiaParaValidar.getVrContratacao() == null || tipologiaParaValidar.getVrContratacao().compareTo(BigDecimal.ZERO) == 0) {
					this.getVisao().setCampoComErro(true);
					this.getVisao().setMensagemDeErroNaValidacaoCampo(
							"O Valor Contratação informado é inválido em alguma linha da tabela, por favor verifique !");
					this.getVisao().setPodeSalvarTipologias(Boolean.FALSE);
					return;
				}

				if (tipologiaParaValidar.getVrAtualizado() == null || tipologiaParaValidar.getVrAtualizado().compareTo(BigDecimal.ZERO) == 0) {
					this.getVisao().setCampoComErro(true);
					this.getVisao().setMensagemDeErroNaValidacaoCampo(
							"O Valor Atualizado informado é inválido em alguma linha da tabela, por favor verifique !");
					this.getVisao().setPodeSalvarTipologias(Boolean.FALSE);
					contexto.validationFailed();
					return;
				}
			}
		}

		this.habilitaSalvarELimpaMensagem();

		if (tipologiaEditada != null && tipologiaEditada.getNuTipologia() != null) {
			this.getVisao().setEditingTipologia(true);
		}
	}

	/**
	 * <p>
	 * Método responsável por adicionar uma nova tipologia a lista/tabela de
	 * tipologias.
	 * </p>
	 */
	public void adicionarTipologia() {
		if (this.idxTipologia == null) {
			this.idxTipologia = 1;
		} else {
			this.idxTipologia++;
		}

		final Tipologia tipologia = new Tipologia();

		tipologia.setIdxTipologia(this.idxTipologia);

		tipologia.setInclusao(Boolean.TRUE);
		tipologia.setVrContratacao(new BigDecimal("0.00"));
		tipologia.setVrAtualizado(new BigDecimal("0.00"));

		if (this.getVisao().getListaTipologia() == null) {
			this.getVisao().setListaTipologia(new ArrayList<Tipologia>());
		}

		this.getVisao().getListaTipologia().add(tipologia);

		this.getVisao().setPodeSalvarTipologias(Boolean.FALSE);

		final DataTable dataTable = (DataTable) FacesContext.getCurrentInstance().getViewRoot()
				.findComponent("formParametrizacaoContrato:gridTipologia");
		if (dataTable != null && this.getVisao().getListaTipologia().size() > 10) {
			final BigDecimal quantidadeTipologia = new BigDecimal(this.getVisao().getListaTipologia().size());
			final BigDecimal paginasTable = new BigDecimal(dataTable.getPage() + 1).multiply(BigDecimal.TEN);
			final BigDecimal resto = quantidadeTipologia.divide(paginasTable, 2, BigDecimal.ROUND_HALF_UP);
			if (resto.compareTo(BigDecimal.ONE) > 0) {
				dataTable.setFirst(this.getVisao().getListaTipologia().size() / 10);
				RequestContext.getCurrentInstance()
						.execute("setTimeout(function(){PF('tipologiaTable').getPaginator().setPage(" + dataTable.getFirst() + ");},100)");
			}
		}

	}

	/**
	 * <p>
	 * Método responsável por excluir uma tipologia selecionada.
	 * </p>
	 */
	public void excluirTipologia(final Integer idxTipologia) {
		if (idxTipologia != null) {

			for (final Iterator<Tipologia> iterator = this.getVisao().getListaTipologia().iterator(); iterator.hasNext();) {
				final Tipologia tipologia = iterator.next();
				if (tipologia.getIdxTipologia().intValue() == idxTipologia.intValue()) {
					if (this.tipologiaService.podeExcluirTipologia(tipologia)) {
						if (tipologia.getNuTipologia() != null) {
							this.getVisao().setEditingTipologia(false);
						}
						iterator.remove();
						break;
					} else {
						this.getVisao().setCampoComErro(true);
						this.getVisao().setMensagemDeErroNaValidacaoCampo(
								"Existem Unidade Habitacionais Associadas a essa Tipologia!, Não é Possível Realizar a Exclusão.");
						return;
					}

				}
			}

			if (!this.getVisao().getListaTipologia().isEmpty()) {
				this.habilitaSalvarELimpaMensagem();

			} else {
				this.getVisao().setCampoComErro(true);
				this.getVisao().setMensagemDeErroNaValidacaoCampo("A lista de Tipologias não pode estar vazia !");
				this.getVisao().setPodeSalvarTipologias(Boolean.FALSE);
				return;
			}
		}

		// Exibe a mensagem de sucesso !
		RequestContext.getCurrentInstance().execute(ParametrizacaoContratoMB.PF_MODAL_SUCESSO_SHOW);
	}

	/**
	 * <p>
	 * Método responsável por carregar a lista de Unidades Habitacionais de um
	 * Empreendimento.
	 * </p>
	 * 
	 */
	public void carregarUnidadesHabitacionais() {
		carregarUnidadesHabitacionais(getVisao().getContratoSelecionadoParaParametrizacao().getEmpreendimento());
	}
	
    public void carregarUnidadesHabitacionais(Empreendimento empreendimento) {
	BigDecimal valorMantido = BigDecimal.ZERO;
	if (Objects.nonNull(empreendimento.getNuEmpreendimento())) {
	    valorMantido = unidadeHabitacionalService.obterValorMantido(empreendimento.getNuEmpreendimento());

	}
	unidadesHabitacionaisPaginada.adicionarFiltros(empreendimento, getVisao().getContratoSelecionadoParaParametrizacao(), valorMantido);

	carregarTipologiasEmprendimento(empreendimento);

	final UnidadeHabitacional uh = new UnidadeHabitacional();
	uh.setNuEmpreendimento(empreendimento);
	uh.setNuTipologia(new Tipologia());
	uh.setIcHipotecadaContratacao(true);
	uh.setIcMantidaHipoteca(true);
	getVisao().setUnidadeHabitacionalEmEdicao(uh);

	getVisao().setProponenteEmEdicao(new ProponenteHabitacional());
	getVisao().getProponenteEmEdicao().setIcTipo(TipoPessoaEnum.F);
	getVisao().setEstaEmEdicaoUnidadeHabitacional(Boolean.FALSE);
	getVisao().setEstaEmInclusaoOuEdicaoUnidadeHabitacional(Boolean.FALSE);
	getVisao().setPodeSalvarUnidadesHabitacionais(Boolean.FALSE);
    }

	public void carregarUnidadesHabitacionaisEmprendimentoConciliacaoPendenciaCPF(final Integer nuRecebido) {
		final Recebido recebido = this.recebidoService.obter(nuRecebido);
		this.setNuRecebido(nuRecebido);
		final Empreendimento e = this.empreendimentoService.obterInicializado(recebido.getNuEmpreendimento().longValue());
		this.getVisao().setContratoSelecionadoParaParametrizacao(e.getNuContrato());
		this.getVisao().getContratoSelecionadoParaParametrizacao().setEmpreendimento(e);
		carregarUnidadesHabitacionais(e); 

		// parametrizacaoContratoMB.visao.contratoSelecionadoParaParametrizacao.empreendimento.noEmpreendimento
	}

	/**
	 * <p>
	 * Método executado quando a combo de Tipologia é selecionado.
	 * </p>
	 * 
	 * @param evento
	 */
	public void onSelectTipologia() {

		final Tipologia tipologia = this.tipologiaService
				.obter(this.getVisao().getUnidadeHabitacionalEmEdicao().getNuTipologia().getNuTipologia());
		this.getVisao().getUnidadeHabitacionalEmEdicao().setNuTipologia(tipologia != null ? tipologia : new Tipologia());

	}

	/**
	 * <p>
	 * Método responsável por adicionar a unidadeHabitacional em adição ao grid de
	 * Unidades Habitacionais.
	 * </p>
	 */
	public void novaUnidadeHabitacional() {
		final UnidadeHabitacional uh = new UnidadeHabitacional();
		uh.setNuEmpreendimento(getVisao().getContratoSelecionadoParaParametrizacao().getEmpreendimento());
		uh.setNuTipologia(new Tipologia());
		uh.setIcHipotecadaContratacao(true);
		uh.setIcMantidaHipoteca(true);
		
		getVisao().setUnidadeHabitacionalEmEdicao(uh);

		getVisao().setTituloJanelaUnidadeHabitacional("Incluir Unidade Habitacional");

		getVisao().setPodeSalvarUnidadesHabitacionais(Boolean.TRUE);
		getVisao().setEstaEmEdicaoUnidadeHabitacional(Boolean.FALSE);
	}

	/**
	 * <p>
	 * Método responsável por selecionar uma unidadeHabitacional do grid de Unidades
	 * Habitacionais para edição.
	 * </p>
	 */
	public void selecionarUnidadeHabitacionalDoGrid(UnidadeHabitacional unidadeHabitacional) {
		getVisao().setUnidadeHabitacionalEmEdicao(unidadeHabitacionalService.carregarUnidadeHabitacionalComLazies(unidadeHabitacional));
		final UnidadeHabitacional unidadeHabitacionalTemp = UtilObjeto.clone(unidadeHabitacional);
		unidadeHabitacionalTemp.setNuTipologia(UtilObjeto.clone(unidadeHabitacional.getNuTipologia()));
		getVisao().setEstaEmEdicaoUnidadeHabitacional(Boolean.TRUE);
		getVisao().setPodeSalvarUnidadesHabitacionais(Boolean.TRUE);

    	carregarComercializacao(unidadeHabitacional);
    	carregarProspectosUnidadeHabitacional(unidadeHabitacional);
    	getVisao().setTituloJanelaUnidadeHabitacional("Alterar Unidade Habitacional");
    	carregarRecebidosUnidadeHabitacional(unidadeHabitacional);
    	carregarAmortizacoesUnidadeHabitacional(unidadeHabitacional);
	}

    /**
     * <p>
     * Método responsável por carregar o modal para tratamento da pendência
     * Ausência de Prospecto.
     * </p>
     */
    public void selecionarUHporTituloRecebido(final Integer nuRecebido) {
	this.setNuRecebido(nuRecebido);
	UnidadeHabitacional unidadeHabitacional = this.unidadeHabitacionalService.carregarUnidadeHabitacionalPorRecebidos(nuRecebido);

	if (UtilObjeto.isReferencia(unidadeHabitacional)) {

	    unidadeHabitacional = this.unidadeHabitacionalService.carregarUnidadeHabitacionalComLazies(unidadeHabitacional);
	    this.getVisao().setUnidadeHabitacionalEmEdicao(unidadeHabitacional);
	    final UnidadeHabitacional unidadeHabitacionalTemp = UtilObjeto.clone(unidadeHabitacional);
	    unidadeHabitacionalTemp.setNuTipologia(UtilObjeto.clone(unidadeHabitacional.getNuTipologia()));
	    this.getVisao().setEstaEmEdicaoUnidadeHabitacional(Boolean.TRUE);
	    this.getVisao().setPodeSalvarUnidadesHabitacionais(Boolean.TRUE);

	    // Carrega dados das Abas complementares
	    this.carregarComercializacao(unidadeHabitacional);
	    this.carregarProspectosUnidadeHabitacional(unidadeHabitacional);
	    this.getVisao().setTituloJanelaUnidadeHabitacional("Alterar Unidade Habitacional");
	    this.carregarRecebidosUnidadeHabitacional(unidadeHabitacional);
	    this.carregarAmortizacoesUnidadeHabitacional(unidadeHabitacional);

	}
    }

	/**
	 * <p>
	 * Método responsável por listar unidade habitacionais por Boleto Recebidos.
	 * </p>
	 */
	public void listarUHporDocumentoSacado(final String cpfCnpj) {
		this.visao.setListUnidadeHabitacional(this.unidadeHabitacionalService.listarUnidaderPorIdentificadorSacado(cpfCnpj));
	}

	/**
	 * <p>
	 * Método responsável por atualizar o contrato de comercialização da tabela
	 * Recebido.
	 * </p>
	 */
	public void atualizarUnidadeComercializacaoRecebido() {
		final UnidadeHabitacionalComercializacao c = this.unidadeHabitacionalComercializacaoService
				.obterUnidadeHabitacionalComercializacao(this.getVisao().getCodUHselecionada());
		this.recebidoService.alterarComercializacaoRecebido(this.getVisao().getNuRecebidoSelecionado(), c);
	}

	/**
	 * <p>
	 * Método responsável por excluir uma unidadeHabitacional selecionada.
	 * </p>
	 */
	public void excluirUnidadeHabitacional(UnidadeHabitacional unidadeHabitacional) {
		final UnidadeHabitacionalComercializacao comercializacao = this.unidadeHabitacionalComercializacaoService
				.obterUnidadeHabitacionalComercializacao(unidadeHabitacional.getNuUnidadeHabitacional());
		if (comercializacao != null && comercializacao.getNuComercializacao() != null) {
			final List<ParametroComercializacao> listaParametroComercializacao = this.parametroComercializacaoService
					.listarParametroPorUnidadeComercializacao(comercializacao.getNuComercializacao());

			if (!listaParametroComercializacao.isEmpty()) {

				for (final ParametroComercializacao comercializacaoParametro : listaParametroComercializacao) {
					final Collection<Prospecto> listaProspecto = this.prospectoService
							.listarPorParametroComercializacao(comercializacaoParametro);

					for (final Prospecto prospecto : listaProspecto) {
						this.prospectoService.remover(prospecto);
					}

					this.parametroComercializacaoService.remover(comercializacaoParametro);
				}
			}
			unidadeHabitacionalComercializacaoService.remover(comercializacao);
		}
			
		unidadeHabitacionalService.remover(unidadeHabitacional);

		RequestContext.getCurrentInstance().execute(ParametrizacaoContratoMB.PF_MODAL_SUCESSO_SHOW);
	}
	
	public void salvarUnidadeHabitacional() {
		final UnidadeHabitacional unidadeHabitacional = getVisao().getUnidadeHabitacionalEmEdicao();
		
		unidadeHabitacionalService.persistir(unidadeHabitacional);
		
		if (!unidadeHabitacional.hasMensagens()) {
			getVisao().setEstaEmEdicaoUnidadeHabitacional(Boolean.TRUE);
			
			getVisao().setTeveSucessoAoSalvarUnidadeHabitacional(Boolean.TRUE);
			RequestContext.getCurrentInstance().execute(PF_MODAL_SUCESSO_SHOW);
			carregarComercializacao(unidadeHabitacional);
		} else {
			adicionaListaMensagemDeAlerta(unidadeHabitacional.getMensagens());
		}
	}
	
	public void onTabChange(TabChangeEvent event) {
		int index = ((TabView) event.getSource()).getActiveIndex();
		
		if (index == 0) {
			if (getVisao().getUnidadeHabitacionalEmEdicao().hasMensagens()) {
    			adicionaListaMensagemDeAlerta(getVisao().getUnidadeHabitacionalEmEdicao().getMensagens());
			}
		} else if (index == 1) {
			if (getVisao().getUnidadeHabitacionalComercializacao().hasMensagens()) {
    			adicionaListaMensagemDeAlerta(getVisao().getUnidadeHabitacionalComercializacao().getMensagens());
			}
		} else if (index == 2) {
			if (getVisao().getProspectoTipoParcelaEmEdicao().hasMensagens()) {
    			adicionaListaMensagemDeAlerta(getVisao().getProspectoTipoParcelaEmEdicao().getMensagens());
			}
		}
    }

	/**
	 * <p>
	 * Método executado quando o filtro de Nome de Tipologia é digitado.
	 * </p>
	 * 
	 * @param evento
	 */
	public void onFiltroNoTipologia() {
		final Empreendimento empreendimento = this.getVisao().getContratoSelecionadoParaParametrizacao().getEmpreendimento();
		final Collection<Tipologia> tipologias = this.tipologiaService.listarTipologiasPorNome(empreendimento,
				this.getVisao().getFiltroPorNoTipologia());
		this.getVisao().setListaTipologia(tipologias);
		this.getVisao().setCampoComErro(false);
		this.getVisao().setMensagemDeErroNaValidacaoCampo("");
	}

	/**
	 * <p>
	 * Método responsável por carregar a UnidadeHabitacionalComercializacao de uma
	 * UnidadeHabitacional.
	 * </p>
	 * 
	 * @param unidadeHabitacional
	 *            - UnidadeHabitacional a ser pesquisada.
	 */
	private void carregarComercializacao(final UnidadeHabitacional unidadeHabitacional) {

		UnidadeHabitacionalComercializacao unidadeHabitacionalComercializacao = this.unidadeHabitacionalComercializacaoService
				.obterUnidadeHabitacionalComercializacao(unidadeHabitacional.getNuUnidadeHabitacional());
		Collection<ProponenteHabitacional> listaProponentesHabitacionaisUnidade = new ArrayList<ProponenteHabitacional>();

		if (UtilObjeto.isReferencia(unidadeHabitacionalComercializacao)) {
			listaProponentesHabitacionaisUnidade = proponenteHabitacionalService.listaProponenteHabitacional(unidadeHabitacionalComercializacao.getNuComercializacao());
			if (listaProponentesHabitacionaisUnidade != null && !listaProponentesHabitacionaisUnidade.isEmpty()) {
				for (final Iterator<ProponenteHabitacional> iterator = listaProponentesHabitacionaisUnidade.iterator(); iterator.hasNext();) {
					final ProponenteHabitacional proponenteHabitacional = (ProponenteHabitacional) iterator.next();
					final Pessoa pessoa = this.pessoaService.obter(proponenteHabitacional.getProponenteHabitacionalID().getNuPessoa());
					if (pessoa != null) {
						proponenteHabitacional.setCoDocumento(pessoa.getNuCnpj());
						proponenteHabitacional.setNome(pessoa.getNoPessoa());
					} else {
						iterator.remove();
					}
				}
			}
		} else {
			unidadeHabitacionalComercializacao = new UnidadeHabitacionalComercializacao();
			unidadeHabitacionalComercializacao.setNuUnidadeHabitacional(unidadeHabitacional);
			unidadeHabitacionalComercializacao.setIcRenegociada(false);
			unidadeHabitacionalComercializacao.setIcSituacao("01");
			unidadeHabitacionalComercializacao.setIcOrigemPlano(TipoPlanoPagamentoEnum.CCV.getCodigo());

			listaProponentesHabitacionaisUnidade = new ArrayList<>();
		}

		getVisao().setUnidadeHabitacionalComercializacao(unidadeHabitacionalComercializacao);
		getVisao().setListaProponentesHabitacionais(listaProponentesHabitacionaisUnidade);
		getVisao().setProponenteEmEdicao(new ProponenteHabitacional());
		getVisao().getProponenteEmEdicao().setIcTipo(TipoPessoaEnum.F);
		getVisao().setHistoricosProspecto(unidadeHabitacionalHistoricoService.relatorioPorUnidade(getVisao().getUnidadeHabitacionalEmEdicao()));
	}

	/**
	 * <p>
	 * Método responsável por buscar um Proponente na base de dados.
	 * <p>
	 *
	 * @author leandro.severino - lseverino@gmail.com
	 */
	public void buscarProponente() {
		unidadeHabitacionalComercializacaoService.buscar(getVisao().getProponenteEmEdicao());
		if (getVisao().getProponenteEmEdicao().hasMensagens()) {
			adicionaListaMensagemDeAlerta(getVisao().getProponenteEmEdicao().getMensagens());
		} else {
			if (getVisao().getProponenteEmEdicao().isIcNaoEncontrado()) {
				RequestContext.getCurrentInstance().execute("modalConfirmacaoInclusaoProponenteWV.show();");
			}
		}
	}

	public void uploadContratoUnidadeHabitacionalComercializacao() {
		throw new NotImplementedException();
	}

	/**
	 * <p>
	 * Método responsável por salvar o registro de Unidades Habitacionais
	 * Comercializacao.
	 * <p>
	 *
	 * @author leandro.severino - lseverino@gmail.com
	 */
	public void salvarComercializacao() {
		getVisao().getUnidadeHabitacionalComercializacao().setNuRecebidoSelecionado(getNuRecebido());
		unidadeHabitacionalComercializacaoService.persistir(getVisao().getUnidadeHabitacionalComercializacao(), getVisao().getListaProponentesHabitacionais());
		
		if (!getVisao().getUnidadeHabitacionalComercializacao().hasMensagens()) {
			getVisao().setEstaEmEdicaoUnidadeHabitacional(Boolean.TRUE);
			getVisao().setTeveSucessoAoSalvarUnidadeHabitacional(true);
			carregarProspectosUnidadeHabitacional(getVisao().getUnidadeHabitacionalEmEdicao());
			RequestContext.getCurrentInstance().execute(PF_MODAL_SUCESSO_SHOW);
		} else {
			adicionaListaMensagemDeAlerta(getVisao().getUnidadeHabitacionalComercializacao().getMensagens());
		}
	}


	/**
	 * <p>
	 * Método responsável por adicionar um Proponente a lista de Proponentes.
	 * <p>
	 *
	 * @author leandro.severino - lseverino@gmail.com
	 */
	public void adicionarProponenteHabitacional() {
		unidadeHabitacionalComercializacaoService.adicionar(getVisao().getProponenteEmEdicao());
		
		if (!getVisao().getProponenteEmEdicao().hasMensagens()) {
			boolean jaContemProponenteNaListagem = false;
			
			for (final ProponenteHabitacional proponente : getVisao().getListaProponentesHabitacionais()) {
				if (proponente.getProponenteHabitacionalID().getNuPessoa().intValue() == getVisao().getProponenteEmEdicao().getProponenteHabitacionalID().getNuPessoa().intValue()) {
					jaContemProponenteNaListagem = true;
					break;
				}
			}

			if (!jaContemProponenteNaListagem) {
				getVisao().getListaProponentesHabitacionais().add(getVisao().getProponenteEmEdicao());
				getVisao().setProponenteEmEdicao(new ProponenteHabitacional());
				getVisao().getProponenteEmEdicao().setIcTipo(TipoPessoaEnum.F);
				RequestContext.getCurrentInstance().execute(ParametrizacaoContratoMB.PF_MODAL_SUCESSO_SHOW);
			} else {
				adicionaMensagemDeAlerta("Proponente já consta na Listagem !");
			}
		} else {
			adicionaListaMensagemDeAlerta(getVisao().getProponenteEmEdicao().getMensagens());
		}
	}

	/**
	 * <p>
	 * Método responsável por excluir um Proponente da Lista de Proponentes.
	 * <p>
	 *
	 * @author leandro.severino - lseverino@gmail.com
	 */
	public void excluirProponenteHabitacional(final ProponenteHabitacional proponenteHabitacional) {
		boolean excluidoComSucesso = false;
		for (final Iterator<?> iterator = getVisao().getListaProponentesHabitacionais().iterator(); iterator.hasNext();) {
			final ProponenteHabitacional prop = (ProponenteHabitacional) iterator.next();
			if (prop.getProponenteHabitacionalID().getNuPessoa().intValue() == proponenteHabitacional.getProponenteHabitacionalID().getNuPessoa()
					.intValue()) {
				iterator.remove();
				excluidoComSucesso = true;
				break;
			}

		}
		if (excluidoComSucesso) {
			RequestContext.getCurrentInstance().execute(ParametrizacaoContratoMB.PF_MODAL_SUCESSO_SHOW);
		}
	}

	/**
	 * <p>
	 * Método responsável por carrregar os dados na aba Prospecto quando selecionada
	 * uma Unidade Habitacional para edição.
	 * <p>
	 * 
	 * @param unidadeHabitacional
	 *            - Unidade Habitacional para filtrar.
	 */
	private void carregarProspectosUnidadeHabitacional(final UnidadeHabitacional unidadeHabitacional) {
		this.getVisao().setProspectoTipoParcelaEmEdicao(new ProspectoTipoParcela());
		this.getVisao().getProspectoTipoParcelaEmEdicao().setIcPeriodicidadePrevista(0);

		this.getVisao().setFiltroPorTipoParcela(null);
		this.getVisao().setFiltroPorPeriodicidade(null);
		this.getVisao().setFiltroPorQuantidadeParcelas(null);
		this.getVisao().setFiltroPorDtInicio(null);

		this.getVisao().setPodeIncluirPropectosGerados(Boolean.TRUE);
		this.getVisao().setPodeGerarPropectosIncluidos(Boolean.FALSE);
		this.getVisao().setTemFiltroProspectoAtivo(Boolean.FALSE);
		this.getVisao().setEstaCarregandoModalProspectos(Boolean.TRUE);

		this.getVisao().setListaParametroComercializacao(null);
		this.getVisao().setListaParametroComercializacaoOriginal(null);
		this.getVisao().setValorTotalCalculadoLinhasProspectoComFiltroAtivo(null);
		this.getVisao().setValorTotalCalculadoLinhasProspecto(null);

		this.carregarProspectosGerados();
		this.onFiltroProspectos();
	}

	/**
	 * <p>
	 * Método responsável obter o TipoParcela de acordo com os valores selecionados
	 * na tela.
	 * <p>
	 * 
	 * @author leandro.severino - lseverino@gmail.com
	 */
	public void obterTipoParcela() {
		ProspectoTipoParcela tipoParcela = null;
		if (!UtilString.isVazio(this.getVisao().getProspectoTipoParcelaEmEdicao().getNoTipoParcela())
				&& this.getVisao().getProspectoTipoParcelaEmEdicao().getIcPeriodicidadePrevista() != null) {
			tipoParcela = this.prospectoTipoParcelaService
					.obtemTipoParcelaPorNomeEPeriodicidade(this.getVisao().getProspectoTipoParcelaEmEdicao().getNoTipoParcela());
		}

		if (tipoParcela != null) {
			if (getVisao().getProspectoTipoParcelaEmEdicao().isEdicao()) {
				tipoParcela.setEdicao(Boolean.TRUE);
			}

			this.getVisao().setProspectoTipoParcelaEmEdicao(tipoParcela);

			this.verificaSePodeIncluir();
		}
	}

	/**
	 * <p>
	 * Método responsável por verificar se um ParametroComerciliazacao pode ser
	 * inserido na tabela da tela.
	 * <p>
	 * 
	 * @author leandro.severino - lseverino@gmail.com
	 */
	public void verificaSePodeIncluir() {
		if (!UtilString.isVazio(this.getVisao().getProspectoTipoParcelaEmEdicao().getNoTipoParcela())
				&& this.getVisao().getProspectoTipoParcelaEmEdicao().getIcPeriodicidadePrevista() != null
				&& this.getVisao().getProspectoTipoParcelaEmEdicao().getDtInicio() != null
				&& (this.getVisao().getProspectoTipoParcelaEmEdicao().getVrParcela() != null
						&& this.getVisao().getProspectoTipoParcelaEmEdicao().getVrParcela().compareTo(BigDecimal.ZERO) != 0)) {
			this.getVisao().setPodeIncluirPropectosGerados(Boolean.TRUE);
		}
	}

	/**
	 * <p>
	 * Atribui o valor ao idxRecebido.
	 * </p>
	 * 
	 * @param idxRecebido
	 * @author leandro.severino - lseverino@gmail.com
	 */
	public void setIdxRecebido(final Integer idxRecebido) {
		this.idxRecebido = idxRecebido;
	}

	/**
	 * <p>
	 * Retorna o valor do idxRecebido.
	 * </p>
	 * 
	 * @return idxRecebibo
	 * @author leandro.severino - lseverino@gmail.com
	 */
	public Integer getIdxRecebido() {
		return this.idxRecebido;
	}

	/**
	 * <p>
	 * Atribui o valor ao idxAmortizacao.
	 * </p>
	 * 
	 * @param idxAmortizacao
	 * @author leandro.severino - lseverino@gmail.com
	 */
	public void setIdxAmortizacao(final Integer idxAmortizacao) {
		this.idxAmortizacao = idxAmortizacao;
	}

	/**
	 * <p>
	 * Retorna o valor do idxAmortizacao.
	 * </p>
	 * 
	 * @return idxAmortizacao
	 * @author leandro.severino - lseverino@gmail.com
	 */
	public Integer getIdxAmortizacao() {
		return this.idxAmortizacao;
	}

	/**
	 * <p>
	 * Atribui o valor ao motivoInativacaoRegistro.
	 * </p>
	 * 
	 * @param motivoInativacaoRegistro
	 * @author leandro.severino - lseverino@gmail.com
	 */
	public void setMotivoInativacaoRegistro(final String motivoInativacaoRegistro) {
		this.motivoInativacaoRegistro = motivoInativacaoRegistro;
	}

	/**
	 * <p>
	 * Retorna o valor do motivoInativacaoRegistro.
	 * </p>
	 * 
	 * @return motivoInativacaoRegistro
	 * @author leandro.severino - lseverino@gmail.com
	 */
	public String getMotivoInativacaoRegistro() {
		return this.motivoInativacaoRegistro;
	}

	/**
	 * <p>
	 * Atribui o valor ao motivoInativacaoAmortizacao.
	 * </p>
	 * 
	 * @param motivoInativacaoAmortizacao
	 * @author leandro.severino - lseverino@gmail.com
	 */
	public void setMotivoInativacaoAmortizacao(final String motivoInativacaoAmortizacao) {
		this.motivoInativacaoAmortizacao = motivoInativacaoAmortizacao;
	}

	/**
	 * <p>
	 * Retorna o valor do motivoInativacaoAmortizacao.
	 * </p>
	 * 
	 * @return motivoInativacaoAmortizacao
	 * @author leandro.severino - lseverino@gmail.com
	 */
	public String getMotivoInativacaoAmortizacao() {
		return this.motivoInativacaoAmortizacao;
	}

	/**
	 * <p>
	 * Método responsável por Associar a Listagem de Prospectos a Unidade
	 * Habitacional.
	 * <p>
	 * 
	 * @author leandro.severino - lseverino@gmail.com
	 */
	public void incluirProspectos() {
		prospectoService.validar(getVisao().getProspectoTipoParcelaEmEdicao(), getVisao().getUnidadeHabitacionalComercializacao());
		
		if (!getVisao().getProspectoTipoParcelaEmEdicao().hasMensagens()) {
			final String matricula = UsuarioUtil.getUsuarioLogado().getDeMatricula();
			final int qtdeParcelas = this.getVisao().getProspectoTipoParcelaEmEdicao().getNuOcorrenciaPrevista();

			if (this.getVisao().getListaParametroComercializacao() == null) {
				this.getVisao().setListaParametroComercializacao(new ArrayList<ParametroComercializacao>());
			}

			if (this.getVisao().getListaProspectoTipoParcela() == null) {
				this.getVisao().setListaProspectoTipoParcela(new ArrayList<ProspectoTipoParcela>());
			}

			final Collection<ParametroComercializacao> parametrosCalculados = new ArrayList<>();

			ParametroComercializacao parametroComercializacao;
			if (getVisao().getProspectoTipoParcelaEmEdicao().isEdicao()) {
				parametroComercializacao = getVisao().getParametroComercializacaoEmEdicao();
			} else {
				parametroComercializacao = new ParametroComercializacao();
				parametroComercializacao.setIcTipoAcao(1);
			}

			parametroComercializacao.setNuUnidadeHabitacionalComercializacao(this.getVisao().getUnidadeHabitacionalComercializacao());
			parametroComercializacao.setNuTipoParcela(this.getVisao().getProspectoTipoParcelaEmEdicao());
			parametroComercializacao.setIcPeriodicidade(this.getVisao().getProspectoTipoParcelaEmEdicao().getIcPeriodicidadePrevista());

			parametroComercializacao.setDtPrevistaInicio(this.getVisao().getProspectoTipoParcelaEmEdicao().getDtInicio());
			parametroComercializacao.setVrPrevisto(this.getVisao().getProspectoTipoParcelaEmEdicao().getVrParcela());
			parametroComercializacao.setNuQtdeOcorrencia(this.getVisao().getProspectoTipoParcelaEmEdicao().getNuOcorrenciaPrevista());
			parametroComercializacao.setIcExclusaoDistrato(false);
			parametroComercializacao.setDhInclusao(new Date());
			parametroComercializacao.setCoResponsavel(matricula);
			final BigDecimal vrTotalParametroCalculado = this.getVisao().getProspectoTipoParcelaEmEdicao().getVrParcela()
					.multiply(new BigDecimal(this.getVisao().getProspectoTipoParcelaEmEdicao().getNuOcorrenciaPrevista()));
			parametroComercializacao.setVrTotal(vrTotalParametroCalculado);

			Date dtUltimaParcelaGerada = null;

			if (getVisao().getProspectoTipoParcelaEmEdicao().isEdicao()) {
				parametroComercializacao.setListaProspecto(new ArrayList<Prospecto>());
			}

			for (int i = 1; i <= qtdeParcelas; i++) {
				final Prospecto prospecto = new Prospecto();
				prospecto.setNuParametroComercializacao(parametroComercializacao);
				prospecto.setNuRecebido(null);

				final Calendar cal = Calendar.getInstance();
				cal.setTime(this.getVisao().getProspectoTipoParcelaEmEdicao().getDtInicio());

				if (i == 1) {
					dtUltimaParcelaGerada = cal.getTime();
					prospecto.setDtPrevista(cal.getTime());
				} else {
					dtUltimaParcelaGerada = this.criarDataFutura(dtUltimaParcelaGerada,
							this.getVisao().getProspectoTipoParcelaEmEdicao().getIcPeriodicidadePrevista(), parametroComercializacao.getListaProspecto());
					prospecto.setDtPrevista(dtUltimaParcelaGerada);
				}

				prospecto.setVrProspecto(this.getVisao().getProspectoTipoParcelaEmEdicao().getVrParcela());
				prospecto.setVrAtualizado(this.getVisao().getProspectoTipoParcelaEmEdicao().getVrParcela());
				prospecto.setDhAtualizacao(new Date());
				prospecto.setDtReferenciaIndicador(new Date());
				prospecto.setDtProspecto(null);
				prospecto.setDhInclusao(new Date());

				prospecto.setCoResponsavel(matricula);

				if (parametroComercializacao.getListaProspecto() == null) {
					parametroComercializacao.setListaProspecto(new ArrayList<Prospecto>());
				}

				parametroComercializacao.getListaProspecto().add(prospecto);
			}

			if (!getVisao().getProspectoTipoParcelaEmEdicao().isEdicao()) {

				parametrosCalculados.add(parametroComercializacao);
				this.getVisao().getListaParametroComercializacao().add(parametroComercializacao);

				if (this.getVisao().getProspectoTipoParcelaEmEdicao().getListaParametroComercializacao() == null) {
					this.getVisao().getProspectoTipoParcelaEmEdicao().setListaParametroComercializacao(new ArrayList<ParametroComercializacao>());
				}

				this.getVisao().getProspectoTipoParcelaEmEdicao().getListaParametroComercializacao().addAll(parametrosCalculados);

				this.getVisao().getListaProspectoTipoParcela().add(this.getVisao().getProspectoTipoParcelaEmEdicao());
			}

			BigDecimal valorTotalCalculado = new BigDecimal("0.00");

			for (final ParametroComercializacao item : this.getVisao().getListaParametroComercializacao()) {

				valorTotalCalculado = valorTotalCalculado.add(item.getVrTotal());
			}

			final NumberFormat nf = NumberFormat.getCurrencyInstance();

			this.getVisao().setValorTotalCalculadoLinhasProspecto(nf.format(valorTotalCalculado));

			if (valorTotalCalculado.compareTo(this.valorCompraVendaProspecto()) >= 0) {
				getVisao().setPodeGerarPropectosIncluidos(Boolean.TRUE);
				getVisao().setPodeIncluirPropectosGerados(Boolean.TRUE);
			} else {
				getVisao().setPodeGerarPropectosIncluidos(Boolean.FALSE);
				getVisao().setPodeIncluirPropectosGerados(Boolean.TRUE);
			}

			
			if (this.getVisao().getProspectoTipoParcelaEmEdicao().isEdicao()) {
				this.getVisao().setProspectoTipoParcelaEmEdicao(new ProspectoTipoParcela());
				this.getVisao().getProspectoTipoParcelaEmEdicao().setIcPeriodicidadePrevista(0);

				gerarProspectos();
			}

			this.getVisao().setProspectoTipoParcelaEmEdicao(new ProspectoTipoParcela());
			this.getVisao().getProspectoTipoParcelaEmEdicao().setIcPeriodicidadePrevista(0);

			RequestContext.getCurrentInstance().execute(ParametrizacaoContratoMB.PF_MODAL_SUCESSO_SHOW);
		} else {
			adicionaListaMensagemDeAlerta(getVisao().getProspectoTipoParcelaEmEdicao().getMensagens());
		}
	}

	/**
	 * <p>
	 * Método que calcula as datas das parcelas.
	 * </p>
	 * 
	 * @param dtBase
	 *            - Date - Data de base.
	 * @param vrPeriodicidade
	 *            - int - Periodicidade.
	 * @param listaValidar
	 *            - Collection - Lista dos valores de parcelas já inseridos na
	 *            tabela.
	 * @return dataFuturaCriada - Date - Data calculada.
	 * @author leandro.severino - lseverino@gmail.com
	 */
	@SuppressWarnings({ "rawtypes", "unchecked" })
	private Date criarDataFutura(final Date dtBase, final int vrPeriodicidade, final Collection<Prospecto> listaValidar) {

		Date dataFuturaCriada = null;

		if (listaValidar != null) {
			final DataProspectoComparator dataPrevistaComparator = new DataProspectoComparator();

			final List<Prospecto> lstProspectos = (ArrayList) listaValidar;

			Collections.sort(lstProspectos, dataPrevistaComparator);

			boolean podeInserirData = false;

			final Calendar cal = Calendar.getInstance();
			cal.setTime(dtBase);

			if (vrPeriodicidade > 0) {
				cal.add(Calendar.MONTH, vrPeriodicidade);
			}

			for (final Prospecto prospecto : listaValidar) {

				if (prospecto.getDtPrevista().getTime() == cal.getTime().getTime()) {
					continue;
				} else if (prospecto.getDtPrevista().getTime() < cal.getTime().getTime()) {
					podeInserirData = true;
				} else {
					podeInserirData = false;
				}
			}

			if (podeInserirData) {
				dataFuturaCriada = cal.getTime();
			}
		} else {
			dataFuturaCriada = dtBase;
		}

		return dataFuturaCriada;
	}

	/**
	 * <p>
	 * Método para excluir um ParametroComercializacao e suas respectivas parcelas.
	 * </p>
	 * 
	 * @author leandro.severino - lseverino@gmail.com
	 */
	public void excluirProspectoSelecionado() {
		if(getVisao().getParametroComercializacaoEmExclusao().getNuParametroComercializacao() == null) {
			for (final Iterator<ParametroComercializacao> iterator = getVisao().getListaParametroComercializacao().iterator(); iterator.hasNext();) {
				final ParametroComercializacao parametro = iterator.next();
				if (parametro.getIdxParametroComercializacao() != null && parametro.getIdxParametroComercializacao().equals(getVisao().getParametroComercializacaoEmExclusao().getIdxParametroComercializacao())) {
					iterator.remove();
				}
				
			}
			
			getVisao().getUnidadeHabitacionalComercializacao().setParametros(new HashSet<ParametroComercializacao>());
			getVisao().getParametroComercializacaoEmExclusao().setIcTipoAcao(3);
		} else { 
			parametroComercializacaoService.removerCascade(getVisao().getParametroComercializacaoEmExclusao());
			
			getVisao().getListaParametroComercializacao().remove(getVisao().getParametroComercializacaoEmExclusao());

			getVisao().getUnidadeHabitacionalComercializacao().setParametros(new HashSet<ParametroComercializacao>());
			getVisao().getParametroComercializacaoEmExclusao().setIcTipoAcao(3);
			getVisao().getUnidadeHabitacionalComercializacao().getParametros().add(getVisao().getParametroComercializacaoEmExclusao());
		}

		BigDecimal valorTotalCalculado = new BigDecimal("0.00");
		for (final ParametroComercializacao item : getVisao().getListaParametroComercializacao()) {
			item.setProspectos(new HashSet<Prospecto>());
			item.getProspectos().addAll(item.getListaProspecto());
		}
		
		for (final ParametroComercializacao item : getVisao().getListaParametroComercializacao()) {
			valorTotalCalculado = valorTotalCalculado.add(item.getVrTotal());
		}
		
		final NumberFormat nf = NumberFormat.getCurrencyInstance();
		this.getVisao().setValorTotalCalculadoLinhasProspecto(nf.format(valorTotalCalculado));
		if (valorTotalCalculado.compareTo(this.valorCompraVendaProspecto()) >= 0) {
			this.getVisao().setPodeGerarPropectosIncluidos(Boolean.TRUE);
			this.getVisao().setPodeIncluirPropectosGerados(Boolean.TRUE);
		} else {
			this.getVisao().setPodeGerarPropectosIncluidos(Boolean.FALSE);
			this.getVisao().setPodeIncluirPropectosGerados(Boolean.TRUE);
		}
		this.getVisao().setPodeAlterarValorCV(Boolean.FALSE);
		getVisao().getUnidadeHabitacionalComercializacao().getParametros().addAll(getVisao().getListaParametroComercializacao());
		
		for (ParametroComercializacao item : getVisao().getUnidadeHabitacionalComercializacao().getParametros()) {
			item.setProspectos(new HashSet<Prospecto>());
			item.getProspectos().addAll(item.getListaProspecto());
		}
		
		if (getVisao().getParametroComercializacaoEmExclusao().getNuParametroComercializacao() != null) {
			unidadeHabitacionalHistoricoService.salvar(getVisao().getUnidadeHabitacionalComercializacao(), super.getMatriculaUsuario());
			getVisao().setHistoricosProspecto(unidadeHabitacionalHistoricoService.relatorioPorUnidade(getVisao().getUnidadeHabitacionalEmEdicao()));
		}
		
		RequestContext.getCurrentInstance().execute(ParametrizacaoContratoMB.PF_MODAL_SUCESSO_SHOW);
	}

	/**
	 * <p>
	 * Método executado para carregar os prospectos já persitidos previamente.
	 * </p>
	 * 
	 * @author leandro.severino - lseverino@gmail.com
	 */
	private void carregarProspectosGerados() {
		final List<ParametroComercializacao> listaPersistida = this.parametroComercializacaoService
				.listarPorUnidadeComercializacao(this.getVisao().getUnidadeHabitacionalComercializacao());

		if (!listaPersistida.isEmpty()) {

			for (final ParametroComercializacao parametro : listaPersistida) {

				parametro.setVrTotal(parametro.getVrPrevisto());

				final Collection<Prospecto> listaProspectos = this.prospectoService.listarPorParametroComercializacao(parametro);
				parametro.setListaProspecto(listaProspectos);

				if (!listaProspectos.isEmpty() && !this.getVisao().getPodeIncluirPropectosGerados()) {
					this.getVisao().setPodeAlterarValorCV(Boolean.TRUE);
				} else {
					this.getVisao().setPodeAlterarValorCV(Boolean.FALSE);
				}
			}

			this.getVisao().setListaParametroComercializacao(listaPersistida);

		} else {
			this.getVisao().setPodeAlterarValorCV(Boolean.FALSE);
		}

	}

	/**
	 * <p>
	 * Método executado quando algum filtro é digitado no grid de Unidades
	 * Habitacionais.
	 * </p>
	 * 
	 * @param evento
	 */
	public void onFiltroProspectos() {

		List<ParametroComercializacao> listaOriginal = (ArrayList<ParametroComercializacao>) this.getVisao().getListaParametroComercializacao();

		if (this.getVisao().getListaParametroComercializacaoOriginal() == null) {
			if (CollectionUtils.isNotEmpty(listaOriginal)) {
				this.getVisao().setListaParametroComercializacaoOriginal(this.getVisao().getListaParametroComercializacao());
			}

		} else if (this.getVisao().getListaParametroComercializacaoOriginal().size() != listaOriginal.size()) {
			if (listaOriginal.size() < this.getVisao().getListaParametroComercializacaoOriginal().size()) {
				listaOriginal = (ArrayList<ParametroComercializacao>) this.getVisao().getListaParametroComercializacaoOriginal();
			}
		}

		final List<ParametroComercializacao> listaFiltrada = new ArrayList<>();

		final String noTipoParcelaFilter = UtilString.isVazio(this.getVisao().getFiltroPorTipoParcela()) ? ""
				: this.getVisao().getFiltroPorTipoParcela();
		final Integer nuPeriodicidadeFilter = this.getVisao().getFiltroPorPeriodicidade() == null ? -1 : this.getVisao().getFiltroPorPeriodicidade();
		final Integer nuQtdeParcelaFilter = this.getVisao().getFiltroPorQuantidadeParcelas() == null ? 0
				: this.getVisao().getFiltroPorQuantidadeParcelas();
		final Date dtInicioFilter = this.getVisao().getFiltroPorDtInicio() == null ? null : this.getVisao().getFiltroPorDtInicio();

		final boolean testFiltroNoTipoParcela = !UtilString.isVazio(noTipoParcelaFilter);
		final boolean testFiltroNuPeriodicidade = nuPeriodicidadeFilter != null && nuPeriodicidadeFilter != -1;
		final boolean testFiltroQtdeParcela = nuQtdeParcelaFilter > 0 && nuQtdeParcelaFilter != null;
		final boolean testDtInicio = dtInicioFilter != null;

		boolean semFiltro = false;

		if (!testFiltroNoTipoParcela && !testFiltroNuPeriodicidade && !testFiltroQtdeParcela && !testDtInicio) {
			semFiltro = true;
			this.getVisao().setPodeIncluirPropectosGerados(Boolean.TRUE);
			this.getVisao().setTemFiltroProspectoAtivo(Boolean.FALSE);
			listaOriginal = (ArrayList<ParametroComercializacao>) this.getVisao().getListaParametroComercializacaoOriginal();
		} else {
			this.getVisao().setPodeIncluirPropectosGerados(Boolean.FALSE);
			this.getVisao().setTemFiltroProspectoAtivo(Boolean.TRUE);
		}

		if (listaOriginal != null) {
			for (final ParametroComercializacao item : listaOriginal) {

				if ((!testFiltroNoTipoParcela || item.getNuTipoParcela().getNoTipoParcela().equalsIgnoreCase(noTipoParcelaFilter))
						&& (!testFiltroNuPeriodicidade
								|| item.getNuTipoParcela().getIcPeriodicidadePrevista().intValue() == nuPeriodicidadeFilter.intValue())
						&& (!testFiltroQtdeParcela || item.getNuQtdeOcorrencia() == nuQtdeParcelaFilter.intValue())
						&& (!testDtInicio || item.getNuTipoParcela().getDtInicio().getTime() == dtInicioFilter.getTime())) {

					listaFiltrada.add(item);
				}
			}
		}

		if (!listaFiltrada.isEmpty() && !semFiltro) {
			this.getVisao().setListaParametroComercializacao(listaFiltrada);

			BigDecimal valorTotalCalculado = new BigDecimal("0.00");

			for (final ParametroComercializacao item : this.getVisao().getListaParametroComercializacao()) {

				for (int i = 0; i < item.getNuQtdeOcorrencia(); i++) {
					valorTotalCalculado = valorTotalCalculado.add(item.getVrTotal());
				}
			}

			final NumberFormat nf = NumberFormat.getCurrencyInstance();
			this.getVisao().setValorTotalCalculadoLinhasProspectoComFiltroAtivo(nf.format(valorTotalCalculado));

			this.valoresParametrizacaoIgualValorCV(this.getVisao().getListaParametroComercializacao(),
					this.getVisao().getEstaCarregandoModalProspectos());

		} else {
			if (semFiltro) {
				this.getVisao().setValorTotalCalculadoLinhasProspectoComFiltroAtivo("");
				this.getVisao().setListaParametroComercializacao(this.getVisao().getListaParametroComercializacaoOriginal());

				BigDecimal valorTotalCalculado = new BigDecimal("0.00");

				if (this.getVisao().getListaParametroComercializacao() != null) {
					for (final ParametroComercializacao item : this.getVisao().getListaParametroComercializacao()) {
						BigDecimal valorTotalItem = new BigDecimal("0.00");
						for (int i = 0; i < item.getNuQtdeOcorrencia(); i++) {
							valorTotalCalculado = valorTotalCalculado.add(item.getVrTotal());
							valorTotalItem = valorTotalItem.add(item.getVrTotal());

						}
						item.setVrTotal(valorTotalItem);
					}
					final NumberFormat nf = NumberFormat.getCurrencyInstance();
					this.getVisao().setValorTotalCalculadoLinhasProspecto(nf.format(valorTotalCalculado));

					this.valoresParametrizacaoIgualValorCV(this.getVisao().getListaParametroComercializacaoOriginal(),
							this.getVisao().getEstaCarregandoModalProspectos());
				}
			} else {
				this.getVisao().setValorTotalCalculadoLinhasProspectoComFiltroAtivo("");
				this.getVisao().setListaParametroComercializacao(listaFiltrada);
			}

		}

		this.getVisao().setEstaCarregandoModalProspectos(Boolean.FALSE);

	}

	/**
	 * <p>
	 * Método que soma o valor das parcelas de um ParametroComercializacao.
	 * </p>
	 * 
	 * @param listaProspecto
	 *            - Collection - Lista de Prospectos (parcelas) a ser somado.
	 * @return retornoSoma - BigDecimal - Valor total somado.
	 * @author leandro.severino - lseverino@gmail.com
	 */
	@SuppressWarnings("unused")
	private BigDecimal somarValorParcelas(final Collection<Prospecto> listaProspecto) {
		BigDecimal retornoSoma = new BigDecimal("0.00");

		for (final Prospecto prospecto : listaProspecto) {
			retornoSoma = retornoSoma.add(prospecto.getVrProspecto());
		}

		return retornoSoma;
	}

	/**
	 * <p>
	 * Método que valida se o valor somado das parcelas é igual ao valor CV.
	 * </p>
	 * 
	 * @param listaParametroComercializacao
	 *            - Collection - Lista a ser avaliada.
	 * @param estaCarregando
	 *            - boolean - Indica se está ou não carregando a tela.
	 * @author leandro.severino - lseverino@gmail.com
	 */
	private void valoresParametrizacaoIgualValorCV(final Collection<ParametroComercializacao> listaParametroComercializacao,
			final boolean estaCarregando) {

		BigDecimal valorTotalCalculado = new BigDecimal("0.00");

		for (final ParametroComercializacao item : listaParametroComercializacao) {
			valorTotalCalculado = valorTotalCalculado.add(item.getVrTotal());
		}

		if (valorTotalCalculado.compareTo(this.valorCompraVendaProspecto()) >= 0) {
			if (estaCarregando) {
				this.getVisao().setPodeGerarPropectosIncluidos(Boolean.TRUE);
				this.getVisao().setPodeIncluirPropectosGerados(Boolean.TRUE);
			} else {
				this.getVisao().setPodeGerarPropectosIncluidos(Boolean.TRUE);
				this.getVisao().setPodeIncluirPropectosGerados(Boolean.FALSE);
			}

		}

	}

	/**
	 * <p>
	 * Método responsável por Persistir a Listagem de Prospectos.
	 * <p>
	 * 
	 * @author leandro.severino - lseverino@gmail.com
	 */
	public void gerarProspectos() {
		for (final ParametroComercializacao parametroComercializacao : this.getVisao().getListaParametroComercializacao()) {
			parametroComercializacao.setProspectos(new HashSet<Prospecto>());
			parametroComercializacao.getProspectos().addAll(parametroComercializacao.getListaProspecto());

			if (parametroComercializacao.getIcTipoAcao() > 0) {
				if (parametroComercializacao.getIcTipoAcao() == 1) {
					this.parametroComercializacaoService.inserir(parametroComercializacao);

					for (final Prospecto prospecto : parametroComercializacao.getListaProspecto()) {
						prospecto.setNuParametroComercializacao(parametroComercializacao);
						this.prospectoService.inserir(prospecto);
					}
				}

				if (parametroComercializacao.getIcTipoAcao() == 2) {
					parametroComercializacaoService.alterar(parametroComercializacao);

					for (final Prospecto prospecto : prospectoService
							.listarPorParametroComercializacao(parametroComercializacao)) {
						prospectoService.remover(prospecto);
					}

					for (final Prospecto prospecto : parametroComercializacao.getListaProspecto()) {
						prospecto.setNuParametroComercializacao(parametroComercializacao);
						prospectoService.inserir(prospecto);
					}
				}

				parametroComercializacao.setProspectos(new HashSet<Prospecto>());
				parametroComercializacao.getProspectos().addAll(parametroComercializacao.getListaProspecto());
			}
		}

		if (CollectionUtils.isNotEmpty(getVisao().getListaParametroComercializacao())) {
			getVisao().getUnidadeHabitacionalComercializacao().setParametros(new HashSet<ParametroComercializacao>());
			getVisao().getUnidadeHabitacionalComercializacao().getParametros().addAll(getVisao().getListaParametroComercializacao());
			unidadeHabitacionalHistoricoService.salvar(getVisao().getUnidadeHabitacionalComercializacao(), super.getMatriculaUsuario());
			getVisao().setHistoricosProspecto(unidadeHabitacionalHistoricoService.relatorioPorUnidade(getVisao().getUnidadeHabitacionalEmEdicao()));
			
			for (ParametroComercializacao parametroComercializacao : this.getVisao().getListaParametroComercializacao()) {
				parametroComercializacao.setIcTipoAcao(0);
			}
			
		}

		this.getVisao().setPodeGerarPropectosIncluidos(Boolean.TRUE);
		this.getVisao().setPodeIncluirPropectosGerados(Boolean.TRUE);
		this.getVisao().setPodeAlterarValorCV(Boolean.TRUE);

		if (getNuRecebido() != null) {
			this.recebidoService.alterarSituacaoConciliacao(getNuRecebido());
		}

		RequestContext.getCurrentInstance().execute(PF_MODAL_SUCESSO_SHOW);
	}

	public void editarProspecto(ParametroComercializacao parametroComercializacao) {
		getVisao().setParametroComercializacaoEmEdicao(parametroComercializacao);
		getVisao().setProspectoTipoParcelaEmEdicao(getVisao().getParametroComercializacaoEmEdicao().getNuTipoParcela());
		getVisao().getProspectoTipoParcelaEmEdicao().setDtInicio(getVisao().getParametroComercializacaoEmEdicao().getDtPrevistaInicio());
		getVisao().getProspectoTipoParcelaEmEdicao().setNuOcorrenciaPrevista(getVisao().getParametroComercializacaoEmEdicao().getNuQtdeOcorrencia());
		getVisao().getProspectoTipoParcelaEmEdicao()
				.setIcPeriodicidadePrevista(getVisao().getParametroComercializacaoEmEdicao().getIcPeriodicidade());

		getVisao().getProspectoTipoParcelaEmEdicao().setVrParcela(getVisao().getParametroComercializacaoEmEdicao().getVrPrevisto());
		getVisao().getProspectoTipoParcelaEmEdicao().setEdicao(Boolean.TRUE);
		getVisao().getParametroComercializacaoEmEdicao().setIcTipoAcao(2);

		BigDecimal valorTotalCalculado = new BigDecimal("0.00");

		for (final ParametroComercializacao item : getVisao().getListaParametroComercializacao()) {
			valorTotalCalculado = valorTotalCalculado.add(item.getVrTotal());
		}

		if (valorTotalCalculado.compareTo(this.valorCompraVendaProspecto()) >= 0) {
			this.getVisao().setPodeGerarPropectosIncluidos(Boolean.TRUE);
			this.getVisao().setPodeIncluirPropectosGerados(Boolean.TRUE);
		}
	}

	/**
	 * <p>
	 * Método responsável por carrregar os dados na aba Recebido quando selecionada
	 * uma Unidade Habitacional para edição.
	 * <p>
	 * 
	 * @param unidadeHabitacional
	 *            - Unidade Habitacional para filtrar.
	 * @author leandro.severino - lseverino@gmail.com
	 */
	private void carregarRecebidosUnidadeHabitacional(final UnidadeHabitacional unidadeHabitacional) {

		// Limpa os filtros de Tela relacionados a aba de Recebidos.
		this.getVisao().setFiltroPorTipoParcelaRecebidos(null);
		this.getVisao().setFiltroPorDtVencimentoRecebidos(null);
		this.getVisao().setFiltroPorNDocumentoRecebidos(null);
		this.getVisao().setFiltroPorNossoNumeroRecebidos(null);
		this.getVisao().setFiltroPorValorTituloRecebidos(null);
		this.getVisao().setFiltroPorValorPagoRecebidos(null);
		this.getVisao().setFiltroPorNCedenteRecebidos(null);
		this.getVisao().setFiltroPorNProponenteRecebidos(null);
		this.getVisao().setIcRegistrosInativos(Boolean.FALSE);

		// Faz o recarregamento do objeto Unidade Habitacional com os
		// respectivos dados
		// lazys
		// necessários para serem exibidos na aba.
		this.getVisao().setUnidadeHabitacionalEmEdicao(this.unidadeHabitacionalService.carregarUnidadeHabitacionalComLazies(unidadeHabitacional));

		this.onFiltroRecebidos();
	}

	/**
	 * <p>
	 * Método auxiliar que retorna o nome do Tipo da Parcela.
	 * </p>
	 * 
	 * @param nuTipoParcela
	 *            - Integer - Codigo do Tipo de Parcela.
	 * @return nomeDoTipoParcela - String - Descrição / Nome do Tipo de Parcela.
	 * @author leandro.severino - lseverino@gmail.com
	 */
	public String buscarTipoParcelaRecebido(final Integer nuTipoParcela) {
		return this.tipoParcelaService.buscarPorId(nuTipoParcela);
	}

	/**
	 * <p>
	 * Método responsável por filtrar os dados na aba Recebidos, na modal de edição
	 * de uma Unidade Habitacional, quando selecionados / informados dados nos
	 * filtros das colunas.
	 * <p>
	 * 
	 * @author leandro.severino - lseverino@gmail.com
	 */
	public void onFiltroRecebidos() {
		this.getVisao()
				.setListaRecebidos(this.recebidoService.listarPorUnidadeHabitacionalEporFiltros(this.getVisao().getUnidadeHabitacionalEmEdicao(),
						this.getVisao().getIcRegistrosInativos(), this.getVisao().getFiltroPorTipoParcelaRecebidos(),
						this.getVisao().getFiltroPorDtVencimentoRecebidos(), this.getVisao().getFiltroPorNDocumentoRecebidos(),
						this.getVisao().getFiltroPorNossoNumeroRecebidos(), this.getVisao().getFiltroPorValorTituloRecebidos(),
						this.getVisao().getFiltroPorValorPagoRecebidos(), this.getVisao().getFiltroPorNCedenteRecebidos(),
						this.getVisao().getFiltroPorNProponenteRecebidos()));
	}

	/**
	 * <p>
	 * Método responsável por reativar um recebido inativo.
	 * </p>
	 * 
	 * @author leandro.severino - lseverino@gmail.com
	 */
	public void ativarRecebido() {
		this.recebidoService.ativarRecebido(this.idxRecebido, UsuarioUtil.getUsuarioLogado().getDeMatricula());
		this.mostraMensagemSucessoErecarregaListagemRecebidos();
	}

	/**
	 * <p>
	 * Método responsável por inativar um recebido (exclusão lógica).
	 * </p>
	 * 
	 * @author leandro.severino - lseverino@gmail.com
	 */
	public void inativarRecebido() {
		this.recebidoService.inativarRecebido(this.idxRecebido, UsuarioUtil.getUsuarioLogado().getDeMatricula(), this.motivoInativacaoRegistro);
		this.mostraMensagemSucessoErecarregaListagemRecebidos();
		this.motivoInativacaoRegistro = "";
	}

	/**
	 * <p>
	 * Método auxiliar para mostrar a mensagem de sucesso e recarregar a listagem de
	 * Recebidos.
	 * </p>
	 * 
	 * @author leandro.severino - lseverino@gmail.com
	 */
	private void mostraMensagemSucessoErecarregaListagemRecebidos() {
		RequestContext.getCurrentInstance().execute(ParametrizacaoContratoMB.PF_MODAL_SUCESSO_SHOW);
		this.onFiltroRecebidos();
	}

	/**
	 * <p>
	 * Método responsável por carrregar os dados na aba Amortização quando
	 * selecionada uma Unidade Habitacional para edição.
	 * <p>
	 * 
	 * @param unidadeHabitacional
	 *            - Unidade Habitacional para filtrar.
	 * @author leandro.severino - lseverino@gmail.com
	 */
	private void carregarAmortizacoesUnidadeHabitacional(final UnidadeHabitacional unidadeHabitacional) {

		// Limpa os filtros de Tela relacionados a aba de AmortizaÃ§Ãµes.
		this.getVisao().setFiltroPorDtPagamentoAmortizacao(null);
		this.getVisao().setFiltroPorValorPagoAmortizacao(null);
		this.getVisao().setFiltroPorMatriculaUsuarioResponsavelAmortizacao(null);
		this.getVisao().setIcAmortizacoesInativos(Boolean.FALSE);

		// Faz o recarregamento do objeto Unidade Habitacional com os
		// respectivos dados
		// lazys
		// necessários para serem exibidos na aba.
		// this.getVisao().setUnidadeHabitacionalEmEdicao(this.unidadeHabitacionalService
		// .carregarUnidadeHabitacionalComLazies(unidadeHabitacional));

		this.onFiltroAmortizacoes();
	}

	/**
	 * <p>
	 * Método responsável por filtrar os dados na aba Amortizações, na modal de
	 * edição de uma Unidade Habitacional, quando selecionados / informados dados
	 * nos filtros das colunas.
	 * <p>
	 * 
	 * @author leandro.severino - lseverino@gmail.com
	 */
	public void onFiltroAmortizacoes() {

		final Collection<Recebido> listaItensAmortizacoes = this.recebidoService.listarAmortizacoesPorUnidadeHabitacionalEporFiltros(
				this.getVisao().getUnidadeHabitacionalEmEdicao(), this.getVisao().getFiltroPorDtPagamentoAmortizacao(),
				this.getVisao().getFiltroPorValorPagoAmortizacao(), this.getVisao().getFiltroPorMatriculaUsuarioResponsavelAmortizacao(),
				this.getVisao().getIcAmortizacoesInativos());

		for (final Iterator<Recebido> iterator = listaItensAmortizacoes.iterator(); iterator.hasNext();) {
			final Recebido recebido = iterator.next();
			recebido.setIdxRecebido(++this.idxAmortizacao);
		}

		this.getVisao().setListaAmortizacoes(listaItensAmortizacoes);
	}

	/**
	 * <p>
	 * Método responsável por reativar uma Amortizações inativa.
	 * </p>
	 * s
	 * 
	 * @author leandro.severino - lseverino@gmail.com
	 */
	public void ativarAmortizacoes() {
		this.recebidoService.ativarAmortizacao(this.idxAmortizacao, UsuarioUtil.getUsuarioLogado().getDeMatricula());
		this.mostraMensagemSucessoErecarregaListagemAmortizacoes();
	}

	/**
	 * <p>
	 * Método responsável por inativar uma Amortizações (exclusÃ£o lÃ³gica).
	 * </p>
	 * 
	 * @author leandro.severino - lseverino@gmail.com
	 */
	public void inativarAmortizacoes() {
		this.recebidoService.inativarAmortizacao(this.idxAmortizacao, UsuarioUtil.getUsuarioLogado().getDeMatricula(),
				this.motivoInativacaoAmortizacao);
		this.mostraMensagemSucessoErecarregaListagemAmortizacoes();
		this.motivoInativacaoAmortizacao = "";
	}

	/**
	 * <p>
	 * Método auxiliar para mostrar a mensagem de sucesso e recarregar a listagem de
	 * Amortizacoes.
	 * </p>
	 * 
	 * @author leandro.severino - lseverino@gmail.com
	 */
	private void mostraMensagemSucessoErecarregaListagemAmortizacoes() {
		RequestContext.getCurrentInstance().execute(ParametrizacaoContratoMB.PF_MODAL_SUCESSO_SHOW);
		this.onFiltroAmortizacoes();
	}

    /**
     * <p>
     * Método auxiliar para adicionar uma Amortizações na listagem de
     * Amortizações.
     * </p>
     * 
     * @author leandro.severino - lseverino@gmail.com
     */
    public void adicionarAmortizacao() {
	if (CollectionUtils.isEmpty(getVisao().getListaProponentesHabitacionais())) {
	    return;
	}

	if (this.idxAmortizacao == null) {
	    this.idxAmortizacao = 1;
	} else {
	    ++this.idxAmortizacao;
	}

	final ProponenteHabitacional primeiroProponente = getVisao().getListaProponentesHabitacionais().iterator().next();
	final String nuIdentificadorSacado = primeiroProponente.getProponenteHabitacionalID().getNuPessoa().toString()
		+ primeiroProponente.getProponenteHabitacionalID().getNuComercializacao().toString();

	if (CollectionUtils.isEmpty(this.getVisao().getListaCedentes())) {
	    final Collection<Cedente> consultaCedentesPorNuEmpreendimento = this.empreendimentoService
		    .listarCedentesHabitacionais(this.getVisao().getUnidadeHabitacionalEmEdicao().getNuEmpreendimento().getNuEmpreendimento());
	    this.getVisao().setListaCedentes(consultaCedentesPorNuEmpreendimento);
	}

	final Cedente cedenteContrato = this.getVisao().getListaCedentes().iterator().next();

	final BigDecimal valorZero = new BigDecimal("0.00");

	final Recebido recebido = new Recebido();

	recebido.setNuUnidadeHabitacionalComercializacao(this.getVisao().getUnidadeHabitacionalComercializacao());
	recebido.setCoNossoNumero("A");
	recebido.setDtVencimento(new Date());
	recebido.setNoSacado(primeiroProponente.getNome());
	recebido.setVrTitulo(valorZero);
	recebido.setVrPago(valorZero);
	recebido.setNuDocumento(null);
	recebido.setNuIdentificadorSacado(nuIdentificadorSacado);
	recebido.setNuCedente(cedenteContrato.getNuCedente());
	recebido.setDhRecebimento(new Date());
	recebido.setDhInclusao(new Date());
	recebido.setCoResponsavel(UsuarioUtil.getUsuarioLogado().getDeMatricula().toUpperCase());
	recebido.setNuTipoParcela(ParametrizacaoContratoMB.TIPO_PARCELA_AMORTIZACAO); //
	recebido.setNuEmpreendimento(this.getVisao().getUnidadeHabitacionalEmEdicao().getNuEmpreendimento().getNuEmpreendimento().intValue());
	recebido.setNuProspecto(null);
	recebido.setIcSituacaoConciliacao(ParametrizacaoContratoMB.SITUACAO_CONCILIACAO_AMORTIZACAO);
	recebido.setIcSituacaoRecebido(Boolean.TRUE);
	recebido.setTsInativacao(null);
	recebido.setDeInativacao(null);
	recebido.setIdxRecebido(this.idxAmortizacao);
	recebido.setInclusao(Boolean.TRUE);

	if (this.getVisao().getListaAmortizacoes() == null) {
	    this.getVisao().setListaAmortizacoes(new ArrayList<Recebido>());
	}

	this.getVisao().getListaAmortizacoes().add(recebido);

	final DataTable dataTable = (DataTable) FacesContext.getCurrentInstance().getViewRoot()
		.findComponent("formParametrizacaoContrato:accordionUnidadeHabitacional:tabelaAmortizacoes");
	if (dataTable != null && this.getVisao().getListaAmortizacoes().size() > 10) {
	    final BigDecimal quantodadeAmortizacoes = new BigDecimal(this.getVisao().getListaAmortizacoes().size());
	    final BigDecimal paginasTable = new BigDecimal(dataTable.getPage() + 1).multiply(BigDecimal.TEN);
	    final BigDecimal resto = quantodadeAmortizacoes.divide(paginasTable, 2, BigDecimal.ROUND_HALF_UP);
	    if (resto.compareTo(BigDecimal.ONE) > 0) {
		dataTable.setFirst(this.getVisao().getListaAmortizacoes().size() / 10);
		RequestContext.getCurrentInstance()
			.execute("setTimeout(function(){PF('amortizacoesTable').getPaginator().setPage(" + dataTable.getFirst() + ");},100)");
	    }
	}

    }

	/**
	 * <p>
	 * Método responsável por tratar o evento de edição em uma linha na tabela de
	 * AmortizaÃ§Ãµes.
	 * </p>
	 * 
	 * @param event
	 *            - Evento de edição de uma linha na tabela de Amortizacoes.
	 * @throws Exception
	 */
	public void onAmortizacaoEdit(final RowEditEvent event) {
		Recebido amortizacaoEditada = null;
		final FacesContext contexto = FacesContext.getCurrentInstance();

		try {
			amortizacaoEditada = (Recebido) ((DataTable) event.getComponent()).getRowData();
		} catch (final Exception e) {
			LogCEF.debug(e);
			return;
		}

		// Valida os novos valores inseridos na linha em relação existentes na
		// linha.

		if (amortizacaoEditada.getDhRecebimento() == null) {
			contexto.validationFailed();
			return;
		} else {
			this.getVisao().setCampoComErro(false);
			this.getVisao().setMensagemDeErroNaValidacaoCampo("");
		}

		if (amortizacaoEditada.getVrPago() == null || amortizacaoEditada.getVrPago().compareTo(BigDecimal.ZERO) == 0) {
			contexto.validationFailed();
			return;
		} else {
			this.getVisao().setCampoComErro(false);
			this.getVisao().setMensagemDeErroNaValidacaoCampo("");
		}

		amortizacaoEditada.setVrTitulo(amortizacaoEditada.getVrPago());

		if (amortizacaoEditada.getNuRecebido() == null) {
			this.recebidoService.inserir(amortizacaoEditada);
		} else {
			this.recebidoService.alterar(amortizacaoEditada);
		}

		this.onFiltroAmortizacoes();
	}

	/**
	 * <p>
	 * Retorna o valor do atributo empreendimentoService
	 * </p>
	 * .
	 *
	 * @return empreendimentoService
	 */
	public EmpreendimentoService getEmpreendimentoService() {
		return this.empreendimentoService;
	}

	/**
	 * <p>
	 * Define o valor do atributo empreendimentoService
	 * </p>
	 * .
	 *
	 * @param empreendimentoService
	 *            valor a ser atribuído
	 */
	public void setEmpreendimentoService(final EmpreendimentoService empreendimentoService) {
		this.empreendimentoService = empreendimentoService;
	}

	/**
	 * <p>
	 * Define o valor do atributo valorCompraVendaProspecto
	 * </p>
	 * .
	 */
	private BigDecimal valorCompraVendaProspecto() {
		if (this.getVisao().getUnidadeHabitacionalComercializacao() != null) {
			return this.getVisao().getUnidadeHabitacionalComercializacao().getVrContrato();
		}
		return null;
	}

	/**
	 * <p>
	 * Retorna o valor do atributo nuRecebido
	 * </p>
	 * .
	 *
	 * @return nuRecebido
	 */
	public Integer getNuRecebido() {
		return this.nuRecebido;
	}

	/**
	 * <p>
	 * Define o valor do atributo nuRecebido
	 * </p>
	 * .
	 *
	 * @param nuRecebido
	 *            valor a ser atribuído
	 */
	public void setNuRecebido(final Integer nuRecebido) {
		this.nuRecebido = nuRecebido;
	}

	public ParametroProdutoVisao getParametroProdutoVisao() {
		if (this.parametroProdutoVisao == null) {
			this.parametroProdutoVisao = new ParametroProdutoVisao();
		}
		return this.parametroProdutoVisao;
	}

	/**
	 * <p>
	 * Define o valor do atributo parametroProdutoVisao
	 * </p>
	 * .
	 *
	 * @param parametroProdutoVisao
	 *            valor a ser atribuído
	 */
	public void setParametroProdutoVisao(final ParametroProdutoVisao parametroProdutoVisao) {
		this.parametroProdutoVisao = parametroProdutoVisao;
	}

	/**
	 * <p>
	 * Retorna o valor do atributo parametroProdutoMB
	 * </p>
	 * .
	 *
	 * @return parametroProdutoMB
	 */
	public ParametroProdutoMB getParametroProdutoMB() {
		if (this.parametroProdutoMB == null) {
			this.parametroProdutoMB = new ParametroProdutoMB();
		}
		return this.parametroProdutoMB;
	}

	/**
	 * <p>
	 * Define o valor do atributo parametroProdutoMB
	 * </p>
	 * .
	 *
	 * @param parametroProdutoMB
	 *            valor a ser atribuído
	 */
	public void setParametroProdutoMB(final ParametroProdutoMB parametroProdutoMB) {
		this.parametroProdutoMB = parametroProdutoMB;
	}

	/**
	 * <p>
	 * Retorna o valor do atributo contaCorrenteCartaoMB
	 * </p>
	 * .
	 *
	 * @return contaCorrenteCartaoMB
	 */
	public ContaCorrenteCartaoMB getContaCorrenteCartaoMB() {
		return this.contaCorrenteCartaoMB;
	}

	/**
	 * <p>
	 * Define o valor do atributo contaCorrenteCartaoMB
	 * </p>
	 * .
	 *
	 * @param contaCorrenteCartaoMB
	 *            valor a ser atribuído
	 */
	public void setContaCorrenteCartaoMB(final ContaCorrenteCartaoMB contaCorrenteCartaoMB) {
		this.contaCorrenteCartaoMB = contaCorrenteCartaoMB;
	}

	/**
	 * <p>
	 * Método responsável por verificar se é um contrato de imóveis
	 * </p>
	 * .
	 *
	 * @author p566506
	 *
	 */
	public boolean getGarantiaContratoImoveis() {

		this.visao.setGarantiaContratoImoveis(this.service.isGarantiaContratoImoveis(this.getVisao().getIdentificadorGarantia()));
		this.msgAlert = null;
		if (this.visao.getGarantiaContratoImoveis()) {
			try {

				this.visao.setGarantiaPassouSerAcompanhada(this.fabricaCalculoGarantia.isGarantiaPassouSerAcompanhada(
						visao.getGarantia().getGrupoGarantia(), this.getVisao().getContratoSelecionadoParaParametrizacao().getDtContrato()));

			} catch (Exception e) {
				LogCefUtil.error(e);
				this.visao.setGarantiaPassouSerAcompanhada(false);
			}

			if (this.visao.getGarantiaContratoImoveis() && this.visao.isGarantiaPassouSerAcompanhada()) {
				this.visao.setListaBemCliente(prepararListaBemClienteImovel());
				if (this.visao.getListaBemCliente().isEmpty()) {
					this.apresentarAlertaBemCliente("Imóvel");
				}else {
					if (visao.getGarantia().isGrupoGarantia(GrupoGarantiaEnum.IMOVEL)) {
						montarListaGarantiaBemCliente();
					}
			}
		}
	}

		return getVisao().getGarantiaContratoImoveis();
	}
	
	private void montarListaGarantiaBemCliente() {
		GarantiaBemCliente garantiaBemCliente;
		for (BemCliente bemCliente : getVisao().getListaBemCliente()) {
			if (!isPossuiBemAdicionado(bemCliente)) {
				garantiaBemCliente = new GarantiaBemCliente();
				garantiaBemCliente.setBemCliente(bemCliente);
				BigDecimal valorUtilizadoOutrasGarantias = BigDecimal.ZERO;
				
				if (getVisao().getValorUtilizadoOutrasGarantias().containsKey(bemCliente.getNuBemCliente())) {
					valorUtilizadoOutrasGarantias = getVisao().getValorUtilizadoOutrasGarantias().get(bemCliente.getNuBemCliente());
				}
				
				garantiaBemCliente.setVrUtilizadoOutrasGarantias(valorUtilizadoOutrasGarantias.add(garantiaBemClienteService.getValorUtilizado(garantiaBemCliente)));
				
				getVisao().getEntidade().getBens().add(garantiaBemCliente);
			}
		}
	}

	private boolean isPossuiBemAdicionado(BemCliente bemCliente) {
		boolean isPossuiBemAdicionado = Boolean.FALSE;
		
		for (GarantiaBemCliente garantiaBemCliente : getVisao().getEntidade().getBens()) {
			if (garantiaBemCliente.getBemCliente().getNuBemCliente().equals(bemCliente.getNuBemCliente())) {
				isPossuiBemAdicionado = Boolean.TRUE;
				break;
			}
		}
		
		return isPossuiBemAdicionado;
	}

	private void apresentarAlertaBemCliente(final String tipoBem) {
	    final  String nrContrato = this.formatarContrato(this.visao.getContratoSelecionadoParaParametrizacao().getCoContrato());
	    this.msgAlert = MensagensUtil.getMensagem(AppConstant.RESOURCE_BUNDLE, MsgConstant.GARANTIA_VINCULADA_CONTRATO, nrContrato, tipoBem);
	    RequestContext.getCurrentInstance().execute("modalErroBemCliente.show();");
	}

	/**
	 * <p>
	 * Método responsável por atribuir o imovel correspondente ao id recuperado na
	 * combobox.
	 * </p>
	 * .
	 *
	 * @author f754687
	 *
	 */
	public void recuperarImovelPorSelecao(Integer nuImovel) {
		if (nuImovel != null && nuImovel > 0) {
			for (final BemCliente bem : visao.getListaBemCliente()) {
				if (bem.getImovel() != null && bem.getImovel().getNuImovel().equals(nuImovel)) {
					getVisao().getEntidade().setBemCliente(UtilObjeto.clone(bem));
					break;
				}
			}
		} else {
			this.visao.getEntidade().setBemCliente(new BemCliente());
		}
	}

	@SuppressWarnings("unchecked")
	public String formatarContrato(String coContrato) {
		if (coContrato == null) {
			return "";
		}

		final HttpServletRequest request = (HttpServletRequest) FacesContext.getCurrentInstance().getExternalContext().getRequest();
		final Map<String, String> mapaOperacaoSistema = (Map<String, String>) request.getSession().getAttribute("mapaOperacaoSistema");
		final String numeroContrato = coContrato.toString();
		final String mascara = mapaOperacaoSistema.get(numeroContrato.substring(4, 8));

		if (mascara != null) {
			return ContratoUtil.formatarNumeroContrato(numeroContrato, mascara);
		}
		return numeroContrato;
	}
	
	/**
	 * <p>
	 * Método responsável por atribuir o MaquinaEquipamento correspondente ao id
	 * recuperado na combobox.
	 * </p>
	 * .
	 *
	 * @author narcieliton.lopes
	 *
	 */
	public void recuperarPorSelecaoMaquinaEquipamento() {
		if (visao.getNuMaquinaEquipamento() != null && visao.getNuMaquinaEquipamento() > 0) {
			for (final BemCliente bem : visao.getListaBemCliente()) {
				if (bem.getMaquinaEquipamento() != null
						&& bem.getMaquinaEquipamento().getNuMaquinaEquipamento().equals(visao.getNuMaquinaEquipamento())) {
					this.visao.getEntidade().setBemCliente(UtilObjeto.clone(bem));
					break;
				}
			}
		} else {
			this.visao.getEntidade().setBemCliente(new BemCliente());
		}
	}

	/**
	 * <p>
	 * Método responsável por exportar para XLS a grid de Unidades Habitacionais
	 * </p>
	 * .
	 *
	 * @author Ludemeula Fernandes
	 *
	 */
	public void gerarXlsUnidadeHabitacional() {
		getVisao().setTipoArquivo(EnumExtensaoArquivo.XLS);
		getVisao().setColecaoRelatorio(
				unidadeHabitacionalService.buscarPorEmpreendimento(getVisao().getContratoSelecionadoParaParametrizacao().getEmpreendimento()));
		getVisao().setNomeRelatorio(NOME_RELATORIO_UNIDADE_HABITACIONAL);
		getVisao().setCaminhoRelatorio(CAMINHO_RELATORIO_UNIDADE_HABITACIONAL);
		getVisao().setMapaParametros(montarMapaParametros());
		this.geraRelatorio();
	}

	/**
	 * <p>
	 * Método responsável por exportar para XLS a grid de Prospectos.
	 * </p>
	 * .
	 *
	 * @author Ludemeula Fernandes
	 *
	 */
	public void gerarXlsProspecto() {
		final Map<String, Object> parametros = new LinkedHashMap<>();
		String adquirinte = "";
		UnidadeHabitacionalComercializacao comercializacao = getVisao().getUnidadeHabitacionalEmEdicao().getComercializacao() != null ?
				getVisao().getUnidadeHabitacionalEmEdicao().getComercializacao() : getVisao().getUnidadeHabitacionalComercializacao();
		
		for (Pessoa pessoa : proponenteHabitacionalService.listarPorComercializacao(comercializacao.getNuComercializacao())) {
			adquirinte = adquirinte.concat(pessoa.getNuCnpjFormatado().concat(" - ").concat(pessoa.getNoPessoa())).concat(", ");
		}
		
		parametros.put("LOGO_CAIXA", FacesContext.getCurrentInstance().getExternalContext().getResourceAsStream("/resources/img/caixa_logo.jpg"));
		parametros.put("MATRICULA_USUARIO", UsuarioUtil.getUsuarioLogado().getDeMatricula());
		parametros.put("apf", getVisao().getUnidadeHabitacionalEmEdicao().getNuEmpreendimento().getCoAPF());
		parametros.put("tipologia", getVisao().getUnidadeHabitacionalEmEdicao().getNuTipologia().getNoTipologia());
		parametros.put("unidade", getVisao().getUnidadeHabitacionalEmEdicao().getCoIdentificadorUnidade());
		parametros.put("adquirinte", !StringUtils.isEmpty(adquirinte) ? adquirinte.substring(0, adquirinte.length() - 2) : adquirinte);
		
		getVisao().setTipoArquivo(EnumExtensaoArquivo.XLS);
		getVisao().setColecaoRelatorio(getVisao().getHistoricosProspecto());
		getVisao().setNomeRelatorio(NOME_RELATORIO_PROSPECTO);
		getVisao().setCaminhoRelatorio(CAMINHO_RELATORIO_PROSPECTO);
		getVisao().setMapaParametros(parametros);
		this.geraRelatorio();
	}

	/**
	 * <p>
	 * Método responsável por gerar relatorios da grid de Unidades Habitacionais.
	 * <p>
	 *
	 */
	public void geraRelatorio() {
		try {
			UtilRelatorio.getInstancia().addCaminhoRelatorio(getVisao().getCaminhoRelatorio()).addColecao(getVisao().getColecaoRelatorio())
					.addResposta(this.getResponse()).addParametros(getVisao().getMapaParametros()).addNomeRelatorio(getVisao().getNomeRelatorio())
					.addExtensaoArquivo(getVisao().getTipoArquivo()).gerarRelatorio();
		} catch (final Exception e) {
			LOG.fine(e.getMessage());
			LogCEF.error(e);
		}
	}

	/**
	 * <p>
	 * Método responsável por montar o mapa de parametros passado para o relatorio
	 * de unidades habitacionais.
	 * <p>
	 *
	 */
	private Map<String, Object> montarMapaParametros() {
		final Contrato contrato = getVisao().getContratoSelecionadoParaParametrizacao();

		final Map<String, Object> parametros = new LinkedHashMap<>();
		parametros.put("LOGO_CAIXA", FacesContext.getCurrentInstance().getExternalContext().getResourceAsStream("/resources/img/caixa_logo.jpg"));
		parametros.put("MATRICULA_USUARIO", UsuarioUtil.getUsuarioLogado().getDeMatricula());
		parametros.put("dataReferencia", new Date());
		parametros.put("nomeEmpreendimento", contrato.getEmpreendimento().getNoEmpreendimento());
		parametros.put("numeroContratoPj", contrato.getCoContrato());
		parametros.put("cedentes",
				formatarArray(empreendimentoService.cedentesHabitacionais(contrato.getEmpreendimento().getNuEmpreendimento()).toArray()));
		parametros.put("saldoDevedor", contrato.getVrSaldoDevedor());
		parametros.put("saldoCredor", contrato.getVrSaldoCredor());
		parametros.put("indiceHipotecario", getIndices(contrato.getNuUltimaAnaliseContrato().getInHipotecario(), contrato));
		parametros.put("indiceRecebiveis", getIndices(contrato.getNuUltimaAnaliseContrato().getInRecebiveis(), contrato));
		parametros.put("garantias", formatarArray(getGarantias(contrato).toArray()));

		return parametros;
	}

	private BigDecimal getIndices(BigDecimal indice, Contrato contrato) {
		return !indice.equals(BigDecimal.ZERO) ? indice.divide(contrato.getVrSaldoCredor().add(contrato.getVrSaldoCredor())) : BigDecimal.ZERO;
	}

	private List<String> getGarantias(Contrato contrato) {
		List<String> garantias = new ArrayList<String>();
		for (GarantiaContrato garantia : contrato.getGarantiaContratoList()) {
			garantias.add(garantia.getGarantia().getCoOperacao());
		}

		return garantias;
	}

	private String formatarArray(Object[] strArray) {
		String formatado = Arrays.toString(strArray);
		return strArray.length > 0 ? formatado.substring(1, formatado.length() - 1) : "";
	}

	/**
	 * <p>
	 * metodo responsavel por consultar aplicações financeira por cpf de terceiro
	 * </p>
	 * author: narcieliton.lopes
	 */
	public void consultarSalvarPessoaTerceiro() {
		// consultar somente cpf diferente
		boolean isCpfCnpjDiferente = validarCpfCnpjTerceiroDiferenteContrato(this.visao.getPessoaTerceiro().getNuCnpj());
		if (!this.visao.getPessoaTerceiro().getNuCnpj().isEmpty() && isCpfCnpjDiferente) {
			Pessoa pessoa = this.pessoaService.recuperarPessoaSicliSalvarTabelaPessoa(this.visao.getPessoaTerceiro().getNuCnpj());
			if (pessoa != null) {
				this.visao.setPessoaTerceiro(pessoa);
			} else {
				final String cpfCnpj = this.visao.getPessoaTerceiro().getNuCnpj().length() == 11 ? "CPF" : "CNPJ";
				super.adicionaMensagemDeAlerta(
						"Pessoa não encontrado para o " + cpfCnpj + " " + this.visao.getPessoaTerceiro().getNuCnpj() + " informado .");
			}
		}
	}

	/**
	 * <p>
	 * metodo responsavel por validar se o cpf informado é diferente do atual
	 * contrato
	 * </p>
	 * 
	 * @author: narcieliton.lopes
	 * @param String
	 *            cpfCnpj
	 * @return true = se for diferente, false = for igual
	 */
	private boolean validarCpfCnpjTerceiroDiferenteContrato(String cpfCnpjTerceiro) {
		boolean isDiferente = true;
		final String cpfCnpjSemFormatacao = UtilCnpj
				.removerFormatacao(this.visao.getContratoSelecionadoParaParametrizacao().getNuPessoa().getNuCnpj());
		final String cpfCnpjSemFormatacaoTerceiro = UtilCnpj.removerFormatacao(cpfCnpjTerceiro);
		if (UtilString.isStringsIguais(cpfCnpjSemFormatacao, cpfCnpjSemFormatacaoTerceiro)) {
			isDiferente = false;
			super.adicionaMensagemDeAlerta("CpfCnpj deve ser diferente do que consta no Contrato");
		}
		return isDiferente;
	}

	/**
	 * <p>
	 * metodo responsavel por adicionar Aplicacao financeira no banco e na grid
	 * </p>
	 * 
	 * @author: narcieliton.lopes
	 * @param String
	 *            cpfCnpj
	 * @return true = se for diferente, false = for igual
	 */
	public void adicionarAplicacaoFinanceiraTerceiro() {
		try {
			List<RetornoAplicacaoSifix> listaAplicacaoSifix = this.aplicacaoFinanceiraService
					.consultarSaldoAplicacaoSifixCpfCnpj(this.visao.getPessoaTerceiro().getNuCnpj());
			if (!listaAplicacaoSifix.isEmpty()) {
				this.aplicacaoFinanceiraService.salvarAplicacaoSifixEmLote(listaAplicacaoSifix);
				Collection<ContaCorrente> listaContaCorrenteTerceiro = this.contratoService
						.listarContaCorrentePorNumeroPessoa(this.visao.getPessoaTerceiro().getNuPessoa());
				for (ContaCorrente contaTerceiro : listaContaCorrenteTerceiro) {
					this.visao.getContaContratoAplicacaoFinanceira().setNuConta(contaTerceiro);
					this.adicionarContaCorrenteAplicacaoFinanceira();
				}
			} else {
				final String cpfCnpj = this.visao.getPessoaTerceiro().getNuCnpj().length() == 11 ? "CPF" : "CNPJ";
				super.adicionaMensagemDeAlerta(
						"Aplicação financeira não encontrado para o " + cpfCnpj + " " + this.visao.getPessoaTerceiro().getNuCnpj() + " informado .");
			}

		} catch (final Exception e) {
			super.adicionaMensagemDeErro("Ocorreu erro ao consultar aplicações no SIFIX.");
			LOG.fine(e.getMessage());
			LogCEF.error(e);
		}
	}

	/**
	 * <p>
	 * Método responsável por verificar se a garantia é Veículo.
	 * </p>
	 * 
	 * @author narcieliton.lopes
	 * @return true se for veiculo
	 */
	public boolean verificaGarantiaVeiculoAcompanhado() {
	    	this.msgAlert  = null;
		this.setIsGarantiaVeiculoAcompanhado(false);
		Garantia garantia = this.getService().obterGarantiaPorCodigoOperacao(visao.getIdentificadorGarantia());
		if (garantia != null && garantia.isGrupoGarantia(GrupoGarantiaEnum.VEICULO)) {
			try {
				this.setIsGarantiaVeiculoAcompanhado(this.service.isGarantiaPassouSerAcompanhada(garantia.getGrupoGarantia(),
						this.getVisao().getContratoSelecionadoParaParametrizacao().getDtContrato()));

				if (this.getIsGarantiaVeiculoAcompanhado()) {
					this.setarListaBemClienteVeiculoAcompanhado(this.visao.isGarantiaPassouSerAcompanhada());
				}
			} catch (Exception e) {
				LogCefUtil.error(e);
				this.visao.setGarantiaPassouSerAcompanhada(false);
			}
		}
		return this.getIsGarantiaVeiculoAcompanhado();
	}

	private void setarListaBemClienteVeiculoAcompanhado(boolean garantiaPassouASerAcompanhada) {
		if (garantiaPassouASerAcompanhada) {
			this.visao.setListaBemCliente(prepararListaBemClienteVeiculo());
			if (this.visao.getListaBemCliente().isEmpty()) {
			    this.apresentarAlertaBemCliente("Veículo");
			}
		}
	}

	/**
	 * <p>
	 * Método responsável por atribuir o Veiculo correspondente ao id recuperado na
	 * combobox.
	 * </p>
	 * 
	 * @author narcieliton.lopes
	 */
	public void recuperarPorSelecaoVeiculoAcompanhado() {
		if (visao.getNuVeiculoAcompanhado() != null && visao.getNuVeiculoAcompanhado() > 0) {
			for (final BemCliente bem : visao.getListaBemCliente()) {
				if (bem.getVeiculo() != null && bem.getVeiculo().getNuVeiculo().equals(visao.getNuVeiculoAcompanhado())) {
					this.visao.getEntidade().setBemCliente(UtilObjeto.clone(bem));
					break;
				}
			}
		} else {
			this.visao.getEntidade().setBemCliente(new BemCliente());
		}
	}

	private List<BemCliente> prepararListaBemClienteImovel() {
		return bemClienteService.imoveis(this.visao.getContratoSelecionadoParaParametrizacao().getNuContrato());
	}

	private List<BemCliente> prepararListaBemClienteVeiculo() {
		return bemClienteService.veiculos(getVisao().getContratoSelecionadoParaParametrizacao().getNuContrato());
	}

	private List<BemCliente> prepararListaBemClienteMaquinaEquipamento() {
		return bemClienteService.maquinas(visao.getContratoSelecionadoParaParametrizacao().getNuContrato());
	}

	public String getMsgAlert() {
		return msgAlert;
	}

	public void setMsgAlert(String msgAlert) {
		this.msgAlert = msgAlert;
	}

	public boolean getIsGarantiaVeiculoAcompanhado() {
		return this.isGarantiaVeiculoAcompanhado;
	}

	public void setIsGarantiaVeiculoAcompanhado(boolean isGarantiaVeiculoAcompanhado) {
		this.isGarantiaVeiculoAcompanhado = isGarantiaVeiculoAcompanhado;
	}

	public BigDecimal getVrCV() {
		return this.vrCV;
	}

	public void setVrCV(final BigDecimal vrCV) {
		this.vrCV = vrCV;
	}

	/**
	 * <p>
	 * Retorna o valor do atributo bandeiraCartaoService
	 * </p>
	 * .
	 *
	 * @return bandeiraCartaoService
	 */
	public BandeiraCartaoService getBandeiraCartaoService() {
		return this.bandeiraCartaoService;
	}
	
	/**
	 * Retorna o valor do atributo consulta.
	 *
	 * @return unidadesHabitacionaisPaginada
	 */
	public UnidadeHabitacionalLazyModel getUnidadesHabitacionaisPaginada() {
		if (this.unidadesHabitacionaisPaginada == null) {
			this.unidadesHabitacionaisPaginada = new UnidadeHabitacionalLazyModel();
		}

		return this.unidadesHabitacionaisPaginada;
	}

	/**
	 * Define o valor do atributo consulta.
	 *
	 * @param unidadesHabitacionaisPaginada
	 *            valor a ser atribuído
	 */
	public void setUnidadesHabitacionaisPaginada(final UnidadeHabitacionalLazyModel unidadesHabitacionaisPaginada) {
		this.unidadesHabitacionaisPaginada = unidadesHabitacionaisPaginada;
	}
	
    /**
     * <p>
     * Método responsável por implementar o comportamento ao marcar/ desmarcar o
     * checkbox Tratamento Especial.
     * </p>
     *
     * @author gerusa.soares
     *
     */
    public void changeCheckboxTratamentoEspecial() {
		  
	final Contrato contrato = this.getVisao().getContratoSelecionadoParaParametrizacao();

	if (UtilObjeto.isReferencia(contrato)) {

	    if (contrato.isIcTratamentoEspecial()) {
		contrato.setDhTratamentoEspecial(new Date());

	    } else {
		contrato.setDhTratamentoEspecial(null);
		contrato.setDeMotivoTratamentoEspecial(null);
	    }

	}

    }
}