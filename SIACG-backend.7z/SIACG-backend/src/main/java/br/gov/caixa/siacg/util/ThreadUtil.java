/**
 * Copyright (c) 2016 Caixa Econômica Federal. Todos os direitos
 * reservados.
 *
 * Caixa Econômica Federal - SIACG
 *
 * Este software foi desenvolvido sob demanda da CAIXA e está
 * protegido por leis de direitos autorais e tratados internacionais. As
 * condições de cópia e utilização do todo ou partes dependem de autorização da
 * pessoa. Cópias não são permitidas sem expressa autorização. Não pode ser
 * comercializado ou utilizado para propósitos particulares.
 *
 * Uso exclusivo da Caixa Econômica Federal. A reprodução ou distribuição não
 * autorizada deste programa ou de parte dele, resultará em punições civis e
 * criminais e os infratores incorrem em sanções previstas na legislação em
 * vigor.
 *
 * Histórico do Subversion:
 *
 * LastChangedRevision: $Revision$
 * LastChangedBy: $Author$
 * LastChangedDate: $Date$
 *
 * HeadURL: $HeadURL$
 *
 */
package br.gov.caixa.siacg.util;

import java.lang.Thread.State;

/**
 * <p>
 * ThreadUtil
 * </p>
 * <p>
 * Descrição: Classe responsável por centralizar funcionalidades utilitárias de
 * uma thread.
 * </p>
 * <br>
 * <b>Empresa:</b> Cef - Caixa Econômica Federal
 *
 * @author guilherme.santos
 * @version 1.0
 */
public class ThreadUtil {
    
    private ThreadUtil() {
	throw new IllegalStateException("Classe de Utilidade");
    }

    /**
     * <p>
     * Método responsável por verificar se as Threads ainda estão em execução,
     * caso estejam, aguarda seu termino.
     * <p>
     *
     * @param thread
     *            valor a ser atribuido
     * @author guilherme.santos
     */
    public static void executarVerificacaoNecessidadeDeAguardarExecucao(final Thread thread) {
        // Verifica se a Thread foi iniciada
        if (thread.getState() == State.NEW) {
            thread.start();
        }
        // Caso a Thread não tenha finalizado sua execução, aguarda seu termino
        if (thread.getState() != State.TERMINATED) {
            try {
                thread.join(); // fica aguarando ate a 1° thread acabar
            } catch (final InterruptedException ex) {
        	thread.interrupt();
                LogCEF.warn(thread + " ERRO NA EXECUÇÃO DA THREAD " + ex.getMessage());
            }
        }
    }
}
