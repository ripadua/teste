/*
 * Copyright (c) 2016 Caixa Econômica Federal. Todos os direitos
 * reservados.
 *
 * Caixa Econômica Federal - SIACG_dev
 *
 * Este software foi desenvolvido sob demanda da CAIXA e está
 * protegido por leis de direitos autorais e tratados internacionais. As
 * condições de cópia e utilização do todo ou partes dependem de autorização da
 * pessoa. Cópias não são permitidas sem expressa autorização. Não pode ser
 * comercializado ou utilizado para propósitos particulares.
 *
 * Uso exclusivo da Caixa Econômica Federal. A reprodução ou distribuição não
 * autorizada deste programa ou de parte dele, resultará em punições civis e
 * criminais e os infratores incorrem em sanções previstas na legislação em
 * vigor.
 *
 * Histórico do Subversion:
 *
 * LastChangedRevision: $Revision$
 * LastChangedBy: $Author$
 * LastChangedDate: $Date$
 *
 * HeadURL: $HeadURL$
 *
 */
package br.gov.caixa.siacg.comum.to;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * <p>
 * RetornoSid09TO.
 * </p>
 * <p>
 * Descrição: TO para representar o conteudo de cada conta da consulta ao SID 09.
 * </p>
 * <br>
 * <b>Empresa:</b> Cef - Caixa Econômica Federal
 *
 * @author f538462
 * @version 1.0
 */
@JsonIgnoreProperties(ignoreUnknown = true)
public class ContaSid09TO {


    @JsonProperty(value = "titularidade")
    private Integer titularidade;

    @JsonProperty(value = "situacao")
    private Integer situacao;

    @JsonProperty(value = "motivo")
    private Integer motivo;

    @JsonProperty(value = "tipo_conta")
    private String tipoConta;

    @JsonProperty(value = "unidade")
    private Integer unidade;

    @JsonProperty(value = "produto")
    private Integer produto;

    @JsonProperty(value = "numero")
    private Integer numero;

    @JsonProperty(value = "dv")
    private Integer dv;

    public Integer getTitularidade() {
	return titularidade;
    }

    public void setTitularidade(Integer titularidade) {
	this.titularidade = titularidade;
    }

    public Integer getSituacao() {
	return situacao;
    }

    public void setSituacao(Integer situacao) {
	this.situacao = situacao;
    }

    public Integer getMotivo() {
	return motivo;
    }

    public void setMotivo(Integer motivo) {
	this.motivo = motivo;
    }

    public String getTipoConta() {
	return tipoConta;
    }

    public void setTipoConta(String tipoConta) {
	this.tipoConta = tipoConta;
    }

    public Integer getUnidade() {
	return unidade;
    }

    public void setUnidade(Integer unidade) {
	this.unidade = unidade;
    }

    public Integer getProduto() {
	return produto;
    }

    public void setProduto(Integer produto) {
	this.produto = produto;
    }

    public Integer getNumero() {
	return numero;
    }

    public void setNumero(Integer numero) {
	this.numero = numero;
    }

    public Integer getDv() {
	return dv;
    }

    public void setDv(Integer dv) {
	this.dv = dv;
    }
    /**
     * 
     * <p>Método responsável por retorna o numero da conta concatenado:
     * </p>.
     *
     * @author p575337
     *
     * @return Agencia-Produto-Numero-Digito
     */
    public String getConta() {
	StringBuilder conta = new StringBuilder();
	conta.append(this.getUnidade());
	conta.append("-");
	conta.append(this.getProduto());
	conta.append("-");
	conta.append(this.getNumero());
	conta.append("-");
	conta.append(this.getDv());
	return conta.toString();
    }
}
