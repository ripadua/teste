
package br.gov.caixa.siacg.view.form;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

import br.gov.caixa.pedesgo.arquitetura.util.UtilString;
import br.gov.caixa.pedesgo.arquitetura.visao.ManutencaoVisao;
import br.gov.caixa.siacg.trilha.TrilhaHistorico;

/**
 * <p>
 * TrilhaHistoricoVisao.
 * </p>
 * <p>
 * Descrição: TrilhaHistoricoVisao
 * </p>
 * <br>
 * <b>Empresa:</b> Cef - Caixa Econômica Federal
 *
 * @version 1.0
 */
public class TrilhaHistoricoVisao extends ManutencaoVisao<TrilhaHistorico> {

    private static final long serialVersionUID = -104674043407726842L;

    /** Atributo listaOperacao. */
    private Collection<String> listaOperacao;

    /** Atributo listaTabela. */
    private Collection<String> listaTabela;

    /** Atributo listaRespOperacao. */
    private Collection<String> listaRespOperacao;

    /** Atributo trilhaHistoricoSelecionada. */
    private TrilhaHistorico trilhaHistoricoSelecionada;

    /** Atributo listTrilhaHistoricoCamposAlteradosVisao. */
    private transient List<TrilhaHistoricoCampoAlteradoVisao> listTrilhaHistoricoCamposAlteradosVisao;

    /**
     * Retorna o valor do atributo listaOperacao.
     *
     * @return listaOperacao
     */
    public Collection<String> getListaOperacao() {
        return this.listaOperacao;
    }

    /**
     * Define o valor do atributo listaOperacao.
     *
     * @param listaOperacao
     *            valor a ser atribuído
     */
    public void setListaOperacao(final Collection<String> listaOperacao) {
        this.listaOperacao = listaOperacao;
    }

    /**
     * Retorna o valor do atributo listaTabela.
     *
     * @return listaTabela
     */
    public Collection<String> getListaTabela() {
        return this.listaTabela;
    }

    /**
     * Define o valor do atributo listaTabela.
     *
     * @param listaTabela
     *            valor a ser atribuído
     */
    public void setListaTabela(final Collection<String> listaTabela) {
        this.listaTabela = listaTabela;
    }

    /**
     * Retorna o valor do atributo listaRespOperacao.
     *
     * @return listaRespOperacao
     */
    public Collection<String> getListaRespOperacao() {
        return this.listaRespOperacao;
    }

    /**
     * Define o valor do atributo listaRespOperacao.
     *
     * @param listaRespOperacao
     *            valor a ser atribuído
     */
    public void setListaRespOperacao(final Collection<String> listaRespOperacao) {
        this.listaRespOperacao = listaRespOperacao;
    }

    /**
     * Retorna o valor do atributo trilhaAuditoriaSelecionada.
     *
     * @return trilhaAuditoriaSelecionada
     */
    public TrilhaHistorico getTrilhaHistoricoSelecionada() {
        return this.trilhaHistoricoSelecionada;
    }

    /**
     * Define o valor do atributo trilhaAuditoriaSelecionada.
     *
     * @param trilhaHistoricoSelecionada
     *            valor a ser atribuído
     */
    public void setTrilhaHistoricoSelecionada(final TrilhaHistorico trilhaHistoricoSelecionada) {
        if (!UtilString.isVazio(trilhaHistoricoSelecionada.getDeCamposVelhos())) {
            this.carregarListTrilhaHistoricoCamposAlteradosVisao(trilhaHistoricoSelecionada.getDeCamposVelhos(),
                    trilhaHistoricoSelecionada.getDeCamposNovos());
        }

        this.trilhaHistoricoSelecionada = trilhaHistoricoSelecionada;
    }

    /**
     * 
     * <p>
     * Método responsável por: carregar o atributo
     * listTrilhaHistoricoCamposAlteradosVisao a partir dos parâmetros
     * recebidos.
     * <p>
     *
     * @param camposAntesAlteracao
     *            - exemplo valor:
     *            "[getVrPrecificado=-102,7][getDhHomologacao=13-07-2015 11:20:45]"
     * @param camposDepoisAlteracao
     *            - exemplo valor:
     *            "[getVrPrecificado=-68,47][getDhHomologacao=16-07-2015 14:54:29 ]"
     * @author robson.oliveira
     */
    public void carregarListTrilhaHistoricoCamposAlteradosVisao(final String camposAntesAlteracao, final String camposDepoisAlteracao) {

        this.listTrilhaHistoricoCamposAlteradosVisao = new ArrayList<>();

        final String[] arrayCamposAntesAlteracao = camposAntesAlteracao.split("]");

        final String[] arrayCamposDepoisAlteracao = camposDepoisAlteracao.split("]");

        for (int i = 0; i < arrayCamposAntesAlteracao.length; i++) {

            final TrilhaHistoricoCampoAlteradoVisao campoAlteradoVisao = new TrilhaHistoricoCampoAlteradoVisao();

            final String[] campoAntes = arrayCamposAntesAlteracao[i].split("=", 2);
            campoAlteradoVisao.setNomeCampo(campoAntes[0].replace("[get", ""));
            campoAlteradoVisao.setValorAntesAlteracao(campoAntes[1]);

            final String[] campoDepois = arrayCamposDepoisAlteracao[i].split("=", 2);
            campoAlteradoVisao.setValorDepoisAlteracao(campoDepois[1]);

            this.listTrilhaHistoricoCamposAlteradosVisao.add(campoAlteradoVisao);
        }

    }

    /**
     * Retorna o valor do atributo listTrilhaHistoricoCamposAlteradosVisao.
     *
     * @return listTrilhaHistoricoCamposAlteradosVisao
     */
    public List<TrilhaHistoricoCampoAlteradoVisao> getListTrilhaHistoricoCamposAlteradosVisao() {
        return this.listTrilhaHistoricoCamposAlteradosVisao;
    }

}
