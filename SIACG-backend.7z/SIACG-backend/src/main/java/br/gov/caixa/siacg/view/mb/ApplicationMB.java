/**
 * Copyright (c) 2013 Caixa Econômica Federal. Todos os direitos
 * reservados.
 *
 * Caixa Econômica Federal - SICIC 
 *
 * Este software foi desenvolvido sob demanda da CAIXA e está
 * protegido por leis de direitos autorais e tratados internacionais. As
 * condições de cópia e utilização do todo ou partes dependem de autorização da
 * pessoa. Cópias não são permitidas sem expressa autorização. Não pode ser
 * comercializado ou utilizado para propósitos particulares.
 *
 * Uso exclusivo da Caixa Econômica Federal. A reprodução ou distribuição não
 * autorizada deste programa ou de parte dele, resultará em punições civis e
 * criminais e os infratores incorrem em sanções previstas na legislação em
 * vigor.
 *
 * Histórico do Subversion:
 *
 * LastChangedRevision: $Revision$
 * LastChangedBy: $Author$
 * LastChangedDate: $Date$
 *
 * HeadURL: $HeadURL$
 *
 */
package br.gov.caixa.siacg.view.mb;

import java.io.Serializable;
import java.util.HashMap;
import java.util.Map;
import java.util.Objects;

import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;

import br.gov.caixa.pedesgo.arquitetura.controlador.ManutencaoBean;
import br.gov.caixa.pedesgo.arquitetura.dao.DAO;
import br.gov.caixa.pedesgo.arquitetura.entidade.Entidade;
import br.gov.caixa.pedesgo.arquitetura.servico.Servico;
import br.gov.caixa.pedesgo.arquitetura.util.UsuarioUtil;
import br.gov.caixa.pedesgo.arquitetura.visao.ManutencaoVisao;
import br.gov.caixa.siacg.model.enums.NoFuncionalidadeEnum;
import br.gov.caixa.siacg.model.enums.TipoBemEnum;

/**
 * <p>ApplicationMB</p>
 *
 * <p>Descrição: Descrição do tipo</p>
 *
 * <br><b>Empresa:</b> Cef - Caixa Econômica Federal
 *
 *
 * @author Leandro Santos Oliveira
 *
 * @version 1.0
*/	
@ManagedBean(name = ApplicationMB.NOME_MANAGED_BEAN)
@SessionScoped
public class ApplicationMB extends ManutencaoBean<Entidade> implements Serializable {

    private static final long serialVersionUID = -1681211892423968673L;

    public static final String NOME_MANAGED_BEAN = "applicationMB";
    public static final String EL_MANAGED_BEAN = "#{applicationMB}";

    /** Atributo possuiPermissaoAnaliseGarantia. */
    private Boolean possuiPermissaoAnaliseGarantia;

    /** Atributo podePesquisarcontrato. */
    private Boolean podePesquisarcontrato;

    /** Atributo podeParametrizarContrato. */
    private Boolean podeParametrizarContrato;

    /** Atributo possuiPermissaoAnaliseCarteira. */
    private Boolean possuiPermissaoAnaliseCarteira;

    /** Atributo possuiPermissaoPreAnaliseCarteira. */
    private Boolean possuiPermissaoPreAnaliseCarteira;

    /** Atributo possuiPermissaoSacadoNaoAceito. */
    private Boolean possuiPermissaoSacadoNaoAceito;

    /** Atributo podeConsultarUnidade. */
    private Boolean podeConsultarUnidade;

    /** Atributo podeManterMensagemApresentacao. */
    private Boolean podeManterMensagemApresentacao;

    /** Atributo podeManterParametrosCalculo. */
    private Boolean podeManterParametrosCalculo;

    /** Atributo possuiPermissaoPesquisaContratoNaoParametrizado. */
    private Boolean possuiPermissaoPesquisaContratoNaoParametrizado;

    /** Atributo possuiPermissaoAnaliseGarantiaNaoParametrizado. */
    private Boolean possuiPermissaoAnaliseGarantiaNaoParametrizado;

    /** Atributo possuiPermissaoManterGarantiasContrato. */
    private Boolean possuiPermissaoManterGarantiasContrato;

    /** Atributo possuiPermissaoParametrizaContratoContaCorrente. */
    private Boolean possuiPermissaoParametrizaContratoContaCorrente;

    /** Atributo possuiPermissaoParametrizaContratoContaCorrenteMarcar. */
    private Boolean possuiPermissaoParametrizaContratoContaCorrenteMarcar;

    /** Atributo possuiPermissaoParametrizaContratoExcepcionarGarantia. */
    private Boolean possuiPermissaoParametrizaContratoExcepcionarGarantia;

    /** Atributo possuiPermissaoParametrizaContratoExcepcionarSacado. */
    private Boolean possuiPermissaoParametrizaContratoExcepcionarSacado;

    /** Atributo possuiPermissaoEmitirRelatorioAnaliseGarantiaExportar. */
    private Boolean possuiPermissaoEmitirRelatorioAnaliseGarantiaExportar;

    /** Atributo possuiPermissaoEmitirRelatorioAtendimentoGarantiasExportar. */
    private Boolean possuiPermissaoEmitirRelatorioAtendimentoGarantiasExportar;

    /** Atributo possuiPermissaoAnaliseGarantiaDetalhesUltimaAnalise. */
    private Boolean possuiPermissaoAnaliseGarantiaDetalhesUltimaAnalise;

    /** Atributo possuiPermissaoAnaliseGarantiaDetalhesOutrosContratos. */
    private Boolean possuiPermissaoAnaliseGarantiaDetalhesOutrosContratos;

    /** Atributo possuiPermissaoAnaliseGarantiaTotalDetalhesDuplicatas. */
    private Boolean possuiPermissaoAnaliseGarantiaDetalhesTotalDuplicatas;

    /** Atributo possuiPermissaoAnaliseGarantiaDetalhesSacadosExcepcionados. */
    private Boolean possuiPermissaoAnaliseGarantiaDetalhesSacadosExcepcionados;

    private Boolean podeManterSacadoNaoAceito;

    /** Atributo possuiPermissaoAnaliseGarantiaDetalhesDuplicatasExcepcionada. */
    private Boolean possuiPermissaoAnaliseGarantiaDetalhesDuplicatasExcepcionada;

    /** Atributo podeParametrizarContratoExcepcionarCheque. */
    private Boolean podeParametrizarContratoExcepcionarCheque;

    /** Atributo possuiPermissaoAnaliseGarantiaDetlahesChequesExcepcionados. */
    private Boolean possuiPermissaoAnaliseGarantiaDetlahesChequesExcepcionados;

    /** Atributo podeManterTemplateMensageria. */
    private Boolean podeManterTemplateMensageria;

    /** Atributo possuiPermissaoAgendamentoEnvioAutomatico. */
    private Boolean possuiPermissaoAgendamentoEnvioAutomatico;

    /** Atributo possuiPermissaoEnviaNotificacaoManual. */
    private Boolean possuiPermissaoEnviaNotificacaoManual;

    /** Atributo podeParametrizarPreAnalise. */
    private Boolean podeParametrizarPreAnalise;

    /** Atributo podeParametrizarPreAnaliseGarantia. */
    private Boolean podeParametrizarPreAnaliseGarantia;

    /** Atributo podeManterDestinatarios. */
    private Boolean podeManterDestinatarios;

    /** Atributo possuiPermissaoAcompanhamentoEndividadentoExportar. */
    private Boolean possuiPermissaoAcompanhamentoEndividadentoExportar;

    /** Atributo possuiPermissaoAcompanhamentoEndividadento. */
    private Boolean possuiPermissaoAcompanhamentoEndividadento;

    /** Atributo possuiPermissaoRelatorioSaldoLiquidoPessoa. */
    private Boolean possuiPermissaoRelatorioSaldoLiquidoPessoa;

    /** Atributo possuiPermissaoPainelGarantiaInsuficiente. */
    private Boolean possuiPermissaoPainelGarantiaInsuficiente;

    /** Atributo possuiPermissaoPainelContratoNaoParametrizado. */
    private Boolean possuiPermissaoPainelContratoNaoParametrizado;

    /** Atributo possuiPermissaoPainelNovoContrato. */
    private Boolean possuiPermissaoPainelNovoContrato;

    /** Atributo possuiPermissaoConsultaContratoParametrizado. */
    private Boolean possuiPermissaoConsultaContratoParametrizado;

    /** Atributo possuiPermissaoConsultaContratoNaoParametrizado. */
    private Boolean possuiPermissaoConsultaContratoNaoParametrizado;

    /** Atributo possuiPermissaoConsultaContratoNaoParametrizado. */
    private Boolean possuiPermissaoConsultaContratoNaoParametrizadoManual;

    /** Atributo possuiPermissaoPainelGarantiaConstituidaSatisfatorio. */
    private Boolean possuiPermissaoPainelGarantiaConstituidaSatisfatorio;

    /** Atributo possuiPermissaoPainelGarantiaConstituidaMediana. */
    private Boolean possuiPermissaoPainelGarantiaConstituidaMediana;

    /** Atributo possuiPermissaoPainelGarantiaConstituidaInsatisfatorio. */
    private Boolean possuiPermissaoPainelGarantiaConstituidaInsatisfatorio;

    /** Atributo possuiPermissaoPainelGarantiaNaoAcompanha. */
    private Boolean possuiPermissaoPainelGarantiaSiacgNaoAcompanha;

    /** Atributo podeEmitirRelatorioGerencias. */
    private Boolean podeEmitirRelatorioGerencias;
    
    /** Atributo podeManterGarantia. */
    private Boolean podeManterGarantia;
    
    /** Atributo podeConsultarLogAuditoria. */
    private Boolean podeConsultarLogAuditoria;
    
    /** Atributo podeManterFaturamento. */
    private Boolean podeManterFaturamento;
    
    /** Atributo podeEmitirRelatorioExcessoGarantia. */
    private Boolean podeEmitirRelatorioExcessoGarantia;
    
    /** Atributo podeEmitirRelatorioPainelGarantias. */
    private Boolean podeEmitirRelatorioPainelGarantias;
    
    /** Atributo possuiPermissaoFiltrarSegmentoPainel. */
    private Boolean possuiPermissaoFiltrarSegmentoPainel;
    
    /** Atributo podeConsultarDadosInterface. */
    private Boolean podeConsultarDadosInterface;
    
    /** Atributo podeManterGarantiaProduto. */
    private Boolean podeManterGarantiaProduto;

    /** Atributo podeManterAplicacaoFinanceira */
    private Boolean podeManterAplicacaoFinanaceira;
    
    /** Atributo podeManterTitulo. */
    private Boolean podeManterTitulo;
    
    /** Atributo podeEmitirRelatorioAppFinanceirasBloqueadas. */
    private Boolean podeEmitirRelatorioAppFinanceirasBloqueadas;
    
    /** Atributo podeEmitirRelatoriosFrenteHabitacional. */
    private Boolean podeEmitirRelatoriosFrenteHabitacional;
    
    /** Atributo podeEmitirRelatorioConciliacao. */
    private Boolean podeEmitirRelatorioConciliacao;
    
    /** Atributo podeEmitirRelatorioApetiteRiscoApos2018. */
    private Boolean podeEmitirRelatorioApetiteRiscoApos2018;
    
    /** Atributo podeConsultarFornecedores */
    private Boolean podeConsultarFornecedor;
   
    /** Atributo podeConsultarDespesa */
    private Boolean podeConsultarDespesa;
    
    /** Atributo podeEmitirRelatorioApetiteRisco. */
    private Boolean podeEmitirRelatorioApetiteRiscoAte2018;
     
    /** Atributo podeManterRemetente. */
    private Boolean podeManterRemetentes;
    
    private Boolean podeManterPortes;
    
    private Boolean podeManterBandeiraCartao;

	private Boolean podeManterBemCliente;

	private Boolean podeManterProspecto;
	
	private Boolean podeManterRedeVarejo;

	private Boolean podeAcompanharImovel;

    private Boolean podeRealizarLeilao;

	private Boolean podeManterServentia;
	
	private Boolean podeManterMenuCadastro;
	
	private Boolean podeManterSubMenuExecucao;
	
	private Boolean podeManterMenuConsulta;
	
	private Boolean podeManterMenuManutencao;
	
	private Boolean podeManterSubMenuMensageria;
	
	private Boolean podeManterMenuRelatorio;
	
	private Boolean podeManterMenuRelatorioGerencial;
	
	private Boolean podeVisualizarPainelDiario;
	
	private Boolean podeVisualizarPainelCarga;
	
	private Boolean podeRestringirOperacao;
	
	private Boolean podeAtualizarManualUsuario;
	
	private Boolean podeAlterarTratamentoEspecial;
	
	private Boolean podeManterBemClienteImovel;
	
	private Boolean podeManterBemClienteMaquina;
	
	private Boolean podeManterBemClienteVeiculo;
	
	private Boolean podeIncluirBemCliente;
	
	private Boolean podeCalcularValorImovel;
	
	private Boolean podeSanarPendenciaLeilaoImovel;
	
	private Boolean podeAlterarSituacaoLeilaoParaExcluido;
    
	/**
     * @see br.gov.caixa.pedesgo.arquitetura.controlador.AbstractBean#getPrefixoCasoDeUso()
     */
    @Override
    protected String getPrefixoCasoDeUso() {
        return null;
    }

    /**
     * @see br.gov.caixa.pedesgo.arquitetura.controlador.AbstractBean#getService()
     */
    @Override
    public <S extends Servico<Entidade, DAO<Entidade>>> S getService() {
        return null;
    }

    /**
     * @see br.gov.caixa.pedesgo.arquitetura.controlador.AbstractBean#getVisao()
     */
    @Override
    public ManutencaoVisao<Entidade> getVisao() {
        return null;
    }

    /**
     * <p>
     * Retorna o valor do atributo podePesquisarcontrato (pesquisar_contrato)
     * </p>
     * .
     *
     * @return podePesquisarcontrato
     */
    public Boolean getPodePesquisarcontrato() {
        if (this.podePesquisarcontrato == null) {
            this.podePesquisarcontrato = UsuarioUtil.contemFuncionalidade(NoFuncionalidadeEnum.PESQUISA_CONTRATO.getNoFuncionalidade());
        }
        return this.podePesquisarcontrato;
    }

    /**
     * <p>
     * Retorna o valor do atributo podeParametrizarContrato (parametrizar_contrato)
     * </p>
     * .
     *
     * @return podeParametrizarContrato
     */
    public Boolean getPodeParametrizarContrato() {
        if (this.podeParametrizarContrato == null) {
            this.podeParametrizarContrato = UsuarioUtil.contemFuncionalidade(NoFuncionalidadeEnum.PARAMETRIZA_CONTRATO.getNoFuncionalidade());
        }
        return this.podeParametrizarContrato;
    }

    /**
     * <p>
     * Retorna o valor do atributo possuiPermissaoAnaliseCarteira (analise_carteira)
     * </p>
     * .
     *
     * @return possuiPermissaoAnalise_carteira
     */
    public Boolean getPossuiPermissaoAnaliseCarteira() {
        if (this.possuiPermissaoAnaliseCarteira == null) {
            this.possuiPermissaoAnaliseCarteira = UsuarioUtil.contemFuncionalidade(NoFuncionalidadeEnum.ANALISE_CARTEIRA.getNoFuncionalidade());
        }
        return this.possuiPermissaoAnaliseCarteira;
    }

    /**
     * <p>
     * Retorna o valor do atributo temPermissaoAnaliseGarantia (analise_garantia)
     * </p>
     * .
     *
     * @return temPermissaoAnaliseGarantia
     */
    public Boolean getPossuiPermissaoAnaliseGarantia() {
        if (this.possuiPermissaoAnaliseGarantia == null) {
            this.possuiPermissaoAnaliseGarantia = UsuarioUtil.contemFuncionalidade(NoFuncionalidadeEnum.ANALISE_GARANTIA.getNoFuncionalidade());
        }
        return this.possuiPermissaoAnaliseGarantia;
    }

    /**
     * <p>
     * Retorna o valor do atributo possuiPermissaoPreAnaliseCarteira (pre_analise_carteira)
     * </p>
     * .
     *
     * @return possuiPermissaoPreAnaliseCarteira
     */
    public Boolean getPossuiPermissaoPreAnaliseCarteira() {
        if (this.possuiPermissaoPreAnaliseCarteira == null) {
            this.possuiPermissaoPreAnaliseCarteira = UsuarioUtil
                    .contemFuncionalidade(NoFuncionalidadeEnum.PRE_ANALISE_CARTEIRA.getNoFuncionalidade());
        }
        return this.possuiPermissaoPreAnaliseCarteira;
    }

    /**
     * <p>
     * Retorna o valor do atributo possuiPermissaoSacadoNaoAceito (sacado_nao_aceito)
     * </p>
     * .
     *
     * @return possuiPermissaoSacadoNaoAceito
     */
    public Boolean getPossuiPermissaoSacadoNaoAceito() {
        if (this.possuiPermissaoSacadoNaoAceito == null) {
            this.possuiPermissaoSacadoNaoAceito = UsuarioUtil.contemFuncionalidade(NoFuncionalidadeEnum.SACADO_NAO_ACEITO.getNoFuncionalidade());
        }
        return this.possuiPermissaoSacadoNaoAceito;
    }

    /**
     * <p>
     * Retorna o valor do atributo podeConsultarUnidade (consulta_unidade)
     * </p>
     * .
     *
     * @return podeConsultarUnidade
     */
    public Boolean getPodeConsultarUnidade() {
        if (this.podeConsultarUnidade == null) {
            this.podeConsultarUnidade = UsuarioUtil.contemFuncionalidade(NoFuncionalidadeEnum.CONSULTA_UNIDADE.getNoFuncionalidade());
        }
        return this.podeConsultarUnidade;
    }

    /**
     * <p>
     * Retorna o valor do atributo podeManterMensagemApresentacao (mantem_mensag_apresentac)
     * </p>
     * .
     *
     * @return podeManterMensagemApresentacao
     */
    public Boolean getPodeManterMensagemApresentacao() {
        if (this.podeManterMensagemApresentacao == null) {
            this.podeManterMensagemApresentacao = UsuarioUtil.contemFuncionalidade(NoFuncionalidadeEnum.MANTEM_MENSAGEM_APRESENTACAO
                    .getNoFuncionalidade());
        }
        return this.podeManterMensagemApresentacao;
    }

    /**
     * <p>
     * Retorna o valor do atributo podeManterParametrosCalculo (mantem_parametros_calculo)
     * </p>
     * .
     *
     * @return podeManterParametrosCalculo
     */
    public Boolean getPodeManterParametrosCalculo() {
        if (this.podeManterParametrosCalculo == null) {
            this.podeManterParametrosCalculo = UsuarioUtil.contemFuncionalidade(NoFuncionalidadeEnum.MANTEM_PARAMETROS_CALCULO.getNoFuncionalidade()) || UsuarioUtil.contemFuncionalidade(NoFuncionalidadeEnum.HOMOLOGAR_PARAMETRO_PRODU.getNoFuncionalidade());
        }
        return this.podeManterParametrosCalculo;
    }

    /**
     * <p>
     * Retorna o valor do atributo possuiPermissaoPesquisaContratoNaoParametrizado (pesquisa_contrato_nao_par)
     * </p>
     * .
     *
     * @return possuiPermissaoPesquisaContratoNaoParametrizado
     */
    public Boolean getPossuiPermissaoPesquisaContratoNaoParametrizado() {
        if (this.possuiPermissaoPesquisaContratoNaoParametrizado == null) {
            this.possuiPermissaoPesquisaContratoNaoParametrizado = UsuarioUtil
                    .contemFuncionalidade(NoFuncionalidadeEnum.PESQUISA_CONTRATO_NAO_PARAMETRIZADO.getNoFuncionalidade());
        }
        return this.possuiPermissaoPesquisaContratoNaoParametrizado;
    }

    /**
     * <p>
     * Retorna o valor do atributo possuiPermissaoAnaliseGarantiaNaoParametrizado (analise_garantia_nao_par)
     * </p>
     * .
     *
     * @return possuiPermissaoAnaliseGarantiaNaoParametrizado
     */
    public Boolean getPossuiPermissaoAnaliseGarantiaNaoParametrizado() {
        if (this.possuiPermissaoAnaliseGarantiaNaoParametrizado == null) {
            this.possuiPermissaoAnaliseGarantiaNaoParametrizado = UsuarioUtil
                    .contemFuncionalidade(NoFuncionalidadeEnum.ANALISE_GARANTIA_NAO_PARAMETRIZADO.getNoFuncionalidade());
        }
        return this.possuiPermissaoAnaliseGarantiaNaoParametrizado;
    }

    /**
     * <p>
     * Retorna o valor do atributo possuiPermissaoManterGarantiasContrato (mantem_garantias_contrato)
     * </p>
     * .
     *
     * @return possuiPermissaoManterGarantiasContrato
     */
    public Boolean getPossuiPermissaoManterGarantiasContrato() {
        if (this.possuiPermissaoManterGarantiasContrato == null) {
            this.possuiPermissaoManterGarantiasContrato = UsuarioUtil
                    .contemFuncionalidade(NoFuncionalidadeEnum.PARAMETRIZA_CONTRATO_GARANTIA_CONTRATO.getNoFuncionalidade());
        }
        return this.possuiPermissaoManterGarantiasContrato;
    }

    /**
     * <p>
     * Retorna o valor do atributo possuiPermissaoParametrizaContratoContaCorrente (parametriza_conta_nlm)
     * </p>
     * .
     *
     * @return possuiPermissaoParametrizaContratoContaCorrente
     */
    public Boolean getPossuiPermissaoParametrizaContratoContaCorrente() {
        if (this.possuiPermissaoParametrizaContratoContaCorrente == null) {
            this.possuiPermissaoParametrizaContratoContaCorrente = UsuarioUtil
                    .contemFuncionalidade(NoFuncionalidadeEnum.PARAMETRIZA_CONTRATO_CONTA_CORRENTE.getNoFuncionalidade());
        }
        return this.possuiPermissaoParametrizaContratoContaCorrente;
    }

    /**
     * <p>
     * Retorna o valor do atributo possuiPermissaoParametrizaContratoContaCorrenteMarcar (marcar_contas_nlm)
     * </p>
     * .
     *
     * @return possuiPermissaoParametrizaContratoContaCorrenteMarcar
     */
    public Boolean getPossuiPermissaoParametrizaContratoContaCorrenteMarcar() {
        if (this.possuiPermissaoParametrizaContratoContaCorrenteMarcar == null) {
            this.possuiPermissaoParametrizaContratoContaCorrenteMarcar = UsuarioUtil
                    .contemFuncionalidade(NoFuncionalidadeEnum.PARAMETRIZA_CONTRATO_CONTA_CORRENTE_MARCAR.getNoFuncionalidade());
        }
        return this.possuiPermissaoParametrizaContratoContaCorrenteMarcar;
    }

    /**
     * <p>
     * Retorna o valor do atributo possuiPermissaoParametrizaContratoExcepcionarGarantia (excepcionar_garantia)
     * </p>
     * .
     *
     * @return possuiPermissaoParametrizaContratoExcepcionarGarantia
     */
    public Boolean getPossuiPermissaoParametrizaContratoExcepcionarGarantia() {
        if (this.possuiPermissaoParametrizaContratoExcepcionarGarantia == null) {
            this.possuiPermissaoParametrizaContratoExcepcionarGarantia = UsuarioUtil
                    .contemFuncionalidade(NoFuncionalidadeEnum.PARAMETRIZA_CONTRATO_EXCEPCIONAR_GARANTIA.getNoFuncionalidade());
        }
        return this.possuiPermissaoParametrizaContratoExcepcionarGarantia;
    }

    /**
     * <p>
     * Retorna o valor do atributo possuiPermissaoParametrizaContratoExcepcionarSacado (excepionar_sacado)
     * </p>
     * .
     *
     * @return possuiPermissaoParametrizaContratoExcepcionarSacado
     */
    public Boolean getPossuiPermissaoParametrizaContratoExcepcionarSacado() {
        if (this.possuiPermissaoParametrizaContratoExcepcionarGarantia == null) {
            this.possuiPermissaoParametrizaContratoExcepcionarGarantia = UsuarioUtil
                    .contemFuncionalidade(NoFuncionalidadeEnum.PARAMETRIZA_CONTRATO_EXCEPCIONAR_SACADO.getNoFuncionalidade());
        }
        return this.possuiPermissaoParametrizaContratoExcepcionarSacado;
    }

    /**
     * <p>
     * Retorna o valor do atributo possuiPermissaoEmitirRelatorioAnaliseGarantiaExportar (exporta_contratos_xls)
     * </p>
     * .
     *
     * @return possuiPermissaoEmitirRelatorioAnaliseGarantiaExportar
     */
    public Boolean getPossuiPermissaoEmitirRelatorioAnaliseGarantiaExportar() {
        if (this.possuiPermissaoEmitirRelatorioAnaliseGarantiaExportar == null) {
            this.possuiPermissaoEmitirRelatorioAnaliseGarantiaExportar = UsuarioUtil
                    .contemFuncionalidade(NoFuncionalidadeEnum.EMITE_RELATORIO_ANALISE_GARANTIA_EXPORTAR.getNoFuncionalidade());
        }
        return this.possuiPermissaoEmitirRelatorioAnaliseGarantiaExportar;
    }

    /**
     * <p>
     * Retorna o valor do atributo possuiPermissaoEmitirRelatorioAtendimentoGarantiasExportar (exportar_contratos_pdf)
     * </p>
     * .
     *
     * @return possuiPermissaoEmitirRelatorioAtendimentoGarantiasExportar
     */
    public Boolean getPossuiPermissaoEmitirRelatorioAtendimentoGarantiasExportar() {
        if (this.possuiPermissaoEmitirRelatorioAtendimentoGarantiasExportar == null) {
            this.possuiPermissaoEmitirRelatorioAtendimentoGarantiasExportar = UsuarioUtil
                    .contemFuncionalidade(NoFuncionalidadeEnum.EMITER_RELATORIO_ATENDIMENTO_GARANTIAS_EXPORTAR.getNoFuncionalidade());
        }
        return this.possuiPermissaoEmitirRelatorioAtendimentoGarantiasExportar;
    }

    /**
     * <p>
     * Retorna o valor do atributo possuiPermissaoAnaliseGarantiaDetalhesUltimaAnalise (analise_garantia_analises)
     * </p>
     * .
     *
     * @return possuiPermissaoAnaliseGarantiaDetalhesUltimaAnalise
     */
    public Boolean getPossuiPermissaoAnaliseGarantiaDetalhesUltimaAnalise() {
        if (this.possuiPermissaoAnaliseGarantiaDetalhesUltimaAnalise == null) {
            this.possuiPermissaoAnaliseGarantiaDetalhesUltimaAnalise = UsuarioUtil
                    .contemFuncionalidade(NoFuncionalidadeEnum.ANALISE_GARANTIA_DETALHES_ULTIMA_ANALISE.getNoFuncionalidade());
        }
        return this.possuiPermissaoAnaliseGarantiaDetalhesUltimaAnalise;
    }

    /**
     * <p>
     * Retorna o valor do atributo possuiPermissaoAnaliseGarantiaDetalhesOutrosContratos (analise_garant_contratos)
     * </p>
     * .
     *
     * @return possuiPermissaoAnaliseGarantiaDetalhesOutrosContratos
     */
    public Boolean getPossuiPermissaoAnaliseGarantiaDetalhesOutrosContratos() {
        if (this.possuiPermissaoAnaliseGarantiaDetalhesOutrosContratos == null) {
            this.possuiPermissaoAnaliseGarantiaDetalhesOutrosContratos = UsuarioUtil
                    .contemFuncionalidade(NoFuncionalidadeEnum.ANALISE_GARANTIA_DETALHES_OUTROS_CONTRATOS.getNoFuncionalidade());
        }
        return this.possuiPermissaoAnaliseGarantiaDetalhesOutrosContratos;
    }

    /**
     * <p>
     * Retorna o valor do atributo possuiPermissaoAnaliseGarantiaTotalDuplicatas (analise_garantia_duplicat)
     * </p>
     * .
     *
     * @return possuiPermissaoAnaliseGarantiaTotalDuplicatas
     */
    public Boolean getPossuiPermissaoAnaliseGarantiaDetalhesTotalDuplicatas() {
        if (this.possuiPermissaoAnaliseGarantiaDetalhesTotalDuplicatas == null) {
            this.possuiPermissaoAnaliseGarantiaDetalhesTotalDuplicatas = UsuarioUtil
                    .contemFuncionalidade(NoFuncionalidadeEnum.ANALISE_GARANTIA_DETALHES_TOTAL_DUPLICATAS.getNoFuncionalidade());
        }
        return this.possuiPermissaoAnaliseGarantiaDetalhesTotalDuplicatas;
    }

    /**
     * <p>
     * Retorna o valor do atributo possuiPermissaoAnaliseGarantiaDetalhesSacadosExcepcionados (analise_sacados_excepcin)
     * </p>
     * .
     *
     * @return possuiPermissaoAnaliseGarantiaDetalhesSacadosExcepcionados
     */
    public Boolean getPossuiPermissaoAnaliseGarantiaDetalhesSacadosExcepcionados() {
        if (this.possuiPermissaoAnaliseGarantiaDetalhesSacadosExcepcionados == null) {
            this.possuiPermissaoAnaliseGarantiaDetalhesSacadosExcepcionados = UsuarioUtil
                    .contemFuncionalidade(NoFuncionalidadeEnum.ANALISE_GARANTIA_DETALHES_SACADOS_EXCEPICIONADOS.getNoFuncionalidade());
        }
        return this.possuiPermissaoAnaliseGarantiaDetalhesSacadosExcepcionados;
    }

    /**
     * <p>
     * Retorna o valor do atributo podeManterCadadoNaoAceito (mantem_sacado_nao_aceito)
     * </p>
     * .
     *
     * @return podeManterCadadoNaoAceito
     */
    public Boolean getPodeManterSacadoNaoAceito() {
        if (this.podeManterSacadoNaoAceito == null) {
            this.podeManterSacadoNaoAceito = UsuarioUtil.contemFuncionalidade(NoFuncionalidadeEnum.MANTEM_SACADO_NAO_ACEITO.getNoFuncionalidade());
        }
        return this.podeManterSacadoNaoAceito;
    }

    /**
     * <p>
     * Retorna o valor do atributo possuiPermissaoAnaliseGarantiaDetalhesDuplicatasExcepcionada (analise_duplicat_excepcin)
     * </p>
     * .
     *
     * @return possuiPermissaoAnaliseGarantiaDetalhesDuplicatasExcepcionada
     */
    public Boolean getPossuiPermissaoAnaliseGarantiaDetalhesDuplicatasExcepcionada() {
        if (this.possuiPermissaoAnaliseGarantiaDetalhesDuplicatasExcepcionada == null) {
            this.possuiPermissaoAnaliseGarantiaDetalhesDuplicatasExcepcionada = UsuarioUtil
                    .contemFuncionalidade(NoFuncionalidadeEnum.ANALISE_GARANTIA_DETALHES_DUPLICATAS_EXCEPCIONADAS.getNoFuncionalidade());
        }
        return this.possuiPermissaoAnaliseGarantiaDetalhesDuplicatasExcepcionada;
    }

    /**
     * <p>
     * Retorna o valor do atributo podeParametrizarContratoExcepcionarCheque (excepciona_g_tipo_cheque)
     * </p>
     * .
     *
     * @return podeParametrizarContratoExcepcionarCheque
     */
    public Boolean getPodeParametrizarContratoExcepcionarCheque() {
        if (this.podeParametrizarContratoExcepcionarCheque == null) {
            this.podeParametrizarContratoExcepcionarCheque = UsuarioUtil
                    .contemFuncionalidade(NoFuncionalidadeEnum.PARAMETRIZA_CONTRATO_EXCEPCIONAR_CHEQUE.getNoFuncionalidade());
        }
        return this.podeParametrizarContratoExcepcionarCheque;
    }

    /**
     * <p>
     * Retorna o valor do atributo possuiPermissaoAnaliseGarantiaDetlahesChequesExcepcionados (analise_cheques_excepcin)
     * </p>
     * .
     *
     * @return possuiPermissaoAnaliseGarantiaDetlahesChequesExcepcionados
     */
    public Boolean getPossuiPermissaoAnaliseGarantiaDetlahesChequesExcepcionados() {
        if (this.possuiPermissaoAnaliseGarantiaDetlahesChequesExcepcionados == null) {
            this.possuiPermissaoAnaliseGarantiaDetlahesChequesExcepcionados = UsuarioUtil
                    .contemFuncionalidade(NoFuncionalidadeEnum.ANALISE_GARANTIA_DETALHES_CHEQUES_EXCEPCIONADOS.getNoFuncionalidade());
        }
        return this.possuiPermissaoAnaliseGarantiaDetlahesChequesExcepcionados;
    }

    /**
     * <p>
     * Retorna o valor do atributo podeManterTemplateMensageria (mantem_template_mensag)
     * </p>
     * .
     *
     * @return podeManterTemplateMensageria
     */
    public Boolean getPodeManterTemplateMensageria() {
        if (this.podeManterTemplateMensageria == null) {
            this.podeManterTemplateMensageria = UsuarioUtil.contemFuncionalidade(NoFuncionalidadeEnum.MANTEM_TEMPLATE_MENSAGERIA
                    .getNoFuncionalidade());
        }
        return this.podeManterTemplateMensageria;
    }

    /**
     * <p>
     * Retorna o valor do atributo possuiPermissaoAgendamentoEnvioAutomatico (agenda_envio_automatico)
     * </p>
     * .
     *
     * @return possuiPermissaoAgendamentoEnvioAutomatico
     */
    public Boolean getPossuiPermissaoAgendamentoEnvioAutomatico() {
        if (this.podeManterTemplateMensageria == null) {
            this.podeManterTemplateMensageria = UsuarioUtil.contemFuncionalidade(NoFuncionalidadeEnum.AGENDAMENTO_ENVIO_AUTOMATICO_MENSAGERIA
                    .getNoFuncionalidade());
        }
        return this.possuiPermissaoAgendamentoEnvioAutomatico;
    }

    /**
     * <p>
     * Retorna o valor do atributo possuiPermissaoEnviaNotificacaoManual (enviar_mensag_not_manual)
     * </p>
     * .
     *
     * @return possuiPermissaoEnviaNotificacaoManual
     */
    public Boolean getPossuiPermissaoEnviaNotificacaoManual() {
        if (this.possuiPermissaoEnviaNotificacaoManual == null) {
            this.possuiPermissaoEnviaNotificacaoManual = UsuarioUtil.contemFuncionalidade(NoFuncionalidadeEnum.ENVIA_NOTIFICACAO_MANUAL
                    .getNoFuncionalidade());
        }
        return this.possuiPermissaoEnviaNotificacaoManual;
    }

    /**
     * <p>
     * Retorna o valor do atributo podeParametrizarPreAnalise (parametriza_pre_analise)
     * </p>
     * .
     *
     * @return podeParametrizarPreAnalise
     */
    public Boolean getPodeParametrizarPreAnalise() {
        if (this.podeParametrizarPreAnalise == null) {
            this.podeParametrizarPreAnalise = UsuarioUtil.contemFuncionalidade(NoFuncionalidadeEnum.PARAMETRIZA_PRE_ANALISE.getNoFuncionalidade());
        }
        return this.podeParametrizarPreAnalise;
    }

    /**
     * <p>
     * Retorna o valor do atributo podeParametrizarPreAnaliseGarantia (mantem_pre_analise_g)
     * </p>
     * .
     *
     * @return podeParametrizarPreAnaliseGarantia
     */
    public Boolean getPodeParametrizarPreAnaliseGarantia() {
        if (this.podeParametrizarPreAnaliseGarantia == null) {
            this.podeParametrizarPreAnaliseGarantia = UsuarioUtil.contemFuncionalidade(NoFuncionalidadeEnum.PARAMETRIZA_PRE_ANALISE_GARANTIA
                    .getNoFuncionalidade());
        }
        return this.podeParametrizarPreAnaliseGarantia;
    }

    /**
     * <p>
     * Retorna o valor do atributo podeManterDestinatarios (manter_destinat_parametrz)
     * </p>
     * .
     *
     * @return podeManterDestinatarios
     */
    public Boolean getPodeManterDestinatarios() {
        if (this.podeManterDestinatarios == null) {
            this.podeManterDestinatarios = UsuarioUtil.contemFuncionalidade(NoFuncionalidadeEnum.MANTEM_DESTINATARIOS.getNoFuncionalidade());
        }
        return this.podeManterDestinatarios;
    }

    /**
     * <p>
     * Retorna o valor do atributo possuiPermissaoAcompanhamentoEndividadentoExportar (acompanhamento_endividamento_exportar)
     * </p>
     * .
     *
     * @return possuiPermissaoAcompanhamentoEndividadentoExportar
     */
    public Boolean getPossuiPermissaoAcompanhamentoEndividadentoExportar() {
        if (this.possuiPermissaoAcompanhamentoEndividadentoExportar == null) {
            this.possuiPermissaoAcompanhamentoEndividadentoExportar = UsuarioUtil
                    .contemFuncionalidade(NoFuncionalidadeEnum.ACOMPANHAMENTO_ENVIDAMENTO_EXPORTAR.getNoFuncionalidade());
        }
        return this.possuiPermissaoAcompanhamentoEndividadentoExportar;
    }

    /**
     * <p>
     * Retorna o valor do atributo possuiPermissaoAcompanhamentoEndividadento (acomp_endividam_consulta)
     * </p>
     * .
     *
     * @return possuiPermissaoAcompanhamentoEndividadento
     */
    public Boolean getPossuiPermissaoAcompanhamentoEndividadento() {
        if (this.possuiPermissaoAcompanhamentoEndividadento == null) {
            this.possuiPermissaoAcompanhamentoEndividadento = UsuarioUtil.contemFuncionalidade(NoFuncionalidadeEnum.ACOMPANHAMENTO_ENVIDAMENTO
                    .getNoFuncionalidade());
        }
        return this.possuiPermissaoAcompanhamentoEndividadento;
    }

    /**
     * <p>
     * Retorna o valor do atributo possuiPermissaoRelatorioSaldoLiquidoPessoa (relatorio_saldo_liquido_pessoa)
     * </p>
     * .
     *
     * @return possuiPermissaoRelatorioSaldoLiquidoPessoa
     */
    public Boolean getPossuiPermissaoRelatorioSaldoLiquidoPessoa() {
        if (this.possuiPermissaoRelatorioSaldoLiquidoPessoa == null) {
            this.possuiPermissaoRelatorioSaldoLiquidoPessoa = UsuarioUtil.contemFuncionalidade(NoFuncionalidadeEnum.RELATORIO_SALDO_LIQUIDO_PESSOA
                    .getNoFuncionalidade());
        }
        return this.possuiPermissaoRelatorioSaldoLiquidoPessoa;
    }

    /**
     * <p>
     * Retorna o valor do atributo possuiPermissaoPainelGarantiaInsuficiente (p_garantia_insuficiente)
     * </p>
     * .
     *
     * @return possuiPermissaoPainelGarantiaInsuficiente
     */
    public Boolean getPossuiPermissaoPainelGarantiaInsuficiente() {
        if (this.possuiPermissaoPainelGarantiaInsuficiente == null) {
            this.possuiPermissaoPainelGarantiaInsuficiente = UsuarioUtil.contemFuncionalidade(NoFuncionalidadeEnum.PAINEL_GARANTIA_INSUFICIENTE
                    .getNoFuncionalidade());
        }
        return this.possuiPermissaoPainelGarantiaInsuficiente;
    }

    /**
     * <p>
     * Retorna o valor do atributo possuiPermissaoPainelContratoNaoParametrizado (p_contrato_nao_param)
     * </p>
     * .
     *
     * @return possuiPermissaoPainelContratoNaoParametrizado
     */
    public Boolean getPossuiPermissaoPainelContratoNaoParametrizado() {
        if (this.possuiPermissaoPainelContratoNaoParametrizado == null) {
            this.possuiPermissaoPainelContratoNaoParametrizado = UsuarioUtil
                    .contemFuncionalidade(NoFuncionalidadeEnum.PAINEL_CONTRATO_NAO_PARAMETRIZADO.getNoFuncionalidade());
        }
        return this.possuiPermissaoPainelContratoNaoParametrizado;
    }

    /**
     * <p>
     * Retorna o valor do atributo possuiPermissaoPainelNovoContrato (p_novos_contratos)
     * </p>
     * .
     *
     * @return possuiPermissaoPainelNovoContrato
     */
    public Boolean getPossuiPermissaoPainelNovoContrato() {
        if (this.possuiPermissaoPainelNovoContrato == null) {
            this.possuiPermissaoPainelNovoContrato = UsuarioUtil
                    .contemFuncionalidade(NoFuncionalidadeEnum.PAINEL_NOVO_CONTRATO.getNoFuncionalidade());
        }
        return this.possuiPermissaoPainelNovoContrato;
    }

    /**
     * <p>
     * Retorna o valor do atributo possuiPermissaoConsultaContratoParametrizado (consulta_contrato_param)
     * </p>
     * .
     *
     * @return possuiPermissaoConsultaContratoParametrizado
     */
    public Boolean getPossuiPermissaoConsultaContratoParametrizado() {
        if (this.possuiPermissaoConsultaContratoParametrizado == null) {
            this.possuiPermissaoConsultaContratoParametrizado = UsuarioUtil.contemFuncionalidade(NoFuncionalidadeEnum.CONSULTA_CONTRATO_PARAMETRIZADO
                    .getNoFuncionalidade());
        }
        return this.possuiPermissaoConsultaContratoParametrizado;
    }

    /**
     * <p>
     * Retorna o valor do atributo possuiPermissaoConsultaContratoNaoParametrizado (consulta_contrato_n_p)
     * </p>
     * .
     *
     * @return possuiPermissaoConsultaContratoNaoParametrizado
     */
    public Boolean getPossuiPermissaoConsultaContratoNaoParametrizado() {
        if (this.possuiPermissaoConsultaContratoNaoParametrizado == null) {
            this.possuiPermissaoConsultaContratoNaoParametrizado = UsuarioUtil
                    .contemFuncionalidade(NoFuncionalidadeEnum.CONSULTA_CONTRATO_NAO_PARAMETRIZADO.getNoFuncionalidade());
        }
        return this.possuiPermissaoConsultaContratoNaoParametrizado;
    }

    /**
     * <p>
     * Retorna o valor do atributo possuiPermissaoConsultaContratoNaoParametrizadoManual (consulta_contrato_n_p_m)
     * </p>
     * .
     *
     * @return possuiPermissaoConsultaContratoNaoParametrizadoManual
     */
    public Boolean getPossuiPermissaoConsultaContratoNaoParametrizadoManual() {
        if (this.possuiPermissaoConsultaContratoNaoParametrizadoManual == null) {
            this.possuiPermissaoConsultaContratoNaoParametrizadoManual = UsuarioUtil
                    .contemFuncionalidade(NoFuncionalidadeEnum.CONSULTA_CONTRATO_NAO_PARAMETRIZADO_MANUAL.getNoFuncionalidade());
        }
        return this.possuiPermissaoConsultaContratoNaoParametrizadoManual;
    }

    /**
     * <p>
     * Retorna o valor do atributo possuiPermissaoPainelGarantiaConstituidaSatisfatorio (p_gar_const_satisfatoria)
     * </p>
     * .
     *
     * @return possuiPermissaoPainelGarantiaConstituidaSatisfatorio
     */
    public Boolean getPossuiPermissaoPainelGarantiaConstituidaSatisfatorio() {
        if (this.possuiPermissaoPainelGarantiaConstituidaSatisfatorio == null) {
            this.possuiPermissaoPainelGarantiaConstituidaSatisfatorio = UsuarioUtil
                    .contemFuncionalidade(NoFuncionalidadeEnum.PAINEL_GARANTIA_CONSTITUIDA_SATISFATORIO.getNoFuncionalidade());
        }
        return this.possuiPermissaoPainelGarantiaConstituidaSatisfatorio;
    }

    /**
     * <p>
     * Retorna o valor do atributo possuiPermissaoPainelGarantiaConstituidaMediana (p_gar_const_mediana)
     * </p>
     * .
     *
     * @return possuiPermissaoPainelGarantiaConstituidaMediana
     */
    public Boolean getPossuiPermissaoPainelGarantiaConstituidaMediana() {
        if (this.possuiPermissaoPainelGarantiaConstituidaSatisfatorio == null) {
            this.possuiPermissaoPainelGarantiaConstituidaSatisfatorio = UsuarioUtil
                    .contemFuncionalidade(NoFuncionalidadeEnum.PAINEL_GARANTIA_CONSTITUIDA_MEDIANA.getNoFuncionalidade());
        }
        return this.possuiPermissaoPainelGarantiaConstituidaMediana;
    }

    /**
     * <p>
     * Retorna o valor do atributo possuiPermissaoPainelGarantiaConstituidaInsatisfatorio (p_gar_const_insatisf)
     * </p>
     * .
     *
     * @return possuiPermissaoPainelGarantiaConstituidaInsatisfatorio
     */
    public Boolean getPossuiPermissaoPainelGarantiaConstituidaInsatisfatorio() {
        if (this.possuiPermissaoPainelGarantiaConstituidaInsatisfatorio == null) {
            this.possuiPermissaoPainelGarantiaConstituidaInsatisfatorio = UsuarioUtil
                    .contemFuncionalidade(NoFuncionalidadeEnum.PAINEL_GARANTIA_CONSTITUIDA_INSATISFATORIO.getNoFuncionalidade());
        }
        return this.possuiPermissaoPainelGarantiaConstituidaInsatisfatorio;
    }

    /**
     * <p>
     * Retorna o valor do atributo possuiPermissaoPainelGarantiaSiacgNaoAcompanha (p_garantia_nao_acompanha)
     * </p>
     * .
     *
     * @return possuiPermissaoPainelGarantiaSiacgNaoAcompanha
     */
    public Boolean getPossuiPermissaoPainelGarantiaSiacgNaoAcompanha() {
        if (this.possuiPermissaoPainelGarantiaSiacgNaoAcompanha == null) {
            this.possuiPermissaoPainelGarantiaSiacgNaoAcompanha = UsuarioUtil
                    .contemFuncionalidade(NoFuncionalidadeEnum.PAINEL_GARANTIA_SIACG_NAO_ACOMPANHA.getNoFuncionalidade());
        }
        return this.possuiPermissaoPainelGarantiaSiacgNaoAcompanha;
    }

    /**
     * <p>Retorna o valor do atributo podeEmitirRelatorioGerencias</p>.
     *
     * @return podeEmitirRelatorioGerencias
     */
    public Boolean getPodeEmitirRelatorioGerencias() {

        if (this.podeEmitirRelatorioGerencias == null) {
            this.podeEmitirRelatorioGerencias = UsuarioUtil
                    .contemFuncionalidade(NoFuncionalidadeEnum.RELAORIO_GERENCIAIS.getNoFuncionalidade());
        }
        return this.podeEmitirRelatorioGerencias;
    }

    /**
     * <p>Retorna o valor do atributo podeManterGarantia  (mantem_garantia)</p>.
     *
     * @return podeManterGarantia
     */
    public Boolean getPodeManterGarantia() {
        if (this.podeManterGarantia == null) {
            this.podeManterGarantia = UsuarioUtil
                    .contemFuncionalidade(NoFuncionalidadeEnum.MANTEM_GARANTIA.getNoFuncionalidade());
        }
        return this.podeManterGarantia;
    }

    /**
     * <p>Retorna o valor do atributo podeConsultarLogAuditoria (consulta_log_auditoria)</p>.
     *
     * @return podeConsultarLogAuditoria
     */
    public Boolean getPodeConsultarLogAuditoria() {
        if (this.podeConsultarLogAuditoria == null) {
            this.podeConsultarLogAuditoria = UsuarioUtil
                    .contemFuncionalidade(NoFuncionalidadeEnum.CONSULTA_LOG_AUDITORIA.getNoFuncionalidade());
        }
        return this.podeConsultarLogAuditoria;
    }
    
    /**
     * <p>Retorna o valor do atributo podeManterFaturamento (mantem_valor_faturamento)</p>.
     *
     * @return podeManterFaturamento
     */
    public Boolean getPodeManterFaturamento() {
        if (this.podeManterFaturamento == null) {
            this.podeManterFaturamento = UsuarioUtil
                    .contemFuncionalidade(NoFuncionalidadeEnum.MANTEM_VALOR_FATURAMENTO.getNoFuncionalidade());
        }
        return this.podeManterFaturamento;
    }

    /**
     * <p>Retorna o valor do atributo podeEmitirExcessoRelatorio (relatorio_excesso_garantia)</p>.
     *
     * @return podeEmitirExcessoRelatorio
     */
    public Boolean getPodeEmitirRelatorioExcessoGarantia() {
        if (this.podeEmitirRelatorioExcessoGarantia == null) {
            this.podeEmitirRelatorioExcessoGarantia = UsuarioUtil
                    .contemFuncionalidade(NoFuncionalidadeEnum.RELATORIO_EXCESSO_GARANTIA.getNoFuncionalidade());
        }
        return this.podeEmitirRelatorioExcessoGarantia;
    }

    /**
     * <p>Retorna o valor do atributo podeEmitirRelatorioPainelGarantias (rel_painel_garantias)</p>.
     *
     * @return podeEmitirRelatorioPainelGarantias
     */
    public Boolean getPodeEmitirRelatorioPainelGarantias() {
        if (this.podeEmitirRelatorioPainelGarantias == null) {
            this.podeEmitirRelatorioPainelGarantias = UsuarioUtil
                    .contemFuncionalidade(NoFuncionalidadeEnum.RELATORIO_PAINEL_GARANTIA.getNoFuncionalidade());
        }
        return this.podeEmitirRelatorioPainelGarantias;
    }

    /**
     * <p>Retorna o valor do atributo possuiPermissaoFiltrarSegmentoPainel (filtra_segmento_painel).</p>.
     *
     * @return possuiPermissaoFiltrarSegmentoPainel
     */
    public Boolean getPossuiPermissaoFiltrarSegmentoPainel() {
        if (this.possuiPermissaoFiltrarSegmentoPainel == null) {
            this.possuiPermissaoFiltrarSegmentoPainel = UsuarioUtil
                    .contemFuncionalidade(NoFuncionalidadeEnum.FILTRA_SEGMENTO_PAINEL.getNoFuncionalidade());
        }
        return this.possuiPermissaoFiltrarSegmentoPainel;
    }

    /**
     * <p>Retorna o valor do atributo podeConsultarDadosInterface (consulta_dados_interface).</p>.
     *
     * @return podeConsultarDadosInterface
     */
    public Boolean getPodeConsultarDadosInterface() {
        if (this.podeConsultarDadosInterface == null) {
            this.podeConsultarDadosInterface = UsuarioUtil
                    .contemFuncionalidade(NoFuncionalidadeEnum.CONSULTA_DADOS_INTERFACE.getNoFuncionalidade());
        }
        return this.podeConsultarDadosInterface;
    }

    /**
     * <p>Retorna o valor do atributo podeManterGarantiaProduto (garantia_produto).</p>.
     *
     * @return podeManterGarantiaProduto
     */
    public Boolean getPodeManterGarantiaProduto() {
    	if (this.podeManterGarantiaProduto == null) {
            this.podeManterGarantiaProduto = UsuarioUtil
                    .contemFuncionalidade(NoFuncionalidadeEnum.GARANTIA_PRODUTO.getNoFuncionalidade());
        }
		return podeManterGarantiaProduto; 
	}

    /**
     * <p>Retorna o valor do atributo podeManterTitulo (titulo).</p>.
     *
     * @return podeManterTitulo
     */
    
	public Boolean getPodeManterTitulo() {
		if (this.podeManterTitulo == null) {
	        this.podeManterTitulo = UsuarioUtil
	                .contemFuncionalidade(NoFuncionalidadeEnum.CONSULTA_TITULO.getNoFuncionalidade());
	      }
		return  this.podeManterTitulo; 
	}

	    /**
     * <p>Retorna o valor do atributo podeManterAplicacaoFinanaceira</p>.
     *
     * @return podeManterAplicacaoFinanaceira
    */
    public Boolean getPodeManterAplicacaoFinanaceira() {
		if(this.podeManterAplicacaoFinanaceira == null) {
		    this.podeManterAplicacaoFinanaceira =  UsuarioUtil.contemFuncionalidade(NoFuncionalidadeEnum.CONSULTA_APLICACAO_FINANC.getNoFuncionalidade());
		}
		return this.podeManterAplicacaoFinanaceira; 
    }

    /**
     * <p>Retorna o valor do atributo podeEmitirRelatorioAppFinanceirasBloqueadas</p>.
     *
     * @return podeEmitirRelatorioAppFinanceirasBloqueadas
     */
    public Boolean getPodeEmitirRelatorioAppFinanceirasBloqueadas() {
    	if(this.podeEmitirRelatorioAppFinanceirasBloqueadas == null) {
		    this.podeEmitirRelatorioAppFinanceirasBloqueadas = UsuarioUtil.contemFuncionalidade(NoFuncionalidadeEnum.RELATORIO_APLICACOES_FINANCEIRAS_BLOQUEADAS.getNoFuncionalidade());
		}
		return this.podeEmitirRelatorioAppFinanceirasBloqueadas; 

    }
    
    /**
     * <p>Retorna o valor do atributo podeEmitirRelatoriosFrenteHabitacional</p>.
     *
     * @return podeEmitirRelatoriosFrenteHabitacional
     */
    public Boolean getPodeEmitirRelatoriosFrenteHabitacional() {
    	if(this.podeEmitirRelatoriosFrenteHabitacional == null) {
		    this.podeEmitirRelatoriosFrenteHabitacional = UsuarioUtil.contemFuncionalidade(NoFuncionalidadeEnum.RELATORIO_FRENTE_HABITACIONAL.getNoFuncionalidade());
		}
		return this.podeEmitirRelatoriosFrenteHabitacional; 

    }

    public Boolean getPodeEmitirRelatorioConciliacao() {
	if(this.podeEmitirRelatorioConciliacao == null) {
	    this.podeEmitirRelatorioConciliacao = UsuarioUtil.contemFuncionalidade(NoFuncionalidadeEnum.RELATORIO_CONCILIACAO.getNoFuncionalidade());
	}
	return this.podeEmitirRelatorioConciliacao; 
    }
    
    
    public Boolean getPodeEmitirRelatorioApetiteRiscoApos2018() {
		if(this.podeEmitirRelatorioApetiteRiscoApos2018 == null) {
		    this.podeEmitirRelatorioApetiteRiscoApos2018 = UsuarioUtil.contemFuncionalidade(NoFuncionalidadeEnum.RELATORIO_APETITE_RISCO.getNoFuncionalidade());
		}
		return this.podeEmitirRelatorioApetiteRiscoApos2018; 
    }

    /**
     * <p>Retorna o valor do atributo podeConsultarFornecedor</p>.
     *
     * @return podeConsultarFornecedor
    */
    public Boolean getPodeManterFornecedor() {
	if(this.podeConsultarFornecedor == null) {
	    this.podeConsultarFornecedor = UsuarioUtil.contemFuncionalidade(NoFuncionalidadeEnum.MANTEM_FORNECEDOR.getNoFuncionalidade());
	}
	return this.podeConsultarFornecedor;
    }

    /**
     * 
     * <p>Método responsável por</p>.
     *
     * @author Wisnton
     *
     * @return podeConsultarDespesa;
     */
    public Boolean getPodeManterDespesa() {
	if(this.podeConsultarDespesa == null) {
	    this.podeConsultarDespesa = UsuarioUtil.contemFuncionalidade(NoFuncionalidadeEnum.MANTEM_DESPESA.getNoFuncionalidade());
	}
	return this.podeConsultarDespesa;
    }

    /**
     * <p>Define o valor do atributo podeConsultarDespesa</p>.
     *
     * @param podeConsultarDespesa valor a ser atribuído
    */
    public void setPodeConsultarDespesa(Boolean podeConsultarDespesa) {
	this.podeConsultarDespesa = podeConsultarDespesa;
    }
    
    public Boolean getPodeEmitirRelatorioApetiteRiscoAte2018() {
 		if(this.podeEmitirRelatorioApetiteRiscoAte2018 == null) {
 		    this.podeEmitirRelatorioApetiteRiscoAte2018 = UsuarioUtil.contemFuncionalidade(NoFuncionalidadeEnum.RELATORIO_APETITE_RISCO_ATE_2018.getNoFuncionalidade());
 		}
 		return this.podeEmitirRelatorioApetiteRiscoAte2018; 
     }
    

    /**
     * <p>
     * Retorna o valor do atributo podeManterRemetentes (manter_remetente_parametrz)
     * </p>
     * .
     *
     * @return podeManterRemetentes
     */
    public Boolean getPodeManterRemetentes() {
        if (this.podeManterRemetentes == null) {
            this.podeManterRemetentes = UsuarioUtil.contemFuncionalidade(NoFuncionalidadeEnum.MANTEM_DESTINATARIOS.getNoFuncionalidade());
        }
        return this.podeManterRemetentes;
    }
    
    /**
     * <p>Retorna o valor do atributo podeManterPortes</p>.
     *
     * @return podeManterPortes
     */
    public Boolean getPodeManterPortes() {
    	if (this.podeManterPortes == null) {
    		this.podeManterPortes = UsuarioUtil.contemFuncionalidade(NoFuncionalidadeEnum.MANTEM_PORTES.getNoFuncionalidade());
    	}
    	return this.podeManterPortes;
    }

	/**
	 * <p>Retorna o valor do atributo podeManterBandeiraCartao</p>.
	 *
	 * @return podeManterBandeiraCartao
	*/
	public Boolean getPodeManterBandeiraCartao() {
		if (this.podeManterBandeiraCartao == null) {
            this.podeManterBandeiraCartao = UsuarioUtil.contemFuncionalidade(NoFuncionalidadeEnum.MANTEM_BANDEIRA_CARTAO.getNoFuncionalidade());
        }
		
		return this.podeManterBandeiraCartao;
	}
	
	public Boolean getPodeManterProspecto() {
		if (this.podeManterProspecto == null) {
            this.podeManterProspecto = UsuarioUtil.contemFuncionalidade(NoFuncionalidadeEnum.MANTEM_PROSPECTO.getNoFuncionalidade());
        }
		
		return this.podeManterProspecto;
	}
	
	public Boolean getPodeManterBemCliente() {
		if (this.podeManterBemCliente == null) {
			this.podeManterBemCliente = UsuarioUtil.contemFuncionalidade(NoFuncionalidadeEnum.MANTEM_BEM_CLIENTE.getNoFuncionalidade());
		}
		
		return this.podeManterBemCliente;
	}
	
	public Boolean getPodeManterRedeVarejo() {
		if (this.podeManterRedeVarejo == null) {
			this.podeManterRedeVarejo = UsuarioUtil.contemFuncionalidade(NoFuncionalidadeEnum.MANTEM_REDE_VAREJO.getNoFuncionalidade());
		}
		
		return this.podeManterRedeVarejo;
	}
	
	public Boolean getPodeAcompanharImovel() {
		if (this.podeAcompanharImovel == null) {
			this.podeAcompanharImovel = UsuarioUtil.contemFuncionalidade(NoFuncionalidadeEnum.ACOMPANHAMENTO_IMOVEL.getNoFuncionalidade());
		}
		
		return this.podeAcompanharImovel;
	}
	
    public Boolean getPodeRealizarLeilao() {
	if (this.podeRealizarLeilao == null) {
	    this.podeRealizarLeilao = UsuarioUtil.contemFuncionalidade(NoFuncionalidadeEnum.REALIZACAO_DE_LEILAO.getNoFuncionalidade());
	}

	return Boolean.TRUE;
	// this.podeRealizarLeilao;
    }

	public Boolean getPodeManterServentia() {
		if (this.podeManterServentia == null) {
			this.podeManterServentia = UsuarioUtil.contemFuncionalidade(NoFuncionalidadeEnum.GESTAO_SERVENTIA.getNoFuncionalidade());
		}
		
		return this.podeManterServentia;
	}
	
	public Boolean getPodeManterMenuCadastro() {
		if (podeManterMenuCadastro == null) {
			podeManterMenuCadastro = getPodePesquisarcontrato() || getPodeManterBemCliente() || getPodeManterSubMenuExecucao();
		}
		
		return podeManterMenuCadastro;
	}
	
	public Boolean getPodeManterMenuConsulta() {
		if (podeManterMenuConsulta == null) {
			podeManterMenuConsulta = getPodeManterAplicacaoFinanaceira() || getPodeConsultarDadosInterface();
		}
		
		return podeManterMenuConsulta;
	}
	
	public Boolean getPodeManterSubMenuExecucao() {
		if (podeManterSubMenuExecucao == null) {
			podeManterSubMenuExecucao = getPodeManterFornecedor() || getPodeManterDespesa() || getPodeAcompanharImovel();
		}
		
		return podeManterSubMenuExecucao;
	}
	
	public Boolean getPodeManterMenuManutencao() {
		if (podeManterMenuManutencao == null) {
			podeManterMenuManutencao = getPodeManterParametrosCalculo() || getPodeManterGarantia() || getPodeManterSacadoNaoAceito()
					 || getPodeManterGarantiaProduto() || getPodeManterServentia() || getPodeManterSubMenuMensageria()
					 || getPodeManterPortes() || getPodePesquisarcontrato();
		}
		
		return podeManterMenuManutencao;
	}
	
	public Boolean getPodeManterSubMenuMensageria() {
		if (podeManterSubMenuMensageria == null) {
			podeManterSubMenuMensageria = getPodeManterMensagemApresentacao() || getPodeManterDestinatarios() || getPodeManterRemetentes()
					 || getPodeManterTemplateMensageria();
		}
		
		return podeManterSubMenuMensageria;
	}
	
	public Boolean getPodeManterMenuRelatorio() {
		if (podeManterMenuRelatorio == null) {
			podeManterMenuRelatorio = getPodeManterTemplateMensageria() || getPossuiPermissaoEnviaNotificacaoManual()
					|| getPodeManterMenuRelatorioGerencial() || getPodeConsultarLogAuditoria() 
					|| getPodeVisualizarPainelDiario() || getPodeVisualizarPainelCarga();
		}
		
		return podeManterMenuRelatorio;
	}
	
	public Boolean getPodeManterMenuRelatorioGerencial() {
		if (podeManterMenuRelatorioGerencial == null) {
			podeManterMenuRelatorioGerencial = getPodeEmitirRelatorioGerencias() || getPodeEmitirRelatoriosFrenteHabitacional();
		}
		
		return podeManterMenuRelatorioGerencial;
	}
	
	public Boolean getPodeVisualizarPainelDiario() {
		if (podeVisualizarPainelDiario == null) {
			podeVisualizarPainelDiario = UsuarioUtil.contemFuncionalidade(NoFuncionalidadeEnum.VISUALIZAR_PAINEL_DIARIO.getNoFuncionalidade());
		}
		
		return podeVisualizarPainelDiario;
	}
	
	public Boolean getPodeVisualizarPainelCarga() {
		if (podeVisualizarPainelCarga == null) {
			podeVisualizarPainelCarga = UsuarioUtil.contemFuncionalidade(NoFuncionalidadeEnum.VISUALIZAR_PAINEL_CARGA.getNoFuncionalidade());
		}
		
		return podeVisualizarPainelCarga;
	}
	
	public Boolean getPodeRestringirOperacao() {
		if (podeRestringirOperacao == null) {
			podeRestringirOperacao = UsuarioUtil.contemFuncionalidade(NoFuncionalidadeEnum.RESTRINGIR_OPERACAO_NA_SUFICIENCIA.getNoFuncionalidade());
		}
		
		return podeRestringirOperacao;
	}
	
        /**
         * <p>
         * Retorna o valor do atributo podeAtualizarManualUsuario (atualizar_manual_usuario)
         * </p>
         * .
         *
         * @return podeAtualizarManualUsuario
         */
    public Boolean getPodeAtualizarManualUsuario() {
	if (this.podeAtualizarManualUsuario == null) {
	    this.podeAtualizarManualUsuario = UsuarioUtil.contemFuncionalidade(NoFuncionalidadeEnum.ATUALIZAR_MANUAL_USUARIO.getNoFuncionalidade());
	}
	return this.podeAtualizarManualUsuario;
    }

	/**
	 * <p>Retorna o valor do atributo podeAlterarTratamentoEspecial</p>.
	 *
	 * @return podeAlterarTratamentoEspecial
	*/
	public Boolean getPodeAlterarTratamentoEspecial() {
	    if(this.podeAlterarTratamentoEspecial == null) {
		this.podeAlterarTratamentoEspecial = UsuarioUtil.contemFuncionalidade(NoFuncionalidadeEnum.MANTER_TRATAMENTO_ESPECIAL.getNoFuncionalidade());
	    }
	    return this.podeAlterarTratamentoEspecial;
	}

	public Boolean getPodeManterBemClienteImovel() {
	    if(this.podeManterBemClienteImovel == null) {
		this.podeManterBemClienteImovel = UsuarioUtil.contemFuncionalidade(NoFuncionalidadeEnum.MANTER_BEM_CLIENTE_IMOVEL.getNoFuncionalidade());
	    }
	    return this.podeManterBemClienteImovel;
	}

	public Boolean getPodeManterBemClienteMaquina() {
	    if(this.podeManterBemClienteMaquina == null) {
		this.podeManterBemClienteMaquina = UsuarioUtil.contemFuncionalidade(NoFuncionalidadeEnum.MANTER_BEM_CLIENTE_MAQUINA.getNoFuncionalidade());
	    }
	    return this.podeManterBemClienteMaquina;
	}

	public Boolean getPodeManterBemClienteVeiculo() {
	    if(this.podeManterBemClienteVeiculo == null) {
		this.podeManterBemClienteVeiculo = UsuarioUtil.contemFuncionalidade(NoFuncionalidadeEnum.MANTER_BEM_CLIENTE_VEICULO.getNoFuncionalidade());
	    }
	    return this.podeManterBemClienteVeiculo;
	}
	
        public Boolean getPodeIncluirBemCliente() {
            if (this.podeIncluirBemCliente == null) {
        	   this.podeIncluirBemCliente = this.getPodeManterBemClienteImovel() || this.getPodeManterBemClienteMaquina()
        	    || this.getPodeManterBemClienteVeiculo();
            }
            return this.podeIncluirBemCliente;
        }
        
        public Boolean getPodeEditarExcluirBemCliente(final TipoBemEnum tipoBemEnum) {
            if(tipoBemEnum != null) {
        	
        	switch (tipoBemEnum) {
		case IMOVEL:
		    return this.getPodeManterBemClienteImovel();

		case MAQUINA_EQUIPAMENTO:
		    return this.getPodeManterBemClienteMaquina();
		    
		case VEICULO:
		    return this.getPodeManterBemClienteVeiculo();
		}
            }
            
            return false;
        }

	public Boolean getPodeCalcularValorImovel() {
	    if(this.podeCalcularValorImovel == null) {
		this.podeCalcularValorImovel = UsuarioUtil.contemFuncionalidade(NoFuncionalidadeEnum.MANTER_CALCULO_VALOR_IMOVEL.getNoFuncionalidade());
	    }
	    return this.podeCalcularValorImovel;
	}
	
    public Boolean getPodeSanarPendenciaLeilaoImovel() {
	if (this.podeSanarPendenciaLeilaoImovel == null) {
	    this.podeSanarPendenciaLeilaoImovel = UsuarioUtil
		    .contemFuncionalidade(NoFuncionalidadeEnum.MANTER_LEILAO_SANAR_PENDENCIA.getNoFuncionalidade());
	}
	return this.podeSanarPendenciaLeilaoImovel;
    }
    
    public Boolean getPodeAlterarSituacaoLeilaoParaExcluido() {
	if (this.podeAlterarSituacaoLeilaoParaExcluido == null) {
	    this.podeAlterarSituacaoLeilaoParaExcluido = UsuarioUtil
		    .contemFuncionalidade(NoFuncionalidadeEnum.MANTER_LEILAO_EXCLUIR_IMOVEL.getNoFuncionalidade());
	}
	return this.podeAlterarSituacaoLeilaoParaExcluido;
    }

    private Map<NoFuncionalidadeEnum, Boolean> mapExecutarAcaoDeLeilao;
    public Boolean getPodeExecutarAcaoDeLeilao(NoFuncionalidadeEnum funcionalidadeEnum) {
	if (Objects.isNull(mapExecutarAcaoDeLeilao)) {
	    mapExecutarAcaoDeLeilao = new HashMap<>();
	}

	if (Objects.isNull(mapExecutarAcaoDeLeilao.get(funcionalidadeEnum))) {
	    Boolean podeExecutarAcaoDeLeilao = UsuarioUtil.contemFuncionalidade(funcionalidadeEnum.getNoFuncionalidade());
	    mapExecutarAcaoDeLeilao.put(funcionalidadeEnum, podeExecutarAcaoDeLeilao);
	}

	return mapExecutarAcaoDeLeilao.get(funcionalidadeEnum);
    }

}