/*
 * Copyright (c) 2016 Caixa Econômica Federal. Todos os direitos
 * reservados.
 *
 * Caixa Econômica Federal - SIACG
 *
 * Este software foi desenvolvido sob demanda da CAIXA e está
 * protegido por leis de direitos autorais e tratados internacionais. As
 * condições de cópia e utilização do todo ou partes dependem de autorização da
 * pessoa. Cópias não são permitidas sem expressa autorização. Não pode ser
 * comercializado ou utilizado para propósitos particulares.
 *
 * Uso exclusivo da Caixa Econômica Federal. A reprodução ou distribuição não
 * autorizada deste programa ou de parte dele, resultará em punições civis e
 * criminais e os infratores incorrem em sanções previstas na legislação em
 * vigor.
 *
 * Histórico do Subversion:
 *
 * LastChangedRevision: $Revision$
 * LastChangedBy: $Author$
 * LastChangedDate: $Date$
 *
 * HeadURL: $HeadURL$
 *
 */
package br.gov.caixa.siacg.funcionalidade;

import java.util.Collection;
import java.util.List;

import br.gov.caixa.pedesgo.arquitetura.to.TemplateMensageriaTO;
import br.gov.caixa.siacg.dao.OperacaoSistemaDAO;
import br.gov.caixa.siacg.model.vo.ContratoVO;
import br.gov.caixa.siacg.service.DestinatarioService;

/**
 * <p>
 * IFuncao.
 * </p>
 * <p>
 * Descrição: Classe abstrata que define o contrato que as funcoes devem seguir
 * no sistema
 * </p>
 * <br>
 * <b>Empresa:</b> Cef - Caixa Econômica Federal
 *
 * @author Bruno Martins de Carvalho
 * @version 1.0
 */
public abstract class IFuncionalidade {

    /**
     * <p>
     * Método responsável por obter o nome da funcao.
     * <p>
     *
     * @return String
     * @author Bruno Martins de Carvalho
     */
    public abstract String getNome();

    /**
     * <p>
     * Método responsável por obter o nome opcional da funcao.
     * <p>
     *
     * @return String
     * @author Bruno Martins de Carvalho
     */
    public abstract String getNomeOpcional();

    /**
     * <p>
     * Método responsável por obter a descricao da funcao.
     * <p>
     *
     * @return String
     * @author Bruno Martins de Carvalho
     */
    public abstract String getDescricao();

    /**
     * <p>
     * Método responsável por montar o template.
     * <p>
     *
     * @param templateMensageriaTO
     *            valor a ser atribuido
     * @return Collection<TemplateMensageriaTO>
     * @author Bruno Martins de Carvalho
     */
    public abstract Collection<TemplateMensageriaTO> traduzirTemplate(final TemplateMensageriaTO templateMensageriaTO);

    /**
     * <p>
     * Método responsável por substituir as tags em um texto informado.
     * <p>
     *
     * @param texto
     *            valor a ser atribuido
     * @param listaContrato
     *            valor a ser atribuido
     * @return String
     * @author Bruno Martins de Carvalho
     */
    public abstract String substituirTagTexto(String texto, final List<ContratoVO> listaContrato);

    /**
     * <p>
     * Método responsável por montar a grid de contratos.
     * <p>
     *
     * @param listaContrato
     *            valor a ser atribuido
     * @return String
     * @author Bruno Martins de Carvalho
     */
    public abstract String montarGridContratos(final Collection<ContratoVO> listaContrato);

    /**
     * Retorna o valor do atributo operacaoSistemaDAO.
     *
     * @return operacaoSistemaDAO
     */
    public abstract OperacaoSistemaDAO getOperacaoSistemaDAO();

    /**
     * Retorna o valor do atributo destinatarioService.
     *
     * @return destinatarioService
     */
    public abstract DestinatarioService getDestinatarioService();

}
