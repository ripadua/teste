/*
 * Copyright (c) 2018 Caixa Econômica Federal. Todos os direitos
 * reservados.
 *
 * Caixa Econômica Federal - SIACG
 *
 * Este software foi desenvolvido sob demanda da CAIXA e está
 * protegido por leis de direitos autorais e tratados internacionais. As
 * condições de cópia e utilização do total ou partes dependem de autorização da
 * empresa. Cópias não são permitidas sem expressa autorização. Não pode ser
 * comercializado ou utilizado para propósitos particulares.
 *
 * Uso exclusivo da Caixa Econômica Federal. A reprodução ou distribuição não
 * autorizada deste programa ou de parte dele, resultará em punições civis e
 * criminais e os infratores incorrem em sanções previstas na legislação em
 * vigor.
 *
 * Histórico do Subversion:
 *
 * LastChangedRevision: $Revision$
 * LastChangedBy: $Author$
 * LastChangedDate: $Date$
 *
 * HeadURL: $HeadURL$
 *
 */
package br.gov.caixa.siacg.util;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStreamWriter;
import java.nio.charset.Charset;
import java.nio.file.Files;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

import org.apache.commons.collections.CollectionUtils;
import org.apache.log4j.Logger;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.Font;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;

import br.gov.caixa.pedesgo.arquitetura.util.LogCefUtil;
import br.gov.caixa.siacg.commons.AppConstant;
import br.gov.caixa.siacg.model.vo.UserOnlineVO;

/**
 * <p>
 * ArquivoUtil
 * </p>
 * <p>
 * Descrição: Classe utilitária de Arquivo
 * </p>
 * <br>
 * <b>Empresa:</b> Cef - Caixa Econômica Federal
 *
 * @author douglas.lopes
 * @version 1.0
 */
public class ArquivoUtil {

    /** Atributo MAX_LINHAS_PLANILHA. */
    private static final int MAX_LINHAS_PLANILHA = 65536;
    private static final Logger LOG = Logger.getLogger(ArquivoUtil.class);

    private ArquivoUtil() {
	super();
    }

    public static String verificaBarraFinalCaminho(String path) {
	if (path.charAt(path.length() - 1) != '/') {
	    return path += File.separatorChar;
	}
	return path;
    }

    public static List<String> arquivoToString(String path) throws IOException {
	List<String> retorno = new ArrayList<>();
	try {
	    retorno = Files.readAllLines(new File(path).toPath(), Charset.forName("UTF-8"));
	} catch (IOException e) {
	    LOG.error("Erro ao ler arquivo. Detalhes: ");
	    LOG.error(e);
	    throw e;
	}

	return retorno;

    }

    @SuppressWarnings("unchecked")
    public static <T extends Object> T obterValor(String fileStr, Integer posicaoInicial, Integer posicaoFinal, Class<T> type) {
	if (type.isAssignableFrom(Integer.class)) {
	    return (T) obterInteiro(fileStr, posicaoInicial, posicaoFinal);
	} else if (type.isAssignableFrom(String.class)) {
	    return (T) obterString(fileStr, posicaoInicial, posicaoFinal);
	} else if (type.isAssignableFrom(Long.class)) {
	    return (T) obterLong(fileStr, posicaoInicial, posicaoFinal);
	}
	return null;
    }

    private static Integer obterInteiro(String fileStr, Integer posicaoInicial, Integer posicaoFinal) {
	try {
	    return new Integer(fileStr.substring(posicaoInicial, posicaoFinal).trim());
	} catch (NumberFormatException e) {
	    LogCEF.info("Não foi possível converter o valor do arquivo em um número. Posição Inicial: " + posicaoInicial + " Posição Final:"
		    + posicaoFinal);
	    return 0;
	}
    }

    private static Long obterLong(String fileStr, Integer posicaoInicial, Integer posicaoFinal) {
	try {
	    return new Long(fileStr.substring(posicaoInicial, posicaoFinal).trim());
	} catch (NumberFormatException e) {
	    return 0L;
	}
    }

    private static String obterString(String fileStr, Integer posicaoInicial, Integer posicaoFinal) {
	return String.valueOf(fileStr.substring(posicaoInicial, posicaoFinal));
    }

    /**
     * <p>
     * Método responsável por criar um File com o nome e a lista de objetos
     * informados. A montagem do arquivo é feita considerando o formato csv.
     * </p>
     *
     * @author f734546
     *
     * @param listObject
     * @param listCabecalho
     * @param nameFile
     * @return
     */
    public static File getFileCSV(final List<Object[]> listObject, final List<String> listCabecalho, final String nameFile) {

	File file = new File(nameFile != null ? nameFile : "");

	try (FileOutputStream fos = new FileOutputStream(file); OutputStreamWriter write = new OutputStreamWriter(fos, "UTF-8");) {
	    final byte[] enc = new byte[] { (byte) 0xEF, (byte) 0xBB, (byte) 0xBF };
	    fos.write(enc);

	    final StringBuilder relatorio = new StringBuilder();

	    relatorio.append(getCabecalhoFile(listCabecalho));
	    relatorio.append(getConteudoFile(listObject));

	    write.write(relatorio.toString());
	    write.flush();

	} catch (IOException e) {
	    LogCefUtil.error("Não foi possivel gerar o arquivo: " + e.getCause());
	    LogCefUtil.error(e);
	}

	return file;
    }

    /**
     * <p>
     * Método responsável por montar o cabeçaho de um arquivo com a
     * listCabecalho informada.
     * </p>
     *
     * @author f734546
     *
     * @param listCabecalho
     * @return
     */
    public static String getCabecalhoFile(final List<String> listCabecalho) {

	final StringBuilder cabecalho = new StringBuilder();

	if (!CollectionUtils.isEmpty(listCabecalho)) {

	    for (String nomeColuna : listCabecalho) {
		cabecalho.append(nomeColuna);
		cabecalho.append(AppConstant.DELIMITADOR);
	    }

	    cabecalho.append(AppConstant.QUEBRALINHA);
	}

	return cabecalho.toString();
    }

    /**
     * <p>
     * Método responsável por montar o conteúdo de um arquivo com a listObjeto
     * informada.
     * </p>
     *
     * @author f734546
     *
     * @param listObject
     * @return
     */
    public static String getConteudoFile(List<Object[]> listObject) {

	final StringBuilder conteudo = new StringBuilder();

	if (CollectionUtils.isNotEmpty(listObject)) {

	    for (Object[] objeto : listObject) {

		if (objeto != null && objeto.length > 0) {

		    addConteudo(conteudo, objeto);

		    conteudo.append(AppConstant.QUEBRALINHA);
		}
	    }
	}

	return conteudo.toString();
    }

    private static void addConteudo(final StringBuilder conteudo, Object[] objeto) {
	for (int i = 0; i < objeto.length; i++) {
	    final Object valor = objeto[i];
	    conteudo.append(valor != null ? valor.toString() : "");
	    conteudo.append(AppConstant.DELIMITADOR);
	}
    }

    /**
     * <p>
     * Método responsável por gerar byte do arquivo informado.
     * </p>
     *
     * @author f734546
     *
     * @param file
     * @return
     */
    public static byte[] getByteFile(final File file) {

	byte[] byteFile = null;

	if (file != null) {

	    try (InputStream inputStream = new FileInputStream(file)) {

		byteFile = new byte[(int) file.length()];

		inputStream.read(byteFile, 0, byteFile.length);

	    } catch (final Exception e) {
		LogCefUtil.error("Não foi possivel obter byte do arquivo: " + e.getMessage());
		LogCefUtil.error(e);
	    }
	}

	return byteFile;
    }

    /**
     * <p>
     * Método responsável por adicionar conteudo ao objeto Workbook, em uma aba
     * com o nameSheet informado.
     * </p>
     *
     * @author f734546
     *
     * @param workbook
     *            Objeto para armazenar o conteudo
     * @param nameSheet
     *            nome da folha/ aba do arquivo
     * @param listCabecalho
     *            Cabecalho a ser apresentado no arquivo
     * @param listObject
     *            Conteudo a ser apresentado no arquivo
     * @return
     */
    public static void writeWorkbook(final Workbook workbook, final String nameSheet, final List<String> listCabecalho,
	    final List<Object[]> listObject) {
	if (workbook == null) {
	    return;
	}

	File file = new File(nameSheet != null ? nameSheet : "");

	try (FileOutputStream fos = new FileOutputStream(file);) {
	    final byte[] enc = new byte[] { (byte) 0xEF, (byte) 0xBB, (byte) 0xBF };
	    fos.write(enc);

	    montaWorkbook(workbook, nameSheet, listObject, listCabecalho);

	    workbook.write(fos);

	} catch (IOException e) {
	    LogCefUtil.error("Nao foi possivel escrever no arquivo: " + e.getCause());
	    LogCefUtil.error(e);
	}
    }

    /**
     * <p>
     * Método responsável por adicionar conteudo ao objeto Workbook, em uma aba
     * com o nameSheet informado.
     * </p>
     *
     * @author f734546
     *
     * @param workbook
     *            Objeto para armazenar o conteudo
     * @param nameSheet
     *            nome da folha/ aba do arquivo
     * @param listCabecalho
     *            Cabecalho a ser apresentado no arquivo
     * @param listUsers
     *            Conteudo a ser apresentado no arquivo
     * @return
     */
    public static void writeWorkbook(final Workbook workbook, final String nameSheet, final List<String> listCabecalho,
	    final Collection<UserOnlineVO> listUsers) {
	if (workbook == null) {
	    return;
	}

	Sheet sheet = workbook.createSheet(nameSheet);

	File file = new File(nameSheet != null ? nameSheet : "");

	try (FileOutputStream fos = new FileOutputStream(file);) {
	    final byte[] enc = new byte[] { (byte) 0xEF, (byte) 0xBB, (byte) 0xBF };
	    fos.write(enc);

	    getCabecalhoWorkbook(workbook, sheet, listCabecalho);

	    montaWorkbook(sheet, listUsers);

	    workbook.write(fos);

	} catch (IOException e) {
	    LogCefUtil.error("Nao foi possivel escrever no arquivo: " + e.getCause());
	    LogCefUtil.error(e);
	}
    }

    private static void montaWorkbook(final Workbook workbook, final String nameSheet, final List<Object[]> listObject,
	    final List<String> listCabecalho) {

	Sheet sheet = workbook.createSheet(nameSheet);

	getCabecalhoWorkbook(workbook, sheet, listCabecalho);

	if (CollectionUtils.isNotEmpty(listObject)) {

	    int countSheet = 1;

	    // inicia na linha 1
	    int rownum = 1;
	    for (Object[] objeto : listObject) {

		// cria novo sheet
		if (rownum == ArquivoUtil.MAX_LINHAS_PLANILHA) {
		    rownum = 1;
		    sheet = workbook.createSheet(nameSheet + " _ " + ++countSheet);
		    getCabecalhoWorkbook(workbook, sheet, listCabecalho);
		}

		Row row = sheet.createRow(rownum++);

		for (int i = 0; i < objeto.length; i++) {
		    final Object valor = objeto[i];
		    Cell cell = row.createCell(i);
		    cell.setCellValue(valor != null ? valor.toString() : "");
		}
	    }
	}
    }

    private static void montaWorkbook(final Sheet sheet, final Collection<UserOnlineVO> listUsers) {

	if (CollectionUtils.isNotEmpty(listUsers)) {
	    // inicia na linha 1
	    int rownum = 1;
	    for (UserOnlineVO user : listUsers) {
		Row row = sheet.createRow(rownum++);

		Cell cellMatricula = row.createCell(0);
		cellMatricula.setCellValue(user.getDeMatricula());

		Cell cellSuv = row.createCell(1);
		cellSuv.setCellValue(user.getSuvUnidade());

		Cell cellSr = row.createCell(2);
		cellSr.setCellValue(user.getSrUnidade());

		Cell cellUn = row.createCell(3);
		cellUn.setCellValue(user.getNuUnidade());
	    }
	}
    }

    private static void getCabecalhoWorkbook(final Workbook workbook, final Sheet sheet, final List<String> listCabecalho) {
	final CellStyle style = getStyleNegrito(workbook);

	// linha 0
	final Row row = sheet.createRow(0);

	int cellnum = 0;
	for (String cabecalho : listCabecalho) {
	    Cell cell = row.createCell(cellnum++);
	    cell.setCellValue(cabecalho);
	    cell.setCellStyle(style);
	}
    }

    private static CellStyle getStyleNegrito(final Workbook workbook) {
	Font font = workbook.createFont();
	font.setBold(true);
	CellStyle style = workbook.createCellStyle();
	style.setFont(font);
	return style;
    }

    public static byte[] getByteWorkbook(final Workbook workbook) {
	byte[] wByte = null;

	if (workbook != null) {

	    try (ByteArrayOutputStream baos = new ByteArrayOutputStream();) {
		workbook.write(baos);
		wByte = baos.toByteArray();

	    } catch (IOException e) {
		LogCefUtil.error("Nao foi possivel gerar byte do objeto Workbook: " + e.getCause());
		LogCefUtil.error(e);

	    } finally {
		try {
		    workbook.close();
		} catch (IOException e) {
		    LogCefUtil.error("Erro ao fechar Workbook: " + e.getCause());
		    LogCefUtil.error(e);
		}
	    }
	}

	return wByte;
    }

}