package br.gov.caixa.siacg.view.form;

import java.util.ArrayList;
import java.util.Collection;

import br.gov.caixa.pedesgo.arquitetura.util.UtilObjeto;
import br.gov.caixa.siacg.model.domain.Cheque;
import br.gov.caixa.siacg.model.domain.Contrato;
import br.gov.caixa.siacg.model.vo.PessoaVO;

/**
 * <p>
 * DetalheChequeVisao
 * </p>
 * <p>
 * Descrição: Classe responsável por armazenar os dados da visão de detalhe de
 * cheques.
 * </p>
 * 
 * <b>Empresa:</b> Cef - Caixa Econômica Federal
 *
 * @author Caio Graco
 * @version 1.0
 */
public class DetalheChequeVisao extends TemplateVisao<Cheque> {

    private static final long serialVersionUID = 1L;

    private Collection<Cheque> listaChequeFiltrada;

    private Collection<Cheque> listaChequesUtilizados;

    private Collection<Cheque> listaChequesBackup;

    private String paginaOrigem;

    private transient PessoaVO pessoaVO;

    private Contrato contrato;

    private boolean mostrarChequesUtilizados;

    private boolean foraPrazoMinimo;

    private boolean foraPrazoMaximo;

    private boolean foraValorMaximo;

    /**
     * Retorna o valor do atributo paginaOrigem.
     *
     * @return paginaOrigem
     */
    public String getPaginaOrigem() {
        return this.paginaOrigem;
    }

    /**
     * Define o valor do atributo paginaOrigem.
     *
     * @param paginaOrigem
     *            valor a ser atribuído
     */
    public void setPaginaOrigem(final String paginaOrigem) {
        this.paginaOrigem = paginaOrigem;
    }

    /**
     * Retorna o valor do atributo pessoaVO.
     *
     * @return pessoaVO
     */
    public PessoaVO getPessoaVO() {
        return this.pessoaVO;
    }

    /**
     * Define o valor do atributo pessoaVO.
     *
     * @param pessoaVO
     *            valor a ser atribuído
     */
    public void setPessoaVO(final PessoaVO pessoaVO) {
        this.pessoaVO = pessoaVO;
    }

    /**
     * Retorna o valor do atributo listaChequeFiltrada.
     *
     * @return listaChequeFiltrada
     */
    public Collection<Cheque> getListaChequeFiltrada() {

        return this.listaChequeFiltrada;
    }

    /**
     * Define o valor do atributo listaChequeFiltrada.
     *
     * @param listaChequeFiltrada
     *            valor a ser atribuído
     */
    public void setListaChequeFiltrada(final Collection<Cheque> listaChequeFiltrada) {

        this.listaChequeFiltrada = listaChequeFiltrada;
    }

    /**
     * Retorna o valor do atributo contrato.
     *
     * @return contrato
     */
    public Contrato getContrato() {

        return this.contrato;
    }

    /**
     * Define o valor do atributo contrato.
     *
     * @param contrato
     *            valor a ser atribuído
     */
    public void setContrato(final Contrato contrato) {

        this.contrato = contrato;
    }

    /**
     * Retorna o valor do atributo mostrarChequesUtilizados.
     *
     * @return mostrarChequesUtilizados
     */
    public boolean isMostrarChequesUtilizados() {

        return this.mostrarChequesUtilizados;
    }

    /**
     * Define o valor do atributo mostrarChequesUtilizados.
     *
     * @param mostrarChequesUtilizados
     *            valor a ser atribuído
     */
    public void setMostrarChequesUtilizados(final boolean mostrarChequesUtilizados) {

        this.mostrarChequesUtilizados = mostrarChequesUtilizados;
    }

    /**
     * Retorna o valor do atributo foraPrazoMinimo.
     *
     * @return foraPrazoMinimo
     */
    public boolean isForaPrazoMinimo() {

        return this.foraPrazoMinimo;
    }

    /**
     * Define o valor do atributo foraPrazoMinimo.
     *
     * @param foraPrazoMinimo
     *            valor a ser atribuído
     */
    public void setForaPrazoMinimo(final boolean foraPrazoMinimo) {

        this.foraPrazoMinimo = foraPrazoMinimo;
    }

    /**
     * Retorna o valor do atributo foraPrazoMaximo.
     *
     * @return foraPrazoMaximo
     */
    public boolean isForaPrazoMaximo() {

        return this.foraPrazoMaximo;
    }

    /**
     * Define o valor do atributo foraPrazoMaximo.
     *
     * @param foraPrazoMaximo
     *            valor a ser atribuído
     */
    public void setForaPrazoMaximo(final boolean foraPrazoMaximo) {

        this.foraPrazoMaximo = foraPrazoMaximo;
    }

    /**
     * Retorna o valor do atributo foraValorMaximo.
     *
     * @return foraValorMaximo
     */
    public boolean isForaValorMaximo() {

        return this.foraValorMaximo;
    }

    /**
     * Define o valor do atributo foraValorMaximo.
     *
     * @param foraValorMaximo
     *            valor a ser atribuído
     */
    public void setForaValorMaximo(final boolean foraValorMaximo) {

        this.foraValorMaximo = foraValorMaximo;
    }

    /**
     * Retorna o valor do atributo listaChequesUtilizados.
     *
     * @return listaChequesUtilizados
     */
    public Collection<Cheque> getListaChequesUtilizados() {

        if (UtilObjeto.isVazio(this.listaChequesUtilizados)) {

            this.listaChequesUtilizados = new ArrayList<>();
        }

        return this.listaChequesUtilizados;
    }

    /**
     * Define o valor do atributo listaChequesUtilizados.
     *
     * @param listaChequesUtilizados
     *            valor a ser atribuído
     */
    public void setListaChequesUtilizados(final Collection<Cheque> listaChequesUtilizados) {

        this.listaChequesUtilizados = listaChequesUtilizados;
    }

    /**
     * Retorna o valor do atributo listaChequesBackup.
     *
     * @return listaChequesBackup
     */
    public Collection<Cheque> getListaChequesBackup() {

        if (UtilObjeto.isVazio(this.listaChequesBackup)) {

            this.listaChequesBackup = new ArrayList<>();
        }

        return this.listaChequesBackup;
    }

    /**
     * Define o valor do atributo listaChequesBackup.
     *
     * @param listaChequesBackup
     *            valor a ser atribuído
     */
    public void setListaChequesBackup(final Collection<Cheque> listaChequesBackup) {

        this.listaChequesBackup = listaChequesBackup;
    }

}