/*
 * Copyright (c) 2019 Caixa Econômica Federal. Todos os direitos
 * reservados.
 *
 * Caixa Econômica Federal - SIACG - Sistema de Crédito Rural
 *
 * Este software foi desenvolvido sob demanda da CAIXA e está
 * protegido por leis de direitos autorais e tratados internacionais. As
 * condições de cópia e utilização do todo ou partes dependem de autorização da
 * empresa. Cópias não são permitidas sem expressa autorização. Não pode ser
 * comercializado ou utilizado para propósitos particulares.
 *
 * Uso exclusivo da Caixa Econômica Federal. A reprodução ou distribuição não
 * autorizada deste programa ou de parte dele, resultará em punições civis e
 * criminais e os infratores incorrem em sanções previstas na legislação em
 * vigor.
 *
 * Histórico do TFS:
 *
 * LastChangedRevision: $Revision$
 * LastChangedBy: $Author$
 * LastChangedDate: $Date$
 *
 * HeadURL: $HeadURL$
 *
 */	
package br.gov.caixa.siacg.view.mb;

import java.util.ArrayList;
import java.util.Collection;

import javax.ejb.EJB;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;

import org.apache.commons.lang3.StringUtils;
import org.primefaces.context.RequestContext;

import br.gov.caixa.pedesgo.arquitetura.controlador.ManutencaoBean;
import br.gov.caixa.pedesgo.arquitetura.enumerador.EnumAcao;
import br.gov.caixa.pedesgo.arquitetura.siico.util.LogCefUtil;
import br.gov.caixa.pedesgo.arquitetura.to.MensagemTO;
import br.gov.caixa.pedesgo.arquitetura.util.MensagensUtil;
import br.gov.caixa.pedesgo.arquitetura.util.UsuarioUtil;
import br.gov.caixa.pedesgo.arquitetura.util.UtilString;
import br.gov.caixa.siacg.model.domain.Despesa;
import br.gov.caixa.siacg.model.domain.Fornecedor;
import br.gov.caixa.siacg.model.domain.Imovel;
import br.gov.caixa.siacg.model.domain.TipoDespesa;
import br.gov.caixa.siacg.model.domain.TipoFornecedor;
import br.gov.caixa.siacg.model.enums.NoFuncionalidadeEnum;
import br.gov.caixa.siacg.service.DespesaService;
import br.gov.caixa.siacg.service.FornecedorService;
import br.gov.caixa.siacg.service.GestaoServentiaService;
import br.gov.caixa.siacg.service.ImovelService;
import br.gov.caixa.siacg.service.TipoDespesaService;
import br.gov.caixa.siacg.service.TipoFornecedorService;
import br.gov.caixa.siacg.view.form.DespesaVisao;

/**
 * <p>DespesaMB</p>
 *
 * <p>Descrição: Descrição do tipo</p>
 *
 * <br><b>Empresa:</b> Cef - Caixa Econômica Federal
 *
 *
 * @author f799837
 *
 * @version 1.0
*/
@ManagedBean
@SessionScoped
public class DespesaMB extends ManutencaoBean<Despesa>{

    /** Atributo serialVersionUID. */
    private static final long serialVersionUID = 1L;

    /** Atributo PREFIXO_CASO_USO. */
    private static final String PREFIXO_CASO_USO = "despesa";

    /** Atributo NOME_MANAGED_BEAN. */
    public static final String NOME_MANAGED_BEAN = "despesaMB";

    /** Atributo EL_MANAGED_BEAN. */
    public static final String EL_MANAGED_BEAN = "#{despesaMB}";
    
    /** Atributo de Mensagem APP */
    private static final String MSG_APP = "msgApp";
    
    /** Atributo PAGINA_CONSULTA_CONTRATO. */
    private static final String PAGINA_CONSULTA_DESPESA = "/pages/execucao/despesa/consulta.xhtml?faces-redirect=true";

    /** Atributo PAGINA_INCLUSAO_CONTRATO. */
    private static final String PAGINA_INCLUSAO_DESPESA = "/pages/execucao/despesa/edicao.xhtml?faces-redirect=true";
    
    private static final Integer TIPO_FORNECEDOR = 1;
    private static final Integer TIPO_CARTORIO = 2;
    
    @EJB
    private transient DespesaService servico;
    
    @EJB
    private transient TipoDespesaService tipoDespesaServico;
    
    @EJB
    private transient TipoFornecedorService tipoFornecedorService;
    
    @EJB
    private transient FornecedorService fornecedorService;
    
    @EJB
    private transient ImovelService imovelService;
    
    @EJB
    private transient GestaoServentiaService gestaoServentiaService;
    
    private DespesaVisao visao;
    
    @Override
    protected String getPrefixoCasoDeUso() {
    	return DespesaMB.PREFIXO_CASO_USO;
    }

    @Override
    public void carregar() {
		this.visao = null;
		this.visao = this.getVisao();
		this.visao.getListaTipoDespesa().clear();
		this.visao.setIcPesquisaCartorio(Boolean.FALSE);
		this.visao.setIcPesquisaCidade(Boolean.FALSE);
		this.visao.getDespesa();
		this.visao.getTipoDespesa();
		this.visao.getDespesa().setIcTipoCredor(0);
		this.visao.getImovelSelecionado();
		this.visao.setListaFornecedores(new ArrayList<>(this.fornecedorService.listarFornecedores(true)));
		this.visao.setListaImovel(new ArrayList<>(this.imovelService.listar()));
		this.visao.setLista(new ArrayList<>(this.servico.listar()));
		
		this.carregarCombosInclusao();
    }
    
    private void carregarCombosInclusao() {
    	Integer id = this.getVisao().getDespesa().getNuCredor();
    	TipoFornecedor tipoFornecedor = this.tipoFornecedorService.obter(id);
    	if (tipoFornecedor != null) {
    		this.visao.setListaTipoDespesa(new ArrayList<>(this.tipoDespesaServico.listarPorTipoFornecedor(tipoFornecedor) ));
    	}
		this.visao.setListaUf(new ArrayList<>(this.gestaoServentiaService.listarTodasUF()));
		this.visao.setListaTipoFornecedores(new ArrayList<>(tipoFornecedorService.listar(true)));
		this.visao.setEventos(new ArrayList<>(this.tipoDespesaServico.listar(true)));
    }
    
    public void pesquisarImoveis() {
		this.visao =  this.getVisao();
		ArrayList<Imovel> listaImovel = new ArrayList<>(imovelService.listarImovelPorCodigoImovelOuCns(this.getVisao().getNuPesquisaImovel()));
		this.visao.setListaImovel(listaImovel);    
    }
    
    public void atualizaComboDeCidades() {
		this.visao = this.getVisao();
		this.visao.setIcPesquisaCidade(Boolean.TRUE);
		this.getVisao().setListaMunicipios( new ArrayList<>(this.gestaoServentiaService.listarMunicipiosPorUF(this.getVisao().getUfSelecionada())));
    }
    
    public void atualizaComboCartorio() {
		this.visao = this.getVisao();
		this.visao.setIcPesquisaCartorio(Boolean.TRUE);
		this.getVisao().setListaDeCartorios( new ArrayList<>(this.gestaoServentiaService.listarCartoriosPorMunicipio(this.getVisao().getMunicipioSelecionado())));
    }
    
    public String abrirConsulta() {
		this.carregar();
		this.restricaoAbrangencia();
		return DespesaMB.PAGINA_CONSULTA_DESPESA;
    }
    
    public String abrirAlteracao(final Despesa despesa) {    			
		final Despesa itemTemp = despesa;
		this.getVisao().setDespesa(itemTemp);
		this.getVisao().setTipoDespesa(itemTemp.getTipoDespesa());
		this.visao.setImovelSelecionado(itemTemp.getImovel());
		this.getVisao().getDespesa().setNuCredor(despesa.getNuCredor());
		
		this.selecionarImovel();
		Integer id = despesa.getNuCredor();
    	TipoFornecedor tipoFornecedor = this.tipoFornecedorService.obter(id);
    	if (tipoFornecedor != null){
    		this.visao.setListaTipoDespesa(new ArrayList<>(this.tipoDespesaServico.listarPorTipoFornecedor(tipoFornecedor)));
    	}		
		if (itemTemp.getIcTipoCredor().equals(TIPO_FORNECEDOR)) {
			this.getVisao().setFornecedor(itemTemp.getFornecedor());
		} else if (despesa.getIcTipoCredor().equals(TIPO_CARTORIO)) {
			this.getVisao().setIcPesquisaCidade(true);
			this.getVisao().setIcPesquisaCartorio(true);
			this.getVisao().setGestaoServentia(itemTemp.getGestaoServentia());
			this.getVisao().setUfSelecionada(itemTemp.getGestaoServentia().getSiglaUf());
			this.atualizaComboDeCidades();
			this.getVisao().setMunicipioSelecionado(itemTemp.getGestaoServentia().getDescricaoMunicipio());
			this.atualizaComboCartorio();
		}
		return DespesaMB.PAGINA_INCLUSAO_DESPESA;
    }
    
    private void restricaoAbrangencia() {
		if (UsuarioUtil.contemPermissao(NoFuncionalidadeEnum.PARAMETRIZA_CONTRATO.getNoFuncionalidade(), EnumAcao.INCLUIR.getNoAcao(), null, null)
			|| UsuarioUtil.contemPermissao(NoFuncionalidadeEnum.PARAMETRIZA_CONTRATO.getNoFuncionalidade(), EnumAcao.ALTERAR.getNoAcao(), null, null)) {
	
		    this.getVisao().setRestricaoAbangencia(true);
		}
    }
    
    public String abrirInclusao() {
        this.carregar();
        return DespesaMB.PAGINA_INCLUSAO_DESPESA;
    }
    
	public void excluirTipoDespesa() {
    	TipoDespesa tipoDespesa = this.getVisao().getTipoDespesaInativar();
    	if (tipoDespesa != null) {
    		try {
				this.tipoDespesaServico.remover(tipoDespesa);
				Integer id = this.getVisao().getDespesa().getNuCredor();
		    	TipoFornecedor tipoFornecedor = this.tipoFornecedorService.obter(id);
		    	if (tipoFornecedor!= null && tipoFornecedor.getNuTipoFornecedor() != null) {
		    		this.visao.setListaTipoDespesa(new ArrayList<>(this.tipoDespesaServico.listarPorTipoFornecedor(tipoFornecedor) ));
		    	} else {
		    		this.visao.setListaTipoDespesa(null);
		    		this.visao.getListaTipoDespesa();
		    	}
				this.visao.setListaTipoFornecedores(new ArrayList<>(tipoFornecedorService.listar(true)));
				this.visao.setEventos(new ArrayList<>(this.tipoDespesaServico.listar(true)));
				super.adicionaMensagemDeSucesso("Excluído com Sucesso");
			} catch (Exception e) {
				this.getVisao().setTipoDespesaInativar(null);
				MensagensUtil.adicionaMensagemDeAlerta(DespesaMB.MSG_APP, "Existem despesas lançadas para o tipo despesa selecionado", "");
				LogCefUtil.error("Erro ao excluir tipo despesa. Existem despesas lançadas para o tipo despesa selecionado");
				LogCefUtil.error(e);
			}
    	}
    }
    
    public void selecionarTipoFornecedor() {
    	Integer id = this.getVisao().getDespesa().getNuCredor();
    	TipoFornecedor tipoFornecedor = this.tipoFornecedorService.obter(id);
    	
		if (tipoFornecedor != null) {
			String noTipoFornecedor = tipoFornecedor.getNoTipoFornecedor().trim();
			boolean validacao = "CARTORIO".equals(noTipoFornecedor) || "CARTÓRIO".equals(noTipoFornecedor);
			
			this.visao.setListaTipoDespesa(new ArrayList<>(this.tipoDespesaServico.listarPorTipoFornecedor(tipoFornecedor) ));
			
			if (validacao) {
				this.getVisao().getDespesa().setIcTipoCredor(TIPO_CARTORIO);
			} else {
				this.getVisao().getDespesa().setIcTipoCredor(TIPO_FORNECEDOR);				
			}
		}
    }
    
    public void selecionarImovel() {
    	Integer id = this.getVisao().getImovelSelecionado().getNuImovel();
    	Imovel imovelTemp = this.imovelService.obter(id);
    	if (imovelTemp != null) {
    		this.getVisao().setImovelSelecionado(imovelTemp) ;
    	}
    }
    
    public void adicionarTipoDespesa() {
		this.visao = this.getVisao();
		final TipoDespesa tipoDespesa = prepararTipoDespesa(this.visao.getTipoDespesa());
		this.tipoDespesaServico.validarDados(tipoDespesa);
	
		if (tipoDespesa.hasMensagens()) {	
		    for (final MensagemTO mensagem : tipoDespesa.getMensagens()) {
		    	MensagensUtil.adicionaMensagemDeAlerta(DespesaMB.MSG_APP, mensagem.getChaveMensagem(), mensagem.getArgumentos());
		    }
		} else {
		    this.tipoDespesaServico.salvar(tipoDespesa);
		    this.visao.setTipoDespesa(new TipoDespesa());
		    this.visao.setTipoFornecedor(new TipoFornecedor());
		    this.carregarCombosInclusao();
		    this.visao.setTipoDespesa(new TipoDespesa());
		    RequestContext.getCurrentInstance().execute("PF('modalSucesso2').show();");
		}
    }

	private TipoDespesa prepararTipoDespesa(TipoDespesa tipoDespesa) {		
		TipoFornecedor tipoFornecedor = this.tipoFornecedorService.obter(this.visao.getTipoFornecedor().getNuTipoFornecedor());
		tipoDespesa.setTipoFornecedor(tipoFornecedor);
		String coEventoDespesa = StringUtils.leftPad(tipoDespesa.getCoEventoDespesa(), 5, "0");
		tipoDespesa.setCoEventoDespesa(coEventoDespesa);
		tipoDespesa.setCoTipoDespesa(coEventoDespesa.concat(tipoDespesa.getDvTipoDespesa().toString()));
		tipoDespesa.setNoTipoDespesa(UtilString.maiuscula(tipoDespesa.getNoTipoDespesa()));
		tipoDespesa.setIcSituacao(Boolean.TRUE);
		return tipoDespesa;
	}
	
	public void filtrar() {
		this.getVisao().setLista(this.servico.listarDespesaPorFiltros(this.getVisao().getEntidade()));
	}
  
	public void limparFiltro() {
		this.abrirConsulta();
	}

    public void salvarDespesa() {		
		Despesa despesa = this.visao.getDespesa();
		TipoDespesa tipoDespesa = this.tipoDespesaServico.obter(visao.getTipoDespesa().getNuTipoDespesa());
		
		if (despesa.getIcTipoCredor().equals(TIPO_FORNECEDOR)) {
			despesa.setFornecedor(visao.getFornecedor());
		} else {
			despesa.setGestaoServentia(visao.getGestaoServentia());
		}
		despesa.setTipoDespesa(tipoDespesa);
		despesa.setImovel(this.visao.getImovelSelecionado());
		this.servico.validarDados(despesa);
		
		if (despesa.hasMensagens()){
		    for (final MensagemTO mensagem : visao.getDespesa().getMensagens()){
		    	MensagensUtil.adicionaMensagemDeAlerta(DespesaMB.MSG_APP, mensagem.getChaveMensagem(), mensagem.getArgumentos());
		    }
		} else {			
		    this.servico.salvar(despesa);
		    RequestContext.getCurrentInstance().execute("PF('modalSucesso').show();");
		}
    }
    
    public Collection<Imovel>pesquisaImovelAutoComplete(final String codigo){
    	return this.imovelService.listarImovelAutoComplete(codigo);
    }   
    
    @SuppressWarnings("unchecked")
    @Override
    public DespesaService getService() {
    	return this.servico;
    }

    @Override
    public DespesaVisao getVisao() {
		if(visao == null ) {
		    this.visao = new DespesaVisao();
		    this.visao.getEntidade().setFornecedor(new Fornecedor());
		}
		return visao;
    }
    
    public static void main(String[] args) {
    	//StringUtils.leftPad(tmpNuContrato.substring(0, 4), TAMANHO_AGENCIA, "0");
    	String coTipoDespesa = StringUtils.leftPad("12", 5, "0");
    	System.out.println(coTipoDespesa);
    	
    	coTipoDespesa = StringUtils.leftPad("1384", 5, "0");
    	System.out.println(coTipoDespesa);
	}

}
