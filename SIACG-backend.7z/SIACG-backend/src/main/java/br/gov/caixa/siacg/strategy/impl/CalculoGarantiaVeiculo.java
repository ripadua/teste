package br.gov.caixa.siacg.strategy.impl;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.Map;

import javax.ejb.Stateless;

import org.apache.log4j.Logger;

import br.gov.caixa.siacg.comum.to.GarantiaBemClienteCalculoTO;
import br.gov.caixa.siacg.comum.to.GarantiaContratoCalculoTO;
import br.gov.caixa.siacg.model.enums.FormaGarantiaEnum;
import br.gov.caixa.siacg.model.vo.ParametrosCalculoGarantiaVO;
import br.gov.caixa.siacg.model.vo.RelatorioAnaliseContratoVO;
import br.gov.caixa.siacg.strategy.CalculoGarantia;

/**
 * <p>
 * CalculoGarantiaVeiculo
 * </p>
 * <p>
 * Descrição: Implementação do calculo para Garantia do tipo Veiculo.
 * </p>
 * <br>
 * <b>Empresa:</b> Cef - Caixa Econômica Federal
 *
 * @author guilherme.santos
 * @version 1.0
 */
@Stateless(mappedName = "CalculoGarantiaVeiculo")
public class CalculoGarantiaVeiculo implements CalculoGarantia {

    private static final long serialVersionUID = 7170040531431287763L;
    
    private static final Logger LOG = Logger.getLogger(CalculoGarantiaVeiculo.class);

    /**
     * @see br.gov.caixa.siacg.strategy.CalculoGarantia#calcular(br.gov.caixa.siacg.model.vo.ParametrosCalculoGarantiaVO)
     */
    @Override
    public RelatorioAnaliseContratoVO calcular(final ParametrosCalculoGarantiaVO parametrosCalculo, final RelatorioAnaliseContratoVO relatorio) {

	if (parametrosCalculo.isOperacaoVeiculoCalculoSuficiencia()) {
	    if (parametrosCalculo.getGarantiaContrato().getListaGarantiaBemCliente().isEmpty()) {
		relatorio.setValorApurado(BigDecimal.ZERO);
		LOG.error(String.format("O Contrato %s de operacao %d não possui garantia de veiculo vinculada ou não possui valor atualizado.", 
			parametrosCalculo.getContrato().getCoContrato(), parametrosCalculo.getContrato().getNuOperacao()));
	    } else {
        	    GarantiaBemClienteCalculoTO garantiaBemCliente = parametrosCalculo.getGarantiaContrato().getListaGarantiaBemCliente().get(0);
        	    if (garantiaBemCliente.getBemCliente() != null && garantiaBemCliente.getBemCliente().getVeiculo() != null 
        		    && garantiaBemCliente.getBemCliente().getVeiculo().getVrTabelaFipe() != null) {
        		relatorio.setValorApurado(garantiaBemCliente.getBemCliente().getVeiculo().getVrTabelaFipe());
        	    } else {
        		relatorio.setValorApurado(BigDecimal.ZERO);
        		LOG.error(String.format("O Contrato %s de operacao %d não possui garantia de veiculo vinculada ou não possui valor atualizado.", 
        			parametrosCalculo.getContrato().getCoContrato(), parametrosCalculo.getContrato().getNuOperacao()));
        	    }
	    }
	} else {
	    relatorio.setValorApurado(parametrosCalculo.getGarantiaContrato().getVrGarantia());
	    relatorio.setValorAlienacaoVeiculos(relatorio.getValorAlienacaoVeiculos().add(parametrosCalculo.getGarantiaContrato().getVrGarantia()));
	}

	return relatorio;
    }

    /**
     * <p>Método responsável por obter o percentual da garantia contratada</p>.
     *
     * @author f541915
     *
     * @param parametrosCalculo
     * @return
     */
    private BigDecimal obterPercentualGarantiaContratado(final GarantiaContratoCalculoTO garantiaContrato, final BigDecimal vrContrato) {
	BigDecimal pcGarantiaContratado = BigDecimal.ZERO;
	if (!garantiaContrato.getListaGarantiaBemCliente().isEmpty()) {
	    GarantiaBemClienteCalculoTO garantiaBemCliente = garantiaContrato.getListaGarantiaBemCliente().get(0);
	    if (garantiaBemCliente.getBemCliente() != null && garantiaBemCliente.getBemCliente().getVeiculo() != null 
		    && garantiaBemCliente.getBemCliente().getVeiculo().getVrVeiculo() != null) {
		pcGarantiaContratado = garantiaBemCliente.getBemCliente().getVeiculo().getVrVeiculo()
			.multiply(BigDecimal.valueOf(100.0)).divide(vrContrato, 2, RoundingMode.HALF_DOWN);
	    }
	}
	return pcGarantiaContratado;
    }

    /**
     * @see br.gov.caixa.siacg.strategy.CalculoGarantia#parametrizar(br.gov.caixa.siacg.comum.to.GarantiaContratoCalculoTO, java.util.Map)
    */
    @Override
    public void parametrizar(GarantiaContratoCalculoTO garantiaContrato, Map<String, Object> valores) {
	BigDecimal pcGarantiaContratado = this.obterPercentualGarantiaContratado(garantiaContrato, (BigDecimal) valores.get("vrContrato"));
	garantiaContrato.setVrFormaGarantia1(pcGarantiaContratado);
	garantiaContrato.setIcFormaGarantia1(FormaGarantiaEnum.SALDO_DEVEDOR);
    }
}
