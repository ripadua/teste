package br.gov.caixa.siacg.view.mb;

import javax.annotation.PostConstruct;
import javax.ejb.EJB;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;
import javax.inject.Inject;

import br.gov.caixa.pedesgo.arquitetura.controlador.ManutencaoBean;
import br.gov.caixa.pedesgo.arquitetura.dao.DAO;
import br.gov.caixa.pedesgo.arquitetura.servico.Servico;
import br.gov.caixa.siacg.dao.PropriedadeDAO;
import br.gov.caixa.siacg.model.domain.Propriedade;
import br.gov.caixa.siacg.model.enums.PropriedadeEnum;
import br.gov.caixa.siacg.service.PropriedadeService;
import br.gov.caixa.siacg.view.form.RemetenteVisao;

/**
 * <p>
 * DestinatatioMB
 * </p>
 * <p>
 * Descrição: Classe DestinatatioMB
 * </p>
 * <br>
 * <b>Empresa:</b> Cef - Caixa Econômica Federal.
 *	
 * @author GS Tecnologia
 * @version 1.0
 */
@ViewScoped
@ManagedBean
public class RemetenteMB extends ManutencaoBean<Propriedade> {

    /** Constante serialVersionUID. */
    private static final long serialVersionUID = -9111456499601861478L;

    /** Constante NOME_VAR_RESOURCE_BUNDLE. */
    private static final String NOME_VAR_RESOURCE_BUNDLE = "msgApp";

    private static final String MENSAGEM_NOTIFICACAO = "mensagemnotificacao";
    
    private static final String TELA_INICIAR = "/pages/index.xhtml?faces-redirect=true";
    
    private static final String MENSAGEM_SUCESSO = "MA002";
    
    /** Atributo visao. */
    private RemetenteVisao visao;

    /** Atributo service. */
    @Inject
    private transient PropriedadeService service;
    
    @EJB
    private PropriedadeDAO propriedadeDAO;

    /**
     * Método Dest.
     */
    @PostConstruct
    public void init() {
        this.visao = new RemetenteVisao();
        this.getVisao().setPropriedade(this.obterPropriedade());
      }

    /**
     * Método Salvar.
     *
     * @return string
     */
    public void salvar() {
        final Propriedade remetente = this.getVisao().getPropriedade();
        if(remetente.getNoValorPropriedade() != null && !remetente.getNoValorPropriedade().isEmpty()) {
        	this.service.salvar(remetente);
        	super.adicionaMensagemDeSucesso(RemetenteMB.MENSAGEM_SUCESSO);
        }
        else if (null == remetente.getNoValorPropriedade() || equals(remetente.getNoValorPropriedade().isEmpty())) {
          super.adicionaMensagemDeErro("MA005");
      }
    }

 
    /**
     * Método Destinatario para remover.
     *
     * @param destinatario
     *            the destinatario
     * @return string
     */
    public String remetenteParaRemover(final Propriedade propriedade) {
        this.visao.setPropriedade(propriedade);
        return null;
    }

    /**
     * Método Remover.
     *
     * @return string
     */
    public String remover() {
        final Propriedade propriedade = this.visao.getPropriedade();
        this.service.remover(propriedade);
        this.getVisao().getPropriedadeList().remove(propriedade);
        return null;
    }

    /**
     * Método cancelar.
     *
     * @return string
     */
    public String cancelar() {
     return RemetenteMB.TELA_INICIAR;
    }

    /**
     * @see br.gov.caixa.pedesgo.arquitetura.controlador.AbstractBean#getVisao()
     */
    @Override
    public RemetenteVisao getVisao() {
        return this.visao;
    }

    /**
     * Método Abrir destinatario.
     *
     * @return string
     */
    public String abrirRementente() {
        return RemetenteVisao.PAGINA_REMETENTE;
    }

    private Propriedade obterPropriedade() {
    	Propriedade propriedade = this.propriedadeDAO.getPropriedade(PropriedadeEnum.CAMINHO_PROPRIEDADE_MENSAGEM_NOTIFICACAO_REMETENTE.getPropriedade(), RemetenteMB.MENSAGEM_NOTIFICACAO);
    	
    	if(propriedade != null) {
    		return propriedade;
    	}else {
    		propriedade = new Propriedade();
    		propriedade.setNoPropriedade(PropriedadeEnum.CAMINHO_PROPRIEDADE_MENSAGEM_NOTIFICACAO_REMETENTE.getPropriedade());
    		propriedade.setNoGrupo(RemetenteMB.MENSAGEM_NOTIFICACAO);
    		return propriedade;
    	}
    }
    
    /**
     * @see br.gov.caixa.pedesgo.arquitetura.controlador.AbstractBean#getNomeVarResourceBundle()
     */
    @Override
    protected String getNomeVarResourceBundle() {
        return RemetenteMB.NOME_VAR_RESOURCE_BUNDLE;
    }
    
    /**
     * @see br.gov.caixa.pedesgo.arquitetura.controlador.AbstractBean#getPrefixoCasoDeUso()
     */
    @Override
    protected String getPrefixoCasoDeUso() {
        return null;
    }

	@Override
	public <S extends Servico<Propriedade, DAO<Propriedade>>> S getService() {
		// TODO Auto-generated method stub
		return null;
	}

}
