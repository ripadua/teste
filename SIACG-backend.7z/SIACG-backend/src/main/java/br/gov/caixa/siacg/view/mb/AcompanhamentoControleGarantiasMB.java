/**
 * Copyright (c) 2014 Caixa Econômica Federal. Todos os direitos
 * reservados.
 *
 * Caixa Econômica Federal - SIACG - Sistema de Crédito Rural
 *
 * Este software foi desenvolvido sob demanda da CAIXA e está
 * protegido por leis de direitos autorais e tratados internacionais. As
 * condições de cópia e utilização do todo ou partes dependem de autorização da
 * pessoa. Cópias não são permitidas sem expressa autorização. Não pode ser
 * comercializado ou utilizado para propósitos particulares.
 *
 * Uso exclusivo da Caixa Econômica Federal. A reprodução ou distribuição não
 * autorizada deste programa ou de parte dele, resultará em punições civis e
 * criminais e os infratores incorrem em sanções previstas na legislação em
 * vigor.
 *
 * Histórico do Subversion:
 *
 * LastChangedRevision: $Revision$
 * LastChangedBy: $Author$
 * LastChangedDate: $Date$
 *
 * HeadURL: $HeadURL$
 *
 */
package br.gov.caixa.siacg.view.mb;

import javax.ejb.EJB;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ManagedProperty;
import javax.faces.bean.SessionScoped;

import br.gov.caixa.pedesgo.arquitetura.controlador.AbstractBean;
import br.gov.caixa.pedesgo.arquitetura.controlador.ManutencaoBean;
import br.gov.caixa.siacg.model.domain.Empreendimento;
import br.gov.caixa.siacg.model.vo.EmpreendimentoVO;
import br.gov.caixa.siacg.pagination.AcompanhamentoControleGarantiasLazyModel;
import br.gov.caixa.siacg.service.EmpreendimentoService;
import br.gov.caixa.siacg.view.form.AcompanhamentoControleGarantiasVisao;

/**
 * <p>
 * AcompanhamentoEndividamentoMB.
 * </p>
 * <p>
 * Descrição: Bean Gerenciado para o Acompanahmento de Endividamento
 * </p>
 * <br>
 * <b>Empresa:</b> Cef - Caixa Econômica Federal
 *
 * @author Caio Graco
 * @version 1.0
 */
@ManagedBean
@SessionScoped
public class AcompanhamentoControleGarantiasMB extends ManutencaoBean<Empreendimento> {

    /** Atributo serialVersionUID. */
    private static final long serialVersionUID = -6313373940518853305L;

    /** Atributo NOME_MANAGED_BEAN. */
    public static final String NOME_MANAGED_BEAN = "acompanhamentoControleGarantiasMB";

    /** Atributo EL_MANAGED_BEAN. */
    public static final String EL_MANAGED_BEAN = "#{acompanhamentoControleGarantiasMB}";

    /** Atributo DIRETORIO_PAGINAS. */
    private static final String DIRETORIO_PAGINAS = "/pages/";

    /** Atributo TELA INICIAL. */
    private static final String INICIAR = "index.xhtml?faces-redirect=true";

    /** Atributo PREFIXO_CASO_USO. */
    private static final String PREFIXO_CASO_USO = "acompanhamentoControleGarantiasMB";
    
    /** Atributo PAGINA ACOMPANHAMENTO CONTROLE GARANTIA. */
    private static final String PAGINA_ACOMPANHAMENTO_CONTROLE_GARANTIA = "/pages/acompanhamentoControleGarantias/acompanhamentoControleGarantias.xhtml?faces-redirect=true";

    @EJB
    private transient EmpreendimentoService empreendimentoService;

    /** Atributo visao. */    
    private AcompanhamentoControleGarantiasVisao visao;

    /** Atributo paginacaoAcompanhamentoEndividamento. */
    @ManagedProperty(value = AcompanhamentoControleGarantiasLazyModel.EL_MANAGED_BEAN)
    private AcompanhamentoControleGarantiasLazyModel paginacaoAcompanhamentoControleGarantias;
    
    /** Atributo parametrizacaoContratoMB. */
    @ManagedProperty(value = ParametrizacaoContratoMB.EL_MANAGED_BEAN)
    private ParametrizacaoContratoMB parametrizacaoContratoMB;

    /**
     * @see br.gov.caixa.pedesgo.arquitetura.controlador.AbstractBean#getPrefixoCasoDeUso()
     */
    @Override
    protected String getPrefixoCasoDeUso() {
        return AcompanhamentoControleGarantiasMB.PREFIXO_CASO_USO;
    }

    /**
     * @see br.gov.caixa.pedesgo.arquitetura.controlador.AbstractBean#getTelaConsulta()
     */
    @Override
    public String getTelaConsulta() {
        this.carregar();
        return AcompanhamentoControleGarantiasMB.DIRETORIO_PAGINAS + this.getPrefixoCasoDeUso() + AbstractBean.SUFIXO_TELA_CONSULTA;
    }
    
    /**
     * @see br.gov.caixa.pedesgo.arquitetura.controlador.AbstractBean#carregar()
     */
    @Override
    public void carregar() { 
    	this.visao = new AcompanhamentoControleGarantiasVisao();
    }
    
        
    public String abrirTelaControleGarantiaPeloGrafico(EmpreendimentoVO empreendimento) {
    	
    	this.paginacaoAcompanhamentoControleGarantias.setFiltro(empreendimento);
    	this.carregar();
    	
    	Empreendimento emp = empreendimentoService.buscarEmpreendimento(empreendimento.getNuEmpreendimento());
    	
    	parametrizacaoContratoMB.carregarUnidadesHabitacionais(emp);
    	
  		return AcompanhamentoControleGarantiasMB.PAGINA_ACOMPANHAMENTO_CONTROLE_GARANTIA;
      	
      }

    /**
     * <p>	
     * Método responsável por limpar os dados do filtro.
     * <p>
     *
     * @return String
     * @author guilherme.santos
     */
    public String limpar() {
        this.visao = new AcompanhamentoControleGarantiasVisao();
        this.getPaginacaoAcompanhamentoControleGarantias().setFiltro(null);
        this.carregar();

        return super.MESMA_TELA;
    }
    
    public String voltaTelaInicial() {
        return AcompanhamentoControleGarantiasMB.DIRETORIO_PAGINAS + AcompanhamentoControleGarantiasMB.INICIAR;
    }
    
    /**
     * @see br.gov.caixa.pedesgo.arquitetura.controlador.AbstractBean#getService()
     */
    @SuppressWarnings("unchecked")
    @Override
    public EmpreendimentoService getService() {
        return this.empreendimentoService;
    }

    /**
     * @see br.gov.caixa.pedesgo.arquitetura.controlador.AbstractBean#getVisao()
     */
    @Override
    public AcompanhamentoControleGarantiasVisao getVisao() {
        if (this.visao == null) {
            this.visao = new AcompanhamentoControleGarantiasVisao();
        }
        return this.visao;
    }

    /**
     * Retorna o valor do atributo paginacaoAcompanhamentoControleGarantias.
     *
     * @return paginacaoAcompanhamentoControleGarantias
     */

    public AcompanhamentoControleGarantiasLazyModel getPaginacaoAcompanhamentoControleGarantias() {

		if(this.paginacaoAcompanhamentoControleGarantias == null) {
			this.paginacaoAcompanhamentoControleGarantias = new AcompanhamentoControleGarantiasLazyModel();
		}
		
		return paginacaoAcompanhamentoControleGarantias;
	}
    /**
     * Define o valor do atributo paginacaoAcompanhamentoControleGarantias.
     *
     * @param paginacaoAcompanhamentoControleGarantias
     *            valor a ser atribuído
     */

	public void setPaginacaoAcompanhamentoControleGarantias( AcompanhamentoControleGarantiasLazyModel paginacaoAcompanhamentoControleGarantias) {
		this.paginacaoAcompanhamentoControleGarantias = paginacaoAcompanhamentoControleGarantias;
	}

	/**
	 * <p>Retorna o valor do atributo parametrizacaoContratoMB</p>.
	 *
	 * @return parametrizacaoContratoMB
	 */
	public ParametrizacaoContratoMB getParametrizacaoContratoMB() {
		if(this.parametrizacaoContratoMB == null) {
			this.parametrizacaoContratoMB = new ParametrizacaoContratoMB();
		}
		return this.parametrizacaoContratoMB;
	}

	/**
	 * <p>Define o valor do atributo parametrizacaoContratoMB</p>.
	 *
	 * @param parametrizacaoContratoMB valor a ser atribuído
	 */
	public void setParametrizacaoContratoMB(ParametrizacaoContratoMB parametrizacaoContratoMB) {
		this.parametrizacaoContratoMB = parametrizacaoContratoMB;}
	
	
}
