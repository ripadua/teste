/**
 * Copyright (c) 2015 Caixa Econômica Federal. Todos os direitos
 * reservados.
 *
 * Caixa Econômica Federal - SIACG - Sistema de Crédito Rural
 *
 * Este software foi desenvolvido sob demanda da CAIXA e está
 * protegido por leis de direitos autorais e tratados internacionais. As
 * condições de cópia e utilização do todo ou partes dependem de autorização da
 * pessoa. Cópias não são permitidas sem expressa autorização. Não pode ser
 * comercializado ou utilizado para propósitos particulares.
 *
 * Uso exclusivo da Caixa Econômica Federal. A reprodução ou distribuição não
 * autorizada deste programa ou de parte dele, resultará em punições civis e
 * criminais e os infratores incorrem em sanções previstas na legislação em
 * vigor.
 *
 * Histórico do Subversion:
 *
 * LastChangedRevision: $Revision$
 * LastChangedBy: $Author$
 * LastChangedDate: $Date$
 *
 * HeadURL: $HeadURL$
 *
 */
package br.gov.caixa.siacg.view.mb;

import javax.ejb.EJB;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;

import org.primefaces.context.RequestContext;

import br.gov.caixa.pedesgo.arquitetura.controlador.AbstractBean;
import br.gov.caixa.pedesgo.arquitetura.controlador.ManutencaoBean;
import br.gov.caixa.siacg.model.domain.Garantia;
import br.gov.caixa.siacg.model.domain.GrupoGarantia;
import br.gov.caixa.siacg.model.enums.GrupoGarantiaEnum;
import br.gov.caixa.siacg.service.GarantiaService;
import br.gov.caixa.siacg.view.form.GarantiaVisao;

/**
 * <p>
 * GarantiaMB.
 * </p>
 * <p>
 * Descrição: Bean Gerenciável para a entidade Garantia
 * </p>
 * <br>
 * <b>Empresa:</b> Cef - Caixa Econômica Federal
 *
 * @author Caio Graco
 * @version 1.0
 */
@ManagedBean
@SessionScoped
public class GarantiaMB extends ManutencaoBean<Garantia> {

    /** Atributo USADA_EM_CONTRATO. */
    private static final String USADA_EM_CONTRATO = "MN026";

    /** Atributo OPERACAO_SUCESSO. */
    private static final String OPERACAO_SUCESSO = "MA002";

    /** Atributo GARANTIA_EXISTENTE. */
    private static final String GARANTIA_EXISTENTE = "MN025";

    /** Atributo serialVersionUID. */
    private static final long serialVersionUID = -4248095391849635745L;

    /** Atributo PREFIXO_CASO_USO. */
    private static final String PREFIXO_CASO_USO = "garantia";

    /** Atributo DIRETORIO_PAGINAS. */
    private static final String DIRETORIO_PAGINAS = "/pages/";

    /** Atributo NOME_MANAGED_BEAN. */
    public static final String NOME_MANAGED_BEAN = "garantiaMB";

    /** Atributo EL_MANAGED_BEAN. */
    public static final String EL_MANAGED_BEAN = "#{garantiaMB}";

    /** Atributo VAR_RESOURCE_BUNDLE. */
    private static final String VAR_RESOURCE_BUNDLE = "msgApp";

    /** Atributo visao. */
    private transient GarantiaVisao visao;

    /** Atributo garantiaService. */
    @EJB
    private transient GarantiaService garantiaService;
    
    /**
     * @see br.gov.caixa.pedesgo.arquitetura.controlador.AbstractBean#carregar()
     */
    @Override
    protected void carregar() {
        this.getVisao().setEntidade(new Garantia());
        this.getVisao().getEntidade().setGrupoGarantia(new GrupoGarantia());
        this.getVisao().setListaGrupoGarantia(this.garantiaService.listarGrupoGarantia());
        this.getVisao().setListaGarantia(this.garantiaService.listarAtivos());
    }

    /**
     * <p>
     * Método responsável por filtrar a lista de garantias.
     * <p>
     *
     * @author Caio Graco
     */
    public void filtrar() {
        this.getVisao().setListaGarantia(this.garantiaService.filtrar(this.getVisao().getEntidade()));
    }

    /**
     * <p>
     * Método responsável por abrir a página de inclusão.
     * <p>
     *
     * @return String
     * @author Caio Graco
     */
    public String abrirInclusao() {
        this.getVisao().setEntidade(new Garantia());
        this.getVisao().getEntidade().setGrupoGarantia(new GrupoGarantia());

        return this.getTelaEdicao();
    }

    /**
     * <p>
     * Método responsável por abrir a página de alteração.
     * <p>
     *
     * @param garantia
     *            valor a ser atribuído
     * @return String
     * @author Caio Graco
     */
    public String abrirAlteracao(final Garantia garantia) {
        this.getVisao().setEntidade(garantia);

        return this.getTelaEdicao();
    }

    /**
     * <p>
     * Método responsável por salvar a garantia.
     * <p>
     *
     * @author Caio Graco
     */
    public void salvar() {
        final Garantia garantia = this.getVisao().getEntidade();

        this.garantiaService.camposObrigatoriosInformados(garantia);

        if (garantia.hasMensagens()) {
            super.adicionaListaMensagemDeErro(garantia.getMensagens());
        } else {
            if (this.garantiaService.existe(garantia)) {
                super.adicionaMensagemDeErro(GarantiaMB.GARANTIA_EXISTENTE);
            } else {
                garantia.setIcAtivo(true);
                garantia.setIcCadastroManual(true);

                this.garantiaService.salvar(garantia);

                RequestContext.getCurrentInstance().execute("PF('modalSucesso').show();");
            }
        }
    }

    /**
     * <p>
     * Método responsável por excluir a garantia selecionada (Exclusão lógica).
     * <p>
     *
     * @return String
     * @author Caio Graco
     */
    public String excluir() {
        final Garantia garantia = this.getVisao().getGarantiaParaExcluir();

        if (this.garantiaService.usadaEmContrato(garantia)) {
            super.adicionaMensagemDeErro(GarantiaMB.USADA_EM_CONTRATO);
        } else {
            garantia.setIcAtivo(false);

            this.garantiaService.salvar(garantia);

            this.carregar();

            super.adicionaMensagemDeSucesso(GarantiaMB.OPERACAO_SUCESSO);
        }

        return super.MESMA_TELA;
    }
    

    /**
     * <p>
     * Método responsável por ativar a garantia selecionada.
     * <p>
     *
     * @return String
     * @author Ludemeula Fernandes de Sá
     */
    public String ativar() {
        final Garantia garantia = this.getVisao().getGarantiaParaExcluir();
        garantia.setIcAtivo(Boolean.TRUE);
        this.garantiaService.salvar(garantia);

        this.carregar();

        super.adicionaMensagemDeSucesso(GarantiaMB.OPERACAO_SUCESSO);

        return super.MESMA_TELA;
    }
    
    /**
     * <p>
     * Método responsável por habilitar cedente na garantia
     * <p>
     *
     * @return String
     * @author Brunno Antunes
     */
    public boolean habilitaCedente() {
    	if(this.getVisao().getEntidade().getGrupoGarantia().getNuGrupoGarantia() == GrupoGarantiaEnum.DUPLICATA.getCodigo()) {
    		this.getVisao().setPossuiCedente(true);
    	} else {
    		this.getVisao().setPossuiCedente(false);
    	}
    	return this.getVisao().isPossuiCedente();
    }

    /**
     * @see br.gov.caixa.pedesgo.arquitetura.controlador.AbstractBean#getPrefixoCasoDeUso()
     */
    @Override
    protected String getPrefixoCasoDeUso() {
        return GarantiaMB.PREFIXO_CASO_USO;
    }

    /**
     * @see br.gov.caixa.pedesgo.arquitetura.controlador.AbstractBean#getService()
     */
    @SuppressWarnings("unchecked")
    @Override
    public GarantiaService getService() {
        return this.garantiaService;
    }

    /**
     * @see br.gov.caixa.pedesgo.arquitetura.controlador.AbstractBean#getTelaConsulta()
     */
    @Override
    public String getTelaConsulta() {
        return GarantiaMB.DIRETORIO_PAGINAS.concat(this.getPrefixoCasoDeUso()).concat(AbstractBean.SUFIXO_TELA_CONSULTA);
    }

    /**
     * @see br.gov.caixa.pedesgo.arquitetura.controlador.AbstractBean#getNomeVarResourceBundle()
     */
    @Override
    protected String getNomeVarResourceBundle() {
        return GarantiaMB.VAR_RESOURCE_BUNDLE;
    }

    /**
     * @see br.gov.caixa.pedesgo.arquitetura.controlador.AbstractBean#getTelaEdicao()
     */
    @Override
    public String getTelaEdicao() {
        return GarantiaMB.DIRETORIO_PAGINAS.concat(this.getPrefixoCasoDeUso()).concat(AbstractBean.SUFIXO_TELA_EDICAO);
    }

    /**
     * @see br.gov.caixa.pedesgo.arquitetura.controlador.AbstractBean#getVisao()
     */
    @Override
    public GarantiaVisao getVisao() {
        if (this.visao == null) {
            this.visao = new GarantiaVisao();
        }

        return this.visao;
    }
    
}
