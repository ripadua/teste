package br.gov.caixa.siacg.view.form;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Map;

import br.gov.caixa.pedesgo.arquitetura.util.UtilObjeto;
import br.gov.caixa.pedesgo.arquitetura.visao.ManutencaoVisao;
import br.gov.caixa.siacg.model.domain.AnaliseCartaoBandeira;
import br.gov.caixa.siacg.model.domain.AnaliseCartaoCredito;
import br.gov.caixa.siacg.model.domain.AnaliseContrato;
import br.gov.caixa.siacg.model.domain.BandeiraCartao;
import br.gov.caixa.siacg.model.domain.GarantiaContrato;
import br.gov.caixa.siacg.model.domain.PreAnalise;
import br.gov.caixa.siacg.model.domain.TotalizadorMaiorSacado;
import br.gov.caixa.siacg.model.vo.RelatorioPreAnaliseContratoVO;

/**
 * <p>
 * RelatorioAnaliseVisao
 * </p>
 * <p>
 * Descrição: Classe responsável por armazenar os dados da visão do caso de uso
 * Relatório de Pré Análise de carteira.
 * </p>
 * <br>
 * <b>Empresa:</b> Cef - Caixa Econômica Federal
 *
 * @author Caio Graco
 * @version 1.0
 */

public class RelatorioPreAnaliseVisao extends ManutencaoVisao<PreAnalise> {

	/** Constante serialVersionUID. */
	private static final long serialVersionUID = -5864004959584451643L;

	// Objetos
	/** Atributo pre analise selecionada. */
	private PreAnalise preAnaliseSelecionada;

	/** Atributo listaGarantiaContratoDuplicata. */
	private Collection<GarantiaContrato> listaGarantiaContratoDuplicata;

	/** Atributo relatorio. */
	private transient RelatorioPreAnaliseContratoVO relatorio;

	/** Atributo analise contrato. */
	private AnaliseContrato analiseContrato;

	// Utilizado para renderizar ou não elementos do Relatório de Pré Análise
	/** Atributo contem garantia caracteristica fluxo. */
	private boolean contemGarantiaCaracteristicaFluxo;

	/** Atributo contem garantia caracteristica estoque. */
	private boolean contemGarantiaCaracteristicaEstoque;

	/** Atributo contem garantia duplicata. */
	private boolean contemGarantiaDuplicata;

	/** Atributo contem garantia cartao. */
	private boolean contemGarantiaCartao;

	/** Atributo contem garantia cartao estoque. */
	private boolean contemGarantiaCartaoEstoque;

	/** Atributo contem garantia cartao fluxo. */
	private boolean contemGarantiaCartaoFluxo;

	// Valores das garantias do tipo Cartão de Crédito

	/** Atributo que mantém o valor máximo permitido para duplicatas. */
	private BigDecimal valorMaximoPermitidoDuplicata = BigDecimal.ZERO;

	/** Atributo que mantém o percentual máximo permitido para duplicatas. */
	private BigDecimal percentualMaximoPermitidoDuplicata = BigDecimal.ZERO;

	/** Atributo que mantém o prazo máximo permitido para duplicatas. */
	private int prazoMaximoPermitidoDuplicata = 0;

	// Listas
	/** Atributo lista cartao credito fluxo. */
	private Collection<AnaliseCartaoCredito> listaCartaoCreditoFluxo;

	/** Atributo lista cartao credito estoque. */
	private Collection<AnaliseCartaoCredito> listaCartaoCreditoEstoque;

	/** Atributo lista maiores sacados. */
	private Collection<TotalizadorMaiorSacado> listaMaioresSacados;

	/** Atributo cedentes utilizados estoque. */
	private String cedentesUtilizadosEstoque;

	/** Atributo cedentes utilizados fluxo. */
	private String cedentesUtilizadosFluxo;

	/** Atributo mapaCartaoPorBandeiraEstoque. */
	private Map<BandeiraCartao, Collection<AnaliseCartaoBandeira>> mapaCartaoPorBandeiraEstoque;

	/** Atributo mapaCartaoPorBandeiraFluxo. */
	private Map<BandeiraCartao, Collection<AnaliseCartaoBandeira>> mapaCartaoPorBandeiraFluxo;

	/**
	 * Retorna o valor do atributo preAnaliseSelecionada.
	 *
	 * @return preAnaliseSelecionada
	 */
	public PreAnalise getPreAnaliseSelecionada() {
		return this.preAnaliseSelecionada;
	}

	/**
	 * Define o valor do atributo preAnaliseSelecionada.
	 *
	 * @param preAnaliseSelecionada
	 *            valor a ser atribuído
	 */
	public void setPreAnaliseSelecionada(final PreAnalise preAnaliseSelecionada) {
		this.preAnaliseSelecionada = preAnaliseSelecionada;
	}

	/**
	 * Retorna o valor do atributo listaCartaoCreditoFluxo.
	 *
	 * @return listaCartaoCreditoFluxo
	 */
	public Collection<AnaliseCartaoCredito> getListaCartaoCreditoFluxo() {

		return this.listaCartaoCreditoFluxo;
	}

	/**
	 * Define o valor do atributo listaCartaoCreditoFluxo.
	 *
	 * @param listaCartaoCreditoFluxo
	 *            valor a ser atribuído
	 */
	public void setListaCartaoCreditoFluxo(final Collection<AnaliseCartaoCredito> listaCartaoCreditoFluxo) {

		this.listaCartaoCreditoFluxo = listaCartaoCreditoFluxo;
	}

	/**
	 * Retorna o valor do atributo listaCartaoCreditoEstoque.
	 *
	 * @return listaCartaoCreditoEstoque
	 */
	public Collection<AnaliseCartaoCredito> getListaCartaoCreditoEstoque() {

		return this.listaCartaoCreditoEstoque;
	}

	/**
	 * Define o valor do atributo listaCartaoCreditoEstoque.
	 *
	 * @param listaCartaoCreditoEstoque
	 *            valor a ser atribuído
	 */
	public void setListaCartaoCreditoEstoque(final Collection<AnaliseCartaoCredito> listaCartaoCreditoEstoque) {

		this.listaCartaoCreditoEstoque = listaCartaoCreditoEstoque;
	}

	/**
	 * Retorna o valor do atributo relatorio.
	 *
	 * @return relatorio
	 */
	public RelatorioPreAnaliseContratoVO getRelatorio() {

		return this.relatorio;
	}

	/**
	 * Define o valor do atributo relatorio.
	 *
	 * @param relatorio
	 *            valor a ser atribuído
	 */
	public void setRelatorio(final RelatorioPreAnaliseContratoVO relatorio) {

		this.relatorio = relatorio;
	}

	/**
	 * Retorna o valor do atributo contemGarantiaCaracteristicaFluxo.
	 *
	 * @return contemGarantiaCaracteristicaFluxo
	 */
	public boolean isContemGarantiaCaracteristicaFluxo() {

		return this.contemGarantiaCaracteristicaFluxo;
	}

	/**
	 * Define o valor do atributo contemGarantiaCaracteristicaFluxo.
	 *
	 * @param contemGarantiaCaracteristicaFluxo
	 *            valor a ser atribuído
	 */
	public void setContemGarantiaCaracteristicaFluxo(final boolean contemGarantiaCaracteristicaFluxo) {

		this.contemGarantiaCaracteristicaFluxo = contemGarantiaCaracteristicaFluxo;
	}

	/**
	 * Retorna o valor do atributo contemGarantiaCaracteristicaEstoque.
	 *
	 * @return contemGarantiaCaracteristicaEstoque
	 */
	public boolean isContemGarantiaCaracteristicaEstoque() {

		return this.contemGarantiaCaracteristicaEstoque;
	}

	/**
	 * Define o valor do atributo contemGarantiaCaracteristicaEstoque.
	 *
	 * @param contemGarantiaCaracteristicaEstoque
	 *            valor a ser atribuído
	 */
	public void setContemGarantiaCaracteristicaEstoque(final boolean contemGarantiaCaracteristicaEstoque) {

		this.contemGarantiaCaracteristicaEstoque = contemGarantiaCaracteristicaEstoque;
	}

	/**
	 * Retorna o valor do atributo contemGarantiaDuplicata.
	 *
	 * @return contemGarantiaDuplicata
	 */
	public boolean isContemGarantiaDuplicata() {

		return this.contemGarantiaDuplicata;
	}

	/**
	 * Define o valor do atributo contemGarantiaDuplicata.
	 *
	 * @param contemGarantiaDuplicata
	 *            valor a ser atribuído
	 */
	public void setContemGarantiaDuplicata(final boolean contemGarantiaDuplicata) {

		this.contemGarantiaDuplicata = contemGarantiaDuplicata;
	}

	/**
	 * Retorna o valor do atributo contemGarantiaCartao.
	 *
	 * @return contemGarantiaCartao
	 */
	public boolean isContemGarantiaCartao() {

		return this.contemGarantiaCartao;
	}

	/**
	 * Define o valor do atributo contemGarantiaCartao.
	 *
	 * @param contemGarantiaCartao
	 *            valor a ser atribuído
	 */
	public void setContemGarantiaCartao(final boolean contemGarantiaCartao) {

		this.contemGarantiaCartao = contemGarantiaCartao;
	}

	/**
	 * <p>
	 * Método responsável por realizar as somatorias dos totalizadores.
	 * <p>
	 *
	 * @author guilherme.santos
	 */
	public void somaTotalizadores() {
		this.zerarTotalizadores();
		this.somaTotalizadorFluxo(this.getListaCartaoCreditoFluxo());
		this.somaTotalizadorEstoque(this.getListaCartaoCreditoEstoque());
	}

	/**
	 * <p>
	 * Método responsável por zerar os totalizadores.
	 * <p>
	 *
	 * @author guilherme.santos
	 */
	private void zerarTotalizadores() {
		// this.fluxoTotalVisa = BigDecimal.ZERO;
		// this.fluxoTotalMaster = BigDecimal.ZERO;
		// this.fluxoGarantiaTotalVisa = BigDecimal.ZERO;
		// this.fluxoGarantiaTotalMaster = BigDecimal.ZERO;
		// this.fluxoGarantiaOutroTotalVisa = BigDecimal.ZERO;
		// this.fluxoGarantiaoutroTotalMaster = BigDecimal.ZERO;
		// this.fluxoPreAnaliseTotalVisa = BigDecimal.ZERO;
		// this.fluxoPreAnaliseTotalMaster = BigDecimal.ZERO;
		//
		// this.estoqueTotalVisa = BigDecimal.ZERO;
		// this.estoqueTotalMaster = BigDecimal.ZERO;
		// this.estoqueGarantiaTotalVisa = BigDecimal.ZERO;
		// this.estoqueGarantiaTotalMaster = BigDecimal.ZERO;
		// this.estoqueGarantiaOutroTotalVisa = BigDecimal.ZERO;
		// this.estoqueGarantiaoutroTotalMaster = BigDecimal.ZERO;
		// this.estoquePreAnaliseTotalVisa = BigDecimal.ZERO;
		// this.estoquePreAnaliseTotalMaster = BigDecimal.ZERO;
	}

	/**
	 * Método Soma totalizador fluxo.
	 *
	 * @param listaFluxo
	 *            the lista fluxo
	 */
	private void somaTotalizadorFluxo(final Collection<AnaliseCartaoCredito> listaFluxo) {
		for (final AnaliseCartaoCredito c : listaFluxo) {
			// this.fluxoTotalVisa =
			// this.fluxoTotalVisa.add(c.getVrSaldoTotalVisa());
			// this.fluxoTotalMaster =
			// this.fluxoTotalMaster.add(c.getVrSaldoTotalMaster());
			// this.fluxoGarantiaTotalVisa =
			// this.fluxoGarantiaTotalVisa.add(c.getVrConsumidoContratoVisa());
			// this.fluxoGarantiaTotalMaster =
			// this.fluxoGarantiaTotalMaster.add(c.getVrConsumidoContratoMaster());
			// this.fluxoGarantiaOutroTotalVisa =
			// this.fluxoGarantiaOutroTotalVisa.add(c.getVrOutrosContratosVisa());
			// this.fluxoGarantiaoutroTotalMaster =
			// this.fluxoGarantiaoutroTotalMaster.add(c.getVrOutrosContratosMaster());
			// this.fluxoPreAnaliseTotalVisa =
			// this.fluxoPreAnaliseTotalVisa.add(c.getVrSaldoDisponivelVisa());
			// this.fluxoPreAnaliseTotalMaster =
			// this.fluxoPreAnaliseTotalMaster.add(c.getVrSaldoDisponivelMaster());
		}
	}

	/**
	 * Método Soma totalizador estoque.
	 *
	 * @param listaEstoque
	 *            the lista estoque
	 */
	private void somaTotalizadorEstoque(final Collection<AnaliseCartaoCredito> listaEstoque) {
		for (final AnaliseCartaoCredito c : listaEstoque) {
			// this.estoqueTotalVisa =
			// this.estoqueTotalVisa.add(c.getVrSaldoTotalVisa());
			// this.estoqueTotalMaster =
			// this.estoqueTotalMaster.add(c.getVrSaldoTotalMaster());
			// this.estoqueGarantiaTotalVisa =
			// this.estoqueGarantiaTotalVisa.add(c.getVrConsumidoContratoVisa());
			// this.estoqueGarantiaTotalMaster =
			// this.estoqueGarantiaTotalMaster.add(c.getVrConsumidoContratoMaster());
			// this.estoqueGarantiaOutroTotalVisa =
			// this.estoqueGarantiaOutroTotalVisa.add(c.getVrOutrosContratosVisa());
			// this.estoqueGarantiaoutroTotalMaster =
			// this.estoqueGarantiaoutroTotalMaster.add(c.getVrOutrosContratosMaster());
			// this.estoquePreAnaliseTotalVisa =
			// this.estoquePreAnaliseTotalVisa.add(c.getVrSaldoDisponivelVisa());
			// this.estoquePreAnaliseTotalMaster =
			// this.estoquePreAnaliseTotalMaster.add(c.getVrSaldoDisponivelMaster());
		}
	}

	/**
	 * Retorna o valor do atributo listaMaioresSacados.
	 *
	 * @return listaMaioresSacados
	 */
	public Collection<TotalizadorMaiorSacado> getListaMaioresSacados() {

		if (UtilObjeto.isVazio(this.listaMaioresSacados)) {

			this.listaMaioresSacados = new ArrayList<>();
		}

		return this.listaMaioresSacados;
	}

	/**
	 * Define o valor do atributo listaMaioresSacados.
	 *
	 * @param listaMaioresSacados
	 *            valor a ser atribuído
	 */
	public void setListaMaioresSacados(final Collection<TotalizadorMaiorSacado> listaMaioresSacados) {

		this.listaMaioresSacados = listaMaioresSacados;
	}

	/**
	 * Retorna o valor do atributo analiseContrato.
	 *
	 * @return analiseContrato
	 */
	public AnaliseContrato getAnaliseContrato() {

		return this.analiseContrato;
	}

	/**
	 * Define o valor do atributo analiseContrato.
	 *
	 * @param analiseContrato
	 *            valor a ser atribuído
	 */
	public void setAnaliseContrato(final AnaliseContrato analiseContrato) {

		this.analiseContrato = analiseContrato;
	}

	/**
	 * Retorna o valor do atributo contemGarantiaCartaoEstoque.
	 *
	 * @return contemGarantiaCartaoEstoque
	 */
	public boolean isContemGarantiaCartaoEstoque() {

		return this.contemGarantiaCartaoEstoque;
	}

	/**
	 * Define o valor do atributo contemGarantiaCartaoEstoque.
	 *
	 * @param contemGarantiaCartaoEstoque
	 *            valor a ser atribuído
	 */
	public void setContemGarantiaCartaoEstoque(final boolean contemGarantiaCartaoEstoque) {

		this.contemGarantiaCartaoEstoque = contemGarantiaCartaoEstoque;
	}

	/**
	 * Retorna o valor do atributo contemGarantiaCartaoFluxo.
	 *
	 * @return contemGarantiaCartaoFluxo
	 */
	public boolean isContemGarantiaCartaoFluxo() {

		return this.contemGarantiaCartaoFluxo;
	}

	/**
	 * Define o valor do atributo contemGarantiaCartaoFluxo.
	 *
	 * @param contemGarantiaCartaoFluxo
	 *            valor a ser atribuído
	 */
	public void setContemGarantiaCartaoFluxo(final boolean contemGarantiaCartaoFluxo) {

		this.contemGarantiaCartaoFluxo = contemGarantiaCartaoFluxo;
	}

	/**
	 * Retorna o valor do atributo listaGarantiaContratoDuplicata.
	 *
	 * @return listaGarantiaContratoDuplicata
	 */
	public Collection<GarantiaContrato> getListaGarantiaContratoDuplicata() {

		return this.listaGarantiaContratoDuplicata;
	}

	/**
	 * Define o valor do atributo listaGarantiaContratoDuplicata.
	 *
	 * @param listaGarantiaContratoDuplicata
	 *            valor a ser atribuído
	 */
	public void setListaGarantiaContratoDuplicata(final Collection<GarantiaContrato> listaGarantiaContratoDuplicata) {

		this.listaGarantiaContratoDuplicata = listaGarantiaContratoDuplicata;
	}

	/**
	 * Retorna o valor do atributo cedentesUtilizadosEstoque.
	 *
	 * @return cedentesUtilizadosEstoque
	 */
	public String getCedentesUtilizadosEstoque() {

		return this.cedentesUtilizadosEstoque;
	}

	/**
	 * Define o valor do atributo cedentesUtilizadosEstoque.
	 *
	 * @param cedentesUtilizadosEstoque
	 *            valor a ser atribuído
	 */
	public void setCedentesUtilizadosEstoque(final String cedentesUtilizadosEstoque) {

		this.cedentesUtilizadosEstoque = cedentesUtilizadosEstoque;
	}

	/**
	 * Retorna o valor do atributo cedentesUtilizadosFluxo.
	 *
	 * @return cedentesUtilizadosFluxo
	 */
	public String getCedentesUtilizadosFluxo() {

		return this.cedentesUtilizadosFluxo;
	}

	/**
	 * Define o valor do atributo cedentesUtilizadosFluxo.
	 *
	 * @param cedentesUtilizadosFluxo
	 *            valor a ser atribuído
	 */
	public void setCedentesUtilizadosFluxo(final String cedentesUtilizadosFluxo) {

		this.cedentesUtilizadosFluxo = cedentesUtilizadosFluxo;
	}

	/**
	 * Retorna o valor do atributo valorMaximoPermitidoDuplicata.
	 *
	 * @return valorMaximoPermitidoDuplicata
	 */
	public BigDecimal getValorMaximoPermitidoDuplicata() {

		return this.valorMaximoPermitidoDuplicata;
	}

	/**
	 * Define o valor do atributo valorMaximoPermitidoDuplicata.
	 *
	 * @param valorMaximoPermitidoDuplicata
	 *            valor a ser atribuído
	 */
	public void setValorMaximoPermitidoDuplicata(final BigDecimal valorMaximoPermitidoDuplicata) {

		this.valorMaximoPermitidoDuplicata = valorMaximoPermitidoDuplicata;
	}

	/**
	 * Retorna o valor do atributo prazoMaximoPermitidoDuplicata.
	 *
	 * @return prazoMaximoPermitidoDuplicata
	 */
	public int getPrazoMaximoPermitidoDuplicata() {

		return this.prazoMaximoPermitidoDuplicata;
	}

	/**
	 * Define o valor do atributo prazoMaximoPermitidoDuplicata.
	 *
	 * @param prazoMaximoPermitidoDuplicata
	 *            valor a ser atribuído
	 */
	public void setPrazoMaximoPermitidoDuplicata(final int prazoMaximoPermitidoDuplicata) {

		this.prazoMaximoPermitidoDuplicata = prazoMaximoPermitidoDuplicata;
	}

	/**
	 * Retorna o valor do atributo percentualMaximoPermitidoDuplicata.
	 *
	 * @return percentualMaximoPermitidoDuplicata
	 */
	public BigDecimal getPercentualMaximoPermitidoDuplicata() {

		return this.percentualMaximoPermitidoDuplicata;
	}

	/**
	 * Define o valor do atributo percentualMaximoPermitidoDuplicata.
	 *
	 * @param percentualMaximoPermitidoDuplicata
	 *            valor a ser atribuído
	 */
	public void setPercentualMaximoPermitidoDuplicata(final BigDecimal percentualMaximoPermitidoDuplicata) {

		this.percentualMaximoPermitidoDuplicata = percentualMaximoPermitidoDuplicata;
	}

	/**
	 * <p>
	 * Retorna o valor do atributo mapaCartaoPorBandeiraEstoque
	 * </p>
	 * .
	 *
	 * @return mapaCartaoPorBandeiraEstoque
	 */
	public Map<BandeiraCartao, Collection<AnaliseCartaoBandeira>> getMapaCartaoPorBandeiraEstoque() {
		return this.mapaCartaoPorBandeiraEstoque;
	}

	/**
	 * <p>
	 * Define o valor do atributo mapaCartaoPorBandeiraEstoque
	 * </p>
	 * .
	 *
	 * @param mapaCartaoPorBandeiraEstoque
	 *            valor a ser atribuído
	 */
	public void setMapaCartaoPorBandeiraEstoque(
			Map<BandeiraCartao, Collection<AnaliseCartaoBandeira>> mapaCartaoPorBandeiraEstoque) {
		this.mapaCartaoPorBandeiraEstoque = mapaCartaoPorBandeiraEstoque;
	}

	/**
	 * <p>
	 * Retorna o valor do atributo mapaCartaoPorBandeiraFluxo
	 * </p>
	 * .
	 *
	 * @return mapaCartaoPorBandeiraFluxo
	 */
	public Map<BandeiraCartao, Collection<AnaliseCartaoBandeira>> getMapaCartaoPorBandeiraFluxo() {
		return this.mapaCartaoPorBandeiraFluxo;
	}

	/**
	 * <p>
	 * Define o valor do atributo mapaCartaoPorBandeiraFluxo
	 * </p>
	 * .
	 *
	 * @param mapaCartaoPorBandeiraFluxo
	 *            valor a ser atribuído
	 */
	public void setMapaCartaoPorBandeiraFluxo(
			Map<BandeiraCartao, Collection<AnaliseCartaoBandeira>> mapaCartaoPorBandeiraFluxo) {
		this.mapaCartaoPorBandeiraFluxo = mapaCartaoPorBandeiraFluxo;
	}

}