package br.gov.caixa.siacg.strategy.impl;

import java.math.BigDecimal;

import javax.ejb.EJB;
import javax.ejb.Stateless;

import br.gov.caixa.siacg.model.vo.ParametrosCalculoGarantiaVO;
import br.gov.caixa.siacg.model.vo.RelatorioAnaliseContratoVO;
import br.gov.caixa.siacg.service.GarantiaHipotecaService;
import br.gov.caixa.siacg.service.TipologiaService;
import br.gov.caixa.siacg.strategy.CalculoGarantia;

@Stateless(mappedName = "CalculoGarantiaIndiceHipotecario")
public class CalculoGarantiaIndiceHipotecario implements CalculoGarantia {

    private static final long serialVersionUID = 7170040531431287763L;

    @EJB	
    private GarantiaHipotecaService garantiaHipotecaService;
    
    @EJB
    private TipologiaService tipologiaService;

    /**
     * 
     * @see br.gov.caixa.siacg.strategy.CalculoGarantia#calcular(br.gov.caixa.siacg.model.vo.ParametrosCalculoGarantiaVO, br.gov.caixa.siacg.model.vo.RelatorioAnaliseContratoVO)
     */
    @Override
    public RelatorioAnaliseContratoVO calcular(ParametrosCalculoGarantiaVO parametrosCalculo, RelatorioAnaliseContratoVO relatorio) {
    	if (relatorio == null) {
    	    relatorio = new RelatorioAnaliseContratoVO();
    	}

    	if (parametrosCalculo == null || parametrosCalculo.getGarantiaContrato() == null
    		|| parametrosCalculo.getGarantiaContrato().getContrato() == null
    		|| parametrosCalculo.getGarantiaContrato().getContrato().getNuContrato() == null) {
    	    relatorio.setValorApurado(BigDecimal.ZERO);
    	    return relatorio;
    	}
    	
    	return this.garantiaHipotecaService.calcular(parametrosCalculo, relatorio);
    }


}
