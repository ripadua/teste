package br.gov.caixa.siacg.view.form;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import br.gov.caixa.pedesgo.arquitetura.util.UtilObjeto;
import br.gov.caixa.pedesgo.arquitetura.visao.ManutencaoVisao;
import br.gov.caixa.siacg.comparator.LogImportacaoComparator;
import br.gov.caixa.siacg.model.domain.DWAnaliseContrato;
import br.gov.caixa.siacg.model.domain.GrupoGarantia;
import br.gov.caixa.siacg.model.domain.LogImportacao;
import br.gov.caixa.siacg.model.domain.Mensagem;
import br.gov.caixa.siacg.model.domain.Segmento;
import br.gov.caixa.siacg.model.enums.SegmentacaoEnum;
import br.gov.caixa.siacg.model.vo.SrEUnidadeVO;
import br.gov.caixa.siacg.model.vo.SrVO;
import br.gov.caixa.siacg.model.vo.UnidadeVO;
import br.gov.caixa.siacg.util.LogCEF;

/**
 * <p>
 * DWAnaliseContratoVisao
 * </p>
 * <p>
 * Descrição: Classe responsável por manter os atributos de tela.
 * </p>
 * <br>
 * <b>Empresa:</b> Cef - Caixa Econômica Federal
 *
 * @author admin
 * @version 1.0
 */
public class DWAnaliseContratoVisao extends ManutencaoVisao<DWAnaliseContrato> {

	/** Constante serialVersionUID. */
	private static final long serialVersionUID = 1L;

	/** Atributo exibir gestor caixa. */
	private boolean exibirGestorCaixa;

	/** Atributo exibir gestor nacional. */
	private boolean exibirGestorNacional;

	/** Atributo exibir gestor regional. */
	private boolean exibirGestorRegional;

	/** Atributo exibir gestor unidade. */
	private boolean exibirGestorUnidade;

	/** Atributo exibir coluna unidade. */
	private boolean exibirColunaUnidade;

	/** Atributo exibir coluna sr. */
	private boolean exibirColunaSR;

	/** Atributo exibir coluna suat. */
	private boolean exibirColunaSUAT;

	/** Atributo bread crumb analise garantia. */
	private boolean breadCrumbAnaliseGarantia;

	/** Atributo exibir pesquisa contrato. */
	private boolean exibirPesquisaContrato;

	/** Atributo exibir pesquisa contrato nao parametrizado. */
	private boolean exibirPesquisaContratoNaoParametrizado;

	/** Atributo restricao abangencia. */
	private boolean restricaoAbangencia;

	/** Atributo exibir botao abrir parametrizacao. */
	private boolean exibirBotaoAbrirParametrizacao;

	/** Atributo exibir botao voltar consulta. */
	private boolean exibirBotaoVoltarConsulta;

	/** Atributo nome suat. */
	private String nomeSuat;

	/** Atributo nome sr. */
	private String nomeSr;

	/** Atributo nome unidade. */
	private String nomeUnidade;

	/** Atributo identificador garantia. */
	private String identificadorGarantia;

	/** Atributo segmentoList. */
	private List<String> segmentoListString;

	/** Atributo nu unidade. */
	private Integer nuUnidade;

	/** Atributo nu sr. */
	private Integer nuSr;

	/** Atributo nu suat. */
	private Integer nuSuat;

	/** Atributo un unidade selecionada. */
	private Integer unidadeSelecionada;

	/** Atributo exibir painel de mensagens. */
	private Boolean exibirPainelMensagem;

	/** Atributo mensagem. */
	private Mensagem mensagem;

	/** Atributo descricao mensagem. */
	private String descricaoMensagem;

	/** Atributo data de referência. */
	private Date dataReferencia;

	/** Atributo título da grid. */
	private String tituloGrid;

	/** Atributo nivel de consulta. **/
	private String nivelConsulta;

	/** Atributo dias para data referencia. */
	private Integer diasParaDataReferencia;

	/** Atributo código identificador. */
	private String coIdentificador;

	/** Atributo quantidade Insuficiente. */
	private Integer quantidadeInsuficiente = 0;

	/** Atributo quantidade de valor pactuado. */
	private BigDecimal vrTotalPactuado = BigDecimal.ZERO;

	/** Atributo quantidade de valor insuficiente. */
	private BigDecimal vrTotalInsuficiente = BigDecimal.ZERO;

	/** Atributo quantidade nao parametrizado. */
	private Integer quantidadeNaoParametrizado = 0;

	/** Atributo quantidadeNovo. */
	private Integer quantidadeNovo;

	/** Atributo quantidadeTotal. */
	private Integer quantidadeTotal;

	/** Atributo lista mensagens. */
	private Collection<Mensagem> listaMensagens;

	/** Atributo lista log de importação. */
	private List<LogImportacao> listaLogImportacao;

	/** Atributo lista de garantias insuficientes. */
	private List<DWAnaliseContrato> garantiasInsuficientes;

	/** Atributo lista de contratos não parametrizados. */
	private List<DWAnaliseContrato> contratosNaoParametrizados;

	/** Atributo lista de contratos novos. */
	private List<DWAnaliseContrato> contratosNovos;

	/** Atributo segmento list. */
	private Collection<Segmento> segmentoList;

	/** Atributo unidade list. */
	private Collection<UnidadeVO> unidadeList;

	/** Atributo suat list. */
	private Collection<UnidadeVO> suatList;

	/** Atributo sr list. */
	private Collection<SrVO> srList;

	/** Atributo garantias. */
	private Collection<GrupoGarantia> garantias;

	/** Atributo listaSegmento. */
	private Collection<Segmento> listaSegmento;

	/** Atributo lista segmento selecionado. */
	private List<SegmentacaoEnum> listaSegmentoSelecionados;

	private SrEUnidadeVO srUnidade;
	private Collection<SrEUnidadeVO> srUnidadesList;

	private String noEmpreendimento;
	private String nuContrato;
	
	/** Config das listas de unitdades/processos */
    private List<UnidadeVO> listaDires;
    
    private List<UnidadeVO> listaSuvs;

    private Collection<UnidadeVO> listaUnidade;
    
    private UnidadeVO suatSelecionada;
    
    private Integer codSuatSelecionada;
    
    private Integer codSuvSelecionado;
    
    private Integer tipoConfig;
    
    private Integer unidadeGestoraProcesso;
    
    /** Atributo habilitar suat. */
    private boolean habilitarSuat;

    /** Atributo habilitar sr. */
    private boolean habilitarSr;

    /** Atributo habilitar unidade. */
    private boolean habilitarUnidade;
    
    private Boolean apresentarGridEmpreendimento = false;

	/**
	 * <p>
	 * Método responsável por pegar a lista de garantias insuficientes.
	 * <p>
	 *
	 * @return List<DWAnaliseContrato>
	 * @author Charles Júnior
	 */
	public List<DWAnaliseContrato> getGarantiasInsuficientes() {
		if (UtilObjeto.isVazio(this.garantiasInsuficientes)) {
			this.garantiasInsuficientes = new ArrayList<>();
		}
		return this.garantiasInsuficientes;
	}

	/**
	 * <p>
	 * Método responsável por ajustar a lista de garantias insuficientes.
	 * <p>
	 *
	 * @param garantiasInsuficientes
	 *            valor a ser atribuido
	 * @author Charles Júnior
	 */
	public void setGarantiasInsuficientes(final List<DWAnaliseContrato> garantiasInsuficientes) {
		this.garantiasInsuficientes = garantiasInsuficientes;
	}

	/**
	 * <p>
	 * Método responsável por pegar a lista de contratos não parametrizados.
	 * <p>
	 *
	 * @return List<DWAnaliseContrato>
	 * @author Charles Júnior
	 */
	public List<DWAnaliseContrato> getContratosNaoParametrizados() {
		if (UtilObjeto.isVazio(this.contratosNaoParametrizados)) {
			this.contratosNaoParametrizados = new ArrayList<>();
		}
		return this.contratosNaoParametrizados;
	}

	/**
	 * <p>
	 * Método responsável por ajustar a lista de contratos não parametrizados.
	 * <p>
	 *
	 * @param contratosNaoParametrizados
	 *            valor a ser atribuido
	 * @author Charles Júnior
	 */
	public void setContratosNaoParametrizados(final List<DWAnaliseContrato> contratosNaoParametrizados) {
		this.contratosNaoParametrizados = contratosNaoParametrizados;
	}

	/**
	 * <p>
	 * Método responsável por pegar a lista de contratos novos.
	 * <p>
	 *
	 * @return List<DWAnaliseContrato>
	 * @author Charles Júnior
	 */
	public List<DWAnaliseContrato> getContratosNovos() {
		if (UtilObjeto.isVazio(this.contratosNovos)) {
			this.contratosNovos = new ArrayList<>();
		}
		return this.contratosNovos;
	}

	/**
	 * <p>
	 * Método responsável por ajustar a lista de contratos novos.
	 * <p>
	 *
	 * @param contratosNovos
	 *            valor a ser atribuido
	 * @author Charles Júnior
	 */
	public void setContratosNovos(final List<DWAnaliseContrato> contratosNovos) {
		this.contratosNovos = contratosNovos;
	}

	/**
	 * Retorna o valor do atributo listaSegmentoSelecionados.
	 *
	 * @return listaSegmentoSelecionados
	 */
	public List<SegmentacaoEnum> getListaSegmentoSelecionados() {
		return this.listaSegmentoSelecionados;
	}

	/**
	 * Define o valor do atributo listaSegmentoSelecionados.
	 *
	 * @param listaSegmentoSelecionados
	 *            valor a ser atribuído
	 */
	public void setListaSegmentoSelecionados(final List<SegmentacaoEnum> listaSegmentoSelecionados) {
		this.listaSegmentoSelecionados = listaSegmentoSelecionados;
	}

	/**
	 * Retorna o valor do atributo exibirGestorCaixa.
	 *
	 * @return exibirGestorCaixa
	 */
	public boolean isExibirGestorCaixa() {
		return this.exibirGestorCaixa;
	}

	/**
	 * Define o valor do atributo exibirGestorCaixa.
	 *
	 * @param exibirGestorCaixa
	 *            valor a ser atribuído
	 */
	public void setExibirGestorCaixa(final boolean exibirGestorCaixa) {
		this.exibirGestorCaixa = exibirGestorCaixa;
	}

	/**
	 * Retorna o valor do atributo exibirGestorNacional.
	 *
	 * @return exibirGestorNacional
	 */
	public boolean isExibirGestorNacional() {
		return this.exibirGestorNacional;
	}

	/**
	 * Define o valor do atributo exibirGestorNacional.
	 *
	 * @param exibirGestorNacional
	 *            valor a ser atribuído
	 */
	public void setExibirGestorNacional(final boolean exibirGestorNacional) {
		this.exibirGestorNacional = exibirGestorNacional;
	}

	/**
	 * Retorna o valor do atributo exibirGestorRegional.
	 *
	 * @return exibirGestorRegional
	 */
	public boolean isExibirGestorRegional() {
		return this.exibirGestorRegional;
	}

	/**
	 * Define o valor do atributo exibirGestorRegional.
	 *
	 * @param exibirGestorRegional
	 *            valor a ser atribuído
	 */
	public void setExibirGestorRegional(final boolean exibirGestorRegional) {
		this.exibirGestorRegional = exibirGestorRegional;
	}

	/**
	 * Retorna o valor do atributo exibirGestorUnidade.
	 *
	 * @return exibirGestorUnidade
	 */
	public boolean isExibirGestorUnidade() {
		return this.exibirGestorUnidade;
	}

	/**
	 * Define o valor do atributo exibirGestorUnidade.
	 *
	 * @param exibirGestorUnidade
	 *            valor a ser atribuído
	 */
	public void setExibirGestorUnidade(final boolean exibirGestorUnidade) {
		this.exibirGestorUnidade = exibirGestorUnidade;
	}

	/**
	 * Retorna o valor do atributo nomeSuat.
	 *
	 * @return nomeSuat
	 */
	public String getNomeSuat() {
		return this.nomeSuat;
	}

	/**
	 * Define o valor do atributo nomeSuat.
	 *
	 * @param nomeSuat
	 *            valor a ser atribuído
	 */
	public void setNomeSuat(final String nomeSuat) {
		this.nomeSuat = nomeSuat;
	}

	/**
	 * Retorna o valor do atributo nomeSr.
	 *
	 * @return nomeSr
	 */
	public String getNomeSr() {
		return this.nomeSr;
	}

	/**
	 * Define o valor do atributo nomeSr.
	 *
	 * @param nomeSr
	 *            valor a ser atribuído
	 */
	public void setNomeSr(final String nomeSr) {
		this.nomeSr = nomeSr;
	}

	/**
	 * Retorna o valor do atributo nomeUnidade.
	 *
	 * @return nomeUnidade
	 */
	public String getNomeUnidade() {
		return this.nomeUnidade;
	}

	/**
	 * Define o valor do atributo nomeUnidade.
	 *
	 * @param nomeUnidade
	 *            valor a ser atribuído
	 */
	public void setNomeUnidade(final String nomeUnidade) {
		this.nomeUnidade = nomeUnidade;
	}

	/**
	 * Retorna o valor do atributo unidadeList.
	 *
	 * @return unidadeList
	 */
	public Collection<UnidadeVO> getUnidadeList() {
		return this.unidadeList;
	}

	/**
	 * Define o valor do atributo unidadeList.
	 *
	 * @param unidadeList
	 *            valor a ser atribuído
	 */
	public void setUnidadeList(final Collection<UnidadeVO> unidadeList) {
		this.unidadeList = unidadeList;
	}	

	public Integer getUnidadeSelecionada() {
		return unidadeSelecionada;
	}

	public void setUnidadeSelecionada(Integer unidadeSelecionada) {
		this.unidadeSelecionada = unidadeSelecionada;
	}

	/**
	 * Retorna o valor do atributo suatList.
	 *
	 * @return suatList
	 */
	public Collection<UnidadeVO> getSuatList() {
		return this.suatList;
	}

	/**
	 * Define o valor do atributo suatList.
	 *
	 * @param suatList
	 *            valor a ser atribuído
	 */
	public void setSuatList(final Collection<UnidadeVO> suatList) {
		this.suatList = suatList;
	}

	/**
	 * Retorna o valor do atributo srList.
	 *
	 * @return srList
	 */
	public Collection<SrVO> getSrList() {
		return this.srList;
	}

	/**
	 * Define o valor do atributo srList.
	 *
	 * @param srList
	 *            valor a ser atribuído
	 */
	public void setSrList(final Collection<SrVO> srList) {
		this.srList = srList;
	}

	/**
	 * Retorna o valor do atributo nuUnidade.
	 *
	 * @return nuUnidade
	 */
	public Integer getNuUnidade() {
		return this.nuUnidade;
	}

	/**
	 * Define o valor do atributo nuUnidade.
	 *
	 * @param nuUnidade
	 *            valor a ser atribuído
	 */
	public void setNuUnidade(final Integer nuUnidade) {
		this.nuUnidade = nuUnidade;
	}

	/**
	 * Retorna o valor do atributo nuSr.
	 *
	 * @return nuSr
	 */
	public Integer getNuSr() {
		return this.nuSr;
	}

	/**
	 * Define o valor do atributo nuSr.
	 *
	 * @param nuSr
	 *            valor a ser atribuído
	 */
	public void setNuSr(final Integer nuSr) {
		this.nuSr = nuSr;
	}

	/**
	 * Retorna o valor do atributo nuSuat.
	 *
	 * @return nuSuat
	 */
	public Integer getNuSuat() {
		return this.nuSuat;
	}

	/**
	 * Define o valor do atributo nuSuat.
	 *
	 * @param nuSuat
	 *            valor a ser atribuído
	 */
	public void setNuSuat(final Integer nuSuat) {
		this.nuSuat = nuSuat;
	}

	/**
	 * Retorna o valor do atributo restricaoAbangencia.
	 *
	 * @return restricaoAbangencia
	 */
	public boolean isRestricaoAbangencia() {
		return this.restricaoAbangencia;
	}

	/**
	 * Define o valor do atributo restricaoAbangencia.
	 *
	 * @param restricaoAbangencia
	 *            valor a ser atribuído
	 */
	public void setRestricaoAbangencia(final boolean restricaoAbangencia) {
		this.restricaoAbangencia = restricaoAbangencia;
	}

	/**
	 * Retorna o valor do atributo exibirColunaUnidade.
	 *
	 * @return exibirColunaUnidade
	 */
	public boolean isExibirColunaUnidade() {
		return this.exibirColunaUnidade;
	}

	/**
	 * Define o valor do atributo exibirColunaUnidade.
	 *
	 * @param exibirColunaUnidade
	 *            valor a ser atribuído
	 */
	public void setExibirColunaUnidade(final boolean exibirColunaUnidade) {
		this.exibirColunaUnidade = exibirColunaUnidade;
	}

	/**
	 * Retorna o valor do atributo exibirColunaSR.
	 *
	 * @return exibirColunaSR
	 */
	public boolean isExibirColunaSR() {
		return this.exibirColunaSR;
	}

	/**
	 * Define o valor do atributo exibirColunaSR.
	 *
	 * @param exibirColunaSR
	 *            valor a ser atribuído
	 */
	public void setExibirColunaSR(final boolean exibirColunaSR) {
		this.exibirColunaSR = exibirColunaSR;
	}

	/**
	 * Retorna o valor do atributo exibirColunaSUAT.
	 *
	 * @return exibirColunaSUAT
	 */
	public boolean isExibirColunaSUAT() {
		return this.exibirColunaSUAT;
	}

	/**
	 * Define o valor do atributo exibirColunaSUAT.
	 *
	 * @param exibirColunaSUAT
	 *            valor a ser atribuído
	 */
	public void setExibirColunaSUAT(final boolean exibirColunaSUAT) {
		this.exibirColunaSUAT = exibirColunaSUAT;
	}

	/**
	 * Retorna o valor do atributo identificadorGarantia.
	 *
	 * @return identificadorGarantia
	 */
	public String getIdentificadorGarantia() {
		return this.identificadorGarantia;
	}

	/**
	 * Define o valor do atributo identificadorGarantia.
	 *
	 * @param identificadorGarantia
	 *            valor a ser atribuído
	 */
	public void setIdentificadorGarantia(final String identificadorGarantia) {
		this.identificadorGarantia = identificadorGarantia;
	}

	/**
	 * Retorna o valor do atributo garantias.
	 *
	 * @return garantias
	 */
	public Collection<GrupoGarantia> getGarantias() {
		return this.garantias;
	}

	/**
	 * Define o valor do atributo garantias.
	 *
	 * @param garantias
	 *            valor a ser atribuído
	 */
	public void setGarantias(final Collection<GrupoGarantia> garantias) {
		this.garantias = garantias;
	}

	/**
	 * Retorna o valor do atributo breadCrumbAnaliseGarantia.
	 *
	 * @return breadCrumbAnaliseGarantia
	 */
	public boolean isBreadCrumbAnaliseGarantia() {
		return this.breadCrumbAnaliseGarantia;
	}

	/**
	 * Define o valor do atributo breadCrumbAnaliseGarantia.
	 *
	 * @param breadCrumbAnaliseGarantia
	 *            valor a ser atribuído
	 */
	public void setBreadCrumbAnaliseGarantia(final boolean breadCrumbAnaliseGarantia) {
		this.breadCrumbAnaliseGarantia = breadCrumbAnaliseGarantia;
	}

	/**
	 * Retorna o valor do atributo exibirPesquisaContrato.
	 *
	 * @return exibirPesquisaContrato
	 */
	public boolean isExibirPesquisaContrato() {
		return this.exibirPesquisaContrato;
	}

	/**
	 * Define o valor do atributo exibirPesquisaContrato.
	 *
	 * @param exibirPesquisaContrato
	 *            valor a ser atribuído
	 */
	public void setExibirPesquisaContrato(final boolean exibirPesquisaContrato) {
		this.exibirPesquisaContrato = exibirPesquisaContrato;
	}

	/**
	 * Retorna o valor do atributo exibirPesquisaContratoNaoParametrizado.
	 *
	 * @return exibirPesquisaContratoNaoParametrizado
	 */
	public boolean isExibirPesquisaContratoNaoParametrizado() {
		return this.exibirPesquisaContratoNaoParametrizado;
	}

	/**
	 * Define o valor do atributo exibirPesquisaContratoNaoParametrizado.
	 *
	 * @param exibirPesquisaContratoNaoParametrizado
	 *            valor a ser atribuído
	 */
	public void setExibirPesquisaContratoNaoParametrizado(final boolean exibirPesquisaContratoNaoParametrizado) {
		this.exibirPesquisaContratoNaoParametrizado = exibirPesquisaContratoNaoParametrizado;
	}

	/**
	 * Retorna o valor do atributo exibirBotaoAbrirParametrizacao.
	 *
	 * @return exibirBotaoAbrirParametrizacao
	 */
	public boolean isExibirBotaoAbrirParametrizacao() {
		return this.exibirBotaoAbrirParametrizacao;
	}

	/**
	 * Define o valor do atributo exibirBotaoAbrirParametrizacao.
	 *
	 * @param exibirBotaoAbrirParametrizacao
	 *            valor a ser atribuído
	 */
	public void setExibirBotaoAbrirParametrizacao(final boolean exibirBotaoAbrirParametrizacao) {
		this.exibirBotaoAbrirParametrizacao = exibirBotaoAbrirParametrizacao;
	}

	/**
	 * Retorna o valor do atributo listaSegmento.
	 *
	 * @return listaSegmento
	 */
	public Collection<Segmento> getListaSegmento() {
		if (this.listaSegmento == null) {
			this.listaSegmento = new ArrayList<>();
		}

		return this.listaSegmento;
	}

	/**
	 * Define o valor do atributo listaSegmento.
	 *
	 * @param listaSegmento
	 *            valor a ser atribuído
	 */
	public void setListaSegmento(final Collection<Segmento> listaSegmento) {
		this.listaSegmento = listaSegmento;
	}

	/**
	 * <p>
	 * Método responsável por pegar uma coleção de mensagens.
	 * <p>
	 *
	 * @return listaMensagens
	 * @author Charles Júnior
	 */
	public Collection<Mensagem> getListaMensagens() {
		if (this.listaMensagens == null) {
			this.listaMensagens = new ArrayList<>();
		}
		return this.listaMensagens;
	}

	/**
	 * <p>
	 * Método responsável por ajustar as mensagens.
	 * <p>
	 *
	 * @param listaMensagens
	 *            valor a ser atribuido
	 * @author Charles Júnior
	 */
	public void setListaMensagens(final Collection<Mensagem> listaMensagens) {
		this.listaMensagens = listaMensagens;
	}

	/**
	 * <p>
	 * Método responsável por pegar uma mensagem.
	 * <p>
	 *
	 * @return Mensagem
	 * @author Charles Júnior
	 */
	public Mensagem getMensagem() {
		return this.mensagem;
	}

	/**
	 * <p>
	 * Método responsável por ajustar uma mensagem.
	 * <p>
	 *
	 * @param mensagem
	 *            valor a ser atribuido
	 * @author Charles Júnior
	 */
	public void setMensagem(final Mensagem mensagem) {
		this.mensagem = mensagem;
	}

	/**
	 * <p>
	 * Método responsável por pegar a descrição da mensagem.
	 * <p>
	 *
	 * @return descricaoMensagem
	 * @author Charles Júnior
	 */
	public String getDescricaoMensagem() {
		return this.descricaoMensagem;
	}

	/**
	 * <p>
	 * Método responsável por ajustar a descrição da mensagem.
	 * <p>
	 *
	 * @param descricaoMensagem
	 *            valor a ser atribuido
	 * @author Charles Júnior
	 */
	public void setDescricaoMensagem(final String descricaoMensagem) {
		this.descricaoMensagem = descricaoMensagem;
	}

	/**
	 * <p>
	 * Método responsável por exibir o painel de mensagem.
	 * <p>
	 *
	 * @return exibirPainelMensagem
	 * @author Charles Júnior
	 */
	public Boolean getExibirPainelMensagem() {
		return this.exibirPainelMensagem;
	}

	/**
	 * <p>
	 * Método responsável por ajustar a exibição do painel de mensagem.
	 * <p>
	 *
	 * @param exibirPainelMensagem
	 *            valor a ser atribuido
	 * @author Charles Júnior
	 */
	public void setExibirPainelMensagem(final Boolean exibirPainelMensagem) {
		this.exibirPainelMensagem = exibirPainelMensagem;
	}

	/**
	 * <p>
	 * Método responsável por pegar a data de referência.
	 * <p>
	 *
	 * @return dataReferencia
	 * @author Charles Júnior
	 */
	public Date getDataReferencia() {
		return this.dataReferencia;
	}

	/**
	 * <p>
	 * Método responsável por ajustar a data de referência.
	 * <p>
	 *
	 * @param dataReferencia
	 *            valor a ser atribuido
	 * @author Charles Júnior
	 */
	public void setDataReferencia(final Date dataReferencia) {
		this.dataReferencia = dataReferencia;
	}

	/**
	 * <p>
	 * Método responsável por pegar o título da grid.
	 * <p>
	 *
	 * @return tituloGrid
	 * @author Charles Júnior
	 */
	public String getTituloGrid() {
		return this.tituloGrid;
	}

	/**
	 * <p>
	 * Método responsável por ajustar o título da grid.
	 * <p>
	 *
	 * @param tituloGrid
	 *            valor a ser atribuido
	 * @author Charles Júnior
	 */
	public void setTituloGrid(final String tituloGrid) {
		this.tituloGrid = tituloGrid;
	}

	/**
	 * <p>
	 * Método responsável por retornar o atributo nivelConsulta.
	 * <p>
	 *
	 * @return nivelConsulta
	 * @author Charles Júnior
	 */
	public String getNivelConsulta() {
		return this.nivelConsulta;
	}

	/**
	 * <p>
	 * Método responsável por definir o atributo nivelConsulta.
	 * <p>
	 *
	 * @param nivelConsulta
	 *            valor a ser atribuido
	 * @author Charles Júnior
	 */
	public void setNivelConsulta(final String nivelConsulta) {
		this.nivelConsulta = nivelConsulta;
	}

	/**
	 * <p>
	 * Método responsável por retornar o atributo diasParaDataReferencia.
	 * <p>
	 *
	 * @return diasParaDataReferencia
	 * @author Charles Júnior
	 */
	public Integer getDiasParaDataReferencia() {
		return this.diasParaDataReferencia;
	}

	/**
	 * <p>
	 * Método responsável por definir o atributo diasParaDataReferencia.
	 * <p>
	 *
	 * @param diasParaDataReferencia
	 *            valor a ser atribuido
	 * @author Charles Júnior
	 */
	public void setDiasParaDataReferencia(final Integer diasParaDataReferencia) {
		this.diasParaDataReferencia = diasParaDataReferencia;
	}

	/**
	 * <p>
	 * Método responsável por retornar o atributo coIdentificador.
	 * <p>
	 *
	 * @return coIdentificador
	 * @author Charles Júnior
	 */
	public String getCoIdentificador() {
		return this.coIdentificador;
	}

	/**
	 * <p>
	 * Método responsável por definir o atributo coIdentificador.
	 * <p>
	 *
	 * @param coIdentificador
	 *            valor a ser atribuido
	 * @author Charles Júnior
	 */
	public void setCoIdentificador(final String coIdentificador) {
		this.coIdentificador = coIdentificador;
	}

	/**
	 * <p>
	 * Método responsável por retornar o atributo quantidadeInsuficiente.
	 * <p>
	 *
	 * @return quantidadeInsuficiente
	 * @author Charles Júnior
	 */
	public Integer getQuantidadeInsuficiente() {
		return this.quantidadeInsuficiente;
	}

	/**
	 * <p>
	 * Método responsável por definir o atributo quantidadeInsuficiente.
	 * <p>
	 *
	 * @param quantidadeInsuficiente
	 *            valor a ser atribuido
	 * @author Charles Júnior
	 */
	public void setQuantidadeInsuficiente(final Integer quantidadeInsuficiente) {
		this.quantidadeInsuficiente = quantidadeInsuficiente;
	}

	/**
	 * <p>
	 * Método responsável por retornar o atributo vrTotalPactuado.
	 * <p>
	 *
	 * @return vrTotalPactuado
	 * @author robson.oliveira
	 */
	public BigDecimal getVrTotalPactuado() {
		return this.vrTotalPactuado;
	}

	/**
	 * <p>
	 * Método responsável por definir o atributo vrTotalPactuado.
	 * <p>
	 *
	 * @param vrTotalPactuado
	 *            valor a ser atribuido
	 * @author robson.oliveira
	 */
	public void setVrTotalPactuado(final BigDecimal vrTotalPactuado) {
		this.vrTotalPactuado = vrTotalPactuado;
	}

	/**
	 * <p>
	 * Método responsável por retornar o atributo vrTotalInsuficiente.
	 * <p>
	 *
	 * @return vrTotalInsuficiente
	 * @author robson.oliveira
	 */
	public BigDecimal getVrTotalInsuficiente() {
		return this.vrTotalInsuficiente;
	}

	/**
	 * <p>
	 * Método responsável por definir o atributo vrTotalInsuficiente.
	 * <p>
	 *
	 * @param vrTotalInsuficiente
	 *            valor a ser atribuido
	 * @author robson.oliveira
	 */
	public void setVrTotalInsuficiente(final BigDecimal vrTotalInsuficiente) {
		this.vrTotalInsuficiente = vrTotalInsuficiente;
	}

	/**
	 * <p>
	 * Método responsável por retornar o atibuto quantidadeNaoParametrizado.
	 * <p>
	 *
	 * @return quantidadeNaoParametrizado
	 * @author Charles Júnior
	 */
	public Integer getQuantidadeNaoParametrizado() {
		return this.quantidadeNaoParametrizado;
	}

	/**
	 * <p>
	 * Método responsável por definir o atibuto quantidadeNaoParametrizado.
	 * <p>
	 *
	 * @param quantidadeNaoParametrizado
	 *            valor a ser atribuido
	 * @author Charles Júnior
	 */
	public void setQuantidadeNaoParametrizado(final Integer quantidadeNaoParametrizado) {
		this.quantidadeNaoParametrizado = quantidadeNaoParametrizado;
	}

	/**
	 * <p>
	 * Método responsável por retornar o atibuto quantidadeNovo.
	 * <p>
	 *
	 * @return quantidadeNovo
	 * @author Charles Júnior
	 */
	public Integer getQuantidadeNovo() {
		return this.quantidadeNovo;
	}

	/**
	 * <p>
	 * Método responsável por definir o atibuto quantidadeNovo.
	 * <p>
	 *
	 * @param quantidadeNovo
	 *            valor a ser atribuido
	 * @author Charles Júnior
	 */
	public void setQuantidadeNovo(final Integer quantidadeNovo) {
		this.quantidadeNovo = quantidadeNovo;
	}

	/**
	 * <p>
	 * Método responsável por retornar o atibuto quantidadeTotal.
	 * <p>
	 *
	 * @return quantidadeTotal
	 * @author Charles Júnior
	 */
	public Integer getQuantidadeTotal() {
		return this.quantidadeTotal;
	}

	/**
	 * <p>
	 * Método responsável por definir o atibuto quantidadeTotal.
	 * <p>
	 *
	 * @param quantidadeTotal
	 *            valor a ser atribuido
	 * @author Charles Júnior
	 */
	public void setQuantidadeTotal(final Integer quantidadeTotal) {
		this.quantidadeTotal = quantidadeTotal;
	}

	/**
	 * <p>
	 * Método responsável por retornar o atibuto exibirBotaoVoltarConsulta.
	 * <p>
	 *
	 * @return exibirBotaoVoltarConsulta
	 * @author Charles Júnior
	 */
	public boolean isExibirBotaoVoltarConsulta() {
		return this.exibirBotaoVoltarConsulta;
	}

	/**
	 * <p>
	 * Método responsável por definir o atibuto exibirBotaoVoltarConsulta.
	 * <p>
	 *
	 * @param exibirBotaoVoltarConsulta
	 *            valor a ser atribuido
	 * @author Charles Júnior
	 */
	public void setExibirBotaoVoltarConsulta(final boolean exibirBotaoVoltarConsulta) {
		this.exibirBotaoVoltarConsulta = exibirBotaoVoltarConsulta;
	}

	/**
	 * Retorna o valor do atributo listaLogImportacao.
	 *
	 * @return listaLogImportacao
	 */
	public Collection<LogImportacao> getListaLogImportacao() {
		if (this.listaLogImportacao == null) {
			this.listaLogImportacao = new ArrayList<>();
		}

		return this.listaLogImportacao;
	}

	/**
	 * Define o valor do atributo listaLogImportacao.
	 *
	 * @param listaLogImportacao
	 *            valor a ser atribuído
	 */
	public void setListaLogImportacao(final List<LogImportacao> listaLogImportacao) {

		this.listaLogImportacao = listaLogImportacao;
	}

	/**
	 * <p>
	 * Método responsável por agrupar os LogImportacao's por tipo de arquivo.
	 * <p>
	 *
	 * @param listaLogImportacao
	 *            valor a ser atribuido
	 * @author guilherme.santos
	 */
	public void processarLogImportacao(final Collection<LogImportacao> listaLogImportacao) {
		final Map<String, LogImportacao> listaProcessada = new HashMap<>();

		for (final LogImportacao log : listaLogImportacao) {
			LogImportacao logDeAgrupamento = listaProcessada.get(log.getDescricaoTipoArquivo().trim());

			if (logDeAgrupamento == null) {
				logDeAgrupamento = new LogImportacao();
				logDeAgrupamento.setDescricaoTipoArquivo(log.getDescricaoTipoArquivo().trim());
				logDeAgrupamento.setDataReferencia(log.getDataReferencia());
				logDeAgrupamento.setTsLogImportacao(log.getTsLogImportacao());
			}

			logDeAgrupamento.setQtdArmazenado(
					this.somarQuantidadeArmazenado(logDeAgrupamento.getQtdArmazenado(), log.getQtdArmazenado()));
			logDeAgrupamento
					.setNomeArquivo(logDeAgrupamento.getNomeArquivo().concat(System.getProperty("line.separator"))
							.concat(log.getNomeArquivo()).concat(" - ").concat(log.getDescricaoLogImportacao()));

			listaProcessada.put(logDeAgrupamento.getDescricaoTipoArquivo(), logDeAgrupamento);
 		}

		this.setListaLogImportacao(new ArrayList<LogImportacao>());
		final Set<String> chaves = listaProcessada.keySet();
		for (final String chave : chaves) {
    			this.getListaLogImportacao().add(listaProcessada.get(chave));
    		
		}
		Collections.sort(this.listaLogImportacao, new LogImportacaoComparator());
	}

    /**
     * <p>
     * Método responsável por somar a quantidade de registros armazenados.
     * <p>
     *
     * @param primeiraQtd
     *            valor a ser atribuido
     * @param segundaQtd
     *            valor a ser atribuido
     * @return String
     * @author guilherme.santos
     */
    private Integer somarQuantidadeArmazenado(final Integer primeiraQtd, final Integer segundaQtd) {
        try {
            return primeiraQtd + segundaQtd;
        } catch (final NumberFormatException e) {
            LogCEF.error("Erro ao somar quantidade armazenada dos logs de processamento. " + primeiraQtd + " - " + segundaQtd);
            LogCEF.error(e);
        }

        return 0;
    }
		
	/**
	 * Retorna o valor do atributo segmentoList.
	 *
	 * @return segmentoList
	 */
	public Collection<Segmento> getSegmentoList() {
		return this.segmentoList;
	}

	/**
	 * Define o valor do atributo segmentoList.
	 *
	 * @param segmentoList
	 *            valor a ser atribuído
	 */
	public void setSegmentoList(final Collection<Segmento> segmentoList) {
		this.segmentoList = segmentoList;
	}

	/**
	 * Retorna o valor do atributo segmentoListString.
	 *
	 * @return segmentoListString
	 */
	public List<String> getSegmentoListString() {
		if (!UtilObjeto.isReferencia(this.segmentoListString)) {
			this.segmentoListString = new ArrayList<>();
		}

		return this.segmentoListString;
	}

	/**
	 * Define o valor do atributo segmentoListString.
	 *
	 * @param segmentoListString
	 *            valor a ser atribuído
	 */
	public void setSegmentoListString(final List<String> segmentoListString) {
		this.segmentoListString = segmentoListString;
	}

	/**
	 * @return the srUnidade
	 */
	public SrEUnidadeVO getSrUnidade() {
		return srUnidade;
	}

	/**
	 * @param srUnidade
	 *            the srUnidade to set
	 */
	public void setSrUnidade(SrEUnidadeVO srUnidade) {
		this.srUnidade = srUnidade;
	}

	/**
	 * @return the srUnidadesList
	 */
	public Collection<SrEUnidadeVO> getSrUnidadesList() {
		return srUnidadesList;
	}

	/**
	 * @param srUnidadesList
	 *            the srUnidadesList to set
	 */
	public void setSrUnidadesList(Collection<SrEUnidadeVO> srUnidadesList) {
		this.srUnidadesList = srUnidadesList;
	}

	public String getNoEmpreendimento() {
		return noEmpreendimento;
	}

	public void setNoEmpreendimento(String noEmpreendimento) {
		this.noEmpreendimento = noEmpreendimento;
	}

	/**
	 * @return the noContrato
	 */
	public String getNuContrato() {
		return nuContrato;
	}

	/**
	 * @param noContrato the noContrato to set
	 */
	public void setNuContrato(String nuContrato) {
		this.nuContrato = nuContrato;
	}
	
	public UnidadeVO getSuatSelecionada() {
		return suatSelecionada;
	}

	public void setSuatSelecionada(UnidadeVO suatSelecionada) {
		this.suatSelecionada = suatSelecionada;
	}

	public Integer getTipoConfig() {
		return tipoConfig;
	}

	public void setTipoConfig(Integer tipoConfig) {
		this.tipoConfig = tipoConfig;
	}

	public Integer getCodSuatSelecionada() {
		return codSuatSelecionada;
	}

	public void setCodSuatSelecionada(Integer codSuatSelecionada) {
		this.codSuatSelecionada = codSuatSelecionada;
	}

	public Integer getCodSuvSelecionado() {
		return codSuvSelecionado;
	}

	public void setCodSuvSelecionado(Integer codSuvSelecionado) {
		this.codSuvSelecionado = codSuvSelecionado;
	}

	public List<UnidadeVO> getListaSuvs() {
		return listaSuvs;
	}

	public void setListaSuvs(List<UnidadeVO> listaSuvs) {
		this.listaSuvs = listaSuvs;
	}

	public List<UnidadeVO> getListaDires() {
		return listaDires;
	}

	public void setListaDires(List<UnidadeVO> listaDires) {
		this.listaDires = listaDires;
	}

	public Collection<UnidadeVO> getListaUnidade() {
		return listaUnidade;
	}

	public void setListaUnidade(Collection<UnidadeVO> listaUnidade) {
		this.listaUnidade = listaUnidade;
	}

	public boolean isHabilitarSuat() {
		return habilitarSuat;
	}

	public void setHabilitarSuat(boolean habilitarSuat) {
		this.habilitarSuat = habilitarSuat;
	}

	public boolean isHabilitarSr() {
		return habilitarSr;
	}

	public void setHabilitarSr(boolean habilitarSr) {
		this.habilitarSr = habilitarSr;
	}

	public boolean isHabilitarUnidade() {
		return habilitarUnidade;
	}

	public void setHabilitarUnidade(boolean habilitarUnidade) {
		this.habilitarUnidade = habilitarUnidade;
	}

	public Integer getUnidadeGestoraProcesso() {
		return unidadeGestoraProcesso;
	}

	public void setUnidadeGestoraProcesso(Integer unidadeGestoraProcesso) {
		this.unidadeGestoraProcesso = unidadeGestoraProcesso;
	}

	public Boolean getApresentarGridEmpreendimento() {
	    return this.apresentarGridEmpreendimento;
	}

	public void setApresentarGridEmpreendimento(Boolean apresentarGridEmpreendimento) {
	    this.apresentarGridEmpreendimento = apresentarGridEmpreendimento;
	}
	
	
	

}