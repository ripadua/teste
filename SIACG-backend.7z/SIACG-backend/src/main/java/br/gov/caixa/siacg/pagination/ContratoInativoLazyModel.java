/*
 * Copyright (c) 2019 Caixa Econômica Federal. Todos os direitos
 * reservados.
 *
 * Caixa Econômica Federal - SIACG - Sistema de Crédito Rural
 *
 * Este software foi desenvolvido sob demanda da CAIXA e está
 * protegido por leis de direitos autorais e tratados internacionais. As
 * condições de cópia e utilização do todo ou partes dependem de autorização da
 * empresa. Cópias não são permitidas sem expressa autorização. Não pode ser
 * comercializado ou utilizado para propósitos particulares.
 *
 * Uso exclusivo da Caixa Econômica Federal. A reprodução ou distribuição não
 * autorizada deste programa ou de parte dele, resultará em punições civis e
 * criminais e os infratores incorrem em sanções previstas na legislação em
 * vigor.
 *
 * Histórico do TFS:
 *
 * LastChangedRevision: $Revision$
 * LastChangedBy: $Author$
 * LastChangedDate: $Date$
 *
 * HeadURL: $HeadURL$
 *
 */
package br.gov.caixa.siacg.pagination;

import java.util.List;
import java.util.Map;

import javax.enterprise.context.SessionScoped;
import javax.inject.Inject;
import javax.inject.Named;

import org.primefaces.model.SortOrder;

import br.gov.caixa.pedesgo.arquitetura.paginacao.Paginacao;
import br.gov.caixa.pedesgo.arquitetura.paginacao.PaginacaoDemanda;
import br.gov.caixa.siacg.model.domain.Contrato;
import br.gov.caixa.siacg.model.vo.FiltroContratoVO;
import br.gov.caixa.siacg.service.ContratoService;

/**
 * <p>
 * ContratoInativoModel.
 * </p>
 * <p>
 * Descrição: Classe de paginação sob demanda do Contratos Inativos (ic_situacao = '03').
 * </p>
 * <br>
 * <b>Empresa:</b> Cef - Caixa Econômica Federal
 *
 * @author ludemeula.sa
 * @version 1.0
 */
@Named
@SessionScoped
public class ContratoInativoLazyModel extends Paginacao<Contrato> {

	private static final long serialVersionUID = 3018753781368696581L;

	@Inject
    private ContratoService service;
	
	private FiltroContratoVO filtro;

    /**
     * @see br.gov.caixa.pedesgo.arquitetura.integracao.componente.paginacao.Paginacao#load(int,
     *      int, java.lang.String, org.primefaces.model.SortOrder,
     *      java.util.Map)
     */
    @Override
    public List<Contrato> load(final int inicio, final int fim, final String campoOrdenacao, final SortOrder ordenacao, final Map<String, String> parametros) {

    	getFiltro().setCampoOrdenacao(campoOrdenacao);
    	getFiltro().setTipoOrdenacao(ordenacao.name());
        final PaginacaoDemanda<Contrato> resultado = getServico().listarLiquidados(getFiltro(), inicio, fim);

        super.setWrappedData(resultado.getLista());
        super.setRowCount(resultado.getQuantidadeRegistros() == 0 ? resultado.getLista().size() : resultado.getQuantidadeRegistros());

        return resultado.getLista();
    }
    
    public void limparFiltro() {
        setFiltro(new FiltroContratoVO());
    }
    
    /**
     * Retorna o valor do atributo filtro.
     *
     * @return filtro
     */
    public FiltroContratoVO getFiltro() {
        if (this.filtro == null) {
            this.filtro = new FiltroContratoVO();
        }
        return this.filtro;
    }

    /**
     * Define o valor do atributo filtro.
     *
     * @param filtro
     *            valor a ser atribuído
     */
    public void setFiltro(final FiltroContratoVO filtro) {
        this.filtro = filtro;
    }

    /**
     * @see br.gov.caixa.pedesgo.arquitetura.integracao.componente.paginacao.Paginacao#getServico()
     */
    @SuppressWarnings("unchecked")
	@Override
    public ContratoService getServico() {
        return this.service;
    }
}