package br.gov.caixa.siacg.strategy.impl;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.ejb.EJB;
import javax.ejb.Stateless;

import br.gov.caixa.siacg.comum.to.ContaContratoCalculoTO;
import br.gov.caixa.siacg.comum.to.ContaCorrenteCalculoTO;
import br.gov.caixa.siacg.comum.to.GarantiaCartaoCreditoCalculoTO;
import br.gov.caixa.siacg.comum.to.GarantiaContratoCalculoTO;
import br.gov.caixa.siacg.comum.to.SaldoCalculoTO;
import br.gov.caixa.siacg.comum.to.SaldoCartaoBandeiraCalculoTO;
import br.gov.caixa.siacg.dao.BandeiraCartaoDAO;
import br.gov.caixa.siacg.dao.CartaoCreditoDAO;
import br.gov.caixa.siacg.dao.GarantiaCartaoCreditoDAO;
import br.gov.caixa.siacg.model.domain.AnaliseCartaoBandeira;
import br.gov.caixa.siacg.model.domain.AnaliseCartaoCredito;
import br.gov.caixa.siacg.model.domain.BandeiraCartao;
import br.gov.caixa.siacg.model.domain.ContaCorrente;
import br.gov.caixa.siacg.model.domain.ContaCorrenteID;
import br.gov.caixa.siacg.model.enums.CaracteristicaEnum;
import br.gov.caixa.siacg.model.enums.TipoOrigemContaContratoEnum;
import br.gov.caixa.siacg.model.vo.ParametrosCalculoGarantiaVO;
import br.gov.caixa.siacg.model.vo.RelatorioAnaliseContratoVO;
import br.gov.caixa.siacg.strategy.CalculoGarantia;

/**
 * <p>
 * CalculoGarantiaCartaoCredito
 * </p>
 * <p>
 * Descrição: Implementação do calculo para Garantia do tipo Cartão de Credito.
 * </p>
 * <br>
 * <b>Empresa:</b> Cef - Caixa Econômica Federal
 *
 * @author guilherme.santos
 * @version 1.0
 */
@Stateless(mappedName = "CalculoGarantiaCartaoCredito")
public class CalculoGarantiaCartaoCredito implements CalculoGarantia {

    private static final long serialVersionUID = 4189191402152827048L;
    
    // Cache de bandeiras
    private static LocalDateTime ultimaAtualizacaoBandeiras = null;
    private static List<BandeiraCartao> listaBandeiras = new ArrayList<>();
    private static Integer duracaoCacheBandeirasMinutos = 60;

    /** Atributo cartaoCreditoDAO. */
    @EJB
    private transient CartaoCreditoDAO cartaoCreditoDAO;
    /** Atributo garantiaCartaoCreditoDAO. */
    @EJB
    private transient GarantiaCartaoCreditoDAO garantiaCartaoCreditoDAO;
    /** Atributo bandeiraCartaoDAO. */
    @EJB
    private transient BandeiraCartaoDAO bandeiraCartaoDAO;
    
    /**
     * Retorna o valor do atributo cartaoCreditoDAO.
     *
     * @return cartaoCreditoDAO
     */
    public CartaoCreditoDAO getCartaoCreditoDAO() {
	return this.cartaoCreditoDAO;
    }

    /**
     * @see br.gov.caixa.siacg.strategy.CalculoGarantia#calcular(br.gov.caixa.siacg.model.vo.ParametrosCalculoGarantiaVO,
     *      br.gov.caixa.siacg.model.vo.RelatorioAnaliseContratoVO)
     */
    @Override
    public RelatorioAnaliseContratoVO calcular(final ParametrosCalculoGarantiaVO parametrosCalculo, final RelatorioAnaliseContratoVO relatorio) {

	relatorio.setValorApurado(parametrosCalculo.getValorApurado());
	relatorio.setValorEsperado(parametrosCalculo.getValorEsperado());

	List<BandeiraCartao> listaBandeiraCartao = this.obterListaBandeirasAtivas();

	for (final ContaContratoCalculoTO contaContrato : parametrosCalculo.getContrato().getListaContaContrato()) {
	    final GarantiaContratoCalculoTO garantiaContrato = parametrosCalculo.getGarantiaContrato();
	    
	    if (this.isOrigemContaContratoImportadaOuCartao(contaContrato)) {
		final AnaliseCartaoCredito analiseCartao = new AnaliseCartaoCredito();
		final ContaCorrenteCalculoTO contaCorrente = contaContrato.getContaCorrente();
		
		Map<Integer, BigDecimal> mapaSaldoPorBandeira = this.consultarTotalCartao(parametrosCalculo, contaCorrente, listaBandeiraCartao);
		Map<Integer, BigDecimal> mapaVrConsumidoOutrosContratosPorBandeira = this.consultarSaldoOutrosContratos(parametrosCalculo, contaCorrente, listaBandeiraCartao);
		
		for (BandeiraCartao bandeiraCartao : listaBandeiraCartao) {
			boolean possuiSaldoPorBandeira = mapaSaldoPorBandeira.containsKey(bandeiraCartao.getNuBandeiraCartao());
			boolean possuiSaldoOutrosContratos = mapaVrConsumidoOutrosContratosPorBandeira.containsKey(bandeiraCartao.getNuBandeiraCartao());
			if (possuiSaldoPorBandeira || possuiSaldoOutrosContratos) {
			
    		    AnaliseCartaoBandeira analiseCartaoBandeira = new AnaliseCartaoBandeira();
    		    analiseCartaoBandeira.setBandeiraCartao(bandeiraCartao);
    		    analiseCartaoBandeira.setAnaliseCartao(analiseCartao);
    
    		    // Consultar saldos totais disponiveis para a bandeira
    		    analiseCartaoBandeira.setVrSaldoTotal(possuiSaldoPorBandeira 
    			    ? mapaSaldoPorBandeira.get(bandeiraCartao.getNuBandeiraCartao())
    			    : BigDecimal.ZERO);
    		    
    		    // Consultar saldos consumidos por garantia de outros contratos
    		    analiseCartaoBandeira.setVrOutrosContratos(possuiSaldoOutrosContratos
    			    ? mapaVrConsumidoOutrosContratosPorBandeira.get(bandeiraCartao.getNuBandeiraCartao())
    			    : BigDecimal.ZERO);
    
    		    // Consultar saldo diponivel antes de parametrizar a garantia
    		    analiseCartaoBandeira.setVrSaldoDisponivel(analiseCartaoBandeira.getVrSaldoTotal().subtract(analiseCartaoBandeira.getVrOutrosContratos()));
    
    		    analiseCartao.getAnalisesCartaoBandeira().add(analiseCartaoBandeira);
			}
		}

		// Consumir saldo do cartão de crédito
		this.consumirSaldoCartaoCredito(garantiaContrato, relatorio, analiseCartao, contaCorrente);

		BigDecimal vrConsumidoTotal = BigDecimal.ZERO;
		Map<Integer, BigDecimal> mapaSaldoConsumidoPorBandeira = this.garantiaCartaoCreditoDAO
			.calcularSaldoConsumidoGarantia(contaCorrente, listaBandeiraCartao, garantiaContrato.getNuGarantiaContrato());

		for (AnaliseCartaoBandeira analiseCartaoBandeira : analiseCartao.getAnalisesCartaoBandeira()) {

		    // Consultar saldo consumido pela garantia e conta corrente
		    analiseCartaoBandeira.setVrConsumidoContrato(mapaSaldoConsumidoPorBandeira.containsKey(analiseCartaoBandeira.getBandeiraCartao().getNuBandeiraCartao()) 
			    ? mapaSaldoConsumidoPorBandeira.get(analiseCartaoBandeira.getBandeiraCartao().getNuBandeiraCartao())
			    : BigDecimal.ZERO);

		    // Consultar saldo diponivel
		    final BigDecimal saldoDisponivel = analiseCartaoBandeira.getVrSaldoDisponivel()
			    .subtract(analiseCartaoBandeira.getVrConsumidoContrato());

		    analiseCartaoBandeira.setVrSaldoDisponivel(saldoDisponivel.compareTo(BigDecimal.ZERO) < 0 ? BigDecimal.ZERO : saldoDisponivel);

		    vrConsumidoTotal = vrConsumidoTotal.add(analiseCartaoBandeira.getVrConsumidoContrato());
		}

		ContaCorrenteID id = new ContaCorrenteID(contaCorrente.getNuAgencia(), contaCorrente.getNuOperacao(), 
			contaCorrente.getNuConta(), contaCorrente.getNuVerificador());
		ContaCorrente contaCorrenteModel = new ContaCorrente(id);
		analiseCartao.setNuConta(contaCorrenteModel);
		
		// Caso a garantia não possua caracteristica, deve ser adotado a caracteristica Fluxo, como relatado no remine #517
		analiseCartao.setIcTipoGarantia(
			garantiaContrato.getIdentificadorCaracteristica() != null ? garantiaContrato.getIdentificadorCaracteristica()
				: CaracteristicaEnum.FLUXO.getValor());
		
		// Adiciona a lista para persistir
		relatorio.getListaAnaliseCartaoCredito().add(analiseCartao);

		// Soma valor apurado
		relatorio.setValorApurado(relatorio.getValorApurado().add(vrConsumidoTotal));

		// Atribui os valores disponiveis para pre-analise
		this.atribuirValoresDisponivelPreAnalise(parametrosCalculo.getSaldo(), analiseCartao);
	    }
	}

	return relatorio;
    }

    /**
     * <p>
     * Método responsável por atribuir os valroes disponiveis para pré-analise.
     * <p>
     *
     * @param relatorio
     *            valor a ser atribuido
     * @param analiseCartao
     *            valor a ser atribuido
     * @author guilherme.santos
     */
    private void atribuirValoresDisponivelPreAnalise(final SaldoCalculoTO saldoPessoa, final AnaliseCartaoCredito analiseCartao) {
    	for (AnaliseCartaoBandeira analiseCartaoBandeira : analiseCartao.getAnalisesCartaoBandeira()) {
    	    SaldoCartaoBandeiraCalculoTO saldoCartaoBandeira = null;
    	    for (SaldoCartaoBandeiraCalculoTO saldoCartao : saldoPessoa.getListaSaldosCartaoBandeira()) {
        		if (saldoCartao.getNuBandeiraCartao().equals(analiseCartaoBandeira.getBandeiraCartao().getNuBandeiraCartao())) {
        		    saldoCartaoBandeira = saldoCartao;
        		    break;
        		}
    	    }
    
    	    if (saldoCartaoBandeira == null) {
        		saldoCartaoBandeira = new SaldoCartaoBandeiraCalculoTO();
        		saldoCartaoBandeira.setNuBandeiraCartao(analiseCartaoBandeira.getBandeiraCartao().getNuBandeiraCartao());
        		saldoCartaoBandeira.setVrCartaoEstoque(BigDecimal.ZERO);
        		saldoCartaoBandeira.setVrCartaoFluxo(BigDecimal.ZERO);
        		saldoCartaoBandeira.setSaldo(saldoPessoa);
        		saldoPessoa.getListaSaldosCartaoBandeira().add(saldoCartaoBandeira);
    	    }
    
    	    if (analiseCartao.getIcTipoGarantia().equals(CaracteristicaEnum.ESTOQUE.getValor())) {
    	    	saldoCartaoBandeira.setVrCartaoEstoque(analiseCartaoBandeira.getVrSaldoDisponivel());
    	    } else if (analiseCartao.getIcTipoGarantia().equals(CaracteristicaEnum.FLUXO.getValor())) {
    	    	saldoCartaoBandeira.setVrCartaoFluxo(analiseCartaoBandeira.getVrSaldoDisponivel());
    	    }

		}
    }

    /**
     * <p>
     * Método responsável por controlar o consumo do saldo dos cartões.
     * <p>
     *
     * @param garantiaContrato
     *            valor a ser atribuido
     * @param relatorio
     *            valor a ser atribuido
     * @param analiseCartao
     *            valor a ser atribuido
     * @param contaCorrente
     *            valor a ser atribuido
     * @author guilherme.santos
     */
    private synchronized void consumirSaldoCartaoCredito(final GarantiaContratoCalculoTO garantiaContrato, final RelatorioAnaliseContratoVO relatorio,
	    final AnaliseCartaoCredito analiseCartao, final ContaCorrenteCalculoTO contaCorrente) {

	BigDecimal valorRestante = relatorio.getValorEsperado().subtract(relatorio.getValorApurado());
	
	for (final GarantiaCartaoCreditoCalculoTO garantiaCartao : garantiaContrato.getListaGarantiaCartaoCredito()) {
	    if (valorRestante.compareTo(BigDecimal.ZERO) <= 0) {
		break;
	    } else if (!garantiaCartao.getContaCorrente().equals(contaCorrente)) {
		continue;
	    }

	    // Atribui flag para consumo de pre analise
	    garantiaCartao.setIcOrigemPreAnalise(garantiaContrato.getContrato().isPreAnalise());

	    for (AnaliseCartaoBandeira analiseCartaoBandeira : analiseCartao.getAnalisesCartaoBandeira()) {

		if (garantiaCartao.getNuBandeiraCartao().equals(analiseCartaoBandeira.getBandeiraCartao().getNuBandeiraCartao())) {

		    // Existe saldo disponivel
		    if (analiseCartaoBandeira.getVrSaldoDisponivel().compareTo(valorRestante) >= 0) {
			garantiaCartao.setVrConsumido(valorRestante);
			valorRestante = BigDecimal.ZERO;

			this.garantiaCartaoCreditoDAO.atualizarVrConsumido(garantiaCartao);
		    } else if (analiseCartaoBandeira.getVrSaldoDisponivel().compareTo(BigDecimal.ZERO) > 0) {
			// Existe saldo insuficiente
			final BigDecimal creditoConsumido = analiseCartaoBandeira.getVrSaldoDisponivel();

			garantiaCartao.setVrConsumido(creditoConsumido);
			valorRestante = valorRestante.subtract(creditoConsumido);

			this.garantiaCartaoCreditoDAO.atualizarVrConsumido(garantiaCartao);
		    }
		    break;
		}
	    }
	}
    }

    /**
     * <p>
     * Método responsável por consultar o saldo de garantias de outros
     * contratos.
     * <p>
     *
     * @param parametrosCalculo
     *            valor a ser atribuido
     * @param contaCorrente
     *            valor a ser atribuido
     * @return BigDecimal
     * @author guilherme.santos
     */
    private Map<Integer,BigDecimal> consultarSaldoOutrosContratos(final ParametrosCalculoGarantiaVO parametrosCalculo, final ContaCorrenteCalculoTO contaCorrente,
	    List<BandeiraCartao> listaBandeiraCartao) {
	return this.garantiaCartaoCreditoDAO.calcularSaldoConsumidoOutrosContratos(contaCorrente, listaBandeiraCartao,
		parametrosCalculo.getGarantiaContrato());
    }

    /**
     * <p>
     * Método responsável por consultar o saldo total de cartão.
     * <p>
     *
     * @param parametrosCalculo
     *            valor a ser atribuido
     * @param contaCorrente
     *            valor a ser atribuido
     * @return BigDecimal
     * @author guilherme.santos
     */
    private Map<Integer, BigDecimal> consultarTotalCartao(final ParametrosCalculoGarantiaVO parametrosCalculo, final ContaCorrenteCalculoTO contaCorrente,
	    List<BandeiraCartao> listaBandeiraCartao) {
	return this.cartaoCreditoDAO.calcularSaldoTotalCartao(contaCorrente, listaBandeiraCartao,
		parametrosCalculo.getGarantiaContrato().getIcCaracteristica());
    }

    /**
     * <p>
     * Método responsável por verificar se a origem da conta contrato é
     * importada ou inserida manualmente para cartão de credito.
     * <p>
     *
     * @param contaContrato
     *            valor a ser atribuido
     * @return boolean
     * @author guilherme.santos
     */
    private boolean isOrigemContaContratoImportadaOuCartao(final ContaContratoCalculoTO contaContrato) {
	return contaContrato.getIcOrigem() == TipoOrigemContaContratoEnum.IMPORTADO
		|| contaContrato.getIcOrigem() == TipoOrigemContaContratoEnum.CARTAO_CREDITO;
    }
    
    /**
     * <p>Método responsável por obter a lista de bandeiras ativas do cache ou do banco</p>.
     *
     * @author f541915
     *
     * @return
     */
    private List<BandeiraCartao> obterListaBandeirasAtivas() {
	if (ultimaAtualizacaoBandeiras != null) {
	    long time = ChronoUnit.MINUTES.between(ultimaAtualizacaoBandeiras, LocalDateTime.now());
	    if (time > duracaoCacheBandeirasMinutos) {
		ultimaAtualizacaoBandeiras = null;
		listaBandeiras.clear();
	    }
	}
	if (!listaBandeiras.isEmpty()) {
	    return listaBandeiras;
	}
	List<BandeiraCartao> bandeiras = this.bandeiraCartaoDAO.listarTodasBandeirasAtivas();
	if (ultimaAtualizacaoBandeiras == null) {
	    ultimaAtualizacaoBandeiras = LocalDateTime.now();
	}
	listaBandeiras.addAll(bandeiras);
	return bandeiras;
    }
}
