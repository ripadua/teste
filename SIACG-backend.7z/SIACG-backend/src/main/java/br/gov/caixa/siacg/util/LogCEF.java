/**
 * reservados.
 * Copyright (c) 2009-2011 Caixa Econômica Federal. Todos os direitos
 *
 * Caixa Econômica Federal - SIACG – Sistema de Acompanhamento de Carteiras de Cobrança
 *
 * Este programa de computador foi desenvolvido sob demanda da CAIXA e está
 * protegido por leis de direitos autorais e tratados internacionais. As
 * condições de cópia e utilização do todo ou partes dependem de autorização da
 * pessoa. Cópias não são permitidas sem expressa autorização. Não pode ser
 * comercializado ou utilizado para propósitos particulares.
 *
 * Uso exclusivo da Caixa Econômica Federal. A reprodução ou distribuição não
 * autorizada deste programa ou de parte dele, resultará em punições civis e
 * criminais e os infratores incorrem em sanções previstas na legislação em
 * vigor.
 *
 * Histórico do Subversion:
 *
 * LastChangedRevision:
 * LastChangedBy:
 * LastChangedDate:
 *
 * HeadURL:
 *
 */
package br.gov.caixa.siacg.util;

import java.util.logging.Logger;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

/**
 * <p>
 * LogCEF
 * </p>
 * <p>
 * Descrição: Classe LogCEF
 * </p>
 * <br>
 * <b>Empresa:</b> Cef - Caixa Econômica Federal.
 *
 * @author GS Tecnologia
 * @version 1.0
 */
public class LogCEF {

    /** Constante log. */
    private static final Logger LOG = Logger.getLogger(LogCEF.class.getName());

    /** Constante JOGO_DA_VELHA. */
    private static final String JOGO_DA_VELHA = " ### ";

    /** Atributo enabled log debug. */
    public static final boolean ENABLED_LOG_DEBUG = false;
    
    private LogCEF() {
	throw new IllegalStateException("Classe de Utilidade");
    }

    /**
     * <p>
     * Método responsável por adicionar mensagem de debug.
     * <p>
     *
     * @param object
     *            valor a ser atribuido
     */
    public static void debug(final Object object) {
        final String methodName = Thread.currentThread().getStackTrace()[2].getMethodName();
        final int line = Thread.currentThread().getStackTrace()[2].getLineNumber();
        final Log logger = LogFactory.getLog(Thread.currentThread().getStackTrace()[2].getClassName());
        logger.debug(methodName + ":" + line + " " + object);
        if (LogCEF.ENABLED_LOG_DEBUG) {
            LogCEF.LOG.fine("###-DEBUG-### " + methodName + ":" + line + LogCEF.JOGO_DA_VELHA + object);
        }
    }

    /**
     * <p>
     * Método responsável por adicionar mensagem informativa.
     * <p>
     *
     * @param object
     *            valor a ser atribuido
     */
    public static void info(final Object object) {
        final String methodName = Thread.currentThread().getStackTrace()[2].getMethodName();
        final int line = Thread.currentThread().getStackTrace()[2].getLineNumber();
        final Log logger = LogFactory.getLog(Thread.currentThread().getStackTrace()[2].getClassName());
        logger.info(methodName + ":" + line + LogCEF.JOGO_DA_VELHA + object);
    }

    /**
     * <p>
     * Método responsável por adicionar mensagem de erro.
     * <p>
     *
     * @param object
     *            valor a ser atribuido
     */
    public static void error(final Object object) {
        final String methodName = Thread.currentThread().getStackTrace()[2].getMethodName();
        final int line = Thread.currentThread().getStackTrace()[2].getLineNumber();
        final Log logger = LogFactory.getLog(Thread.currentThread().getStackTrace()[2].getClassName());
        logger.error(methodName + ":" + line + LogCEF.JOGO_DA_VELHA + object);
    }

    /**
     * Método Fatal.
     *
     * @param object
     *            the object
     */
    public static void fatal(final Object object) {
        final String methodName = Thread.currentThread().getStackTrace()[2].getMethodName();
        final int line = Thread.currentThread().getStackTrace()[2].getLineNumber();
        final Log logger = LogFactory.getLog(Thread.currentThread().getStackTrace()[2].getClassName());
        logger.fatal(methodName + ":" + line + LogCEF.JOGO_DA_VELHA + object);
    }

    /**
     * <p>
     * Método responsável por adicionar mensagem de alerta.
     * <p>
     *
     * @param object
     *            valor a ser atribuido
     */
    public static void warn(final Object object) {
        final String methodName = Thread.currentThread().getStackTrace()[2].getMethodName();
        final int line = Thread.currentThread().getStackTrace()[2].getLineNumber();
        final Log logger = LogFactory.getLog(Thread.currentThread().getStackTrace()[2].getClassName());
        logger.warn(methodName + ":" + line + LogCEF.JOGO_DA_VELHA + object);
    }

    /**
     * Método Debug.
     */
    public static void debug() {
        final String methodName = Thread.currentThread().getStackTrace()[2].getMethodName();
        final int line = Thread.currentThread().getStackTrace()[2].getLineNumber();
        if (LogCEF.ENABLED_LOG_DEBUG) {
            LogCEF.LOG.fine("###-DEBUG-### " + methodName + ":" + line + LogCEF.JOGO_DA_VELHA);
        }
    }
}
