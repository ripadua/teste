/**
 * Copyright (c) 2015 Caixa Econômica Federal. Todos os direitos
 * reservados.
 *
 * Caixa Econômica Federal - SIACG - Sistema de Crédito Rural
 *
 * Este software foi desenvolvido sob demanda da CAIXA e está
 * protegido por leis de direitos autorais e tratados internacionais. As
 * condições de cópia e utilização do todo ou partes dependem de autorização da
 * pessoa. Cópias não são permitidas sem expressa autorização. Não pode ser
 * comercializado ou utilizado para propósitos particulares.
 *
 * Uso exclusivo da Caixa Econômica Federal. A reprodução ou distribuição não
 * autorizada deste programa ou de parte dele, resultará em punições civis e
 * criminais e os infratores incorrem em sanções previstas na legislação em
 * vigor.
 *
 * Histórico do Subversion:
 *
 * LastChangedRevision: $Revision$
 * LastChangedBy: $Author$
 * LastChangedDate: $Date$
 *
 * HeadURL: $HeadURL$
 *
 */
package br.gov.caixa.siacg.view.mb;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import javax.annotation.PostConstruct;
import javax.ejb.EJB;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;
import javax.faces.component.UIOutput;
import javax.faces.event.AjaxBehaviorEvent;
import javax.faces.model.SelectItem;
import javax.inject.Inject;

import org.primefaces.component.datatable.DataTable;
import org.primefaces.context.RequestContext;
import org.primefaces.event.CellEditEvent;
import org.primefaces.event.RowEditEvent;
import org.primefaces.event.TabChangeEvent;

import br.gov.caixa.pedesgo.arquitetura.controlador.AbstractBean;
import br.gov.caixa.pedesgo.arquitetura.controlador.ManutencaoBean;
import br.gov.caixa.pedesgo.arquitetura.util.UsuarioUtil;
import br.gov.caixa.pedesgo.arquitetura.util.UtilObjeto;
import br.gov.caixa.pedesgo.arquitetura.util.UtilString;
import br.gov.caixa.siacg.model.domain.Garantia;
import br.gov.caixa.siacg.model.domain.ParametroGarantia;
import br.gov.caixa.siacg.model.domain.ParametroProduto;
import br.gov.caixa.siacg.model.domain.ParametroProdutoGestorProduto;
import br.gov.caixa.siacg.model.domain.ParametroProdutoGestorProdutoID;
import br.gov.caixa.siacg.model.domain.ParametroProdutoID;
import br.gov.caixa.siacg.model.domain.SegmentoCliente;
import br.gov.caixa.siacg.model.domain.Unidade;
import br.gov.caixa.siacg.model.domain.UnidadeID;
import br.gov.caixa.siacg.model.domain.ViewProdutoSiico;
import br.gov.caixa.siacg.model.enums.FormaBloqueioGarantiaEnum;
import br.gov.caixa.siacg.model.enums.OrdemBloqueioDesbloqueioGarantiaEnum;
import br.gov.caixa.siacg.model.vo.NumberNameVO;
import br.gov.caixa.siacg.service.ContratoService;
import br.gov.caixa.siacg.service.GarantiaService;
import br.gov.caixa.siacg.service.ParametroProdutoGarantiaService;
import br.gov.caixa.siacg.service.ParametroProdutoService;
import br.gov.caixa.siacg.service.ParametroProdutoUnidadeGestoraService;
import br.gov.caixa.siacg.service.SegmentoClienteService;
import br.gov.caixa.siacg.service.UnidadeService;
import br.gov.caixa.siacg.service.ViewProdutoSiicoService;
import br.gov.caixa.siacg.util.LogCEF;
import br.gov.caixa.siacg.view.form.ParametroProdutoVisao;

/**
 * <p>
 * ParametroProduto.
 * </p>
 * <p>
 * Descrição: Bean Gerenciável para a entidade ParametroProduto
 * </p>
 * <br>
 * <b>Empresa:</b> Cef - Caixa Econômica Federal
 *
 * @author Leandro Severino -> lseverino@gmail.com
 * @version 1.0
 */
@ManagedBean
@SessionScoped
public class ParametroProdutoMB extends ManutencaoBean<ParametroProduto> {

    /** Atributo OPERACAO_SUCESSO. */
    private static final String OPERACAO_SUCESSO = "MA002";

    /** Atributo PRODUTO_MODALIDADE_INVALIDO. */
    private static final String PRODUTO_MODALIDADE_INVALIDO = "MN053";

    private static final String PORTE_INVALIDO = "MN067";
    private static final String PORTE_DUPLICADO = "MN068";
    private static final String JUSTIFICATIVA_INVALIDA = "MN069";

    /** Atributo serialVersionUID. */
    private static final long serialVersionUID = -4248095391849635745L;

    /** Atributo PREFIXO_CASO_USO. */
    private static final String PREFIXO_CASO_USO = "parametroProduto";

    /** Atributo DIRETORIO_PAGINAS. */
    private static final String DIRETORIO_PAGINAS = "/pages/";

    /** Atributo NOME_MANAGED_BEAN. */
    public static final String NOME_MANAGED_BEAN = "parametroProdutoMB";

    /** Atributo EL_MANAGED_BEAN. */
    public static final String EL_MANAGED_BEAN = "#{parametroProdutoMB}";

    /** Atributo VAR_RESOURCE_BUNDLE. */
    private static final String VAR_RESOURCE_BUNDLE = "msgApp";

    /** Atributo OPERACAO_INCLUSAO. */
    public static final boolean OPERACAO_INCLUSAO = true;

    /** Atributo MODO_INCLUSAO. */
    public static final int MODO_INCLUSAO = 0;

    /** Atributo MODO_ALTERACAO. */
    public static final int MODO_ALTERACAO = 1;

    /** Atributo MODO_ERRO. */
    public static final int MODO_ERRO = 2;

    /** Atributo visao. */
    private transient ParametroProdutoVisao visao;

    /** Atributo parametroProdutoService. */
    @EJB
    private transient ParametroProdutoService parametroProdutoService;
    
    @Inject
    private SegmentoClienteService segmentoClienteService; 

    /** Atributo viewProdutoSiicoService. */
    @EJB
    private transient ViewProdutoSiicoService viewProdutoSiicoService;

    /** Atributo parametroProdutoUnidadeGestoraService. */
    @EJB
    private transient ParametroProdutoUnidadeGestoraService parametroProdutoUnidadeGestoraService;

    /** Atributo parametroGarantiaService. */
    @EJB
    private transient ParametroProdutoGarantiaService parametroGarantiaService;

    /** Atributo garantiaService. */
    @EJB
    private transient GarantiaService garantiaService;

    /** Atributo contratoService. */
    @EJB
    private transient ContratoService contratoService;

    /** Atributo unidadeService. */
    @EJB
    private transient UnidadeService unidadeService;

    /** Atributo listaSN. */
    private List<SelectItem> listaSN = new ArrayList<>();

    /** Atributo paginaJaFoiInicializada. */
    private Boolean paginaJaFoiInicializada = Boolean.FALSE;

    /** Atributo idxGarantia. */
    private Integer idxGarantia;

    /** Atributo campoComErro. */
    private boolean campoComErro;

    /** Atributo mensagemDeErroNaValidacaoCampo. */
    private String mensagemDeErroNaValidacaoCampo;

    /** Atributo nomesDosProdutosParaExcluir. */
    private String nomesDosProdutosParaExcluir;

    /** Atributo confirmaExclusaoModalidade. */
    private String confirmaExclusaoModalidade;

    /** Atributo nomeModalModalidadeParaAbrir. */
    private String nomeModalModalidadeParaAbrir;

    /** Atributo nomeModalUnidadeGestoraParaAbrir. */
    private String nomeModalUnidadeGestoraParaAbrir;

    /** Atributo listaProdutosParaExcluir. */
    private Collection<ParametroProduto> listaProdutosParaExcluir = new ArrayList<>();

    /** Atributo listaProdutosParaHomologar. */
    private Collection<ViewProdutoSiico> listaProdutosParaHomologar = new ArrayList<>();

    /** Atributo listaProdutosBloqueio. */
    private List<ParametroGarantia> listaProdutosBloqueio = new ArrayList<>();

    /** Atributo listaProdutosDesbloqueio. */
    private List<ParametroGarantia> listaProdutosDesbloqueio = new ArrayList<>();

    /** Atributo produtoParaHomologar. */
    private ParametroProduto produtoParaHomologar;

    /** Atributo modalidadeParaExcluir. */
    private ParametroProduto modalidadeParaExcluir = new ParametroProduto();

    /** Atributo unidadeParaExcluir. */
    private ParametroProdutoGestorProduto unidadeParaExcluir = new ParametroProdutoGestorProduto();

    private String strModalidadeFormatada;

    private boolean disableModalidadeClonar = true;

    private boolean limparCamposTela = true;

    private List<NumberNameVO> listModalidadesClonar = new ArrayList<>();

    private Collection<SegmentoCliente> segmentos;

    private ParametroGarantia garantiaSelecionada;

    private SegmentoCliente segmentoSelecionado;

    private String justificativaHomologacao;

    /**
     * @see br.gov.caixa.pedesgo.arquitetura.controlador.AbstractBean#carregar()
     */

    @PostConstruct
    public void carregaTelainicializar() {

	this.setPaginaJaFoiInicializada(Boolean.FALSE);
	this.limparCamposTela = false;

    }

    public void carregarHomologar() {
	this.setProdutoParaHomologar(new ParametroProduto());
	this.getProdutoParaHomologar().setParametroProdutoID(new ParametroProdutoID());
	this.getProdutoParaHomologar().setListaParametroGarantia(new ArrayList<ParametroGarantia>());
    }

    public void carregarClonar() {
	// this.getVisao().setListaGarantiasBacen(this.garantiaService.listarAtivos());

	final Integer nuModalidade = Integer.parseInt(this.getStrModalidadeFormatada());

	this.getVisao().setListaGarantiasBacen(this.garantiaService.listarPorProdutoModalidade(this.visao.getProdutoSelecionado(), nuModalidade));
    }

    public void carregar(boolean consulta) {

	if (!paginaJaFoiInicializada || this.getVisao().isCarregarTela()) {
	    this.getVisao().setEntidade(new ParametroProduto());
	    this.getVisao().setViewProdutoSiico(new ViewProdutoSiico());
	    this.getVisao().setProdutoSelecionado(new ParametroProduto());
	    this.getVisao().getProdutoSelecionado().setParametroProdutoID(new ParametroProdutoID());

	    this.getVisao().setProdutoSelecionadoClonar(new ParametroProduto());
	    this.getVisao().getProdutoSelecionadoClonar().setParametroProdutoID(new ParametroProdutoID());

	    this.getVisao().setModalidadeProdutoSelecionada(new ParametroProduto());
	    this.getVisao().setModalidadeProdutoSelecionadaClonar(new ParametroProduto());

	    this.getVisao().setUnidadeGestora(new ParametroProdutoGestorProduto());

	    this.getVisao().setUnidadeGestoraSelecionada(new Unidade());
	    this.getVisao().getUnidadeGestoraSelecionada().setUnidadeID(new UnidadeID(0, 0));

	    this.getVisao().getProdutoSelecionado().getParametroProdutoID().setNuModalidade(0);
	    this.setStrModalidadeFormatada("");
	    this.getVisao().getProdutoSelecionado().setListaParametroGarantia(new ArrayList<ParametroGarantia>());
	    this.getVisao().setTemNomeModalidadePreenchido(Boolean.FALSE);
	    this.getVisao().setTemProdutoEModalidadeSelecionadosParaClonar(Boolean.FALSE);
	    this.getVisao().setListaProdutosTipoEmprestimo(this.getViewProdutoSiicoService().listarProdutosTipoEmprestimo());
	    this.limpaCamposDaTela();
	    this.getVisao().setCarregarTela(false);
	}

    }

    public String getStrModalidadeFormatada() {
	return this.strModalidadeFormatada;
    }

    public void setStrModalidadeFormatada(final String strModalidadeFormatada) {
	this.strModalidadeFormatada = strModalidadeFormatada;
    }

    private void limpaCamposDaTela() {

	this.setProdutoParaHomologar(new ParametroProduto());
	this.getProdutoParaHomologar().setParametroProdutoID(new ParametroProdutoID());
	this.getProdutoParaHomologar().setListaParametroGarantia(new ArrayList<ParametroGarantia>());

	this.getVisao().setProdutoSelecionadoClonar(new ParametroProduto());
	this.getVisao().getProdutoSelecionadoClonar().setParametroProdutoID(new ParametroProdutoID());

	this.getVisao().getProdutoSelecionado().getParametroProdutoID().setNuModalidade(0);
	this.getVisao().getProdutoSelecionado().setNoModalidade("");
	this.getVisao().setTemNomeModalidadePreenchido(Boolean.FALSE);
	this.getVisao().setTemProdutoEModalidadeSelecionadosParaClonar(Boolean.FALSE);
	this.getVisao().getProdutoSelecionado().setCoProdutoOrigem("");
	this.setStrModalidadeFormatada("");
	this.getVisao().getProdutoSelecionado().setListaParametroGarantia(new ArrayList<ParametroGarantia>());
	this.getVisao().getProdutoSelecionado().setProduto(new ViewProdutoSiico());

	this.getVisao().getProdutoSelecionado().setNoNormativo(null);

	// Clonar
	this.getVisao().setListaProdutosTipoEmprestimoClonar(new ArrayList<ViewProdutoSiico>());

	this.getVisao().setListaUnidadesGestoras(new ArrayList<ParametroProdutoGestorProduto>());
	this.getVisao().setListaUnidadesGestorasJaAssociadasAoProduto(new ArrayList<ParametroProdutoGestorProduto>());

	this.getVisao().setListaProdutosTipoGarantia(new ArrayList<ViewProdutoSiico>());

	this.getVisao().setEstaEmEdicao(Boolean.FALSE);
	this.getVisao().setEstaEmInclusao(Boolean.FALSE);
	this.getVisao().setEhProdutoClonado(Boolean.FALSE);

	this.idxGarantia = 0;
	this.setMensagemDeErroNaValidacaoCampo("");
	this.setPaginaJaFoiInicializada(Boolean.TRUE);

	setGarantiaSelecionada(new ParametroGarantia());

    }

    public void onTabChange(final TabChangeEvent event) {

	if (event.getTab().getId().equals("tbIncluirAlterarProduto")) {
	    this.paginaJaFoiInicializada = false;
	    this.carregar(false);
	} else if (event.getTab().getId().equals("tbHomologacao")) {
	    this.paginaJaFoiInicializada = true;
	    this.carregarProdutosParaHomologar();
	} else {
	    this.limpaCamposDaTela();
	}
    }

    /**
     * <p>
     * Método responsável por carregar os produtos que precisam ser homologados.
     * </p>
     */
    public void carregarProdutosParaHomologar() {
	this.carregarHomologar();
	this.listaProdutosParaHomologar = this.viewProdutoSiicoService.listarProdutosHomologacaoPendente();

	if (this.listaProdutosParaHomologar.isEmpty()) {
	    this.listaProdutosParaHomologar = new ArrayList<>();
	}
    }

    /**
     * <p>
     * Método responsável por selecionar o produto para ser homologado.
     * </p>
     */
    public void selecionarProdutoParaHomologar(final ViewProdutoSiico produtoSiico) {
	final ParametroProdutoID id = new ParametroProdutoID();
	id.setNuModalidade(Integer.parseInt(produtoSiico.getNuModalidade()));
	id.setNuProduto(produtoSiico.getProdutoSiicoID().getNuProduto());

	final ParametroProduto produtoCarregado = this.parametroProdutoService.obterParametroProdutoPorParametroProdutoID(id);

	this.populaListaDeUnidadesGestorasAssociadasAoProdutoHomologar(produtoCarregado);
	this.buscarGarantiasDoProdutoSelecionado(produtoCarregado, true);

	this.setProdutoParaHomologar(produtoCarregado);
	this.produtosBloqueio();
	this.produtosDesbloqueio();
    }

    /**
     * <p>
     * Método responsável por homologar o produto selecionado.
     * </p>
     */
    public void homologarProduto() {
	if (!getJustificativaHomologacao().isEmpty()) {
	    getGarantiaSelecionada().setDeHomologacao(getJustificativaHomologacao());
	    this.getVisao().setTemProdutoHomologado(Boolean.TRUE);
	    getGarantiaSelecionada().setIcHomologacao(!getGarantiaSelecionada().getIcHomologacao());
	    RequestContext.getCurrentInstance().execute("PF('mdlJustificativa').hide();");
	} else {
	    super.adicionaMensagemDeErro(ParametroProdutoMB.JUSTIFICATIVA_INVALIDA);
	}
    }

    public void limparJustificativa() {
	setJustificativaHomologacao(null);
    }

    /**
     * <p>
     * Método responsável por salvar a Homologação de um Produto.
     * </p>
     */
    public void salvarHomologacaoProduto() {
	int i = 1;
	for (final ParametroGarantia garantiaProduto : this.listaProdutosBloqueio) {
	    garantiaProduto.setNuOrdemBlouqueio(String.valueOf(i));
	    i++;
	}

	i = 1;
	// Acerta a ordem dos desbloqueios.
	for (final ParametroGarantia garantiaProduto : this.listaProdutosDesbloqueio) {
	    garantiaProduto.setNuOrdemDesbloqueio(String.valueOf(i));
	    i++;
	}

	// Salva as garantias.
	for (final ParametroGarantia garantia : this.produtoParaHomologar.getListaParametroGarantia()) {
	    this.parametroGarantiaService.salvar(garantia);
	}
	// Salva os produtos
	produtoParaHomologar.setCoMatricula(UsuarioUtil.getUsuarioLogado().getDeMatricula());
	this.parametroProdutoService.salvar(this.produtoParaHomologar);

	// Recarrega a lista produtos para Homologar.
	this.carregarProdutosParaHomologar();
	RequestContext.getCurrentInstance().execute("PF('mdlHomologarProduto').hide();");
    }

    /**
     * <p>
     * Método responsável por os dados de Forma de Bloqueio de uma Garantia.
     * </p>
     * 
     * @return SelectItem[] items - SelectItems das Formas de Bloqueio.
     */
    public SelectItem[] getFormasBloqueioGarantia() {
	final SelectItem[] items = new SelectItem[FormaBloqueioGarantiaEnum.values().length];
	int i = 0;
	for (final FormaBloqueioGarantiaEnum fbg : FormaBloqueioGarantiaEnum.values()) {
	    items[i++] = new SelectItem(fbg.getCodigo(), fbg.getNome());
	}
	return items;
    }

    /**
     * <p>
     * Método responsável por retornar o Nome da uma Forma de Bloqueio de
     * Garantia.
     * </p>
     * 
     * @param String
     *            codigo - Código da Forma de Bloqueio procurada.
     * @return String - Nome da Forma de Bloqueio de Garantia.
     */
    public String formaDeBloqueioGarantiaNome(final String codigo) {
	if (codigo != null && codigo.trim().length() == 1 && !codigo.equals("0")) {
	    return FormaBloqueioGarantiaEnum.obterEnumPorCodigo(codigo).getNome();
	} else {
	    this.setCampoComErro(true);
	    this.setMensagemDeErroNaValidacaoCampo("Forma de Bloqueio inválida !");
	    this.getVisao().setPodeSalvarProduto(Boolean.FALSE);
	    return "";
	}

    }

    /**
     * <p>
     * Método responsável por retornar o Ordem de Bloqueio de Garantia.
     * </p>
     * 
     * @param String
     *            codigo - Código da Ordem de Bloqueio procurada.
     * @return String - Nome da Ordem de Bloqueio de Garantia.
     */
    public String ordemDeBloqueioGarantiaNome(final String codigo) {
	if (codigo != null && codigo.trim().length() == 1 && !codigo.equals("0")) {
	    return OrdemBloqueioDesbloqueioGarantiaEnum.obterEnumPorCodigo(codigo).getNome();
	} else {
	    return "";
	}
    }

    /**
     * <p>
     * Método responsável por obter a lista de produtos na Ordem de Bloqueio.
     * </p>
     */
    private void produtosBloqueio() {
	final Map<Integer, ParametroGarantia> mapGarantias = new HashMap<>();
	int i = 0;
	for (final ParametroGarantia garantia : this.getProdutoParaHomologar().getListaParametroGarantia()) {
	    if (UtilObjeto.isReferencia(garantia.getNuOrdemBlouqueio())) {
		mapGarantias.put(Integer.parseInt(garantia.getNuOrdemBlouqueio().trim()), garantia);
	    } else {
		if (!mapGarantias.containsValue(garantia)) {
		    mapGarantias.put(i, garantia);
		    i++;
		}
	    }
	}
	this.setListaProdutosBloqueio(new ArrayList<ParametroGarantia>(mapGarantias.values()));
    }

    /**
     * <p>
     * Método responsável por obter a lista de produtos na Ordem de Bloqueio.
     * </p>
     * 
     * @return Collection listaProdutosBloqueio
     */
    public List<ParametroGarantia> getListaProdutosBloqueio() {
	return this.listaProdutosBloqueio;
    }

    /**
     * <p>
     * Método responsável por setar a listaProdutosBloqueio.
     * </p>
     * 
     * @param listaProdutosBloqueio
     */
    public void setListaProdutosBloqueio(final List<ParametroGarantia> listaProdutosBloqueio) {
	this.listaProdutosBloqueio = listaProdutosBloqueio;
    }

    /**
     * <p>
     * Método responsável por obter a lista de produtos na Ordem de Desbloqueio.
     * </p>
     * 
     * @return Collection listaProdutosDesbloqueio
     */
    public List<ParametroGarantia> getListaProdutosDesbloqueio() {
	return this.listaProdutosDesbloqueio;
    }

    /**
     * <p>
     * Método responsável por obter a lista de produtos na Ordem de Desbloqueio.
     * </p>
     * 
     */
    private void produtosDesbloqueio() {
	final Map<Integer, ParametroGarantia> mapGarantias = new HashMap<>();
	int i = 0;
	for (final ParametroGarantia garantia : this.getProdutoParaHomologar().getListaParametroGarantia()) {
	    if (UtilObjeto.isReferencia(garantia.getNuOrdemDesbloqueio())) {
		mapGarantias.put(Integer.parseInt(garantia.getNuOrdemDesbloqueio().trim()), garantia);
	    } else {
		if (!mapGarantias.containsValue(garantia)) {
		    mapGarantias.put(i, garantia);
		    i++;
		}
	    }
	}
	this.setListaProdutosDesbloqueio(new ArrayList<ParametroGarantia>(mapGarantias.values()));
    }

    /**
     * <p>
     * Método responsável por setar a listaProdutosDesbloqueio.
     * </p>
     * 
     * @param listaProdutosDesbloqueio
     */
    public void setListaProdutosDesbloqueio(final List<ParametroGarantia> listaProdutosDesbloqueio) {
	this.listaProdutosDesbloqueio = listaProdutosDesbloqueio;
    }

    /**
     * <p>
     * Método responsável por obter a lista de Garantias para um determinado
     * produto (ParametroProduto).
     * </p>
     * 
     * @param ParametroProduto
     *            produtoSelecionado - Produto selecionado na tela.
     */
    public void buscarGarantiasDoProdutoSelecionado(final ParametroProduto produtoSelecionado, final boolean ehHomologacao) {

	this.getVisao().setListaGarantiasJaAssociadasAoProduto(new ArrayList<ParametroGarantia>());

	final Collection<ParametroGarantia> garantiasAssociadasAoProduto = this.parametroGarantiaService
		.listarGarantiasPorProduto(produtoSelecionado);

	this.idxGarantia = 1;

	for (final ParametroGarantia parametroGarantia : garantiasAssociadasAoProduto) {
	    final Garantia garantia = this.garantiaService.obter(parametroGarantia.getNuGarantia());
	    parametroGarantia.setParametroProduto(produtoSelecionado);
	    parametroGarantia.setGarantia(garantia);
	    parametroGarantia.setInclusao(Boolean.FALSE);
	    if (parametroGarantia.getNuProdutoGarantia() != null && parametroGarantia.getNuProdutoGarantia() != 0) {
		final ViewProdutoSiico produtoSiico = this.viewProdutoSiicoService.obterProdutoPorCodigo(parametroGarantia.getNuProdutoGarantia());
		parametroGarantia.setProduto(produtoSiico);
	    }
	    parametroGarantia.setIdxGarantia(this.idxGarantia);
	    this.idxGarantia++;
	}

	produtoSelecionado.setListaParametroGarantia(new ArrayList<>(garantiasAssociadasAoProduto));

	if (!ehHomologacao) {

	    for (final ParametroGarantia garantiaEmMemoria : garantiasAssociadasAoProduto) {

		final ParametroGarantia persistedParametroGarantia = UtilObjeto.clone(garantiaEmMemoria);
		this.getVisao().getListaGarantiasJaAssociadasAoProduto().add(persistedParametroGarantia);
	    }
	}

    }

    /**
     * <p>
     * Método responsável por carregar as garantias de um produto clonado para o
     * produto em edição.
     * </p>
     * 
     * @param ParametroProduto
     *            produtoClonado - Produto clonada.
     */
    public void atribuirGarantiasDoProdutoClonado(ParametroProduto produtoClonado) {

	final ParametroProduto produtoNaTela = this.getVisao().getProdutoSelecionado();

	final List<ViewProdutoSiico> listaProdutosQuePodemSerGarantias = new ArrayList<>(
		this.viewProdutoSiicoService.listarProdutosTipoParametro(produtoNaTela));

	if (!listaProdutosQuePodemSerGarantias.isEmpty()) {
	    this.getVisao().setListaProdutosTipoGarantia(listaProdutosQuePodemSerGarantias);

	} else {
	    final RequestContext context = RequestContext.getCurrentInstance();
	    context.execute("PF('modalErroClonarProduto').show();");
	    return;
	}

	// Validar se o produto na tela tem a tabela associativa de garantias.
	produtoClonado = this.parametroProdutoService.obterParametroProdutoPorParametroProdutoID(produtoClonado.getParametroProdutoID());

	produtoNaTela.setNoModalidade(produtoClonado.getNoModalidade());
	this.getVisao().setTemNomeModalidadePreenchido(Boolean.TRUE);

	final Collection<ParametroGarantia> garantiasProdutoClonado = this.parametroGarantiaService.listarGarantiasPorProduto(produtoClonado);

	this.idxGarantia = 1;

	boolean temGarantiaInvalida = false;

	for (final ParametroGarantia parametroGarantia : garantiasProdutoClonado) {

	    final Garantia garantia = this.garantiaService.obter(parametroGarantia.getNuGarantia());
	    parametroGarantia.setParametroProduto(produtoNaTela);
	    parametroGarantia.setNuProduto(produtoNaTela.getParametroProdutoID().getNuProduto());

	    parametroGarantia.setNuModalidade(produtoNaTela.getParametroProdutoID().getNuModalidade());
	    parametroGarantia.setGarantia(garantia);
	    parametroGarantia.setInclusao(Boolean.TRUE);
	    parametroGarantia.setIcHomologacao(false);
	    parametroGarantia.setNuParametroGarantia(null);

	    final ViewProdutoSiico produtoSiico = this.viewProdutoSiicoService.obterProdutoPorCodigo(parametroGarantia.getNuProdutoGarantia());

	    // Verificar se o Produto que esta associado a garantia clonada
	    // existe na lista de produtos que podem ser garantia.
	    if (!listaProdutosQuePodemSerGarantias.contains(produtoSiico)) {

		final ViewProdutoSiico produtoSiicoEmpty = new ViewProdutoSiico();
		produtoSiicoEmpty.getProdutoSiicoID().setNuProduto(0);
		produtoSiicoEmpty.setNoProduto("");
		parametroGarantia.setProduto(produtoSiicoEmpty);
		parametroGarantia.setNuParametroGarantia(null);

		temGarantiaInvalida = true;

	    } else {

		parametroGarantia.setProduto(produtoSiico);
		parametroGarantia.setNuParametroGarantia(produtoSiico.getProdutoSiicoID().getNuProduto());
	    }

	    parametroGarantia.setIdxGarantia(this.idxGarantia);
	    this.idxGarantia++;

	}

	produtoNaTela.setListaParametroGarantia(new ArrayList<>(garantiasProdutoClonado));

	this.getVisao().setListaGarantiasJaAssociadasAoProduto(garantiasProdutoClonado);

	this.getVisao().setProdutoSelecionado(produtoNaTela);

	this.setaModoBotoesDeAcao(ParametroProdutoMB.MODO_INCLUSAO);

	this.getVisao().setPodeSalvarProduto(!temGarantiaInvalida);

    }

    /**
     * <p>
     * Método responsável por adicionar uma garantia a lista/tabela de
     * parâmetro.
     * </p>
     */
    public void adicionarGarantia() {

	this.idxGarantia++;
	this.carregarClonar();
	final ParametroGarantia garantia = new ParametroGarantia();

	garantia.setIdxGarantia(this.idxGarantia);
	garantia.setNuProduto(this.getVisao().getProdutoSelecionado().getParametroProdutoID().getNuProduto());
	garantia.setNuModalidade(this.getVisao().getProdutoSelecionado().getParametroProdutoID().getNuModalidade());

	final Garantia garantiaBacen = new Garantia();
	garantia.setGarantia(garantiaBacen);

	garantia.setParametroProduto(this.getVisao().getProdutoSelecionado());

	final ViewProdutoSiico produtoSiico = new ViewProdutoSiico();
	produtoSiico.getProdutoSiicoID().setNuProduto(0);
	produtoSiico.setNoProduto("");
	garantia.setProduto(produtoSiico);

	garantia.setInclusao(Boolean.TRUE);
	garantia.setNuProdutoGarantia(0);
	garantia.setQtdDiaPrazoMaximo(0);
	garantia.setQtdDiaPrazoMininmo(0);
	garantia.setVrMinimo(new BigDecimal("0.00"));
	garantia.setVrPercentualMinimo(new BigDecimal("0.00"));
	garantia.setVrPercentualMaximo(new BigDecimal("0.00"));
	garantia.setPcJuros(new BigDecimal("0.0"));
	garantia.setDhInicioPrazo(null);
	garantia.setDhFimPrazo(null);
	garantia.setIcHomologacao(false);
	garantia.setIcFormaBloqueio(null);
	garantia.setNuOrdemBlouqueio(String.valueOf(this.idxGarantia));
	garantia.setNuOrdemDesbloqueio(String.valueOf(this.idxGarantia));
	garantia.setSegmentos(new ArrayList<SegmentoCliente>());

	if (this.getVisao().getProdutoSelecionado().getListaParametroGarantia() == null) {
	    this.getVisao().getProdutoSelecionado().setListaParametroGarantia(new ArrayList<ParametroGarantia>());
	}

	this.getVisao().getProdutoSelecionado().getListaParametroGarantia().add(garantia);
    }

    /**
     * <p>
     * Método responsável por excluir uma garantia selecionada.
     * </p>
     */
    public void excluirGarantia(final Integer idxGarantia) {
	if (idxGarantia != null) {

	    for (final Iterator<ParametroGarantia> iterator = this.getVisao().getProdutoSelecionado().getListaParametroGarantia().iterator(); iterator
		    .hasNext();) {
		final ParametroGarantia garantia = iterator.next();
		if (garantia.getIdxGarantia().intValue() == idxGarantia.intValue()) {
		    iterator.remove();
		    this.getVisao().setPodeSalvarProduto(Boolean.TRUE);
		    break;
		}
	    }
	    if (this.getVisao().getProdutoSelecionado().getListaParametroGarantia() == null) {
		this.getVisao().setPodeSalvarProduto(Boolean.FALSE);
	    }
	}
    }

    /**
     * <p>
     * Método responsável por adicionar o Segmento selecionado a lista de
     * segmentos da garantia.
     * </p>
     * .
     *
     * @author f503697
     *
     */
    public void adicionarSegmento() {
	if (getSegmentoSelecionado() != null && getSegmentoSelecionado().getCoSegmentoCliente() != null) {
	    if (!getGarantiaSelecionada().getSegmentos().contains(getSegmentoSelecionado())) {
		getGarantiaSelecionada().getSegmentos().add(getSegmentoSelecionado());

		if (getGarantiaSelecionada().getSegmentosRemovidos().contains(getSegmentoSelecionado())) {
		    getGarantiaSelecionada().getSegmentosRemovidos().remove(getSegmentoSelecionado());
		}

		setSegmentoSelecionado(new SegmentoCliente());
	    } else {
		super.adicionaMensagemDeErro(ParametroProdutoMB.PORTE_DUPLICADO);
	    }
	} else {
	    super.adicionaMensagemDeErro(ParametroProdutoMB.PORTE_INVALIDO);
	}
    }

    /**
     * <p>
     * Método responsável por remover o Segmento selecionado da lista de
     * segmentos vinculados à garantia.
     * </p>
     * .
     *
     * @author f503697
     *
     */
    public void removerSegmento(SegmentoCliente segmentoCliente) {
	if (segmentoCliente != null && segmentoCliente.getCoSegmentoCliente() != null) {
	    getGarantiaSelecionada().getSegmentos().remove(segmentoCliente);
	    getGarantiaSelecionada().getSegmentosRemovidos().add(segmentoCliente);
	}
    }

    /**
     * <p>
     * Método responsável por Clonar um Produto.
     * </p>
     */
    public String clonarProdutoModalidade() {

	if ((this.getVisao().getProdutoSelecionado().getParametroProdutoID().getNuProduto().intValue() == this.getVisao()
		.getProdutoSelecionadoClonar().getParametroProdutoID().getNuProduto().intValue())
		&& (this.getVisao().getProdutoSelecionado().getParametroProdutoID().getNuModalidade().intValue() == this.getVisao()
			.getProdutoSelecionadoClonar().getParametroProdutoID().getNuModalidade().intValue())) {

	    final RequestContext context = RequestContext.getCurrentInstance();
	    context.execute("PF('modalErroClonarProduto').show();");
	    return "";

	} else {

	    this.atribuirGarantiasDoProdutoClonado(this.getVisao().getProdutoSelecionadoClonar());
	    this.getVisao().setEhProdutoClonado(Boolean.TRUE);
	    return "";

	}

    }

    /**
     * <p>
     * Método responsável por persistir e adicionar na tabela da modal de
     * UnidadeGestora.
     * </p>
     */
    public void incluirUnidadeGestora() {

	this.getVisao().setMsgErroUnidadeGestoraExistente(null);

	final Unidade unidade = this.unidadeService.obterUnidade(this.getVisao().getUnidadeGestoraSelecionada());

	if (unidade != null) {

	    // verifica se unidadeGestora já existe na tabela de Unidades
	    // Gestoras da tela.
	    boolean jaExisteEstaUnidadeAssociadaAoProduto = false;
	    for (final ParametroProdutoGestorProduto unidadeGestoraDoProduto : this.getVisao().getListaUnidadesGestoras()) {

		if (unidadeGestoraDoProduto.getParametroProdutoGestorProdutoID().getNuUnidade().intValue() == unidade.getUnidadeID().getNuUnidade()
			.intValue()
			&& unidadeGestoraDoProduto.getParametroProdutoGestorProdutoID().getNuNatural()
				.equals(unidade.getUnidadeID().getNuNatural())) {

		    jaExisteEstaUnidadeAssociadaAoProduto = true;
		    break;
		}
	    }
	    if (jaExisteEstaUnidadeAssociadaAoProduto) {
		final RequestContext context = RequestContext.getCurrentInstance();
		context.execute("PF('modalErroSalvarUnidadeGestora').show();");

	    } else {

		ParametroProdutoGestorProduto unidadeGestora = new ParametroProdutoGestorProduto();
		unidadeGestora.setParametroProdutoGestorProdutoID(new ParametroProdutoGestorProdutoID());
		unidadeGestora.setEhInclusao(true);
		unidadeGestora.getParametroProdutoGestorProdutoID()
			.setNuProduto(this.getVisao().getProdutoSelecionado().getParametroProdutoID().getNuProduto());
		unidadeGestora.getParametroProdutoGestorProdutoID()
			.setNuModalidade(this.getVisao().getProdutoSelecionado().getParametroProdutoID().getNuModalidade());
		unidadeGestora.getParametroProdutoGestorProdutoID().setNuUnidade(unidade.getUnidadeID().getNuUnidade());
		unidadeGestora.setNoUnidadeGestora(this.getNoUnidadeGestora(unidade.getSgUnidade(), unidade.getNoUnidade()));
		unidadeGestora.getParametroProdutoGestorProdutoID()
			.setNuNatural(unidade.getUnidadeID().getNuNatural() != null ? unidade.getUnidadeID().getNuNatural() : null);
		unidadeGestora.setIcGestorSiico(false);

		// Atualiza a lista de UnidadesGestoras no MB (visão)
		this.getVisao().getListaUnidadesGestoras().add(unidadeGestora);
	    }

	    final Unidade novaUnidade = new Unidade();
	    novaUnidade.setUnidadeID(new UnidadeID(0, 0));
	    this.getVisao().setUnidadeGestoraSelecionada(novaUnidade);

	}

    }

    /**
     * <p>
     * Método responsável por retornar o nome da unidade gestora.
     * <p>
     *
     * @param sigla
     *            - sigla da unidade gestora
     * @param nome
     *            - nome da unidade gestora
     * @return
     * @author gerusa.soares
     */
    private String getNoUnidadeGestora(final String sigla, final String nome) {
	return !UtilString.isVazio(sigla) ? (sigla + " - " + nome) : nome;
    }

    /**
     * <p>
     * Método responsável por formatar números nas tabelas com três digitos.
     * </p>
     */
    public String showFormattedNumberColumn(final Object value) {
	try {
	    if (value != null) {
		return String.format("%03d", Integer.parseInt(value.toString()));
	    } else {
		return "";
	    }
	} catch (final Exception e) {
	    LogCEF.debug(e);
	    return value.toString();
	}

    }

    /**
     * <p>
     * Método responsável por formatar números nas tabelas com quatro digitos.
     * </p>
     */
    public String showFormattedNumberColumn4Digits(final Object value) {
	try {
	    if (value != null) {
		return String.format("%04d", Integer.parseInt(value.toString()));
	    } else {
		return "";
	    }
	} catch (final Exception e) {
	    LogCEF.debug(e);
	    return value.toString();
	}
    }

    /**
     * Retorna a lista SN.
     *
     * @return listaSN
     */
    public List<SelectItem> getListaSN() {
	return this.listaSN;
    }

    /**
     * Define o valor da lista SN.
     *
     * @param listaSN
     *            valor a ser atribuído
     */
    public void setListaSN(final List<SelectItem> listaSN) {
	this.listaSN = listaSN;
    }

    /**
     * <p>
     * Método responsável pela exclusão de uma UnidadeGestora da tela.
     * 
     * </p>
     */
    public void validarExclusaoUnidadeGestoraSelecionada(final ParametroProdutoGestorProduto unidadeParaExcluir) {

	this.getVisao().getListaUnidadesGestoras().remove(unidadeParaExcluir);

    }

    /**
     * <p>
     * Método responsável por excluir uma Unidade Gestora.
     * </p>
     */
    public void excluirUnidadeGestora() {
	this.parametroProdutoUnidadeGestoraService.remover(this.getUnidadeParaExcluir());
	// Recarrega a Listagem:
	this.getVisao().setListaUnidadesGestoras(
		this.parametroProdutoUnidadeGestoraService.listarUnidades(this.getVisao().getProdutoSelecionado().getParametroProdutoID()));
    }

    /**
     * <p>
     * Método responsável por inicializar uma edição de uma UnidadeGestora na
     * tabela de unidades gestoras.
     * </p>
     */
    public void onRowUnidadeGestoraEditInit(final RowEditEvent event) {
	final ParametroProdutoGestorProduto unidadeEditada = (ParametroProdutoGestorProduto) event.getObject();
	unidadeEditada.setStrGestorSiico(unidadeEditada.isIcGestorSiico() ? "true" : "false");
    }

    /**
     * <p>
     * Método responsável por editar uma UnidadeGestora e salvar no banco de
     * dados.
     * </p>
     */
    public void onRowUnidadeGestoraEdit(final RowEditEvent event) {
	final ParametroProdutoGestorProduto unidadeEditada = (ParametroProdutoGestorProduto) event.getObject();
	// verifica se unidadeGestora já existe no banco de dados/tabela.
	boolean jaExisteNaListagem = false;
	for (final ParametroProdutoGestorProduto g : this.getVisao().getListaUnidadesGestoras()) {
	    if (g.getParametroProdutoGestorProdutoID().getNuUnidade() == unidadeEditada.getParametroProdutoGestorProdutoID().getNuUnidade()
		    && !g.getNoUnidadeGestora().equals(unidadeEditada.getNoUnidadeGestora())) {
		jaExisteNaListagem = true;
		break;
	    }
	    if (g.getParametroProdutoGestorProdutoID().getNuUnidade() != unidadeEditada.getParametroProdutoGestorProdutoID().getNuUnidade()
		    && g.getNoUnidadeGestora().equals(unidadeEditada.getNoUnidadeGestora())) {
		jaExisteNaListagem = true;
		break;
	    }
	}
	if (jaExisteNaListagem) {
	    final RequestContext context = RequestContext.getCurrentInstance();
	    context.execute("PF('modalErroSalvarUnidadeGestora').show();");
	} else {
	    // Persiste a Unidade Gestora Editada.
	    this.parametroProdutoUnidadeGestoraService.salvar(unidadeEditada);
	}
	// Recarrega a Listagem:
	this.getVisao().setListaUnidadesGestoras(
		this.parametroProdutoUnidadeGestoraService.listarUnidades(this.getVisao().getProdutoSelecionado().getParametroProdutoID()));
    }

    /**
     * <p>
     * Método responsável por cancelar uma edição de Unidade Gestora.
     * </p>
     */
    public void onRowUnidadeGestoraCancel(final RowEditEvent event) {
	event.getObject();
    }

    /**
     * <p>
     * Método responsável por Carregar os dados de garantias quando a modal de
     * modalidades for fechada.
     * </p>
     */
    public void loadTabelaGarantias() {
		this.prepareNewModalidade();
		this.getVisao().setListaModalidades(this.parametroProdutoService.listarParametroProdutos());
		this.getVisao().setListaUnidadesGestoras(this.parametroProdutoUnidadeGestoraService.listarUnidades(this.getVisao().getProdutoSelecionado().getParametroProdutoID()));
		this.getVisao().setTemProdutoSelecionado(Boolean.TRUE);
    }

    public Collection<ViewProdutoSiico> autoCompleteProduto(final String produto) {
		limpaCamposDaTela();
		setSegmentos(this.segmentoClienteService.listarPorNomeCodigo(""));
		setGarantiaSelecionada(new ParametroGarantia());
		this.getVisao().setTemProdutoSelecionado(Boolean.FALSE);
		return this.viewProdutoSiicoService.listaAutoComplete(produto);
    }
   
    public Collection<ViewProdutoSiico> autoCompleteGarantiaCaixa(final String produto) {
    	return this.viewProdutoSiicoService.listaAutoComplete(produto);
    }

    public void onSelectProduto() {
		this.limpaCamposDaTela();
		Collection<Unidade> unidades = this.unidadeService.listarUnidades();
		this.getVisao().setTemProdutoSelecionado(Boolean.TRUE);
		this.getVisao().setListaUnidadesSiico(unidades);
		if (!UtilString.isVazio(this.getVisao().getProdutoSelecionado().getAutoComplete())) {
		    String[] retornoSplit = this.getVisao().getProdutoSelecionado().getAutoComplete().split(" ");
		    this.getVisao().getProdutoSelecionado().getParametroProdutoID().setNuProduto(Integer.parseInt(retornoSplit[0]));
		}
		if (this.getVisao().getProdutoSelecionado().getParametroProdutoID().getNuProduto() != null) {
		    this.buscaNoBancoDeDadosSeJaExisteEsseProdutoCadastrado(this.getVisao().getProdutoSelecionado());
		}
    }

    private void buscaNoBancoDeDadosSeJaExisteEsseProdutoCadastrado(final ParametroProduto produtoSelecionado) {
		final Collection<ParametroProduto> produtosEncontrados = this.parametroProdutoService.obterParametroProdutoPorCodigo(produtoSelecionado.getParametroProdutoID().getNuProduto());
	
		if (produtosEncontrados.isEmpty()) {
		    this.setStrModalidadeFormatada("0000");
		    this.getVisao().getProdutoSelecionado().setNoModalidade("Normal");	
		    produtoSelecionado.setCoProdutoOrigem(this.showFormattedNumberColumn(produtoSelecionado.getParametroProdutoID().getNuProduto()));	
		    this.buscarProdutoNoBancoDeDados(this.getVisao().getProdutoSelecionado());
		    this.setaModoBotoesDeAcao(MODO_INCLUSAO);
		}
    }

    /**
     * <p>
     * Método executado quando perde o foco do campo de código de Modalidade.
     * </p>
     * 
     * @param evento
     */
    public void getSelectModalidade() {
	if (!UtilString.isVazio(this.getStrModalidadeFormatada())) {
	    this.strModalidadeFormatada = this.showFormattedNumberColumn4Digits(this.getStrModalidadeFormatada());
	    final Integer nuModalidade = Integer.parseInt(this.getStrModalidadeFormatada());
	    this.getVisao().getModalidadeProdutoSelecionada().setParametroProdutoID(
		    new ParametroProdutoID(this.getVisao().getProdutoSelecionado().getParametroProdutoID().getNuProduto(), nuModalidade));
	    this.buscarProdutoNoBancoDeDados(this.getVisao().getProdutoSelecionado());
	}

    }

    /**
     * <p>
     * Método executado quando perde o foco do campo de nome de Modalidade.
     * </p>
     * 
     * @param evento
     */
    public void getSelectNomeModalidade() {
	this.getVisao().setTemNomeModalidadePreenchido(!UtilString.isVazio(this.getVisao().getProdutoSelecionado().getNoModalidade()));
    }

    /**
     * <p>
     * Método executado quando a combo de ProdutoClonar é selecionado.
     * </p>
     * 
     * @param evento
     */
    public void onSelectProdutoClonar() {

	if (this.getVisao().getProdutoSelecionadoClonar().getParametroProdutoID().getNuProduto() != null) {
	    this.disableModalidadeClonar = false;
	    this.listModalidadesClonar = this.getVisao().getMapProdutoPorModalidade()
		    .get(new NumberNameVO(this.getVisao().getProdutoSelecionadoClonar().getParametroProdutoID().getNuProduto(), null));

	    // this.getVisao().getListaModalidadesClonar().clear();

	    // Descobre as modalidades associadas ao produto selecionado
	    // final List<ParametroProduto> listaProdutos = new
	    // ArrayList<>(this.parametroProdutoService.obterParametroProdutoPorCodigo(this.getVisao()
	    // .getProdutoSelecionadoClonar().getParametroProdutoID().getNuProduto()));
	    // final List<ParametroProduto>
	    // listaModalidadesEncontradasParaProduto = new
	    // ArrayList<ParametroProduto>();
	    //
	    // if (listaProdutos != null) {
	    //
	    // for (final ParametroProduto parametroProduto : listaProdutos) {
	    //
	    // final ParametroProduto modalidade = new ParametroProduto();
	    // modalidade.setParametroProdutoID(parametroProduto.getParametroProdutoID());
	    // modalidade.setNoModalidade(parametroProduto.getNoModalidade());
	    //
	    // if (!listaModalidadesEncontradasParaProduto.contains(modalidade))
	    // {
	    //
	    // listaModalidadesEncontradasParaProduto.add(modalidade);
	    // }
	    // }
	    //
	    // }
	    //
	    // this.getVisao().getListaModalidadesClonar().addAll(listaModalidadesEncontradasParaProduto);
	}
	//
    }

    /**
     * <p>
     * Método executado quando a combo de Modalidade é selecionada.
     * </p>
     * 
     * @param evento
     */
    public void onSelectModalidade() {
	this.getVisao().setUnidadeGestoraSelecionada(this.getVisao().getUnidadeGestoraSelecionada());
    }

    /**
     * <p>
     * Método executado quando a combo de ModalidadeClonar é selecionado.
     * </p>
     * 
     * @param evento
     */
    public void onSelectModalidadeClonar() {
	if (this.getVisao().getProdutoSelecionadoClonar().getParametroProdutoID().getNuProduto() != null
		&& this.getVisao().getProdutoSelecionadoClonar().getParametroProdutoID().getNuModalidade() != null) {

	    this.getVisao().setTemProdutoEModalidadeSelecionadosParaClonar(Boolean.TRUE);
	}
    }

    /**
     * <p>
     * Método executado quando o combo de Garantia é selecionado na tabela de
     * edição.
     * </p>
     * 
     * @param evento
     */
    public void onSelectGarantiaBacen(final AjaxBehaviorEvent event) {
	((UIOutput) event.getSource()).getValue();
    }

    /**
     * <p>
     * Método responsável por tratar o evento de edição em uma linha na tabela
     * de garantias.
     * </p>
     * 
     * @param event
     *            - Evento de Edição de uma linha na tabela de Garantias.
     */
    public void onCellEdit(final CellEditEvent event) {
	final ParametroGarantia paramtroGarantiaEditada = (ParametroGarantia) ((DataTable) event.getComponent()).getRowData();

	final Object newValue = event.getNewValue();

	final String idColunaSelecionada = event.getColumn().getClientId();

	if (idColunaSelecionada.contains("colunaGarantiaData")) {
	    if (Integer.parseInt(newValue.toString()) == 0) {
		this.getVisao().setPodeSalvarProduto(Boolean.FALSE);
		this.setCampoComErro(true);
		this.setMensagemDeErroNaValidacaoCampo("Garantia BACEN informada é inválida !");
	    } else {
		final Garantia garantia = this.garantiaService.obter(Integer.parseInt(newValue.toString()));
		paramtroGarantiaEditada.setGarantia(garantia);
		paramtroGarantiaEditada.setNuGarantia(garantia.getNuGarantia());

	    }
	} else if (idColunaSelecionada.contains("colunaAplicacaoData")) {
	    if (Integer.parseInt(newValue.toString()) == 0) {
		this.getVisao().setPodeSalvarProduto(Boolean.FALSE);
		this.setCampoComErro(true);
		this.setMensagemDeErroNaValidacaoCampo("Garantia informada é inválida !");
	    } else {
		ViewProdutoSiico novoProduto = null;
		final Integer novoProdutoSelecionado = Integer.parseInt(newValue.toString());
		for (final ViewProdutoSiico produtoGarantia : this.getVisao().getListaProdutosTipoGarantia()) {
		    if (produtoGarantia.getProdutoSiicoID().getNuProduto().intValue() == novoProdutoSelecionado.intValue()) {
			novoProduto = produtoGarantia;
			break;
		    }
		}
		paramtroGarantiaEditada.setProduto(novoProduto);
		paramtroGarantiaEditada.setNuProdutoGarantia(novoProduto.getProdutoSiicoID().getNuProduto());
	    }

	} else if (idColunaSelecionada.contains("colunaVrPrazoMinimoData")) {
	    if (paramtroGarantiaEditada.getQtdDiaPrazoMaximo() < Integer.parseInt(newValue.toString())) {
		this.getVisao().setPodeSalvarProduto(Boolean.FALSE);
		this.setCampoComErro(true);
		this.setMensagemDeErroNaValidacaoCampo("Prazo Mínimo informado é inválido, para a linha editada !");
	    } else {
		this.setCampoComErro(false);
		this.setMensagemDeErroNaValidacaoCampo("");
	    }
	} else if (idColunaSelecionada.contains("colunaVrPrazoMaximoData")) {
	    if (paramtroGarantiaEditada.getQtdDiaPrazoMininmo() > Integer.parseInt(newValue.toString())) {
		this.getVisao().setPodeSalvarProduto(Boolean.FALSE);
		this.setCampoComErro(true);
		this.setMensagemDeErroNaValidacaoCampo("Prazo Máximo informado é inválido, para a linha editada !");
	    } else {
		this.setCampoComErro(false);
		this.setMensagemDeErroNaValidacaoCampo("");
	    }

	} else if (idColunaSelecionada.contains("colunaVrMaximoData")) {
	    if (paramtroGarantiaEditada.getVrMinimo().compareTo(new BigDecimal(newValue.toString())) > 0) {
		this.getVisao().setPodeSalvarProduto(Boolean.FALSE);
		this.setCampoComErro(true);
		this.setMensagemDeErroNaValidacaoCampo("Valor Máximo informado é inválido, para a linha editada !");
	    } else {
		this.setCampoComErro(false);
		this.setMensagemDeErroNaValidacaoCampo("");
	    }
	} else if (idColunaSelecionada.contains("colunaVrMinimocontrato")) {
	    if (paramtroGarantiaEditada.getVrMinimoContrato().compareTo(new BigDecimal(newValue.toString())) < 0) {
		this.getVisao().setPodeSalvarProduto(Boolean.FALSE);
		this.setCampoComErro(true);
		this.setMensagemDeErroNaValidacaoCampo("Valor Mínimo (Contrato) informado é inválido, para a linha editada !");
	    } else {
		this.setCampoComErro(false);
		this.setMensagemDeErroNaValidacaoCampo("");
	    }
	} else if (idColunaSelecionada.contains("colunaVrMaximoContrato")) {
	    if (paramtroGarantiaEditada.getVrMaximoContrato().compareTo(new BigDecimal(newValue.toString())) < 0) {
		this.getVisao().setPodeSalvarProduto(Boolean.FALSE);
		this.setCampoComErro(true);
		this.setMensagemDeErroNaValidacaoCampo("Valor Máximo (Contrato) informado é inválido, para a linha editada !");
	    } else {
		this.setCampoComErro(false);
		this.setMensagemDeErroNaValidacaoCampo("");
	    }

	} else if (idColunaSelecionada.contains("colunaVrPercentualMinimoData")) {
	    if (paramtroGarantiaEditada.getVrPercentualMaximo().compareTo(new BigDecimal(newValue.toString())) < 0) {
		this.getVisao().setPodeSalvarProduto(Boolean.FALSE);
		this.setCampoComErro(true);
		this.setMensagemDeErroNaValidacaoCampo("Percentual Mínimo informado é inválido, para a linha editada !");
	    } else {
		this.setCampoComErro(false);
		this.setMensagemDeErroNaValidacaoCampo("");
	    }
	} else if (idColunaSelecionada.contains("colunaVrPercentualMaximoData")) {
	    if (paramtroGarantiaEditada.getVrPercentualMinimo().compareTo(new BigDecimal(newValue.toString())) > 0) {
		this.getVisao().setPodeSalvarProduto(Boolean.FALSE);
		this.setCampoComErro(true);
		this.setMensagemDeErroNaValidacaoCampo("Percentual Máximo informado é inválido, para a linha editada !");
	    } else {
		this.setCampoComErro(false);
		this.setMensagemDeErroNaValidacaoCampo("");
	    }
	}
	if (paramtroGarantiaEditada.getGarantia() != null && paramtroGarantiaEditada.getGarantia().getNuGarantia() == 0) {
	    this.setCampoComErro(true);
	    this.setMensagemDeErroNaValidacaoCampo("A Garantia BACEN informada é inválida, para a linha editada !");
	    this.getVisao().setPodeSalvarProduto(Boolean.FALSE);
	    return;
	}

	if (paramtroGarantiaEditada.getQtdDiaPrazoMininmo().intValue() > paramtroGarantiaEditada.getQtdDiaPrazoMaximo().intValue()) {
	    this.setCampoComErro(true);
	    this.setMensagemDeErroNaValidacaoCampo("Prazo Mínimo informado é maior que o Prazo Máximo, para a linha editada !");
	    this.getVisao().setPodeSalvarProduto(Boolean.FALSE);
	    return;
	}
	if (paramtroGarantiaEditada.getVrMinimoContrato().compareTo(paramtroGarantiaEditada.getVrMaximoContrato()) > 0) {
	    this.setCampoComErro(true);
	    this.setMensagemDeErroNaValidacaoCampo("Valor Mínimo (Contrato) informado é maior que o Valor Máximo (Contrato), para a linha editada !");
	    this.getVisao().setPodeSalvarProduto(Boolean.FALSE);
	    return;
	}

	if (paramtroGarantiaEditada.getDhInicioPrazo() != null && paramtroGarantiaEditada.getDhFimPrazo() != null) {
	    if (paramtroGarantiaEditada.getDhFimPrazo().before(paramtroGarantiaEditada.getDhInicioPrazo())) {
		this.setCampoComErro(true);
		this.setMensagemDeErroNaValidacaoCampo("Período Inicial deve ser inferior ao Período Final!");
		this.getVisao().setPodeSalvarProduto(Boolean.FALSE);
		return;
	    }
	}

	if (paramtroGarantiaEditada.getVrPercentualMinimo().compareTo(paramtroGarantiaEditada.getVrPercentualMaximo()) > 0) {
	    this.setCampoComErro(true);
	    this.setMensagemDeErroNaValidacaoCampo("Percentual Mínimo informado é maior que o Percentual Máximo, para a linha editada !");
	    this.getVisao().setPodeSalvarProduto(Boolean.FALSE);
	    return;
	}

	if (paramtroGarantiaEditada.getIcFormaBloqueio() == null || paramtroGarantiaEditada.getIcFormaBloqueio().equals("0")) {
	    this.setCampoComErro(true);
	    this.setMensagemDeErroNaValidacaoCampo("Forma de Bloqueio precisa ser informada, para a linha editada !");
	    this.getVisao().setPodeSalvarProduto(Boolean.FALSE);
	    return;
	}
	final Collection<ParametroGarantia> produtosParaProcurar = this.getVisao().getProdutoSelecionado().getListaParametroGarantia();
	if (produtosParaProcurar.size() > 1) {
	    boolean podeFiltrar = false;
	    if (paramtroGarantiaEditada.getGarantia() != null) {
		if (paramtroGarantiaEditada.getProduto().getProdutoSiicoID().getNuProduto() != null && paramtroGarantiaEditada.getIcFormaBloqueio() != null) {
		    podeFiltrar = true;
		}
	    }
	    if (podeFiltrar) {
		final List<ParametroGarantia> encontrados = new ArrayList<>();
		for (final ParametroGarantia procurado : produtosParaProcurar) {
		    try {
			if ((procurado.getGarantia().getNuGarantia() == paramtroGarantiaEditada.getGarantia().getNuGarantia())
				&& procurado.getNuProdutoGarantia().intValue() == paramtroGarantiaEditada.getNuProdutoGarantia().intValue()
				&& procurado.getIcFormaBloqueio().equals(paramtroGarantiaEditada.getIcFormaBloqueio())
				&& procurado.getIdxGarantia().intValue() != paramtroGarantiaEditada.getIdxGarantia().intValue()) {
			    encontrados.add(procurado);
			}
		    } catch (final Exception e) {
			LogCEF.debug(e);
		    }

		}
		if (!encontrados.isEmpty()) {
		    for (final ParametroGarantia encontrado : encontrados) {
			if (!(encontrado.getQtdDiaPrazoMininmo().intValue() <= paramtroGarantiaEditada.getQtdDiaPrazoMininmo().intValue())) {
			    this.setCampoComErro(true);
			    this.setMensagemDeErroNaValidacaoCampo(
				    "Para itens com a mesma Garantia BACEN e a mesma Garantia os prazos devem ser sequenciais !");
			    this.getVisao().setPodeSalvarProduto(Boolean.FALSE);
			    return;
			}
		    }
		}
	    }
	    for (final ParametroGarantia garantiaParaValidar : produtosParaProcurar) {
		if (garantiaParaValidar.getGarantia() != null) {
		    if (garantiaParaValidar.getGarantia().getNuGarantia() == 0) {
			this.setCampoComErro(true);
			this.setMensagemDeErroNaValidacaoCampo(
				"A Garantia BACEN informada é inválida em alguma linha da tabela, por favor verifique !");
			this.getVisao().setPodeSalvarProduto(Boolean.FALSE);
			return;
		    }
		}

		if (garantiaParaValidar.getQtdDiaPrazoMininmo().intValue() > garantiaParaValidar.getQtdDiaPrazoMaximo().intValue()) {
		    this.setCampoComErro(true);
		    this.setMensagemDeErroNaValidacaoCampo(
			    "Prazo Mínimo informado é maior que o Prazo Máximo em alguma linha da tabela, por favor verifique !");
		    this.getVisao().setPodeSalvarProduto(Boolean.FALSE);
		    return;
		}
		if (garantiaParaValidar.getVrPercentualMinimo().compareTo(garantiaParaValidar.getVrPercentualMaximo()) > 0) {
		    this.setCampoComErro(true);
		    this.setMensagemDeErroNaValidacaoCampo(
			    "Percentual Mínimo informado é maior que o Percentual Máximo em alguma linha da tabela, por favor verifique !");
		    this.getVisao().setPodeSalvarProduto(Boolean.FALSE);
		    return;
		}

		if (garantiaParaValidar.getIcFormaBloqueio() == null) {
		    this.setCampoComErro(true);
		    this.setMensagemDeErroNaValidacaoCampo(
			    "Forma de Bloqueio precisa ser informada em alguma linha da tabela, por favor verifique !");
		    this.getVisao().setPodeSalvarProduto(Boolean.FALSE);
		    return;
		}
	    }
	}

	this.setCampoComErro(false);
	this.setMensagemDeErroNaValidacaoCampo("");

	if (!UtilString.isVazio(this.getVisao().getProdutoSelecionado().getNoModalidade())) {
	    this.getVisao().setTemNomeModalidadePreenchido(Boolean.TRUE);
	    this.getVisao().setPodeSalvarProduto(Boolean.TRUE);
	} else {
	    this.getVisao().setTemNomeModalidadePreenchido(Boolean.FALSE);
	    this.getVisao().setPodeSalvarProduto(Boolean.FALSE);
	}
    }

    /**
     * <p>
     * Método executado quando a combo de Produto Parametro é selecionado na
     * tabela em edição.
     * </p>
     * 
     * @param evento
     */
    public void onSelectProdutoParametro(final AjaxBehaviorEvent event) {
	((UIOutput) event.getSource()).getValue();
    }

    /**
     * <p>
     * Método reponsável por carregar do banco de dados as informações de um
     * Produto, baseado no Produto Siico selecionado no combo.
     * </p>
     *
     * @param produtoSelecionadoNoCombo
     *            valor a ser pesquisado.
     */
    private void buscarProdutoNoBancoDeDados(final ParametroProduto produtoSelecionadoNoCombo) {

	// Se possuí Produto e Modalidades selecionados.
	if (this.validaSelecaoProdutoModalidade(produtoSelecionadoNoCombo)) {

	    produtoSelecionadoNoCombo.getParametroProdutoID().setNuModalidade(Integer.parseInt(this.getStrModalidadeFormatada()));

	    // Busca a lista de Garantias(Produtos Siico) que estão habilitados
	    // para serem utilizados como garantia para o Produto selecionado no
	    // combo de Acordo com produto de credito e modalidade Selecionada.
	    this.getVisao().setListaProdutosTipoGarantia(this.viewProdutoSiicoService.listarProdutosTipoParametro(produtoSelecionadoNoCombo));

	    this.getVisao().setListaProdutosTipoGarantia(this.viewProdutoSiicoService.listarProdutosTipoParametroProduto(produtoSelecionadoNoCombo));

	    final ParametroProduto parametroProdutoDoRepositorio = this.parametroProdutoService
		    .obterParametroProdutoPorParametroProdutoID(produtoSelecionadoNoCombo.getParametroProdutoID());

	    // Produto não existe na base do SIACG
	    if (parametroProdutoDoRepositorio == null) {

		// prepara o novo produto SIACG.
		produtoSelecionadoNoCombo
			.setCoProdutoOrigem(this.showFormattedNumberColumn(produtoSelecionadoNoCombo.getParametroProdutoID().getNuProduto()));
		this.populaListaDeUnidadesGestorasAssociadasAoProduto(produtoSelecionadoNoCombo, ParametroProdutoMB.OPERACAO_INCLUSAO);

		final String noModalide = this.getStrModalidadeFormatada().equals("0000") ? "Normal" : "";
		produtoSelecionadoNoCombo.setNoModalidade(noModalide);

		this.getVisao().setPodeSalvarProduto(Boolean.FALSE);

		this.getVisao().setProdutoSelecionado(produtoSelecionadoNoCombo);

		this.setaModoBotoesDeAcao(ParametroProdutoMB.MODO_INCLUSAO);

	    } else {
		if (UtilString.isVazio(parametroProdutoDoRepositorio.getCoProdutoOrigem())) {
		    produtoSelecionadoNoCombo.setCoProdutoOrigem(
			    this.showFormattedNumberColumn4Digits(produtoSelecionadoNoCombo.getParametroProdutoID().getNuProduto()));
		} else {
		    produtoSelecionadoNoCombo
			    .setCoProdutoOrigem(this.showFormattedNumberColumn4Digits(parametroProdutoDoRepositorio.getCoProdutoOrigem()));
		}

		if (!UtilString.isVazio(parametroProdutoDoRepositorio.getNoModalidade())) {
		    produtoSelecionadoNoCombo.setNoModalidade(parametroProdutoDoRepositorio.getNoModalidade());
		}

		this.getVisao().setTemNomeModalidadePreenchido(Boolean.TRUE);

		produtoSelecionadoNoCombo.setIcAceitaGarantiaTerceiro(parametroProdutoDoRepositorio.getIcAceitaGarantiaTerceiro());
		produtoSelecionadoNoCombo.setNoNormativo(parametroProdutoDoRepositorio.getNoNormativo());

		// É uma edição de Produto, então carrega a lista de
		// ParametroGarantias e a lista de ParametroProdutoGestorProduto
		// (Unidades Gestoras).
		this.populaListaDeUnidadesGestorasAssociadasAoProduto(produtoSelecionadoNoCombo, !ParametroProdutoMB.OPERACAO_INCLUSAO);

		// Busca as garantias (ParametroGarantia) associados ao produto.
		this.buscarGarantiasDoProdutoSelecionado(produtoSelecionadoNoCombo, !ParametroProdutoMB.OPERACAO_INCLUSAO);

		// buscas nos contratos se existe um parametroProduto associado.
		this.getVisao().setTemContratoAssociado(this.contratoService.existe(produtoSelecionadoNoCombo));

		this.getVisao().setProdutoSelecionado(produtoSelecionadoNoCombo);

		this.setaModoBotoesDeAcao(ParametroProdutoMB.MODO_ALTERACAO);

	    }
	} else {
	    // Não tem ParametroProduto (Produto) e Modalidade informados !

	    // Limpa os dados da tela caso já tenham sido preenchidos
	    final ParametroProduto parametroProdutoLimpo = new ParametroProduto();
	    parametroProdutoLimpo.setParametroProdutoID(produtoSelecionadoNoCombo.getParametroProdutoID());
	    parametroProdutoLimpo.setProduto(new ViewProdutoSiico());
	    parametroProdutoLimpo.setCoProdutoOrigem(this.showFormattedNumberColumn(parametroProdutoLimpo.getParametroProdutoID().getNuProduto()));

	    // Limpa as listas em memória.
	    this.getVisao().setListaUnidadesGestoras(new ArrayList<ParametroProdutoGestorProduto>());
	    this.getVisao().setListaProdutosTipoGarantia(new ArrayList<ViewProdutoSiico>());

	    this.getVisao().setProdutoSelecionado(parametroProdutoLimpo);

	    this.setaModoBotoesDeAcao(ParametroProdutoMB.MODO_ERRO);

	    // Exibe a Mensagem de erro.
	    super.adicionaMensagemDeErro(ParametroProdutoMB.PRODUTO_MODALIDADE_INVALIDO);
	}

    }

    /**
     * <p>
     * Método reponsável por carregar do banco de dados do Siico e do SIACG as
     * Unidades Gestoras associadas a um produto (ParametroProduto).
     * </p>
     *
     * @param produtoSelecionadoNoCombo
     *            valor a ser pesquisado.
     * @param ehInclusao
     *            Se é uma inclusão ou não.
     */
    private void populaListaDeUnidadesGestorasAssociadasAoProduto(final ParametroProduto produtoSelecionadoNoCombo, final boolean ehInclusao) {

	// Encontra as Unidades Gestoras já persistidas para o Produto que não
	// são Siico.
	final Collection<ParametroProdutoGestorProduto> listaUnidadesGestorasNaoSiicoEncontradas = this.parametroProdutoUnidadeGestoraService
		.listarUnidades(produtoSelecionadoNoCombo.getParametroProdutoID());

	// Vai buscar o nome da Unidade no Siico
	for (final ParametroProdutoGestorProduto unidadesGestoraNaoSiicoEncontrada : listaUnidadesGestorasNaoSiicoEncontradas) {

	    final String siglaUnidade = this.unidadeService
		    .obterSiglaUnidadePorNuUnidade(unidadesGestoraNaoSiicoEncontrada.getParametroProdutoGestorProdutoID().getNuUnidade());
	    final String nomeUnidade = this.unidadeService
		    .getNomeUnidade(unidadesGestoraNaoSiicoEncontrada.getParametroProdutoGestorProdutoID().getNuUnidade());

	    unidadesGestoraNaoSiicoEncontrada.setNoUnidadeGestora(this.getNoUnidadeGestora(siglaUnidade, nomeUnidade));
	}

	this.getVisao().setListaUnidadesGestoras(listaUnidadesGestorasNaoSiicoEncontradas);

	final Collection<ViewProdutoSiico> produtosSiicoEncontrados = this.viewProdutoSiicoService
		.listarProdutosTipoEmprestimoPorNuProduto(produtoSelecionadoNoCombo.getParametroProdutoID().getNuProduto());

	boolean jaCopiouDadosSiico = false;

	produtoSelecionadoNoCombo.setProduto(new ViewProdutoSiico());

	for (final ViewProdutoSiico produtoSiico : produtosSiicoEncontrados) {

	    if (produtoSiico.getProdutoSiicoID().getNuProduto().intValue() == produtoSelecionadoNoCombo.getParametroProdutoID().getNuProduto().intValue()) {

		if (!jaCopiouDadosSiico) {

		    produtoSelecionadoNoCombo.setEhInclusao(ehInclusao);
		    produtoSelecionadoNoCombo.getProduto().setCoUltimaSituacao(produtoSiico.getCoUltimaSituacao());
		    produtoSelecionadoNoCombo.setListaParametroGarantia(null);

		    if (ehInclusao) {
			produtoSelecionadoNoCombo.setIcAceitaGarantiaTerceiro(false);
		    }

		    produtoSelecionadoNoCombo.getMensagens().addAll(produtoSiico.getMensagens());
		    produtoSelecionadoNoCombo.getProduto().setNoComercialPrdto(produtoSiico.getNoComercialPrdto());
		    produtoSelecionadoNoCombo.getProduto().setNoProduto(produtoSiico.getNoProduto());
		    produtoSelecionadoNoCombo.getProduto().getProdutoSiicoID().setNuProduto(produtoSiico.getProdutoSiicoID().getNuProduto());
		    produtoSelecionadoNoCombo.getProduto().getProdutoSiicoID().setNuOperacao(produtoSiico.getProdutoSiicoID().getNuOperacao());
		    produtoSelecionadoNoCombo.getProduto().setNoOperacao(produtoSiico.getNoOperacao());
		    produtoSelecionadoNoCombo.getProduto().setSgSistema(produtoSiico.getSgSistema());
		    produtoSelecionadoNoCombo.getProduto().setNuSegmentoAtndo(produtoSiico.getNuSegmentoAtndo());
		    produtoSelecionadoNoCombo.getProduto().setNoSegmentoAtndo(produtoSiico.getNoSegmentoAtndo());
		    jaCopiouDadosSiico = true;
		}

		final ParametroProdutoGestorProduto unidadeGestora = new ParametroProdutoGestorProduto();
		unidadeGestora.setParametroProdutoGestorProdutoID(new ParametroProdutoGestorProdutoID());
		unidadeGestora.setEhInclusao(true);
		unidadeGestora.getParametroProdutoGestorProdutoID().setNuProduto(produtoSelecionadoNoCombo.getParametroProdutoID().getNuProduto());
		unidadeGestora.getParametroProdutoGestorProdutoID()
			.setNuModalidade(produtoSelecionadoNoCombo.getParametroProdutoID().getNuModalidade());
		unidadeGestora.getParametroProdutoGestorProdutoID().setNuUnidade(produtoSiico.getNuUnidade());
		unidadeGestora.setNoUnidadeGestora(this.getNoUnidadeGestora(produtoSiico.getSgUnidade(), produtoSiico.getNoUnidade()));

		unidadeGestora.getParametroProdutoGestorProdutoID()
			.setNuNatural(produtoSiico.getNuNatural() != null ? produtoSiico.getNuNatural() : null);
		unidadeGestora.setIcGestorSiico(true);

		this.adicionaUnidadeAlista(unidadeGestora);
	    }
	}

	if (!ehInclusao) {
	    for (final ParametroProdutoGestorProduto unidadeEmMemoria : this.getVisao().getListaUnidadesGestoras()) {
		this.getVisao().getListaUnidadesGestorasJaAssociadasAoProduto().add(unidadeEmMemoria);
	    }

	}
    }

    /**
     * <p>
     * Método reponsável por carregar do banco de dados do Siico e do SIACG as
     * Unidades Gestoras associadas a um produto para Homologar
     * (ParametroProduto).
     * </p>
     *
     * @param produtoParaHomologar
     *            valor a ser pesquisado.
     * @param ehInclusao
     *            Se é uma inclusão ou não.
     */
    private void populaListaDeUnidadesGestorasAssociadasAoProdutoHomologar(final ParametroProduto produtoParaHomologar) {

	// Encontra as Unidades Gestoras já persistidas para o Produto que não
	// são Siico.
	final Collection<ParametroProdutoGestorProduto> listaUnidadesGestorasNaoSiicoEncontradas = this.parametroProdutoUnidadeGestoraService
		.listarUnidades(produtoParaHomologar.getParametroProdutoID());

	// Vai buscar o nome da Unidade no Siico
	for (final ParametroProdutoGestorProduto unidadesGestoraNaoSiicoEncontrada : listaUnidadesGestorasNaoSiicoEncontradas) {

	    final String siglaUnidade = this.unidadeService
		    .obterSiglaUnidadePorNuUnidade(unidadesGestoraNaoSiicoEncontrada.getParametroProdutoGestorProdutoID().getNuUnidade());
	    final String nomeUnidade = this.unidadeService
		    .getNomeUnidade(unidadesGestoraNaoSiicoEncontrada.getParametroProdutoGestorProdutoID().getNuUnidade());

	    unidadesGestoraNaoSiicoEncontrada.setNoUnidadeGestora(this.getNoUnidadeGestora(siglaUnidade, nomeUnidade));
	}

	this.getVisao().setListaUnidadesGestorasHomologar(listaUnidadesGestorasNaoSiicoEncontradas);

	final Collection<ViewProdutoSiico> produtosSiicoEncontrados = this.viewProdutoSiicoService
		.listarProdutosTipoEmprestimoPorNuProduto(produtoParaHomologar.getParametroProdutoID().getNuProduto());

	boolean jaCopiouDadosSiico = false;

	produtoParaHomologar.setProduto(new ViewProdutoSiico());

	for (final ViewProdutoSiico produtoSiico : produtosSiicoEncontrados) {
	    if (produtoSiico.getProdutoSiicoID().getNuProduto().intValue() == produtoParaHomologar.getParametroProdutoID().getNuProduto().intValue()) {

		if (!jaCopiouDadosSiico) {
		    produtoParaHomologar.getProduto().setCoUltimaSituacao(produtoSiico.getCoUltimaSituacao());
		    produtoParaHomologar.getMensagens().addAll(produtoSiico.getMensagens());
		    produtoParaHomologar.getProduto().setNoComercialPrdto(produtoSiico.getNoComercialPrdto());
		    produtoParaHomologar.getProduto().setNoProduto(produtoSiico.getNoProduto());
		    produtoParaHomologar.getProduto().getProdutoSiicoID().setNuProduto(produtoSiico.getProdutoSiicoID().getNuProduto());
		    produtoParaHomologar.getProduto().getProdutoSiicoID().setNuOperacao(produtoSiico.getProdutoSiicoID().getNuOperacao());
		    produtoParaHomologar.getProduto().setNoOperacao(produtoSiico.getNoOperacao());
		    produtoParaHomologar.getProduto().setSgSistema(produtoSiico.getSgSistema());
		    produtoParaHomologar.getProduto().setNuSegmentoAtndo(produtoSiico.getNuSegmentoAtndo());
		    produtoParaHomologar.getProduto().setNoSegmentoAtndo(produtoSiico.getNoSegmentoAtndo());
		    jaCopiouDadosSiico = true;
		}

		final ParametroProdutoGestorProduto unidadeGestora = new ParametroProdutoGestorProduto();
		unidadeGestora.setParametroProdutoGestorProdutoID(new ParametroProdutoGestorProdutoID());
		unidadeGestora.setEhInclusao(true);
		unidadeGestora.getParametroProdutoGestorProdutoID().setNuProduto(produtoParaHomologar.getParametroProdutoID().getNuProduto());
		unidadeGestora.getParametroProdutoGestorProdutoID().setNuModalidade(produtoParaHomologar.getParametroProdutoID().getNuModalidade());
		unidadeGestora.getParametroProdutoGestorProdutoID().setNuUnidade(produtoSiico.getNuUnidade());
		unidadeGestora.setNoUnidadeGestora(this.getNoUnidadeGestora(produtoSiico.getSgUnidade(), produtoSiico.getNoUnidade()));

		unidadeGestora.getParametroProdutoGestorProdutoID()
			.setNuNatural(produtoSiico.getNuNatural() != null ? produtoSiico.getNuNatural() : null);
		unidadeGestora.setIcGestorSiico(true);
		this.getVisao().getListaUnidadesGestorasHomologar().add(unidadeGestora);
	    }
	}

    }

    private void setaModoBotoesDeAcao(final int modo) {

	switch (modo) {
	case ParametroProdutoMB.MODO_INCLUSAO:
	    this.getVisao().setEstaEmEdicao(Boolean.FALSE);
	    this.getVisao().setEstaEmInclusao(Boolean.TRUE);
	    this.getVisao().setTemProdutoSelecionado(Boolean.TRUE);
	    break;
	case ParametroProdutoMB.MODO_ALTERACAO:
	    this.getVisao().setEstaEmEdicao(Boolean.TRUE);
	    this.getVisao().setEstaEmInclusao(Boolean.FALSE);
	    this.getVisao().setPodeSalvarProduto(Boolean.TRUE);
	    this.getVisao().setTemProdutoSelecionado(Boolean.TRUE);
	    break;
	case ParametroProdutoMB.MODO_ERRO:
	    this.getVisao().setEstaEmEdicao(Boolean.FALSE);
	    this.getVisao().setEstaEmInclusao(Boolean.FALSE);
	    this.getVisao().setTemProdutoSelecionado(Boolean.FALSE);
	    break;
	default:
	    break;
	}
    }

    /**
     * <p>
     * Método responsável por adicionar uma Unidade Gestora a lista de Unidades
     * Gestoras.
     * </p>
     * 
     * @param ParametroProdutoGestorProduto
     *            unidadeGestora
     */
    private void adicionaUnidadeAlista(final ParametroProdutoGestorProduto unidadeGestora) {
	boolean contemUnidade = false;
	for (final ParametroProdutoGestorProduto item : this.getVisao().getListaUnidadesGestoras()) {
	    if (item.getParametroProdutoGestorProdutoID().getNuUnidade() == unidadeGestora.getParametroProdutoGestorProdutoID().getNuUnidade() && item
		    .getParametroProdutoGestorProdutoID().getNuNatural().equals(unidadeGestora.getParametroProdutoGestorProdutoID().getNuNatural())) {
		contemUnidade = true;
		break;
	    }
	}
	if (!contemUnidade) {
	    this.getVisao().getListaUnidadesGestoras().add(unidadeGestora);
	}
    }

    /**
     * <p>
     * Método responsável por validar de o produto está selecionado
     * corretamente.
     * </p>
     * 
     * @param ParametroProduto
     *            produto
     * @return boolean true/false
     */
    private boolean validaSelecaoProdutoModalidade(final ParametroProduto produto) {
	if (produto.getParametroProdutoID().getNuProduto() != null && produto.getParametroProdutoID().getNuProduto() != 0
		&& !UtilString.isVazio(this.getStrModalidadeFormatada())) {
	    return true;
	    // if (produto.getParametroProdutoID().getNuModalidade() !=
	    // null) {
	    // if (produto.getParametroProdutoID().getNuModalidade() != 0) {
	    // return true;
	    // }
	    // }
	}
	return false;
    }

    /**
     * <p>
     * Método responsável por limpar o Pojo de Modalidade.
     * </p>
     */
    public void prepareNewModalidade() {
	this.getVisao().setMsgErroModalidadeExistente(null);
	this.getVisao().setModalidadeProdutoSelecionada(new ParametroProduto());
    }

    /**
     * <p>
     * Método responsável por carregar as listas Clonadas.
     * </p>
     * 
     * @param evt
     */
    public void carregarListasClonagem() {
	final boolean temProdutoModalidadeSelecionados = this.validaSelecaoProdutoModalidade(this.getVisao().getProdutoSelecionado());

	if (temProdutoModalidadeSelecionados) {

	    // Limpa as listas e objetos relacionados a funcionalidade de
	    // clonar:
	    this.getVisao().setListaProdutosTipoEmprestimoClonar(new ArrayList<ViewProdutoSiico>());
	    this.getVisao().setListaModalidadesClonar(new ArrayList<ParametroProduto>());
	    this.getVisao().setProdutoSelecionadoClonar(new ParametroProduto());
	    this.getVisao().getProdutoSelecionadoClonar().setParametroProdutoID(new ParametroProdutoID());
	    this.getVisao().setModalidadeProdutoSelecionadaClonar(new ParametroProduto());
	    this.getVisao().getListaProdutosTipoEmprestimoClonar().clear();
	    this.getVisao().getListaModalidadesClonar().clear();

	    // this.getVisao().getListaProdutosTipoEmprestimoClonar().addAll(this.getVisao().getListaProdutosTipoEmprestimo());
	    this.getVisao().setMapProdutoPorModalidade(this.parametroProdutoService.obterModalidadePorProduto());
	    this.getVisao().setProdutoSiicoNampeIntoMapProdutoPorModalidade();
	    this.disableModalidadeClonar = true;
	    this.listModalidadesClonar = new ArrayList<>();

	} else {

	    super.adicionaMensagemDeErro(ParametroProdutoMB.PRODUTO_MODALIDADE_INVALIDO);
	}
    }

    /**
     * <p>
     * Método responsável por verificar se existe registros na lista de
     * Garantias.
     * </p>
     * 
     * @return boolean true/false
     */
    public boolean possuiRegistrosNaListaDeGarantias() {
	return this.getVisao().getListaGarantiasJaAssociadasAoProduto().size() > 0;
    }

    private boolean validarDadosTela(final ParametroProduto parametroProduto) {
		boolean retorno = true;
		if (parametroProduto.getNoModalidade() == null || parametroProduto.getNoModalidade().isEmpty()) {
		    this.setCampoComErro(true);
		    this.setMensagemDeErroNaValidacaoCampo("Nome da modalidade é Obrigatório!");
		    retorno = false;
		}
	
		if (parametroProduto.getNoNormativo() == null || parametroProduto.getNoNormativo().isEmpty()) {
		    this.setCampoComErro(true);
		    this.setMensagemDeErroNaValidacaoCampo("Nome do normativo é Obrigatório!");
		    retorno = false;
		}
		return retorno;
    }

    private ParametroProduto criarParametroProduto() {
	final ParametroProduto parametroProduto = this.getVisao().getProdutoSelecionado();
	parametroProduto.setCoMatricula(UsuarioUtil.getUsuarioLogado().getDeMatricula());
	return parametroProduto;
    }

    private List<ParametroGarantia> criarListaParametroProduto(final ParametroProduto parametroProduto) {
	// Salva as garantias
	List<ParametroGarantia> listaParametroGarantia = new ArrayList<>();
	for (final ParametroGarantia garantia : parametroProduto.getListaParametroGarantia()) {
	    listaParametroGarantia.add(garantia);
	}
	return listaParametroGarantia;
    }

    private List<ParametroProdutoGestorProduto> criarListaUnidadeGestora() {
	List<ParametroProdutoGestorProduto> listaUnidadeGestora = new ArrayList<>();
	for (final ParametroProdutoGestorProduto unidadeGestora : this.getVisao().getListaUnidadesGestoras()) {
	    if (!unidadeGestora.isIcGestorSiico()) {
		listaUnidadeGestora.add(unidadeGestora);
	    }
	}
	return listaUnidadeGestora;
    }

    /**
     * <p>
     * Método responsável por salvar a parametroProduto.
     * <p>
     *
     * @author Leandro Severino -> lseverino@gmail.com
     */
    public void salvarParametroProduto() {
	this.setCampoComErro(false);
	this.setMensagemDeErroNaValidacaoCampo("");

	final ParametroProduto parametroProduto = criarParametroProduto();
	if (!validarDadosTela(parametroProduto)) {
	    return;
	}
	if (parametroProduto.isEhInclusao()) {
	    // Salva o produto
	    this.parametroProdutoService.salvar(parametroProduto, criarListaUnidadeGestora(), criarListaParametroProduto(parametroProduto));
	} else {
	    // Então é uma edição !

	    // Persiste as Unidades Gestoras
	    final Collection<ParametroProdutoGestorProduto> unidadesGestorasPersistidas = this.getVisao()
		    .getListaUnidadesGestorasJaAssociadasAoProduto();
	    final Collection<ParametroProdutoGestorProduto> unidadesGestorasEmMemoria = this.getVisao().getListaUnidadesGestoras();

	    // Valida se a lista de Unidades Gestoras associadas ao produto em
	    // memória foi zerada.
	    if (unidadesGestorasEmMemoria.isEmpty()) {

		for (final Iterator<ParametroProdutoGestorProduto> iterator = unidadesGestorasPersistidas.iterator(); iterator.hasNext();) {

		    final ParametroProdutoGestorProduto unidadeGestoraPersistida = iterator.next();

		    // Só permite exclusão se não for Gestor Siico.
		    if (!unidadeGestoraPersistida.isIcGestorSiico()) {

			this.parametroProdutoUnidadeGestoraService.remover(unidadeGestoraPersistida);
			iterator.remove();
		    }
		}

	    } else {
		// Unidades Gestoras foram retiradas ou incluidas

		// Valida se uma Unidade Gestora persistida foi retirada da
		// memória.
		for (final Iterator<ParametroProdutoGestorProduto> iterator = unidadesGestorasPersistidas.iterator(); iterator.hasNext();) {
		    final ParametroProdutoGestorProduto unidadeGestoraPersistida = iterator.next();

		    // Se a Unidade Gestora persistida não está na memória,
		    // então foi retirada.
		    if (!unidadesGestorasEmMemoria.contains(unidadeGestoraPersistida)) {

			// Só permite exclusão se não for Gestor Siico.
			if (!unidadeGestoraPersistida.isIcGestorSiico()) {

			    this.parametroProdutoUnidadeGestoraService.remover(unidadeGestoraPersistida);
			    iterator.remove();
			}
		    }
		}

		// Valida se uma Unidade Gestora foi adicionada em memória.
		for (final ParametroProdutoGestorProduto unidadeGestoraEmMemoria : unidadesGestorasEmMemoria) {

		    // Se a Unidade Gestora em memória não está persistida,
		    // então foi adicionada.
		    if (!unidadesGestorasPersistidas.contains(unidadeGestoraEmMemoria)) {

			// Só permite inclusão se não for Gestor Siico.
			if (!unidadeGestoraEmMemoria.isIcGestorSiico()) {

			    this.parametroProdutoUnidadeGestoraService.salvar(unidadeGestoraEmMemoria);
			    unidadesGestorasPersistidas.add(unidadeGestoraEmMemoria);

			}
		    }
		}

	    }

	    // Persiste as Garantias
	    final Collection<ParametroGarantia> garantiasPersistidas = this.getVisao().getListaGarantiasJaAssociadasAoProduto();
	    final Collection<ParametroGarantia> garantiasEmMemoria = parametroProduto.getListaParametroGarantia();

	    // carregarSegmentos(parametroProduto);

	    if (garantiasEmMemoria.isEmpty()) { // Todas as Garantias foram
						// removidas.

		for (final Iterator<ParametroGarantia> iterator = garantiasPersistidas.iterator(); iterator.hasNext();) {

		    final ParametroGarantia garantia = iterator.next();

		    this.parametroGarantiaService.remover(garantia);
		    iterator.remove();
		}

	    } else {
		// Garantias foram retiradas ou incluidas
		for (final ParametroGarantia garantiaEmMemoria : garantiasEmMemoria) {

		    if (garantiaEmMemoria.getInclusao()) {

			this.parametroGarantiaService.salvar(garantiaEmMemoria);
			garantiasPersistidas.add(garantiaEmMemoria);

		    } else {
			// é uma edição de garantia.
			ParametroGarantia garantiaPersistidaEncontrada = null;

			// Procura a Garantia em Memória na lista de Garantias
			// Persistidas para testar se houve alguma alteração
			for (final ParametroGarantia garantiaPersistida : garantiasPersistidas) {
			    if (garantiaPersistida.getNuParametroGarantia().intValue() == garantiaEmMemoria.getNuParametroGarantia().intValue()) {
				garantiaPersistidaEncontrada = garantiaPersistida;
				break;
			    }
			}

			if (this.hasCamposModificados(garantiaEmMemoria, garantiaPersistidaEncontrada)) {
			    garantiaEmMemoria.setIcHomologacao(false);
			}

			this.parametroGarantiaService.salvar(garantiaEmMemoria);
		    }
		}

		// Trata as Garantias Excluidas
		boolean garantiaFoiExcluida = true;

		for (final Iterator<ParametroGarantia> iterator = garantiasPersistidas.iterator(); iterator.hasNext();) {

		    final ParametroGarantia garantiaPersistida = iterator.next();

		    for (final ParametroGarantia parametroGarantia : garantiasEmMemoria) {

			final ParametroGarantia garantiaEmMemoria = parametroGarantia;

			if (garantiaEmMemoria.getNuParametroGarantia().intValue() == garantiaPersistida.getNuParametroGarantia().intValue()) {
			    garantiaFoiExcluida = false;
			    break;

			} else {
			    garantiaFoiExcluida = true;
			}
		    }

		    // Se a Garantia Persistida não está na memória, então foi
		    // retirada.
		    if (garantiaFoiExcluida) {
			this.parametroGarantiaService.remover(garantiaPersistida);
			iterator.remove();
		    }
		}

	    }
	    
	    for (ParametroGarantia garantia : parametroProduto.getListaParametroGarantia()) {
			for (SegmentoCliente segmento : garantia.getSegmentosRemovidos()) {
				segmentoClienteService.removerSegmento(segmento.getNuSegmentoCliente(), garantia.getNuParametroGarantia());
			}
		}

	    // Salva a edição do ParametroProduto
	    this.parametroProdutoService.salvar(parametroProduto);
	    this.parametroProdutoService.flushEClear();
	}

	this.buscarGarantiasDoProdutoSelecionado(parametroProduto, false);

	parametroProduto.setEhInclusao(Boolean.FALSE);
	this.getVisao().setEstaEmInclusao(Boolean.FALSE);
	this.getVisao().setEstaEmEdicao(Boolean.TRUE);

	// Exibe a mensagem de sucesso !
	RequestContext.getCurrentInstance().execute("PF('modalSucesso').show();");
    }

    /**
     * <p>
     * Método responsável por verificar se tem campos modificaos
     * </p>
     * .
     *
     * @param garantiaEmMemoria
     * @param garantiaPersistidaEncontrada
     * @return TRUE caso tenha campo modificado, FALSE caso contrário.
     */
    private boolean hasCamposModificados(final ParametroGarantia garantiaEmMemoria, ParametroGarantia garantiaPersistidaEncontrada) {
	return garantiaPersistidaEncontrada != null
		&& (garantiaEmMemoria.getNuProdutoGarantia().intValue() != garantiaPersistidaEncontrada.getNuProdutoGarantia().intValue()
			|| !garantiaEmMemoria.getGarantia().getCoOperacao().equals(garantiaPersistidaEncontrada.getGarantia().getCoOperacao())
			|| garantiaEmMemoria.getQtdDiaPrazoMininmo().intValue() != garantiaPersistidaEncontrada.getQtdDiaPrazoMininmo().intValue()
			|| garantiaEmMemoria.getQtdDiaPrazoMaximo().intValue() != garantiaPersistidaEncontrada.getQtdDiaPrazoMaximo().intValue()
			|| garantiaEmMemoria.getVrMinimo().compareTo(garantiaPersistidaEncontrada.getVrMinimo()) != 0
			|| garantiaEmMemoria.getVrPercentualMinimo().compareTo(garantiaPersistidaEncontrada.getVrPercentualMinimo()) != 0
			|| garantiaEmMemoria.getVrPercentualMaximo().compareTo(garantiaPersistidaEncontrada.getVrPercentualMaximo()) != 0
			|| !garantiaEmMemoria.getIcFormaBloqueio().equals(garantiaPersistidaEncontrada.getIcFormaBloqueio()));
    }

    /**
     * <p>
     * Método responsável por excluir a parametroProduto selecionada.
     * <p>
     *
     * @return String
     * @author Leandro Severino -> lseverino@gmail.com
     */
    public String excluir() {
	final ParametroProduto parametroProduto = null;
	this.parametroProdutoService.salvar(parametroProduto);
	this.carregar();
	super.adicionaMensagemDeSucesso(ParametroProdutoMB.OPERACAO_SUCESSO);
	return super.MESMA_TELA;
    }

    /**
     * <p>
     * Método responsável por obter o produto para homologar.
     * </p>
     * 
     * @return ParametroProduto produtoParaHomologar
     */
    public ParametroProduto getProdutoParaHomologar() {
	return this.produtoParaHomologar;
    }

    /**
     * <p>
     * Método responsável por setar o produto para homologar.
     * </p>
     * 
     * @param produtoParaHomologar
     */
    public void setProdutoParaHomologar(final ParametroProduto produtoParaHomologar) {
	this.produtoParaHomologar = produtoParaHomologar;
    }

    /**
     * <p>
     * Método responsável por retornar o nome da Modal de Unidade Gestora para
     * abrir.
     * </p>
     * 
     * @return String nomeModalUnidadeGestoraParaAbrir
     */
    public String getNomeModalUnidadeGestoraParaAbrir() {
	return this.nomeModalUnidadeGestoraParaAbrir;
    }

    /**
     * <p>
     * Método responsável por setar o nome da modal de Unidade Gestora para
     * abrir.
     * </p>
     * 
     * @param String
     *            nomeModalUnidadeGestoraParaAbrir
     */
    public void setNomeModalUnidadeGestoraParaAbrir(final String nomeModalUnidadeGestoraParaAbrir) {
	this.nomeModalUnidadeGestoraParaAbrir = nomeModalUnidadeGestoraParaAbrir;
    }

    /**
     * <p>
     * Método responsável por retornar o nome da Modal de Modalidade para abrir.
     * </p>
     * 
     * @return String nomeModalModalidadeParaAbrir
     */
    public String getNomeModalModalidadeParaAbrir() {
	return this.nomeModalModalidadeParaAbrir;
    }

    /**
     * <p>
     * Método responsável por setar o nome da modal de Modalidade para abrir.
     * </p>
     * 
     * @param String
     *            nomeModalUnidadeGestoraParaAbrir
     */
    public void setNomeModalModalidadeParaAbrir(final String nomeModalModalidadeParaAbrir) {
	this.nomeModalModalidadeParaAbrir = nomeModalModalidadeParaAbrir;
    }

    /**
     * <p>
     * Método responsável por retornar o lista de Produtos para Excluir.
     * </p>
     * 
     * @return Collection listaProdutosParaExcluir
     */
    public Collection<ParametroProduto> getListaProdutosParaExcluir() {
	return this.listaProdutosParaExcluir;
    }

    /**
     * <p>
     * Método responsável por setar a lista de Produtos para Excluir.
     * </p>
     * 
     * @param Collection
     *            listaProdutosParaExcluir
     */
    public void setListaProdutosParaExcluir(final Collection<ParametroProduto> listaProdutosParaExcluir) {
	this.listaProdutosParaExcluir = listaProdutosParaExcluir;
    }

    /**
     * <p>
     * Método responsável por retornar o lista de Produtos para Homologar.
     * </p>
     * 
     * @return Collection listaProdutosParaHomologar
     */
    public Collection<ViewProdutoSiico> getListaProdutosParaHomologar() {
	return this.listaProdutosParaHomologar;
    }

    /**
     * <p>
     * Método responsável por setar a lista de Produtos para homologar.
     * </p>
     * 
     * @param Collection
     *            listaProdutosParaHomologar
     */
    public void setListaProdutosParaHomologar(final Collection<ViewProdutoSiico> listaProdutosParaHomologar) {
	this.listaProdutosParaHomologar = listaProdutosParaHomologar;
    }

    /**
     * <p>
     * Método responsável por retornar a Modalidade para excluir.
     * </p>
     * 
     * @return ParametroProdutoModalidade modalidadeParaExcluir
     */
    public ParametroProduto getModalidadeParaExcluir() {
	return this.modalidadeParaExcluir;
    }

    /**
     * <p>
     * Método responsável por setar a modalidade para Excluir.
     * </p>
     * 
     * @param ParametroProdutoModalidade
     *            modalidadeParaExcluir
     */
    public void setModalidadeParaExcluir(final ParametroProduto modalidadeParaExcluir) {
	this.modalidadeParaExcluir = modalidadeParaExcluir;
    }

    /**
     * <p>
     * Método responsável por retornar a Unidade Gestora para excluir.
     * </p>
     * 
     * @return ParametroProdutoGestorProduto unidadeParaExcluir
     */
    public ParametroProdutoGestorProduto getUnidadeParaExcluir() {
	return this.unidadeParaExcluir;
    }

    /**
     * <p>
     * Método responsável por setar a Unidade Gestora para Excluir.
     * </p>
     * 
     * @param ParametroProdutoGestorProduto
     *            unidadeParaExcluir
     */
    public void setUnidadeParaExcluir(final ParametroProdutoGestorProduto unidadeParaExcluir) {
	this.unidadeParaExcluir = unidadeParaExcluir;
    }

    /**
     * <p>
     * Método responsável por retornar os nomes dos produtos para excluir.
     * </p>
     * 
     * @return String nomesDosProdutosParaExcluir
     */
    public String getNomesDosProdutosParaExcluir() {
	return this.nomesDosProdutosParaExcluir;
    }

    /**
     * <p>
     * Método responsável por setar o nome dos produtos para Excluir.
     * </p>
     * 
     * @param String
     *            nomesDosProdutosParaExcluir
     */
    public void setNomesDosProdutosParaExcluir(final String nomesDosProdutosParaExcluir) {
	this.nomesDosProdutosParaExcluir = nomesDosProdutosParaExcluir;
    }

    /**
     * <p>
     * Método responsável por retornar se confirma a exclusão da modalidade.
     * </p>
     * 
     * @return String confirmaExclusaoModalidade
     */
    public String getConfirmaExclusaoModalidade() {
	return this.confirmaExclusaoModalidade;
    }

    /**
     * <p>
     * Método responsável por setar a confirmação de exclusão de Modalidade.
     * </p>
     * 
     * @param String
     *            confirmaExclusaoModalidade
     */
    public void setConfirmaExclusaoModalidade(final String confirmaExclusaoModalidade) {
	this.confirmaExclusaoModalidade = confirmaExclusaoModalidade;
    }

    /**
     * <p>
     * Método responsável por setar a confirmação de exclusão de Modalidade SN.
     * </p>
     * 
     * @param String
     *            valor
     */
    public void confirmaExclusaoModalidadeSN(final String valor) {
	this.setConfirmaExclusaoModalidade(valor);
    }

    /**
     * @see br.gov.caixa.pedesgo.arquitetura.controlador.AbstractBean#getPrefixoCasoDeUso()
     */
    @Override
    protected String getPrefixoCasoDeUso() {
	return ParametroProdutoMB.PREFIXO_CASO_USO;
    }

    /**
     * @see br.gov.caixa.pedesgo.arquitetura.controlador.AbstractBean#getService()
     */
    @SuppressWarnings("unchecked")
    @Override
    public ParametroProdutoService getService() {
	return this.parametroProdutoService;
    }

    /**
     * @see br.gov.caixa.pedesgo.arquitetura.controlador.AbstractBean#getParametroProdutoService()
     */
    public ParametroProdutoService getParametroProdutoService() {
	return this.parametroProdutoService;
    }

    /**
     * @see br.gov.caixa.pedesgo.arquitetura.controlador.AbstractBean#getViewProdutoSiicoService()
     */
    public ViewProdutoSiicoService getViewProdutoSiicoService() {
	return this.viewProdutoSiicoService;
    }

    /**
     * @see br.gov.caixa.pedesgo.arquitetura.controlador.AbstractBean#getParametroProdutoUnidadeGestoraService()
     */
    public ParametroProdutoUnidadeGestoraService getParametroProdutoUnidadeGestoraService() {
	return this.parametroProdutoUnidadeGestoraService;
    }

    /**
     * @see br.gov.caixa.pedesgo.arquitetura.controlador.AbstractBean#getTelaConsulta()
     */
    @Override
    public String getTelaConsulta() {
	return ParametroProdutoMB.DIRETORIO_PAGINAS.concat(this.getPrefixoCasoDeUso()).concat(AbstractBean.SUFIXO_TELA_CONSULTA);
    }

    /**
     * @see br.gov.caixa.pedesgo.arquitetura.controlador.AbstractBean#getNomeVarResourceBundle()
     */
    @Override
    protected String getNomeVarResourceBundle() {
	return ParametroProdutoMB.VAR_RESOURCE_BUNDLE;
    }

    /**
     * @see br.gov.caixa.pedesgo.arquitetura.controlador.AbstractBean#getTelaEdicao()
     */
    @Override
    public String getTelaEdicao() {
	return ParametroProdutoMB.DIRETORIO_PAGINAS.concat(this.getPrefixoCasoDeUso()).concat(AbstractBean.SUFIXO_TELA_EDICAO);
    }

    /**
     * @see br.gov.caixa.pedesgo.arquitetura.controlador.AbstractBean#getVisao()
     */
    @Override
    public ParametroProdutoVisao getVisao() {
	if (this.visao == null) {
	    this.visao = new ParametroProdutoVisao();
	}

	return this.visao;
    }

    /**
     * <p>
     * Método responsável por retornar se a Página já foi inicializada.
     * </p>
     * 
     * @return Boolean paginaJaFoiInicializada
     */
    public Boolean getPaginaJaFoiInicializada() {
	return this.paginaJaFoiInicializada;
    }

    /**
     * <p>
     * Método responsável por setar se a página já foi carregada.
     * </p>
     * 
     * @param Boolean
     *            paginaJaFoiInicializada
     */
    public void setPaginaJaFoiInicializada(final Boolean paginaJaFoiInicializada) {
	this.paginaJaFoiInicializada = paginaJaFoiInicializada;
    }

    /**
     * <p>
     * Método responsável por retornar se retornar se existe um campo com erro
     * na tela.
     * </p>
     * 
     * @return Boolean campoComErro
     */
    public boolean isCampoComErro() {
	return this.campoComErro;
    }

    /**
     * <p>
     * Método responsável por setar se existe um campo com erro na tela.
     * </p>
     * 
     * @param Boolean
     *            campoComErro
     */
    public void setCampoComErro(final boolean campoComErro) {
	this.campoComErro = campoComErro;
	this.getVisao().setPodeSalvarProduto(!this.campoComErro);
    }

    /**
     * <p>
     * Método responsável por retornar a mensagem de erro de validação.
     * </p>
     * 
     * @return String mensagemDeErroNaValidacaoCampo
     */
    public String getMensagemDeErroNaValidacaoCampo() {
	return this.mensagemDeErroNaValidacaoCampo;
    }

    /**
     * <p>
     * Método responsável por setar a mensagem de erro na validação.
     * </p>
     * 
     * @param String
     *            mensagemDeErroNaValidacaoCampo
     */
    public void setMensagemDeErroNaValidacaoCampo(final String mensagemDeErroNaValidacaoCampo) {
	this.mensagemDeErroNaValidacaoCampo = mensagemDeErroNaValidacaoCampo;
    }

    /**
     * @return the disableModalidadeClonar
     */
    public boolean isDisableModalidadeClonar() {
	return disableModalidadeClonar;
    }

    /**
     * @return the listModalidadesClonar
     */
    public List<NumberNameVO> getListModalidadesClonar() {
	return listModalidadesClonar;
    }

    /**
     * @param listModalidadesClonar
     *            the listModalidadesClonar to set
     */
    public void setListModalidadesClonar(List<NumberNameVO> listModalidadesClonar) {
	this.listModalidadesClonar = listModalidadesClonar;
    }

    /**
     * <p>
     * Retorna o valor do atributo limparCamposTela
     * </p>
     * .
     *
     * @return limparCamposTela
     */
    public boolean isLimparCamposTela() {
	return this.limparCamposTela;
    }

    /**
     * <p>
     * Define o valor do atributo limparCamposTela
     * </p>
     * .
     *
     * @param limparCamposTela
     *            valor a ser atribuído
     */
    public void setLimparCamposTela(boolean limparCamposTela) {
	this.limparCamposTela = limparCamposTela;
    }

    public Collection<SegmentoCliente> getSegmentos() {
	if (segmentos == null) {
	    setSegmentos(new ArrayList<SegmentoCliente>());
	}
	return segmentos;
    }

    public void setSegmentos(Collection<SegmentoCliente> collection) {
	this.segmentos = collection;
    }

    public ParametroGarantia getGarantiaSelecionada() {
	return this.garantiaSelecionada;
    }

    public void setGarantiaSelecionada(ParametroGarantia garantiaSelecionada) {
	this.garantiaSelecionada = garantiaSelecionada;
    }

    public SegmentoCliente getSegmentoSelecionado() {
	return this.segmentoSelecionado;
    }

    public void setSegmentoSelecionado(SegmentoCliente segmentoSelecionado) {
	this.segmentoSelecionado = segmentoSelecionado;
    }

    /**
     * <p>
     * Retorna o valor do atributo justificativaHomologacao
     * </p>
     * .
     *
     * @return justificativaHomologacao
     */
    public String getJustificativaHomologacao() {
	return this.justificativaHomologacao;
    }

    /**
     * <p>
     * Define o valor do atributo justificativaHomologacao
     * </p>
     * .
     *
     * @param justificativaHomologacao
     *            valor a ser atribuído
     */
    public void setJustificativaHomologacao(String justificativaHomologacao) {
	this.justificativaHomologacao = justificativaHomologacao;
    }
}