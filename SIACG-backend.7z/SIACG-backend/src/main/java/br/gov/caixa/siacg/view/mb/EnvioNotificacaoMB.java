package br.gov.caixa.siacg.view.mb;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.LinkedList;
import java.util.List;

import javax.ejb.EJB;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;
import javax.faces.context.FacesContext;
import javax.inject.Inject;

import br.gov.caixa.pedesgo.arquitetura.controlador.AbstractBean;
import br.gov.caixa.pedesgo.arquitetura.controlador.ManutencaoBean;
import br.gov.caixa.pedesgo.arquitetura.enumerador.EnumAcao;
import br.gov.caixa.pedesgo.arquitetura.enumerador.EnumNomeAbrangenciaRestritaUnidade;
import br.gov.caixa.pedesgo.arquitetura.enumerador.EnumTipoAbrangencia;
import br.gov.caixa.pedesgo.arquitetura.excecao.NegocioException;
import br.gov.caixa.pedesgo.arquitetura.util.LogCefUtil;
import br.gov.caixa.pedesgo.arquitetura.util.UsuarioUtil;
import br.gov.caixa.pedesgo.arquitetura.util.UtilObjeto;
import br.gov.caixa.pedesgo.arquitetura.util.UtilString;
import br.gov.caixa.siacg.commons.UtilPermissao;
import br.gov.caixa.siacg.exception.ParametrosInvalidosException;
import br.gov.caixa.siacg.model.domain.Contrato;
import br.gov.caixa.siacg.model.domain.EnvioNotificacao;
import br.gov.caixa.siacg.model.enums.NoFuncionalidadeEnum;
import br.gov.caixa.siacg.model.vo.ContratoParametrizadoVO;
import br.gov.caixa.siacg.model.vo.FiltroEnvioNotificacaoVO;
import br.gov.caixa.siacg.model.vo.SrVO;
import br.gov.caixa.siacg.model.vo.UnidadeVO;
import br.gov.caixa.siacg.pagination.RelatorioHistoricoEnvioLazyModel;
import br.gov.caixa.siacg.pagination.RelatorioMensageriaLazyModel;
import br.gov.caixa.siacg.service.DWAnaliseContratoService;
import br.gov.caixa.siacg.service.EnvioNotificacaoService;
import br.gov.caixa.siacg.service.PropriedadeService;
import br.gov.caixa.siacg.service.UnidadeVinculadaSuatService;
import br.gov.caixa.siacg.util.LogCEF;
import br.gov.caixa.siacg.view.form.EnvioNotificacaoVisao;

/**
 * <p>
 * TemplateMensageriaMB.
 * </p>
 * <p>
 * Descrição: Classe Bean responsável por armazenar os metodos amarrados a tela
 * do caso de uso de Envio de notificação
 * </p>
 * <br>
 * <b>Empresa:</b> Cef - Caixa Econômica Federal
 *
 * @author Waltenes Junior
 * @version 1.0
 */
@SessionScoped
@ManagedBean
public class EnvioNotificacaoMB extends ManutencaoBean<EnvioNotificacao> {

    /** Atributo UC_ENVIO_NOTIFICACAO_CONTRATO_OBRIGATORIO. */
    private static final String UC_ENVIO_NOTIFICACAO_CONTRATO_OBRIGATORIO = "uc_envio_notificacao_contrato_obrigatorio";

    /** Atributo serialVersionUID. */
    private static final long serialVersionUID = 231767297452250354L;

    /** Atributo SUFIXO_TELA_CONSULTA_NOTIFICACAO. */
    private static final String SUFIXO_TELA_CONSULTA_NOTIFICACAO = "/consultaNotificacao.xhtml?faces-redirect=true";

    /** Atributo DIRETORIO_PAGINAS. */
    private static final String DIRETORIO_PAGINAS = "/pages/";

    /** Atributo PREFIXO_CASO_USO. */
    private static final String PREFIXO_CASO_USO = "envioNotificao";

    /** Atributo PROPRIEDADE_ENVIO_AUTOMATICO. */
    private static final String PROPRIEDADE_ENVIO_AUTOMATICO = "envio.mensageria.automatico";

    /** Atributo PROPRIEDADE_EXPRESSAO. */
    private static final String PROPRIEDADE_EXPRESSAO = "envio.mensageria.expressao";

    /** Atributo PROPRIEDADE_GRUPO. */
    private static final String PROPRIEDADE_GRUPO = "mensageria";

    /** Atributo MENSAGEM_SUCESSO. */
    private static final String MENSAGEM_SUCESSO = "MA002";

    /** Atributo VAR_RESOURCE_BUNDLE. */
    private static final String VAR_RESOURCE_BUNDLE = "msgApp";

    /** Atributo LABEL_DESLIGADO. */
    private static final String LABEL_DESLIGADO = "desligado";
    
    private static final String UNIDADE = "unidade";
	private static final Integer HIERARQUIA=1;
    
    /** Atributo servico. */
    @EJB
    private transient EnvioNotificacaoService servico;

    /** Atributo permissao. */
    @Inject
    private transient UtilPermissao permissao;

    /** Atributo visao. */
    private transient EnvioNotificacaoVisao visao;
    
    @Inject
    private PropriedadeService propriedadeService;
    
    @Inject
    private DWAnaliseContratoService dwAnaliseContratoService;
    
    @Inject
    private transient UnidadeVinculadaSuatService unidadeVinculadaSuatService;
    
    @Inject
    private RelatorioMensageriaLazyModel relatorioMensageriaLazyModel;
    
    @Inject
    private RelatorioHistoricoEnvioLazyModel relatorioHistoricoEnvioLazyModel;

    /**
     * @see br.gov.caixa.pedesgo.arquitetura.controlador.AbstractBean#carregar()
     */
    @Override
    protected void carregar() {
        this.visao = null;

        getVisao().setListaContratoInsuficiente(new ArrayList<ContratoParametrizadoVO>());
        
        configurarPermissao();
    	carregarListaUnidades();

        carregarPropriedadeEnvioAutomatico();

        getVisao().setListaGrupoGarantia(getService().listarTodasGarantias());
        getVisao().setListaContratoInsuficienteSelecionado(new ArrayList<ContratoParametrizadoVO>());
        
        this.relatorioMensageriaLazyModel.setVisao(getVisao());
        this.relatorioHistoricoEnvioLazyModel.setVisao(getVisao());
    }

    /**
     * <p>
     * Método responsável por carregar os dados da propriedade de envio
     * automatico.
     * <p>
     *
     * @author Waltenes Junior
     */
    private void carregarPropriedadeEnvioAutomatico() {
        final EnvioNotificacaoVisao visao = this.getVisao();

        final String propriedadeEnvioAutomatico = servico.obterValorPropriedade(EnvioNotificacaoMB.PROPRIEDADE_ENVIO_AUTOMATICO,
                EnvioNotificacaoMB.PROPRIEDADE_GRUPO);

        if (UtilObjeto.isReferencia(propriedadeEnvioAutomatico)) {
            visao.setEnvioAutomatico(propriedadeEnvioAutomatico.equals(EnvioNotificacaoMB.LABEL_DESLIGADO) ? Boolean.FALSE : Boolean.TRUE);
        }

        visao.setExpressao(this.servico.obterValorPropriedade(EnvioNotificacaoMB.PROPRIEDADE_EXPRESSAO, EnvioNotificacaoMB.PROPRIEDADE_GRUPO));
    }

    /**
     * <p>
     * Método responsável por carregar a lista de contratos insulficiente pelas
     * unidade vinculadas a unidade do usuário logado.
     * <p>
     * @author Waltenes Junior
     */
    private void carregarListaContratoPorPermissaoUsuario() {
    	getVisao().getFiltro().setListaUnidades(
                permissao.prepararConsultaPorTipoAbrangencia(NoFuncionalidadeEnum.ENVIA_NOTIFICACAO_MANUAL.getNoFuncionalidade()));

    }

    /**
     * <p>
     * Método responsável por preencher a lista de unidades de acordo com a suat
     * selecionada.
     * <p>
     *
     * @author Caio Graco
     */
    public void selecionarSuat() {
		getVisao().setNuSuat(getVisao().getSuatSelecionada());
		getVisao().getFiltro().setListaUnidades(new ArrayList<Integer>());
		if (UtilObjeto.isReferencia(getVisao()) && getVisao().getNuSuat() != null && !getVisao().getNuSuat().equals(0)) {
			Integer tipoConfig = getVisao().getTipoConfig();
			if (tipoConfig == 1) {
				getVisao().setSrList(dwAnaliseContratoService.listarSrsPorNuSuat(getVisao().getNuSuat()));
				getVisao().setUnidadeList(new LinkedList<UnidadeVO>());
				
				adicionarFiltronidadePorSr();
			} else {
				getVisao().setListaUnidade(unidadeVinculadaSuatService.listarProcessoPorListaNuProcesso(Arrays.asList(visao.getNuSuat())));
				getVisao().setSrList(new LinkedList<SrVO>());
			}
		} else {
			getVisao().setSrList(new LinkedList<SrVO>());
			getVisao().setUnidadeList(new LinkedList<UnidadeVO>());
		}
		
		filtrarContratoInsuficiente();
    }

    public void selecionarSr() {
    	getVisao().setNuSr(getVisao().getCodSuvSelecionado());
		
		if (UtilObjeto.isReferencia(getVisao()) && getVisao().getNuSr() != null && !getVisao().getNuSr().equals(0)) {
			getVisao().setListaUnidade(dwAnaliseContratoService.listarUnidadesPorNuSr(getVisao().getNuSr()));
			
			adicionarFiltroUnidadePorUnidade();
		} else {
			getVisao().setNuSr(null);
			getVisao().setUnidadeList(new LinkedList<UnidadeVO>());
			
			adicionarFiltronidadePorSr();
		}
		
		filtrarContratoInsuficiente();
    }
    
    private void adicionarFiltronidadePorSr() {
		final Collection<Integer> listaNuSr = new ArrayList<>();
		for (final SrVO srVO : getVisao().getSrList()) {
		    listaNuSr.add(srVO.getNuSrVO());
		}
		
		getVisao().getFiltro().setListaUnidades(unidadeVinculadaSuatService.getNuUnidadesVinculadasSR(listaNuSr));
	}

    /**
     * <p>
     * Método responsável por preencher a lista de unidades de acordo com a SR
     * selecionada.
     * <p>
     *
     * @author Caio Graco
     */
    public void selecionarUnidade() {
    	visao.getFiltro().setListaUnidades(Arrays.asList(visao.getUnidadeSelecionada()));
		
		if (UtilObjeto.isReferencia(getVisao()) && getVisao().getUnidadeSelecionada() != null && !getVisao().getUnidadeSelecionada().equals(0)) {
			filtrarContratoInsuficiente();
		} else {
			getVisao().setUnidadeSelecionada(null);
			adicionarFiltroUnidadePorUnidade();
			filtrarContratoInsuficiente();
		}
    }
    
    private void adicionarFiltroUnidadePorUnidade() {
		final Collection<Integer> listaNuUnidade = new ArrayList<>();
		for (final UnidadeVO unidade : getVisao().getListaUnidade()) {
		    listaNuUnidade.add(unidade.getCoUnidadeVO());
		}
		
		getVisao().getFiltro().setListaUnidades(listaNuUnidade);
	}
    
    private void carregarListaUnidades() {
		List<UnidadeVO> listaDires = new ArrayList<>();
		
		Integer tipoConfig = 1; 
		try {
			List<Integer> codigos = new ArrayList<>();
			String dados = propriedadeService.getPropriedadeBanco("unidade.lista", UNIDADE);
			tipoConfig = Integer.parseInt(this.propriedadeService.getPropriedadeBanco("unidade.tipoconfig", UNIDADE));
			String[] lista = dados.split(";");
			for (String item : lista) {
				codigos.add(Integer.parseInt(item));
			}
			if (tipoConfig == HIERARQUIA) {
				listaDires = new ArrayList<>(this.unidadeVinculadaSuatService.listarDiresPorCodigo(codigos));
			} else {
				listaDires = new ArrayList<>(this.unidadeVinculadaSuatService.listarProcessoPorListaNuProcesso(codigos));
			}
		} catch (ParametrosInvalidosException e) {
			LogCEF.error("Erro ao carregar propriedades de unidades. Detalhes: ");
			LogCEF.error(e);
		}
			
		this.getVisao().setListaDires(listaDires);
		this.getVisao().setTipoConfig(tipoConfig);
	}
    
    private void configurarPermissao() {
		final FacesContext contexto = FacesContext.getCurrentInstance();

		if (UtilObjeto.isReferencia(contexto)) {
			final String unidadeUsuario = super.getUnidadeUsuario();

			if (!UtilString.isVazio(unidadeUsuario)) {

				final Integer nuUnidadeusuarioLogado = Integer.valueOf(unidadeUsuario);

				if (UtilObjeto.isReferencia(nuUnidadeusuarioLogado)) {

					if (UsuarioUtil.contemPermissao(NoFuncionalidadeEnum.CONSULTA_UNIDADE.getNoFuncionalidade(), EnumAcao.CONSULTAR.getNoAcao(),
							EnumTipoAbrangencia.RESTRITA_UNIDADE.getTipoAbrangencia(),
							EnumNomeAbrangenciaRestritaUnidade.TODAS.getNomeAbrangencia())) {

						getVisao().setHabilitarSuat(Boolean.FALSE);
						getVisao().setHabilitarSr(Boolean.FALSE);
					    getVisao().setHabilitarUnidade(Boolean.FALSE);
					    
					    carregarListaContratoPorPermissaoUsuario();
					} else if (UsuarioUtil.contemPermissao(NoFuncionalidadeEnum.CONSULTA_UNIDADE.getNoFuncionalidade(),
							EnumAcao.CONSULTAR.getNoAcao(), EnumTipoAbrangencia.RESTRITA_UNIDADE.getTipoAbrangencia(),
							EnumNomeAbrangenciaRestritaUnidade.VINCULADAS.getNomeAbrangencia())) {

						getVisao().setHabilitarSuat(Boolean.TRUE);
						getVisao().setHabilitarSr(Boolean.TRUE);
						getVisao().setHabilitarUnidade(Boolean.FALSE);

						carregarListaContratoPorPermissaoUsuario();

					} else if (UsuarioUtil.contemPermissao(NoFuncionalidadeEnum.CONSULTA_UNIDADE.getNoFuncionalidade(),
							EnumAcao.CONSULTAR.getNoAcao(), EnumTipoAbrangencia.RESTRITA_UNIDADE.getTipoAbrangencia(),
							EnumNomeAbrangenciaRestritaUnidade.UNIDADE.getNomeAbrangencia())) {

						getVisao().setHabilitarSuat(Boolean.TRUE);
						getVisao().setHabilitarSr(Boolean.TRUE);
						getVisao().setHabilitarUnidade(Boolean.TRUE);
						
						carregarListaContratoPorPermissaoUsuario();
					}
				}
			}
		}
	}

    /**
     * <p>
     * Método responsável por salvar as propriedades de envio automatico e a
     * expressão usada pela rotina de envio automatico.
     * <p>
     *
     * @return String
     * @author Waltenes Junior
     */
    public String salvarPropriedadeEnvioNotificacao() {
        final EnvioNotificacaoVisao visao = this.getVisao();
        super.adicionaMensagemDeSucesso(this.servico.salvarExpressao(visao.getExpressao(), visao.isEnvioAutomatico()));
        return super.MESMA_TELA;
    }

    /**
     * <p>
     * Método responsável por filtrar os contratos insuficientes pelo filtro
     * selecionado pelo usuário.
     * <p>
     *
     * @author Waltenes Junior
     */
    public void filtrarContratoInsuficiente() {
    }

    /**
     * <p>
     * Método responsável por enviar as notificações manualmente.
     * <p>
     *
     * @author Waltenes Junior
     */
    public void envioManual() {
        try {

            final Collection<Contrato> listaContrato = this.servico
                    .listarContratoPorListaCoContrato(this.getVisao().getListaContratoInsuficienteSelecionado());

            if (!UtilObjeto.isVazio(listaContrato)) {

                this.servico.enviarEmailNotificacao(listaContrato, Boolean.TRUE);

                super.adicionaMensagemDeSucesso(EnvioNotificacaoMB.MENSAGEM_SUCESSO);

            } else {

                super.adicionaMensagemDeAlerta(EnvioNotificacaoMB.UC_ENVIO_NOTIFICACAO_CONTRATO_OBRIGATORIO);
            }
        } catch (final NegocioException e) {
            super.adicionaListaMensagemDeErro(e.getMensagens());
            LogCefUtil.error(e);
            
        } catch (final Exception e) {
            super.adicionaMensagemDeErroDeSistema("Não foi possivel realizar o envio das notificações =>" + e.getMessage());
            LogCefUtil.error(e);
        }

    }

    /**
     * <p>
     * Método responsável por abrir a tela de detalhe do envio de notificação.
     * <p>
     *
     * @param envioNotificacao
     *            valor a ser atribuído
     * @return String com a URL da tela de detalhe
     * @author Waltenes Junior
     */
    public String abrirDetalheEnvioNotificacao(final EnvioNotificacao envioNotificacao) {
        this.getVisao().setEntidade(envioNotificacao);
        return this.getTelaDetalhe();
    }

    /**
     * <p>
     * Método responsável por abrir a tela de historico de envio de notificação.
     * <p>
     *
     * @return String
     * @author Waltenes Junior
     */
    public String abrirTelaHistoricoEnvio() {
        //this.getVisao().setLista(super.listar());
//        this.verificarTipoPermissaoUsuario(this.servico.listarSuats(), Integer.valueOf(super.getUnidadeUsuario()));
        configurarPermissao();
        return this.getTelaConsultaNotificacao();
    }

    /**
     * <p>
     * Método responsável por filtrar a lista de notificação de acordo com o
     * filtro da tela.
     * <p>
     *
     * @author Waltenes Junior
     */
    public void filtrarListaNotificacao() {
    }

    /**
     * <p>
     * Método responsável por abrir a tela de consulta do envio de notificações.
     * <p>
     *
     * @return String com a tela de consulta das notificações
     * @author Waltenes Junior
     */
    public String getTelaConsultaNotificacao() {
        return EnvioNotificacaoMB.DIRETORIO_PAGINAS + this.getPrefixoCasoDeUso() + EnvioNotificacaoMB.SUFIXO_TELA_CONSULTA_NOTIFICACAO;
    }

    /**
     * <p>
     * Método responsável por limpar os dados do filtro.
     * <p>
     *
     * @return String
     * @author guilherme.santos
     */
    public String limpar() {
        this.getVisao().setFiltroEnvioNotificacaoVO(new FiltroEnvioNotificacaoVO());
        this.getVisao().setUnidadeSelecionada(null);
        this.getVisao().setSrSelecionada(null);
        this.getVisao().setSuatSelecionada(null);

        return super.MESMA_TELA;
    }

    /**
     * @see br.gov.caixa.pedesgo.arquitetura.controlador.AbstractBean#getTelaConsulta()
     */
    @Override
    public String getTelaConsulta() {
        return EnvioNotificacaoMB.DIRETORIO_PAGINAS + this.getPrefixoCasoDeUso() + AbstractBean.SUFIXO_TELA_CONSULTA;
    }

    /**
     * @see br.gov.caixa.pedesgo.arquitetura.controlador.AbstractBean#getTelaEdicao()
     */
    @Override
    public String getTelaEdicao() {
        return EnvioNotificacaoMB.DIRETORIO_PAGINAS + this.getPrefixoCasoDeUso() + AbstractBean.SUFIXO_TELA_EDICAO;
    }

    /**
     * @see br.gov.caixa.pedesgo.arquitetura.controlador.AbstractBean#getTelaDetalhe()
     */
    @Override
    public String getTelaDetalhe() {
        return EnvioNotificacaoMB.DIRETORIO_PAGINAS + this.getPrefixoCasoDeUso() + AbstractBean.SUFIXO_TELA_DETALHE;
    }

    /**
     * @see br.gov.caixa.pedesgo.arquitetura.controlador.AbstractBean#getNomeVarResourceBundle()
     */
    @Override
    protected String getNomeVarResourceBundle() {
        return EnvioNotificacaoMB.VAR_RESOURCE_BUNDLE;
    }

    /**
     * @see br.gov.caixa.pedesgo.arquitetura.controlador.AbstractBean#getPrefixoCasoDeUso()
     */
    @Override
    protected String getPrefixoCasoDeUso() {
        return EnvioNotificacaoMB.PREFIXO_CASO_USO;
    }

    /**
     * @see br.gov.caixa.pedesgo.arquitetura.controlador.AbstractBean#getService()
     */
    @SuppressWarnings("unchecked")
    @Override
    public EnvioNotificacaoService getService() {
        return this.servico;
    }

    /**
     * @see br.gov.caixa.pedesgo.arquitetura.controlador.AbstractBean#getVisao()
     */
    @Override
    public EnvioNotificacaoVisao getVisao() {
        if (this.visao == null) {
            this.visao = new EnvioNotificacaoVisao();
        }

        return this.visao;
    }

    /**
     * <p>Retorna o valor do atributo relatorioMensageriaLazyModel</p>.
     *
     * @return relatorioMensageriaLazyModel
    */
    public RelatorioMensageriaLazyModel getRelatorioMensageriaLazyModel() {
        return this.relatorioMensageriaLazyModel;
    }

    /**
     * <p>Define o valor do atributo relatorioMensageriaLazyModel</p>.
     *
     * @param relatorioMensageriaLazyModel valor a ser atribuído
    */
    public void setRelatorioMensageriaLazyModel(RelatorioMensageriaLazyModel relatorioMensageriaLazyModel) {
        this.relatorioMensageriaLazyModel = relatorioMensageriaLazyModel;
    }

    /**
     * <p>Retorna o valor do atributo relatorioHistoricoEnvioLazyModel</p>.
     *
     * @return relatorioHistoricoEnvioLazyModel
    */
    public RelatorioHistoricoEnvioLazyModel getRelatorioHistoricoEnvioLazyModel() {
        return this.relatorioHistoricoEnvioLazyModel;
    }

    /**
     * <p>Define o valor do atributo relatorioHistoricoEnvioLazyModel</p>.
     *
     * @param relatorioHistoricoEnvioLazyModel valor a ser atribuído
    */
    public void setRelatorioHistoricoEnvioLazyModel(RelatorioHistoricoEnvioLazyModel relatorioHistoricoEnvioLazyModel) {
        this.relatorioHistoricoEnvioLazyModel = relatorioHistoricoEnvioLazyModel;
    }
    
    
    
    
}
