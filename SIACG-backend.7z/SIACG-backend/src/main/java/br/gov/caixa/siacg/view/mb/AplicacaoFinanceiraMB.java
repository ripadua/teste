/*
 * Copyright (c) 2018 Caixa Econômica Federal. Todos os direitos
 * reservados.
 *
 * Caixa Econômica Federal - SIACG - Sistema de Crédito Rural
 *
 * Este software foi desenvolvido sob demanda da CAIXA e está
 * protegido por leis de direitos autorais e tratados internacionais. As
 * condições de cópia e utilização do todo ou partes dependem de autorização da
 * empresa. Cópias não são permitidas sem expressa autorização. Não pode ser
 * comercializado ou utilizado para propósitos particulares.
 *
 * Uso exclusivo da Caixa Econômica Federal. A reprodução ou distribuição não
 * autorizada deste programa ou de parte dele, resultará em punições civis e
 * criminais e os infratores incorrem em sanções previstas na legislação em
 * vigor.
 *
 * Histórico do TFS:
 *
 * LastChangedRevision: $Revision$
 * LastChangedBy: $Author$
 * LastChangedDate: $Date$
 *
 * HeadURL: $HeadURL$
 *
 */
package br.gov.caixa.siacg.view.mb;

import javax.ejb.EJB;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ManagedProperty;
import javax.faces.bean.SessionScoped;

import br.gov.caixa.pedesgo.arquitetura.controlador.AbstractBean;
import br.gov.caixa.pedesgo.arquitetura.controlador.ManutencaoBean;
import br.gov.caixa.pedesgo.arquitetura.util.UtilObjeto;
import br.gov.caixa.pedesgo.arquitetura.visao.ManutencaoVisao;
import br.gov.caixa.siacg.model.domain.AplicacaoFinanceira;
import br.gov.caixa.siacg.pagination.AplicacaoFinanceiraLazyModel;
import br.gov.caixa.siacg.service.AplicacaoFinanceiraService;
import br.gov.caixa.siacg.view.form.AplicacaoFinanceiraVisao;

/**
 * <p>
 * AplicacaoFinanceiraMB
 * </p>
 *
 * <p>
 * Descrição: Descrição do tipo
 * </p>
 *
 * <br>
 * <b>Empresa:</b> Cef - Caixa Econômica Federal
 *
 *
 * @author f799837
 *
 * @version 1.0
 */
@ManagedBean
@SessionScoped
public class AplicacaoFinanceiraMB extends ManutencaoBean<AplicacaoFinanceira> {

    /** Atributo serialVersionUID. */
    private static final long serialVersionUID = 1L;

    /** Atributo PREFIXO_CASO_USO. */
    private static final String PREFIXO_CASO_USO = "aplicacaoFinanceira";

    /** Atributo DIRETORIO_PAGINAS. */
    private static final String DIRETORIO_PAGINAS = "/pages/";

    /** Atributo NOME_MANAGED_BEAN. */
    public static final String NOME_MANAGED_BEAN = "aplicacaoFinanceiraMB";

    /** Atributo EL_MANAGED_BEAN. */
    public static final String EL_MANAGED_BEAN = "#{aplicacaoFinanceiraMB}";

    private transient AplicacaoFinanceiraVisao visao;

    @EJB
    private transient AplicacaoFinanceiraService aplicacaoFinanceiraService;

    /** Atributo de Consulta */
    @ManagedProperty(value = AplicacaoFinanceiraLazyModel.EL_MANAGED_BEAN)
    private AplicacaoFinanceiraLazyModel consulta;

    @Override
    protected String getPrefixoCasoDeUso() {
	return AplicacaoFinanceiraMB.PREFIXO_CASO_USO;
    }

    /**
     * 
     * <p>
     * Método responsável por
     * </p>
     * . Filtrar Contas e aplicações Financeiras Filtro pelo CNPJ ou NOTA
     * 
     * @author f799837
     *
     */
    public void filtrar() {
	this.getConsulta();
    }

    public void limparFiltros() {
	this.getConsulta().limparFiltro();
	// this.visao.setListaAplicacaoFinanceira(null);
	// this.visao.setFiltro(null);
	// this.visao.setQtdItens(null);
	this.getVisao();
    }

    @SuppressWarnings("unchecked")
    @Override
    public AplicacaoFinanceiraService getService() {
	return this.aplicacaoFinanceiraService;
    }

    @Override
    public ManutencaoVisao<AplicacaoFinanceira> getVisao() {
	if (this.visao == null) {
	    this.visao = new AplicacaoFinanceiraVisao();
	}
	return this.visao;
    }

    @Override
    protected void carregar() {
	this.visao.setEntidade(new AplicacaoFinanceira());

    }

    @Override
    public String getTelaConsulta() {
	return AplicacaoFinanceiraMB.DIRETORIO_PAGINAS.concat(this.getPrefixoCasoDeUso()).concat(AbstractBean.SUFIXO_TELA_CONSULTA);
    }

    public AplicacaoFinanceiraLazyModel getConsulta() {
	if (!UtilObjeto.isReferencia(this.consulta)) {
	    this.consulta = new AplicacaoFinanceiraLazyModel();
	}
	return this.consulta;
    }

    public void setConsulta(AplicacaoFinanceiraLazyModel consulta) {
	this.consulta = consulta;
    }
}
