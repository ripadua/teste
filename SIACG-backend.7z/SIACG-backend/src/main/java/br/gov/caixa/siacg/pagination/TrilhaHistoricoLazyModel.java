
package br.gov.caixa.siacg.pagination;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;
import javax.inject.Inject;

import org.primefaces.model.SortOrder;

import br.gov.caixa.pedesgo.arquitetura.paginacao.Paginacao;
import br.gov.caixa.pedesgo.arquitetura.paginacao.PaginacaoDemanda;
import br.gov.caixa.siacg.comum.to.TrilhaHistoricoTO;
import br.gov.caixa.siacg.service.TrilhaHistoricoService;
import br.gov.caixa.siacg.trilha.TrilhaHistorico;
import br.gov.caixa.siacg.util.ValidacaoUtil;

/**
 * <p>
 * TrilhaHistoricoLazyModel.
 * </p>
 * <p>
 * Descrição: TrilhaHistoricoLazyModel
 * </p>
 * <br>
 * <b>Empresa:</b> Cef - Caixa Econômica Federal
 *
 * @version 1.0
 */
@ManagedBean(name = "trilhaHistoricoLazyModel")
@SessionScoped
public class TrilhaHistoricoLazyModel extends Paginacao<TrilhaHistorico> {

    private static final long serialVersionUID = 4267001132950930377L;

    /** Atributo service. */
    @Inject
    private TrilhaHistoricoService service;

    /** Atributo EL_MANAGED_BEAN. */
    public static final String EL_MANAGED_BEAN = "#{trilhaHistoricoLazyModel}";

    /** Atributo resultado. */
    private transient PaginacaoDemanda<TrilhaHistorico> resultado = new PaginacaoDemanda<>(new ArrayList<TrilhaHistorico>(), 0);

    /** Atributo trilhaHistoricoTO. */
    private transient TrilhaHistoricoTO trilhaHistoricoTO;

    /** Atributo valido. */
    private boolean valido = false;

    /**
     *
     *
     * @see br.gov.caixa.pedesgo.arquitetura.integracao.componente.paginacao.Paginacao#load(int,
     *      int, java.lang.String, org.primefaces.model.SortOrder,
     *      java.util.Map)
     */
    @Override
    public List<TrilhaHistorico> load(final int inicioConsulta, final int fimConsulta, final String campoOrdenacao, final SortOrder ordenacao,
            final Map<String, String> parametros) {

        if (this.service.validarFiltroFuncionalidadeOuResponsavel(this.trilhaHistoricoTO) && this.service.validarFiltroData(this.trilhaHistoricoTO)
                && this.valido) {

            this.resultado = this.service.listarTrilhasHistoricoParametrizado(this.trilhaHistoricoTO, inicioConsulta, fimConsulta);

            this.setWrappedData(this.resultado.getLista());

            this.setRowCount(this.resultado.getQuantidadeRegistros());

            return this.resultado.getLista();
        }

        return new ArrayList<>();

    }

    /**
     * @see br.gov.caixa.pedesgo.arquitetura.integracao.componente.paginacao.Paginacao#getServico()
     */
    @SuppressWarnings("unchecked")
    @Override
    public TrilhaHistoricoService getServico() {
        return this.service;
    }

    /**
     * Retorna o valor do atributo trilhaAuditoriaConsultaTO.
     *
     * @return trilhaAuditoriaConsultaTO
     */
    public TrilhaHistoricoTO getTrilhaHistoricoTO() {
        if(ValidacaoUtil.isNulo(this.trilhaHistoricoTO)){
            this.trilhaHistoricoTO = new TrilhaHistoricoTO();
        }
        return  this.trilhaHistoricoTO;
    }

    /**
     * Define o valor do atributo trilhaAuditoriaConsultaTO.
     *
     * @param trilhaHistoricoTO
     *            valor a ser atribuído
     */
    public void setTrilhaHistoricoTO(final TrilhaHistoricoTO trilhaHistoricoTO) {
        this.trilhaHistoricoTO = trilhaHistoricoTO;
    }

    /**
     *
     * <p>
     * Método responsável retornar o valor do atributo.
     * <p>
     *
     * @return Boolean
     * @author Robson.Oliveira
     */
    public Boolean getValido() {

        return this.valido;
    }

    /**
     *
     * <p>
     * Método responsável por setar valor no atributo.
     * <p>
     *
     * @param valido
     *            valor a ser atribuido
     * @author Robson Oliveira
     */
    public void setValido(final Boolean valido) {

        this.valido = valido;
    }

    /**
     *
     * <p>
     * Método responsável retornar o valor do atributo.
     * <p>
     *
     * @return resultado
     * @author Robson.Oliveira
     */
    public PaginacaoDemanda<TrilhaHistorico> getResultado() {

        return this.resultado;
    }

    /**
     *
     *
     * <p>
     * Método responsável por setar valor no atributo.
     * <p>
     *
     * @param resultado
     *            valor a ser atribuido
     * @author admin
     */
    public void setResultado(final PaginacaoDemanda<TrilhaHistorico> resultado) {

        this.resultado = resultado;
    }

}
