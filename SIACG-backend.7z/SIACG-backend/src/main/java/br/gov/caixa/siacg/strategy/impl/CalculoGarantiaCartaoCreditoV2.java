package br.gov.caixa.siacg.strategy.impl;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.Map;

import javax.ejb.EJB;
import javax.ejb.Stateless;

import br.gov.caixa.siacg.comum.to.ContaContratoCalculoTO;
import br.gov.caixa.siacg.comum.to.ContaCorrenteCalculoTO;
import br.gov.caixa.siacg.comum.to.GarantiaCartaoCreditoCalculoTO;
import br.gov.caixa.siacg.comum.to.GarantiaContratoCalculoTO;
import br.gov.caixa.siacg.comum.to.SaldoCalculoTO;
import br.gov.caixa.siacg.comum.to.SaldoCartaoBandeiraCalculoTO;
import br.gov.caixa.siacg.dao.BandeiraCartaoDAO;
import br.gov.caixa.siacg.dao.CartaoCreditoDAO;
import br.gov.caixa.siacg.dao.GarantiaCartaoCreditoDAO;
import br.gov.caixa.siacg.model.domain.AnaliseCartaoBandeira;
import br.gov.caixa.siacg.model.domain.AnaliseCartaoCredito;
import br.gov.caixa.siacg.model.domain.BandeiraCartao;
import br.gov.caixa.siacg.model.domain.ContaCorrente;
import br.gov.caixa.siacg.model.domain.ContaCorrenteID;
import br.gov.caixa.siacg.model.enums.CaracteristicaEnum;
import br.gov.caixa.siacg.model.enums.TipoOrigemContaContratoEnum;
import br.gov.caixa.siacg.model.vo.ParametrosCalculoGarantiaVO;
import br.gov.caixa.siacg.model.vo.RelatorioAnaliseContratoVO;
import br.gov.caixa.siacg.strategy.CalculoGarantia;

/**
 * <p>
 * CalculoGarantiaCartaoCredito
 * </p>
 * <p>
 * Descrição: Implementação do calculo para Garantia do tipo Cartão de Credito.
 * </p>
 * <br>
 * <b>Empresa:</b> Cef - Caixa Econômica Federal
 *
 * @author guilherme.santos
 * @author Mábio Barbosa
 * @version 2.0
 */
@Stateless(mappedName = "CalculoGarantiaCartaoCreditoV2")
public class CalculoGarantiaCartaoCreditoV2 implements CalculoGarantia {

    /** Atributo serialVersionUID. */
    private static final long serialVersionUID = -8830469342544664421L;
    
    // Cache de bandeiras
    private static LocalDateTime ultimaAtualizacaoBandeiras = null;
    private static List<BandeiraCartao> listaBandeiras = new ArrayList<>();
    private static Integer duracaoCacheBandeirasMinutos = 60;

    /** Atributo cartaoCreditoDAO. */
    @EJB
    private transient CartaoCreditoDAO cartaoCreditoDAO;
    /** Atributo garantiaCartaoCreditoDAO. */
    @EJB
    private transient GarantiaCartaoCreditoDAO garantiaCartaoCreditoDAO;
    /** Atributo bandeiraCartaoDAO. */
    @EJB
    private transient BandeiraCartaoDAO bandeiraCartaoDAO;

    /**
     * @see br.gov.caixa.siacg.strategy.CalculoGarantia#calcular(br.gov.caixa.siacg.model.vo.ParametrosCalculoGarantiaVO,
     *      br.gov.caixa.siacg.model.vo.RelatorioAnaliseContratoVO)
     */
    @Override
    public RelatorioAnaliseContratoVO calcular(ParametrosCalculoGarantiaVO parametrosCalculo, RelatorioAnaliseContratoVO relatorio) {

	if(relatorio == null) {
	    relatorio = new RelatorioAnaliseContratoVO();
	}
	
	if (parametrosCalculo == null || parametrosCalculo.getGarantiaContrato() == null
		|| parametrosCalculo.getGarantiaContrato().getVrGarantia() == null) {
	    relatorio.setValorApurado(BigDecimal.ZERO);
	    return relatorio;
	}
	
	relatorio.setValorApurado(parametrosCalculo.getValorApurado());
	relatorio.setValorEsperado(parametrosCalculo.getValorEsperado());

	List<BandeiraCartao> listaBandeiraCartao = this.obterListaBandeirasAtivas();
	final GarantiaContratoCalculoTO garantiaContrato = parametrosCalculo.getGarantiaContrato();

	for (final ContaContratoCalculoTO contaContrato : parametrosCalculo.getContrato().getListaContaContrato()) {

	    if (this.isOrigemContaContratoImportadaOuCartao(contaContrato)) {
		final AnaliseCartaoCredito analiseCartao = new AnaliseCartaoCredito();
		final ContaCorrenteCalculoTO contaCorrente = contaContrato.getContaCorrente();
		
		Map<Integer, BigDecimal> mapaSaldoPorBandeira = this.consultarTotalCartao(parametrosCalculo, contaCorrente, listaBandeiraCartao);
		Map<Integer, BigDecimal> mapaVrConsumidoOutrosContratosPorBandeira = this.consultarSaldoOutrosContratos(parametrosCalculo, contaCorrente, listaBandeiraCartao);
		
		for (BandeiraCartao bandeiraCartao : listaBandeiraCartao) {
			boolean possuiSaldoPorBandeira = mapaSaldoPorBandeira.containsKey(bandeiraCartao.getNuBandeiraCartao());
			boolean possuiSaldoOutrosContratos = mapaVrConsumidoOutrosContratosPorBandeira.containsKey(bandeiraCartao.getNuBandeiraCartao());
			if (possuiSaldoPorBandeira || possuiSaldoOutrosContratos) {
				 AnaliseCartaoBandeira analiseCartaoBandeira = new AnaliseCartaoBandeira();
				    analiseCartaoBandeira.setBandeiraCartao(bandeiraCartao);
				    analiseCartaoBandeira.setAnaliseCartao(analiseCartao);

				    // Consultar saldos totais disponiveis para a bandeira
				    analiseCartaoBandeira.setVrSaldoTotal(possuiSaldoPorBandeira 
					    ? mapaSaldoPorBandeira.get(bandeiraCartao.getNuBandeiraCartao())
					    : BigDecimal.ZERO);

				    // Consultar saldos consumidos por garantia de outros
				    // contratos
				    analiseCartaoBandeira.setVrOutrosContratos(possuiSaldoOutrosContratos 
					    ? mapaVrConsumidoOutrosContratosPorBandeira.get(bandeiraCartao.getNuBandeiraCartao())
					    : BigDecimal.ZERO);

				    // Consultar saldo diponivel antes de parametrizar a
				    // garantia
				    analiseCartaoBandeira
					    .setVrSaldoDisponivel(analiseCartaoBandeira.getVrSaldoTotal().subtract(analiseCartaoBandeira.getVrOutrosContratos()));

				    analiseCartaoBandeira.setVrConsumidoContrato(BigDecimal.ZERO);

				    analiseCartao.getAnalisesCartaoBandeira().add(analiseCartaoBandeira);
			}
		}

		// Consumir saldo do cartão de crédito. Se for Pré-Analise não
		// tem saldo para consumir, importando apenas o total da
		// carteira.
		BigDecimal vrConsumidoTotal = garantiaContrato.getContrato().isPreAnalise() ? BigDecimal.ZERO
			: this.consumirSaldoCartaoCredito(garantiaContrato, relatorio, analiseCartao, contaCorrente);

		ContaCorrenteID id = new ContaCorrenteID(contaCorrente.getNuAgencia(), contaCorrente.getNuOperacao(), 
			contaCorrente.getNuConta(), contaCorrente.getNuVerificador());
		ContaCorrente contaCorrenteModel = new ContaCorrente(id);
		analiseCartao.setNuConta(contaCorrenteModel);

		analiseCartao.setIcTipoGarantia(this.getIcTipoGarantiaDefaultSeVazio(garantiaContrato));

		// Adiciona a lista para persistir
		relatorio.getListaAnaliseCartaoCredito().add(analiseCartao);

		// Soma valor apurado
		relatorio.setValorApurado(relatorio.getValorApurado().add(vrConsumidoTotal));

		// Atribui os valores disponiveis para pre-analise
		this.atribuirValoresDisponivelPreAnalise(parametrosCalculo.getSaldo(), analiseCartao);
	    }
	}

	return relatorio;
    }

    /**
     * <p>
     * Método responsável por setar a caracteristica Fluxo, caso a garantia não
     * possua caracteristica, como relatado no remine #517
     * </p>
     * .
     *
     * @author TO-Brasil
     *
     * @param garantiaContrato
     * @return icTipoGarantia
     */
    private String getIcTipoGarantiaDefaultSeVazio(final GarantiaContratoCalculoTO garantiaContrato) {
	return garantiaContrato.getIdentificadorCaracteristica() != null ? garantiaContrato.getIdentificadorCaracteristica()
		: CaracteristicaEnum.FLUXO.getValor();
    }

    /**
     * <p>
     * Método responsável por atribuir os valroes disponiveis para pré-analise.
     * <p>
     *
     * @param relatorio
     *            valor a ser atribuido
     * @param analiseCartao
     *            valor a ser atribuido
     * @author guilherme.santos
     */
    private void atribuirValoresDisponivelPreAnalise(final SaldoCalculoTO saldoPessoa, final AnaliseCartaoCredito analiseCartao) {
    	for (AnaliseCartaoBandeira analiseCartaoBandeira : analiseCartao.getAnalisesCartaoBandeira()) {
    	    SaldoCartaoBandeiraCalculoTO saldoCartaoBandeira = null;
    	    for (SaldoCartaoBandeiraCalculoTO saldoCartao : saldoPessoa.getListaSaldosCartaoBandeira()) {
        		if (saldoCartao.getNuBandeiraCartao().equals(analiseCartaoBandeira.getBandeiraCartao().getNuBandeiraCartao())) {
        		    saldoCartaoBandeira = saldoCartao;
        		    break;
        		}
    	    }
    
    	    if (saldoCartaoBandeira == null) {
        		saldoCartaoBandeira = new SaldoCartaoBandeiraCalculoTO();
        		saldoCartaoBandeira.setNuBandeiraCartao(analiseCartaoBandeira.getBandeiraCartao().getNuBandeiraCartao());
        		saldoCartaoBandeira.setVrCartaoEstoque(BigDecimal.ZERO);
        		saldoCartaoBandeira.setVrCartaoFluxo(BigDecimal.ZERO);
        		saldoCartaoBandeira.setSaldo(saldoPessoa);
        		saldoPessoa.getListaSaldosCartaoBandeira().add(saldoCartaoBandeira);
    	    }
    
    	    if (analiseCartao.getIcTipoGarantia().equals(CaracteristicaEnum.ESTOQUE.getValor())) {
    	    	saldoCartaoBandeira.setVrCartaoEstoque(analiseCartaoBandeira.getVrSaldoDisponivel());
    	    } else if (analiseCartao.getIcTipoGarantia().equals(CaracteristicaEnum.FLUXO.getValor())) {
    	    	saldoCartaoBandeira.setVrCartaoFluxo(analiseCartaoBandeira.getVrSaldoDisponivel());
    	    }
    
    	}
    }

    /**
     * <p>
     * Método responsável por controlar o consumo do saldo dos cartões.
     * <p>
     *
     * @param garantiaContrato
     *            valor a ser atribuido
     * @param relatorio
     *            valor a ser atribuido
     * @param analiseCartao
     *            valor a ser atribuido
     * @param contaCorrente
     *            valor a ser atribuido
     * @author guilherme.santos
     * @author Mábio Barbosa
     */
    private synchronized BigDecimal consumirSaldoCartaoCredito(final GarantiaContratoCalculoTO garantiaContrato, final RelatorioAnaliseContratoVO relatorio,
	    final AnaliseCartaoCredito analiseCartao, final ContaCorrenteCalculoTO contaCorrente) {

	BigDecimal valorPactuado = relatorio.getValorEsperado();
	BigDecimal vrConsumidoTotal = BigDecimal.ZERO;

	for (final GarantiaCartaoCreditoCalculoTO garantiaCartao : garantiaContrato.getListaGarantiaCartaoCredito()) {

	    if (!garantiaCartao.getContaCorrente().equals(contaCorrente)) {
		continue;
	    }

	    // Na tela de cadastro (cartao de credito v2, seleção de percentuais por bandeira), 
	    // o percentual é relativo ao percentual escolhido e não o que de fato sera aplicado
	    // Variavel criada para adptar o valor do percentual para o valor real (que de fato sera aplicado)
	    BigDecimal valorPercentualReal = null;
	    
	    if(garantiaContrato.getVrFormaGarantia1() != null && garantiaContrato.getVrFormaGarantia1().compareTo(BigDecimal.ZERO) > 0) {
	    	//[f734546 - 06/05/2020]: add BigDecimal.ROUND_UP p evitar ArithmeticException
	    	valorPercentualReal = new BigDecimal(100).multiply(garantiaCartao.getPcConcentracao())
	    			.divide(garantiaContrato.getVrFormaGarantia1(), BigDecimal.ROUND_UP);
	    }else {
		valorPercentualReal = garantiaCartao.getPcConcentracao();		
	    }

	    BigDecimal valorBandeira = valorPercentualReal.multiply(valorPactuado).divide(new BigDecimal(100));

	    // Atribui flag para consumo de pre analise
	    garantiaCartao.setIcOrigemPreAnalise(garantiaContrato.getContrato().isPreAnalise());

	    AnaliseCartaoBandeira analiseCartaoBandeira = this.obterAnaliseCartaoBandeira(analiseCartao.getAnalisesCartaoBandeira(),
		    garantiaCartao.getNuBandeiraCartao());

	    if (analiseCartaoBandeira != null) {
		if (analiseCartaoBandeira.getVrSaldoDisponivel().compareTo(valorBandeira) >= 0) {
		    garantiaCartao.setVrConsumido(valorBandeira);
		} else {
		    garantiaCartao.setVrConsumido(analiseCartaoBandeira.getVrSaldoDisponivel());
		}

		analiseCartaoBandeira.setVrSaldoDisponivel(analiseCartaoBandeira.getVrSaldoDisponivel().subtract(garantiaCartao.getVrConsumido()));
		analiseCartaoBandeira.setVrConsumidoContrato(garantiaCartao.getVrConsumido());

		vrConsumidoTotal = vrConsumidoTotal.add(garantiaCartao.getVrConsumido());

		this.garantiaCartaoCreditoDAO.atualizarVrConsumido(garantiaCartao);
	    }
	}

	return vrConsumidoTotal;
    }

    /**
     * 
     * <p>
     * Método responsável por retornar a AnaliseCartaoBandeira que seja
     * equivalente a BandeiraCartao passada por parâmetro
     * </p>
     * .
     *
     * @author Mábio Barbosa
     *
     * @param listaAnaliseCartaoBandeira
     * @param bandeiraCartao
     * @return AnaliseCartaoBandeira
     */
    private AnaliseCartaoBandeira obterAnaliseCartaoBandeira(Collection<AnaliseCartaoBandeira> listaAnaliseCartaoBandeira,
	    final Integer nuBandeiraCartao) {
	for (AnaliseCartaoBandeira analiseCartaoBandeira : listaAnaliseCartaoBandeira) {
	    if (nuBandeiraCartao.equals(analiseCartaoBandeira.getBandeiraCartao().getNuBandeiraCartao())) {
		return analiseCartaoBandeira;
	    }
	}

	return null;
    }

    /**
     * <p>
     * Método responsável por consultar o saldo de garantias de outros
     * contratos.
     * <p>
     *
     * @param parametrosCalculo
     *            valor a ser atribuido
     * @param contaCorrente
     *            valor a ser atribuido
     * @return BigDecimal
     * @author guilherme.santos
     */
    private Map<Integer,BigDecimal> consultarSaldoOutrosContratos(final ParametrosCalculoGarantiaVO parametrosCalculo, final ContaCorrenteCalculoTO contaCorrente,
	    List<BandeiraCartao> listaBandeiraCartao) {
	return this.garantiaCartaoCreditoDAO.calcularSaldoConsumidoOutrosContratos(contaCorrente, listaBandeiraCartao,
		parametrosCalculo.getGarantiaContrato());
    }

    /**
     * <p>
     * Método responsável por consultar o saldo total de cartão.
     * <p>
     *
     * @param parametrosCalculo
     *            valor a ser atribuido
     * @param contaCorrente
     *            valor a ser atribuido
     * @return BigDecimal
     * @author guilherme.santos
     */
    private Map<Integer, BigDecimal> consultarTotalCartao(final ParametrosCalculoGarantiaVO parametrosCalculo, final ContaCorrenteCalculoTO contaCorrente,
	    List<BandeiraCartao> listaBandeiraCartao) {
	return this.cartaoCreditoDAO.calcularSaldoTotalCartao(contaCorrente, listaBandeiraCartao,
		parametrosCalculo.getGarantiaContrato().getIcCaracteristica());
    }

    /**
     * <p>
     * Método responsável por verificar se a origem da conta contrato é
     * importada ou inserida manualmente para cartão de credito.
     * <p>
     *
     * @param contaContrato
     *            valor a ser atribuido
     * @return boolean
     * @author guilherme.santos
     */
    private boolean isOrigemContaContratoImportadaOuCartao(final ContaContratoCalculoTO contaContrato) {
	return TipoOrigemContaContratoEnum.IMPORTADO.equals(contaContrato.getIcOrigem())
		|| TipoOrigemContaContratoEnum.CARTAO_CREDITO.equals(contaContrato.getIcOrigem());
    }
    
    /**
     * <p>Método responsável por obter a lista de bandeiras ativas do cache ou do banco</p>.
     *
     * @author f541915
     *
     * @return
     */
    private List<BandeiraCartao> obterListaBandeirasAtivas() {
	if (ultimaAtualizacaoBandeiras != null) {
	    long time = ChronoUnit.MINUTES.between(ultimaAtualizacaoBandeiras, LocalDateTime.now());
	    if (time > duracaoCacheBandeirasMinutos) {
		ultimaAtualizacaoBandeiras = null;
		listaBandeiras.clear();
	    }
	}
	if (!listaBandeiras.isEmpty()) {
	    return listaBandeiras;
	}
	List<BandeiraCartao> bandeiras = this.bandeiraCartaoDAO.listarTodasBandeirasAtivas();
	if (ultimaAtualizacaoBandeiras == null) {
	    ultimaAtualizacaoBandeiras = LocalDateTime.now();
	}
	listaBandeiras.addAll(bandeiras);
	return bandeiras;
    }
}
