/*
 * Copyright (c) 2019 Caixa Econômica Federal. Todos os direitos
 * reservados.
 *
 * Caixa Econômica Federal - SIACG - Sistema de Crédito Rural
 *
 * Este software foi desenvolvido sob demanda da CAIXA e está
 * protegido por leis de direitos autorais e tratados internacionais. As
 * condições de cópia e utilização do todo ou partes dependem de autorização da
 * empresa. Cópias não são permitidas sem expressa autorização. Não pode ser
 * comercializado ou utilizado para propósitos particulares.
 *
 * Uso exclusivo da Caixa Econômica Federal. A reprodução ou distribuição não
 * autorizada deste programa ou de parte dele, resultará em punições civis e
 * criminais e os infratores incorrem em sanções previstas na legislação em
 * vigor.
 *
 * Histórico do TFS:
 *
 * LastChangedRevision: $Revision$
 * LastChangedBy: $Author$
 * LastChangedDate: $Date$
 *
 * HeadURL: $HeadURL$
 *
 */
package br.gov.caixa.siacg.view.mb;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.logging.Logger;

import javax.ejb.EJB;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;
import javax.faces.context.FacesContext;
import javax.inject.Inject;

import br.gov.caixa.pedesgo.arquitetura.controlador.ManutencaoBean;
import br.gov.caixa.pedesgo.arquitetura.enums.EnumExtensaoArquivo;
import br.gov.caixa.pedesgo.arquitetura.relatorio.UtilRelatorio;
import br.gov.caixa.pedesgo.arquitetura.util.UsuarioUtil;
import br.gov.caixa.pedesgo.arquitetura.util.UtilObjeto;
import br.gov.caixa.siacg.model.domain.Despesa;
import br.gov.caixa.siacg.model.domain.DocumentoLancamentoEvento;
import br.gov.caixa.siacg.model.domain.InstituicaoBancaria;
import br.gov.caixa.siacg.model.vo.DocumentoLancamentoEventoVO;
import br.gov.caixa.siacg.service.DespesaService;
import br.gov.caixa.siacg.service.DocumentoLancamentoEventoService;
import br.gov.caixa.siacg.service.InstituicaoBancariaService;
import br.gov.caixa.siacg.util.LogCEF;
import br.gov.caixa.siacg.view.form.DocumentoLancamentoEventoVisao;

/**
 * <p>
 * DocumentoLancamentoEventoMB
 * </p>
 * <p>
 * Descrição: Managed bean do caso de uso
 * <code>{@link DocumentoLancamentoEventoVO}</code>.
 * </p>
 * <br>
 * <b>Empresa:</b> Cef - Caixa Econômica Federal
 *
 * @author Ludemeula Fernandes de Sá
 * @version 1.0
 */
@ManagedBean
@SessionScoped
public class DocumentoLancamentoEventoMB extends ManutencaoBean<Despesa> {

	private static final long serialVersionUID = -7859440363691079863L;

	private static final Logger LOG = Logger.getLogger(DocumentoLancamentoEventoMB.class.getName());

	public static final String NOME_MANAGED_BEAN = "documentoLancamentoEventoMB";

	public static final String EL_MANAGED_BEAN = "#{documentoLancamentoEventoMB}";

	private static final String PREFIXO_CASO_USO = "documentoLancamentoEvento";

	private static final String PAGINA_CONSULTA = "/pages/execucao/dle/consulta.xhtml?faces-redirect=true";
	private static final String PAGINA_DESPESA = "/pages/execucao/despesa/consulta.xhtml?faces-redirect=true";

	private static final String NOME_RELATORIO_DLE = "relatorio_dle";

	private static final String CAMINHO_RELATORIO_DLE = "/reports/relatorio_dle.jasper";

	private List<InstituicaoBancaria> listaInstituicaoBancaria;

	@EJB
	private DespesaService service;
	
	@Inject
	private DocumentoLancamentoEventoService documentoLancamentoEventoService;

	/** Atributo Instituicao Bancaria */
	@Inject
	private transient InstituicaoBancariaService bancoServico;

	private DocumentoLancamentoEventoVisao visao;
	private DocumentoLancamentoEventoVO dle;

	public String abrir(Despesa despesa) {
		visao = null;
		getVisao().setEntidade(despesa);
		getVisao().getLista().clear();
		getListaInstituicaoBancaria().addAll((this.bancoServico.listarTodos()));
		carregar();

		return PAGINA_CONSULTA;
	}

	@Override
	public void carregar() {
		setDle(service.getDle(getVisao().getEntidade().getNuDespesa()));
	}

	public String voltar() {
		return PAGINA_DESPESA;
	}

	/**
	 * <p>
	 * Método responsável por exportar para PDF os dados da DLE
	 * </p>
	 * .
	 *
	 * @author Ludemeula Fernandes
	 *
	 */
	public void gerarRelatorio() {
		try {
			documentoLancamentoEventoService.salvar(this.crirarDLE(dle));
		} catch (Exception e) {
			LOG.fine("Não foi possível persistir DLE. Detalhes: ");
			LogCEF.error(e);
		}
		try {
			
			getVisao().setTipoArquivo(EnumExtensaoArquivo.PDF);
			getVisao().setColecaoRelatorio(Arrays.asList(dle));
			getVisao().setNomeRelatorio(NOME_RELATORIO_DLE);
			getVisao().setCaminhoRelatorio(CAMINHO_RELATORIO_DLE);
			getVisao().setMapaParametros(montarMapaParametros());

			UtilRelatorio.getInstancia().addCaminhoRelatorio(getVisao().getCaminhoRelatorio()).addColecao(getVisao().getColecaoRelatorio())
					.addResposta(this.getResponse()).addParametros(getVisao().getMapaParametros()).addNomeRelatorio(getVisao().getNomeRelatorio())
					.addExtensaoArquivo(getVisao().getTipoArquivo()).gerarRelatorio();
		} catch (final Exception e) {
			LOG.fine(e.getMessage());
			LogCEF.error(e);
		}
	}

	private DocumentoLancamentoEvento crirarDLE(DocumentoLancamentoEventoVO dle) {
		DocumentoLancamentoEvento retorno = new DocumentoLancamentoEvento();
		retorno.setUnidadeMovimento(dle.getUnidadeMovimento());
		retorno.setUnidadeMovimentoDv(dle.getUnidadeMovimentoDv());
		retorno.setProdutoCodigo(dle.getProdutoCodigo());
		retorno.setProdutoCodigoDv(dle.getProdutoCodigoDv());		
		retorno.setUnidadeDestino(dle.getUnidadeDestino());
		retorno.setUnidadeDestinoDv(dle.getUnidadeDestinoDv());		
		retorno.setAnaliticoCodigo(dle.getAnaliticoCodigo());
		retorno.setAnaliticoCodigoDv(dle.getAnaliticoCodigoDv());		
		retorno.setEmpenho(dle.getEmpenho());
		retorno.setSegCarteira(dle.getSegCarteira());
		retorno.setQuantidade(dle.getQuantidade());
		
		retorno.setCoEvento(dle.getCoEvento());
		retorno.setEventoCodigoDv(dle.getEventoCodigoDv());
		retorno.setTitularImovel(dle.getTitularImovel());
		retorno.setIndicadorRegistro(dle.getIndicadorRegistro());
		retorno.setCentroCusto(dle.getCentroCusto());
		retorno.setCentroCustoDv(dle.getCentroCustoDv());
		retorno.setTipoAnalitico(dle.getTipoAnalitico());
		retorno.setNuDocumento(dle.getNuDocumento());
		retorno.setNoEvento(dle.getNoEvento());
		retorno.setVrDespesa(dle.getVrDespesa());		
		retorno.setDataMovimento(dle.getDataMovimento());
		retorno.setSituacaoLancamento(dle.getSituacaoLancamento());		
		retorno.setDataEfetiva(dle.getDataEfetiva());		
		retorno.setProjeto(dle.getProjeto());
		retorno.setNuConciliacao(dle.getNuConciliacao());
		retorno.setAviso(dle.getAviso());
		retorno.setTipo(dle.getTipo());
		
		//DOC/TED
		retorno.setRemetente(dle.getRemetente());
		retorno.setTelefone(dle.getTelefone());
		retorno.setCnpj(dle.getCnpj());
		retorno.setCpfcnpjFavorecido(dle.getCpfcnpjFavorecido());
		retorno.setDataTransferencia(dle.getDataTransferencia());
		retorno.setTitularConta(dle.getTitularConta());
		retorno.setNoBanco(dle.getNoBanco());		
		retorno.setNuAgencia(dle.getNuAgencia());
		retorno.setNuConta(dle.getNuConta());
		
		// Aviso de crédito
		retorno.setNuAgencia(dle.getNuAgencia());
		//retorno.setOperacao(dle.getOperacao());
		retorno.setNuConta(dle.getNuConta());
		retorno.setNuContaDv(dle.getNuContaDv());
		retorno.setTitularConta(dle.getTitularConta());
		retorno.setNuDocumento(dle.getNumeroDocumento());
		retorno.setCl(dle.getCl());
		retorno.setClDv(dle.getClDv());
		retorno.setDataValorizacao(dle.getDataValorizacao());		
		retorno.setTipo(dle.getTipo());		
		retorno.setVrDespesa(dle.getVrDespesa());
		return retorno;
	}

	/**
	 * <p>
	 * Método responsável por montar o mapa de parametros passado para o
	 * relatorio de unidades habitacionais.
	 * <p>
	 *
	 */
	private Map<String, Object> montarMapaParametros() {
		final Map<String, Object> parametros = new LinkedHashMap<>();
		parametros.put("LOGO_CAIXA", FacesContext.getCurrentInstance().getExternalContext().getResourceAsStream("/resources/img/caixa_logo.jpg"));
		parametros.put("MATRICULA_USUARIO", UsuarioUtil.getUsuarioLogado().getDeMatricula());

		return parametros;
	}

	@Override
	protected String getPrefixoCasoDeUso() {
		return PREFIXO_CASO_USO;
	}

	@SuppressWarnings("unchecked")
	@Override
	public DespesaService getService() {
		return this.service;
	}

	@Override
	public DocumentoLancamentoEventoVisao getVisao() {
		if (!UtilObjeto.isReferencia(visao)) {
			this.visao = new DocumentoLancamentoEventoVisao();
		}

		return this.visao;
	}

	/**
	 * @return the dle
	 */
	public DocumentoLancamentoEventoVO getDle() {
		return dle;
	}

	/**
	 * @param dle
	 *            the dle to set
	 */
	public void setDle(DocumentoLancamentoEventoVO dle) {
		this.dle = dle;
	}

	/**
	 * <p>
	 * Retorna o valor do atributo listaInstituicaoBancaria
	 * </p>
	 * .
	 *
	 * @return listaInstituicaoBancaria
	 */
	public List<InstituicaoBancaria> getListaInstituicaoBancaria() {
		if (!UtilObjeto.isReferencia(listaInstituicaoBancaria)) {
			this.listaInstituicaoBancaria = new ArrayList<>();
		}
		return this.listaInstituicaoBancaria;
	}

	/**
	 * <p>
	 * Define o valor do atributo listaInstituicaoBancaria
	 * </p>
	 * .
	 *
	 * @param listaInstituicaoBancaria
	 *            valor a ser atribuído
	 */
	public void setListaInstituicaoBancaria(List<InstituicaoBancaria> listaInstituicaoBancaria) {
		this.listaInstituicaoBancaria = listaInstituicaoBancaria;
	}
}