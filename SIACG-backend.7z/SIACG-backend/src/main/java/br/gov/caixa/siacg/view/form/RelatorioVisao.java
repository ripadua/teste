package br.gov.caixa.siacg.view.form;

import br.gov.caixa.pedesgo.arquitetura.visao.ManutencaoVisao;
import br.gov.caixa.siacg.model.domain.Relatorio;

/**
 * <p>
 * RelatorioVisao
 * </p>
 * <p>
 * Descrição: Classe de visão auxiliar do Bean.
 * </p>
 * <br>
 * <b>Empresa:</b> Cef - Caixa Econômica Federal
 *
 * @author Waltenes Junior
 * @version 1.0
 */
public class RelatorioVisao extends ManutencaoVisao<Relatorio> {

    /** Constante serialVersionUID. */
    private static final long serialVersionUID = -5841147717765888545L;
    
    /** Atributo codApf. */
    private String codApf;
    
    /** Atributo cpfCnpj. */
    private String cpfCnpj;
    
    /** Atributo cpfCnpj. */
    private String opcaoCpfCnpj = "1";
    
    /** Atributo ativa Campo. */
    private boolean ativaCampo = true;
    
    	/** Atributo nuEmpreendimento. */
	private Long nuEmpreendimento;
    
  
	/**
	 * <p>Retorna o valor do atributo codApf</p>.
	 *
	 * @return codApf
	*/
	public String getCodApf() {
		return this.codApf;
	}

	/**
	 * <p>Define o valor do atributo codApf</p>.
	 *
	 * @param codApf valor a ser atribuído
	*/
	public void setCodApf(String codApf) {
	this.codApf = codApf;}

	/**
	 * <p>Retorna o valor do atributo cpfCnpj</p>.
	 *
	 * @return cpfCnpj
	*/
	public String getCpfCnpj() {
		return this.cpfCnpj;
	}

	/**
	 * <p>Define o valor do atributo cpfCnpj</p>.
	 *
	 * @param cpfCnpj valor a ser atribuído
	*/
	public void setCpfCnpj(String cpfCnpj) {
	this.cpfCnpj = cpfCnpj;}

	/**
	 * <p>Retorna o valor do atributo opcaoCpfCnpj</p>.
	 *
	 * @return opcaoCpfCnpj
	*/
	public String getOpcaoCpfCnpj() {
		return this.opcaoCpfCnpj;
	}

	/**
	 * <p>Define o valor do atributo opcaoCpfCnpj</p>.
	 *
	 * @param opcaoCpfCnpj valor a ser atribuído
	*/
	public void setOpcaoCpfCnpj(String opcaoCpfCnpj) {
	this.opcaoCpfCnpj = opcaoCpfCnpj;}

	/**
	 * <p>Retorna o valor do atributo ativaCampo</p>.
	 *
	 * @return ativaCampo
	*/
	public boolean isAtivaCampo() {
		return this.ativaCampo;
	}

	/**
	 * <p>Define o valor do atributo ativaCampo</p>.
	 *
	 * @param ativaCampo valor a ser atribuído
	*/
	public void setAtivaCampo(boolean ativaCampo) {
	this.ativaCampo = ativaCampo;}
    
	/**
	 * <p>
	 * Método responsável por selecionar o tipo de busca campo cpf/cnpj.
	 * <p>
	 *
	 * @author Brunno Antunes
	 */
	
	public void campoCpfCnpj() {
		this.ativaCampo = this.opcaoCpfCnpj.equals("1");
	}

	public Long getNuEmpreendimento() {
	    return this.nuEmpreendimento;
	}

	public void setNuEmpreendimento(Long nuEmpreendimento) {
	    this.nuEmpreendimento = nuEmpreendimento;
	}
}
