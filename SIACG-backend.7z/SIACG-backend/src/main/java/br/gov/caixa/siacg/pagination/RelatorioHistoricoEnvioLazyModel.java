/**
 * Copyright (c) 2020 Caixa Econômica Federal. Todos os direitos
 * reservados.
 *
 * Caixa Econômica Federal - SIACG - Sistema de Crédito Rural
 *
 * Este software foi desenvolvido sob demanda da CAIXA e está
 * protegido por leis de direitos autorais e tratados internacionais. As
 * condições de cópia e utilização do total ou partes dependem de autorização da
 * empresa. Cópias não são permitidas sem expressa autorização. Não pode ser
 * comercializado ou utilizado para propósitos particulares.
 *
 * Uso exclusivo da Caixa Econômica Federal. A reprodução ou distribuição não
 * autorizada deste programa ou de parte dele, resultará em punições civis e
 * criminais e os infratores incorrem em sanções previstas na legislação em
 * vigor.
 *
 * Histórico do TFS:
 *
 * LastChangedRevision: $Revision$
 * LastChangedBy: $Author$
 * LastChangedDate: $Date$
 *
 * HeadURL: $HeadURL$
 *
 */
package br.gov.caixa.siacg.pagination;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.Map;

import javax.ejb.EJB;
import javax.enterprise.context.SessionScoped;
import javax.inject.Named;

import org.primefaces.model.SortOrder;

import br.gov.caixa.pedesgo.arquitetura.paginacao.Paginacao;
import br.gov.caixa.siacg.model.domain.EnvioNotificacao;
import br.gov.caixa.siacg.model.vo.FiltroEnvioNotificacaoVO;
import br.gov.caixa.siacg.service.EnvioNotificacaoService;
import br.gov.caixa.siacg.view.form.EnvioNotificacaoVisao;

/**
 * <p>
 * RelatorioMensageriaLazyModel
 * </p>
 *
 * <p>
 * Descrição: Descrição do tipo
 * </p>
 *
 * <br>
 * <b>Empresa:</b> Cef - Caixa Econômica Federal
 *
 *
 * @author f725905
 *
 * @version 1.0
 */
@Named
@SessionScoped
public class RelatorioHistoricoEnvioLazyModel extends Paginacao<EnvioNotificacao> {

    /** Atributo serialVersionUID. */
    private static final long serialVersionUID = 1L;

    @EJB
    private EnvioNotificacaoService envioNotificacaoService;

    private EnvioNotificacaoVisao visao;

    /**
     * @see br.gov.caixa.pedesgo.arquitetura.paginacao.Paginacao#getServico()
     */
    @SuppressWarnings("unchecked")
    @Override
    public EnvioNotificacaoService getServico() {
	return envioNotificacaoService;
    }

    /**
     * @see br.gov.caixa.pedesgo.arquitetura.paginacao.Paginacao#load(int, int,
     *      java.lang.String, org.primefaces.model.SortOrder, java.util.Map)
     */
    @Override
    public List<EnvioNotificacao> load(final int inicio, final int fim, final String campoOrdenacao, final SortOrder ordenacao,
	    final Map<String, String> parametros) {

	final FiltroEnvioNotificacaoVO filtroEnvioNotificacaoVO = this.visao.getFiltroEnvioNotificacaoVO();
	filtroEnvioNotificacaoVO.setCampoOrdenacao(campoOrdenacao);
	filtroEnvioNotificacaoVO.setTipoOrdenacao(ordenacao.name());
	Collection<EnvioNotificacao> envioNotificacaos = this.envioNotificacaoService.listarNotificacaoPorFiltro(filtroEnvioNotificacaoVO, inicio,
		fim);

	super.setWrappedData(envioNotificacaos);
	super.setRowCount(this.envioNotificacaoService.countListarNotificacaoPorFiltro(filtroEnvioNotificacaoVO).intValue());
	return new ArrayList<EnvioNotificacao>(envioNotificacaos);
    }

    /**
     * <p>
     * Retorna o valor do atributo visao
     * </p>
     * .
     *
     * @return visao
     */
    public EnvioNotificacaoVisao getVisao() {
	return this.visao;
    }

    /**
     * <p>
     * Define o valor do atributo visao
     * </p>
     * .
     *
     * @param visao
     *            valor a ser atribuído
     */
    public void setVisao(EnvioNotificacaoVisao visao) {
	this.visao = visao;
    }

}
