/**
 * Copyright (c) 2020 Caixa Econômica Federal. Todos os direitos
 * reservados.
 *
 * Caixa Econômica Federal - SIACG - Sistema de Crédito Rural
 *
 * Este software foi desenvolvido sob demanda da CAIXA e está
 * protegido por leis de direitos autorais e tratados internacionais. As
 * condições de cópia e utilização do total ou partes dependem de autorização da
 * empresa. Cópias não são permitidas sem expressa autorização. Não pode ser
 * comercializado ou utilizado para propósitos particulares.
 *
 * Uso exclusivo da Caixa Econômica Federal. A reprodução ou distribuição não
 * autorizada deste programa ou de parte dele, resultará em punições civis e
 * criminais e os infratores incorrem em sanções previstas na legislação em
 * vigor.
 *
 * Histórico do TFS:
 *
 * LastChangedRevision: $Revision$
 * LastChangedBy: $Author$
 * LastChangedDate: $Date$
 *
 * HeadURL: $HeadURL$
 *
 */
package br.gov.caixa.siacg.view.mb;

import java.io.Serializable;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.ejb.EJB;
import javax.ejb.Singleton;
import javax.ejb.Startup;

import br.gov.caixa.siacg.service.TrilhaHistoricoService;

/**
 * <p>
 * SiacgMB
 * </p>
 *
 * <p>
 * Descrição: Descrição do tipo
 * </p>
 *
 * <br>
 * <b>Empresa:</b> Cef - Caixa Econômica Federal
 *
 *
 * @author f725905
 *
 * @version 1.0
 */

@Singleton
@Startup
public class SiacgMB implements Serializable {

    /** Atributo serialVersionUID. */
    private static final long serialVersionUID = 1L;

    /** Atributo IC_ACAO. */
    private static final String IC_ACAO = "icAcao";

    /** Atributo NO_ACAO. */
    private static final String NO_ACAO = "noAcao";

    /** Atributo service. */
    @EJB
    private transient TrilhaHistoricoService trilhaHistoricoService;

    private List<String> noAcaoList;

    private List<String> icAcaoList;

    @PostConstruct
    public void init() {
	this.noAcaoList = this.trilhaHistoricoService.getListDe(SiacgMB.NO_ACAO);
	this.icAcaoList = this.trilhaHistoricoService.getListDe(SiacgMB.IC_ACAO);
    }

    /**
     * <p>
     * Retorna o valor do atributo noAcaoList
     * </p>
     * .
     *
     * @return noAcaoList
     */
    public List<String> getNoAcaoList() {
	return this.noAcaoList;
    }

    /**
     * <p>
     * Retorna o valor do atributo icAcaoList
     * </p>
     * .
     *
     * @return icAcaoList
     */
    public List<String> getIcAcaoList() {
	return this.icAcaoList;
    }

}
