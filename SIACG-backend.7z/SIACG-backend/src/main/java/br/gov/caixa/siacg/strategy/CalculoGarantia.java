package br.gov.caixa.siacg.strategy;

import java.io.Serializable;
import java.util.Map;

import org.apache.log4j.Logger;

import br.gov.caixa.siacg.comum.to.GarantiaContratoCalculoTO;
import br.gov.caixa.siacg.model.vo.ParametrosCalculoGarantiaVO;
import br.gov.caixa.siacg.model.vo.RelatorioAnaliseContratoVO;

/**
 * <p>
 * RealizaCalculo
 * </p>
 * <p>
 * Descrição: Interface dos tipos de calculos. Adotando padrão de projeto
 * Strategy.
 * </p>
 * <br>
 * <b>Empresa:</b> Cef - Caixa Econômica Federal
 *
 * @author guilherme.santos
 * @version 1.0
 */
public interface CalculoGarantia extends Serializable {
    
    public static final Logger LOG = Logger.getLogger(CalculoGarantia.class);

    /**
     * <p>
     * Método responsável por calcular o valor apurado da garantia.
     * <p>
     *
     * @param parametrosCalculo
     *            valor a ser atribuido
     * @param relatorio
     *            valor a ser atribuido
     * @return RelatorioAnaliseContratoVO
     * @author guilherme.santos
     */
    RelatorioAnaliseContratoVO calcular(final ParametrosCalculoGarantiaVO parametrosCalculo, final RelatorioAnaliseContratoVO relatorio);
    
    /**
     * <p>Método responsável por parametrizar a garantia do contrato</p>.
     *
     * @author f541915
     *
     * @param parametrosCalculo
     * @param valores
     */
    default void parametrizar(final GarantiaContratoCalculoTO garantiaContrato, Map<String, Object> valores) {
	LOG.info("Parametrização automatica nao disponivel");
    }
}
