/**
 * reservados. Copyright (c) 2009-2011 Caixa Econômica Federal. Todos os direitos
 *
 * Caixa Econômica Federal - SIACG – Sistema de Acompanhamento de Carteiras de Cobrança
 *
 * Este programa de computador foi desenvolvido sob demanda da CAIXA e está protegido por leis de direitos autorais e
 * tratados internacionais. As condições de cópia e utilização do todo ou partes dependem de autorização da pessoa.
 * Cópias não são permitidas sem expressa autorização. Não pode ser comercializado ou utilizado para propósitos
 * particulares.
 *
 * Uso exclusivo da Caixa Econômica Federal. A reprodução ou distribuição não autorizada deste programa ou de parte
 * dele, resultará em punições civis e criminais e os infratores incorrem em sanções previstas na legislação em vigor.
 *
 * Histórico do Subversion:
 *
 * LastChangedRevision: LastChangedBy: LastChangedDate:
 *
 * HeadURL:
 *
 */
package br.gov.caixa.siacg.commons;

/**
 * <p>
 * ReportErrorCreateDatasourceException
 * </p>
 * <p>
 * Descrição: Classe ReportErrorCreateDatasourceException
 * </p>
 * <br>
 * <b>Empresa:</b> Cef - Caixa Econômica Federal.
 *
 * @author GS Tecnologia
 * @version 1.0
 */
public class ReportErrorCreateDatasourceException extends Exception {

    /** Constante serialVersionUID. */
    private static final long serialVersionUID = 8238001656871744863L;

    /**
     * Construtor report error create datasource exception.
     *
     * @param mensagem
     *            the mensagem
     */
    public ReportErrorCreateDatasourceException(final String mensagem) {
        super(mensagem);
    }

    /**
     * Construtor report error create datasource exception.
     *
     * @param mensagem
     *            the mensagem
     * @param exc
     *            the exc
     */
    public ReportErrorCreateDatasourceException(final String mensagem, final Throwable exc) {
        super(mensagem, exc);
    }

}
