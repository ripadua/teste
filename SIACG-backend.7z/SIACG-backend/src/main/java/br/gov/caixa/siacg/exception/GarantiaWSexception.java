/*
 * Copyright (c) 2020 Caixa Econômica Federal. Todos os direitos
 * reservados.
 *
 * Caixa Econômica Federal - SIACG - Sistema de Crédito Rural
 *
 * Este software foi desenvolvido sob demanda da CAIXA e está
 * protegido por leis de direitos autorais e tratados internacionais. As
 * condições de cópia e utilização do todo ou partes dependem de autorização da
 * empresa. Cópias não são permitidas sem expressa autorização. Não pode ser
 * comercializado ou utilizado para propósitos particulares.
 *
 * Uso exclusivo da Caixa Econômica Federal. A reprodução ou distribuição não
 * autorizada deste programa ou de parte dele, resultará em punições civis e
 * criminais e os infratores incorrem em sanções previstas na legislação em
 * vigor.
 *
 * Histórico do TFS:
 *
 * LastChangedRevision: $Revision$
 * LastChangedBy: $Author$
 * LastChangedDate: $Date$
 *
 * HeadURL: $HeadURL$
 *
 */
package br.gov.caixa.siacg.exception;

import javax.ws.rs.core.Response.Status;

/**
 * <p>
 * GarantiaWSexception
 * </p>
 *
 * <p>
 * Descrição: Classe responsável por representar uma exceção que pode ser
 * lançada durante a execução do serviço de garantia (GarantiaWS).
 * </p>
 *
 * <br>
 * <b>Empresa:</b> Cef - Caixa Econômica Federal
 *
 *
 * @author gerusa.soares
 *
 * @version 1.0
 */
public class GarantiaWSexception extends Exception {

    /** Atributo serialVersionUID. */
    private static final long serialVersionUID = 1L;

    private final Status status;
    private final String retornoJson;

    /**
     * Responsável pela criação de novas instâncias desta classe.
     *
     * @param status
     * @param retornoJson
     *
     */
    public GarantiaWSexception(final Status status, final String retornoJson) {
	super();
	this.status = status;
	this.retornoJson = retornoJson;
    }

    /**
     * <p>
     * Retorna o valor do atributo status
     * </p>
     * .
     *
     * @return status
     */
    public Status getStatus() {
	return this.status;
    }

    /**
     * <p>
     * Retorna o valor do atributo retornoJson
     * </p>
     * .
     *
     * @return retornoJson
     */
    public String getRetornoJson() {
	return this.retornoJson;
    }

}
