package br.gov.caixa.siacg.comum.to;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

@JsonIgnoreProperties(ignoreUnknown = true)
public class ControlePaginacaoTO {

    @JsonProperty(value = "numero_ocorrencias")
    private Integer numeroOcorrencias;

    @JsonProperty(value = "numero_controle_paginacao")
    private Integer numeroControlePaginacao;

    public ControlePaginacaoTO() {
	super();
    }

    public Integer getNumeroOcorrencias() {
	return numeroOcorrencias;
    }

    public void setNumeroOcorrencias(Integer numeroOcorrencias) {
	this.numeroOcorrencias = numeroOcorrencias;
    }

    public Integer getNumeroControlePaginacao() {
	return numeroControlePaginacao;
    }

    public void setNumeroControlePaginacao(Integer numeroControlePaginacao) {
	this.numeroControlePaginacao = numeroControlePaginacao;
    }

}
