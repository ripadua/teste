package br.gov.caixa.siacg.view.form;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;

import br.gov.caixa.pedesgo.arquitetura.visao.ManutencaoVisao;
import br.gov.caixa.siacg.model.domain.Propriedade;

/**
 * <p>
 * DestinatarioVisao
 * </p>
 * <p>
 * Descrição: Classe DestinatarioVisao
 * </p>
 * <br>
 * <b>Empresa:</b> Cef - Caixa Econômica Federal.
 *
 * @author GS Tecnologia
 * @version 1.0
 */
public class RemetenteVisao extends ManutencaoVisao<Propriedade> {

    /** Constante serialVersionUID. */
    private static final long serialVersionUID = 1240145123096667341L;

    /** Atributo destinatario list. */
    private List<Propriedade> propriedadeList;

    /** Atributo destinatario. */
    private Propriedade propriedade;

    /** Constante PAGINA_DESTINATARIO. */
    public static final String PAGINA_REMETENTE = "/pages/email/remetente/remetente.xhtml?faces-redirect=true";

    /**
     * Construtor destinatario visao.
     */
    public RemetenteVisao() {
        this.propriedadeList = new ArrayList<>();
        this.propriedade = new Propriedade();
    }

    /**
     * Retorna o valor do atributo destinatarioList.
     *
     * @return destinatarioList
     */
    public List<Propriedade> getPropriedadeList() {
        this.propriedadeList = new ArrayList<>(new HashSet<Propriedade>(this.propriedadeList));
        return this.propriedadeList;
    }

    /**
     * Define o valor do atributo destinatarioList.
     *
     * @param destinatarioList
     *            valor a ser atribuído
     */
    public void setPropriedadeList(final List<Propriedade> propriedadeList) {
        this.propriedadeList = propriedadeList;
    }

    /**
     * Retorna o valor do atributo destinatario.
     *
     * @return destinatario
     */
    public Propriedade getPropriedade() {

        return this.propriedade;
    }

    /**
     * Define o valor do atributo destinatario.
     *
     * @param destinatario
     *            valor a ser atribuído
     */
    public void setPropriedade(final Propriedade propriedade) {

        this.propriedade = propriedade;
    }

    /**
     * <p>
     * Método responsável por.
     * <p>
     *
     * @param ic
     *            valor a ser atribuido
     * @return String
     */
    public String mostrarNomeRemetente(final String ic) {
        String retorno = "";
        if ("01".equals(ic)) {
            retorno = "Gestor do Sistema";
        } else if ("02".equals(ic)) {
            retorno = "Auditoria";
        } else if ("03".equals(ic)) {
            retorno = "Gestor do Risco";
        }

        return retorno;

    }
}
