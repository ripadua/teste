package br.gov.caixa.siacg.view.mb;

import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;
import javax.inject.Inject;

import org.apache.commons.codec.binary.Base64;
import org.primefaces.event.FileUploadEvent;

import br.gov.caixa.pedesgo.arquitetura.controlador.AbstractBean;
import br.gov.caixa.pedesgo.arquitetura.controlador.ManutencaoBean;
import br.gov.caixa.pedesgo.arquitetura.util.MensagensUtil;
import br.gov.caixa.siacg.commons.AppConstant;
import br.gov.caixa.siacg.commons.MsgConstant;
import br.gov.caixa.siacg.model.domain.BandeiraCartao;
import br.gov.caixa.siacg.model.vo.FiltroBandeiraCartaoVO;
import br.gov.caixa.siacg.service.BandeiraCartaoService;
import br.gov.caixa.siacg.view.form.BandeiraCartaoVisao;

/**
 * <p>
 * BandeiraCartaoMB.
 * </p>
 * <p>
 * Descrição: Bean Gerenciável para o UC de Bandeiras de Cartão.
 * </p>
 * <br>
 * <b>Empresa:</b> Cef - Caixa Econômica Federal
 *
 * @author Marco Isecke
 * @author ludemeula.sa
 * @version 1.0
 */
@ManagedBean
@SessionScoped
public class BandeiraCartaoMB extends ManutencaoBean<BandeiraCartao> {

	private static final long serialVersionUID = 4617104820337665444L;

	private static final String DIRETORIO_PAGINAS = "/pages/bandeiraCartao";
	private static final String PREFIXO_CASO_USO = "bandeiraCartao";
	private static final Integer ORIGEM_API = 2;

	private BandeiraCartaoVisao visao;

	@Inject
	private BandeiraCartaoService servico;

	/**
	 * @see br.gov.caixa.pedesgo.arquitetura.controlador.AbstractBean#carregar()
	 */
	@Override
	public void carregar() {
		if (getVisao() == null) {
			visao = new BandeiraCartaoVisao();
		}
		getVisao().setLista(getService().pesquisar(new FiltroBandeiraCartaoVO()));
		limpar();
	}
	
	public void editar(BandeiraCartao bandeiraCartao) {
		getVisao().setEntidade(bandeiraCartao);
		getVisao().setInclusao(Boolean.TRUE);
		
		getVisao().getEntidade().setAlteracao(Boolean.TRUE);
	}
	
	public void ativar() {
		getVisao().getEntidade().setIcAtivo(!getVisao().getEntidade().isIcAtivo());
		
		getService().alterar(getVisao().getEntidade());
		limpar();
	}

	public void novo() {
		getVisao().setEntidade(new BandeiraCartao());
		getVisao().getEntidade().setIcOrigem(ORIGEM_API);
		getVisao().setInclusao(Boolean.TRUE);
	}
	
	public void cancelar() {
		visao = new BandeiraCartaoVisao();
		limpar();
	}
	
	public void salvar() {
		getService().persistir(getVisao().getEntidade());
		
		if (getVisao().getEntidade().hasMensagens()) {
			adicionaListaMensagemDeAlerta(getVisao().getEntidade().getMensagens());
		} else {
			getVisao().setMensagemModal(MensagensUtil.getMensagem(getNomeVarResourceBundle(), MsgConstant.OPERACAO_COM_SUCESSO));
		}
	}

	public void pesquisar() {
		getVisao().setLista(getService().pesquisar(getVisao().getFiltro()));
	}

	public void limpar() {
		getVisao().setFiltro(new FiltroBandeiraCartaoVO());
		getVisao().setLista(getService().pesquisar(new FiltroBandeiraCartaoVO()));
	}
	
	public void uploadArquivo(final FileUploadEvent fileUploadEvent) {
        String nomeArquivo = fileUploadEvent.getFile().getFileName();

        if (nomeArquivo.trim().length() > 20) {

            nomeArquivo = nomeArquivo.substring(0, 20);
        }
        
        Base64 base64 = new Base64();

        getVisao().getEntidade().setImBandeiraCartao(new String(base64.encode(fileUploadEvent.getFile().getContents())));
    }
	/*******************************************************************
	 * GETTERS && SETTERS
	 ******************************************************************/
	@Override
	protected String getNomeVarResourceBundle() {
		return AppConstant.RESOURCE_BUNDLE;
	}
	
	@Override
	protected String getPrefixoCasoDeUso() {
		return BandeiraCartaoMB.PREFIXO_CASO_USO;
	}

	@Override
	public String getTelaConsulta() {
		return BandeiraCartaoMB.DIRETORIO_PAGINAS + this.getPrefixoCasoDeUso() + AbstractBean.SUFIXO_TELA_CONSULTA;
	}

	@SuppressWarnings("unchecked")
	@Override
	public BandeiraCartaoService getService() {
		return this.servico;
	}

	@Override
	public BandeiraCartaoVisao getVisao() {
		if (this.visao == null) {
			this.visao = new BandeiraCartaoVisao();
		}
		return this.visao;
	}
}