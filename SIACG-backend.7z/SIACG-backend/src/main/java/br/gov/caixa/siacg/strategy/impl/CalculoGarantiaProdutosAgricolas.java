package br.gov.caixa.siacg.strategy.impl;

import java.math.BigDecimal;

import javax.ejb.Stateless;

import br.gov.caixa.siacg.model.vo.ParametrosCalculoGarantiaVO;
import br.gov.caixa.siacg.model.vo.RelatorioAnaliseContratoVO;
import br.gov.caixa.siacg.strategy.CalculoGarantia;

/**
 * <p>
 * CalculoGarantiaProdutosAgricolas
 * </p>
 * <p>
 * Descrição: Implementação do calculo para Garantia do tipo Produtos Agricolas
 * Equipamento.
 * </p>
 * <br>
 * <b>Empresa:</b> Cef - Caixa Econômica Federal
 *
 * @author brunno.antunes
 * @version 1.0
 */
@Stateless(mappedName = "CalculoGarantiaProdutosAgricolas")
public class CalculoGarantiaProdutosAgricolas implements CalculoGarantia {

	private static final long serialVersionUID = 7170040531431287763L;

	/**
	 * @see br.gov.caixa.siacg.strategy.CalculoGarantia#calcular(br.gov.caixa.siacg.model.vo.ParametrosCalculoGarantiaVO)
	 */
	@Override
	public RelatorioAnaliseContratoVO calcular(ParametrosCalculoGarantiaVO parametrosCalculo, RelatorioAnaliseContratoVO relatorio) {

		if (relatorio == null) {
			relatorio = new RelatorioAnaliseContratoVO();
		}

		if (parametrosCalculo == null || parametrosCalculo.getGarantiaContrato() == null
				|| parametrosCalculo.getGarantiaContrato().getVrGarantia() == null) {
			relatorio.setValorApurado(BigDecimal.ZERO);
			return relatorio;
		}

		relatorio.setValorApurado(parametrosCalculo.getGarantiaContrato().getVrGarantia());

		return relatorio;
	}
}