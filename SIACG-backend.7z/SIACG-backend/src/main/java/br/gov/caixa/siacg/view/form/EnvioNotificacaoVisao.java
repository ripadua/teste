package br.gov.caixa.siacg.view.form;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.List;

import br.gov.caixa.pedesgo.arquitetura.util.UtilObjeto;
import br.gov.caixa.pedesgo.arquitetura.visao.ManutencaoVisao;
import br.gov.caixa.siacg.model.domain.EnvioNotificacao;
import br.gov.caixa.siacg.model.domain.GrupoGarantia;
import br.gov.caixa.siacg.model.enums.NivelEnum;
import br.gov.caixa.siacg.model.enums.SegmentacaoEnum;
import br.gov.caixa.siacg.model.vo.ContratoParametrizadoVO;
import br.gov.caixa.siacg.model.vo.FiltroAnaliseCarteiraVO;
import br.gov.caixa.siacg.model.vo.FiltroEnvioNotificacaoVO;
import br.gov.caixa.siacg.model.vo.SrVO;
import br.gov.caixa.siacg.model.vo.UnidadeVO;
import br.gov.caixa.siacg.view.mb.EnvioNotificacaoMB;

/**
 * <p>
 * EnvioNotificacaoVisao
 * </p>
 * <p>
 * Descrição: Classe de visao auxiliar da classe bean {@link EnvioNotificacaoMB}
 * responsável por armazenar os objetos(gets e sets).
 * </p>
 * 
 * <b>Empresa:</b> Cef - Caixa Econômica Federal
 *
 * @author Waltenes Junior
 * @version 1.0
 */
public class EnvioNotificacaoVisao extends ManutencaoVisao<EnvioNotificacao> {

    /** Constante serialVersionUID. */
    private static final long serialVersionUID = 679475466858503169L;

    /** Atributo expressao. */
    private String expressao;

    /** Atributo unidade selecionada. */
    private Integer unidadeSelecionada;

    /** Atributo sr selecionada. */
    private Integer srSelecionada;

    /** Atributo suat selecionada. */
    private Integer suatSelecionada;

    /** Atributo habilitar suat. */
    private boolean habilitarSuat;

    /** Atributo habilitar sr. */
    private boolean habilitarSr;

    /** Atributo habilitar unidade. */
    private boolean habilitarUnidade;

    /** Atributo envio automatico. */
    private boolean envioAutomatico;

    /** Atributo filtro. */
    private FiltroAnaliseCarteiraVO filtro;

    /** Atributo filtro envio notificacao vo. */
    private FiltroEnvioNotificacaoVO filtroEnvioNotificacaoVO;

    /** Atributo listaSegmento. */
    private Collection<SegmentacaoEnum> listaSegmento;

    /** Atributo lista unidade. */
    private Collection<UnidadeVO> listaUnidade;

    /** Atributo lista suat. */
    private Collection<UnidadeVO> listaSuat;

    /** Atributo lista sr. */
    private Collection<SrVO> srList;

    /** Atributo lista grupo garantia. */
    private Collection<GrupoGarantia> listaGrupoGarantia;

    /** Atributo lista contrato insuficiente. */
    private Collection<ContratoParametrizadoVO> listaContratoInsuficiente;

    /** Atributo lista contrato insuficiente selecionado. */
    private List<ContratoParametrizadoVO> listaContratoInsuficienteSelecionado;
    
    private List<UnidadeVO> listaDires;
    private Collection<UnidadeVO> unidadeList;
    private Integer tipoConfig;
    private Integer nuSuat;
	private Integer nuSr;
    private Integer codSuvSelecionado;

    /**
     * <p>
     * Método responsável por obter o array de niveis.
     * <p>
     *
     * @return NivelEnum[]
     * @author Waltenes Junior
     */
    public NivelEnum[] getArrayNivel() {
        return NivelEnum.values();
    }

    /**
     * Retorna o valor do atributo listaUnidade.
     *
     * @return listaUnidade
     */
    public Collection<UnidadeVO> getListaUnidade() {
        if (!UtilObjeto.isReferencia(this.listaUnidade)) {
            this.listaUnidade = new ArrayList<>();
        }

        return this.listaUnidade;
    }

    /**
     * Define o valor do atributo listaUnidade.
     *
     * @param listaUnidade
     *            valor a ser atribuído
     */
    public void setListaUnidade(final Collection<UnidadeVO> listaUnidade) {
        this.listaUnidade = listaUnidade;
    }

    /**
     * Retorna o valor do atributo listaSuat.
     *
     * @return listaSuat
     */
    public Collection<UnidadeVO> getListaSuat() {
        if (!UtilObjeto.isReferencia(this.listaSuat)) {
            this.listaSuat = new ArrayList<>();
        }

        return this.listaSuat;
    }

    /**
     * Define o valor do atributo listaSuat.
     *
     * @param listaSuat
     *            valor a ser atribuído
     */
    public void setListaSuat(final Collection<UnidadeVO> listaSuat) {
        this.listaSuat = listaSuat;
    }

    /**
     * Retorna o valor do atributo srList.
     *
     * @return srList
     */
    public Collection<SrVO> getSrList() {
        if (!UtilObjeto.isReferencia(this.srList)) {
            this.srList = new ArrayList<>();
        }

        return this.srList;
    }

    /**
     * Define o valor do atributo srList.
     *
     * @param srList
     *            valor a ser atribuído
     */
    public void setSrList(final Collection<SrVO> srList) {
        this.srList = srList;
    }

    /**
     * Retorna o valor do atributo unidadeSelecionada.
     *
     * @return unidadeSelecionada
     */
    public Integer getUnidadeSelecionada() {
        return this.unidadeSelecionada;
    }

    /**
     * Define o valor do atributo unidadeSelecionada.
     *
     * @param unidadeSelecionada
     *            valor a ser atribuído
     */
    public void setUnidadeSelecionada(final Integer unidadeSelecionada) {
        this.unidadeSelecionada = unidadeSelecionada;
    }

    /**
     * Retorna o valor do atributo srSelecionada.
     *
     * @return srSelecionada
     */
    public Integer getSrSelecionada() {
        return this.srSelecionada;
    }

    /**
     * Define o valor do atributo srSelecionada.
     *
     * @param srSelecionada
     *            valor a ser atribuído
     */
    public void setSrSelecionada(final Integer srSelecionada) {
        this.srSelecionada = srSelecionada;
    }

    /**
     * Retorna o valor do atributo suatSelecionada.
     *
     * @return suatSelecionada
     */
    public Integer getSuatSelecionada() {
        return this.suatSelecionada;
    }

    /**
     * Define o valor do atributo suatSelecionada.
     *
     * @param suatSelecionada
     *            valor a ser atribuído
     */
    public void setSuatSelecionada(final Integer suatSelecionada) {
        this.suatSelecionada = suatSelecionada;
    }

    /**
     * Retorna o valor do atributo habilitarSuat.
     *
     * @return habilitarSuat
     */
    public boolean isHabilitarSuat() {
        return this.habilitarSuat;
    }

    /**
     * Define o valor do atributo habilitarSuat.
     *
     * @param habilitarSuat
     *            valor a ser atribuído
     */
    public void setHabilitarSuat(final boolean habilitarSuat) {
        this.habilitarSuat = habilitarSuat;
    }

    /**
     * Retorna o valor do atributo habilitarSr.
     *
     * @return habilitarSr
     */
    public boolean isHabilitarSr() {
        return this.habilitarSr;
    }

    /**
     * Define o valor do atributo habilitarSr.
     *
     * @param habilitarSr
     *            valor a ser atribuído
     */
    public void setHabilitarSr(final boolean habilitarSr) {
        this.habilitarSr = habilitarSr;
    }

    /**
     * Retorna o valor do atributo habilitarUnidade.
     *
     * @return habilitarUnidade
     */
    public boolean isHabilitarUnidade() {
        return this.habilitarUnidade;
    }

    /**
     * Define o valor do atributo habilitarUnidade.
     *
     * @param habilitarUnidade
     *            valor a ser atribuído
     */
    public void setHabilitarUnidade(final boolean habilitarUnidade) {
        this.habilitarUnidade = habilitarUnidade;
    }

    /**
     * Retorna o valor do atributo filtro.
     *
     * @return filtro
     */
    public FiltroAnaliseCarteiraVO getFiltro() {
        if (!UtilObjeto.isReferencia(this.filtro)) {
            this.filtro = new FiltroAnaliseCarteiraVO();
        }

        return this.filtro;
    }

    /**
     * Define o valor do atributo filtro.
     *
     * @param filtro
     *            valor a ser atribuído
     */
    public void setFiltro(final FiltroAnaliseCarteiraVO filtro) {
        this.filtro = filtro;
    }

    /**
     * Retorna o valor do atributo listaGrupoGarantia.
     *
     * @return listaGrupoGarantia
     */
    public Collection<GrupoGarantia> getListaGrupoGarantia() {
        if (!UtilObjeto.isReferencia(this.listaGrupoGarantia)) {
            this.listaGrupoGarantia = new ArrayList<>();
        }

        return this.listaGrupoGarantia;
    }

    /**
     * Define o valor do atributo listaGrupoGarantia.
     *
     * @param listaGrupoGarantia
     *            valor a ser atribuído
     */
    public void setListaGrupoGarantia(final Collection<GrupoGarantia> listaGrupoGarantia) {
        this.listaGrupoGarantia = listaGrupoGarantia;
    }

    /**
     * Retorna o valor do atributo envioAutomatico.
     *
     * @return envioAutomatico
     */
    public boolean isEnvioAutomatico() {
        return this.envioAutomatico;
    }

    /**
     * Define o valor do atributo envioAutomatico.
     *
     * @param envioAutomatico
     *            valor a ser atribuído
     */
    public void setEnvioAutomatico(final boolean envioAutomatico) {
        this.envioAutomatico = envioAutomatico;
    }

    /**
     * Retorna o valor do atributo expressao.
     *
     * @return expressao
     */
    public String getExpressao() {
        return this.expressao;
    }

    /**
     * Define o valor do atributo expressao.
     *
     * @param expressao
     *            valor a ser atribuído
     */
    public void setExpressao(final String expressao) {
        this.expressao = expressao;
    }

    /**
     * Retorna o valor do atributo listaContratoInsuficiente.
     *
     * @return listaContratoInsuficiente
     */
    public Collection<ContratoParametrizadoVO> getListaContratoInsuficiente() {
        if (!UtilObjeto.isReferencia(this.listaContratoInsuficiente)) {
            this.listaContratoInsuficiente = new ArrayList<>();
        }

        return this.listaContratoInsuficiente;
    }

    /**
     * Define o valor do atributo listaContratoInsuficiente.
     *
     * @param listaContratoInsuficiente
     *            valor a ser atribuído
     */
    public void setListaContratoInsuficiente(final Collection<ContratoParametrizadoVO> listaContratoInsuficiente) {
        this.listaContratoInsuficiente = listaContratoInsuficiente;
    }

    /**
     * Retorna o valor do atributo listaContratoInsuficienteSelecionado.
     *
     * @return listaContratoInsuficienteSelecionado
     */
    public List<ContratoParametrizadoVO> getListaContratoInsuficienteSelecionado() {
        if (!UtilObjeto.isReferencia(this.listaContratoInsuficienteSelecionado)) {
            this.listaContratoInsuficienteSelecionado = new ArrayList<>();
        }

        return this.listaContratoInsuficienteSelecionado;
    }

    /**
     * Define o valor do atributo listaContratoInsuficienteSelecionado.
     *
     * @param listaContratoInsuficienteSelecionado
     *            valor a ser atribuído
     */
    public void setListaContratoInsuficienteSelecionado(final List<ContratoParametrizadoVO> listaContratoInsuficienteSelecionado) {
        this.listaContratoInsuficienteSelecionado = listaContratoInsuficienteSelecionado;
    }

    /**
     * Retorna o valor do atributo filtroEnvioNotificacaoVO.
     *
     * @return filtroEnvioNotificacaoVO
     */
    public FiltroEnvioNotificacaoVO getFiltroEnvioNotificacaoVO() {
        if (!UtilObjeto.isReferencia(this.filtroEnvioNotificacaoVO)) {
            this.filtroEnvioNotificacaoVO = new FiltroEnvioNotificacaoVO();
        }

        return this.filtroEnvioNotificacaoVO;
    }

    /**
     * Define o valor do atributo filtroEnvioNotificacaoVO.
     *
     * @param filtroEnvioNotificacaoVO
     *            valor a ser atribuído
     */
    public void setFiltroEnvioNotificacaoVO(final FiltroEnvioNotificacaoVO filtroEnvioNotificacaoVO) {
        this.filtroEnvioNotificacaoVO = filtroEnvioNotificacaoVO;
    }

    /**
     * Retorna o valor do atributo listaSegmento.
     *
     * @return listaSegmento
     */
    public Collection<SegmentacaoEnum> getListaSegmento() {
        if (this.listaSegmento == null) {
            this.listaSegmento = Arrays.asList(SegmentacaoEnum.values());
        }
        return this.listaSegmento;
    }

    /**
     * Define o valor do atributo listaSegmento.
     *
     * @param listaSegmento
     *            valor a ser atribuído
     */
    public void setListaSegmento(final Collection<SegmentacaoEnum> listaSegmento) {
        this.listaSegmento = listaSegmento;
    }
    
    /**
	 * <p>Retorna o valor do atributo listaDires</p>.
	 *
	 * @return listaDires
	*/
	public List<UnidadeVO> getListaDires() {
		return this.listaDires;
	}

	/**
	 * <p>Define o valor do atributo listaDires</p>.
	 *
	 * @param listaDires valor a ser atribuído
	*/
	public void setListaDires(List<UnidadeVO> listaDires) {
		this.listaDires = listaDires;
	}
	
	/**
	 * Retorna o valor do atributo unidadeList.
	 *
	 * @return unidadeList
	 */
	public Collection<UnidadeVO> getUnidadeList() {

		return this.unidadeList;
	}

	/**
	 * Define o valor do atributo unidadeList.
	 *
	 * @param unidadeList
	 *            valor a ser atribuído
	 */
	public void setUnidadeList(final Collection<UnidadeVO> unidadeList) {

		this.unidadeList = unidadeList;
	}
	
	/**
	 * <p>Retorna o valor do atributo tipoConfig</p>.
	 *
	 * @return tipoConfig
	*/
	public Integer getTipoConfig() {
		return this.tipoConfig;
	}

	/**
	 * <p>Define o valor do atributo tipoConfig</p>.
	 *
	 * @param tipoConfig valor a ser atribuído
	*/
	public void setTipoConfig(Integer tipoConfig) {
		this.tipoConfig = tipoConfig;
	}
	
	/**
	 * Retorna o valor do atributo nuSuat.
	 *
	 * @return nuSuat
	 */
	public Integer getNuSuat() {

		return this.nuSuat;
	}

	/**
	 * Define o valor do atributo nuSuat.
	 *
	 * @param nuSuat
	 *            valor a ser atribuído
	 */
	public void setNuSuat(final Integer nuSuat) {

		this.nuSuat = nuSuat;
	}
	
	/**
	 * Retorna o valor do atributo nuSr.
	 *
	 * @return nuSr
	 */
	public Integer getNuSr() {

		return this.nuSr;
	}

	/**
	 * Define o valor do atributo nuSr.
	 *
	 * @param nuSr
	 *            valor a ser atribuído
	 */
	public void setNuSr(final Integer nuSr) {

		this.nuSr = nuSr;
	}
	
	public Integer getCodSuvSelecionado() {
		return codSuvSelecionado;
	}

	public void setCodSuvSelecionado(Integer codSuvSelecionado) {
		this.codSuvSelecionado = codSuvSelecionado;
	}
}