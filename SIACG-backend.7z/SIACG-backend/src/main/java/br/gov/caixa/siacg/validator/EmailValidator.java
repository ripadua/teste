package br.gov.caixa.siacg.validator;

import javax.faces.application.FacesMessage;
import javax.faces.component.UIComponent;
import javax.faces.context.FacesContext;
import javax.faces.validator.FacesValidator;
import javax.faces.validator.ValidatorException;

/**
 * <p>
 * EmailValidator
 * </p>
 * <p>
 * Descrição: Classe EmailValidator
 * </p>
 * <br>
 * <b>Empresa:</b> Cef - Caixa Econômica Federal.
 *
 * @author GS Tecnologia
 * @version 1.0
 */
@FacesValidator(value = "emailValidator")
public class EmailValidator implements javax.faces.validator.Validator {

    /**
     * @see javax.faces.validator.Validator#validate(javax.faces.context.FacesContext,
     *      javax.faces.component.UIComponent, java.lang.Object)
     */
    @Override
    public void validate(final FacesContext context, final UIComponent component, final Object value) throws ValidatorException {
        final String email = String.valueOf(value);
        boolean valid = true;
        if (value == null || "".equals(email)) {
            valid = false;
        } else if (!email.contains("@")) {
            valid = false;
        } else if (!email.contains(".")) {
            valid = false;
        } else if (email.contains(" ")) {
            valid = false;
        }
        if (!valid && null != email && !"".equals(email)) {
            final FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_ERROR, "O email é inválido", "O email inserido é inválido");
            throw new ValidatorException(message);
        }
    }
}
