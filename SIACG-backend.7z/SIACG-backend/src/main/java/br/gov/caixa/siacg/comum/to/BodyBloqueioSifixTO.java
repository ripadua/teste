/*
 * Copyright (c) 2016 Caixa Econômica Federal. Todos os direitos
 * reservados.
 *
 * Caixa Econômica Federal - SIACG_dev
 *
 * Este software foi desenvolvido sob demanda da CAIXA e está
 * protegido por leis de direitos autorais e tratados internacionais. As
 * condições de cópia e utilização do total ou partes dependem de autorização da
 * pessoa. Cópias não são permitidas sem expressa autorização. Não pode ser
 * comercializado ou utilizado para propósitos particulares.
 *
 * Uso exclusivo da Caixa Econômica Federal. A reprodução ou distribuição não
 * autorizada deste programa ou de parte dele, resultará em punições civis e
 * criminais e os infratores incorrem em sanções previstas na legislação em
 * vigor.
 *
 * Histórico do Subversion:
 *
 * LastChangedRevision: $Revision$
 * LastChangedBy: $Author$
 * LastChangedDate: $Date$
 *
 * HeadURL: $HeadURL$
 *
 */
package br.gov.caixa.siacg.comum.to;

import java.math.BigDecimal;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

import br.gov.caixa.siacg.model.json.saldows.Garantia;
import br.gov.caixa.siacg.util.LogCEF;
import br.gov.caixa.siacg.util.NumeroUtil;

/**
 * <p>
 * BodyBloqueioDesbloqueioSifixTO.
 * </p>
 * <p>
 * Descrição: TO para representar a propriedade de retorno Negocial do sistema Sifix.
 * </p>
 * <br>
 * <b>Empresa:</b> Cef - Caixa Econômica Federal
 *
 * @author Leandro Severino
 * @version 1.0
 */
@JsonIgnoreProperties(ignoreUnknown = true)
public class BodyBloqueioSifixTO {

    /** numeroCanal. */
    @JsonProperty(value="numero_canal")
    private Integer numeroCanal;

    /** numeroUnidade. */
    @JsonProperty(value="numero_unidade")
    private Integer numeroUnidade;

    /** numeroOperacao. */
    @JsonProperty(value="numero_operacao")
    private Integer numeroOperacao;

    /** numeroConta. */
    @JsonProperty(value="numero_conta")
    private Long numeroConta;

    /** numeroProduto. */
    @JsonProperty(value="numero_produto")
    private Integer numeroProduto;

    /** indicadorResgate. */
    @JsonProperty(value="indicador_resgate")
    private String indicadorResgate;

    /** numeroNota. */
    @JsonProperty(value="numero_nota")
    private String numeroNota;

    /** numeroBloqueio. */
    @JsonProperty(value="numero_tipo_bloqueio")
    private Integer numeroTipoBloqueio;

    /** numeroBloqueio. */
    @JsonProperty(value="numero_bloqueio")
    private Integer numeroBloqueio;

    /** valorBloqueio. */
    @JsonProperty(value="valor_bloqueio")
    private BigDecimal valorBloqueio;

    /** descricaoBloqueio. */
    @JsonProperty(value="descricao_bloqueio")
    private String descricaoBloqueio;

    /**
     * Construtor.
     *
     */
    public BodyBloqueioSifixTO() {
	super();
    }
    
    public BodyBloqueioSifixTO(Garantia garantia) {
		this();
		criarObjSifix(garantia.getCodigoOperacao(), garantia.getCodigoAgencia(), garantia.getNumeroNota(),
				garantia.getCodigoContaEdigitoVerificador(), garantia.getValorBloqueio(),
				NumeroUtil.parseInt(garantia.getNumeroProdutoSifix()));
    }
    
    private void criarObjSifix(Integer operacao, Integer agencia, String numNota, Long codigoContaEdigitoVerificador, BigDecimal valorBloqueio, Integer numeroProduto) {
    	setIndicadorResgate("S");
    	setDescricaoBloqueio("Bloqueio realizado pelo sistema SIAGC");
    	setNumeroOperacao(operacao);
    	setNumeroUnidade(agencia);
    	int tamanhoNumeroNota = numNota.length();
    	if(tamanhoNumeroNota < 18) {
    		LogCEF.info("verificar se existe numero nota + modalidade/produto " + numNota);
    	}
    	setNumeroNota(numNota.substring(0, tamanhoNumeroNota - 4));
    	setNumeroBloqueio(2);
    	setNumeroConta(codigoContaEdigitoVerificador);
    	setValorBloqueio(valorBloqueio);
    	setNumeroProduto(numeroProduto);
    }

    
    public BodyBloqueioSifixTO(GarantiaAcaoPreventivaTO garantia) {
		this();
		this.criarObjSifix(garantia.getCodigoOperacao(), garantia.getCodigoAgencia(), garantia.getNumeroNota(),
				garantia.getCodigoContaEdigitoVerificador(), garantia.getValor(),
				NumeroUtil.parseInt(garantia.getNumeroProduto()));
    }

    /**
     * Retorna o valor do atributo descricaoBloqueio.
     *
     * @return descricaoBloqueio
     */
    public String getDescricaoBloqueio() {
	return descricaoBloqueio;
    }

    /**
     * Retorna o valor do atributo indicadorResgate.
     *
     * @return indicadorResgate
     */
    public String getIndicadorResgate() {
	return indicadorResgate;
    }

    /**
     * Retorna o valor do atributo numeroBloqueio.
     *
     * @return numeroBloqueio
     */
    public Integer getNumeroBloqueio() {
	return numeroBloqueio;
    }

    /**
     * Retorna o valor do atributo numeroCanal.
     *
     * @return numeroCanal
     */
    public Integer getNumeroCanal() {
	return numeroCanal;
    }

    /**
     * Retorna o valor do atributo numeroConta.
     *
     * @return numeroConta
     */
    public Long getNumeroConta() {
	return numeroConta;
    }

    /**
     * Retorna o valor do atributo numeroNota.
     *
     * @return numeroNota
     */
    public String getNumeroNota() {
	return numeroNota;
    }

    /**
     * Retorna o valor do atributo numeroOperacao.
     *
     * @return numeroOperacao
     */
    public Integer getNumeroOperacao() {
	return numeroOperacao;
    }

    /**
     * Retorna o valor do atributo numeroProduto.
     *
     * @return numeroProduto
     */
    public Integer getNumeroProduto() {
	return numeroProduto;
    }


    /**
     * Retorna o valor do atributo numeroTipoBloqueio.
     *
     * @return numeroTipoBloqueio
     */
    public Integer getNumeroTipoBloqueio() {
	return numeroTipoBloqueio;
    }

    /**
     * Retorna o valor do atributo numeroUnidade.
     *
     * @return numeroUnidade
     */
    public Integer getNumeroUnidade() {
	return numeroUnidade;
    }

    /**
     * Retorna o valor do atributo valorBloqueio.
     *
     * @return valorBloqueio
     */
    public BigDecimal getValorBloqueio() {
	return valorBloqueio;
    }

    /**
     * Define o valor do atributo descricaoBloqueio.
     *
     * @param descricaoBloqueio
     *            valor a ser atribuído
     */
    public void setDescricaoBloqueio(String descricaoBloqueio) {
	this.descricaoBloqueio = descricaoBloqueio;
    }


    /**
     * Define o valor do atributo indicadorResgate.
     *
     * @param indicadorResgate
     *            valor a ser atribuído
     */
    public void setIndicadorResgate(String indicadorResgate) {
	this.indicadorResgate = indicadorResgate;
    }

    /**
     * Define o valor do atributo numeroBloqueio.
     *
     * @param numeroBloqueio
     *            valor a ser atribuído
     */
    public void setNumeroBloqueio(Integer numeroBloqueio) {
	this.numeroBloqueio = numeroBloqueio;
    }

    /**
     * Define o valor do atributo numeroCanal.
     *
     * @param numeroCanal
     *            valor a ser atribuído
     */
    public void setNumeroCanal(Integer numeroCanal) {
	this.numeroCanal = numeroCanal;
    }

    /**
     * Define o valor do atributo numeroConta.
     *
     * @param numeroConta
     *            valor a ser atribuído
     */
    public void setNumeroConta(Long numeroConta) {
	this.numeroConta = numeroConta;
    }

    /**
     * Define o valor do atributo numeroNota.
     *
     * @param numeroNota
     *            valor a ser atribuído
     */
    public void setNumeroNota(String numeroNota) {
	this.numeroNota = numeroNota;
    }

    /**
     * Define o valor do atributo numeroOperacao.
     *
     * @param numeroOperacao
     *            valor a ser atribuído
     */
    public void setNumeroOperacao(Integer numeroOperacao) {
	this.numeroOperacao = numeroOperacao;
    }

    /**
     * Define o valor do atributo numeroProduto.
     *
     * @param numeroProduto
     *            valor a ser atribuído
     */
    public void setNumeroProduto(Integer numeroProduto) {
	this.numeroProduto = numeroProduto;
    }

    /**
     * Define o valor do atributo numeroTipoBloqueio.
     *
     * @param numeroTipoBloqueio
     *            valor a ser atribuído
     */
    public void setNumeroTipoBloqueio(Integer numeroTipoBloqueio) {
	this.numeroTipoBloqueio = numeroTipoBloqueio;
    }

    /**
     * Define o valor do atributo numeroUnidade.
     *
     * @param numeroUnidade
     *            valor a ser atribuído
     */
    public void setNumeroUnidade(Integer numeroUnidade) {
	this.numeroUnidade = numeroUnidade;
    }

    /**
     * Define o valor do atributo valorBloqueio.
     *
     * @param valorBloqueio
     *            valor a ser atribuído
     */
    public void setValorBloqueio(BigDecimal valorBloqueio) {
	this.valorBloqueio = valorBloqueio;
    }

    @Override
    public String toString() {
	return "BodyBloqueioDesbloqueioSifixTO [numeroCanal=" + numeroCanal + ", numeroUnidade=" + numeroUnidade
		+ ", numeroOperacao=" + numeroOperacao + ", numeroConta=" + numeroConta + ", numeroProduto="
		+ numeroProduto + ", indicadorResgate=" + indicadorResgate + ", numeroNota=" + numeroNota
		+ ", numeroTipoBloqueio=" + numeroTipoBloqueio + ", numeroBloqueio=" + numeroBloqueio
		+ ", valorBloqueio=" + valorBloqueio + ", descricaoBloqueio=" + descricaoBloqueio + "]";
    }
}
