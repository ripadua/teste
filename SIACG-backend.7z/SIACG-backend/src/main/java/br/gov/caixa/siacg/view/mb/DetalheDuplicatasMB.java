/**
 * reservados. Copyright (c) 2009-2011 Caixa Econômica Federal. Todos os direitos
 *
 * Caixa Econômica Federal - SIACG – Sistema de Acompanhamento de Carteiras de Cobrança
 *
 * Este programa de computador foi desenvolvido sob demanda da CAIXA e está protegido por leis de direitos autorais e
 * tratados internacionais. As condições de cópia e utilização do todo ou partes dependem de autorização da pessoa.
 * Cópias não são permitidas sem expressa autorização. Não pode ser comercializado ou utilizado para propósitos
 * particulares.
 *
 * Uso exclusivo da Caixa Econômica Federal. A reprodução ou distribuição não autorizada deste programa ou de parte
 * dele, resultará em punições civis e criminais e os infratores incorrem em sanções previstas na legislação em vigor.
 *
 * Histórico do Subversion:
 *
 * LastChangedRevision: LastChangedBy: LastChangedDate:
 *
 * HeadURL:
 *
 */
package br.gov.caixa.siacg.view.mb;

import java.util.Collection;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.logging.Logger;

import javax.ejb.EJB;
import javax.enterprise.context.SessionScoped;
import javax.faces.context.FacesContext;
import javax.inject.Named;

import br.gov.caixa.pedesgo.arquitetura.controlador.ManutencaoBean;
import br.gov.caixa.pedesgo.arquitetura.enums.EnumExtensaoArquivo;
import br.gov.caixa.pedesgo.arquitetura.relatorio.UtilRelatorio;
import br.gov.caixa.pedesgo.arquitetura.util.UsuarioUtil;
import br.gov.caixa.siacg.model.domain.Titulo;
import br.gov.caixa.siacg.model.vo.PessoaVO;
import br.gov.caixa.siacg.service.RelatorioAnaliseService;
import br.gov.caixa.siacg.service.TituloService;
import br.gov.caixa.siacg.util.LogCEF;
import br.gov.caixa.siacg.view.form.DetalheDuplicatasVisao;

/**
 * <p>
 * RelatorioAnaliseMB.
 * </p>
 * <p>
 * Descrição: Managed bean de detalhamento de duplicatas
 * </p>
 * <br>
 * <b>Empresa:</b> Cef - Caixa Econômica Federal
 *
 * @author ricardocrispim@gsgroup.com.br
 * @version 1.0
 */
@Named
@SessionScoped
public class DetalheDuplicatasMB extends ManutencaoBean<Titulo> {

    /** Atributo serialVersionUID. */
    private static final long serialVersionUID = 509553705294132803L;

    /** Atributo LOG. */
    private static final Logger LOG = Logger.getLogger(DetalheDuplicatasMB.class.getName());

    /** Atributo NOME_MANAGED_BEAN. */
    public static final String NOME_MANAGED_BEAN = "detalheDuplicatasMB";

    /** Atributo EL_MANAGED_BEAN. */
    public static final String EL_MANAGED_BEAN = "#{detalheDuplicatasMB}";

    /** Atributo PAGINA_DETALHE_DUPLICATAS. */
    private static final String PAGINA_DETALHE_DUPLICATAS = "/pages/analise/detalheDuplicatas.xhtml?faces-redirect=true";

    /** Atributo PAGINA_DETALHE_DUPLICATAS_PRE_ANALISE. */
    private static final String PAGINA_DETALHE_DUPLICATAS_PRE_ANALISE = "/pages/preanalise/detalheDuplicatas.xhtml?faces-redirect=true";

    /** Atributo NOME_RELATORIO_DUPLICATAS_CARTEIRA. */
    private static final String NOME_RELATORIO_DUPLICATAS_CARTEIRA = "relatorio_duplicatas_carteira";
    
    private static final String NOME_RELATORIO_TITULO_HABITACIONAL = "relatorio_titulo_habitacional";

    /** Atributo CAMINHO_RELATORIO_DUPLICATAS_PDF. */
    private static final String CAMINHO_RELATORIO_DUPLICATAS_PDF = "/reports/duplicatas_pdf.jasper";

    /** Atributo CAMINHO_RELATORIO_DUPLICATAS_XLS. */
    private static final String CAMINHO_RELATORIO_DUPLICATAS_XLS = "/reports/duplicatas_xls.jasper";
    
    private static final String CAMINHO_RELATORIO_TITULO_HABITACIONAL_XLS = "/reports/duplicatas_habitacional_xls.jasper";
    
    /** Atributo service. */
    @EJB
    private transient RelatorioAnaliseService service;

    /** Atributo tituloService. */
    @EJB
    private TituloService tituloService;

    /** Atributo visao. */
    private DetalheDuplicatasVisao visao = new DetalheDuplicatasVisao();

    /** Atributo pessoaVO. */
    private transient PessoaVO pessoaVO;
    
    /**
     * <p>
     * Abre a tela pra detalhar as duplicatas.
     * <p>
     *
     * @return String
     * @author Caio Graco
     */
    public String abrirDetalheDuplicatas() {
        this.carregarDuplicatas();

        String retorno = "";

        if (this.getVisao().getPaginaOrigem().equals(RelatorioAnaliseMB.PAGINA_RELATORIO_ANALISE)) {
            retorno = DetalheDuplicatasMB.PAGINA_DETALHE_DUPLICATAS;
        } else if (this.getVisao().getPaginaOrigem().equals(RelatorioPreAnaliseMB.PAGINA_RELATORIO_PRE_ANALISE)) {
            retorno = DetalheDuplicatasMB.PAGINA_DETALHE_DUPLICATAS_PRE_ANALISE;
        }

        return retorno;
    }

    /**
     * Carrega as duplicatas.
     *
     * @author Ricardo Crispim
     */
    public void carregarDuplicatas() {
    	getVisao().setLista(getTituloService().listarDuplicatasCedentes(getVisao().getCedentesSelecionados(), getVisao().getPrazoMaximo(), getVisao().getValorMaximo(),
    			getVisao().getConcentracaoMaximaValor(), getVisao().isMostrarDuplicatasValidas(), getVisao().getValorEsperado(), getVisao().getIcInstrucaoProtesto(),
    			getVisao().getNuContrato()));
    }

    /**
     * <p>
     * Método responsável por atulizar a grid de duplicatas com os itens fora do
     * parâmetro.
     * <p>
     *
     * @author Waltenes Junior
     */
    public void atualizarGridDuplicata() {
        final Collection<Titulo> duplicatas = getTituloService().listarDuplicatasCedentes(getVisao().getCedentesSelecionados(), getVisao().getPrazoMaximo(),
        		getVisao().getValorMaximo(), getVisao().getConcentracaoMaximaValor(), getVisao().isMostrarDuplicatasValidas(), getVisao().getValorEsperado(),
        		getVisao().getIcInstrucaoProtesto(), getVisao().getNuContrato());

        getVisao().setLista(this.getTituloService().atualizarGridDuplicatas(duplicatas, getVisao().getDuplicataInadimplenteVO()));
    }


    /**
     * <p>
     * Método responsável por filtrar a grid de títulos habitacionais.
     * <p>
     *
     * @author Ludemeula Fernandes
     *
     * @param lista a ser filtrada
     */
    public void filtrarGridHabitacional() {
        getVisao().setLista(this.getTituloService().atualizarGridDuplicatas(getTituloService().habitacionais(getVisao().getNuEmpreendimento()), getVisao().getDuplicataInadimplenteVO()));
    }

    
    /**
     * <p>
     * Método responsável por gerar relatorio no formato pdf.
     * <p>
     *
     * @author Waltenes Junior
     */
    public void gerarPdfDuplicatasEmCarteira() {
        final DetalheDuplicatasVisao visao = this.getVisao();
        visao.setTipoArquivo(EnumExtensaoArquivo.PDF);
        visao.setColecaoRelatorio(visao.getLista());
        visao.setNomeRelatorio(DetalheDuplicatasMB.NOME_RELATORIO_DUPLICATAS_CARTEIRA);
        visao.setCaminhoRelatorio(DetalheDuplicatasMB.CAMINHO_RELATORIO_DUPLICATAS_PDF);
        visao.setMapaParametros(this.montarMapaParametros());
        this.geraRelatorio();
    }

    /**
     * <p>
     * Método responsável por gerar relatorios de duplicatas em carteira.
     * <p>
     *
     * @author Waltenes Junior
     */
    public void geraRelatorio() {
        try {
            UtilRelatorio.getInstancia().addCaminhoRelatorio(getVisao().getCaminhoRelatorio()).addColecao(getVisao().getColecaoRelatorio())
                    .addResposta(this.getResponse()).addParametros(getVisao().getMapaParametros()).addNomeRelatorio(getVisao().getNomeRelatorio())
                    .addExtensaoArquivo(getVisao().getTipoArquivo()).gerarRelatorio();
        } catch (final Exception e) {
            DetalheDuplicatasMB.LOG.fine(e.getMessage());
            LogCEF.error(e);
        }
    }

    /**
     * <p>
     * Método responsável por gerar relatorio no formato xls.
     * <p>
     *
     * @author Waltenes Junior
     */
    public void gerarXlsDuplicatasEmCarteira() {
        getVisao().setTipoArquivo(EnumExtensaoArquivo.XLS);
        getVisao().setColecaoRelatorio(visao.getLista());
        getVisao().setNomeRelatorio(DetalheDuplicatasMB.NOME_RELATORIO_DUPLICATAS_CARTEIRA);
        getVisao().setCaminhoRelatorio(DetalheDuplicatasMB.CAMINHO_RELATORIO_DUPLICATAS_XLS);
        getVisao().setMapaParametros(this.montarMapaParametros());
        this.geraRelatorio();
    }
    
    /**
     * <p>
     * Método responsável por gerar relatorio no formato xls.
     * <p>
     *
     * @author Ludemeula Fernandes
     */
    public void gerarXlsHabitacional() {
        getVisao().setTipoArquivo(EnumExtensaoArquivo.XLS);
        getVisao().setColecaoRelatorio(visao.getLista());
        getVisao().setNomeRelatorio(DetalheDuplicatasMB.NOME_RELATORIO_TITULO_HABITACIONAL);
        getVisao().setCaminhoRelatorio(DetalheDuplicatasMB.CAMINHO_RELATORIO_TITULO_HABITACIONAL_XLS);
        getVisao().setMapaParametros(this.montarMapaParametros());
        this.geraRelatorio();
    }

    /**
     * <p>
     * Método responsável por montar o mapa de parametros passado para o
     * relatorio de duplicatas.
     * <p>
     *
     * @return Map<String, Object>
     * @author Waltenes Junior
     */
    private Map<String, Object> montarMapaParametros() {
        final Map<String, Object> parametros = new LinkedHashMap<>();
        parametros.put("LOGO_CAIXA", FacesContext.getCurrentInstance().getExternalContext().getResourceAsStream("/resources/img/caixa_logo.jpg"));
        parametros.put("MATRICULA_USUARIO", UsuarioUtil.getUsuarioLogado().getDeMatricula());

        parametros.put("pessoa", this.getVisao().getPessoaVO().getPessoa());
        parametros.put("contrato", this.getVisao().getPessoaVO().getContrato());
        parametros.put("valor", this.getVisao().getPessoaVO().getVrContrato());
        parametros.put("devedor", this.getVisao().getPessoaVO().getSaldoDevedor());

        return parametros;
    }

    /**
     * <p>
     * Retorna para a página do relatório.
     * <p>
     *
     * @return String
     * @author Caio Graco
     */
    public String voltarRelatorio() {
        return this.getVisao().getPaginaOrigem();
    }

    /**
     * @see br.gov.caixa.pedesgo.arquitetura.controlador.AbstractBean#getPrefixoCasoDeUso()
     */
    @Override
    protected String getPrefixoCasoDeUso() {
        return null;
    }

    /**
     * @see br.gov.caixa.pedesgo.arquitetura.controlador.AbstractBean#getService()
     */
    @SuppressWarnings("unchecked")
    @Override
    public RelatorioAnaliseService getService() {
        return this.service;
    }

    /**
     * @see br.gov.caixa.pedesgo.arquitetura.controlador.AbstractBean#getVisao()
     */
    @Override
    public DetalheDuplicatasVisao getVisao() {
        return this.visao;
    }

    /**
     * <p>
     * Método responsável por atribuir a visao.
     * <p>
     *
     * @param visao
     *            valor a ser atribuído
     */
    public void setVisao(final DetalheDuplicatasVisao visao) {
        this.visao = visao;
    }

    /**
     * Retorna o valor do atributo tituloService.
     *
     * @return tituloService
     */
    public TituloService getTituloService() {

        return this.tituloService;

    }

    /**
     * Define o valor do atributo tituloService.
     *
     * @param tituloService
     *            valor a ser atribuído
     */
    public void setTituloService(final TituloService tituloService) {

        this.tituloService = tituloService;

    }

    /**
     * Retorna o valor do atributo pessoaVO.
     *
     * @return pessoaVO
     */
    public PessoaVO getPessoaVO() {

        return this.pessoaVO;
    }

    /**
     * Define o valor do atributo pessoaVO.
     *
     * @param pessoaVO
     *            valor a ser atribuído
     */
    public void setPessoaVO(final PessoaVO pessoaVO) {

        this.pessoaVO = pessoaVO;
    }
    
    /**
     * <p>
     * Método responsável por atualizar a grid de duplicatas com os itens validos e sem vinculo com contrato
     * <p>
     *
     * @author narcieliton.lopes
	 * @dataCriacao: 2019-10-10 yyyy-MM-dd
     */
    public void abrirDetalheDuplicatasHipersuficiente() {
            final DetalheDuplicatasVisao visao = this.getVisao();
            visao.setLista(null);
            visao.setLista(this.tituloService.listarDuplicatasCedentesHipersuficiencia(visao.getCedentesSelecionados()));
     }
}
