/**
 * Copyright (c) 2018 Caixa Econômica Federal. Todos os direitos
 * reservados.
 *
 * Caixa Econômica Federal - SIACG
 *
 * Este software foi desenvolvido sob demanda da CAIXA e está
 * protegido por leis de direitos autorais e tratados internacionais. As
 * condições de cópia e utilização total ou partes dependem de autorização da
 * empresa. Cópias não são permitidas sem expressa autorização. Não pode ser
 * comercializado ou utilizado para propósitos particulares.
 *
 * Uso exclusivo da Caixa Econômica Federal. A reprodução ou distribuição não
 * autorizada deste programa ou de parte dele, resultará em punições civis e
 * criminais e os infratores incorrem em sanções previstas na legislação em
 * vigor.
 *
 * Histórico do TFS:
 *
 * LastChangedRevision: $Revision$
 * LastChangedBy: $Author$
 * LastChangedDate: $Date$
 *
 * HeadURL: $HeadURL$
 *
 */	
package br.gov.caixa.siacg.strategy.impl.titulo;

import java.math.BigDecimal;

import br.gov.caixa.siacg.model.domain.Titulo;

/**
 * <p>ConjuntoTituloLiquidado</p>
 *
 * <p>Descrição: Classe que representa um conjunto de titulos liquidados</p>
 *
 * <br><b>Empresa:</b> Cef - Caixa Econômica Federal
 *
 *
 * @author p541915
 *
 * @version 1.0
*/
public class ConjuntoTituloLiquidado extends ConjuntoTitulo {

	/** Atributo vrPagoCompensacao. */
	private BigDecimal vrPagoCompensacao = BigDecimal.ZERO;
	
	/** Atributo vrPagoCaixa. */
	private BigDecimal vrPagoCaixa = BigDecimal.ZERO;
	
	/** Atributo vrDataLiquidacaoOntem. */
	private BigDecimal vrDataLiquidacaoOntem = BigDecimal.ZERO;
	
	/** Atributo qtdPagoCaixa. */
	private Integer qtdPagoCaixa = 0;
	
	/** Atributo qtdPagoCompensacao. */
	private Integer qtdPagoCompensacao = 0;
	
	/** Atributo CANAL_RECEBEDOR_COMPENSACAO. */
    private static final String CANAL_RECEBEDOR_COMPENSACAO = "8575";
    
	/**
	 * <p>Retorna o valor do atributo vrPagoCompensacao</p>.
	 *
	 * @return vrPagoCompensacao
	*/
	public BigDecimal getVrPagoCompensacao() {
		return this.vrPagoCompensacao;
	}

	/**
	 * <p>Retorna o valor do atributo vrPagoCaixa</p>.
	 *
	 * @return vrPagoCaixa
	*/
	public BigDecimal getVrPagoCaixa() {
		return this.vrPagoCaixa;
	}

	/**
	 * <p>Retorna o valor do atributo vrDataLiquidacaoOntem</p>.
	 *
	 * @return vrDataLiquidacaoOntem
	*/
	public BigDecimal getVrDataLiquidacaoOntem() {
		return this.vrDataLiquidacaoOntem;
	}
	
	/**
	 * <p>Retorna o valor do atributo qtdPagoCaixa</p>.
	 *
	 * @return qtdPagoCaixa
	*/
	public Integer getQtdPagoCaixa() {
		return this.qtdPagoCaixa;
	}
	
	/**
	 * <p>Retorna o valor do atributo qtdPagoCompensacao</p>.
	 *
	 * @return qtdPagoCompensacao
	*/
	public Integer getQtdPagoCompensacao() {
		return this.qtdPagoCompensacao;
	}
	
	/**
	 * @see br.gov.caixa.siacg.strategy.impl.titulo.ConjuntoTitulo#adicionarTitulo(br.gov.caixa.siacg.model.domain.Titulo)
	*/
	@Override
	public void adicionarTitulo(Titulo titulo) {
		super.adicionarTitulo(titulo);
		
		if (CANAL_RECEBEDOR_COMPENSACAO.equals(titulo.getNuCanalRecebedor())) {
            this.vrPagoCompensacao = this.vrPagoCompensacao.add(titulo.getVrTitulo());
            this.qtdPagoCompensacao++;
        } else {
            this.vrPagoCaixa = this.vrPagoCaixa.add(titulo.getVrTitulo());
            this.qtdPagoCaixa++;
        }
	}
}
