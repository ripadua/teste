package br.gov.caixa.siacg.view.mb;

import javax.ejb.EJB;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;

import br.gov.caixa.pedesgo.arquitetura.controlador.AbstractBean;
import br.gov.caixa.pedesgo.arquitetura.controlador.ManutencaoBean;
import br.gov.caixa.pedesgo.arquitetura.util.MensagensUtil;
import br.gov.caixa.pedesgo.arquitetura.visao.ManutencaoVisao;
import br.gov.caixa.siacg.model.domain.GrupoGarantia;
import br.gov.caixa.siacg.model.vo.FiltroGrupoGarantiaVO;
import br.gov.caixa.siacg.service.GrupoGarantiaService;
import br.gov.caixa.siacg.view.form.GrupoGarantiaVisao;

/**
 * <p>
 * ConsultaInterfaceMB.
 * </p>
 * <p>
 * Descrição: Bean Gerenciável para a tela de parametros de grupo garantia
 * </p>
 * <br>
 * <b>Empresa:</b> Cef - Caixa Econômica Federal
 *
 * @author Marco Isecke
 * @version 1.0
 */
@ManagedBean
@SessionScoped
public class GrupoGarantiaMB extends ManutencaoBean<GrupoGarantia> {

	/** Atributo serialVersionUID. */
	private static final long serialVersionUID = 4617104820337665444L;

	/** Atributo DIRETORIO_PAGINAS. */
	private static final String DIRETORIO_PAGINAS = "/pages/grupoGarantia";

	/** Atributo PREFIXO_CASO_USO. */
	private static final String PREFIXO_CASO_USO = "grupoGarantia";

	/** Atributo visao. */
	private GrupoGarantiaVisao visao;

	/** Atributo servico. */
	@EJB
	private GrupoGarantiaService servico;

	/**
	 *
	 * @see br.gov.caixa.pedesgo.arquitetura.controlador.AbstractBean#carregar()
	 */
	@Override
	public void carregar() {
		if (this.visao == null) {
			this.visao = new GrupoGarantiaVisao();
		}
		this.visao.setLista(servico.consultaGrupos(new FiltroGrupoGarantiaVO()));
		limpaFiltros();
	}

	public void salvarGrupos() {
		servico.salvarTodos(visao.getLista());
		MensagensUtil.adicionaMensagemDeSucesso("msgApp", "Alterações salvas com sucesso!");
	}

	/**
	 * 
	 */
	public void executarConsulta() {
		getVisao().setLista(servico.consultaGrupos(this.visao.getFiltro()));
	}

	public void limpaFiltros() {
		this.visao.setFiltro(new FiltroGrupoGarantiaVO());
		this.visao.setLista(servico.consultaGrupos(new FiltroGrupoGarantiaVO()));
	}

	@Override
	protected String getPrefixoCasoDeUso() {
		return GrupoGarantiaMB.PREFIXO_CASO_USO;
	}

	@Override
	public String getTelaConsulta() {
		return GrupoGarantiaMB.DIRETORIO_PAGINAS + this.getPrefixoCasoDeUso() + AbstractBean.SUFIXO_TELA_CONSULTA;
	}

	@SuppressWarnings("unchecked")
	@Override
	public GrupoGarantiaService getService() {
		return this.servico;
	}

	@Override
	public ManutencaoVisao<GrupoGarantia> getVisao() {
		if (this.visao == null) {
			this.visao = new GrupoGarantiaVisao();
		}
		return this.visao;
	}
}