/**
 * reservados. Copyright (c) 2009-2011 Caixa Econômica Federal. Todos os direitos
 *
 * Caixa Econômica Federal - SIACG – Sistema de Acompanhamento de Carteiras de Cobrança
 *
 * Este programa de computador foi desenvolvido sob demanda da CAIXA e está protegido por leis de direitos autorais e
 * tratados internacionais. As condições de cópia e utilização do todo ou partes dependem de autorização da pessoa.
 * Cópias não são permitidas sem expressa autorização. Não pode ser comercializado ou utilizado para propósitos
 * particulares.
 *
 * Uso exclusivo da Caixa Econômica Federal. A reprodução ou distribuição não autorizada deste programa ou de parte
 * dele, resultará em punições civis e criminais e os infratores incorrem em sanções previstas na legislação em vigor.
 *
 * Histórico do Subversion:
 *
 * LastChangedRevision: LastChangedBy: LastChangedDate:
 *
 * HeadURL:
 *
 */
package br.gov.caixa.siacg.view.mb;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Date;
import java.util.EnumSet;
import java.util.LinkedList;
import java.util.List;

import javax.ejb.EJB;
import javax.enterprise.context.SessionScoped;
import javax.faces.bean.ManagedProperty;
import javax.faces.context.FacesContext;
import javax.inject.Inject;
import javax.inject.Named;

import org.primefaces.model.DefaultTreeNode;
import org.primefaces.model.TreeNode;

import br.gov.caixa.pedesgo.arquitetura.controlador.AbstractBean;
import br.gov.caixa.pedesgo.arquitetura.controlador.ManutencaoBean;
import br.gov.caixa.pedesgo.arquitetura.enumerador.EnumAcao;
import br.gov.caixa.pedesgo.arquitetura.enumerador.EnumNomeAbrangenciaRestritaUnidade;
import br.gov.caixa.pedesgo.arquitetura.enumerador.EnumTipoAbrangencia;
import br.gov.caixa.pedesgo.arquitetura.enumerador.EnumTipoFormatacao;
import br.gov.caixa.pedesgo.arquitetura.enumerador.EnumTipoPessoa;
import br.gov.caixa.pedesgo.arquitetura.util.MensagensUtil;
import br.gov.caixa.pedesgo.arquitetura.util.UsuarioUtil;
import br.gov.caixa.pedesgo.arquitetura.util.UtilCnpj;
import br.gov.caixa.pedesgo.arquitetura.util.UtilCpf;
import br.gov.caixa.pedesgo.arquitetura.util.UtilFormatacao;
import br.gov.caixa.pedesgo.arquitetura.util.UtilObjeto;
import br.gov.caixa.pedesgo.arquitetura.util.UtilString;
import br.gov.caixa.siacg.commons.UtilPermissao;
import br.gov.caixa.siacg.exception.ParametrosInvalidosException;
import br.gov.caixa.siacg.interceptador.Auditoria;
import br.gov.caixa.siacg.interceptador.OperacaoAuditoria;
import br.gov.caixa.siacg.model.domain.BandeiraCartao;
import br.gov.caixa.siacg.model.domain.Cedente;
import br.gov.caixa.siacg.model.domain.ContaContrato;
import br.gov.caixa.siacg.model.domain.ContaCorrente;
import br.gov.caixa.siacg.model.domain.ContaCorrenteID;
import br.gov.caixa.siacg.model.domain.Contrato;
import br.gov.caixa.siacg.model.domain.DuplicataExcepcionada;
import br.gov.caixa.siacg.model.domain.Garantia;
import br.gov.caixa.siacg.model.domain.GarantiaCartaoCredito;
import br.gov.caixa.siacg.model.domain.GarantiaContrato;
import br.gov.caixa.siacg.model.domain.Pessoa;
import br.gov.caixa.siacg.model.domain.PreAnalise;
import br.gov.caixa.siacg.model.domain.UnidadeVinculadaSuat;
import br.gov.caixa.siacg.model.enums.CaracteristicaEnum;
import br.gov.caixa.siacg.model.enums.ContaCorrenteEnum;
import br.gov.caixa.siacg.model.enums.ContaEnum;
import br.gov.caixa.siacg.model.enums.FormaGarantiaEnum;
import br.gov.caixa.siacg.model.enums.GrupoGarantiaEnum;
import br.gov.caixa.siacg.model.enums.NoFuncionalidadeEnum;
import br.gov.caixa.siacg.model.enums.ParametroCalculoEnum;
import br.gov.caixa.siacg.model.enums.SituacaoPreAnaliseEnum;
import br.gov.caixa.siacg.model.enums.TipoMovimentacaoEnum;
import br.gov.caixa.siacg.model.enums.TipoOrigemContaContratoEnum;
import br.gov.caixa.siacg.model.vo.DuplicataVO;
import br.gov.caixa.siacg.model.vo.ParametrizacaoContratoVO;
import br.gov.caixa.siacg.model.vo.SrVO;
import br.gov.caixa.siacg.model.vo.UnidadeVO;
import br.gov.caixa.siacg.service.BandeiraCartaoService;
import br.gov.caixa.siacg.service.ContaContratoService;
import br.gov.caixa.siacg.service.ContratoService;
import br.gov.caixa.siacg.service.DWAnaliseContratoService;
import br.gov.caixa.siacg.service.EnvioNotificacaoService;
import br.gov.caixa.siacg.service.GarantiaContratoService;
import br.gov.caixa.siacg.service.PreAnaliseService;
import br.gov.caixa.siacg.service.PropriedadeService;
import br.gov.caixa.siacg.service.SuatService;
import br.gov.caixa.siacg.service.TrilhaHistoricoService;
import br.gov.caixa.siacg.service.UnidadeService;
import br.gov.caixa.siacg.service.UnidadeVinculadaSuatService;
import br.gov.caixa.siacg.util.LogCEF;
import br.gov.caixa.siacg.view.form.PreAnaliseVisao;

/**
 * <p>
 * AnaliseMB.
 * </p>
 * <p>
 * Descrição: Bean Gerenciado para a Entidade PreAnalise
 * </p>
 * <br>
 * <b>Empresa:</b> Cef - Caixa Econômica Federal
 *
 * @author Caio Graco
 * @version 1.0
 */
@Named
@SessionScoped
public class PreAnaliseMB extends ManutencaoBean<PreAnalise> {

    /** Atributo MENSAGE_SUCESSO. */
    private static final String MENSAGE_SUCESSO = "MA002";

    /** Atributo MSG_APP. */
    private static final String MSG_APP = "msgApp";

    /**
     * Valor criado para não impactar nos calculos da parametrização do
     * contrato.
     */
    private static final String VALOR_FORMA_GARANTIA_FICTICIO = "99999999999";

    /** Atributo MN011. */
    private static final String MN011 = "MN011";

    /** Atributo MN012. */
    private static final String MN012 = "MN012";

    /** Atributo UC_PRE_ANALISE_PESSOA_INEXISTENTE. */
    private static final String UC_PRE_ANALISE_PESSOA_INEXISTENTE = "uc_pre_analise_pessoa_inexistente";

    /** Atributo serialVersionUID. */
    private static final long serialVersionUID = 509553705294132803L;

    // Constantes
    /** Atributo CNPJ_INVALIDO. */
    private static final String CNPJ_INVALIDO = "MN024";
    private static final String CNPJ_OBRIGATORIO = "MN062";
    /** Atributo VAZIO. */
    private static final String VAZIO = "";
    /** Atributo NOME_MANAGED_BEAN. */
    public static final String NOME_MANAGED_BEAN = "preAnaliseMB";
    /** Atributo EL_MANAGED_BEAN. */
    public static final String EL_MANAGED_BEAN = "#{preAnaliseMB}";
    /** Atributo PREFIXO_CASO_DE_USO. */
    private static final String PREFIXO_CASO_DE_USO = "preanalise";
    /** Atributo DIRETORIO_PAGINAS. */
    private static final String DIRETORIO_PAGINAS = "/pages/";
    /** Atributo VAR_RESOURCE_BUNDLE. */
    private static final String VAR_RESOURCE_BUNDLE = PreAnaliseMB.MSG_APP;
    /** Atributo com o codigo da mesagem de operação realizada com sucesso. */
    public static final String OPERACAO_REALIZADA_SUCESSO = PreAnaliseMB.MENSAGE_SUCESSO;
    /** Atributo com o codigo de situação do contrato cancelado. */
    public static final String SITUACAO_CONTRATO_CANCELADO = "04";
    
    private static final String UNIDADE = "unidade";
    
    /** Atributo visao. */
    private transient PreAnaliseVisao visao;

    /** Atributo preAnaliseService. */
    @Inject
    private transient PreAnaliseService preAnaliseService;

    /** Atributo envioNotificacaoService. */
    @EJB
    private transient EnvioNotificacaoService envioNotificacaoService;

    /** Atributo permissao. */
    @Inject
    private transient UtilPermissao permissao;

    /** Atributo unidadeService. */
    @EJB
    private transient UnidadeService unidadeService;

    /** Atributo suatService. */
    @EJB
    private transient SuatService suatService;

    /** Atributo unidadeVinculadaSuatService. */
    @EJB
    private transient UnidadeVinculadaSuatService unidadeVinculadaSuatService;

    /** Atributo trilhaHistoricoService. */
    @EJB
    private TrilhaHistoricoService trilhaHistoricoService;

    /** Atributo contratoService. */
    @EJB
    private ContratoService contratoService;
	
    /** Atributo relatorioPreAnaliseMB. */
    @Inject
    private RelatorioPreAnaliseMB relatorioPreAnaliseMB;

    /** Atributo bandeiraCartaoService. */
    @Inject
    private BandeiraCartaoService bandeiraCartaoService;
    
    @Inject
    private ContaContratoService contaContratoService;
    
    @Inject
    private GarantiaContratoService garantiaContratoService;
    
    @Inject
    private PropriedadeService propriedadeService;
    
    @ManagedProperty(value = ContaCorrenteCartaoMB.EL_MANAGED_BEAN)
    private ContaCorrenteCartaoMB contaCorrenteCartaoMB;
    
    @Inject
    private DWAnaliseContratoService dwAnaliseContratoService;

    /**
     * @see br.gov.caixa.pedesgo.arquitetura.controlador.AbstractBean#carregar()
     */
    @Override
    public void carregar() {
    	this.visao = null;
    	carregarDadosVisao();
    	configurarPermissao();
    	carregarListaUnidades();
    }

    /**
     * <p>
     * Método responsável por preencher a lista de unidades de acordo com a suat
     * selecionada.
     * <p>
     *
     * @author Caio Graco
     */
    public void selecionarSuat() {
		getVisao().setNuSuat(getVisao().getSuatSelecionada());
		getVisao().setListaUnidadeFiltro(new ArrayList<Integer>());
		
		if (UtilObjeto.isReferencia(getVisao()) && getVisao().getNuSuat() != null && !getVisao().getNuSuat().equals(0)) {
			getVisao().setSrList(dwAnaliseContratoService.listarSrsPorNuSuat(getVisao().getNuSuat()));
			adicionarFiltronidadePorSr();
		} else {
			getVisao().setSrList(new LinkedList<SrVO>());
		}
		
		filtrar();
    }

    /**
     * <p>
     * Método responsável por preencher a lista de unidades de acordo com a SR
     * selecionada.
     * <p>
     *
     * @author Caio Graco
     */
    public void selecionarSr() {
    	getVisao().setNuSr(getVisao().getCodSuvSelecionado());
    	
    	getVisao().setListaUnidadeFiltro(new ArrayList<Integer>());
		
		if (UtilObjeto.isReferencia(getVisao()) && getVisao().getNuSr() != null && !getVisao().getNuSr().equals(0)) {
			getVisao().setListaUnidade(dwAnaliseContratoService.listarUnidadesPorNuSr(getVisao().getNuSr()));			
			adicionarFiltroUnidadePorUnidade();
		} else {
			getVisao().setNuSr(null);
			getVisao().setNuUnidade(null);			
			adicionarFiltronidadePorSr();
		}
		
		filtrar();
    }

	private void adicionarFiltronidadePorSr() {
		final Collection<Integer> listaNuSr = new ArrayList<>();
		for (final SrVO srVO : getVisao().getSrList()) {
		    listaNuSr.add(srVO.getNuSrVO());
		}
		
		getVisao().setListaUnidadeFiltro(unidadeVinculadaSuatService.getNuUnidadesVinculadasSR(listaNuSr));
	}
    
    /**
     * <p>
     * Método responsável por preencher a lista de unidades de acordo com a SR
     * selecionada.
     * <p>
     *
     * @author Caio Graco
     */
    public void selecionarUnidade() {
    	getVisao().setListaUnidadeFiltro(new ArrayList<Integer>());
    	
    	getVisao().setNuUnidade(getVisao().getUnidadeSelecionada());
    	
    	getVisao().getListaUnidadeFiltro().add(getVisao().getNuUnidade());
		
		if (UtilObjeto.isReferencia(getVisao()) && getVisao().getNuUnidade() != null && !getVisao().getNuUnidade().equals(0)) {
			filtrar();
		} else {
			getVisao().setNuUnidade(null);
			adicionarFiltroUnidadePorUnidade();
			filtrar();
		}
    }

	private void adicionarFiltroUnidadePorUnidade() {
		final Collection<Integer> listaNuUnidade = new ArrayList<>();
		for (final UnidadeVO unidade : getVisao().getListaUnidade()) {
		    listaNuUnidade.add(unidade.getCoUnidadeVO());
		}
		
		getVisao().setListaUnidadeFiltro(listaNuUnidade);
	}

    /**
     * <p>
     * Método responsável por carregar os dados da tela de edição.
     * <p>
     *
     * @author guilherme.santos
     */
    @Auditoria
    @OperacaoAuditoria(acao = "PARAMETRO_CONTRATO")
    public void carregarEdicao() {

	final PreAnaliseVisao visao = this.getVisao();
	final PreAnalise preAnaliseEditada = visao.getEntidade();

	this.carregarComboSituacao();
	visao.setContaCorrente(new ContaCorrente());
	visao.setListaCedentes(new ArrayList<Cedente>());
	visao.setCedenteIncluido(new Cedente());
	visao.setMensagemSalvarParametrizacao(PreAnaliseMB.VAZIO);
	visao.setExibirModalOperacaoRealizadaComSucesso(false);
	visao.setEdicao(true);
	visao.setPessoaObj(preAnaliseEditada.getContrato().getNuPessoa());
	
	ArrayList<ContaContrato> listaContaContrato = (ArrayList<ContaContrato>) contaContratoService.consultarPorContrato(visao.getContratoPreAnalise());
				
	visao.setListaContaContrato(
		(ArrayList<ContaContrato>) this.filtrarListaContaContratoParaContrato(listaContaContrato));
	visao.setListaContaContratoCartao(
		((ArrayList<ContaContrato>) this.filtrarListaContaContratoParaCartao(listaContaContrato)));

	visao.setCaracteristicaList(EnumSet.allOf(CaracteristicaEnum.class));
	visao.setUnidadeSelecionada(preAnaliseEditada.getContrato().getNuUnidade());
	visao.setNomeUnidade(preAnaliseEditada.getContrato().getUnidade().getNomeUnidade());
	visao.setListaExclusaoParametrizacao(new ArrayList<ParametrizacaoContratoVO>());

	this.carregarListaGarantias(preAnaliseEditada);
    }

    /**
     * <p>
     * Método responsável por carregar a lista de garantias.
     * <p>
     *
     * @param preAnaliseEditada
     *            valor a ser atribuído
     * @author guilherme.santos
     */
    private void carregarListaGarantias(final PreAnalise preAnaliseEditada) {
	this.visao.getParametrizacaoList().clear();
	if (preAnaliseEditada.getContrato() != null && preAnaliseEditada.getContrato().getGarantiaContratoList() != null) {
	    ArrayList<GarantiaContrato> listaGarantiaContrato = (ArrayList<GarantiaContrato>) garantiaContratoService.listarGarantiaContrato(preAnaliseEditada.getContrato());
	    for (final GarantiaContrato garantiaContrato : listaGarantiaContrato) {
		final ParametrizacaoContratoVO parametrizacaoContratoVO = new ParametrizacaoContratoVO();

		if (garantiaContrato.isGarantiaDuplicata() && garantiaContrato.getIcCaracteristica() != null
			&& garantiaContrato.getIcCaracteristica().getValor().equals(CaracteristicaEnum.FLUXO.getValor())) {
		    garantiaContrato.setVrPrazoMaximoPermitido(null);
		    garantiaContrato.setVrMaximoPermitido(null);
		    garantiaContrato.setVrPercentualMaximoCncno(null);
		}

		parametrizacaoContratoVO.setGarantiaContrato(garantiaContrato);
		parametrizacaoContratoVO.setCedenteList(new ArrayList<Cedente>(garantiaContrato.getCedenteList()));
		this.visao.getParametrizacaoList().add(parametrizacaoContratoVO);
	    }
	}
    }

    /**
     * <p>
     * Método responsável por carregar garantias.
     * <p>
     */
    private void carregarGarantias() {
	if (null != this.visao.getGarantias()) {
	    this.visao.getGarantias().clear();
	}
	this.visao.setGarantias(this.preAnaliseService.listarGarantiaDuplicataCartaoCredito());
    }

	private void carregarListaUnidades() {
		List<UnidadeVO> listaDires = new ArrayList<>();
		
		Integer tipoConfig = 1; 
		Integer unidadeGestora = null; 
		try {
			List<Integer> codigos = new ArrayList<>();
			String dados = propriedadeService.getPropriedadeBanco("unidade.lista", UNIDADE);
			tipoConfig = Integer.parseInt(propriedadeService.getPropriedadeBanco("unidade.tipoconfig", UNIDADE));
			unidadeGestora = Integer.parseInt(this.propriedadeService.getPropriedadeBanco("unidade.unidadeGestora", UNIDADE));
			String[] lista = dados.split(";");
			for (String item : lista) {
				codigos.add(Integer.parseInt(item));
			}
			listaDires = new ArrayList<>(unidadeVinculadaSuatService.listarDiresPorCodigo(codigos));
		} catch (ParametrosInvalidosException e) {
			LogCEF.error("Erro ao carregar propriedades de unidades. Detalhes: ");
			LogCEF.error(e);
		}
			
		getVisao().setListaDires(listaDires);
		getVisao().setTipoConfig(tipoConfig);
		getVisao().setUnidadeGestoraProcesso(unidadeGestora);
	}
	
	private void configurarPermissao() {
		final FacesContext contexto = FacesContext.getCurrentInstance();

		if (UtilObjeto.isReferencia(contexto)) {
			final String unidadeUsuario = super.getUnidadeUsuario();

			if (!UtilString.isVazio(unidadeUsuario)) {

				final Integer nuUnidadeusuarioLogado = Integer.valueOf(unidadeUsuario);

				if (UtilObjeto.isReferencia(nuUnidadeusuarioLogado)) {

					if (UsuarioUtil.contemPermissao(NoFuncionalidadeEnum.CONSULTA_UNIDADE.getNoFuncionalidade(), EnumAcao.CONSULTAR.getNoAcao(),
							EnumTipoAbrangencia.RESTRITA_UNIDADE.getTipoAbrangencia(),
							EnumNomeAbrangenciaRestritaUnidade.TODAS.getNomeAbrangencia())) {

						getVisao().setHabilitarSuat(Boolean.FALSE);
						getVisao().setHabilitarSr(Boolean.FALSE);
					    getVisao().setHabilitarUnidade(Boolean.FALSE);
					    
						filtrar();
					} else if (UsuarioUtil.contemPermissao(NoFuncionalidadeEnum.CONSULTA_UNIDADE.getNoFuncionalidade(),
							EnumAcao.CONSULTAR.getNoAcao(), EnumTipoAbrangencia.RESTRITA_UNIDADE.getTipoAbrangencia(),
							EnumNomeAbrangenciaRestritaUnidade.VINCULADAS.getNomeAbrangencia())) {

						getVisao().setHabilitarSuat(Boolean.TRUE);
						getVisao().setHabilitarSr(Boolean.TRUE);
						getVisao().setHabilitarUnidade(Boolean.FALSE);

						filtrar();

					} else if (UsuarioUtil.contemPermissao(NoFuncionalidadeEnum.CONSULTA_UNIDADE.getNoFuncionalidade(),
							EnumAcao.CONSULTAR.getNoAcao(), EnumTipoAbrangencia.RESTRITA_UNIDADE.getTipoAbrangencia(),
							EnumNomeAbrangenciaRestritaUnidade.UNIDADE.getNomeAbrangencia())) {

						getVisao().setHabilitarSuat(Boolean.TRUE);
						getVisao().setHabilitarSr(Boolean.TRUE);
						getVisao().setHabilitarUnidade(Boolean.TRUE);
						
						filtrar();
					}
				}
			}
		}
	}
    
    /**
     * <p>
     * Método responsável por filtrar a grid.
     * <p>
     *
     * @author Caio Graco
     */
    public void filtrar() {
    	getVisao().getLista().clear();
    
    	if (UtilObjeto.isVazio(getVisao().getListaUnidadeFiltro())) {
    		getVisao().setListaUnidadeFiltro(permissao.prepararConsultaPorTipoAbrangencia(NoFuncionalidadeEnum.ANALISE_GARANTIA.getNoFuncionalidade()));
    	}
    
    	getVisao().setLista(getService().listaFiltrada(getVisao().getEntidade(), getVisao().getPessoa(),
    			getVisao().getCpfCnpj(), getVisao().getListaUnidadeFiltro(), getVisao().getListaSegmentoSelecionados()));
    }

    /**
     * <p>
     * Método responsável por carregar os dados da visão.
     * <p>
     *
     * @author Caio Graco
     */
    private void carregarDadosVisao() {
	if (this.getContaCorrenteCartaoMB() == null) {
	    FacesContext context = FacesContext.getCurrentInstance();
	    this.setContaCorrenteCartaoMB(context.getApplication().evaluateExpressionGet(context, "#{contaCorrenteCartaoMB}", ContaCorrenteCartaoMB.class));
	}
	
	this.carregarComboSituacao();
	final PreAnaliseVisao visao = this.getVisao();
	visao.setEntidade(new PreAnalise());
	visao.getEntidade().setContrato(new Contrato());
	visao.getEntidade().getContrato().setNuPessoa(new Pessoa());
	visao.setPessoa(null);
	visao.setContaContrato(new ContaContrato());
	visao.getContaContrato().setNuConta(new ContaCorrente());
	visao.getContaContrato().getNuConta().setId(new ContaCorrenteID());
	visao.setContaCorrente(new ContaCorrente());
	visao.getContaCorrente().setId(new ContaCorrenteID());
	visao.setListaContaCorrente(new ArrayList<ContaCorrente>());
	visao.setListaContaContratoCartao(new ArrayList<ContaContrato>());
	visao.setListaContaContrato(new ArrayList<ContaContrato>());
	visao.setContaContratoCartao(new ContaContrato());
	visao.getContaContratoCartao().setNuConta(new ContaCorrente());
	visao.setCaracteristicaList(EnumSet.allOf(CaracteristicaEnum.class));
	visao.setExibirCamposEdicao(false);
	visao.setListaCedentes(new ArrayList<Cedente>());
	visao.setCedenteIncluido(new Cedente());
	visao.setMensagemSalvarParametrizacao(PreAnaliseMB.VAZIO);
	visao.setExibirModalOperacaoRealizadaComSucesso(false);
	visao.setUnidadeSelecionada(null);
	visao.setContaContratoList(new ArrayList<ContaContrato>());
	visao.setEdicao(false);
	visao.setPessoaObj(new Pessoa());
	visao.setParametrizacaoList(new ArrayList<ParametrizacaoContratoVO>());
	visao.setNuSr(null);
	visao.setNuSuat(null);
	visao.setNuUnidade(null);
	visao.setSrList(new ArrayList<SrVO>());
	this.limparDadosParametrizacao();
	this.verificarPermissao();
	this.carregarListaBandeiraCartao();
    }

    /**
     * <p>
     * Método responsável por verificar as permissões do usuário logado.
     * <p>
     *
     * @author Waltenes Junior
     */
    private void verificarPermissao() {
	final PreAnaliseVisao visao = this.getVisao();

	visao.setContemPermissaoBotaoConsultar(UsuarioUtil.contemPermissao(NoFuncionalidadeEnum.PARAMETRIZA_PRE_ANALISE.getNoFuncionalidade(),
		EnumAcao.CONSULTAR.getNoAcao(), null, null));
	visao.setContemPermissaoBotaoEditar(UsuarioUtil.contemPermissao(NoFuncionalidadeEnum.PARAMETRIZA_PRE_ANALISE.getNoFuncionalidade(),
		EnumAcao.ALTERAR.getNoAcao(), null, null));
	visao.setContemPermissaoBotaoNovo(UsuarioUtil.contemPermissao(NoFuncionalidadeEnum.PARAMETRIZA_PRE_ANALISE.getNoFuncionalidade(),
		EnumAcao.INCLUIR.getNoAcao(), null, null));
	visao.setContemPermissaoEditarParametro(UsuarioUtil.contemPermissao(
		NoFuncionalidadeEnum.PARAMETRIZA_PRE_ANALISE_GARANTIA.getNoFuncionalidade(), EnumAcao.ALTERAR.getNoAcao(), null, null));
    }

    /**
     * <p>
     * Método responsável por abrir o relatório de pré análise.
     * <p>
     *
     * @return String
     * @author Caio Graco, guilherme.santos
     */
    @Auditoria
    @OperacaoAuditoria(acao = "ABRIR_RELATORIO_PRE_ANALISE")
    public String abrirRelatorioPreAnalise() {

	this.getRelatorioPreAnaliseMB().getVisao().setPreAnaliseSelecionada(this.getVisao().getEntidade());
	this.getRelatorioPreAnaliseMB().getVisao().setAnaliseContrato(this.getVisao().getEntidade().getContrato().getNuUltimaAnaliseContrato());

	return this.getRelatorioPreAnaliseMB().getTelaConsulta();
    }

    /**
     * <p>
     * Método executado quando a combo de Caracteristica e selecionada.
     * </p>
     *
     * @since 1.2.0_r12
     * @param evento
     * @author thales.ribeiro, guilherme.santos
     */
    public void onSelectIcCaracteristica() {
	final PreAnaliseVisao visao = this.getVisao();
	visao.getGarantiaContratoEdicao().setVrGarantia(null);
	visao.getGarantiaContratoEdicao().setIcFormaGarantia1(null);
	visao.getGarantiaContratoEdicao().setVrFormaGarantia1(BigDecimal.ZERO);
	visao.getGarantiaContratoEdicao().setIcFormaGarantia2(null);
	visao.getGarantiaContratoEdicao().setVrFormaGarantia2(BigDecimal.ZERO);

	if (UtilObjeto.isReferencia(visao.getGarantiaContratoEdicao().getIcCaracteristica())
		&& (visao.getGarantiaContratoEdicao().getIcCaracteristica().equals(CaracteristicaEnum.FLUXO)
			&& visao.getGarantiaContratoEdicao().getGarantia().isGrupoGarantia(GrupoGarantiaEnum.DUPLICATA))
		|| visao.getGarantiaContratoEdicao().getGarantia().isGrupoGarantia(GrupoGarantiaEnum.CARTAO_CREDITO)) {

	    visao.setOcultarPrazoMaximo(Boolean.TRUE);
	    visao.setOcultarValorMaximo(Boolean.TRUE);
	    visao.setOcultarPercentualMaximo(Boolean.TRUE);
	    visao.setOcultarInstrucaoProtesto(Boolean.TRUE);

	} else {
	    visao.setOcultarPrazoMaximo(Boolean.FALSE);
	    visao.setOcultarValorMaximo(Boolean.FALSE);
	    visao.setOcultarPercentualMaximo(Boolean.FALSE);
	    visao.setOcultarInstrucaoProtesto(Boolean.FALSE);
	}

    }

    /**
     * <p>
     * Método responsável por carregar os dados da combo de situacao.
     * <p>
     *
     * @author Caio Graco
     */
    private void carregarComboSituacao() {
	this.getVisao().setListaSituacoes(Arrays.asList(SituacaoPreAnaliseEnum.values()));
    }

    /**
     * <p>
     * Método responsável por carregar a lista de bandeiras de cartões
     * </p>
     * .
     *
     * @author p541915
     *
     */
    private void carregarListaBandeiraCartao() {
	this.getVisao().setListaBandeiraCartao(this.getBandeiraCartaoService().listarTodasBandeirasAtivas());
    }

    /**
     *
     * <p>
     * Método responsável por retornar a descrição da situação.
     * <p>
     *
     * @param situacao
     *            valor a ser atribuído
     * @return String
     * @author Caio Graco
     */
    public String tratarSituacao(final String situacao) {
	return SituacaoPreAnaliseEnum.obterDescricaoPorCodigo(situacao);
    }

    /**
     * <p>
     * Método executado quando a garantia e selecionada.
     * </p>
     *
     * @param evento
     * @author Caio Graco
     */
    public void onSelectIcGarantia() {
	final PreAnaliseVisao visao2 = this.getVisao();

	final Garantia garantia = this.preAnaliseService.obterGarantiaPorCodigoOperacao(visao2.getIdentificadorGarantia());

	if (UtilObjeto.isReferencia(garantia)) {
	    this.buscarPessoa();

	    if (!UtilObjeto.isReferencia(visao2.getPessoaObj().getNuCnpj())) {
		this.adicionaMensagemDeAlerta(PreAnaliseMB.CNPJ_OBRIGATORIO);
		this.cancelarEdicao();

	    } else {
		// Habilitar campos para edição
		
		visao2.setExibirCamposEdicao(true);
		visao2.setEdicao(true);
		visao2.setGarantiaContratoEdicao(new GarantiaContrato());
		visao2.getGarantiaContratoEdicao().setGarantia(garantia);
		visao2.getGarantiaContratoEdicao().setNuContrato(this.visao.getContratoPreAnalise());

		// Tratar Garantia do tipo Duplicata
		this.tratarGarantiaDuplicata(garantia);
		// Tratar Garantia do tipo Cartão ou Cheque
		this.tratarGarantiaCartaoCredito(garantia);
	    }

	} else {
	    this.cancelarEdicao();
	}
    }

    /**
     * <p>
     * Método responsável por tratar os campos de Garantia Cartão.
     * <p>
     *
     * @param garantia
     *            valor a ser atribuído
     * @author guilherme.santos
     */
    private void tratarGarantiaCartaoCredito(final Garantia garantia) {
	if (garantia.isGrupoGarantia(GrupoGarantiaEnum.CARTAO_CREDITO)) {
	    this.ocultarCamposCartaoCredito();
	    this.getVisao().setExibirCartaoCredito(true);

	    if (UtilObjeto.isVazio(this.getVisao().getListaContaContratoCartao())) {

		this.getVisao().getListaContaContratoCartao().addAll(UtilObjeto
			.clone(this.preAnaliseService.listarContaContratoCartaoCredito(this.getVisao().getContratoPreAnalise().getNuContrato())));

	    }

	    // Pré-analise não tem condições para habilitar Cartão de credito V2
	    this.montarArvoreCartaoCredito();

	} else {

	    this.getVisao().setExibirCartaoCredito(false);
	}
    }

    /**
     * <p>
     * Método responsável por tratar os campos da Garantia Cheque e Cartão.
     * <p>
     *
     * @author guilherme.santos
     */
    public void ocultarCamposCartaoCredito() {
	this.getVisao().setOcultarInstrucaoProtesto(true);
	this.getVisao().setOcultarTipoGarantia(false);
	this.getVisao().setOcultarPercentualMaximo(true);
	this.getVisao().setOcultarPrazoMaximo(true);
	this.getVisao().setOcultarValor(true);
	this.getVisao().setOcultarValorMaximo(true);
	this.getVisao().setExibirAplicacaoFinanceira(false);
    }

    /**
     * <p>
     * Método responsável por montar a Arvore de Cartao de Credito.
     * <p>
     *
     * @author guilherme.santos
     */
    public void montarArvoreCartaoCredito() {
	final PreAnaliseVisao visao = this.getVisao();

	if (!UtilObjeto.isVazio(visao.getListaContaContratoCartao())) {
	    final TreeNode treeCartoes = new DefaultTreeNode(new ContaContrato(), null);
	    TreeNode conta = null;

	    for (final ContaContrato contaContrato : visao.getListaContaContratoCartao()) {

		conta = new DefaultTreeNode(contaContrato, treeCartoes);

		conta.setExpanded(true);
		conta.setSelectable(false);

		List<TreeNode> listaGarantiaCartaoNode = new ArrayList<>();

		for (BandeiraCartao bandeiraCartao : visao.getListaBandeiraCartao()) {
		    // Percorre a lista de bandeiras de cartão e adiciona na
		    // arvore
		    final GarantiaCartaoCredito garantiaCartao = this.consultarGarantiaCartaoCredito(contaContrato.getNuConta(),
			    this.visao.getGarantiaContratoEdicao().getNuGarantia(), bandeiraCartao);

		    if (bandeiraCartao.getIcTipoMovimentacao().equals(TipoMovimentacaoEnum.CREDITO.getValor())) {
		    	final TreeNode garantiaCartaoNode = new DefaultTreeNode(garantiaCartao, conta);
		    	garantiaCartaoNode.setExpanded(true);
		    	listaGarantiaCartaoNode.add(garantiaCartaoNode);		    	
		    }
		    
		}

		this.verificarMarcacaoArvoreCartao(visao, listaGarantiaCartaoNode);

	    }
	    visao.setContaCorrenteCartaoCredito(treeCartoes);
	}else {
	    visao.getContaCorrenteCartaoCredito().getChildren().clear();
	}
    }
    
    public boolean isMostrarContasBandeirasCartaoCredito() {
	return this.getVisao().isExibirCartaoCredito() && this.getVisao().isExibirCamposEdicao();
    }
    
    public boolean isMostrarContasBandeirasCartaoCreditoV1() {
	//Foi definido que no momento a Pre analise possui implementação válida somente para Cartao de Credito V1
	return Boolean.TRUE;
    }
    
    public boolean isMostrarContasBandeirasCartaoCreditoV2() {
	//Foi definido que no momento a Pre analise possui implementação válida somente para Cartao de Credito V1
	return Boolean.FALSE;
    }    

    /**
     * Método responsável por.
     *
     * @author Leandro Santos Oliveira
     *
     * @param visao
     *            valor a ser atribuído
     * @param garantiaCartaoCreditoVisa
     *            valor a ser atribuído
     * @param garantiaCartaoVisa
     *            valor a ser atribuído
     * @param garantiaCartaoCreditoMaster
     *            valor a ser atribuído
     * @param garantiaCartaoMaster
     *            valor a ser atribuído
     */
    private void verificarMarcacaoArvoreCartao(final PreAnaliseVisao visao, List<TreeNode> listaGarantiaCartaoNode) {
	if (UtilObjeto.isReferencia(visao.getCartoesSelecionados())) {

	    GarantiaCartaoCredito garantiaCartaoDaLista;
	    GarantiaCartaoCredito garantiaCartaoSelecionado;

	    for (final TreeNode treeNode : visao.getCartoesSelecionados()) {
		garantiaCartaoSelecionado = (GarantiaCartaoCredito) treeNode.getData();

		for (TreeNode garantiaCartaoNode : listaGarantiaCartaoNode) {
		    garantiaCartaoDaLista = (GarantiaCartaoCredito) garantiaCartaoNode.getData();

		    if (garantiaCartaoDaLista.getNuGarantiaCartaoCredito() != null && garantiaCartaoDaLista.getNuGarantiaCartaoCredito().equals(garantiaCartaoSelecionado.getNuGarantiaCartaoCredito())) {
			garantiaCartaoNode.setSelected(true);
			break;
		    }
		}
	    }
	}
    }

    /**
     * <p>
     * Método responsável por consultar GarantiaCartaoCredito.
     * <p>
     *
     * @param conta
     *            valor a ser atribuído
     * @param idGarantiaContrato
     *            valor a ser atribuído
     * @param bandeira
     *            valor a ser atribuído
     * @return GarantiaCartaoCredito
     * @author guilherme.santos
     */
    private GarantiaCartaoCredito consultarGarantiaCartaoCredito(final ContaCorrente conta, final Integer idGarantiaContrato,
	    final BandeiraCartao bandeiraCartao) {
	GarantiaCartaoCredito retorno = null;

	if (idGarantiaContrato != null) {
	    retorno = this.preAnaliseService.obterGarantiaCartaoCredito(conta, idGarantiaContrato, bandeiraCartao);
	}
	if (idGarantiaContrato == null || retorno == null || retorno.getNuGarantiaCartaoCredito() == null) {
	    retorno = new GarantiaCartaoCredito();
	    retorno.setBandeiraCartao(bandeiraCartao);
	    retorno.setNuConta(conta);
	}

	return retorno;
    }

    /**
     * <p>
     * Método responsável por adicionar a conta corrente a arvore de cartão de
     * crédito.
     * <p>
     *
     * @author guilherme.santos
     */
    public void adicionarContaCorrenteCartaoCredito() {
	final PreAnaliseVisao visao = this.getVisao();
	
	if (this.preAnaliseService.validarContaCorrente(visao.getContaContratoCartao().getNuConta())) {
	    if (this.verificarSeListaContemContaCorrente(visao.getListaContaContratoCartao(), visao.getContaContratoCartao())) {
		super.adicionaMensagemDeAlerta(PreAnaliseMB.MN012);
		
	    } else if (this.preAnaliseService.obterContaContratoPorContratoEContaCorrente(visao.getContaContratoCartao().getNuConta(),
		    this.recuperarContrato()) != null) {
		visao.getContaContratoCartao().getNuConta().setFormaInsercao(ContaCorrenteEnum.INSERIDO);
		visao.getContaContratoCartao().setIcOrigem(TipoOrigemContaContratoEnum.CARTAO_CREDITO);
		visao.getListaContaContratoCartao().add(visao.getContaContratoCartao());
		this.montarArvoreCartaoCredito();
		visao.setContaContratoCartao(new ContaContrato());
		visao.getContaContratoCartao().setNuConta(new ContaCorrente());

	    } else {
		visao.getContaContratoCartao().setIcUtilizarSaldo(false);
		visao.getContaContratoCartao().setIcUtilizarSaldoCheque(false);
		visao.getContaContratoCartao().setIcOrigem(TipoOrigemContaContratoEnum.CARTAO_CREDITO);
		visao.getContaContratoCartao().setIcConta(ContaEnum.NORMAL);
		visao.getContaContratoCartao().setNuContrato(this.recuperarContrato());
		if (visao.getContaContratoCartao().getNuConta() != null) {
		    visao.getContaContratoCartao().getNuConta().setFormaInsercao(ContaCorrenteEnum.INSERIDO);
		}
		visao.getListaContaContratoCartao().add(visao.getContaContratoCartao());

		this.montarArvoreCartaoCredito();

		visao.setContaContratoCartao(new ContaContrato());
		visao.getContaContratoCartao().setNuConta(new ContaCorrente());
	    }
	    
	} else {
	    super.adicionaMensagemInformativa(PreAnaliseMB.MN011);
	}
    }

    /**
     * <p>
     * Método responsável por verificar se a conta corrente esta contida na
     * lista de conta contrato.
     * <p>
     *
     * @param listaContaContrato
     *            valor a ser atribuído
     * @param contaContrato
     *            valor a ser atribuído
     * @return boolean
     * @author guilherme.santos
     */
    private boolean verificarSeListaContemContaCorrente(final Collection<ContaContrato> listaContaContrato, final ContaContrato contaContrato) {

	boolean retorno = false;

	for (final ContaContrato conta : listaContaContrato) {
	    if (conta.getNuConta().getId().equals(contaContrato.getNuConta().getId())) {
		retorno = true;
	    }
	}

	return retorno;
    }

    /**
     * <p>
     * Método responsável por remover elemento da lista de ContaContrato de
     * Cheque.
     * <p>
     *
     * @author guilherme.santos
     */
    public void removerContaCorrenteCartaoCredito() {
	final ContaContrato contaContrato = this.getVisao().getContaContratoCartao();

	this.getVisao().getListaContaContratoCartao().remove(contaContrato);

	this.getVisao().setContaContratoCartao(new ContaContrato());
	this.getVisao().getContaContratoCartao().setNuConta(new ContaCorrente());

	this.montarArvoreCartaoCredito();
    }

    /**
     * <p>
     * Método responsável por adicionar o cedente na lista e salvar no banco.
     * <p>
     *
     * @author Caio Graco
     * @author Gilberto Nery
     * 
     */
    public void adicionarCedente() {
	
	final Cedente cedente = this.getVisao().getCedenteIncluido();
	
	final Pessoa pessoaContrato = visao.getPessoaObj();

	if (!UtilObjeto.isReferencia(visao.getPessoaObj().getNuCnpj())) {
	    this.adicionaMensagemDeAlerta(PreAnaliseMB.UC_PRE_ANALISE_PESSOA_INEXISTENTE);
	    return;
	}
	
	Cedente cedenteIncluido = this.preAnaliseService.getParametrizacaoContratoService().adicionarCedente(cedente, (List<Cedente>) this.getVisao().getListaCedentes(), pessoaContrato);

	if(cedenteIncluido == null) {
	    super.adicionaMensagemInformativa("MN083");
	} else if(cedenteIncluido.getNuCedente() == null && cedenteIncluido.getCoCedente() == null) {
	    super.adicionaMensagemDeErro("MN018");
	} 
				
	this.getVisao().setCedenteIncluido(new Cedente());
	
    }
    
    /**
     * <p>
     * Método responsável por buscar a pessoa pelo cnpj e exibir na tela.
     * <p>
     *
     * @author Thales Ribeiro
     */
    public void buscarPessoa() {
	final PreAnaliseVisao visao2 = this.getVisao();
	final String cnpj = UtilCnpj.removerFormatacao(visao2.getPessoaObj().getNuCnpj());

	if (UtilCnpj.isCNPJ(cnpj) || UtilCpf.isCPF(cnpj)) {
	    Pessoa pessoa = this.preAnaliseService.obterNomePessoaPorCnpj(cnpj);

	    if (UtilObjeto.isReferencia(pessoa)) {
	    	visao2.setPessoaObj(pessoa);
	    	
	    } else {
		try {
		    pessoa = this.preAnaliseService.inserirPessoa(cnpj);
		    visao2.setPessoaObj(pessoa);
		} catch (Exception e) {
		    LogCEF.debug(e);
		    visao2.setPessoaObj(new Pessoa());
		    this.adicionaMensagemDeAlerta(PreAnaliseMB.CNPJ_INVALIDO);
		}
	    }
	}
    }

    /**
     * @param visao2
     * @param pessoa
     */
    public void formatarCpfOuCnpjPorTipoPessoa(final PreAnaliseVisao visao2, Pessoa pessoa) {
	String nuCnpj = pessoa.getNuCnpj();
	if(EnumTipoPessoa.F.getDocumento().contains(pessoa.getIcPfPj())) {
	    if(nuCnpj.length() == 14) {
		nuCnpj = nuCnpj.substring(3,14);
	    }
	    pessoa.setNuCnpj(UtilFormatacao.formatar(nuCnpj, EnumTipoFormatacao.CPF));
	}else {
	    pessoa.setNuCnpj(UtilFormatacao.formatar(nuCnpj, EnumTipoFormatacao.CNPJ));		    
	}
	visao2.setPessoaObj(pessoa);
    }

    /**
     * <p>
     * Método responsável por remover o cedente selecionado.
     * <p>
     *
     * @author Caio Graco
     */
    public void removerCedente() {

	final Cedente cedente = this.getVisao().getCedenteIncluido();

	Integer nuGarantia = 0;
	if(this.getVisao().getParametrizacaoEdicao() != null && this.getVisao().getParametrizacaoEdicao().getGarantiaContrato() != null
		&& this.getVisao().getParametrizacaoEdicao().getGarantiaContrato().getNuGarantia() != null) {
	    nuGarantia = this.getVisao().getParametrizacaoEdicao().getGarantiaContrato().getNuGarantia();
	}
	
	String msg = this.getService().getParametrizacaoContratoService().removerCedente(cedente, nuGarantia);

	if(msg != null && !msg.isEmpty()) {
	    super.adicionaMensagemInformativa(msg);
	}

	this.getVisao().setCedenteIncluido(new Cedente());
	
    }

    /**
     * <p>
     * Método responsável por tratar os campos para Garantia Duplicata.
     * <p>
     *
     * @param garantia
     *            valor a ser atribuído
     * @author guilherme.santos
     */
    private void tratarGarantiaDuplicata(final Garantia garantia) {
	if (garantia.isGrupoGarantia(GrupoGarantiaEnum.DUPLICATA)) {

	    this.getVisao().getGarantiaContratoEdicao().setIcCaracteristica(null);
	    this.getVisao().getGarantiaContratoEdicao().setIcFormaGarantia1(null);

	    this.desabilitarCampos(false);
	    this.ocultarCampos(false);
	    this.getVisao().setOcultarValor(true);
	    // Recupera os parametros automaticos para os campos nulos, caso nao
	    // seja uma edição
	    if (this.visao.getParametrizacaoEdicao() == null) {
		this.recuperarParametrosCalculoDuplicata();
	    }

	}
    }

    /**
     * <p>
     * Método responsável por inicializar os valores parametrizados dos
     * calculos.
     * <p>
     *
     * @author guilherme.santos
     */
    public void recuperarParametrosCalculoDuplicata() {

	if (this.getVisao().getGarantiaContratoEdicao().getVrPrazoMaximoPermitido() == null) {
	    this.getVisao().getGarantiaContratoEdicao()
		    .setVrPrazoMaximoPermitido(this.preAnaliseService.consultarParametroCalculo(ParametroCalculoEnum.PRAZO_MAXIMO_DUPLICATA));
	}
	if (this.getVisao().getGarantiaContratoEdicao().getVrMaximoPermitido() == null) {
	    this.getVisao().getGarantiaContratoEdicao()
		    .setVrMaximoPermitido(this.preAnaliseService.consultarParametroCalculo(ParametroCalculoEnum.VALOR_MAXIMO_DUPLICATA));
	}
	if (this.getVisao().getGarantiaContratoEdicao().getVrPercentualMaximoCncno() == null) {
	    this.getVisao().getGarantiaContratoEdicao()
		    .setVrPercentualMaximoCncno(this.preAnaliseService.consultarParametroCalculo(ParametroCalculoEnum.PERCENTUAL_MAXIMO_DUPLICATA));
	}
    }

    /**
     * <p>
     * Método responsável por desabilitar os campos tipo garantia e forma
     * garantia.
     * <p>
     *
     * @param desabilitar
     *            valor a ser atribuído
     * @author Caio Graco
     */
    private void desabilitarCampos(final boolean desabilitar) {
	this.getVisao().setDesabilitarTipoGarantia(desabilitar);
    }

    /**
     * <p>
     * Método responsável por renderizar ou não os campos da tela.
     * <p>
     *
     * @param valor
     *            valor a ser atribuído
     * @author Caio Graco
     */
    private void ocultarCampos(final boolean valor) {
	this.getVisao().setOcultarInstrucaoProtesto(valor);
	this.getVisao().setOcultarPercentualMaximo(valor);
	this.getVisao().setOcultarPrazoMaximo(valor);
	this.getVisao().setOcultarValor(valor);
	this.getVisao().setOcultarValorMaximo(valor);
	this.getVisao().setExibirAplicacaoFinanceira(valor);
	// Exceção para garantias diferentes de Cheque e Cartão
	this.getVisao().setOcultarTipoGarantia(false);
    }

    /**
     * <p>
     * Método responsável por editar uma parametrização.
     * </p>
     *
     * @param parametrizacaoEdicao
     *            valor a ser atribuído
     * @return String
     * @author thales.ribeiro, guilherme.santos
     */
    public String editar(final ParametrizacaoContratoVO parametrizacaoEdicao) {
	final PreAnaliseVisao visao = this.getVisao();
	final GarantiaContrato garantiaContratoClonado = UtilObjeto.clone(parametrizacaoEdicao.getGarantiaContrato());

	visao.setGarantiaContratoEdicao(garantiaContratoClonado);
	visao.setGarantia(garantiaContratoClonado.getGarantia());
	visao.setIdentificadorGarantia(garantiaContratoClonado.getGarantia().getCoOperacao());

	visao.setParametrizacaoEdicao(parametrizacaoEdicao);

	if (garantiaContratoClonado.isGarantiaDuplicata()) {
	    visao.setListaCedentes(null);
	    visao.getListaCedentes().addAll(UtilObjeto.clone(garantiaContratoClonado.getCedenteList()));

	    this.desabilitarCampos(false);
	    this.ocultarCampos(false);
	    visao.setOcultarValor(true);

	    if (garantiaContratoClonado.getIcCaracteristica().equals(CaracteristicaEnum.FLUXO)) {
		visao.setOcultarPrazoMaximo(Boolean.TRUE);
		visao.setOcultarValorMaximo(Boolean.TRUE);
		visao.setOcultarPercentualMaximo(Boolean.TRUE);
		visao.setOcultarInstrucaoProtesto(Boolean.TRUE);
	    }
	}

	for (final Cedente cedente : visao.getListaCedentes()) {
	    cedente.setUtilizado(false);
	    if (garantiaContratoClonado.getCedenteList() != null && garantiaContratoClonado.getCedenteList().contains(cedente)) {
		cedente.setUtilizado(true);
	    }
	}

	this.atualizarListaGarantiaCartaoSelecionado(garantiaContratoClonado);

	// Tratar Garantia do tipo Cartão ou Cheque
	this.tratarGarantiaCartaoCredito(garantiaContratoClonado.getGarantia());
	// Habilita os campos para serem mostrados.
	this.getVisao().setExibirCamposEdicao(true);
	// Desabilita a combo de garantias
	this.getVisao().setDesabilitarComboGarantia(true);
	// Habilita botões de edição
	this.getVisao().setEdicao(true);

	if (!UsuarioUtil.contemPermissao(NoFuncionalidadeEnum.PARAMETRIZA_CONTRATO_GARANTIA_CONTRATO.getNoFuncionalidade(),
		EnumAcao.INCLUIR.getNoAcao(), null, null)) {
	    this.getVisao().setDesabilitarTipoGarantia(true);
	    this.getVisao().setDesabilitarCampos(true);
	}

	return null;
    }

    /**
     * Método responsável por.
     *
     * @author Leandro Santos Oliveira
     *
     * @param garantiaContratoClonado
     *            valor a ser atribuído
     */
    @SuppressWarnings("unused")
    private void atualizarListaGarantiaCartaoSelecionado(final GarantiaContrato garantiaContratoClonado) {
	final PreAnaliseVisao visao = this.getVisao();
	final List<GarantiaCartaoCredito> listaCartao = (List<GarantiaCartaoCredito>) garantiaContratoClonado.getListaGarantiaCartaoCredito();
	visao.setCartoesSelecionados(new TreeNode[listaCartao.size()]);

	int index = 0;

	for (final TreeNode treeNode : visao.getCartoesSelecionados()) {
	    visao.getCartoesSelecionados()[index] = new DefaultTreeNode(listaCartao.get(index));
	    visao.getCartoesSelecionados()[index].setSelected(true);
	    visao.getCartoesSelecionados()[index].setSelectable(false);
	    visao.getCartoesSelecionados()[index].setRowKey("" + index + "_" + (index + 1));

	    index++;
	}
    }

    /**
     * <p>
     * Método responsável por buscar as duplicatas da garantia delecionada.
     * <p>
     *
     * @param idGarantia
     *            valor a ser atribuído
     * @author Caio Graco
     */
    public void buscarDuplicatasGarantia(final Integer idGarantia) {
	final Collection<DuplicataExcepcionada> duplicataContratos = this.preAnaliseService.getParametrizacaoContratoService()
		.listarDuplicatasPorGarantia(this.preAnaliseService.getParametrizacaoContratoService().obter(idGarantia));

	this.getVisao().setDuplicatasEncontradas(new ArrayList<DuplicataVO>());
	this.getVisao().setDuplicataExcepcionada(new DuplicataExcepcionada());

	if (duplicataContratos.isEmpty()) {
	    this.getVisao().setDuplicatasParaExcepcionar(new ArrayList<DuplicataVO>());
	} else {
	    final Collection<DuplicataVO> vos = new ArrayList<>();
	    DuplicataVO duplicataVO;

	    for (final DuplicataExcepcionada duplicataExcepcionada : duplicataContratos) {
		duplicataVO = new DuplicataVO();

		duplicataVO.setCoNossoNumero(duplicataExcepcionada.getCoNossoNumero());
		duplicataVO.setNuDuplicata(duplicataExcepcionada.getNuDuplicata());
		duplicataVO.setVrDuplicata(duplicataExcepcionada.getVrDuplicata());

		vos.add(duplicataVO);
	    }

	    this.getVisao().setDuplicatasParaExcepcionar(vos);
	}
    }

    /**
     * <p>
     * Método responsável por parametrizar contrato.
     * </p>
     *
     * @return String
     * @author joseroberto@gsgroup.com.br, Ronnie Mikihiro
     */
    public String adicionar() {
	final PreAnaliseVisao visao = this.getVisao();
	ParametrizacaoContratoVO parametrizacao = new ParametrizacaoContratoVO();
	parametrizacao.setGarantiaContrato(new GarantiaContrato());

	// Se o objeto de edicao nao for nulo significa que é uma edição
	if (UtilObjeto.isReferencia(visao.getParametrizacaoEdicao())) {
	    parametrizacao = visao.getParametrizacaoEdicao();
	}

	// Obtem a garantia contrato que estava sendo trabalhada na tela
	final GarantiaContrato garantiaContrato = visao.getGarantiaContratoEdicao();

	//Salva o contrato como Pré-Análise
	garantiaContrato.getNuContrato().setIcSituacao("05");
	
	garantiaContrato.setVrPrazoMinimoPermitido(BigDecimal.ZERO);
	garantiaContrato.setIcFormaGarantia1(FormaGarantiaEnum.VALOR_CONTRATO);
	garantiaContrato.setVrFormaGarantia1(new BigDecimal(PreAnaliseMB.VALOR_FORMA_GARANTIA_FICTICIO));
	garantiaContrato.setDeObservacao(visao.getGarantiaContratoEdicao().getDeObservacao());

	garantiaContrato.getNuContrato().setDtContrato(new Date());
	garantiaContrato.getNuContrato().setNuPessoa(this.getVisao().getPessoaObj());
	
	// Se na garantiacontrato não tiver a garantia então adiciona
	if (!UtilObjeto.isReferencia(garantiaContrato.getGarantia())) {
	    garantiaContrato.setGarantia(
		    this.preAnaliseService.getParametrizacaoContratoService().obterGarantiaPorCodigoOperacao(visao.getIdentificadorGarantia()));
	}

	// Preenche lista de cedentes da parametrizacao com os cedentes
	// selecionados
	if (garantiaContrato.isGarantiaDuplicata()) {
	    garantiaContrato.setCedenteList(visao.getCedentesSelecionados());
	    garantiaContrato.setVrMaximoPermitido(visao.getGarantiaContratoEdicao().getVrMaximoPermitido());
	    garantiaContrato.setVrPercentualMaximoCncno(visao.getGarantiaContratoEdicao().getVrPercentualMaximoCncno());
	    garantiaContrato.setVrPrazoMaximoPermitido(visao.getGarantiaContratoEdicao().getVrPrazoMaximoPermitido());
	}

	// Preenche a lista com as GarantiaCartaoCredito selecionadas
	if (garantiaContrato.isGarantiaCartaoCredito()) {
	    // Pré-analise ainda não tem condições habilitadas para cartao de credito V2 
//	    boolean isGarantiaCartaoCreditoV2 = false;
//	    garantiaContrato.setListaGarantiaCartaoCredito(isGarantiaCartaoCreditoV2 ? this.getContaCorrenteCartaoMB().getListaGarantiaCartaoCreditoSelecionadosV2()
//		    : this.getListaGarantiaCartaoCreditoSelecionados());
	    garantiaContrato.setListaGarantiaCartaoCredito(this.getListaGarantiaCartaoCreditoSelecionados());
	}

	this.getService().getParametrizacaoContratoService().validarDadosParametrizacaoContrato(visao.getGarantiaContratoEdicao(),
		visao.getListaCedentes(), null, garantiaContrato.getListaGarantiaCartaoCredito());

	// Caso não tenha passado na validação apresenta mensagem e retorna para
	// mesma tela
	if (visao.getGarantiaContratoEdicao().hasMensagens()) {
	    super.adicionaListaMensagemDeAlerta(visao.getGarantiaContratoEdicao().getMensagens());
	    return super.MESMA_TELA;
	}

	// Valida a inclusao de duplicatas do mesmo tipo
	final Boolean duplicatasAdicionadasMesmoTipo = this.preAnaliseService.getParametrizacaoContratoService()
		.validarDuplicatasAdicionadasMesmoTipo(visao.getParametrizacaoList(), garantiaContrato);

	if (duplicatasAdicionadasMesmoTipo) {
	    super.adicionaMensagemInformativa(ParametrizacaoContratoMB.DUPLICATAS_ADICIONADAS_MESMO_TIPO);
	    return super.MESMA_TELA;
	}

	// Preenche os dados basicos da garantia parametrizada
	parametrizacao.setGarantiaContrato(garantiaContrato);

	// Caso ainda não exista na lista adiciona
	if (!visao.getParametrizacaoList().contains(parametrizacao)) {
	    visao.getParametrizacaoList().add(parametrizacao);
	}
	super.adicionaMensagemDeSucesso(PreAnaliseMB.OPERACAO_REALIZADA_SUCESSO);
	this.ocultarCamposGarantia();
	return super.MESMA_TELA;
    }

    /**
     * <p>
     * Método responsável por.
     * <p>
     *
     * @author Caio Graco
     */
    private void ocultarCamposGarantia() {
	this.limparDadosParametrizacao();
	this.visao.setParametrizacaoContratoVOTemp(null);
	this.getVisao().setExibirCamposEdicao(false);
	this.getVisao().setDesabilitarComboGarantia(false);
    }

    /**
     * <p>
     * Método responsável por limpar os dados da tela de uma parametrização para
     * o contrato.
     * </p>
     *
     */
    public void limparDadosParametrizacao() {
	final PreAnaliseVisao visao = this.getVisao();
	visao.setIdentificadorGarantia(null);
	visao.setIdentificadorRemocao(null);
	visao.setParametrizacaoEdicao(null);
	visao.setEdicao(Boolean.FALSE);
	visao.getListaCedentes().clear();
	visao.setIdentificadorGarantia(null);
	visao.setExibirModalExclusao(Boolean.FALSE);
	// Cartao de credito
	visao.setExibirCartaoCredito(Boolean.FALSE);
	visao.setContaContratoCartao(new ContaContrato());
	this.getVisao().setContaCorrenteCartaoCredito(null);
	visao.getContaContratoCartao().setNuConta(new ContaCorrente());
	visao.getContaContratoCartao().getNuConta().setId(new ContaCorrenteID());
    }

    /**
     * <p>
     * Método responsável por retornar as GarantiaCartaoCredito da arvore.
     * <p>
     *
     * @return Collection<GarantiaCartaoCredito>
     * @author guilherme.santos
     */
    public Collection<GarantiaCartaoCredito> getListaGarantiaCartaoCreditoSelecionados() {

	final Collection<GarantiaCartaoCredito> listaGarantiaCartaoCredito = new ArrayList<>();
	if (this.getVisao().getCartoesSelecionados() != null) {

	    for (final TreeNode treeNode : this.getVisao().getCartoesSelecionados()) {
		if (UtilObjeto.isReferencia(treeNode) && treeNode.getData() instanceof GarantiaCartaoCredito) {

		    final GarantiaCartaoCredito novaGarantiaCartao = (GarantiaCartaoCredito) treeNode.getData();
		    GarantiaCartaoCredito garantiaCartaoCreditoSelecionada = null;

		    if (novaGarantiaCartao.getNuGarantiaCartaoCredito() != null) {
			garantiaCartaoCreditoSelecionada = this.preAnaliseService.getParametrizacaoContratoService()
				.consultarGarantiaCartaoCreditoPorId(novaGarantiaCartao.getNuGarantiaCartaoCredito());
		    }

		    if (garantiaCartaoCreditoSelecionada == null) {
			garantiaCartaoCreditoSelecionada = new GarantiaCartaoCredito();
			garantiaCartaoCreditoSelecionada.setVrConsumido(BigDecimal.ZERO);
			garantiaCartaoCreditoSelecionada.setBandeiraCartao(novaGarantiaCartao.getBandeiraCartao());
			garantiaCartaoCreditoSelecionada.setNuConta(novaGarantiaCartao.getNuConta());
			garantiaCartaoCreditoSelecionada.setGarantiaContrato(this.getVisao().getGarantiaContratoEdicao());
		    }

		    listaGarantiaCartaoCredito.add(garantiaCartaoCreditoSelecionada);
		}
	    }

	}

	return listaGarantiaCartaoCredito;
    }

    /**
     * <p>
     * Método responsável por retornar a string com o valor da forma da
     * parametrização.
     * <p>
     *
     * @param parametrizacaoContratoVO
     *            valor a ser atribuído
     * @return String
     * @author Waltenes Junior
     */
    public String criarStringFormaParametrizacao(final ParametrizacaoContratoVO parametrizacaoContratoVO) {
	if (null != parametrizacaoContratoVO && parametrizacaoContratoVO.getGarantiaContrato().getIcFormaGarantia1() != null) {
	    String porcentagem = PreAnaliseMB.VAZIO;

	    if (parametrizacaoContratoVO.getGarantiaContrato().getGarantia().getGrupoGarantia().getNuGrupoGarantia() == GrupoGarantiaEnum.DUPLICATA
		    .getCodigo() && parametrizacaoContratoVO.getGarantiaContrato().getIcFormaGarantia1().equals(FormaGarantiaEnum.PMT)) {

		final BigDecimal valor = parametrizacaoContratoVO.getGarantiaContrato().getVrFormaGarantia1();
		String numero = PreAnaliseMB.VAZIO;

		try {
		    numero = String.valueOf(valor.intValueExact());
		} catch (final Exception e) {
		    LogCEF.debug(e);
		    numero = valor.toString();
		}

		porcentagem = numero.replace(".", ",").concat("%");
	    } else {
		if (parametrizacaoContratoVO.getGarantiaContrato().getVrFormaGarantia1() != null) {
		    porcentagem = parametrizacaoContratoVO.getGarantiaContrato().getVrFormaGarantia1().toString().replace(".", ",").concat("%");
		}
	    }
	    final CaracteristicaEnum icCaracteristica = parametrizacaoContratoVO.getGarantiaContrato().getIcCaracteristica();
	    final String caracteristica = icCaracteristica != null ? icCaracteristica.toString().toLowerCase() : PreAnaliseMB.VAZIO;
	    final String forma = parametrizacaoContratoVO.getGarantiaContrato().getIcFormaGarantia1().toString().replace("_", " ").toLowerCase();

	    return porcentagem.concat(" ").concat(forma).concat(" ").concat(caracteristica);
	}
	return PreAnaliseMB.VAZIO;
    }

    /**
     * <p>
     * Método responsável por retornar a String com o valor da forma garantia 2
     * da parametrização.
     * <p>
     *
     * @param parametrizacaoContratoVO
     *            valor a ser atribuído
     * @return String
     * @author Ronnie Mikihiro
     */
    public String criarStringForma2Parametrizacao(final ParametrizacaoContratoVO parametrizacaoContratoVO) {
	if (parametrizacaoContratoVO != null && parametrizacaoContratoVO.getGarantiaContrato().getIcFormaGarantia2() != null) {
	    if (parametrizacaoContratoVO.getGarantiaContrato().getGarantia() != null) {
		if (parametrizacaoContratoVO.getGarantiaContrato().getGarantia().getGrupoGarantia()
			.getNuGrupoGarantia() == GrupoGarantiaEnum.DUPLICATA.getCodigo()) {
		    final String porcentagem2 = parametrizacaoContratoVO.getGarantiaContrato().getVrFormaGarantia2().toString().replace(".", ",")
			    .concat("%");
		    final String caracteristica2 = parametrizacaoContratoVO.getGarantiaContrato().getIcCaracteristica().toString().toLowerCase();
		    final String forma2 = parametrizacaoContratoVO.getGarantiaContrato().getIcFormaGarantia2().toString().replace("_", " ")
			    .toLowerCase();
		    return porcentagem2.concat(" ").concat(forma2).concat(" ").concat(caracteristica2);
		}
		return null;
	    }
	    return null;
	}
	return null;
    }

    /**
     * <p>
     * Método responsável por salvar a parametrização.
     * </p>
     *
     * @return String
     * @author thales.ribeiro, guilherme.santos
     */
    public String salvarParametrizacao() {
	final PreAnaliseVisao visao2 = this.getVisao();
	final Contrato contrato = this.recuperarContrato();

	if (UtilObjeto.isReferencia(contrato.getIcCategoria())) {
	    contrato.setIcCategoria('1');
	}
	final char inclusaoManual = '4';
	contrato.setIcFormaInclusao(inclusaoManual);

	contrato.setNuUnidade(visao2.getUnidadeSelecionada());
	contrato.setNuUnidadeContratacao(visao2.getUnidadeSelecionada());

	this.getService().validarContrato(contrato, visao2.getParametrizacaoList());

	try {
	    if (contrato.hasMensagens()) {
		super.adicionaListaMensagemDeAlerta(contrato.getMensagens());
		visao2.setExibirModalOperacaoRealizadaComSucesso(Boolean.FALSE);

	    } else {
		final String retorno = this.preAnaliseService.salvarPreAnalise(visao2.getParametrizacaoList(), visao2.getListaExclusaoParametrizacao(),
			contrato, visao2.getListaContaContrato(), visao2.getListaContaContratoCartao());

		if (UtilString.isVazio(retorno)) {
		    visao2.setMensagemSalvarParametrizacao(MensagensUtil.getMensagem(PreAnaliseMB.MSG_APP, PreAnaliseMB.MENSAGE_SUCESSO));
		    visao2.setExibirModalOperacaoRealizadaComSucesso(Boolean.TRUE);

		} else {
		    visao2.setMensagemSalvarParametrizacao(MensagensUtil.getMensagem(PreAnaliseMB.MSG_APP, retorno));
		    visao2.setExibirModalOperacaoRealizadaComSucesso(Boolean.TRUE);
		}
	    }

	    this.filtrar();

	} catch (final Exception e) {
	    LogCEF.debug(e);
	    visao2.setMensagemSalvarParametrizacao(e.getLocalizedMessage());
	}

	return super.MESMA_TELA;
    }

    /**
     * <p>
     * Método responsável por recuperar o contrato com informações da tela.
     * <p>
     *
     * @return Contrato
     * @author guilherme.santos
     */
    private Contrato recuperarContrato() {
	final PreAnaliseVisao visao = this.getVisao();
	final UnidadeVinculadaSuat unidade = this.preAnaliseService.getUnidade(this.visao.getUnidadeSelecionada());
	final Contrato contrato = visao.getContratoPreAnalise();

	this.buscarPessoa();
	contrato.setContaContratoList(visao.getListaContaContrato());
	contrato.setNuPessoa(visao.getPessoaObj());
	contrato.setDtInclusaoContrato(contrato.getDtInclusaoContrato());
	if (UtilObjeto.isReferencia(unidade)) {
	    contrato.setNuUnidade(unidade.getNuUnidade());
	    contrato.setNuNatural(unidade.getNuNaturalSr());
	}
	contrato.setUnidade(unidade);

	if (UtilObjeto.isReferencia(unidade) && UtilObjeto.isReferencia(unidade.getNuNaturalSr())) {
	    contrato.setNuNatural(unidade.getNuNaturalSr());
	}

	return contrato;
    }

    /**
     * <p>
     * Método responsável por atualizar o contrato com dados definidos na tela.
     * <p>
     *
     * @author guilherme.santos
     */
    public void atualizarContrato() {
	this.buscarPessoa();

	if (this.getVisao().getContratoPreAnalise() == null) {
	    final Contrato contrato = new Contrato();

	    contrato.setNuPessoa(this.getVisao().getPessoaObj());
	    this.getVisao().setContratoPreAnalise(contrato);
	}
    }

    /**
     * <p>
     * Método responsável por verificar se a garantia é do tipo duplicata.
     * <p>
     *
     * @return boolean
     * @author Caio Graco
     */
    public boolean isGarantiaDuplicata() {
	return this.preAnaliseService.isGarantiaDuplicata(this.getVisao().getIdentificadorGarantia());
    }

    /**
     * @see br.gov.caixa.pedesgo.arquitetura.controlador.AbstractBean#getTelaConsulta()
     */
    @Override
    public String getTelaConsulta() {
    	this.getVisao().setSuatSelecionada(null);
		this.getVisao().setSrSelecionada(null);
		this.getVisao().setUnidadeSelecionada(null);
		this.carregar();

		return PreAnaliseMB.DIRETORIO_PAGINAS + this.getPrefixoCasoDeUso() + AbstractBean.SUFIXO_TELA_CONSULTA;
    }

    /**
     * @see br.gov.caixa.pedesgo.arquitetura.controlador.AbstractBean#getTelaEdicao()
     */
    @Override
    @Auditoria
    @OperacaoAuditoria(acao = "ABRIR_EDICAO_PARAMETRO_PRE_ANALISE")
    public String getTelaEdicao() {
	this.carregarEdicao();
	this.carregarGarantias();
	this.ocultarCamposGarantia();

	return PreAnaliseMB.DIRETORIO_PAGINAS + this.getPrefixoCasoDeUso() + AbstractBean.SUFIXO_TELA_EDICAO;
    }

    /**
     * @see br.gov.caixa.pedesgo.arquitetura.controlador.AbstractBean#getTelaInclusao()
     */
    @Override
    public String getTelaInclusao() {
    	this.carregar();
    	this.carregarGarantias();
    	
    	final Collection<Integer> listaNuUnidades = this.permissao
                .prepararConsultaPorTipoAbrangencia(NoFuncionalidadeEnum.PRE_ANALISE_CARTEIRA.getNoFuncionalidade());
    	
        if (null == listaNuUnidades || listaNuUnidades.isEmpty()) {
            getVisao().setListaUnidade(unidadeVinculadaSuatService.listarTodasUnidades());

        } else {
        	getVisao().setListaUnidade(unidadeVinculadaSuatService.listarUnidadesPorListaNuUnidade(listaNuUnidades));
        }
    	
    	return PreAnaliseMB.DIRETORIO_PAGINAS + this.getPrefixoCasoDeUso() + AbstractBean.SUFIXO_TELA_EDICAO;
    }

    /**
     * @see br.gov.caixa.pedesgo.arquitetura.controlador.AbstractBean#getService()
     */
    @SuppressWarnings("unchecked")
    @Override
    public PreAnaliseService getService() {
	return this.preAnaliseService;
    }

    /**
     * <p>
     * Método responsável por adicionar uma nova conta a lista de Conta Corrente
     * NLM.
     * <p>
     *
     * @author guilherme.santos
     */
    public void adicionarContaCorrente() {
	final PreAnaliseVisao visao = this.getVisao();
	final ContaContrato novaContaCotrato = visao.getContaContrato();

	if (UtilObjeto.isReferencia(novaContaCotrato) && !UtilString.isVazio(novaContaCotrato.getNuConta().getId().getNuAgencia())) {

	    novaContaCotrato.setIcOrigem(TipoOrigemContaContratoEnum.CONTRATO);
	    novaContaCotrato.setIcConta(ContaEnum.CONTA_NAO_LIVRE_MOVIMENTACAO);
	    novaContaCotrato.setIcUtilizarSaldo(true);
	    novaContaCotrato.setIcUtilizarSaldoCheque(false);
	    novaContaCotrato.getNuConta().setNuPessoa(visao.getPessoaObj());
	    if (!visao.getListaContaContrato().contains(novaContaCotrato)) {
		visao.getListaContaContrato().add(novaContaCotrato);
	    }
	    visao.setContaContrato(null);
	}
    }

    /**
     * @see br.gov.caixa.pedesgo.arquitetura.controlador.AbstractBean#getVisao()
     */
    @Override
    public PreAnaliseVisao getVisao() {
	if (this.visao == null) {
	    this.visao = new PreAnaliseVisao();
	}
	return this.visao;
    }

    /**
     * @see br.gov.caixa.pedesgo.arquitetura.controlador.AbstractBean#getPrefixoCasoDeUso()
     */
    @Override
    protected String getPrefixoCasoDeUso() {
	return PreAnaliseMB.PREFIXO_CASO_DE_USO;
    }

    /**
     * Retorna o valor do atributo relatorioPreAnaliseMB.
     *
     * @return relatorioPreAnaliseMB
     */
    public RelatorioPreAnaliseMB getRelatorioPreAnaliseMB() {

	return this.relatorioPreAnaliseMB;
    }

    /**
     * Define o valor do atributo relatorioPreAnaliseMB.
     *
     * @param relatorioPreAnaliseMB
     *            valor a ser atribuído
     */
    public void setRelatorioPreAnaliseMB(final RelatorioPreAnaliseMB relatorioPreAnaliseMB) {

	this.relatorioPreAnaliseMB = relatorioPreAnaliseMB;
    }

    /**
     * <p>
     * Método responsável por cancelar pre analise.
     * <p>
     *
     * @return String
     * @author guilherme.santos
     */
    public String cancelarPreAnalise() {
	this.getVisao().setEntidade(new PreAnalise());

	return this.getTelaConsulta();
    }

    /**
     * <p>
     * Método responsável por remover a conta corrente da lista.
     * <p>
     *
     * @author guilherme.santos
     */
    public void removerContaCorrente() {
	this.getVisao().getListaContaContrato().remove(this.visao.getContaContrato());
	this.visao.setContaContrato(null);
    }

    /**
     * <p>
     * Método responsável por remover uma parametrização do contrato.
     * </p>
     *
     * @return String
     * @author guilherme.santos
     */
    public String removerPreAnalise() {
	final PreAnaliseVisao visao = this.getVisao();
	this.preAnaliseService.excluirContratoPreAnalise(Integer.valueOf(visao.getIdentificadorRemocao()));

	if (visao.getLista().contains(visao.getEntidade())) {
	    visao.getLista().remove(visao.getEntidade());
	}

	super.adicionaMensagemInformativa(PreAnaliseMB.OPERACAO_REALIZADA_SUCESSO);

	return super.MESMA_TELA;
    }

    /**
     * <p>
     * Método responsável por remover uma parametrização do contrato.
     * </p>
     *
     * @return String
     * @author guilherme.santos
     */
    public String remover() {
	final PreAnaliseVisao visao = this.getVisao();
	for (final ParametrizacaoContratoVO parametrizacao : visao.getParametrizacaoList()) {
	    if (parametrizacao.getIdentificador().equals(visao.getIdentificadorRemocao())) {
		visao.getListaExclusaoParametrizacao().add(parametrizacao);
		visao.getParametrizacaoList().remove(parametrizacao);
		break;
	    }
	}
	super.adicionaMensagemInformativa(PreAnaliseMB.OPERACAO_REALIZADA_SUCESSO);
	this.limparDadosParametrizacao();
	this.cancelarEdicao();
	return super.MESMA_TELA;
    }

    /**
     * <p>
     * Método responsável por invocar a pagina de consulta.
     * <p>
     *
     * @return String
     * @author guilherme.santos
     */
    public String abrirConsulta() {
	this.cancelarEdicao();
	return this.getTelaConsulta();
    }

    /**
     * <p>
     * Método responsável por cancelar a edição da uma GarantiaContrato.
     * <p>
     *
     * @author guilherme.santos
     */
    public void cancelarEdicao() {
	this.ocultarCamposGarantia();
	this.getVisao().setGarantiaContratoEdicao(new GarantiaContrato());
    }

    /**
     * <p>
     * Método responsável por filtrar conta contrato para visualização na
     * Garantia Cartao.
     * <p>
     *
     * @param listaSemTratamento
     *            valor a ser atribuído
     * @return Collection<ContaContrato>
     * @author guilherme.santos
     */
    private Collection<ContaContrato> filtrarListaContaContratoParaCartao(final Collection<ContaContrato> listaSemTratamento) {
	final Collection<ContaContrato> listaTratada = new ArrayList<>();
	for (final ContaContrato contaContrato : listaSemTratamento) {
	    if (this.verificarSeOrigemEhCartaoOuImportado(contaContrato)) {
		listaTratada.add(contaContrato);
	    }
	}
	return listaTratada;
    }

    /**
     * <p>
     * Método responsável por verificar se a origem é de Cartão ou importado.
     * <p>
     *
     * @param contaContrato
     *            valor a ser atribuído
     * @return boolean
     * @author guilherme.santos
     */
    private boolean verificarSeOrigemEhCartaoOuImportado(final ContaContrato contaContrato) {
	return contaContrato.getIcOrigem() == null || contaContrato.getIcOrigem().equals(TipoOrigemContaContratoEnum.CARTAO_CREDITO)
		|| contaContrato.getIcOrigem().equals(TipoOrigemContaContratoEnum.IMPORTADO);
    }

    /**
     * <p>
     * Método responsável por filtrar conta contrato para visualização no
     * contrato.
     * <p>
     *
     * @param listaSemTratamento
     *            valor a ser atribuído
     * @return Collection<ContaContrato>
     * @author guilherme.santos
     */
    private Collection<ContaContrato> filtrarListaContaContratoParaContrato(final Collection<ContaContrato> listaSemTratamento) {
	final Collection<ContaContrato> listaTratada = new ArrayList<>();
	for (final ContaContrato contaContrato : listaSemTratamento) {
	    if (this.verificarSeOrigemEhContratoOuImportado(contaContrato)) {
		listaTratada.add(contaContrato);
	    }
	}
	return listaTratada;
    }

    /**
     * <p>
     * Método responsável por verificar se a origem é do contrato ou importado.
     * <p>
     *
     * @param contaContrato
     *            valor a ser atribuído
     * @return boolean
     * @author guilherme.santos
     */
    private boolean verificarSeOrigemEhContratoOuImportado(final ContaContrato contaContrato) {
	return contaContrato.getIcOrigem() == null || contaContrato.getIcOrigem().equals(TipoOrigemContaContratoEnum.CONTRATO)
		|| contaContrato.getIcOrigem().equals(TipoOrigemContaContratoEnum.IMPORTADO);
    }

    /**
     * <p>
     * Método responsável por retornar o atributo trilhaHistoricoService.
     * <p>
     *
     * @return trilhaHistoricoService
     * @author robson.oliveira
     */
    public TrilhaHistoricoService getTrilhaHistoricoService() {
	return this.trilhaHistoricoService;
    }

    /**
     * <p>
     * Método responsável por atribuir valor ao atributo trilhaHistoricoService.
     * <p>
     *
     * @param trilhaHistoricoService
     *            valor a ser atribuído
     * @author robson.oliveira
     */
    public void setTrilhaHistoricoService(final TrilhaHistoricoService trilhaHistoricoService) {
	this.trilhaHistoricoService = trilhaHistoricoService;
    }

    /**
     * <p>
     * Retorna o valor do atributo contaCorrenteCartaoMB
     * </p>
     * .
     *
     * @return contaCorrenteCartaoMB
     */
    public ContaCorrenteCartaoMB getContaCorrenteCartaoMB() {
        return this.contaCorrenteCartaoMB;
    }

    /**
     * Define o valor do atributo contaCorrenteCartaoMB.
     *
     * @param contaCorrenteCartaoMB
     *            valor a ser atribuído
     */
    public void setContaCorrenteCartaoMB(ContaCorrenteCartaoMB contaCorrenteCartaoMB) {
        this.contaCorrenteCartaoMB = contaCorrenteCartaoMB;
    }
    
	/**
     * <p>
     * Retorna o valor do atributo bandeiraCartaoService
     * </p>
     * .
     *
     * @return bandeiraCartaoService
     */
    public BandeiraCartaoService getBandeiraCartaoService() {
	return this.bandeiraCartaoService;
    }

    /**
     * @see br.gov.caixa.pedesgo.arquitetura.controlador.AbstractBean#getNomeVarResourceBundle()
     */
    @Override
    protected String getNomeVarResourceBundle() {
	return PreAnaliseMB.VAR_RESOURCE_BUNDLE;
    }

	
    public GarantiaContratoService getGarantiaContratoService() {
	return this.garantiaContratoService;
    }

    public void setGarantiaContratoService(GarantiaContratoService garantiaContratoService) {
	this.garantiaContratoService = garantiaContratoService;
    }
    
    /**
     * Retorna o valor do atributo contratoService.
     *
     * @return contratoService
     */
    public ContratoService getContratoService() {
	return this.contratoService;
    }

    /**
     * Define o valor do atributo contratoService.
     *
     * @param contratoService
     *            valor a ser atribuído
     */
    public void setContratoService(final ContratoService contratoService) {
	this.contratoService = contratoService;
    }    
}