/*
 * Copyright (c) 2019 Caixa Econômica Federal. Todos os direitos
 * reservados.
 *
 * Caixa Econômica Federal - SIACG - Sistema de Crédito Rural
 *
 * Este software foi desenvolvido sob demanda da CAIXA e está
 * protegido por leis de direitos autorais e tratados internacionais. As
 * condições de cópia e utilização do todo ou partes dependem de autorização da
 * empresa. Cópias não são permitidas sem expressa autorização. Não pode ser
 * comercializado ou utilizado para propósitos particulares.
 *
 * Uso exclusivo da Caixa Econômica Federal. A reprodução ou distribuição não
 * autorizada deste programa ou de parte dele, resultará em punições civis e
 * criminais e os infratores incorrem em sanções previstas na legislação em
 * vigor.
 *
 * Histórico do TFS:
 *
 * LastChangedRevision: $Revision$
 * LastChangedBy: $Author$
 * LastChangedDate: $Date$
 *
 * HeadURL: $HeadURL$
 *
 */
package br.gov.caixa.siacg.view.mb;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;
import javax.faces.component.UIOutput;
import javax.faces.event.AjaxBehaviorEvent;
import javax.inject.Inject;

import org.apache.commons.lang3.StringUtils;

import br.gov.caixa.pedesgo.arquitetura.enums.EnumExtensaoArquivo;
import br.gov.caixa.pedesgo.arquitetura.relatorio.UtilRelatorio;
import br.gov.caixa.pedesgo.arquitetura.util.LogCefUtil;
import br.gov.caixa.siacg.model.domain.Segmento;
import br.gov.caixa.siacg.model.enums.CaracteristicaEnum;
import br.gov.caixa.siacg.model.enums.SituacaoEnum;
import br.gov.caixa.siacg.model.enums.StatusGarantiaSuficienteEnum;
import br.gov.caixa.siacg.model.vo.FiltroPainelComportamentoVO;
import br.gov.caixa.siacg.model.vo.PainelComportamentoVO;
import br.gov.caixa.siacg.service.ContratoService;
import br.gov.caixa.siacg.service.PropriedadeService;
import br.gov.caixa.siacg.service.SegmentoService;
import br.gov.caixa.siacg.singleton.UsuarioOnlineSingleton;

/**
 * <p>
 * PainelComportamentoMB
 * </p>
 * <p>
 * Descrição: Managed bean do caso de uso de Painel de Comportamento, segundo US
 * 165562.
 * </p>
 * <br>
 * <b>Empresa:</b> Cef - Caixa Econômica Federal
 *
 * @author ludemeula.sa
 * @version 1.0
 */
@ManagedBean
@SessionScoped
public class PainelComportamentoMB {

    private static final String EMBED_TRUE = "?rs:embed=true";
    private static final String HTTP_RELATORIO = "http://relatoriapedes.bi.caixa/reportspbi/powerbi/PEDESGO%20-%207875/SIACG/DES/SIACG_PAINEL_ROTINA";
    private static final String PAGINA_CONSULTA = "/pages/painel/comportamento/consulta.xhtml?faces-redirect=true";
    private static final String PAGINA_MONITORAMENTO = "/pages/painel/monitoramento/consulta.xhtml?faces-redirect=true";

    @Inject
    private ContratoService contratoService;

    @Inject
    private SegmentoService segmentoService;

    @Inject
    private PropriedadeService propriedadeService;

    private FiltroPainelComportamentoVO filtro;

    private Collection<Segmento> segmentos;
    private List<PainelComportamentoVO> statusGarantia;
    private List<PainelComportamentoVO> situacaoContrato;
    private List<PainelComportamentoVO> caracteristicaContrato;
    private Long garantiaAcompanhada;
    private Long garantiaNaoAcompanhada;
    private Long novosContratos;

    public String abrirConsulta() {
	setFiltro(new FiltroPainelComportamentoVO());

	carregarPaineis();

	return PAGINA_CONSULTA;
    }

    public String abrirMonitoramento() {
	return PAGINA_MONITORAMENTO;
    }

    public void selecionarItem(AjaxBehaviorEvent event) {
	filtro.selecionarItem((Boolean) (((UIOutput) event.getSource()).getValue()));
    }

    public void exportar() {

	if (!filtro.isPeloMenosUmItemMarcado()) {
	    return;
	}

	byte[] relatorio = this.contratoService.getRelatorioPainelSIACG(filtro);

	this.inserirRelatorioCessao("Painel_SIACG", relatorio);
    }
    
    public void exportarSituacaoContrato() {

	byte[] relatorio = this.contratoService.getRelatorioSituacaoContrato(filtro.getTotalSituacaoContratos());

	this.inserirRelatorioCessao("Situação_dos_Contratos", relatorio);
    }

    /**
     * <p>
     * Método responsável por inserir o relatório informado na cessão.
     * </p>
     *
     * @author f734546
     *
     * @param nomeRelatorio
     * @param relatorio
     */
    private void inserirRelatorioCessao(final String nomeRelatorio, final byte[] relatorio) {

	try {

	    UtilRelatorio.getInstancia().adicionarArquivoCessao(relatorio, nomeRelatorio, EnumExtensaoArquivo.CSV.getExtensao());

	} catch (final Exception e) {
	    LogCefUtil.error("Nao foi possivel gerar o relatorio " + nomeRelatorio + ": " + e.getMessage());
	    LogCefUtil.error(e);
	}
    }

    private void carregarPaineis() {

	buscarSegmentos();
	buscarStatus();
	buscarSituacaoContrato();
	buscarCaracteristicaContrato();
	setGarantiaAcompanhada(contratoService.contaContratosAcompanhadas());
	setGarantiaNaoAcompanhada(contratoService.contaContratosNaoAcompanhadas());
	setNovosContratos(contratoService.contaNovosContratos());
    }

    private void buscarSegmentos() {
	setSegmentos(segmentoService.listarSegmentos());
	for (Segmento segmento : getSegmentos()) {
	    Long contador = contratoService.contaContratosSegmento(segmento.getNuSegmento());
	    segmento.setContadorPainel(contador);

	    if (contador > 0) {
		this.getFiltro().setDesabilitaSegmentos(false);
	    }
	}

    }

    private void buscarStatus() {
	getStatusGarantia().clear();

	final Long contadorInsuficiente = contratoService.contaContratosStatus(StatusGarantiaSuficienteEnum.INSUFICIENTE);
	final Long contadorSuficiente = contratoService.contaContratosStatus(StatusGarantiaSuficienteEnum.SUFICIENTE);
	final Long contadorTratEspecial = contratoService.contaContratosStatus(StatusGarantiaSuficienteEnum.TRATAMENTO_ESPECIAL);

	getStatusGarantia().add(new PainelComportamentoVO(StatusGarantiaSuficienteEnum.INSUFICIENTE.getDescricao(), contadorInsuficiente));
	getStatusGarantia().add(new PainelComportamentoVO(StatusGarantiaSuficienteEnum.SUFICIENTE.getDescricao(), contadorSuficiente));
	getStatusGarantia().add(new PainelComportamentoVO(StatusGarantiaSuficienteEnum.TRATAMENTO_ESPECIAL.getDescricao(), contadorTratEspecial));

	this.getFiltro().setDesabilitaStatusContratos(contadorInsuficiente == 0 && contadorSuficiente == 0 && contadorTratEspecial == 0);
    }

    private void buscarSituacaoContrato() {
	getSituacaoContrato().clear();

	final Long contadorAberto = contratoService.contaContratoPorSituacao(SituacaoEnum.ABERTO.getValor());
	final Long contadorAtrasado = contratoService.contaContratoPorSituacao(SituacaoEnum.ATRASADO.getValor());
	final Long contadorFechado = contratoService.contaContratoPorSituacao(SituacaoEnum.FECHADO.getValor());
	final Long contadorCancelado = contratoService.contaContratoPorSituacao(SituacaoEnum.CANCELADO.getValor());
	final Long contadorPreAnalise = contratoService.contaContratoPorSituacao(SituacaoEnum.PRE_ANALISE.getValor());
	final Long contadorAtraso = contratoService.contaContratoPorSituacao(SituacaoEnum.CREDITO_EM_ATRASO.getValor());
	final Long contadorDesabilitado = contratoService.contaContratoPorSituacao(SituacaoEnum.DESABILITADO_POR_ROTINA.getValor());

	getSituacaoContrato().add(new PainelComportamentoVO("Aberto", contadorAberto));
	getSituacaoContrato().add(new PainelComportamentoVO("Atrasado", contadorAtrasado));
	getSituacaoContrato().add(new PainelComportamentoVO("Fechado", contadorFechado));
	getSituacaoContrato().add(new PainelComportamentoVO("Cancelado", contadorCancelado));
	getSituacaoContrato().add(new PainelComportamentoVO("Pré Análise", contadorPreAnalise));
	getSituacaoContrato().add(new PainelComportamentoVO("Crédito em Atraso", contadorAtraso));
	getSituacaoContrato().add(new PainelComportamentoVO("Contrato Desabilitado por Rotina Automatica", contadorDesabilitado));
	
	final Long totalSituacaoContratos = contadorAberto + contadorAtrasado + contadorFechado + contadorCancelado + contadorPreAnalise + contadorAtraso + contadorDesabilitado;
	this.getFiltro().setTotalSituacaoContratos(totalSituacaoContratos);
    }

    private void buscarCaracteristicaContrato() {
	getCaracteristicaContrato().clear();

	final Long contadorEstoque = contratoService.contaContratosCaracteristicas(CaracteristicaEnum.ESTOQUE.getValor());
	final Long contadorFluxo = contratoService.contaContratosCaracteristicas(CaracteristicaEnum.FLUXO.getValor());

	getCaracteristicaContrato().add(new PainelComportamentoVO(CaracteristicaEnum.ESTOQUE.getDescricao(), contadorEstoque));
	getCaracteristicaContrato().add(new PainelComportamentoVO(CaracteristicaEnum.FLUXO.getDescricao(), contadorFluxo));

	this.getFiltro().setDesabilitaCaracteristicasContratos(contadorEstoque == 0 && contadorFluxo == 0);
    }

    /*******************************************************************
     * GETTERS && SETTERS
     ******************************************************************/
    public String getRelatorioCaminho() {
	String retorno = propriedadeService.getValorPropriedade("relatorio.monitoramento", "relatorio").trim();
	String caminho = StringUtils.defaultIfEmpty(retorno.trim(), HTTP_RELATORIO);
	return caminho + EMBED_TRUE;
    }

    /**
     * <p>
     * Retorna o valor do atributo segmentos
     * </p>
     * .
     *
     * @return segmentos
     */
    public Collection<Segmento> getSegmentos() {
	if (segmentos == null) {
	    setSegmentos(new ArrayList<Segmento>());
	}

	return this.segmentos;
    }

    /**
     * <p>
     * Define o valor do atributo segmentos
     * </p>
     * .
     *
     * @param segmentos
     *            valor a ser atribuído
     */
    public void setSegmentos(Collection<Segmento> segmentos) {
	this.segmentos = segmentos;
    }

    /**
     * <p>
     * Retorna o valor do atributo statusGarantia
     * </p>
     * .
     *
     * @return statusGarantia
     */
    public List<PainelComportamentoVO> getStatusGarantia() {
	if (statusGarantia == null) {
	    setStatusGarantia(new ArrayList<PainelComportamentoVO>());
	}

	return this.statusGarantia;
    }

    /**
     * <p>
     * Define o valor do atributo statusGarantia
     * </p>
     * .
     *
     * @param statusGarantia
     *            valor a ser atribuído
     */
    public void setStatusGarantia(List<PainelComportamentoVO> statusGarantia) {
	this.statusGarantia = statusGarantia;
    }

    /**
     * <p>
     * Retorna o valor do atributo situacaoContrato
     * </p>
     * .
     *
     * @return situacaoContrato
     */
    public List<PainelComportamentoVO> getSituacaoContrato() {
	if (situacaoContrato == null) {
	    setSituacaoContrato(new ArrayList<PainelComportamentoVO>());
	}

	return this.situacaoContrato;
    }

    /**
     * <p>
     * Define o valor do atributo situacaoContrato
     * </p>
     * .
     *
     * @param situacaoContrato
     *            valor a ser atribuído
     */
    public void setSituacaoContrato(List<PainelComportamentoVO> situacaoContrato) {
	this.situacaoContrato = situacaoContrato;
    }

    /**
     * <p>
     * Retorna o valor do atributo cacteristicaContrato
     * </p>
     * .
     *
     * @return cacteristicaContrato
     */
    public List<PainelComportamentoVO> getCaracteristicaContrato() {
	if (caracteristicaContrato == null) {
	    setCaracteristicaContrato(new ArrayList<PainelComportamentoVO>());
	}

	return this.caracteristicaContrato;
    }

    /**
     * <p>
     * Define o valor do atributo cacteristicaContrato
     * </p>
     * .
     *
     * @param cacteristicaContrato
     *            valor a ser atribuído
     */
    public void setCaracteristicaContrato(List<PainelComportamentoVO> cacteristicaContrato) {
	this.caracteristicaContrato = cacteristicaContrato;
    }

    /**
     * <p>
     * Retorna o valor do atributo propriedadeService
     * </p>
     * .
     *
     * @return propriedadeService
     */
    public PropriedadeService getPropriedadeService() {
	return this.propriedadeService;
    }

    /**
     * <p>
     * Define o valor do atributo propriedadeService
     * </p>
     * .
     *
     * @param propriedadeService
     *            valor a ser atribuído
     */
    public void setPropriedadeService(PropriedadeService propriedadeService) {
	this.propriedadeService = propriedadeService;
    }

    /**
     * <p>
     * Retorna o valor do atributo garantiaAcompanhada
     * </p>
     * .
     *
     * @return garantiaAcompanhada
     */
    public Long getGarantiaAcompanhada() {
	return this.garantiaAcompanhada;
    }

    /**
     * <p>
     * Define o valor do atributo garantiaAcompanhada
     * </p>
     * .
     *
     * @param garantiaAcompanhada
     *            valor a ser atribuído
     */
    public void setGarantiaAcompanhada(Long garantiaAcompanhada) {
	this.garantiaAcompanhada = garantiaAcompanhada;
    }

    /**
     * <p>
     * Retorna o valor do atributo garantiaNaoAcompanhada
     * </p>
     * .
     *
     * @return garantiaNaoAcompanhada
     */
    public Long getGarantiaNaoAcompanhada() {
	return this.garantiaNaoAcompanhada;
    }

    /**
     * <p>
     * Define o valor do atributo garantiaNaoAcompanhada
     * </p>
     * .
     *
     * @param garantiaNaoAcompanhada
     *            valor a ser atribuído
     */
    public void setGarantiaNaoAcompanhada(Long garantiaNaoAcompanhada) {
	this.garantiaNaoAcompanhada = garantiaNaoAcompanhada;
    }

    /**
     * <p>
     * Retorna o valor do atributo novosContratos
     * </p>
     * .
     *
     * @return novosContratos
     */
    public Long getNovosContratos() {
	return this.novosContratos;
    }

    /**
     * <p>
     * Define o valor do atributo novosContratos
     * </p>
     * .
     *
     * @param novosContratos
     *            valor a ser atribuído
     */
    public void setNovosContratos(Long novosContratos) {
	this.novosContratos = novosContratos;
    }

    public int getUsuariosLogados() {
	return UsuarioOnlineSingleton.getQtdUsuarios();
    }

    /**
     * <p>
     * Retorna o valor do atributo filtro
     * </p>
     * .
     *
     * @return filtro
     */
    public FiltroPainelComportamentoVO getFiltro() {
	return this.filtro;
    }

    /**
     * <p>
     * Define o valor do atributo filtro
     * </p>
     * .
     *
     * @param filtro
     *            valor a ser atribuído
     */
    public void setFiltro(FiltroPainelComportamentoVO filtro) {
	this.filtro = filtro;
    }
}