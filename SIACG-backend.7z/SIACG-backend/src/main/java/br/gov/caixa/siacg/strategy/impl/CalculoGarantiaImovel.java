package br.gov.caixa.siacg.strategy.impl;

import java.math.BigDecimal;

import javax.ejb.Stateless;
//import javax.inject.Inject;

import br.gov.caixa.siacg.comum.to.GarantiaBemClienteCalculoTO;
import br.gov.caixa.siacg.model.vo.ParametrosCalculoGarantiaVO;
import br.gov.caixa.siacg.model.vo.RelatorioAnaliseContratoVO;
//import br.gov.caixa.siacg.service.GarantiaBemClienteService;
import br.gov.caixa.siacg.strategy.CalculoGarantia;

/**
 * <p>
 * CalculoGarantiaImovel
 * </p>
 * <p>
 * Descrição: Implementação do calculo para Garantia do tipo Garantia Imovel.
 * </p>
 * <br>
 * <b>Empresa:</b> Cef - Caixa Econômica Federal
 *
 * @author guilherme.santos
 * @version 1.0
 */
@Stateless(mappedName = "CalculoGarantiaImovel")
public class CalculoGarantiaImovel implements CalculoGarantia {

	private static final long serialVersionUID = 7170040531431287763L;
	
	/**
	 * @see br.gov.caixa.siacg.strategy.CalculoGarantia#calcular(br.gov.caixa.siacg.model.vo.ParametrosCalculoGarantiaVO)
	 */
	@Override
	public RelatorioAnaliseContratoVO calcular(final ParametrosCalculoGarantiaVO parametrosCalculo, RelatorioAnaliseContratoVO relatorio) {

		if (relatorio == null) {
			relatorio = new RelatorioAnaliseContratoVO();
		}

		if (parametrosCalculo == null || parametrosCalculo.getGarantiaContrato() == null) {
			relatorio.setValorApurado(BigDecimal.ZERO);
			relatorio.setValorAlienacaoImobiliaria(BigDecimal.ZERO);

			return relatorio;
		}
		
		BigDecimal valorUtilizado = parametrosCalculo.getGarantiaContrato().getListaGarantiaBemCliente().stream()
			.filter(bemCliente -> bemCliente != null && bemCliente.getVrUtilizado() != null)
			.map(GarantiaBemClienteCalculoTO::getVrUtilizado).reduce(BigDecimal.ZERO, BigDecimal::add);
		
		relatorio.setValorApurado(valorUtilizado);
		relatorio.setValorAlienacaoImobiliaria(relatorio.getValorAlienacaoImobiliaria().add(valorUtilizado));

		return relatorio;
	}
}