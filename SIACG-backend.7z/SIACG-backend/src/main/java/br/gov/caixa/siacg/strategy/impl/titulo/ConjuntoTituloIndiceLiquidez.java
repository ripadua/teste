/**
 * Copyright (c) 2018 Caixa Econômica Federal. Todos os direitos
 * reservados.
 *
 * Caixa Econômica Federal - SIACG
 *
 * Este software foi desenvolvido sob demanda da CAIXA e está
 * protegido por leis de direitos autorais e tratados internacionais. As
 * condições de cópia e utilização total ou partes dependem de autorização da
 * empresa. Cópias não são permitidas sem expressa autorização. Não pode ser
 * comercializado ou utilizado para propósitos particulares.
 *
 * Uso exclusivo da Caixa Econômica Federal. A reprodução ou distribuição não
 * autorizada deste programa ou de parte dele, resultará em punições civis e
 * criminais e os infratores incorrem em sanções previstas na legislação em
 * vigor.
 *
 * Histórico do TFS:
 *
 * LastChangedRevision: $Revision$
 * LastChangedBy: $Author$
 * LastChangedDate: $Date$
 *
 * HeadURL: $HeadURL$
 *
 */	
package br.gov.caixa.siacg.strategy.impl.titulo;

import java.math.BigDecimal;
import java.math.RoundingMode;

import br.gov.caixa.siacg.model.domain.Titulo;

/**
 * <p>ConjuntoTituloIndiceLiquidez</p>
 *
 * <p>Descrição: Classe que representa o conjunto de titulos para calculo de indice de liquidez</p>
 *
 * <br><b>Empresa:</b> Cef - Caixa Econômica Federal
 *
 *
 * @author p541915
 *
 * @version 1.0
*/
public class ConjuntoTituloIndiceLiquidez extends ConjuntoTitulo {
	
	/** Atributo vrTitulosLiquidados. */
	private BigDecimal vrTitulosLiquidados = BigDecimal.ZERO;
	
	/**
	 * @see br.gov.caixa.siacg.strategy.impl.titulo.ConjuntoTitulo#adicionarTitulo(br.gov.caixa.siacg.model.domain.Titulo)
	*/
	@Override
	public void adicionarTitulo(Titulo titulo) {
		super.adicionarTitulo(titulo);
		
		if (titulo.isTituloLiquidado()) {
			this.vrTitulosLiquidados = this.vrTitulosLiquidados.add(titulo.getVrTitulo());
		}
	}
	
	/**
	 * <p>Método responsável por calcular o indice de liquidez</p>.
	 *
	 * @author p541915
	 *
	 * @return
	 */
	public Double calcularIndiceLiquidez() {
		
		BigDecimal percentualLiquidez = BigDecimal.ZERO;
		// Calcula percentual de liquidez
        if (this.getVrTotal().compareTo(BigDecimal.ZERO) > 0) {
            percentualLiquidez = this.vrTitulosLiquidados.divide(this.getVrTotal(), 2, RoundingMode.HALF_DOWN);
            if (percentualLiquidez.compareTo(BigDecimal.ZERO) > 0) {
                percentualLiquidez = percentualLiquidez.multiply(BigDecimal.valueOf(100));
            }
        }

        return percentualLiquidez.doubleValue();
	}

}
