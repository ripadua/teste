package br.gov.caixa.siacg.util;

import java.util.AbstractList;
import java.util.List;

/**
 * <p>
 * PartitionList
 * </p>
 *
 * <p>
 * Descrição: Util PartitionList
 * </p>
 *
 * <br>
 * <b>Empresa:</b> Cef - Caixa Econômica Federal
 *
 * @param <T>
 *
 * @author f575368
 *
 * @version 1.0
 */
public final class PartitionListUtil<T> extends AbstractList<List<T>> {

    final List<T> list;

    final int size;

    public PartitionListUtil(final List<T> list, final int size) {
	this.list = list;
	this.size = size;
    }

    @Override
    public List<T> get(final int index) {
	final int listSize = size();
	if (listSize < 0) {
	    throw new IllegalArgumentException("negative size: " + listSize);
	}
	if (index < 0) {
	    throw new IndexOutOfBoundsException("index " + index + " must not be negative");
	}
	if (index >= listSize) {
	    throw new IndexOutOfBoundsException("index " + index + " must be less than size " + listSize);
	}
	final int start = index * size;
	final int end = Math.min(start + size, list.size());
	return list.subList(start, end);
    }

    @Override
    public int size() {
	return (list.size() + size - 1) / size;
    }

    @Override
    public boolean isEmpty() {
	return list.isEmpty();
    }

    public static <T> List<List<T>> of(final List<T> list, final int size) {
	if (list == null) {
	    throw new NullPointerException("'list' must not be null");
	}
	if (!(size > 0)) {
	    throw new IllegalArgumentException("'size' must be greater than 0");
	}

	return new PartitionListUtil<>(list, size);
    }
}
