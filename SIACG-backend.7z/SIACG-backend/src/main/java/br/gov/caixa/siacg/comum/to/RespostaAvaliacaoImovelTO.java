package br.gov.caixa.siacg.comum.to;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

@JsonIgnoreProperties(ignoreUnknown = true)
public class RespostaAvaliacaoImovelTO {

	@JsonProperty(value="avaliacoes")
	@JsonIgnoreProperties(ignoreUnknown = true)
	private RespostaAvaliacaoTO avaliacao;

	@JsonIgnoreProperties(ignoreUnknown = true)
	@JsonProperty(value="avaliacao")
	private AvaliacaoTO avaliacaoDetalhada;
	
	public RespostaAvaliacaoTO getAvaliacao() {
		return avaliacao;
	}

	public void setAvaliacao(RespostaAvaliacaoTO avaliacao) {
		this.avaliacao = avaliacao;
	}

	public AvaliacaoTO getAvaliacaoDetalhada() {
		return avaliacaoDetalhada;
	}

	public void setAvaliacaoDetalhada(AvaliacaoTO avaliacaoDetalhada) {
		this.avaliacaoDetalhada = avaliacaoDetalhada;
	}

}
