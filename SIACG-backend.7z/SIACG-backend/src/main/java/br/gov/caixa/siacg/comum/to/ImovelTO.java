package br.gov.caixa.siacg.comum.to;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public class ImovelTO implements Comparable<ImovelTO>{

	private Integer codigoImovel;
	private Integer matricula;
	private String livro;
	private Integer cartorio;
	
	public ImovelTO() {
		super();
	}

	public Integer getCodigoImovel() {
		return codigoImovel;
	}
	public void setCodigoImovel(Integer codigoImovel) {
		this.codigoImovel = codigoImovel;
	}
	public Integer getMatricula() {
		return matricula;
	}
	public void setMatricula(Integer matricula) {
		this.matricula = matricula;
	}
	public String getLivro() {
		return livro;
	}
	public void setLivro(String livro) {
		this.livro = livro;
	}
	public Integer getCartorio() {
		return cartorio;
	}
	public void setCartorio(Integer cartorio) {
		this.cartorio = cartorio;
	}

	@Override
	public int compareTo(ImovelTO o) {
		return o.getCodigoImovel().compareTo(this.codigoImovel);
	}
	
	
}
