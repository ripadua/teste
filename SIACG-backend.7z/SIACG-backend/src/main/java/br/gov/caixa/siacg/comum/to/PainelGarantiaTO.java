/*
 * Copyright (c) 2016 Caixa Econômica Federal. Todos os direitos
 * reservados.
 *
 * Caixa Econômica Federal - SIACG_dev
 *
 * Este software foi desenvolvido sob demanda da CAIXA e está
 * protegido por leis de direitos autorais e tratados internacionais. As
 * condições de cópia e utilização do total ou partes dependem de autorização da
 * pessoa. Cópias não são permitidas sem expressa autorização. Não pode ser
 * comercializado ou utilizado para propósitos particulares.
 *
 * Uso exclusivo da Caixa Econômica Federal. A reprodução ou distribuição não
 * autorizada deste programa ou de parte dele, resultará em punições civis e
 * criminais e os infratores incorrem em sanções previstas na legislação em
 * vigor.
 *
 * Histórico do Subversion:
 *
 * LastChangedRevision: $Revision$
 * LastChangedBy: $Author$
 * LastChangedDate: $Date$
 *
 * HeadURL: $HeadURL$
 *
 */
package br.gov.caixa.siacg.comum.to;

import java.io.Serializable;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import br.gov.caixa.pedesgo.arquitetura.util.UtilObjeto;
import br.gov.caixa.siacg.util.ContratoUtil;
import br.gov.caixa.siacg.util.LogCEF;

/**
 * <p>
 * PainelGarantiaTO.
 * </p>
 * <p>
 * Descrição: TO para painel garantia.
 * </p>
 * <br>
 * <b>Empresa:</b> Cef - Caixa Econômica Federal
 *
 * @author Bruno Martins de Carvalho
 * @version 1.0
 */
public class PainelGarantiaTO implements Serializable{

    /** Atributo serialVersionUID. */
    private static final long serialVersionUID = 7431223276661388549L;
    /** Atributo CEM. */
    private static final int CEM = 100;

    /** coIdentificador. */
    private String coIdentificador;

    /** noIdentificador. */
    private String noIdentificador;

    /** nuIdentificadorContrato. */
    private Integer nuIdentificadorContrato;

    /** coIdentificadorContrato. */
    private String coIdentificadorContrato;

    /** nuOperacao. */
    private Integer nuOperacao;

    /** qtContrato. */
    private Integer qtContrato;

    /** qtContratoTotal. */
    private Integer qtContratoTotal;

    /** vrContrato. */
    private BigDecimal vrContrato;

    /** vrTotalConstituido. */
    private BigDecimal vrTotalConstituido;

    /** pcContrato. */
    private BigDecimal pcContrato;

    /** dtContrato. */
    private Date dtContrato;

    /** segmentoList. */
    private List<String> segmentoList;

    /** Atributo nu unidade. */
    private String nuUnidade;

    /** Atributo nu sr. */
    private String nuSr;

    /** Atributo nu suat. */
    private String nuSuat;

    /* Atributos para relatório */

    /**
     * Construtor.
     *
     */
    public PainelGarantiaTO() {

    }

    /**
     * Construtor.
     *
     * @param coIdentificador
     *            valor a ser atribuido
     * @param noIdentificador
     *            valor a ser atribuido
     * @param qtdeContrato
     *            valor a ser atribuido
     * @param qtdeContratoTotal
     *            valor a ser atribuido
     */
    public PainelGarantiaTO(final String coIdentificador, final String noIdentificador, final Long qtdeContrato, final Long qtdeContratoTotal) {
        this.coIdentificador = coIdentificador;
        this.noIdentificador = noIdentificador;
        this.qtContrato = qtdeContrato.intValue();
        this.qtContratoTotal = qtdeContratoTotal.intValue();
    }

    /**
     * Construtor.
     *
     * @param coIdentificador
     *            valor a ser atribuido
     * @param noIdentificador
     *            valor a ser atribuido
     * @param qtdeContrato
     *            valor a ser atribuido
     * @param vrContratoConstituido
     *            valor a ser atribuido
     * @param vrTotalConstituido
     *            valor a ser atribuido
     */
    public PainelGarantiaTO(final String coIdentificador, final String noIdentificador, final Long qtdeContrato,
            final BigDecimal vrContratoConstituido, final BigDecimal vrTotalConstituido) {
        this.coIdentificador = coIdentificador;
        this.noIdentificador = noIdentificador;
        this.qtContrato = qtdeContrato.intValue();
        this.vrContrato = vrContratoConstituido;
        this.vrTotalConstituido = vrTotalConstituido;
    }

    /**
     * Construtor.
     *
     * @param nuIdentificadorContrato
     *            valor a ser atribuido
     * @param coIdentificadorContrato
     *            valor a ser atribuido
     * @param nuOperacao
     *            valor a ser atribuido
     * @param qtdeContrato
     *            valor a ser atribuido
     * @param vrContratoConstituido
     *            valor a ser atribuido
     * @param vrTotalConstituido
     *            valor a ser atribuido
     */
    public PainelGarantiaTO(final Integer nuIdentificadorContrato, final String coIdentificadorContrato, final Integer nuOperacao,
            final Long qtdeContrato, final BigDecimal vrContratoConstituido, final BigDecimal vrTotalConstituido) {
        this.nuIdentificadorContrato = nuIdentificadorContrato;
        this.coIdentificadorContrato = coIdentificadorContrato;
        this.nuOperacao = nuOperacao;
        this.qtContrato = qtdeContrato.intValue();
        this.vrContrato = vrContratoConstituido;
        this.vrTotalConstituido = vrTotalConstituido;
    }

    /**
     * Construtor.
     *
     * @param nuIdentificadorContrato
     *            valor a ser atribuido
     * @param coIdentificadorContrato
     *            valor a ser atribuido
     * @param vrContrato
     *            valor a ser atribuido
     * @param dtContrato
     *            valor a ser atribuido
     * @param nuoperacao
     *            valor a ser atribuido
     * @param qtdeContrato
     *            valor a ser atribuido
     * @param qtdeContratoTotal
     *            valor a ser atribuido
     */
    public PainelGarantiaTO(final Integer nuIdentificadorContrato, final String coIdentificadorContrato, final BigDecimal vrContrato,
            final Date dtContrato, final Integer nuoperacao, final Long qtdeContrato, final Long qtdeContratoTotal) {
        this.nuIdentificadorContrato = nuIdentificadorContrato;
        this.coIdentificadorContrato = coIdentificadorContrato;
        this.vrContrato = vrContrato;
        this.dtContrato = dtContrato;
        this.nuOperacao = nuoperacao;
        this.qtContrato = qtdeContrato.intValue();
        this.qtContratoTotal = qtdeContratoTotal.intValue();
    }

    /**
     * Construtor.
     *
     * @param noIdentificador
     *            valor a ser atribuido
     */
    public PainelGarantiaTO(final String noIdentificador) {
        this.noIdentificador = noIdentificador;
    }

    /**
     * <p>
     * Método responsável por formatar e retornar o número do contrato.
     * <p>
     *
     * @return coIdentificadorContrato
     * @author Bruno Martins de Carvalho
     */
    public String getNoIdentificadorContrato() {
	if (UtilObjeto.isReferencia(this.coIdentificadorContrato) && UtilObjeto.isReferencia(this.nuOperacao)
                && this.coIdentificadorContrato.length() >= 4) {
	    	this.coIdentificadorContrato = ContratoUtil.formatarContratoComMascaraSessao(this.nuOperacao, this.coIdentificadorContrato);
        }
        return this.coIdentificadorContrato;

    }

    /**
     * Retorna o valor do atributo percentual.
     *
     * @return percentual
     */
    public BigDecimal getPcContrato() {
        this.pcContrato = BigDecimal.ZERO;

        if (UtilObjeto.isReferencia(this.qtContrato) && UtilObjeto.isReferencia(this.qtContratoTotal) && this.qtContratoTotal != 0) {
            try {
                final BigDecimal valor = new BigDecimal(this.qtContrato);
                final BigDecimal valorTotal = new BigDecimal(this.qtContratoTotal);
                this.pcContrato = valor.multiply(BigDecimal.valueOf(PainelGarantiaTO.CEM)).divide(valorTotal, 2, RoundingMode.HALF_UP).abs();

            } catch (final ArithmeticException e) {
        	LogCEF.error(e);
            }
        }
        return this.pcContrato;
    }

    /**
     * Define o valor do atributo percentual.
     *
     * @param pcContrato
     *            valor a ser atribuído
     */
    public void setPcContrato(final BigDecimal pcContrato) {
        this.pcContrato = pcContrato;
    }

    /**
     * <p>
     * Método responsável por reduzir o tamanho da label de identificação da
     * 'Suat', 'Sr' ou 'Unidade'.
     * <p>
     *
     * @return String
     * @author Bruno Martins de Carvalho
     */
    public String getNoIdentificadorReduzido() {
        if (UtilObjeto.isReferencia(this.noIdentificador) && this.noIdentificador.trim().length() >= 15) {
            return this.noIdentificador.substring(0, 14) + "...";
        }

        return this.noIdentificador;
    }

    /**
     * Retorna o valor do atributo nuSegmento.
     *
     * @return nuSegmento
     */
    public List<String> getSegmentoList() {
        if (!UtilObjeto.isReferencia(this.segmentoList)) {
            this.segmentoList = new ArrayList<>();
        }
        return this.segmentoList;
    }

    /**
     * Define o valor do atributo nuSegmento.
     *
     * @param segmentoList
     *            valor a ser atribuído
     */
    public void setSegmentoList(final List<String> segmentoList) {
        this.segmentoList = segmentoList;
    }

    /**
     * Retorna o valor do atributo coIdentificadorContrato.
     *
     * @return coIdentificadorContrato
     */
    public String getCoIdentificadorContrato() {
        return this.coIdentificadorContrato;
    }

    /**
     * Define o valor do atributo coIdentificadorContrato.
     *
     * @param coIdentificadorContrato
     *            valor a ser atribuído
     */
    public void setCoIdentificadorContrato(final String coIdentificadorContrato) {
        this.coIdentificadorContrato = coIdentificadorContrato;
    }

    /**
     * Retorna o valor do atributo nuIdentificadorContrato.
     *
     * @return nuIdentificadorContrato
     */
    public Integer getNuIdentificadorContrato() {
        return this.nuIdentificadorContrato;
    }

    /**
     * Retorna o valor do atributo nuOperacao.
     *
     * @return nuOperacao
     */
    public Integer getNuOperacao() {
        return this.nuOperacao;
    }

    /**
     * Define o valor do atributo nuIdentificadorContrato.
     *
     * @param nuIdentificadorContrato
     *            valor a ser atribuído
     */
    public void setNuIdentificadorContrato(final Integer nuIdentificadorContrato) {
        this.nuIdentificadorContrato = nuIdentificadorContrato;
    }

    /**
     * Define o valor do atributo nuOperacao.
     *
     * @param nuOperacao
     *            valor a ser atribuído
     */
    public void setNuOperacao(final Integer nuOperacao) {
        this.nuOperacao = nuOperacao;
    }

    /**
     * Retorna o valor do atributo coIdentificador.
     *
     * @return coIdentificador
     */
    public String getCoIdentificador() {
        return this.coIdentificador;
    }

    /**
     * Retorna o valor do atributo noIdentificador.
     *
     * @return noIdentificador
     */
    public String getNoIdentificador() {
        return this.noIdentificador;
    }

    /**
     * Retorna o valor do atributo qtContrato.
     *
     * @return qtContrato
     */
    public Integer getQtContrato() {
        return this.qtContrato;
    }

    /**
     * Retorna o valor do atributo qtContratoTotal.
     *
     * @return qtContratoTotal
     */
    public Integer getQtContratoTotal() {
        if (!UtilObjeto.isReferencia(this.qtContratoTotal)) {
            this.qtContratoTotal = 0;
        }
        return this.qtContratoTotal;
    }

    /**
     * Retorna o valor do atributo vrContrato.
     *
     * @return vrContrato
     */
    public BigDecimal getVrContrato() {
        return this.vrContrato;
    }

    /**
     * Retorna o valor do atributo nuUnidade.
     *
     * @return nuUnidade
     */
    public String getNuUnidade() {
        return this.nuUnidade;
    }

    /**
     * Retorna o valor do atributo nuSr.
     *
     * @return nuSr
     */
    public String getNuSr() {
        return this.nuSr;
    }

    /**
     * Retorna o valor do atributo nuSuat.
     *
     * @return nuSuat
     */
    public String getNuSuat() {
        return this.nuSuat;
    }

    /**
     * Define o valor do atributo coIdentificador.
     *
     * @param coIdentificador
     *            valor a ser atribuído
     */
    public void setCoIdentificador(final String coIdentificador) {
        this.coIdentificador = coIdentificador;
    }

    /**
     * Define o valor do atributo noIdentificador.
     *
     * @param noIdentificador
     *            valor a ser atribuído
     */
    public void setNoIdentificador(final String noIdentificador) {
        this.noIdentificador = noIdentificador;
    }

    /**
     * Define o valor do atributo qtContrato.
     *
     * @param qtContrato
     *            valor a ser atribuído
     */
    public void setQtContrato(final Integer qtContrato) {
        this.qtContrato = qtContrato;
    }

    /**
     * Define o valor do atributo qtContratoTotal.
     *
     * @param qtContratoTotal
     *            valor a ser atribuído
     */
    public void setQtContratoTotal(final Integer qtContratoTotal) {
        this.qtContratoTotal = qtContratoTotal;
    }

    /**
     * Define o valor do atributo vrContrato.
     *
     * @param vrContrato
     *            valor a ser atribuído
     */
    public void setVrContrato(final BigDecimal vrContrato) {
        this.vrContrato = vrContrato;
    }

    /**
     * Define o valor do atributo nuUnidade.
     *
     * @param nuUnidade
     *            valor a ser atribuído
     */
    public void setNuUnidade(final String nuUnidade) {
        this.nuUnidade = nuUnidade;
    }

    /**
     * Define o valor do atributo nuSr.
     *
     * @param nuSr
     *            valor a ser atribuído
     */
    public void setNuSr(final String nuSr) {
        this.nuSr = nuSr;
    }

    /**
     * Define o valor do atributo nuSuat.
     *
     * @param nuSuat
     *            valor a ser atribuído
     */
    public void setNuSuat(final String nuSuat) {
        this.nuSuat = nuSuat;
    }

    /**
     * Retorna o valor do atributo dtContrato.
     *
     * @return dtContrato
     */
    public Date getDtContrato() {
        return this.dtContrato;
    }

    /**
     * Define o valor do atributo dtContrato.
     *
     * @param dtContrato
     *            valor a ser atribuído
     */
    public void setDtContrato(final Date dtContrato) {
        this.dtContrato = dtContrato;
    }

    /**
     * Retorna o valor do atributo vrTotalConstituido.
     *
     * @return vrTotalConstituido
     */
    public BigDecimal getVrTotalConstituido() {
        return this.vrTotalConstituido;
    }

    /**
     * Define o valor do atributo vrTotalConstituido.
     *
     * @param vrTotalConstituido
     *            valor a ser atribuído
     */
    public void setVrTotalConstituido(final BigDecimal vrTotalConstituido) {
        this.vrTotalConstituido = vrTotalConstituido;
    }

    /**
     * Retorna o valor do atributo percentual.
     *
     * @return percentual
     */
    public BigDecimal getPcConstituido() {
        this.pcContrato = BigDecimal.ZERO;

        if (UtilObjeto.isReferencia(this.vrContrato) && UtilObjeto.isReferencia(this.vrTotalConstituido)
                && this.vrTotalConstituido.compareTo(BigDecimal.ZERO) != 0) {
            try {
                this.pcContrato = this.vrContrato.multiply(BigDecimal.valueOf(PainelGarantiaTO.CEM))
                        .divide(this.vrTotalConstituido, 2, RoundingMode.HALF_UP).abs();

            } catch (final ArithmeticException e) {
                LogCEF.error(e);
            }
        }
        return this.pcContrato;
    }

}
