/*
 * Copyright (c) 2016 Caixa Econômica Federal. Todos os direitos
 * reservados.
 *
 * Caixa Econômica Federal - SIACG_dev
 *
 * Este software foi desenvolvido sob demanda da CAIXA e está
 * protegido por leis de direitos autorais e tratados internacionais. As
 * condições de cópia e utilização do todo ou partes dependem de autorização da
 * pessoa. Cópias não são permitidas sem expressa autorização. Não pode ser
 * comercializado ou utilizado para propósitos particulares.
 *
 * Uso exclusivo da Caixa Econômica Federal. A reprodução ou distribuição não
 * autorizada deste programa ou de parte dele, resultará em punições civis e
 * criminais e os infratores incorrem em sanções previstas na legislação em
 * vigor.
 *
 * Histórico do Subversion:
 *
 * LastChangedRevision: $Revision$
 * LastChangedBy: $Author$
 * LastChangedDate: $Date$
 *
 * HeadURL: $HeadURL$
 *
 */
package br.gov.caixa.siacg.comum.to;

import java.math.BigDecimal;

/**
 * <p>
 * retornoWebserviceSaldoTO.
 * </p>
 * <p>
 * Descrição: TO para representar o retorno das operações com o webservice de Saldos (bloqueio, desbloqueio e consulta).
 * </p>
 * <br>
 * <b>Empresa:</b> Cef - Caixa Econômica Federal
 *
 * @author Leandro Severino - lseverino@gmail.com
 * @version 1.0
 */
public class RetornoWebserviceSaldoTO {

    /** sistemaSolicitado. */
    private String sistemaSolicitado;

    /** saldo. */
    private String saldo;

    /** coGarantia. */
    private String coGarantia;
    
    /** valorOperacao. */
    private BigDecimal valorOperacao;

    /**
     * Construtor.
     *
     */
    public RetornoWebserviceSaldoTO() {

    }

    /**
     * Construtor.
     *
     * @param sistemaSolicitado
     *            valor a ser atribuido
     * @param saldo
     *            valor a ser atribuido
     * @param coGarantia
     *            valor a ser atribuido
     * @param valorOperacao
     *            valor a ser atribuido
     */
    public RetornoWebserviceSaldoTO(final String sistemaSolicitado, final String saldo, final String coGarantia, final BigDecimal valorOperacao) {
        this.sistemaSolicitado = sistemaSolicitado;
        this.saldo = saldo;
        this.coGarantia = coGarantia;
        this.valorOperacao = valorOperacao;
    }
    
    /**
     * Retorna o valor do atributo sistemaSolicitado.
     *
     * @return sistemaSolicitado
     */
    public String getSistemaSolicitado() {
        return this.sistemaSolicitado;
    }

    /**
     * Define o valor do atributo sistemaSolicitado.
     *
     * @param sistemaSolicitado
     *            valor a ser atribuído
     */
    public void setSistemaSolicitado(final String sistemaSolicitado) {
        this.sistemaSolicitado = sistemaSolicitado;
    }

    /**
     * Retorna o valor do atributo saldo.
     *
     * @return saldo
     */
    public String getSaldo() {
        return this.saldo;
    }

    /**
     * Define o valor do atributo saldo.
     *
     * @param saldo
     *            valor a ser atribuído
     */
    public void setSaldo(final String saldo) {
        this.saldo = saldo;
    }
    
    /**
     * Retorna o valor do atributo coGarantia.
     *
     * @return coGarantia
     */
    public String getCoGarantia() {
        return this.coGarantia;
    }

    /**
     * Define o valor do atributo coGarantia.
     *
     * @param coGarantia
     *            valor a ser atribuído
     */
    public void setCoGarantia(final String coGarantia) {
        this.coGarantia = coGarantia;
    }

    /**
     * Retorna o valor do atributo valorOperacao.
     *
     * @return valorOperacao
     */
	public BigDecimal getValorOperacao() {
		return valorOperacao;
	}

	/**
     * Define o valor do atributo valorOperacao.
     *
     * @param valorOperacao
     *            valor a ser atribuído
     */
	public void setValorOperacao(BigDecimal valorOperacao) {
		this.valorOperacao = valorOperacao;
	}
    
}
