/*
 * Copyright (c) 2019 Caixa Econômica Federal. Todos os direitos
 * reservados.
 *
 * Caixa Econômica Federal - SIACG - Sistema de Crédito Rural
 *
 * Este software foi desenvolvido sob demanda da CAIXA e está
 * protegido por leis de direitos autorais e tratados internacionais. As
 * condições de cópia e utilização do todo ou partes dependem de autorização da
 * empresa. Cópias não são permitidas sem expressa autorização. Não pode ser
 * comercializado ou utilizado para propósitos particulares.
 *
 * Uso exclusivo da Caixa Econômica Federal. A reprodução ou distribuição não
 * autorizada deste programa ou de parte dele, resultará em punições civis e
 * criminais e os infratores incorrem em sanções previstas na legislação em
 * vigor.
 *
 * Histórico do TFS:
 *
 * LastChangedRevision: $Revision$
 * LastChangedBy: $Author$
 * LastChangedDate: $Date$
 *
 * HeadURL: $HeadURL$
 *
 */
package br.gov.caixa.siacg.view.mb;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.function.Consumer;

import javax.faces.bean.ManagedBean;
import javax.faces.bean.ManagedProperty;
import javax.faces.bean.SessionScoped;
import javax.inject.Inject;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.primefaces.context.RequestContext;

import br.gov.caixa.pedesgo.arquitetura.controlador.ManutencaoBean;
import br.gov.caixa.pedesgo.arquitetura.siico.dao.EnderecoDao;
import br.gov.caixa.pedesgo.arquitetura.siico.model.dto.EnderecoDTO;
import br.gov.caixa.pedesgo.arquitetura.siico.util.LogCefUtil;
import br.gov.caixa.pedesgo.arquitetura.util.MensagensUtil;
import br.gov.caixa.pedesgo.arquitetura.util.UtilCnpj;
import br.gov.caixa.pedesgo.arquitetura.util.UtilObjeto;
import br.gov.caixa.pedesgo.arquitetura.util.UtilString;
import br.gov.caixa.siacg.commons.AppConstant;
import br.gov.caixa.siacg.commons.MsgConstant;
import br.gov.caixa.siacg.comum.to.AvaliacaoTO;
import br.gov.caixa.siacg.comum.to.RespostaAvaliacaoImovelTO;
import br.gov.caixa.siacg.comum.to.RespostaLaudoEngenhariaTO;
import br.gov.caixa.siacg.dao.CategoriaImovelDAO;
import br.gov.caixa.siacg.dao.TipoLogradouroImovelDAO;
import br.gov.caixa.siacg.dao.TipoUsoImovelDAO;
import br.gov.caixa.siacg.exception.ParametrosInvalidosException;
import br.gov.caixa.siacg.jms.SolicitarDadosSifecVeiculos;
import br.gov.caixa.siacg.model.domain.BemCliente;
import br.gov.caixa.siacg.model.domain.Contrato;
import br.gov.caixa.siacg.model.domain.GestaoServentia;
import br.gov.caixa.siacg.model.domain.Imovel;
import br.gov.caixa.siacg.model.domain.MaquinaEquipamento;
import br.gov.caixa.siacg.model.domain.PapelProprietario;
import br.gov.caixa.siacg.model.domain.Pessoa;
import br.gov.caixa.siacg.model.domain.ProprietarioImovel;
import br.gov.caixa.siacg.model.domain.Veiculo;
import br.gov.caixa.siacg.model.enums.OrigemEnum;
import br.gov.caixa.siacg.model.enums.TipoBemEnum;
import br.gov.caixa.siacg.pagination.BemClienteLazyModel;
import br.gov.caixa.siacg.service.BemClienteService;
import br.gov.caixa.siacg.service.ContratoService;
import br.gov.caixa.siacg.service.GarantiaBemClienteService;
import br.gov.caixa.siacg.service.GestaoServentiaService;
import br.gov.caixa.siacg.service.ImovelService;
import br.gov.caixa.siacg.service.PapelProprietarioService;
import br.gov.caixa.siacg.service.PessoaService;
import br.gov.caixa.siacg.util.LogCEF;
import br.gov.caixa.siacg.util.NumeroUtil;
import br.gov.caixa.siacg.view.form.BemClienteVisao;
import br.gov.caixa.siacg.webservice.AvaliacaoImovelWS;

/**
 * <p>
 * BemClienteMB
 * </p>
 * <p>
 * Descrição: Managed bean do caso de uso de Bem do Cliente.
 * </p>
 * <br>
 * <b>Empresa:</b> Cef - Caixa Econômica Federal
 *
 * @author narcieliton.lopes
 * @author ludemeula.sa
 * @version 1.0
 */
@ManagedBean
@SessionScoped
public class BemClienteMB extends ManutencaoBean<BemCliente> {

    private static final long serialVersionUID = 1133316313004308593L;

    private static final String PAGINA_CONSULTA = "/pages/bemCliente/consulta.xhtml?faces-redirect=true";
    private static final String PAGINA_INCLUSAO = "/pages/bemCliente/edicao.xhtml?faces-redirect=true";
    private static final String NOME_MANAGED_BEAN = "bemClienteMB";

    @Inject
    private BemClienteService service;

    @Inject
    private GarantiaBemClienteService garantiaBemClienteService;

    @Inject
    private GestaoServentiaService gestaoServentiaService;

    @Inject
    private TipoLogradouroImovelDAO tipoLogradouroDAO;

    @Inject
    private TipoUsoImovelDAO tipoUsoDAO;

    @Inject
    private CategoriaImovelDAO tipoCategoriaDAO;

    @Inject
    private PessoaService pessoaService;

    @Inject
    private ContratoService contratoService;

    @Inject
    private EnderecoDao enderecoDao;

    @Inject
    private SolicitarDadosSifecVeiculos sifecVeiculos;

    @Inject
    private ImovelService imovelService;

    private BemClienteVisao visao;

    /** Atributo de Consulta */
    @ManagedProperty(value = BemClienteLazyModel.EL_MANAGED_BEAN)
    private BemClienteLazyModel consulta;

    @Inject
    private AvaliacaoImovelWS avaliacaoImovelWS;

    @Inject
    private PapelProprietarioService papelProprietarioService;

    /**
     * <p>
     * Método responsável por abrir a tela de consutla do sacado.
     * <p>
     *
     * @param filtro
     * @return <code>String</code>
     * @author Leandro Oliveira
     */
    public String abrirConsulta() {
	limparVisao();
	this.getConsulta().limparFiltro();
	return BemClienteMB.PAGINA_CONSULTA;
    }

    public void pesquisar() {
	this.getConsulta();
    }

    public void salvar() {
	try {
	    atualizarVinculoContratos();

	    this.tratarPapelProprietario();

	    getService().salvar(getVisao().getEntidade(), this.getVisao().getListaProprietarioImovelExclusao());

	    if (getVisao().getEntidade().hasMensagens()) {
		adicionaListaMensagemDeAlerta(getVisao().getEntidade().getMensagens());
	    } else {
		getVisao().setMensagemModal(MensagensUtil.getMensagem(getNomeVarResourceBundle(), MsgConstant.OPERACAO_COM_SUCESSO));
	    }
	} catch (Exception e) {
	    LogCefUtil.error("Erro ao salvar bens do cliente: " + e.getCause());
	    LogCefUtil.error(e);
	}
    }

    private void tratarPapelProprietario() {
	if (getVisao().getEntidade().getTipoBemEnum().isImovel()) {
	    this.getVisao().getEntidade().getImovel().getListaProprietario().stream().forEach(new Consumer<ProprietarioImovel>() {
		@Override
		public void accept(ProprietarioImovel t) {
		    if (t.getPapel() == null || t.getPapel().getNuPapelProprietario() == null) {
			t.setPapel(null);
		    }
		}
	    });
	}
    }

    /**
     * <p>
     * Método responsável por consultar os dados do imóvel, na api de habitação.
     * </p>
     *
     */
    public void consultarDadosImovel() {
	final Imovel imovelVisao = this.getVisao().getEntidade().getImovel();

	try {
	    imovelVisao.setDhConsultaDadosImovel(new Date());
	    this.atualizarDadosImoveis(this.imovelService.consultarDetalhesImovelSiopi(imovelVisao.getNuMatricula(), imovelVisao.getLivroServentia(),
		    this.pegarCodigoCNS(imovelVisao)));
	    // TODO Validar a consulta de cep no banco Oracle
	    // this.buscaCep();
	} catch (RuntimeException e) {
	    LogCEF.debug("Erro de validação do serviço de imóveis do SIOPI. Detalhes: ");
	    LogCEF.debug(e);
	    MensagensUtil.adicionaMensagemDeAlerta(AppConstant.RESOURCE_BUNDLE, parseMessage(e.getMessage()), "");
	} catch (Exception e) {
	    LogCEF.debug("Erro ao consultar dados do imóvel. Detalhes: ");
	    LogCEF.debug(e);
	    MensagensUtil.adicionaMensagemDeAlerta(AppConstant.RESOURCE_BUNDLE, "Não foi possível consultar dados do imóvel.", "");
	}
    }

    private Long pegarCodigoCNS(final Imovel imovelVisao) {
	Long identificacaoCartorio = null;
	if (imovelVisao != null && imovelVisao.getGestaoServentia() != null) {
	    identificacaoCartorio = NumeroUtil.parseLong(imovelVisao.getGestaoServentia().getCodigoCns());
	}
	return identificacaoCartorio;
    }

    private void atualizarDadosImoveis(Imovel consultarDadosSiopi) {
	if (consultarDadosSiopi != null) {
	    final Imovel imovelVisao = this.getVisao().getEntidade().getImovel();

	    imovelVisao.vrAreaPrivativa(consultarDadosSiopi.getVrAreaPrivativa());
	    imovelVisao.vrAreaImovel(consultarDadosSiopi.getVrAreaImovel());
	    imovelVisao.areaTerreno(consultarDadosSiopi.getAreaTerreno());
	    imovelVisao.descricao(consultarDadosSiopi.getDescricao());
	    imovelVisao.quantidadeDormitorio(consultarDadosSiopi.getQuantidadeDormitorio());
	    imovelVisao.nuCep(consultarDadosSiopi.getNuCep());
	    imovelVisao.cepComMascara(String.valueOf(consultarDadosSiopi.getNuCep()));
	    imovelVisao.tipoLogradouro(consultarDadosSiopi.getTipoLogradouro());
	    imovelVisao.noLogadouro(consultarDadosSiopi.getNoLogadouro());
	    imovelVisao.nuNumero(consultarDadosSiopi.getNuNumero());
	    imovelVisao.noComplemento(consultarDadosSiopi.getNoComplemento());
	    imovelVisao.noBairro(consultarDadosSiopi.getNoBairro());
	    imovelVisao.noUf(consultarDadosSiopi.getNoUf());
	    imovelVisao.noMunicipio(consultarDadosSiopi.getNoMunicipio());
	    imovelVisao.tipoImplantacao(consultarDadosSiopi.getTipoImplantacao());
	    imovelVisao.quantidadeVagasGaragem(consultarDadosSiopi.getQuantidadeVagasGaragem());
	    imovelVisao.testada(consultarDadosSiopi.getTestada());
	    imovelVisao.valorCompraVenda(consultarDadosSiopi.getValorCompraVenda());

	    imovelVisao.estadoConservacaoImovel(consultarDadosSiopi.getEstadoConservacaoImovel());
	    imovelVisao.estadoConservacaoCondominio(consultarDadosSiopi.getEstadoConservacaoCondominio());
	    imovelVisao.padraoAcabamento(consultarDadosSiopi.getPadraoAcabamento());

	    imovelVisao.usoImovel(consultarDadosSiopi.getUsoImovel());
	    imovelVisao.categoriaImovel(consultarDadosSiopi.getCategoriaImovel());
	    imovelVisao.padraoAcabamento(consultarDadosSiopi.getPadraoAcabamento());
	    imovelVisao.estadoConservacaoImovel(consultarDadosSiopi.getEstadoConservacaoImovel());
	    imovelVisao.estadoConservacaoCondominio(consultarDadosSiopi.getEstadoConservacaoCondominio());

	    imovelVisao.setCoImovelSIOPI(consultarDadosSiopi.getCoImovelSIOPI());
	} else {
	    MensagensUtil.adicionaMensagemDeAlerta(AppConstant.RESOURCE_BUNDLE, "Dados de imóveis não encontrados no SIOPI.", "");
	}
    }

    private String parseMessage(String message) {
	String retorno = "";
	if (message != null && message.length() > 0) {
	    String[] dados = message.split(":");
	    if (dados != null && dados.length > 1) {
		retorno = dados[1];
	    }
	}
	return retorno;
    }

    /**
     * <p>
     * Método responsável por consultar os dados da avaliação do imóvel, na api
     * de habitação.
     * </p>
     *
     * @author gerusa.soares
     *
     */
    public void consultarDadosAvaliacao() {
	try {
	    final Imovel imovelVisao = this.getVisao().getEntidade().getImovel();
	    imovelVisao.setDhConsultaDadosAvaliacao(new Date());

	    String nuCpfCnpj = this.getVisao().getProprietarioImovelVisao().getPessoa().getNuCnpj();
	    BigInteger nuAvaliacao = imovelVisao.getNuIdentificadorAvaliacao();
	    Integer codigoImovel = NumeroUtil.parseInt(imovelVisao.getCoImovelSIOPI());

	    if ((nuCpfCnpj == null || nuCpfCnpj.isEmpty()) && (nuAvaliacao == null || nuAvaliacao.equals(BigInteger.ZERO))) {
		final String msg = "É necessário informar o CPF/CNPJ ou Código Identificador para realizar a pesquisa.";
		super.adicionaMensagemDeAlerta(msg);
	    } else {
		if (nuCpfCnpj != null && !nuCpfCnpj.isEmpty()) {
		    this.buscarAvaliacoesPorCpfCnpj(nuCpfCnpj);
		} else {
		    if (codigoImovel != null) {
			this.buscarAvaliacoesPorNumAvaliacao(codigoImovel, nuAvaliacao);
		    } else {
			final String msg = "Para realizar a consulta de avaliações primeiro faça a consulta de imóveis por cartório/livro/matrícula.";
			super.adicionaMensagemDeAlerta(msg);
		    }
		}
	    }
	} catch (ParametrosInvalidosException e) {
	    final String msg = e.getCause().getMessage();
	    super.adicionaMensagemDeAlerta(msg);
	} catch (Exception e) {
	    LogCEF.debug("Erro ao consultar dados da avaliação. Detalhes: ");
	    LogCEF.debug(e);
	    getVisao().setListaAvaliacaoImoveis(new ArrayList<AvaliacaoTO>());

	    final String msg = (e.getCause() != null && e.getCause().getMessage() != null) ? e.getCause().getMessage()
		    : "É necessário informar o CPF/CNPJ do proprietário.";
	    super.adicionaMensagemDeAlerta(msg);
	}
    }

    private void buscarAvaliacoesPorNumAvaliacao(Integer codigoImovel, BigInteger nuAvaliacao) throws ParametrosInvalidosException {
	RespostaAvaliacaoImovelTO resposta = avaliacaoImovelWS.buscarAvaliacaoPorCodigoImovelAndIdentAvaliacao(codigoImovel, nuAvaliacao);

	if (resposta != null && resposta.getAvaliacaoDetalhada() != null) {
	    getVisao().setSelectedAvaliacao(resposta.getAvaliacaoDetalhada());
	    getVisao().getEntidade().getImovel().setNuIdentificadorAvaliacao(resposta.getAvaliacaoDetalhada().getIdentificacaoAvaliacao());
	    getVisao().getEntidade().getImovel().setCoOrdemServicoAvaliacao(resposta.getAvaliacaoDetalhada().getOrdemServico());
	    RespostaLaudoEngenhariaTO laudo = avaliacaoImovelWS.buscarLaudoPorCodigoImovelAndIdentAvaliacao(codigoImovel, nuAvaliacao);
	    if (laudo != null) {
		getVisao().getEntidade().getImovel().setDataAvaliacao(prepararData(laudo));
		getVisao().getEntidade().getImovel().setValorAvaliacao(laudo.getLaudoEngenharia().getValorAvaliacao());
	    }

	} else {
	    MensagensUtil.adicionaMensagemDeAlerta(AppConstant.RESOURCE_BUNDLE, "Não consta dados de avaliação.", "");
	}
    }

    private void buscarAvaliacoesPorCpfCnpj(String nuCpfCnpj) throws ParametrosInvalidosException {
	RespostaAvaliacaoImovelTO resposta = avaliacaoImovelWS.buscarAvaliacoesImoveisPorCpfCnpj(nuCpfCnpj);

	if (resposta != null) {
	    if (resposta.getAvaliacao().getListaAvaliacoes().size() > 1) {
		getVisao().setListaAvaliacaoImoveis(resposta.getAvaliacao().getListaAvaliacoes());
		RequestContext.getCurrentInstance().execute("modalSelecionarAvaliacaoWidget.show();");
	    } else if (!resposta.getAvaliacao().getListaAvaliacoes().isEmpty() && resposta.getAvaliacao().getListaAvaliacoes().size() == 1) {
		getVisao().setSelectedAvaliacao(resposta.getAvaliacao().getListaAvaliacoes().get(0));
		selecionarAvaliacao();
		getVisao().getEntidade().getImovel().setNuIdentificadorAvaliacao(getVisao().getSelectedAvaliacao().getIdentificacaoAvaliacao());
		getVisao().getEntidade().getImovel().setDataAvaliacao(getVisao().getSelectedAvaliacao().getDataAbertura());
	    }
	} else {
	    MensagensUtil.adicionaMensagemDeAlerta(AppConstant.RESOURCE_BUNDLE, "Não consta dados de avaliação.", "");
	}
    }

    /**
     * <p>
     * Método responsável por abrir a tela de edição ou detalhamento, conforme
     * parâmetros informados.
     * <p>
     *
     * @param sacado
     *            valor a ser atribuído
     * @param desabilitarTodosCampos
     *            - true, desabilita todos os campos
     * @return <code>String</code>
     * @author Leandro Oliveira
     * @author Gilberto Nery
     * @author gerusa.soares
     */
    public String editarDetalhar(final BemCliente bemCliente, final boolean desabilitarTodosCampos) {
	this.getVisao().setDesabilitarTodosCampos(desabilitarTodosCampos);

	getVisao().setEntidade(getService().obter(bemCliente.getNuBemCliente()));

	if (getVisao().getEntidade().getTipoBemEnum().isImovel()) {
	    carregarGestaoServentia();

	    // quando o imóvel é rural ele não desabilita os campos de endereço
	    if (getVisao().getEntidade().getImovel().getUsoImovel().getNuTipoUsoImovel() != null) {
		getVisao().setDesabilitarEndereco(getVisao().getEntidade().getImovel().getUsoImovel().getNuTipoUsoImovel() != 5);
	    }

	    this.carregarListaPapelProprietarioImovel();
	    this.getVisao().getEntidade().getImovel()
		    .setListaProprietario(this.service.listarProprietariosAtivosImovel(getVisao().getEntidade().getImovel().getNuImovel()));
	    this.carregarTipoLogradouroImovel();
	    this.carregarTipoUsoImovel();
	    this.carregarCategoriaImovel();

	} else if (getVisao().getEntidade().getTipoBemEnum().isVeiculo()) {
	    getVisao().setDadosSifecUfs(sifecVeiculos.consultarUFs("1"));

	    if (getVisao().getDadosSifecUfs() == null) {
		getVisao().setMensagemModal(MensagensUtil.getMensagem(AppConstant.RESOURCE_BUNDLE, MsgConstant.SERVICO_INDISPONIVEL));
	    }
	    tipoVeiculo();
	    marcaVeiculo();
	    modeloVeiculo();
	}

	atribuirVinculoContratos();

	return PAGINA_INCLUSAO;
    }

    /**
     *
     * @author gerusa.soares
     *
     */
    private void carregarListaPapelProprietarioImovel() {
	if (UtilObjeto.isVazio(this.getVisao().getListaPapelProprietario())) {
	    final Collection<PapelProprietario> lista = this.papelProprietarioService.listar();
	    if (!UtilObjeto.isVazio(lista)) {
		this.getVisao().setListaPapelProprietario((List<PapelProprietario>) lista);
	    }
	}
    }

    public void excluir() {
	getVisao().setEntidade(getService().obter(getVisao().getBem().getNuBemCliente()));

	if (!garantiaBemClienteService.isPossuiGarantia(getVisao().getEntidade().getNuBemCliente())) {
	    getService().excluir(getVisao().getEntidade());
	    pesquisar();
	    super.adicionaMensagemDeSucesso(MensagensUtil.getMensagem(AppConstant.RESOURCE_BUNDLE, MsgConstant.OPERACAO_COM_SUCESSO));
	} else {
	    super.adicionaMensagemDeAlerta(MensagensUtil.getMensagem(AppConstant.RESOURCE_BUNDLE, MsgConstant.EXCLUSAO_NAO_PERMITIDA_BEM_CLIENTE));
	}
    }

    /**
     * <p>
     * Método responsável por abrir a tela de edição do Sacado.
     * <p>
     *
     * @param sacado
     *            valor a ser atribuído
     * @return <code>String</code>
     * @author narcieliton.lopes
     */
    public String abrirInclusao() {
	limparVisao();

	return PAGINA_INCLUSAO;
    }

    public void onChangeTipoBem() {
	if (getVisao().getEntidade().getTipoBemEnum().isImovel()) {
	    final Imovel imovel = new Imovel();
	    imovel.setLivroServentia("2");
	    getVisao().getEntidade().setImovel(imovel);
	    limparCombos();
	    carregarGestaoServentia();
	    this.carregarListaPapelProprietarioImovel();
	}

	if (getVisao().getEntidade().getTipoBemEnum().isMaquinaEquipamento()) {
	    getVisao().getEntidade().setMaquinaEquipamento(new MaquinaEquipamento());
	}

	if (getVisao().getEntidade().getTipoBemEnum().isVeiculo()) {
	    getVisao().getEntidade().setVeiculo(new Veiculo());
	    getVisao().setDadosSifecUfs(sifecVeiculos.consultarUFs("1"));
	    if (getVisao().getDadosSifecUfs() == null) {
		getVisao().setMensagemModal(MensagensUtil.getMensagem(AppConstant.RESOURCE_BUNDLE, MsgConstant.SERVICO_INDISPONIVEL));
	    }
	}
    }

    public void onChangeGestaoServentia() {
	if (UtilObjeto.isReferenciaNumeroPositivo(this.visao.getEntidade().getImovel().getGestaoServentia().getNuGestaoServentia())) {
	    for (final GestaoServentia gestaoServentia : this.visao.getListaGestaoServentia()) {
		if (this.getVisao().getEntidade().getImovel().getGestaoServentia().getNuGestaoServentia()
			.equals(gestaoServentia.getNuGestaoServentia())) {
		    this.visao.getEntidade().getImovel().setGestaoServentia(UtilObjeto.clone(gestaoServentia));
		    this.visao.getEntidade().getImovel().setNoCartorio(gestaoServentia.getDenominacao());
		    break;
		}
	    }
	} else {
	    this.visao.getEntidade().getImovel().setNoCartorio("");
	    this.visao.getEntidade().getImovel().setGestaoServentia(null);
	}
    }

    public void onChangeTipoLogradouro() {

    }

    public void onChangeCategoriaImovel() {

    }

    /**
     * <p>
     * Método responsável por consultar o cliente na base do SIACG, e caso não
     * seja encontrato, é buscado na base do SICLI
     * </p>
     * .
     *
     * @author f503697
     */
    public void consultarPessoa() {
	final String cpfCnpj = UtilCnpj.removerFormatacao(getVisao().getEntidade().getPessoa().getNuCnpj());
	if (!UtilString.isVazio(cpfCnpj)) {
	    getVisao().getEntidade().setPessoa(pessoaService.obterPessoaSicliComRepresentanteLegal(cpfCnpj));

	    if (getVisao().getEntidade().getPessoa() == null || getVisao().getEntidade().getPessoa().getNuCnpj() == null) {
		super.adicionaMensagemDeAlerta(MsgConstant.CPF_CNPJ_NAO_ENCONTRADO);
	    }
	} else {
	    getVisao().getEntidade().getPessoa().setNoPessoa("");
	}
    }

    /**
     * <p>
     * Método responsável por obter os contratos da Pessoa informada, a partir
     * do SICLI.
     * </p>
     * .
     *
     * @author f503697
     */
    public void consultarContratos() {
	contratoService.recuperarContratoSifecParaAtualizarOuSalvar(getVisao().getTitularContrato().getNuCnpj());
	getVisao().setTitularContrato(pessoaService.obterPessoaPorCnpj(getVisao().getTitularContrato().getNuCnpj()));
	if (getVisao().getTitularContrato().getNuPessoa() == null) {
	    super.adicionaMensagemDeAlerta(MsgConstant.CPF_CNPJ_NAO_ENCONTRADO);
	}

	if (getVisao().getTitularContrato().getNuPessoa() != null) {
	    final List<Contrato> contratos = this.contratoService.listarContratosPorPessoa(getVisao().getTitularContrato());
	    criarListaContratos(contratos);
	}
    }

    private void criarListaContratos(final List<Contrato> contratos) {
	List<Contrato> dados = new ArrayList<>();
	if (!UtilObjeto.isVazio(contratos)) {
	    for (final Contrato contrato : contratos) {
		if (!getVisao().getEntidade().getContratos().contains(contrato)) {
		    contrato.setCoContratoFormatado(contratoService.formatarCodigoContrato(contrato.getCoContrato()));

		    if (validarContratoConformeTipoBemCliente(contrato, getVisao().getEntidade().getTipoBemEnum())) {
			dados.add(contrato);
		    }
		}
	    }
	}

	if (!UtilObjeto.isVazio(dados)) {
	    getVisao().getEntidade().getContratos().addAll(dados);
	} else {
	    super.adicionaMensagemDeAlerta(MsgConstant.NAO_FORAM_ENCONTRADOS_CONTRATOS_BASE);
	}
    }

    /**
     * <b>Descricao:</b> Validar os contratos para cada bem cliente conforme as
     * suas operações: Rever essa regra
     * <ul>
     * <li><b>1 - Imóveis:</b> Para os contratos de Imóveis não deverão ser
     * utilizadas as seguintes operações:</br>
     * <strong>"0426", "0427", "0563" e "0564"</strong></li>
     * <li><b>2 - Maquinas/Equipamentos:</b> Validar***</li>
     * <li><b>3 - Veículos:</b> Validar***</li>
     * </ul>
     * 
     * @param contrato
     * @param tipoBemEnum
     * @return
     */
    private boolean validarContratoConformeTipoBemCliente(Contrato contrato, TipoBemEnum tipoBemEnum) {
	boolean retorno = false;
	// 1-IMOVEL, 2-MAQUINA_EQUIPAMENTO, 3-VEICULO
	switch (tipoBemEnum.getCodigo()) {
	case 1:
	    // TODO Validar nas garantias Bacen e não nas Operações do contrato
	    // (Verificar com o Bruno/Alexandre)
	    // retorno =
	    // OPERACOES_PERMITIDAS_IMOVEIS.contains(contrato.getNuOperacao());
	    retorno = true;
	    break;
	case 2:
	    retorno = true;
	    break;
	case 3:
	    retorno = true;
	    break;
	default:
	    retorno = false;
	    break;
	}
	return retorno;
    }

    public String getDescricaoBotao() {
	return getVisao().getEntidade().getNuBemCliente() == null ? "Incluir" : "Alterar";
    }

    /**
     * <p>
     * Método executado quando digitado o cep
     * </p>
     *
     * @author Brunno Antunes
     * @author Mábio Barbosa
     */
    public void buscaCep() {
	visao.getEntidade().getImovel().setNoBairro("");
	visao.getEntidade().getImovel().setNoMunicipio("");
	visao.getEntidade().getImovel().setNoUf("");
	visao.getEntidade().getImovel().setNoLogadouro("");
	visao.getEntidade().getImovel().setNuCep(null);
	final String cepSemMascara = UtilCnpj.removerFormatacao(visao.getEntidade().getImovel().getCepComMascara());
	if (!UtilString.isVazio(cepSemMascara)) {
	    if (visao.getEntidade().getImovel().getUsoImovel() != null) {
		final List<EnderecoDTO> lista = enderecoDao.listarEnderecoPorCep(cepSemMascara);
		final EnderecoDTO enderecoDTO = lista.stream().findFirst().orElse(null);
		if (enderecoDTO != null) {
		    visao.getEntidade().getImovel().setNuCep(Integer.valueOf(cepSemMascara));
		    visao.getEntidade().getImovel().setNoBairro(enderecoDTO.getNoBairro());
		    visao.getEntidade().getImovel().setNoMunicipio(enderecoDTO.getNoMunicipio());
		    visao.getEntidade().getImovel().setNoUf(enderecoDTO.getSgUf());
		    visao.getEntidade().getImovel().setNoLogadouro(enderecoDTO.getNoLogradouro());
		    // quando o imóvel é rural ele não desabilita os campos de
		    // endereço
		    visao.setDesabilitarEndereco(visao.getEntidade().getImovel().getUsoImovel().getNuTipoUsoImovel() != 5);
		} else if (visao.getEntidade().getImovel().getUsoImovel().getNuTipoUsoImovel() != 5) {
		    visao.getEntidade().getImovel().setCepComMascara(null);
		    super.adicionaMensagemDeAlerta(MsgConstant.CEP_NAO_CADASTRADO_SIICO);
		    RequestContext.getCurrentInstance().execute("modalMessagemWidgetCep.show();");
		}
		visao.getEntidade().getImovel().setNuCep(Integer.parseInt(cepSemMascara));
	    } else {
		super.adicionaMensagemDeAlerta(MsgConstant.TIPO_USO_IMOVEL_OBRIGATORIO);
		RequestContext.getCurrentInstance().execute("modalMessagemWidgetCep.show();");
	    }
	}
    }

    public void vincular(final Contrato contrato) {

	if (getVisao().getEntidade().getNuBemCliente() != null
		&& getService().isPossuiContrato(getVisao().getEntidade().getNuBemCliente(), contrato.getNuContrato())) {
	    super.adicionaMensagemDeAlerta(MsgConstant.CONTRATO_POSSUI_GARANTIA_VINCULADA);
	} else {
	    if (getVisao().getEntidade().getTipoBemEnum().isVeiculo() || getVisao().getEntidade().getTipoBemEnum().isImovel()) {
		vincularContrato(contrato);
	    } else {
		contrato.setIcVinculado(!contrato.isIcVinculado());
	    }
	}
    }

    private void vincularContrato(final Contrato contrato) {
	if (StringUtils.isNotEmpty(contrato.getCoContrato())) {
	    if (contrato.isIcVinculado()) {
		contrato.setIcVinculado(false);
	    } else {
		List<Contrato> listaMarcados = obterContratosMarcados();
		validarOperacao734(listaMarcados, contrato);
	    }
	} else {
	    super.adicionaMensagemDeAlerta(MsgConstant.CONTRATO_INVALIDO_PARA_VINCULACAO);
	}
    }

    private void marcaDesmarcaVinculo(final Contrato contrato) {
	contrato.setIcVinculado(!contrato.isIcVinculado());
    }

    private Integer obterOperacao(String coContratoFormatado) {
	return Integer.valueOf(coContratoFormatado.split("\\.")[1]);
    }

    private List<Contrato> obterContratosMarcados() {
	List<Contrato> contratoMarcados = new ArrayList<>();
	for (Contrato c : getVisao().getEntidade().getContratos()) {
	    if (c.isIcVinculado()) {
		contratoMarcados.add(c);
	    }
	}
	return contratoMarcados;
    }

    private void validarOperacao734(List<Contrato> listaMarcados, Contrato contrato) {
	boolean podeVincular = true;
	if (CollectionUtils.isNotEmpty(listaMarcados)) {
	    Contrato cMarcado = listaMarcados.get(0);
	    Integer operacaoMarcado = obterOperacao(cMarcado.getCoContratoFormatado());
	    Integer operacaoAMarcar = obterOperacao(contrato.getCoContratoFormatado());
	    if (((!operacaoMarcado.equals(734) && operacaoAMarcar.equals(734)) || !operacaoAMarcar.equals(734))
		    || !contrato.getNuPessoa().equals(cMarcado.getNuPessoa())) {
		podeVincular = false;
		super.adicionaMensagemDeAlerta(MsgConstant.VINCULO_CONTRATO_NAO_PERMITIDO, "0734", cMarcado.getNuPessoa().getNuCnpjFormatado());
	    }
	    if (podeVincular) {
		marcaDesmarcaVinculo(contrato);
	    }
	} else {
	    marcaDesmarcaVinculo(contrato);
	}
    }

    public void limparVisao() {
	this.visao = new BemClienteVisao();
	this.getConsulta().limparFiltro();
	getVisao().setDesabilitarValorAvaliacao(false);
	getVisao().getEntidade().setPessoa(new Pessoa());
    }

    public void getCnm() {
	if (getVisao().getEntidade().getImovel() != null) {
	    getVisao().getEntidade().getImovel().setCodigoCnm(imovelService.cnm(getVisao().getEntidade().getImovel()));
	}
    }

    public void validarArea() {
	if (getVisao().getEntidade().getImovel().getVrAreaPrivativa() != null
		&& getVisao().getEntidade().getImovel().getVrAreaPrivativa().compareTo(getVisao().getEntidade().getImovel().getVrAreaImovel()) > 0) {
	    RequestContext.getCurrentInstance().execute("modalAreaImovel.show();");
	}
    }

    public void limparAreaPrivativa() {
	getVisao().getEntidade().getImovel().setVrAreaPrivativa(BigDecimal.ZERO);
	RequestContext.getCurrentInstance().execute("modalAreaImovel.hide();");
	RequestContext.getCurrentInstance().execute("$('#vrAreaPrivativa').focus();");
    }

    private void atualizarVinculoContratos() {
	if (!UtilObjeto.isVazio(getVisao().getEntidade().getContratos())) {
	    Iterator<Contrato> iterator = getVisao().getEntidade().getContratos().iterator();
	    while (iterator.hasNext()) {
		Contrato contrato = iterator.next();
		if (!contrato.isIcVinculado()) {
		    iterator.remove();
		}
	    }
	}
    }

    /**
     * <p>
     * Método responsável por inicializar as combos
     * </p>
     * .
     *
     * @author f503697
     */
    private void limparCombos() {
	if (getVisao().getEntidade().getImovel().getTipoImplantacao() != null && getVisao().getEntidade().getImovel().getTipoImplantacao() == 0) {
	    getVisao().getEntidade().getImovel().setTipoImplantacao(null);
	}
	if (getVisao().getEntidade().getImovel().getEstadoConservacaoCondominio() != null
		&& getVisao().getEntidade().getImovel().getEstadoConservacaoCondominio() == 0) {
	    getVisao().getEntidade().getImovel().setEstadoConservacaoCondominio(null);
	}
	if (getVisao().getEntidade().getImovel().getEstadoConservacaoImovel() != null
		&& getVisao().getEntidade().getImovel().getEstadoConservacaoImovel() == 0) {
	    getVisao().getEntidade().getImovel().setEstadoConservacaoImovel(null);
	}
	if (getVisao().getEntidade().getImovel().getPadraoAcabamento() != null && getVisao().getEntidade().getImovel().getPadraoAcabamento() == 0) {
	    getVisao().getEntidade().getImovel().setPadraoAcabamento(null);
	}
    }

    private void carregarGestaoServentia() {
	GestaoServentia gestaoServentia = new GestaoServentia();
	gestaoServentia.setSituacao("Ativo");
	this.getVisao().setListaGestaoServentia(new ArrayList<>(this.gestaoServentiaService.listarGestaoServentiaPorFiltros(gestaoServentia)));
    }

    private void carregarTipoLogradouroImovel() {
	this.getVisao().setListaTipoLogradouro(new ArrayList<>(this.tipoLogradouroDAO.listar()));
    }

    private void carregarTipoUsoImovel() {
	this.getVisao().setListaTipoUsoImovel(new ArrayList<>(this.tipoUsoDAO.listar()));
    }

    private void carregarCategoriaImovel() {
	this.getVisao().setListaCategoriaImovel(new ArrayList<>(this.tipoCategoriaDAO.listar()));
    }

    private void atribuirVinculoContratos() {
	for (Contrato contrato : getVisao().getEntidade().getContratos()) {
	    contrato.setIcVinculado(Boolean.TRUE);
	    contrato.setCoContratoFormatado(contratoService.formatarCodigoContrato(contrato.getCoContrato()));
	}

	if (getVisao().getEntidade().getContratos().size() > 0) {
	    getVisao().setTitularVinculo(getVisao().getEntidade().getContratos().get(0).getNuPessoa());
	}
    }

    /**
     * Método responsavel por carregar e limpar os tipo veiculos na tela de
     * inclusao de Veiculo.
     */
    public void atualizaTipoVeiculo() {
	getVisao().getEntidade().getVeiculo().setNoTipoVeiculo(null);
	getVisao().getEntidade().getVeiculo().setNoMarca(null);
	getVisao().getEntidade().getVeiculo().setNoModelo(null);
	tipoVeiculo();
    }

    /**
     * Método responsavel por carregar os tipo veiculos na tela de inclusao de
     * Veiculo.
     */
    public void tipoVeiculo() {
	getVisao().setDadosSifecTipos(sifecVeiculos.consultarTiposVeiculos("1", getVisao().getEntidade().getVeiculo().getNoCategoria()));
    }

    /**
     * Método responsavel por carregar as marcas de veiculos na tela de inclusao
     * de Veiculo.
     */
    public void atualizaMarcaVeiculo() {
	getVisao().getEntidade().getVeiculo().setNoMarca(null);
	getVisao().getEntidade().getVeiculo().setNoModelo(null);
	marcaVeiculo();
    }

    /**
     * Método responsavel por carregar as marcas de veiculos na tela de inclusao
     * de Veiculo.
     */
    public void marcaVeiculo() {
	getVisao().setDadosSifecMarcas(sifecVeiculos.consultarMarcaVeiculos("1", getVisao().getEntidade().getVeiculo().getNoCategoria(),
		visao.getEntidade().getVeiculo().getNoTipoVeiculo()));
    }

    /**
     * Método responsavel por carregar os modelos de veiculos na tela de bens
     * cliente > Veiculo.
     */
    public void atualizaModeloVeiculo() {
	getVisao().getEntidade().getVeiculo().setNoModelo(null);
	modeloVeiculo();
    }

    /**
     * Método responsavel por carregar os modelos de veiculos na tela de bens
     * cliente > Veiculo.
     */
    public void modeloVeiculo() {
	getVisao().setDadosSifecModelos(sifecVeiculos.consultarModelosVeiculos("1", getVisao().getEntidade().getVeiculo().getNoCategoria(),
		visao.getEntidade().getVeiculo().getNoTipoVeiculo(), visao.getEntidade().getVeiculo().getNoMarca()));
    }

    /*******************************************************************
     * GETTERS && SETTERS
     ******************************************************************/
    @Override
    protected String getNomeVarResourceBundle() {
	return AppConstant.RESOURCE_BUNDLE;
    }

    @Override
    protected String getPrefixoCasoDeUso() {
	return NOME_MANAGED_BEAN;
    }

    @SuppressWarnings("unchecked")
    @Override
    public BemClienteService getService() {
	return this.service;
    }

    @Override
    public BemClienteVisao getVisao() {
	if (!UtilObjeto.isReferencia(visao)) {
	    this.visao = new BemClienteVisao();
	}

	return visao;
    }

    public void mudarUsoImovel() {
	if (getVisao().getEntidade().getImovel().getUsoImovel().getNuTipoUsoImovel() != null) {
	    getVisao().setDesabilitarEndereco(getVisao().getEntidade().getImovel().getUsoImovel().getNuTipoUsoImovel() != 5);
	}
    }

    public void selecionarAvaliacao() {
	getVisao().getSelectedAvaliacao();
	Integer codigoImovel = getVisao().getSelectedAvaliacao().getImovel().getCodigoImovel();
	BigInteger identificacaoAvaliacao = getVisao().getSelectedAvaliacao().getIdentificacaoAvaliacao();

	RespostaAvaliacaoImovelTO resposta = avaliacaoImovelWS.buscarAvaliacaoPorCodigoImovelAndIdentAvaliacao(codigoImovel, identificacaoAvaliacao);
	if (resposta.getAvaliacaoDetalhada() != null) {
	    getVisao().setSelectedAvaliacao(resposta.getAvaliacaoDetalhada());
	    getVisao().getEntidade().getImovel().setNuIdentificadorAvaliacao(resposta.getAvaliacaoDetalhada().getIdentificacaoAvaliacao());
	    getVisao().getEntidade().getImovel().setCoOrdemServicoAvaliacao(resposta.getAvaliacaoDetalhada().getOrdemServico());
	}
	RespostaLaudoEngenhariaTO laudo = avaliacaoImovelWS.buscarLaudoPorCodigoImovelAndIdentAvaliacao(codigoImovel, identificacaoAvaliacao);
	if (laudo != null) {
	    getVisao().getEntidade().getImovel().setDataAvaliacao(prepararData(laudo));
	    getVisao().getEntidade().getImovel().setValorAvaliacao(laudo.getLaudoEngenharia().getValorAvaliacao());
	}
    }

    private Date prepararData(RespostaLaudoEngenhariaTO laudo) {
	Date retorno = null;
	try {
	    if (laudo.getLaudoEngenharia() != null && laudo.getLaudoEngenharia().getDataRegistroLaudo() != null) {
		retorno = new SimpleDateFormat("yyyy/MM/dd").parse(laudo.getLaudoEngenharia().getDataRegistroLaudo());
	    }
	} catch (ParseException e) {
	    LogCefUtil.imprimirLog("SIACG -> prepararData ->  ", e.getMessage());
	}
	return retorno;
    }

    public void consultarAvaliacao() {
	try {
	    String nuCnpj = getVisao().getEntidade().getPessoa().getNuCnpj();
	    RespostaAvaliacaoImovelTO resposta = avaliacaoImovelWS.buscarAvaliacoesImoveisPorCpfCnpj(nuCnpj);
	    if (resposta != null && resposta.getAvaliacao().getListaAvaliacoes().size() > 1) {
		getVisao().setListaAvaliacaoImoveis(resposta.getAvaliacao().getListaAvaliacoes());
		RequestContext.getCurrentInstance().execute("modalSelecionarAvaliacaoWidget.show();");
	    } else if (resposta != null && !resposta.getAvaliacao().getListaAvaliacoes().isEmpty() && resposta.getAvaliacao().getListaAvaliacoes().size() == 1) {
		getVisao().setSelectedAvaliacao(resposta.getAvaliacao().getListaAvaliacoes().get(0));
	    }
	} catch (Exception e) {
	    LogCEF.debug(e);
	    super.adicionaMensagemDeAlerta("É necessário informar o CPF/CNPJ do proprietário.");
	    RequestContext.getCurrentInstance().execute("modalSelecionarAvaliacaoWidget.show();");
	}
    }

    public void consultarProprietarioImovel() {
	final ProprietarioImovel proprietario = this.getVisao().getProprietarioImovelVisao();

	final String cpfCnpj = UtilCnpj.removerFormatacao(proprietario.getPessoa().getNuCnpj());

	if (!UtilString.isVazio(cpfCnpj)) {
	    final Pessoa pessoa = this.pessoaService.obterPessoaSicliComRepresentanteLegal(cpfCnpj);

	    if (pessoa == null || pessoa.getNuCnpj() == null) {
		this.limparProprietarioImovelVisao();
		super.adicionaMensagemDeAlerta(MsgConstant.CPF_CNPJ_NAO_ENCONTRADO);
		return;
	    }

	    proprietario.setPessoa(pessoa);

	} else {
	    this.limparProprietarioImovelVisao();
	}

    }

    private void limparProprietarioImovelVisao() {
	this.getVisao().setProprietarioImovelVisao(new ProprietarioImovel());
    }

    /**
     *
     * @author gerusa.soares
     *
     */
    public void adicionarProprietarioImovel() {
	final ProprietarioImovel proprietarioImovelVisao = this.getVisao().getProprietarioImovelVisao();
	proprietarioImovelVisao.limparMensagens();

	this.service.validarProprietarioImovelVisao(proprietarioImovelVisao, this.getVisao().getEntidade().getImovel().getListaProprietario());

	if (proprietarioImovelVisao.hasMensagens()) {
	    this.adicionaListaMensagemDeAlerta(proprietarioImovelVisao.getMensagens());
	    return;
	}

	if (UtilObjeto.isReferencia(proprietarioImovelVisao.getPapel())
		&& UtilObjeto.isReferencia(proprietarioImovelVisao.getPapel().getNuPapelProprietario())) {

	    final Integer nuPapelSelecionado = proprietarioImovelVisao.getPapel().getNuPapelProprietario();

	    final PapelProprietario papelSelecionado = this.getVisao().getListaPapelProprietario().stream()
		    .filter(papelProprietario -> papelProprietario.getNuPapelProprietario() == nuPapelSelecionado).findFirst().orElse(null);

	    if (UtilObjeto.isReferencia(papelSelecionado)) {
		proprietarioImovelVisao.setPapel(papelSelecionado);
	    }
	}

	proprietarioImovelVisao.setImovel(this.getVisao().getEntidade().getImovel());
	proprietarioImovelVisao.setDhInclusao(new Date());
	proprietarioImovelVisao.setIcOrigemInclusao(OrigemEnum.SIACG.getCodigo().shortValue());

	this.getVisao().getEntidade().getImovel().getListaProprietario().add(proprietarioImovelVisao);

	this.getVisao().setProprietarioImovelVisao(new ProprietarioImovel());
    }

    public void excluirProprietarioImovel() {
	final ProprietarioImovel proprietarioSelecionadoExclusao = this.getVisao().getProprietarioImovelVisaoExclusao();

	final List<ProprietarioImovel> collection = this.getVisao().getEntidade().getImovel().getListaProprietario();
	for (Iterator<ProprietarioImovel> iterator = collection.iterator(); iterator.hasNext();) {
	    final ProprietarioImovel proprietario = iterator.next();

	    if (proprietario.getPessoa().getNuCnpj().equals(proprietarioSelecionadoExclusao.getPessoa().getNuCnpj())) {
		if (proprietario.getNuProprietarioImovel() != null) {
		    this.getVisao().getListaProprietarioImovelExclusao().add(proprietario);
		}
		collection.remove(proprietario);
		break;
	    }
	}

	super.adicionaMensagemDeSucesso(MensagensUtil.getMensagem(AppConstant.RESOURCE_BUNDLE, MsgConstant.OPERACAO_COM_SUCESSO));
    }

    public void consultarHistoricoProprietarioImovel() {
	if (UtilObjeto.isVazio(this.getVisao().getListaHistoricoProprietarioImovel())) {
	    this.getVisao().setListaHistoricoProprietarioImovel(
		    this.service.listarTodosProprietariosImovel(getVisao().getEntidade().getImovel().getNuImovel()));
	}
    }
    
    public BemClienteLazyModel getConsulta() {
	if (!UtilObjeto.isReferencia(this.consulta)) {
	    this.consulta = new BemClienteLazyModel();
	}
	return this.consulta;
    }

    public void setConsulta(BemClienteLazyModel consulta) {
	this.consulta = consulta;
    }

}