/*==============================================================*/
/* SCRIPT V1_0_0_2__SIACG_DW_DLL									*/
/*==============================================================*/
-- Table: acgsm001.acgtd006_produto

CREATE TABLE acgsm001.acgtd006_produto
(
  nu_produto smallint, -- identificador do produto
  no_produto character varying(120), -- nome do produto
  nu_unidade_gestora smallint, -- identificador da unidade gestora do produto
  no_unidade_gestora character varying(35), -- nome da unidade gestora
  sg_unidade_gestora character varying(5), -- sigla da unidade gestora
  nu_natural integer, -- identificador natural
  nu_idntr_produto serial NOT NULL, -- Identificador da tabela
  nu_operacao smallint, -- numero da operacao do produto.
  no_operacao character varying(40), -- nome da operacao do produto.
  co_ultima_situacao character varying(2), -- Identificador de situacao do produto....
  dt_fim_gestao date, -- Dia, mes e ano em que a Unidade encerrou a gestao sobre o produto.
  dt_fim_atndo_prdto date,
  CONSTRAINT pk_acgtd006_produto PRIMARY KEY (nu_idntr_produto)
)
WITH (
  OIDS=FALSE
);

COMMENT ON TABLE acgsm001.acgtd006_produto
  IS 'Table: acgsm001.acgtd006_produto';
COMMENT ON COLUMN acgsm001.acgtd006_produto.nu_produto IS 'identificador do produto';
COMMENT ON COLUMN acgsm001.acgtd006_produto.no_produto IS 'nome do produto';
COMMENT ON COLUMN acgsm001.acgtd006_produto.nu_unidade_gestora IS 'identificador da unidade gestora do produto';
COMMENT ON COLUMN acgsm001.acgtd006_produto.no_unidade_gestora IS 'nome da unidade gestora';
COMMENT ON COLUMN acgsm001.acgtd006_produto.sg_unidade_gestora IS 'sigla da unidade gestora';
COMMENT ON COLUMN acgsm001.acgtd006_produto.nu_natural IS 'identificador natural';
COMMENT ON COLUMN acgsm001.acgtd006_produto.nu_idntr_produto IS 'Identificador da tabela';
COMMENT ON COLUMN acgsm001.acgtd006_produto.nu_operacao IS 'numero da operacao do produto.';
COMMENT ON COLUMN acgsm001.acgtd006_produto.no_operacao IS 'nome da operacao do produto.';
COMMENT ON COLUMN acgsm001.acgtd006_produto.co_ultima_situacao IS 'Identificador de situacao do produto.
Exemplos:

ATIVO: Produto em opereacao de venda para o cliente.

SUSPENSO: Produto ativo, no entanto esta suspensa a comercializacao por determinacao administrativa, com sistema ativo.

DESCONTINUADO: Produto cancelado para a venda e cancelado no sistema, podendo ter clientes com contratos ativos no produto e podendo ser ativado novamente.

EM CRIACAO: Produto definido, aguardando desenvolvimento.

EM DESENVOLVIMENTO: Produto em desenvolvimento e não existe sistema.;';
COMMENT ON COLUMN acgsm001.acgtd006_produto.dt_fim_gestao IS 'Dia, mes e ano em que a Unidade encerrou a gestao sobre o produto.';

-- Index: acgsm001.ix_acgtd006_01
CREATE INDEX ix_acgtd006_01
  ON acgsm001.acgtd006_produto
  USING btree
  (nu_produto);
COMMENT ON INDEX acgsm001.ix_acgtd006_01
  IS 'Index: acgsm001.ix_ix_acgtd006_01';

-- Index: acgsm001.ix_acgtd006_produto_02
CREATE INDEX ix_acgtd006_produto_02
  ON acgsm001.acgtd006_produto
  USING btree
  (nu_unidade_gestora);

-- Index: acgsm001.ix_acgtd006_produto_03
CREATE INDEX ix_acgtd006_produto_03
  ON acgsm001.acgtd006_produto
  USING btree
  (nu_natural);

/*########################### SCRIPT ROLLBACK ##############################*/
/* 
DROP TABLE acgsm001.acgtd006_produto;
*/ 