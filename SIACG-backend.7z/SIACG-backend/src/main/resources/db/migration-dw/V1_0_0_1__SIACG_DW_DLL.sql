/*==============================================================*/
/* SCRIPT V1_0_0_1__SIACG_DW_DLL									*/
/*==============================================================*/

ALTER TABLE acgsm001.acgtd004_unidade
 ADD COLUMN co_unidade_dire character varying(5),
 ADD COLUMN no_unidade_dire character varying(100);

 COMMENT ON COLUMN acgsm001.acgtd004_unidade.co_unidade_dire is 'Codigo da unidade de DIRE';
 COMMENT ON COLUMN acgsm001.acgtd004_unidade.no_unidade_dire is 'Nome da unidade de DIRE';
 
  

/*########################### SCRIPT ROLLBACK ##############################*/
/* 
ALTER TABLE acgsm001.acgtd004_unidade
DROP COLUMN co_unidade_dire,
DROP COLUMN no_unidade_dire;
*/