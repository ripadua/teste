/*==============================================================*/
/* Sequence: acgtd007_aplicacao_financeira_seq                  */
/*==============================================================*/
create sequence acgsm001.acgtd007_aplicacao_financeira_seq;

/*==============================================================*/
/* Table: acgtd007_aplicacao_financeira                         */
/*==============================================================*/

create table acgsm001.acgtd007_aplicacao_financeira (
   nu_idntr_aplicacao_financeira integer     not null default nextval('acgsm001.acgtd007_aplicacao_financeira_seq'::regclass),
   nu_aplicacao_financeira integer           null,
   nu_contrato          integer              null,
   co_identificador_contrato VARCHAR(30)     null,
   co_identificador_pessoa VARCHAR(14)       null,
   no_pessoa            VARCHAR(100)         null,
   nu_garantia          integer              null,
   no_garantia          VARCHAR(60)          null,
   co_operacao_garantia VARCHAR(20)          null,
   conta_corrente       VARCHAR(38)          null,
   co_certificado_aplicacao_fncra VARCHAR(20) null,
   de_aplicacao_financeira VARCHAR(200)       null,
   ic_origem_aplicacao_financeira integer     null,
   dt_ultima_atualizacao date                 null,
   constraint PK_ACGTD007_APLICACAO_FINANCEI primary key (nu_idntr_aplicacao_financeira)
);

comment on table acgsm001.acgtd007_aplicacao_financeira is
'Armazena informações das aplicações financeiras.';

comment on column acgsm001.acgtd007_aplicacao_financeira.nu_idntr_aplicacao_financeira is
'Número identificador da aplicação financeira, gerado automaticamente pelo sistema.';

comment on column acgsm001.acgtd007_aplicacao_financeira.nu_aplicacao_financeira is
'Número identificador da aplicação financeira na base relacional, gerado automaticamente pelo sistema.';

comment on column acgsm001.acgtd007_aplicacao_financeira.nu_contrato is
'Número identificador do contrato na base relacional, gerado automaticamente pelo sistema.';

comment on column acgsm001.acgtd007_aplicacao_financeira.co_identificador_contrato is
'Código identificador do contrato.';

comment on column acgsm001.acgtd007_aplicacao_financeira.co_identificador_pessoa is
'Código identificador da pessoa, podendo ser cpf ou cnpj.';

comment on column acgsm001.acgtd007_aplicacao_financeira.no_pessoa is
'Nome da pessoa física ou jurídica.';

comment on column acgsm001.acgtd007_aplicacao_financeira.nu_garantia is
'Número identificador da garantia na base relacional, gerado automaticamente pelo sistema.';

comment on column acgsm001.acgtd007_aplicacao_financeira.no_garantia is
'Nome da garantia. Ex: Caução-Duplicata, Caução-Cheques, etc';

comment on column acgsm001.acgtd007_aplicacao_financeira.co_operacao_garantia is
'Código da operação da garantia.';

comment on column acgsm001.acgtd007_aplicacao_financeira.conta_corrente is
'Conta corrente no formato agencia.operacao.conta-dvConta';

comment on column acgsm001.acgtd007_aplicacao_financeira.co_certificado_aplicacao_fncra is
'Código do certificado da aplicação financeira no SIART/SIFIX.';

comment on column acgsm001.acgtd007_aplicacao_financeira.de_aplicacao_financeira is
'Descrição da aplicação financeira.';

comment on column acgsm001.acgtd007_aplicacao_financeira.ic_origem_aplicacao_financeira is
'Origem da aplicação financeira.';

comment on column acgsm001.acgtd007_aplicacao_financeira.dt_ultima_atualizacao is
'Data da última atualização da aplicação financeira.';

/*==============================================================*/
/* REVERT                                                       */
/*==============================================================*/
-- drop table if exists acgsm001.acgtd007_aplicacao_financeira;
-- drop sequence if exists acgsm001.acgtd007_aplicacao_financeira_seq;
