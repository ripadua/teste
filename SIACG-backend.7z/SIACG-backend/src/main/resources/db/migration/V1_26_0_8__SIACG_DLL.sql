COMMENT ON COLUMN acgsm001.acgtb068_garantia_produto.ic_garantia_obrigatoria IS
'Informa se a Garantia BACEN é Obrigatória ou Acessória.

TRUE: Obrigatória
FALSE: Acessória';    

