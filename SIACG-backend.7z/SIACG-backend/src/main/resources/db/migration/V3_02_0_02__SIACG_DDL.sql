
-- ACGTB133_LEILAO_PENDENCIA
ALTER TABLE ACG.ACGTB133_LEILAO_PENDENCIA ADD CO_MATRICULA CHAR(7) NOT NULL;
COMMENT ON COLUMN ACG.ACGTB133_LEILAO_PENDENCIA.CO_MATRICULA IS 'Matrícula do responsável pela criação do registro de pendência';

-- ACGTB130_LEILAO
ALTER TABLE ACG.ACGTB130_LEILAO DROP CONSTRAINT CK_ACGTB130_01;
ALTER TABLE ACG.ACGTB130_LEILAO ADD CONSTRAINT CK_ACGTB130_01 CHECK (IC_SITUACAO IN ('0', '1', '2', '3', '4', '5', '6', '7', '8', '9')) ENABLE;

COMMENT ON COLUMN ACG.ACGTB130_LEILAO.IC_SITUACAO IS 'Situação do imóvel 
0 - Aguardando leilão
1 - Aguardando 1º leilão
2 - Aguardando 2º leilão
3 - Em pendência
4 - Baixado
5 - Vendido
6 - Emissão de quitação
7 - Prestação de contas
8 - Proposta direito de preferência
9 - Excluído';

-- ACGTB136_HSTRO_LEILAO
ALTER TABLE ACG.ACGTB136_HSTRO_LEILAO DROP CONSTRAINT CK_ACGTB136_01;
ALTER TABLE ACG.ACGTB136_HSTRO_LEILAO ADD CONSTRAINT CK_ACGTB136_01 CHECK (IC_SITUACAO IN ('0', '1', '2', '3', '4', '5', '6', '7', '8', '9')) ENABLE;

COMMENT ON COLUMN ACG.ACGTB136_HSTRO_LEILAO.IC_SITUACAO IS 'Situação do imóvel 
0 - Aguardando leilão
1 - Aguardando 1º leilão
2 - Aguardando 2º leilão
3 - Em pendência
4 - Baixado
5 - Vendido
6 - Emissão de quitação
7 - Prestação de contas
8 - Proposta direito de preferência
9 - Excluído';

