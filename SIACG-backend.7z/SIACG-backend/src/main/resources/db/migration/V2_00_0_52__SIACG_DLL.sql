/*==============================================================*/
/* Table: acgtb077_maquina_equipamento                          */
/*==============================================================*/
 
ALTER TABLE acgsm001.acgtb077_maquina_equipamento ADD COLUMN ic_estado_bem smallint; 


COMMENT ON COLUMN acgsm001.acgtb077_maquina_equipamento.ic_estado_bem IS 
'Define o estado do bem:

1 - Novo;
2 - Usado.';


--ALTER TABLE acgsm001.acgtb077_maquina_equipamento DROP COLUMN ic_estado_bem;