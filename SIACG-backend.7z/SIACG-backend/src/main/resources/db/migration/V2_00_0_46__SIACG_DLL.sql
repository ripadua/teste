/*==============================================================*/
/* Sequence: acgsq093_instituicao_bancaria                      */
/*==============================================================*/


create sequence acgsm001.acgsq093_instituicao_bancaria;


/*==============================================================*/
/* Table: acgtb093_instituicao_bancaria                         */
/*==============================================================*/
create table acgsm001.acgtb093_instituicao_bancaria (
   nu_instituicao_bancaria INT               not null default nextval('acgsm001.acgsq093_instituicao_bancaria'),
   nu_ispb              INT                  null,
   no_banco_reduzido    CHAR(80)             null,
   nu_compe             INT                  null,
   constraint PK_ACGTB093_INSTITUICAO_BANCAR primary key (nu_instituicao_bancaria),
   constraint AK_UK_NU_ISPB_ACGTB093 unique (nu_ispb)
);

comment on table acgsm001.acgtb093_instituicao_bancaria is
'Tabela que tem descritivo de todos os Bancon relacionados no BACEN. ';

comment on column acgsm001.acgtb093_instituicao_bancaria.nu_instituicao_bancaria is
'Identificador unico de instituição bancaria';

comment on column acgsm001.acgtb093_instituicao_bancaria.nu_ispb is
'Identificador do sistema de pagamentos Brasileiro';

comment on column acgsm001.acgtb093_instituicao_bancaria.no_banco_reduzido is
'Nome reduzido da instituição Bancaria';

comment on column acgsm001.acgtb093_instituicao_bancaria.nu_compe is
'Centralizadora de compensacao de cheques e outros papeis';


/*==============================================================*/
/* Script reverse: acgsm001.acgtb093_instituicao_bancaria                */
/*==============================================================*/


--drop sequence acgsq093_instituicao_bancaria;

--drop table acgtb093_instituicao_bancaria;


