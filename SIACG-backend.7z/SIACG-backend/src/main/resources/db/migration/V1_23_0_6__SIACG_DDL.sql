-- ###############   Tabela: acgtb001_contrato
-- Colunas Presentes Apenas no Power Designer
ALTER TABLE "acgsm001"."acgtb001_contrato" ADD COLUMN "co_produto_origem" varchar(4) COLLATE "pg_catalog"."default";
COMMENT ON COLUMN "acgsm001"."acgtb001_contrato"."co_produto_origem" IS 'Código do produto no sistema de origem da contratação. Esse código é utilizado para armazenar a informação do código do produto quando esse código difere do código do SIICO.

Ex: CDC no SIAPI tem o código 400, no SIICO é o produto 115.';

ALTER TABLE "acgsm001"."acgtb001_contrato" ADD COLUMN "vr_saldo_disponivel" numeric(16,2);
COMMENT ON COLUMN "acgsm001"."acgtb001_contrato"."vr_saldo_disponivel" IS 'Valor do saldo credo a ser liberado para o contrato. Esse valor é utilizado em operações de crédito rotativo onde a liberação do saldo é realizada conforme a utilização do limite vinculado. Também é utilizado em operações onde os recursos são liberados em etapas, por exemplo em operações vinculadas a obras, onde a liberação dos recursos são realizadas conforme as etapas de execução.';

-- Colunas Presentes Apenas no Banco DES
ALTER TABLE "acgsm001"."acgtb001_contrato" DROP COLUMN "nu_produto_pai";
ALTER TABLE "acgsm001"."acgtb001_contrato" DROP COLUMN "nu_modalidade_pai";
-- ###############   Tabela: acgtb001_contrato

-- ###############   Tabela: acgtb003_pessoa
-- Colunas Presentes Apenas no Power Designer
ALTER TABLE "acgsm001"."acgtb003_pessoa" ADD COLUMN "ic_titular_principal" bool DEFAULT true;
COMMENT ON COLUMN "acgsm001"."acgtb003_pessoa"."ic_titular_principal" IS 'Indica se a pessoa é o titular principal do contrato';

ALTER TABLE "acgsm001"."acgtb003_pessoa" ADD COLUMN "co_cliente" varchar(15) COLLATE "pg_catalog"."default";
COMMENT ON COLUMN "acgsm001"."acgtb003_pessoa"."co_cliente" IS 'Código único de identificação da pessoa como cliente da Caixa. Esse código é mantido no SICLI que é o sistema responsável pelas informações dos clientes da Caixa.';
-- ###############   Tabela: acgtb003_pessoa

-- ###############   Tabela: acgtb009_garantia_contrato
-- Colunas Presentes Apenas no Power Designer
ALTER TABLE "acgsm001"."acgtb009_garantia_contrato" ADD COLUMN "vr_percentual_minimo" numeric(16,2);
ALTER TABLE "acgsm001"."acgtb009_garantia_contrato" ADD COLUMN "vr_minimo" numeric(16,2);
ALTER TABLE "acgsm001"."acgtb009_garantia_contrato" ADD COLUMN "ic_bloqueio" char(1) COLLATE "pg_catalog"."default";
COMMENT ON COLUMN "acgsm001"."acgtb009_garantia_contrato"."ic_bloqueio" IS 'Solcitação do bloqueio sobre o valor da aplicação. Valores possiveis:

1 - Total
2 - Parcial';
ALTER TABLE "acgsm001"."acgtb009_garantia_contrato" ADD COLUMN "ic_parametrizacao" char(1) COLLATE "pg_catalog"."default";
COMMENT ON COLUMN "acgsm001"."acgtb009_garantia_contrato"."ic_parametrizacao" IS 'Tipos de parametrização existente para o contrato. Valores possiveis:

1- Parametros de Calculo - para analise de garantias
2- Parametros de Produto - para consulta de aplicações para compor a garantia do produto';
-- ###############   Tabela: acgtb009_garantia_contrato

-- ###############   Tabela: acgtb047_garantia_habitacao
-- Colunas Presentes Apenas no Power Designer
ALTER TABLE "acgsm001"."acgtb047_garantia_habitacao" ADD COLUMN "dh_inclusao" date;
COMMENT ON COLUMN "acgsm001"."acgtb047_garantia_habitacao"."dh_inclusao" IS 'Data e hora vinculação da unidade habitacional como garantia do contrato.';

ALTER TABLE "acgsm001"."acgtb047_garantia_habitacao" ADD COLUMN "co_responsavel" varchar(7) COLLATE "pg_catalog"."default" NOT NULL;
COMMENT ON COLUMN "acgsm001"."acgtb047_garantia_habitacao"."co_responsavel" IS 'Matricula do responsavel pela inclusão da informação.';

-- Colunas Presentes Apenas no Banco DES
ALTER TABLE "acgsm001"."acgtb047_garantia_habitacao" DROP COLUMN "nu_garantia_habitacao";
-- ###############   Tabela: acgtb047_garantia_habitacao

-- ###############   Tabela: acgtb050_empreendimento
-- Colunas Presentes Apenas no Power Designer
ALTER TABLE "acgsm001"."acgtb050_empreendimento" ADD COLUMN "dh_inclusao" date NOT NULL DEFAULT now();
COMMENT ON COLUMN "acgsm001"."acgtb050_empreendimento"."dh_inclusao" IS 'Data e hora da inclusão das informações do empreendimento.';

-- Colunas Presentes Apenas no Banco DES
ALTER TABLE "acgsm001"."acgtb050_empreendimento" DROP COLUMN "dt_inclusao";
-- ###############   Tabela: acgtb050_empreendimento

-- ###############   Tabela: acgtb053_recebido
-- Colunas Presentes Apenas no Power Designer
ALTER TABLE "acgsm001"."acgtb053_recebido" ADD COLUMN "nu_ctrto_comercializacao" int8;
COMMENT ON COLUMN "acgsm001"."acgtb053_recebido"."nu_ctrto_comercializacao" IS 'Identifica o contrato de comercialização ao qual está vinculado o recebimento. Essa vinculação ocorre através do batimento do código de identificação do sacado (CPF/CNPJ) com o das pessoas vinculadas ao contrato de comercialização.

Caso no batimento não seja identificada uma correspondência, esse campo deverá receber o valor nulo. Isso significa que existe uma pendência de identificação do contrato de comercialização.

Poderá ainda existir um recebimento em que o código de identificação do sacado esteja vinculado a mais de um contrato de comercialização. Nesse caso também deverá ser armazenado o valor nulo e gerada uma pendência de identificação do contrato de comercialização.

Os recebimentos com pendência de identificação do contrato de comercialização deverá ser tratados em conciliação manual.';

ALTER TABLE "acgsm001"."acgtb053_recebido" ADD COLUMN "nu_tipo_parcela" int4;
COMMENT ON COLUMN "acgsm001"."acgtb053_recebido"."nu_tipo_parcela" IS 'Identificação do tipo de parcela a que o recebimento corresponde. Esse tipo deve corresponder ao tipo de parcela do prospecto para recebimentos que foram conciliados, portanto essa informação deve ser atualizada no momento da conciliação de um recebimento.';

ALTER TABLE "acgsm001"."acgtb053_recebido" ADD COLUMN "nu_empreendimento" int8 NOT NULL DEFAULT nextval('"acgsm001".acgsq050_empreendimento'::regclass);
COMMENT ON COLUMN "acgsm001"."acgtb053_recebido"."nu_empreendimento" IS 'Arrmazena a informação do empreendimento de vinculação de um título recebido. Essa informação é importante quando é realizado o cruzamento das informações dos títulos recebidos com os cedentes vinculados as garantias do empreendimento. Os títulos que tiverem um cedente vinculado a garantia de um empreendimento devem ter a vinculação de pagamento a esse emprrendimento. Essa vinculação será utilizada na rotina de conciliação do prospecto com os recebimentos.';

ALTER TABLE "acgsm001"."acgtb053_recebido" ADD COLUMN "nu_prospecto" int8;
COMMENT ON COLUMN "acgsm001"."acgtb053_recebido"."nu_prospecto" IS 'Identifica um recebimento recebido para o valor prospectado através da conciliação do valores (automática ou manual).

Essa informação é incluída quando ocorre um batimento entre a data prevista no prospecto com a data de vencimento do título recebido e o valor atualizado do prospecto com o valor do título.

Os recebimentos que não tiverem batimento serão incluído com o valor nulo para este campo. Isso significa que existe uma pendência de conciliação.';

-- Colunas Presentes Apenas no Banco DES
ALTER TABLE "acgsm001"."acgtb053_recebido" DROP COLUMN "nu_comercializacao";
ALTER TABLE "acgsm001"."acgtb053_recebido" DROP COLUMN "ic_recebido";
ALTER TABLE "acgsm001"."acgtb053_recebido" DROP COLUMN "vr_recebido";
ALTER TABLE "acgsm001"."acgtb060_parametro_garantia" DROP COLUMN "qt_prazo_maximo";
-- ###############   Tabela: acgtb053_recebido

-- ###############   Tabelas a serem CRIADAS
-- ###############   Tabela: acgtb054_bloqueio
CREATE SEQUENCE acgsm001.acgsq054_bloqueio
  INCREMENT 1
  MINVALUE 1
  MAXVALUE 9223372036854775807
  START 1
  CACHE 1;
ALTER TABLE acgsm001.acgsq054_bloqueio
  OWNER TO postgres;
CREATE TABLE "acgsm001"."acgtb054_bloqueio" (
  "nu_bloqueio" int4 NOT NULL DEFAULT nextval('"acgsm001".acgsq054_bloqueio'::regclass),
  "nu_garantia_contrato" int4,
  "co_responsavel" varchar(7) COLLATE "pg_catalog"."default" NOT NULL,
  "dt_bloqueio" date NOT NULL,
  "dt_prevista_desbloqueio" date,
  "dh_comando" date NOT NULL,
  "dh_desbloqueio" date,
  "ic_situacao" char(1) COLLATE "pg_catalog"."default" NOT NULL,
  "co_nsu_envio" varchar(9) COLLATE "pg_catalog"."default",
  "co_nsu_retorno" varchar(9) COLLATE "pg_catalog"."default"
)
;
COMMENT ON COLUMN "acgsm001"."acgtb054_bloqueio"."nu_bloqueio" IS 'Identificador do registro. Gerado automaticamente.';
COMMENT ON COLUMN "acgsm001"."acgtb054_bloqueio"."nu_garantia_contrato" IS 'Identificador da garantia do contrato. Gerado automaticamente pelo sistema.';
COMMENT ON COLUMN "acgsm001"."acgtb054_bloqueio"."co_responsavel" IS 'Identifica o responsável pela operação de bloqueio. Essa informação será repassada pelo sistema integrador, de onde a solicitação de bloqueio será enviada.
Ex. O empregado c999999, efetua uma operação de bloqueio de garantia no SIFEC. O SIFEC então envia a solicitação de bloqueio e envia para o SIACG a informação da matrícula do empregado.';
COMMENT ON COLUMN "acgsm001"."acgtb054_bloqueio"."dt_bloqueio" IS 'Data de efetivação do bloqueio da garantia.';
COMMENT ON COLUMN "acgsm001"."acgtb054_bloqueio"."dt_prevista_desbloqueio" IS 'Data prevista para desbloqueio da garantia. Essa data geralmente está relacionada a data de vencimento da garantia.

Ex: Uma aplicação financeira constituída como garantia tem uma data de vencimento/resgate da aplicação. O sistema deve tratar essas situações, garantindo que haverá um bloqueio de outra garantia no caso de necessidade de desbloqueio de uma garantia.';

COMMENT ON COLUMN "acgsm001"."acgtb054_bloqueio"."dh_comando" IS 'Identifica a data e hora que o comando de bloqueio foi executado no sistema responsável pelo bloqueio da garantia. Essa informação deve ser retornada pelo sistema que realiza a operacionalização da garantia.

Ex. Um bloqueio de aplicação é realizado no SIART que retorna a data e hora de efetivação deste comando para o SIACG.';

COMMENT ON COLUMN "acgsm001"."acgtb054_bloqueio"."dh_desbloqueio" IS 'Data e hora em que foi efetivado o desbloqueio da garantia.';
COMMENT ON COLUMN "acgsm001"."acgtb054_bloqueio"."ic_situacao" IS 'Identifica a operação de bloqueio realizada:

1- Bloqueada
2- Desbloqueada
3- Debitada - Conta CEF
4- Resgatada  - Credido conta corrente cliente';
COMMENT ON COLUMN "acgsm001"."acgtb054_bloqueio"."co_nsu_envio" IS 'Código de identificação único da transação de bloqueio gerado na origem. O desbloqueio somente poderá ser realizado com a utilização deste código.

Esse código será gerado pelo SIACG usando a seguinte regra de formação:

Número representativo do momento de geração da transação. Ex: xxxx';
COMMENT ON COLUMN "acgsm001"."acgtb054_bloqueio"."co_nsu_retorno" IS 'Códido de retorno da operação de bloqueio enviado pelo sistema responsável para operacionalização da garantia.

Ex: O SIACG solicita o bloqueio de poupança ao SID00 que realiza o bloqueio e retorna um códio NSU do bloqueio que deve ser armazenado neste campo.';
COMMENT ON TABLE "acgsm001"."acgtb054_bloqueio" IS 'Guarda os comandos de bloqueios/desbloqueios e débito/crédito realizados nas aplicações que constituem a garantia do contrato ';
-- ###############   Tabela: acgtb054_bloqueio

-- ###############   Tabela: acgtb055_log_bloqueio
CREATE SEQUENCE acgsm001.acgsq055_log_bloqueio
  INCREMENT 1
  MINVALUE 1
  MAXVALUE 9223372036854775807
  START 1
  CACHE 1;
ALTER TABLE acgsm001.acgsq055_log_bloqueio
  OWNER TO postgres;

CREATE TABLE "acgsm001"."acgtb055_log_bloqueio" (
  "nu_log_bloqueio" int8 NOT NULL DEFAULT nextval('"acgsm001".acgsq055_log_bloqueio'::regclass),
  "nu_bloqueio" int4,
  "nu_pessoa" int4,
  "no_tomador" varchar(200) COLLATE "pg_catalog"."default" NOT NULL,
  "nu_agencia" int4 NOT NULL,
  "nu_operacao" int4 NOT NULL,
  "nu_contrato" int4 NOT NULL,
  "acg_nu_pessoa" int4 NOT NULL,
  "ic_comando" char(1) COLLATE "pg_catalog"."default" NOT NULL,
  "ic_tipo_relacao" varchar(1) COLLATE "pg_catalog"."default" NOT NULL DEFAULT 'T'::character varying,
  "nu_digito_verificador" int4 NOT NULL,
  "ic_sistema_origem" varchar(10) COLLATE "pg_catalog"."default" NOT NULL,
  "vr_contrato" numeric(16,2) NOT NULL,
  "ic_indicativo_liquidacao" bool NOT NULL,
  "vr_garantia" numeric(16,2) NOT NULL,
  "ic_transacao" char(1) COLLATE "pg_catalog"."default" NOT NULL,
  "qt_dia_vigencia" int4 NOT NULL,
  "no_aplicacao" varchar(200) COLLATE "pg_catalog"."default" NOT NULL,
  "ic_bloqueio" char(1) COLLATE "pg_catalog"."default" NOT NULL,
  "ic_retorno" bool NOT NULL,
  "vr_bloqueado" numeric(16,2) NOT NULL,
  "nu_prioridade_bloqueio" int4 NOT NULL
)
;
COMMENT ON COLUMN "acgsm001"."acgtb055_log_bloqueio"."nu_bloqueio" IS 'Identificador do registro. Gerado automaticamente.';
COMMENT ON COLUMN "acgsm001"."acgtb055_log_bloqueio"."nu_pessoa" IS 'Identificador da empresa. Gerado automaticamente pelo sistema.';
COMMENT ON COLUMN "acgsm001"."acgtb055_log_bloqueio"."no_tomador" IS 'Nome do tomador do contrato';
COMMENT ON COLUMN "acgsm001"."acgtb055_log_bloqueio"."nu_agencia" IS 'Número da agência a qual o contrato está vinculado';
COMMENT ON COLUMN "acgsm001"."acgtb055_log_bloqueio"."nu_operacao" IS 'Número da operação de crédito';
COMMENT ON COLUMN "acgsm001"."acgtb055_log_bloqueio"."nu_contrato" IS 'Identificador do contrato';
COMMENT ON COLUMN "acgsm001"."acgtb055_log_bloqueio"."acg_nu_pessoa" IS 'Identificador da empresa. Gerado automaticamente pelo sistema.';
COMMENT ON COLUMN "acgsm001"."acgtb055_log_bloqueio"."ic_comando" IS 'Identifica o comando executado sobre a aplicação que constitui a garantia

1 - BL GAR APL - BLOQ GARANTIA APLICACAO FINANCEIRA - Bloqueio
2 - D BL GR AP - DESBLOQ GARANTIA APLIC FINANCEIRA - Desbloqueio
3 - DB GAR APL - DEB BLOQ GARANTIA APLICACAO FINANCEIRA  - débito
4 - DB GAR APR - DEB BLOQ GARANTIA APLICACAO FINANCEIRA (RETRO) - débito retroativo (D-1)
5 - C AP BLGAR - CRED APL BLOQ GARANTIA APLICACAO FINANCEIRA
6 - C AP BLGRR - CRED APL BLOQ GARANTIA APLICACAO FINANCEIRA (RETRO)
7 - ES AP BLGR - ES CR APL BLOQ GARANTIA APLICACAO FINANCEIRA
8 - ES D GR AP - ES DEB BLOQ GARANTIA APLICACAO FINANCEIRA - estorno';
COMMENT ON COLUMN "acgsm001"."acgtb055_log_bloqueio"."ic_tipo_relacao" IS 'Identifica o tipo de relacionamento ou papel da pessoa com o contrato.
Ex:

T - Tomador
A - Avalista
C - Cônjuge
F - Fiador';

COMMENT ON COLUMN "acgsm001"."acgtb055_log_bloqueio"."nu_digito_verificador" IS 'Digito verificador do contrato';
COMMENT ON COLUMN "acgsm001"."acgtb055_log_bloqueio"."ic_sistema_origem" IS 'Sistema de origem de crédito. Valores possiveis:

SIAPI – Créditos Parcelados PF e PJ;
SIEMP – Créditos Parcelados PF e PJ, Veículos e Agronegócio;
SICDC – Crédito Direto CAIXA PF e PJ (evolução de contrato no SIAPI);
SILCR – Créditos Rotativos PF e PJ – PEDEP;
SID00 - Créditos Rotativos PF e PJ (SIDEC);
SIDEO- Créditos Rotativos PJ (SIDEC - GIM);
';
COMMENT ON COLUMN "acgsm001"."acgtb055_log_bloqueio"."vr_contrato" IS 'Valor do contrato';
COMMENT ON COLUMN "acgsm001"."acgtb055_log_bloqueio"."ic_indicativo_liquidacao" IS 'Indicativo de liquidação do contrato';
COMMENT ON COLUMN "acgsm001"."acgtb055_log_bloqueio"."vr_garantia" IS 'Valor da garantia';
COMMENT ON COLUMN "acgsm001"."acgtb055_log_bloqueio"."ic_transacao" IS 'Identifica qual é o tipo da transação, possiveis ser realizadas através do comandos que o SIACG envia aos sistemas originadores do contrato

1- Consulta
2- Bloqueio
3- Desbloqueio
4- Resgate (crédito)
5- Débito';
COMMENT ON COLUMN "acgsm001"."acgtb055_log_bloqueio"."qt_dia_vigencia" IS 'Quantidade de dias da vigencia da garantia';
COMMENT ON COLUMN "acgsm001"."acgtb055_log_bloqueio"."no_aplicacao" IS 'Nome da aplicação que possui saldo suficiente para constituir a garantia do contrato
';
COMMENT ON COLUMN "acgsm001"."acgtb055_log_bloqueio"."ic_bloqueio" IS 'Solcitação do bloqueio sobre o valor da aplicação. Valores possiveis:
1 - Total
2 - Parcial';
COMMENT ON COLUMN "acgsm001"."acgtb055_log_bloqueio"."ic_retorno" IS 'Resposta retorno do sistema origem da aplicação, em relação aos comandos enviados pelo SIACG';
COMMENT ON COLUMN "acgsm001"."acgtb055_log_bloqueio"."vr_bloqueado" IS 'Valor a ser bloqueado ';
COMMENT ON COLUMN "acgsm001"."acgtb055_log_bloqueio"."nu_prioridade_bloqueio" IS 'Indica a ordem de prioridade do bloqueio das aplicaçoes, conforme a parametrização das garantias aceitas pelo produto';
COMMENT ON TABLE "acgsm001"."acgtb055_log_bloqueio" IS 'Guarda os dados da execução dos comandos executados pelo SIACG na integração com os sistemas que realizam a operacionalização dos bloqueios de garantias.';
-- ###############   Tabela: acgtb055_log_bloqueio

-- ###############   Tabela: acgtb061_pessoa_contrato
CREATE TABLE "acgsm001"."acgtb061_pessoa_contrato" (
  "nu_contrato" int4 NOT NULL,
  "nu_pessoa" int4 NOT NULL,
  "ic_tipo_relacao" varchar(1) COLLATE "pg_catalog"."default" NOT NULL DEFAULT 'T'::character varying
)
;

COMMENT ON COLUMN "acgsm001"."acgtb061_pessoa_contrato"."nu_contrato" IS 'Identificador do contrato. Virá da importação';
COMMENT ON COLUMN "acgsm001"."acgtb061_pessoa_contrato"."nu_pessoa" IS 'Identificador da empresa. Gerado automaticamente pelo sistema.';
COMMENT ON COLUMN "acgsm001"."acgtb061_pessoa_contrato"."ic_tipo_relacao" IS 'Identifica o tipo de relacionamento ou papel da pessoa com o contrato.

Ex:

T - Tomador / Proponente
A - Avalista
C - Cônjuge
F - Fiador';
COMMENT ON TABLE "acgsm001"."acgtb061_pessoa_contrato" IS 'Vinculação de uma pessoa a um contrato através de um papel específico.

Ex: Cônjuge, Tomador (Principal ou Secundário), Avalista, Fiador, etc.
';
-- ###############   Tabela: acgtb061_pessoa_contrato

-- ###############   Tabela: acgtb062_pessoa_garantia
CREATE TABLE "acgsm001"."acgtb062_pessoa_garantia" (
  "nu_contrato" int4 NOT NULL,
  "nu_pessoa" int4 NOT NULL,
  "ic_tipo_relacao" varchar(1) COLLATE "pg_catalog"."default" NOT NULL DEFAULT 'T'::character varying,
  "nu_garantia_contrato" int4 NOT NULL
)
;
COMMENT ON COLUMN "acgsm001"."acgtb062_pessoa_garantia"."nu_contrato" IS 'Identificador do contrato. Virá da importação';
COMMENT ON COLUMN "acgsm001"."acgtb062_pessoa_garantia"."nu_pessoa" IS 'Identificador da empresa. Gerado automaticamente pelo sistema.';
COMMENT ON COLUMN "acgsm001"."acgtb062_pessoa_garantia"."ic_tipo_relacao" IS 'Identifica o tipo de relacionamento ou papel da pessoa com o contrato.

Ex:

T - Tomador
A - Avalista
C - Cônjuge
F - Fiador';
COMMENT ON COLUMN "acgsm001"."acgtb062_pessoa_garantia"."nu_garantia_contrato" IS 'Identificador da garantia do contrato. Gerado automaticamente pelo sistema.';
COMMENT ON TABLE "acgsm001"."acgtb062_pessoa_garantia" IS 'Vinculação de uma pessoa a uma garantia de um contrato em um papel específico.

Ex: A Pessoa X, está vinculada a garantia de Aval do contrato XPTO no papel de avalista.';
-- ###############   Tabela: acgtb062_pessoa_garantia

-- ###############   Tabela: acgtb064_tipo_parcela
CREATE TABLE "acgsm001"."acgtb064_tipo_parcela" (
  "nu_tipo_parcela" int4 NOT NULL,
  "no_tipo_parcela" varchar(100) COLLATE "pg_catalog"."default" NOT NULL,
  "ic_periodicidade_prevista" int2 NOT NULL DEFAULT 0,
  "qt_ocorrencia_prevista" int4 NOT NULL
)
;
COMMENT ON COLUMN "acgsm001"."acgtb064_tipo_parcela"."nu_tipo_parcela" IS 'Número identificado automático gerado pelo sistema.';
COMMENT ON COLUMN "acgsm001"."acgtb064_tipo_parcela"."no_tipo_parcela" IS 'Nome do tipo de parcela que pode ser utilizada como base de prospecção de um contrato de comercialização de uma unidade habitacional.

Ex:
- Sinal
- Parcela
- Repasse bancário
- Balão
- Chave';
COMMENT ON COLUMN "acgsm001"."acgtb064_tipo_parcela"."ic_periodicidade_prevista" IS 'Periodicidade prevista para o tipo de parcela. Essa periodicidade será sugerida no lançamento do prospecto de parcelas do contrato, podendo ser alterado de acordo com as características do contrato.
Valores possiveis:

0 - Única
1 - Mensal
2 - Bimestral
3 - Trimestral
4 - Quadrimestral
6 - Semestral
12 - Anual';
COMMENT ON COLUMN "acgsm001"."acgtb064_tipo_parcela"."qt_ocorrencia_prevista" IS 'Quantidade de ocorrências previstas para o tipo de parcela. Essa informação será sugerida para facilitar o preenchimento do prospecto do contrato.';
COMMENT ON TABLE "acgsm001"."acgtb064_tipo_parcela" IS 'Tipo de parcela que pode ser utilizada no propecto de um contrato.
Ex: 
- Sinal
- Parcela
- Repasse bancário
- Chave
- Sinal
- Balão
- Parcela
- Encargo
- Amortização';
-- ###############   Tabela: acgtb064_tipo_parcela

-- ###############   Tabela: acgtbs01_contrato
CREATE TABLE "acgsm001"."acgtbs01_contrato" (
  "co_operacao_contrato" varchar(4) COLLATE "pg_catalog"."default",
  "nu_unidade_concessora" int4,
  "co_avaliacao_operacao" varchar(11) COLLATE "pg_catalog"."default",
  "co_identificador_contrato" varchar(30) COLLATE "pg_catalog"."default",
  "co_contrato_dv" varchar(1) COLLATE "pg_catalog"."default",
  "co_contrato_sem_dv" varchar(20) COLLATE "pg_catalog"."default",
  "nu_unidade_conta_corrente" int4,
  "co_operacao_conta_corrente" varchar(4) COLLATE "pg_catalog"."default",
  "co_conta_corrente" varchar(20) COLLATE "pg_catalog"."default",
  "co_conta_corrente_dv" varchar(1) COLLATE "pg_catalog"."default",
  "dt_contrato" date,
  "dt_concessao_operacao" date,
  "no_cliente" varchar(100) COLLATE "pg_catalog"."default",
  "co_identificador_cliente" varchar(14) COLLATE "pg_catalog"."default",
  "co_prazo" varchar(5) COLLATE "pg_catalog"."default",
  "ic_situacao" varchar(2) COLLATE "pg_catalog"."default",
  "vr_contrato" numeric(16,2),
  "vr_comprometido" numeric(16,2),
  "vr_saldo_devedor" numeric(16,2),
  "vr_prestacao" numeric(16,2),
  "vr_maximo_emprestimo" numeric(16,2),
  "vr_ultima_prestacao" numeric(16,2),
  "vr_primeira_prestacao" numeric(16,2),
  "qt_prazo_contrato" int4,
  "co_garantia_01" varchar(4) COLLATE "pg_catalog"."default",
  "co_garantia_02" varchar(4) COLLATE "pg_catalog"."default",
  "co_garantia_03" varchar(4) COLLATE "pg_catalog"."default",
  "co_garantia_04" varchar(4) COLLATE "pg_catalog"."default",
  "co_garantia_05" varchar(4) COLLATE "pg_catalog"."default",
  "co_garantia_06" varchar(4) COLLATE "pg_catalog"."default",
  "co_garantia_07" varchar(4) COLLATE "pg_catalog"."default",
  "co_garantia_08" varchar(4) COLLATE "pg_catalog"."default",
  "co_garantia_09" varchar(4) COLLATE "pg_catalog"."default",
  "co_garantia_10" varchar(4) COLLATE "pg_catalog"."default",
  "co_garantia_11" varchar(4) COLLATE "pg_catalog"."default",
  "co_garantia_12" varchar(4) COLLATE "pg_catalog"."default",
  "co_garantia_13" varchar(4) COLLATE "pg_catalog"."default",
  "co_garantia_14" varchar(4) COLLATE "pg_catalog"."default",
  "co_garantia_15" varchar(4) COLLATE "pg_catalog"."default",
  "co_garantia_16" varchar(4) COLLATE "pg_catalog"."default",
  "co_garantia_17" varchar(4) COLLATE "pg_catalog"."default",
  "co_garantia_18" varchar(4) COLLATE "pg_catalog"."default",
  "co_garantia_19" varchar(4) COLLATE "pg_catalog"."default",
  "co_garantia_20" varchar(4) COLLATE "pg_catalog"."default",
  "vr_garantia_01" numeric(16,2),
  "vr_garantia_02" numeric(16,2),
  "vr_garantia_03" numeric(16,2),
  "vr_garantia_04" numeric(16,2),
  "vr_garantia_05" numeric(16,2),
  "vr_garantia_06" numeric(16,2),
  "vr_garantia_07" numeric(16,2),
  "vr_garantia_08" numeric(16,2),
  "vr_garantia_09" numeric(16,2),
  "vr_garantia_10" numeric(16,2),
  "vr_garantia_11" numeric(16,2),
  "vr_garantia_12" numeric(16,2),
  "vr_garantia_13" numeric(16,2),
  "vr_garantia_14" numeric(16,2),
  "vr_garantia_15" numeric(16,2),
  "vr_garantia_16" numeric(16,2),
  "vr_garantia_17" numeric(16,2),
  "vr_garantia_18" numeric(16,2),
  "vr_garantia_19" numeric(16,2),
  "vr_garantia_20" numeric(16,2),
  "sg_sistema_origem" varchar(5) COLLATE "pg_catalog"."default",
  "no_arquivo" varchar(100) COLLATE "pg_catalog"."default",
  "ts_processamento" date,
  "dt_referencia" date,
  "ic_ativo" bool DEFAULT true
)
;

COMMENT ON COLUMN "acgsm001"."acgtbs01_contrato"."co_operacao_contrato" IS 'Código do produto para a qual foi realizada a operação de contratação.';
COMMENT ON COLUMN "acgsm001"."acgtbs01_contrato"."co_identificador_contrato" IS 'Código completo de identificação do contrato. contempla a concatenação da unidade, operação, código do contrato e DV.';
COMMENT ON COLUMN "acgsm001"."acgtbs01_contrato"."dt_contrato" IS 'Data da assinatura do contrato.';
COMMENT ON COLUMN "acgsm001"."acgtbs01_contrato"."dt_concessao_operacao" IS 'Data da liberação do crédito para o cliente.';
COMMENT ON COLUMN "acgsm001"."acgtbs01_contrato"."no_cliente" IS 'Nome ou razação social do principal tomador da operação contratada.';
COMMENT ON COLUMN "acgsm001"."acgtbs01_contrato"."co_identificador_cliente" IS 'Código do documento de identificação do cliente que realizou a contratação (CPF ou CNPJ ).';
COMMENT ON COLUMN "acgsm001"."acgtbs01_contrato"."vr_contrato" IS 'Valor bruto da contratação.';
COMMENT ON COLUMN "acgsm001"."acgtbs01_contrato"."vr_comprometido" IS 'Valor comprometido ou liberado na operação. Trata-se do valor líquido para o SIEMP.';
COMMENT ON COLUMN "acgsm001"."acgtbs01_contrato"."vr_ultima_prestacao" IS 'Valor da última prestação aberta.';
COMMENT ON COLUMN "acgsm001"."acgtbs01_contrato"."sg_sistema_origem" IS 'Sigla do sistema de origem dos contratos.

Ex: SIDEC, SIAPI, SIFBN, SIEMP';
COMMENT ON TABLE "acgsm001"."acgtbs01_contrato" IS 'Staging Area com informações de contratos importadas dos arquivos de interface SIDEC, SIAPI, SIFBN e SIEMP.';
-- ###############   Tabela: acgtbs01_contrato

-- ###############   Tabela: acgtbs08_duplicata
CREATE TABLE "acgsm001"."acgtbs08_duplicata" (
  "co_cedente" varchar(16) COLLATE "pg_catalog"."default",
  "co_identificador_cedente" varchar(14) COLLATE "pg_catalog"."default",
  "no_cedente" varchar(50) COLLATE "pg_catalog"."default",
  "co_identificador_sacado" varchar(14) COLLATE "pg_catalog"."default",
  "no_sacado" varchar(50) COLLATE "pg_catalog"."default",
  "no_carteira" varchar(10) COLLATE "pg_catalog"."default",
  "co_titulo" varchar(17) COLLATE "pg_catalog"."default",
  "vr_titulo" numeric(11,2),
  "co_cancelamento" varchar(4) COLLATE "pg_catalog"."default",
  "dt_liquidacao" date,
  "vr_pago" numeric(11,2),
  "co_situacao_titulo" char(2) COLLATE "pg_catalog"."default",
  "ic_protesto" char(3) COLLATE "pg_catalog"."default",
  "co_tipo_titulo" char(2) COLLATE "pg_catalog"."default",
  "dt_vencimento" date,
  "dt_entrada" date,
  "dt_situacao" date,
  "dt_movimento" date,
  "sg_sistema_origem" varchar(5) COLLATE "pg_catalog"."default",
  "co_especie_titulo" char(2) COLLATE "pg_catalog"."default",
  "no_arquivo" varchar(100) COLLATE "pg_catalog"."default",
  "ts_processamento" date,
  "dt_referencia" date,
  "ic_ativo" bool DEFAULT true
)
;

COMMENT ON COLUMN "acgsm001"."acgtbs08_duplicata"."co_identificador_cedente" IS 'CPF / CNPJ do Cedente.';
COMMENT ON COLUMN "acgsm001"."acgtbs08_duplicata"."co_identificador_sacado" IS 'CPF/CNPJ';
COMMENT ON COLUMN "acgsm001"."acgtbs08_duplicata"."co_titulo" IS 'Campo NUMERO do arquivo.';
COMMENT ON TABLE "acgsm001"."acgtbs08_duplicata" IS 'Tabela de Stage Area que armazena as informações de duplicatas referentes aos arquivos de interface do SIGCB e SICOB.';
-- ###############   Tabela: acgtbs08_duplicata

-- ###############   Tabelas a serem Apagadas
-- DROP TABLE acgsm001.acgtb054_log_servico_saldo;
-- DROP TABLE acgsm001.acgtb058_modalidade;
-- DROP TABLE acgsm001.acgtb062_sgmno_prdto;
-- DROP TABLE acgsm001.acgtb063_sistema;
-- DROP TABLE acgsm001.acgtb057_produto;


-- ###############   Tabela: acgtb051_ctrto_comercializacao
ALTER TABLE "acgsm001"."acgtb051_comercializacao" RENAME COLUMN "nu_comercializacao" TO "nu_ctrto_comercializacao";
-- ###############   Tabela: acgtb051_ctrto_comercializacao

-- ###############   Tabela: acgtb064_proponente_habitaciona
-- Colunas a serem adicionadas
ALTER TABLE "acgsm001"."acgtb064_proponente_habitaciona" ADD COLUMN "nu_ctrto_comercializacao" int8 NOT NULL DEFAULT nextval('"acgsm001".acgsq051_comercializacao'::regclass);
COMMENT ON COLUMN "acgsm001"."acgtb064_proponente_habitaciona"."nu_ctrto_comercializacao" IS 'Identificador únido';

-- Colunas a serem deletadas
ALTER TABLE "acgsm001"."acgtb064_proponente_habitaciona" DROP COLUMN "nu_comercializacao";
-- ###############   Tabela: acgtb064_proponente_habitaciona

-- ###############   Tabelas com Nomes ERRADOS
ALTER TABLE acgsm001.acgtb051_comercializacao RENAME TO acgtb051_ctrto_comercializacao;
ALTER TABLE acgsm001.acgtb064_proponente_habitaciona RENAME TO acgtb063_proponente_habitacional;
