/*============================================================*/
/*           SCRIPT V2_13_0_01__SIACG_DML		              */
/*============================================================*/

UPDATE acgsm001.acgtb017_propriedade SET no_valor_propriedade='58' WHERE no_propriedade='bloqueio.tipo';

INSERT INTO acgsm001.acgtb017_propriedade(no_propriedade, no_valor_propriedade, no_grupo, de_comentario)
VALUES ('desbloqueio.cl_dv', '86', 'bloqueio', 'Código de CL para utilização na comunicação com o SID00, durante desbloqueio');


/*============================================================*/
/* Revert 								                      */
/*============================================================*/
--UPDATE acgsm001.acgtb017_propriedade SET no_valor_propriedade='80' WHERE no_propriedade='bloqueio.tipo';
--DELETE FROM acgsm001.acgtb017_propriedade WHERE no_propriedade = 'desbloqueio.cl_dv';