ALTER TABLE acgsm001.acgtb053_recebido ADD COLUMN ic_situacao_recebido boolean NOT NULL DEFAULT false;
ALTER TABLE acgsm001.acgtb053_recebido ADD COLUMN ts_inativacao timestamp without time zone;
ALTER TABLE acgsm001.acgtb053_recebido ADD COLUMN de_inativacao character varying(255);

COMMENT ON COLUMN acgsm001.acgtb053_recebido.ic_situacao_recebido IS 'Se o recebido está ativo TRUE ou inativo FALSE.';
COMMENT ON COLUMN acgsm001.acgtb053_recebido.ts_inativacao IS 'Data e hora da inativação do registro.';
COMMENT ON COLUMN acgsm001.acgtb053_recebido.de_inativacao IS 'Justificaticativa para a inativação do registro.';
