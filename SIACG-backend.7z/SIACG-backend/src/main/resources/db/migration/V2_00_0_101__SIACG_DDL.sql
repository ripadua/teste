/*==============================================================*/
/*           SCRIPT V2_00_0_101__SIACG_DLL						*/
/*==============================================================*/

/*==============================================================*/
/* Table: acgsm001.acgtb109_undde_hbtcl_historico               */
/*==============================================================*/

create sequence acgsm001.sq109_undde_hbtcl_historico;

create table acgsm001.acgtb109_undde_hbtcl_historico (
   nu_historico         integer              not null default nextval('acgsm001.sq109_undde_hbtcl_historico'::regclass),
   nu_prmto_comercializao bigint               null,
   co_responsavel       character varying(7) not null,
   dt_alteracao         date                 not null,
   de_prospecto         json                 null,
   ic_acao              integer              not null default '1'
   constraint ckc_acgtb109_01 check (ic_acao in ('1','2','3')),
   constraint pk_acgtb109_undde_hbtcl_histor primary key (nu_historico)
);

comment on table acgsm001.acgtb109_undde_hbtcl_historico is
'Tabela que irá armazenar os históricos (inclusão, alteração, exclusão) oriundos da tabela de unidade habitacional.';

comment on column acgsm001.acgtb109_undde_hbtcl_historico.nu_historico is
'Identificador da tabela de histórico';

comment on column acgsm001.acgtb109_undde_hbtcl_historico.nu_prmto_comercializao is
'Identificador unico';

comment on column acgsm001.acgtb109_undde_hbtcl_historico.co_responsavel is
'Matrícula do responsável pela alteração';

comment on column acgsm001.acgtb109_undde_hbtcl_historico.dt_alteracao is
'Data de alteração do registro';

comment on column acgsm001.acgtb109_undde_hbtcl_historico.de_prospecto is
'Json que irá armazenar as alterações vinculadas ao prospecto';

comment on column acgsm001.acgtb109_undde_hbtcl_historico.ic_acao is
'Define as ações que irão gerar o histórico, podendo ser:
1 - Inclusão,
2 - Alteração,
3 - Exclusão';

alter table acgsm001.acgtb109_undde_hbtcl_historico  add constraint fk_acgtb109_acgtb052 
foreign key (nu_prmto_comercializao) references acgsm001.acgtb052_prmto_comercializacao (nu_prmto_comercializao) on delete restrict on update restrict;

/*===========================================================================*/
/* Table: acgsm001.acgtb037_destinatario		                			 */
/* #156120 - Alteração de destinatário nas rotinas do SIACG que mandam email */       
/*===========================================================================*/      
      
alter table acgsm001.acgtb037_destinatario DROP CONSTRAINT ckc_ic_tipo_destinatario_acgtb036 ;
alter table acgsm001.acgtb037_destinatario ADD CONSTRAINT ckc_ic_tipo_destinatario_acgtb037 CHECK (ic_tipo_destinatario = ANY (ARRAY['01'::bpchar, '02'::bpchar, '03'::bpchar, '04'::bpchar]));

COMMENT ON COLUMN acgsm001.acgtb037_destinatario.ic_tipo_destinatario IS 'Identificador do tipo de destinatário, podendo ser:
01 - Gestor do Sistema
02 - Auditoria
03 - Gestor de Risco
04 - BI / Relatórios';


/*==============================================================*/
/* Reverse Table                                                */
/*==============================================================*/
--drop table acgsm001.acgtb109_undde_hbtcl_historico;
--drop sequence acgsm001.sq109_undde_hbtcl_historico;
      
--alter table acgsm001.acgtb037_destinatario DROP CONSTRAINT ckc_ic_tipo_destinatario_acgtb037 ;
--alter table acgsm001.acgtb037_destinatario ADD CONSTRAINT ckc_ic_tipo_destinatario_acgtb036 CHECK (ic_tipo_destinatario = ANY (ARRAY['01'::bpchar, '02'::bpchar, '03'::bpchar]));
/*
COMMENT ON COLUMN acgsm001.acgtb037_destinatario.ic_tipo_destinatario IS 'Identificador do tipo de destinatário, podendo ser:
01 - Gestor do Sistema
02 - Auditoria
03 - Gestor de Risco';*/