--========================================
--Data: 04/12/2017
--Versão 1.17.00
--Descrição manutenção da base de dado para contemplar as funcionalidades da OS2804 Conformidade de garantia

--========================================

-- altera o nome da tabela empresa para pessoa
alter table acgsm001.acgtb003_empresa rename to acgtb003_pessoa;
	
-- altera o nome das colunas na tabela pessoa
alter table acgsm001.acgtb003_pessoa rename column nu_empresa to nu_pessoa;
alter table acgsm001.acgtb003_pessoa rename column no_empresa to no_pessoa;
alter table acgsm001.acgtb003_pessoa rename column nu_cnpj to nu_identificador_pessoa;

-- adiciona a coluna ic_tipo_pessoa na tabela pessoa
alter table acgsm001.acgtb003_pessoa add column ic_tipo_pessoa char(2) not null default 'PJ';


-- atualização dos comentarios tabela pessoa
COMMENT ON TABLE acgsm001.acgtb003_pessoa
  IS 'Informa os dados do cliente que possui contrato de operações de crédito com a CEF, podendo este cliente ser pessoa física ou jurídica';
COMMENT ON COLUMN acgsm001.acgtb003_pessoa.nu_pessoa IS 'Identificador da pessoa. Gerado automaticamente pelo sistema.';
COMMENT ON COLUMN acgsm001.acgtb003_pessoa.no_pessoa IS 'Informa o nome da pessoa física/jurídica.';
COMMENT ON COLUMN acgsm001.acgtb003_pessoa.nu_identificador_pessoa IS 'Informa o cnpj ou cpf da pessoa.';
COMMENT ON COLUMN acgsm001.acgtb003_pessoa.ic_alerta_endividamento IS 'Armazena o Alerta de Endividamento da Pessoa. Valores possíveis:
0 - Sem Alerta
1 - Alerta Amarelo
2 - Alerta Vermelho';
COMMENT ON COLUMN acgsm001.acgtb003_pessoa.ic_tipo_pessoa IS 'Informa qual é o tipo de pessoa: PF = Pessoa Física e PJ = Pessoa Jurídica';



-- altera nome da coluna nu_empresa para nu_pessoa nas tabelas que possuem relacionamento com pessoa
alter table acgsm001.acgtb001_contrato rename column nu_empresa to nu_pessoa;
COMMENT ON COLUMN acgsm001.acgtb001_contrato.nu_pessoa IS 'Identificador da pessoa física/juridica.';

alter table acgsm001.acgtb039_acompanhamento_endvto rename column nu_empresa to nu_pessoa;
COMMENT ON COLUMN acgsm001.acgtb039_acompanhamento_endvto.nu_pessoa IS 'Identificador da Pessoa';

alter table acgsm001.acgtb006_conta_corrente rename column nu_empresa to nu_pessoa;
COMMENT ON COLUMN acgsm001.acgtb006_conta_corrente.nu_pessoa IS 'Identificador da pessoa. Chave estrangeira.';

alter table acgsm001.acgtb027_custodia_cheque rename column nu_empresa to nu_pessoa;
COMMENT ON COLUMN acgsm001.acgtb027_custodia_cheque.nu_pessoa IS 'Identificador da pessoa que possui a custódia.  Chave estrangeira';

alter table acgsm001.acgtb004_cedente rename column nu_empresa to nu_pessoa;
COMMENT ON COLUMN acgsm001.acgtb004_cedente.nu_pessoa IS 'Identifica a pessoa. Chave estrangeira.';

alter table acgsm001.acgtb010_solicitacao_preanalise rename column nu_empresa to nu_pessoa;
COMMENT ON COLUMN acgsm001.acgtb010_solicitacao_preanalise.nu_pessoa IS 'Identificador da pessoa. Gerado automaticamente pelo sistema. Chave estrangeira.';

alter table acgsm001.acgtb046_historico_ftrmo_empsa rename column nu_empresa to nu_pessoa;
COMMENT ON TABLE acgsm001.acgtb046_historico_ftrmo_empsa
  IS 'Entidade responsável por manter o histórico de faturamento da pessoa juridica. A aplicação sempre irá cosiderar o registro mais atual para a pessoa juridica consultada.';


 
create table acgsm001.acgtb059_gestor_produto (
   nu_unidade_gestora   INT4                 not null,
   no_unidade_gestora   VARCHAR(120)         null,
   ic_gestor_siico      BOOL                 null default true,
   constraint PK_ACGTB059_GESTOR_PRODUTO primary key (nu_unidade_gestora)
);

comment on table acgsm001.acgtb059_gestor_produto is
'Gestores do produto, quanto a permissão da gestão do produto tem:
1- Gestor que recebeu permissão de gestão do produto no SIICO
2- Gestor que recebeu permissão de gestão no SIACG';

comment on column acgsm001.acgtb059_gestor_produto.ic_gestor_siico is
'Indica se o gestor recebeu a permissão de gestão do produto no SIICO';



--drop table acgsm001.acgtb063_sistema;

/*==============================================================*/
/* Table: acgtb063_sistema                                      */
/*==============================================================*/
create table acgsm001.acgtb063_sistema (
   nu_sistema           smallint             not null,
   sg_sistema           CHAR(8)              null,
   constraint PK_ACGTB063_SISTEMA primary key (nu_sistema)
);

comment on table acgsm001.acgtb063_sistema is
'Sistema o qual mantém o produto';

comment on column acgsm001.acgtb063_sistema.nu_sistema is
'Número identificador do sistema';

comment on column acgsm001.acgtb063_sistema.sg_sistema is
'Sigla do sistema que mantem o produto';


--drop table acgsm001.acgtb062_sgmno_prdto;

/*==============================================================*/
/* Table: acgtb062_sgmno_prdto                                  */
/*==============================================================*/
create table acgsm001.acgtb062_sgmno_prdto (
   nu_segmento          smallint             not null,
   no_segmento          VARCHAR(30)          null,
   constraint PK_ACGTB062_SGMNO_PRDTO primary key (nu_segmento)
);

comment on table acgsm001.acgtb062_sgmno_prdto is
'Segmento do produto';

comment on column acgsm001.acgtb062_sgmno_prdto.nu_segmento is
'Número do segmento de atendimento do produto';

comment on column acgsm001.acgtb062_sgmno_prdto.no_segmento is
'Nome do segmento de atendimento do produto';



--drop table acgsm001.acgtb058_modalidade;

/*==============================================================*/
/* Table: acgtb058_modalidade                                   */
/*==============================================================*/
create table acgsm001.acgtb058_modalidade (
   nu_modalidade        smallint             not null,
   no_modalidade        VARCHAR(50)          null,
   constraint PK_ACGTB058_MODALIDADE primary key (nu_modalidade)
);

comment on table acgsm001.acgtb058_modalidade is
'Modalidades do produto';

comment on column acgsm001.acgtb058_modalidade.nu_modalidade is
'Código da modalidade';

comment on column acgsm001.acgtb058_modalidade.no_modalidade is
'Nome da modalidade';

--drop index ix_acgsm001.acgtb057_01;

--drop table acgsm001.acgtb057_produto;

/*==============================================================*/
/* Table: acgtb057_produto                                      */
/*==============================================================*/
create table acgsm001.acgtb057_produto (
   nu_produto           smallint             not null,
   nu_modalidade        INT2                 not null,
   nu_unidade_gestora   smallint             not null,
   nu_garantia          int4                 not null,
   nu_segmento          smallint             not null,
   nu_sistema           smallint             not null,
   nu_produto_pai       smallint             null,
   nu_modalidade_pai    INT2                 null,
   no_comercial_prdto   VARCHAR(45)          null,
   no_produto           VARCHAR(120)         null,
   nu_operacao          smallint             not null,
   ic_aceita_garantia_terceiro BOOL                 null default False,
   co_ultima_situacao   CHAR(2)              null,
   de_homologacao       VARCHAR(255)         null,
   constraint PK_ACGTB057_PRODUTO primary key (nu_produto, nu_modalidade)
);

comment on table acgsm001.acgtb057_produto is
'Produto do segmento emprestimo, apto para contração conforme a parametrização de suas garantias';

comment on column acgsm001.acgtb057_produto.nu_produto is
'Identificador do produto';

comment on column acgsm001.acgtb057_produto.nu_modalidade is
'Código da modalidade';

comment on column acgsm001.acgtb057_produto.nu_unidade_gestora is
'identificador da unidade gestora';

comment on column acgsm001.acgtb057_produto.nu_garantia is
'Identificador do registro. Gerado automaticamente pelo sistema.';

comment on column acgsm001.acgtb057_produto.nu_segmento is
'Número do segmento de atendimento do produto';

comment on column acgsm001.acgtb057_produto.nu_sistema is
'Número identificador do sistema';

comment on column acgsm001.acgtb057_produto.nu_produto_pai is
'Produto do segmento emprestimo que pode receber produtos do segmento do tipo aplicações e fundos de investimento';

comment on column acgsm001.acgtb057_produto.nu_modalidade_pai is
'Código da modalidade';

comment on column acgsm001.acgtb057_produto.no_comercial_prdto is
'Nome comercial do produto';

comment on column acgsm001.acgtb057_produto.no_produto is
'Nome do produto';

comment on column acgsm001.acgtb057_produto.nu_operacao is
'Código da operação do produto';

comment on column acgsm001.acgtb057_produto.ic_aceita_garantia_terceiro is
'indicador de aceite de garantia de terceiro';

comment on column acgsm001.acgtb057_produto.co_ultima_situacao is
'Código da situação do produto';

comment on column acgsm001.acgtb057_produto.de_homologacao is
'Justificaticativa homologação gestor GEGAR';


/*==============================================================*/
/* Index: ix_acgtb057_01                                        */
/*==============================================================*/
CREATE UNIQUE INDEX ix_acgtb057_01
  ON acgsm001.acgtb057_produto
  USING btree
  (nu_produto, nu_modalidade, nu_produto_pai, nu_modalidade_pai);


alter table acgsm001.acgtb057_produto
   add constraint FK_ACGTB057_ACGTB011 foreign key (nu_garantia)
      references acgsm001.acgtb011_garantia (nu_garantia)
      on delete restrict on update restrict;


alter table acgsm001.acgtb057_produto
   add constraint FK_ACGTB057_ACGTB058 foreign key (nu_modalidade)
      references acgsm001.acgtb058_modalidade (nu_modalidade)
      on delete restrict on update restrict;

alter table acgsm001.acgtb057_produto
   add constraint FK_ACGTB057_ACGTB059 foreign key (nu_unidade_gestora)
      references acgsm001.acgtb059_gestor_produto (nu_unidade_gestora)
      on delete restrict on update restrict;

alter table acgsm001.acgtb057_produto
   add constraint FK_ACGTB057_ACGTB062 foreign key (nu_segmento)
      references acgsm001.acgtb062_sgmno_prdto (nu_segmento)
      on delete restrict on update restrict;

alter table acgsm001.acgtb057_produto
   add constraint FK_ACGTB057_ACGTB057 foreign key (nu_produto_pai, nu_modalidade_pai)
      references acgsm001.acgtb057_produto (nu_produto, nu_modalidade)
      on delete restrict on update restrict;

alter table acgsm001.acgtb057_produto
   add constraint FK_ACGTB057_ACGTB063 foreign key (nu_sistema)
      references acgsm001.acgtb063_sistema (nu_sistema)
      on delete restrict on update restrict;

	  
-- adiciona colunas no contrato
alter table acgsm001.acgtb001_contrato add column ic_categoria         char(1)              not null default '1'
      constraint CKC_IC_CATEGORIA_ACGTB001 check (ic_categoria in ('1','2'));
	  
alter table acgsm001.acgtb001_contrato add column ic_forma_inclusao    CHAR(1)              not null default '1'
      constraint CKC_IC_FORMA_INCLUSAO_ACGTB001 check (ic_forma_inclusao in ('1','2','3','4'));

alter table acgsm001.acgtb001_contrato add column  nu_produto           smallint                 null;
alter table acgsm001.acgtb001_contrato add column   nu_modalidade        smallint                 null;
ALTER TABLE acgsm001.acgtb001_contrato ADD COLUMN nu_produto_pai smallint;
ALTER TABLE acgsm001.acgtb001_contrato ADD COLUMN nu_modalidade_pai smallint;

-- Inclusão da fk nu_modalidade, nu_produto tabela contrato
ALTER TABLE acgsm001.acgtb001_contrato
  ADD CONSTRAINT fk_acgtb001_acgtb058 FOREIGN KEY (nu_produto, nu_modalidade, nu_produto_pai, nu_modalidade_pai)
      REFERENCES acgsm001.acgtb057_produto (nu_produto, nu_modalidade, nu_produto_pai, nu_modalidade_pai) MATCH SIMPLE
      ON UPDATE RESTRICT ON DELETE RESTRICT;

	 
	 	  
--drop index ix_acgtb060_01;

--drop table acgsm001.acgtb060_garantia_produto cascade;

/*==============================================================*/
/* Table: acgtb060_garantia_produto                             */
/*==============================================================*/
CREATE TABLE acgsm001.acgtb060_garantia_produto
(
  nu_garantia_produto integer NOT NULL, -- Codigo da garantia do produto
  nu_produto smallint, -- Indentificador da tabela produto
  nu_modalidade smallint,
  vr_prazo_minimo integer NOT NULL, -- Valor do prazo minimo da garantia
  vr_prazo_maximo integer NOT NULL, -- Valor do prazo maximo da garantia
  vr_minimo numeric(16,2) NOT NULL, -- Valor minimo aceito para garantia
  vr_maximo numeric(16,2) NOT NULL, -- Valor máximo aceito para garantia
  vr_percentual_minimo numeric(16,2) NOT NULL, -- Valor do percentual minimo para bloqueio garantia
  vr_percentual_maximo numeric(16,2) NOT NULL, -- Valor do percentual  maximo para bloqueio garantia
  ic_forma_bloqueio character(1) NOT NULL, -- Indica a forma de bloqueio. 1- SD (saldo devedor), 2- PMT (Parcela), 3- VC (Valor Contrato)
  ic_homologacao boolean, -- Indica se os parametros cadastrados foram homologados pelo Gestor
  nu_produto_pai smallint NOT NULL, -- Código do Produto Pai
  nu_modalidade_pai smallint NOT NULL, -- Código da Modalidade Pai
  nu_ordem_bloqueio character(4), -- Ordem de prioridade de bloqueio da garantia
  nu_ordem_desbloqueio character(4), -- Ordem de prioridade de desbloqueio da grantia
  CONSTRAINT pk_acgtb060_garantia_produto PRIMARY KEY (nu_garantia_produto),
  CONSTRAINT ckc_ic_forma_bloqueio_acgtb060 CHECK (ic_forma_bloqueio in ('1','2','3'))
);

COMMENT ON TABLE acgsm001.acgtb060_garantia_produto
  IS 'Garantias do produto constituida por aplicações financeiras';
COMMENT ON COLUMN acgsm001.acgtb060_garantia_produto.nu_garantia_produto IS 'Codigo da garantia do produto';
COMMENT ON COLUMN acgsm001.acgtb060_garantia_produto.nu_produto IS 'Indentificador da tabela produto';
COMMENT ON COLUMN acgsm001.acgtb060_garantia_produto.vr_prazo_minimo IS 'Valor do prazo minimo da garantia';
COMMENT ON COLUMN acgsm001.acgtb060_garantia_produto.vr_prazo_maximo IS 'Valor do prazo maximo da garantia';
COMMENT ON COLUMN acgsm001.acgtb060_garantia_produto.vr_minimo IS 'Valor minimo aceito para garantia';
COMMENT ON COLUMN acgsm001.acgtb060_garantia_produto.vr_maximo IS 'Valor máximo aceito para garantia';
COMMENT ON COLUMN acgsm001.acgtb060_garantia_produto.vr_percentual_minimo IS 'Valor do percentual minimo para bloqueio garantia';
COMMENT ON COLUMN acgsm001.acgtb060_garantia_produto.vr_percentual_maximo IS 'Valor do percentual  maximo para bloqueio garantia';
COMMENT ON COLUMN acgsm001.acgtb060_garantia_produto.ic_forma_bloqueio IS 'Indica a forma de bloqueio. 1- SD (saldo devedor), 2- PMT (Parcela), 3- VC (Valor Contrato)';
COMMENT ON COLUMN acgsm001.acgtb060_garantia_produto.ic_homologacao IS 'Indica se os parametros cadastrados foram homologados pelo Gestor';
COMMENT ON COLUMN acgsm001.acgtb060_garantia_produto.nu_produto_pai IS 'Código do Produto Pai';
COMMENT ON COLUMN acgsm001.acgtb060_garantia_produto.nu_modalidade_pai IS 'Código da Modalidade Pai';
COMMENT ON COLUMN acgsm001.acgtb060_garantia_produto.nu_ordem_bloqueio IS 'Ordem de prioridade de bloqueio da garantia';
COMMENT ON COLUMN acgsm001.acgtb060_garantia_produto.nu_ordem_desbloqueio IS 'Ordem de prioridade de desbloqueio da grantia';


-- Index: acgsm001.ix_acgtb060_01

-- DROP INDEX acgsm001.ix_acgtb060_01;

CREATE UNIQUE INDEX ix_acgtb060_01
  ON acgsm001.acgtb060_garantia_produto
  USING btree
  (nu_garantia_produto);

ALTER TABLE acgsm001.acgtb060_garantia_produto
  ADD CONSTRAINT fk_acgtb060_acgtb057 FOREIGN KEY (nu_produto, nu_modalidade, nu_produto_pai, nu_modalidade_pai)
      REFERENCES acgsm001.acgtb057_produto (nu_produto, nu_modalidade, nu_produto_pai, nu_modalidade_pai) MATCH SIMPLE
      ON UPDATE RESTRICT ON DELETE RESTRICT;
