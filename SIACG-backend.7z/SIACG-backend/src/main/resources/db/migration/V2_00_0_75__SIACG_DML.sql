/*==============================================================*/
/* Table: acgtb097_fonte_expressao                              */
/*==============================================================*/

INSERT INTO acgsm001.acgtb097_fonte_expressao(ic_tipo_expressao, no_fonte_expressao, de_expressao) VALUES (1, 'Valor Total Pago (Soma) - UH', 'Informar descrição aqui');
INSERT INTO acgsm001.acgtb097_fonte_expressao(ic_tipo_expressao, no_fonte_expressao, de_expressao) VALUES (1, 'Valor Total do Prospecto (Soma) - UH', 'Informar descrição aqui');
INSERT INTO acgsm001.acgtb097_fonte_expressao(ic_tipo_expressao, no_fonte_expressao, de_expressao) VALUES (1, 'Valor Atualizado da Tipologia - TP', 'Informar descrição aqui');
INSERT INTO acgsm001.acgtb097_fonte_expressao(ic_tipo_expressao, no_fonte_expressao, de_expressao) VALUES (1, 'Situação - UH', 'Informar descrição aqui');
INSERT INTO acgsm001.acgtb097_fonte_expressao(ic_tipo_expressao, no_fonte_expressao, de_expressao) VALUES (1, 'Hipotecada - UH', 'Informar descrição aqui');
INSERT INTO acgsm001.acgtb097_fonte_expressao(ic_tipo_expressao, no_fonte_expressao, de_expressao) VALUES (1, 'Código APF do Empreendimento - UH', 'Informar descrição aqui');
INSERT INTO acgsm001.acgtb097_fonte_expressao(ic_tipo_expressao, no_fonte_expressao, de_expressao) VALUES (1, 'Saldo Credor (Disponível) - CT', 'Informar descrição aqui');
INSERT INTO acgsm001.acgtb097_fonte_expressao(ic_tipo_expressao, no_fonte_expressao, de_expressao) VALUES (1, 'Saldo Devedor - CT', 'Informar descrição aqui');
INSERT INTO acgsm001.acgtb097_fonte_expressao(ic_tipo_expressao, no_fonte_expressao, de_expressao) VALUES (1, 'Valor Total da Garantia Extra - EP', 'Informar descrição aqui');

INSERT INTO acgsm001.acgtb097_fonte_expressao(ic_tipo_expressao, no_fonte_expressao, de_expressao, de_representacao) VALUES (3, 'mais', 'Informar descrição aqui', '+');
INSERT INTO acgsm001.acgtb097_fonte_expressao(ic_tipo_expressao, no_fonte_expressao, de_expressao, de_representacao) VALUES (3, 'menos', 'Informar descrição aqui', '-');
INSERT INTO acgsm001.acgtb097_fonte_expressao(ic_tipo_expressao, no_fonte_expressao, de_expressao, de_representacao) VALUES (3, 'dividido por', 'Informar descrição aqui', '/');
INSERT INTO acgsm001.acgtb097_fonte_expressao(ic_tipo_expressao, no_fonte_expressao, de_expressao, de_representacao) VALUES (3, 'multiplicado por', 'Informar descrição aqui', '*');
INSERT INTO acgsm001.acgtb097_fonte_expressao(ic_tipo_expressao, no_fonte_expressao, de_expressao, de_representacao) VALUES (3, 'e', 'Informar descrição aqui', '&&');
INSERT INTO acgsm001.acgtb097_fonte_expressao(ic_tipo_expressao, no_fonte_expressao, de_expressao, de_representacao) VALUES (3, 'ou', 'Informar descrição aqui', '||');
INSERT INTO acgsm001.acgtb097_fonte_expressao(ic_tipo_expressao, no_fonte_expressao, de_expressao, de_representacao) VALUES (3, 'não', 'Informar descrição aqui', '!');
INSERT INTO acgsm001.acgtb097_fonte_expressao(ic_tipo_expressao, no_fonte_expressao, de_expressao, de_representacao) VALUES (3, 'Abrir Parêntese', 'Informar descrição aqui', '(');
INSERT INTO acgsm001.acgtb097_fonte_expressao(ic_tipo_expressao, no_fonte_expressao, de_expressao, de_representacao) VALUES (3, 'Fechar Parêntese', 'Informar descrição aqui', ')');

INSERT INTO acgsm001.acgtb097_fonte_expressao(ic_tipo_expressao, no_fonte_expressao, de_expressao, de_representacao) VALUES (4, 'igual', 'Informar descrição aqui', '=');
INSERT INTO acgsm001.acgtb097_fonte_expressao(ic_tipo_expressao, no_fonte_expressao, de_expressao, de_representacao) VALUES (4, 'diferente', 'Informar descrição aqui', '!=');
INSERT INTO acgsm001.acgtb097_fonte_expressao(ic_tipo_expressao, no_fonte_expressao, de_expressao, de_representacao) VALUES (4, 'maior que', 'Informar descrição aqui', '>');
INSERT INTO acgsm001.acgtb097_fonte_expressao(ic_tipo_expressao, no_fonte_expressao, de_expressao, de_representacao) VALUES (4, 'maior ou igual a', 'Informar descrição aqui', '>=');
INSERT INTO acgsm001.acgtb097_fonte_expressao(ic_tipo_expressao, no_fonte_expressao, de_expressao, de_representacao) VALUES (4, 'menor que', 'Informar descrição aqui', '<');
INSERT INTO acgsm001.acgtb097_fonte_expressao(ic_tipo_expressao, no_fonte_expressao, de_expressao, de_representacao) VALUES (4, 'menor ou igual a', 'Informar descrição aqui', '<=');

INSERT INTO acgsm001.acgtb097_fonte_expressao(ic_tipo_expressao, no_fonte_expressao, de_expressao) VALUES (5, 'somatorio_uh(fonte*, cond)', 'Informar descrição aqui');