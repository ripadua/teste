 DROP TABLE IF EXISTS acgsm001.acgtb046_historico_ftrmo_empsa;
/*==============================================================*/
/* Versão 1.16.0		    07/12/2016                          */
/*==============================================================*/	

/*================================================================================*/
/* User Story 22247:Nova rotina de Cadastramento de Faturamento Clientes PJ       */
/*================================================================================*/

--drop index ix_acgtb046_02;
--drop index ix_acgtb046_01;
--drop table acgsm001.acgtb046_historico_ftrmo_empsa;

/*==============================================================*/
/* Table: acgtb046_historico_ftrmo_empsa                        */
/*==============================================================*/
create table acgsm001.acgtb046_historico_ftrmo_empsa (
   nu_historico_ftrmo_pessoa SERIAL               not null,
   nu_empresa           INT4                 not null,
   nu_segmento          int2                 null,
   vr_faturamento_apurado NUMERIC(16,2)        not null,
   ic_forma_apuracao    CHAR(1)              not null
      constraint CKC_IC_FORMA_APURACAO_ACGTB046 check (ic_forma_apuracao in ('R','C','B','G')),
   co_responsavel       CHAR(7)              not null,
   ts_atualizacao       TIMESTAMP            not null,
   constraint PK_ACGTB046_HISTORICO_FTRMO_EM primary key (nu_historico_ftrmo_pessoa)
);

comment on table acgsm001.acgtb046_historico_ftrmo_empsa is
'Entidade responsável por manter o histórico de faturamento da pessoa.
A aplicação sempre irá cosiderar o registro mais atual para a pessoa consultada.';

comment on column acgsm001.acgtb046_historico_ftrmo_empsa.nu_historico_ftrmo_pessoa is
'Número sequencial gerado automaticamente pelo sistema para identificação de um registro de faturamento da pessoa.';

comment on column acgsm001.acgtb046_historico_ftrmo_empsa.nu_empresa is
'Identificação da pessoa. Chave estrangeira da tabela acgtb003_empresa.';

comment on column acgsm001.acgtb046_historico_ftrmo_empsa.nu_segmento is
'Identificação do segmento.';

comment on column acgsm001.acgtb046_historico_ftrmo_empsa.vr_faturamento_apurado is
'Valor do faturamento fiscal anual apurado para a pessoa em um certo momento.
O valor pode ser inserido manualmente na parametrização do contrato, por rotina de consulta ao SICLI ou por dados do Bacen/SURIC.';

comment on column acgsm001.acgtb046_historico_ftrmo_empsa.ic_forma_apuracao is
'Forma de apuração do valor do faturamento da pessoa, baseado na origem das informações:

R - Informações de risco de crédito da Caixa (SIRIC)
C - Informações cadastrais da Caixa (SICLI)
B - Informações originadas do SCR BACEN (SISBACEN)
G - Informações gerenciais (Manual).';

comment on column acgsm001.acgtb046_historico_ftrmo_empsa.co_responsavel is
'Código de identificação (matrícula) do usuário responsável pela alteração das informações de faturamento da pessoa.
Para atualização de informações que sejam realizados de forma automatizada será incluído o código s000000.';

comment on column acgsm001.acgtb046_historico_ftrmo_empsa.ts_atualizacao is
'Data e hora de inclusão/atualização do faturamento da pessoa.';

/*==============================================================*/
/* Index: ix_acgtb046_01                                        */
/*==============================================================*/
create  index ix_acgtb046_01 on acgsm001.acgtb046_historico_ftrmo_empsa using BTREE (
nu_historico_ftrmo_pessoa
);

/*==============================================================*/
/* Index: ix_acgtb046_02                                        */
/*==============================================================*/
create  index ix_acgtb046_02 on acgsm001.acgtb046_historico_ftrmo_empsa using BTREE (
nu_empresa
);

alter table acgsm001.acgtb046_historico_ftrmo_empsa
   add constraint FK_ACGTB046_ACGTB003 foreign key (nu_empresa)
      references acgsm001.acgtb003_empresa (nu_empresa)
      on delete restrict on update restrict;

alter table acgsm001.acgtb046_historico_ftrmo_empsa
   add constraint FK_ACGTB046_FK_ACGTB0_ACGTB041 foreign key (nu_segmento)
      references acgsm001.acgtb041_segmento (nu_segmento)
      on delete restrict on update restrict;

/*==============================================================*/
/* Agendamento da rotina de consulta ao SICLI.                  */
/*==============================================================*/

insert into acgsm001.acgtb017_propriedade(
            no_propriedade, no_valor_propriedade, no_grupo, de_comentario)
    values ('agendamento.consulta.sicli.automatico', '0 0 8 * * 7', 'consulta.sicli.automatico', 'Agendamento da rotina responsável por atualizar o faturamento das pessoas com os dados do SICLI.');
