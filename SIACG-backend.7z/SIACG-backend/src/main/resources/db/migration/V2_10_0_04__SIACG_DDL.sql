/*============================================================*/
/*           SCRIPT V2_10_0_04__SIACG_DDL		              */
/*============================================================*/

ALTER TABLE acgsm001.acgtb081_imovel ADD COLUMN nu_identificador_avaliacao INT8;
ALTER TABLE acgsm001.acgtb081_imovel ADD COLUMN dh_consulta_dados_avaliacao TIMESTAMP;
ALTER TABLE acgsm001.acgtb081_imovel ADD COLUMN dh_consulta_dados_imovel TIMESTAMP;

comment on column acgsm001.acgtb081_imovel.nu_identificador_avaliacao is
'Número identificador da avaliação. É um número interno do SIOPI atribuído à solicitação de avaliação em andamento.';

comment on column acgsm001.acgtb081_imovel.dh_consulta_dados_avaliacao is
'Data e hora da última consulta aos dados da avaliação do imóvel, na api de habitação.';

comment on column acgsm001.acgtb081_imovel.dh_consulta_dados_imovel is
'Data e hora da última consulta aos dados do imóvel, na api de habitação.';

/*==============================================================*/
/* REVERT                                                       */
/*==============================================================*/ 
-- ALTER TABLE acgsm001.acgtb081_imovel DROP COLUMN nu_identificador_avaliacao;
-- ALTER TABLE acgsm001.acgtb081_imovel DROP COLUMN dh_consulta_dados_avaliacao;
-- ALTER TABLE acgsm001.acgtb081_imovel DROP COLUMN dh_consulta_dados_imovel;