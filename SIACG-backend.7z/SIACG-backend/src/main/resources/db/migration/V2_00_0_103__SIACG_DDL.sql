/*==============================================================*/
/*           SCRIPT V2_00_0_103__SIACG_DLL						*/
/*==============================================================*/

/*============================================================================*/
/* #156120 - Alteração de destinatário nas rotinas do SIACG que mandam email  */
/*============================================================================*/

ALTER TABLE acgsm001.acgtb037_destinatario DROP CONSTRAINT IF EXISTS ckc_ic_tipo_destinatario_acgtb037;
ALTER TABLE acgsm001.acgtb037_destinatario ADD CONSTRAINT ckc_ic_tipo_destinatario_acgtb037 CHECK (ic_tipo_destinatario = ANY (ARRAY['01'::bpchar, '02'::bpchar, '03'::bpchar, '04'::bpchar]));
COMMENT ON COLUMN acgsm001.acgtb037_destinatario.ic_tipo_destinatario IS 'Identificador do tipo de destinatário, podendo ser:
01 - Gestor do Sistema
02 - Auditoria
03 - Gestor de Risco
04 - BI / Relatórios';


CREATE SEQUENCE acgsm001.sq110_relatorio_destinatario
  INCREMENT 1
  MINVALUE 1
  MAXVALUE 9223372036854775807
  START 1
  CACHE 1;

CREATE TABLE IF NOT EXISTS acgsm001.acgtb110_relatorio_destinatario
(
  nu_relatorio_destinatario integer NOT NULL DEFAULT nextval('acgsm001.sq110_relatorio_destinatario'::regclass), -- Identificador do relatorios habilitados ao destinatario. Gerado automaticamente pelo sistema.
  nu_destinatario integer NOT NULL, -- Identificador do destinatario. Gerado automaticamente pelo sistema.
  ic_relatorio character(2) NULL, -- Identificador do relatorio.
  CONSTRAINT pk_acgtb110_relatorio_destinatario PRIMARY KEY (nu_relatorio_destinatario),
  CONSTRAINT fk_acgtb110_acgtb037 FOREIGN KEY (nu_destinatario)
      REFERENCES acgsm001.acgtb037_destinatario (nu_destinatario) MATCH SIMPLE
      ON UPDATE RESTRICT ON DELETE RESTRICT
)
WITH (
  OIDS=FALSE
);
COMMENT ON COLUMN acgsm001.acgtb110_relatorio_destinatario.nu_relatorio_destinatario IS 'Identificador do relatorios habilitados ao destinatario. Gerado automaticamente pelo sistema.';
COMMENT ON COLUMN acgsm001.acgtb110_relatorio_destinatario.nu_destinatario IS 'Identificador do destinatario. Gerado automaticamente pelo sistema.';
COMMENT ON COLUMN acgsm001.acgtb110_relatorio_destinatario.ic_relatorio IS 'Identificador do relatorio, podendo ser:
01 - Relatório de contratos não parametrizados
02 - Relatório de contratos novos';

/*========================================*/
/* Script de reversão					  */
/*========================================*/

/*
ALTER TABLE acgsm001.acgtb037_destinatario DROP CONSTRAINT IF EXISTS ckc_ic_tipo_destinatario_acgtb037;
ALTER TABLE acgsm001.acgtb037_destinatario ADD CONSTRAINT ckc_ic_tipo_destinatario_acgtb037 CHECK (ic_tipo_destinatario = ANY (ARRAY['01'::bpchar, '02'::bpchar, '03'::bpchar]));
COMMENT ON COLUMN acgsm001.acgtb037_destinatario.ic_tipo_destinatario IS 'Identificador do tipo de destinatário, podendo ser:
01 - Gestor do Sistema
02 - Auditoria
03 - Gestor de Risco';
*/


-- DROP TABLE IF EXISTS acgsm001.acgtb110_relatorio_destinatario;
-- DROP SEQUENCE IF EXISTS acgsm001.sq110_relatorio_destinatario;