/*==============================================================*/
/* Table: acgsm001.acgtb094_gestao_tipo_despesa                 */
/*==============================================================*/

	
ALTER TABLE acgsm001.acgtb094_gestao_tipo_despesa
 	ADD COLUMN ic_situacao BOOLEAN NULL ;
	
	COMMENT ON COLUMN acgsm001.acgtb094_gestao_tipo_despesa.ic_situacao IS 'Situação do tipo Despesa se esta ativo';

/*==============================================================*/
/* Reverse: acgsm001.acgtb094_gestao_tipo_despesa               */
/*==============================================================*/


--ALTER TABLE acgsm001.acgtb094_gestao_tipo_despesa
--	DROP COLUMN ic_situacao BOOLEAN NULL ;
	
	
