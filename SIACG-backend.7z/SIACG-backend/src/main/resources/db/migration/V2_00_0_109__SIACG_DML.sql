/*==============================================================*/
/*           SCRIPT V2_00_0_109__SIACG_DLL						*/
/*==============================================================*/


/* Gilberto Nery - 29-04-2020 - #114683 - Melhoria no tratamento de cedentes - Exclusão lógica	*/

alter table acgsm001.acgtb004_cedente add column ic_ativo boolean DEFAULT true;
COMMENT ON COLUMN acgsm001.acgtb004_cedente.ic_ativo IS 'Caso verdadeiro informa que o cedente está ativo, caso falso informa que o cedente foi excluido e não está vinculado a nenhum contrato';


/* Ludemeula Fernandes - 29-04-2020 - #164265 */

alter table acgsm001.acgtb001_contrato add column de_justificativa_reabertura TEXT;
alter table acgsm001.acgtb001_contrato add column dt_reabertura_contrato DATE;

comment on column acgsm001.acgtb001_contrato.de_justificativa_reabertura is
'Responsável por armazenar a justificativa de reabertura manual do contrato.
Este campo será manipulado através da aplicação, na funcionalidade de reabertura de contratos.';

comment on column acgsm001.acgtb001_contrato.dt_reabertura_contrato is
'Responsável por armazenar a data de reabertura manual do contrato.
Este campo será manipulado através da aplicação, na funcionalidade de reabertura de contratos.';


/*========================================*/
/* Script de reversão					  */
/*========================================*/
--alter table acgsm001.acgtb004_cedente drop column ic_ativo;

--alter table acgsm001.acgtb001_contrato drop column de_justificativa_reabertura;
--alter table acgsm001.acgtb001_contrato drop column dt_reabertura_contrato; 
