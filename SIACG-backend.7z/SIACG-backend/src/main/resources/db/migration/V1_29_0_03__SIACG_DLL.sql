DROP SEQUENCE IF EXISTS acgsm001.sq054_bloqueio;
  
DROP TABLE acgsm001.acgtb054_bloqueio;
  
CREATE TABLE acgsm001.acgtb054_acao_preventiva
(
  nu_acao_preventiva integer NOT NULL, 
  co_responsavel_bloqueio character varying(7) NOT NULL,
  dt_bloqueio date NOT NULL,
  nu_log_servico_saldo_bloqueio integer, 
  dt_desbloqueio date,
  co_responsavel_desbloqueio character varying(7),
  co_chave_desbloqueio character varying(20),
  nu_log_servico_saldo_desbloqueio integer, 
  nu_conta character varying(20), 
  nu_agencia_conta character varying(10), 
  nu_operacao_conta character varying(6), 
  nu_dv_conta character varying(1),
  nu_aplicacao_financeira integer,
  nu_veiculo bigint,
  co_garantia_bacen character varying(4),
  nu_contrato bigint NOT NULL, 
  nu_agencia_contrato integer NOT NULL, 
  nu_operacao_contrato integer NOT NULL, 
  nu_dv_contrato integer NOT NULL,
  CONSTRAINT pk_acgtb054_acao_preventiva PRIMARY KEY (nu_acao_preventiva)
);


COMMENT ON COLUMN acgsm001.acgtb054_acao_preventiva.nu_acao_preventiva IS 'Identificador unico da tabela preenchido por sequence.';
COMMENT ON COLUMN acgsm001.acgtb054_acao_preventiva.co_responsavel_bloqueio IS 'Matricula do usuario que fez a opera��o de bloqueio ';
COMMENT ON COLUMN acgsm001.acgtb054_acao_preventiva.dt_bloqueio IS 'Data da efetivacao do bloqueio.';
COMMENT ON COLUMN acgsm001.acgtb054_acao_preventiva.nu_log_servico_saldo_bloqueio IS 'Log gerado da entrada e saida do resultado do servico de bloqueio';
COMMENT ON COLUMN acgsm001.acgtb054_acao_preventiva.dt_desbloqueio IS 'Data de Desbloqueio';
COMMENT ON COLUMN acgsm001.acgtb054_acao_preventiva.co_responsavel_desbloqueio IS 'Matricula do usuario que fez a operacao de desbloqueio';
COMMENT ON COLUMN acgsm001.acgtb054_acao_preventiva.co_chave_desbloqueio IS 'Chave necessaria para executar a operacao de desbloqueio, chave pode ser retornada pelo sistema de origem ou gerada pelo SIACG';
COMMENT ON COLUMN acgsm001.acgtb054_acao_preventiva.nu_log_servico_saldo_desbloqueio IS 'Log gerado da entrada e saida do resultado do servico de desbloqueio';
COMMENT ON COLUMN acgsm001.acgtb054_acao_preventiva.nu_conta IS 'Numero da conta bloqueada';
COMMENT ON COLUMN acgsm001.acgtb054_acao_preventiva.nu_agencia_conta IS 'Agencia da conta bloqueada';
COMMENT ON COLUMN acgsm001.acgtb054_acao_preventiva.nu_operacao_conta IS 'Operacao da conta bloqueada';
COMMENT ON COLUMN acgsm001.acgtb054_acao_preventiva.nu_dv_conta IS 'Digito da conta bloqueada';
COMMENT ON COLUMN acgsm001.acgtb054_acao_preventiva.nu_aplicacao_financeira IS 'Identificador da aplicacao financeira bloqueada';
COMMENT ON COLUMN acgsm001.acgtb054_acao_preventiva.nu_veiculo IS 'Identificador do veiculo bloqueada';
COMMENT ON COLUMN acgsm001.acgtb054_acao_preventiva.co_garantia_bacen IS 'Codigo da garantia Bacen de como a garantia foi usada ';
COMMENT ON COLUMN acgsm001.acgtb054_acao_preventiva.nu_contrato IS 'Numero do Contrato que esta bloqueando a garantia';
COMMENT ON COLUMN acgsm001.acgtb054_acao_preventiva.nu_agencia_contrato IS 'Numero da Agencia do contrato que esta bloqueando a garantia';
COMMENT ON COLUMN acgsm001.acgtb054_acao_preventiva.nu_operacao_contrato IS 'Numero da operacao do Contrato que esta bloqueando a garantia';
COMMENT ON COLUMN acgsm001.acgtb054_acao_preventiva.nu_dv_contrato IS 'Numero do digito do Contrato que esta bloqueando a garantia';

CREATE SEQUENCE acgsm001.sq054_acao_preventiva   INCREMENT 1   MINVALUE 1  MAXVALUE 9223372036854775807  START 1  CACHE 1;

GRANT ALL ON SEQUENCE acgsm001.sq054_acao_preventiva TO postgres;

ALTER TABLE acgsm001.acgtb054_acao_preventiva  OWNER TO postgres;