/*==============================================================*/
/* SCRIPT V2_00_0_35__SIACG_DLL									*/
/*==============================================================*/


-- **********************************************************  
-- ==> Script para criação de tabela usada pelo Pentaho
-- **********************************************************


CREATE TABLE IF NOT EXISTS acgsm002.acgtbx01_controla_fluxo 
(
  nu_linha integer
);

--Atualiza comentário de coluna:
COMMENT ON COLUMN acgsm001.acgtb030_cartao_credito.ic_situacao IS 'Situação do movimento, podendo ser:
01 - Fluxo
02 - Estoque';