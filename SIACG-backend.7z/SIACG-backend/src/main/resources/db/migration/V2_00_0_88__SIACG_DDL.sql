/*==============================================================*/
/*           SCRIPT V2_00_0_88__SIACG_DLL						*/
/*==============================================================*/

/*==============================================================*/
/* Table: acgsm001.acgtb106_bem_cliente                         */
/*==============================================================*/

create sequence acgsm001.sq106_bem_cliente;
create table acgsm001.acgtb106_bem_cliente (
   nu_bem_cliente       integer                 not null default nextval('acgsm001.sq106_bem_cliente'::regclass),
   ic_tipo_bem          smallint                 not null constraint ckc_acgtb106_01 check (ic_tipo_bem in (1,2,3)),
   ic_situacao_bem      smallint                 not null default 1 constraint ckc_acgtb106_02 check (ic_situacao_bem in (1,2,3,4,5)),
   nu_pessoa            integer              ,
   nu_maquina_equipamento integer             ,
   nu_imovel            integer              ,
   nu_veiculo           integer              ,
   constraint pk_acgtb106_bem_cliente primary key (nu_bem_cliente)
);

comment on table acgsm001.acgtb106_bem_cliente is 'Tabela que representa os bens do cliente e que serão utilizados na parametrização de garantias.';

comment on column acgsm001.acgtb106_bem_cliente.nu_bem_cliente is 'Representa o identificador do bem do cliente.';

comment on column acgsm001.acgtb106_bem_cliente.ic_tipo_bem is
'Define o tipo do bem, podendo ser:
1 - Imóveis
2 - Maquinas e Equipamentos,
3 - Veículos';

comment on column acgsm001.acgtb106_bem_cliente.ic_situacao_bem is
'Define a situação de execução do bem, podendo ser:
1 - Sem Execução,
2 - Em Execução,
3 - Em Averbação,
4 - Conformidade
5 - Consolidação';


comment on column acgsm001.acgtb106_bem_cliente.nu_pessoa is 'Identificador da tablea acgt003_pessoa.';

comment on column acgsm001.acgtb106_bem_cliente.nu_maquina_equipamento is 'Identificador da tabela maquinas_equipamentos.';

comment on column acgsm001.acgtb106_bem_cliente.nu_imovel is 'Identificador da tabela imovel';

comment on column acgsm001.acgtb106_bem_cliente.nu_veiculo is 'Identificador da tabela de veículo';

alter table acgsm001.acgtb106_bem_cliente add constraint fk_acgtb106_acgtb077 foreign key (nu_maquina_equipamento)
      references acgsm001.acgtb077_maquina_equipamento (nu_maquina_equipamento) on delete restrict on update restrict;

alter table acgsm001.acgtb106_bem_cliente add constraint fk_acgtb106_acgtb081 foreign key (nu_imovel)
      references acgsm001.acgtb081_imovel (nu_imovel) on delete restrict on update restrict;

alter table acgsm001.acgtb106_bem_cliente add constraint fk_acgtb106_acgtb075 foreign key (nu_veiculo)
      references acgsm001.acgtb075_veiculo (nu_veiculo) on delete restrict on update restrict;
      

alter table acgsm001.acgtb106_bem_cliente add constraint fk_acgtb106_acgtb003 foreign key (nu_pessoa) 
	references acgsm001.acgtb003_pessoa (nu_pessoa)  on delete restrict on update restrict;


/*==============================================================*/
/* Table: acgsm001.acgtb107_contrato_bem_cliente                */
/*==============================================================*/
create table acgsm001.acgtb107_contrato_bem_cliente (
   nu_contrato          integer              not null,
   nu_bem_cliente       integer              not null,
   constraint pk_acgtb107_contrato_bem_clien primary key (nu_contrato, nu_bem_cliente)
);

comment on table acgsm001.acgtb107_contrato_bem_cliente is
'Tabela que irá armazenar os contratos vinculados ao bem do cliente: Imóvel, Máquinas/Equipamentos e Veículo.';

comment on column acgsm001.acgtb107_contrato_bem_cliente.nu_contrato is
'Identificador do contrato que estará vinculado ao bem';

comment on column acgsm001.acgtb107_contrato_bem_cliente.nu_bem_cliente is
'Representa o identificador do bem do cliente.';

alter table acgsm001.acgtb107_contrato_bem_cliente add constraint fk_acgtb107_acgtb001 foreign key (nu_contrato)
      references acgsm001.acgtb001_contrato (nu_contrato) on delete restrict on update restrict;

alter table acgsm001.acgtb107_contrato_bem_cliente add constraint fk_acgtb107_acgtb106 foreign key (nu_bem_cliente)
      references acgsm001.acgtb106_bem_cliente (nu_bem_cliente) on delete restrict on update restrict;
      
      
/*==============================================================*/
/* Table: acgsm001.acgtb075_veiculo                             */
/*==============================================================*/
alter table acgsm001.acgtb075_veiculo alter column de_cor                    drop not null;
alter table acgsm001.acgtb075_veiculo alter column ic_tipo_chassi            drop not null;
alter table acgsm001.acgtb075_veiculo alter column sg_uf_veiculo             drop not null;
alter table acgsm001.acgtb075_veiculo alter column ic_cpf_cnpj_vendedor      drop not null;
alter table acgsm001.acgtb075_veiculo alter column co_identificador_vendedor drop not null;
alter table acgsm001.acgtb075_veiculo alter column ic_tipo_restricao         drop not null;
alter table acgsm001.acgtb075_veiculo alter column ed_logradouro_origem      drop not null;
alter table acgsm001.acgtb075_veiculo alter column ed_numero_origem          drop not null;
alter table acgsm001.acgtb075_veiculo alter column ed_complemento_origem     drop not null;
alter table acgsm001.acgtb075_veiculo alter column ed_bairro_origem          drop not null;
alter table acgsm001.acgtb075_veiculo alter column co_municipio_origem       drop not null;
alter table acgsm001.acgtb075_veiculo alter column sg_uf_origem              drop not null;
alter table acgsm001.acgtb075_veiculo alter column ed_cep_origem             drop not null;
alter table acgsm001.acgtb075_veiculo alter column de_ddd_origem             drop not null;
alter table acgsm001.acgtb075_veiculo alter column de_telefone_origem        drop not null;
alter table acgsm001.acgtb075_veiculo alter column ic_identificador_cliente  drop not null;
alter table acgsm001.acgtb075_veiculo alter column ed_logradouro_cliente     drop not null;
alter table acgsm001.acgtb075_veiculo alter column ed_numero_cliente         drop not null;
alter table acgsm001.acgtb075_veiculo alter column ed_complemento_cliente    drop not null;
alter table acgsm001.acgtb075_veiculo alter column ed_bairro_cliente         drop not null;
alter table acgsm001.acgtb075_veiculo alter column co_municipio_cliente      drop not null;
alter table acgsm001.acgtb075_veiculo alter column sg_uf_cliente             drop not null;
alter table acgsm001.acgtb075_veiculo alter column ed_cep_cliente            drop not null;
alter table acgsm001.acgtb075_veiculo alter column de_ddd_cliente            drop not null;
alter table acgsm001.acgtb075_veiculo alter column de_telefone_cliente       drop not null;
alter table acgsm001.acgtb075_veiculo alter column no_nome_cliente           drop not null;
alter table acgsm001.acgtb075_veiculo alter column co_agencia                drop not null;
alter table acgsm001.acgtb075_veiculo alter column co_operacao               drop not null;
alter table acgsm001.acgtb075_veiculo alter column co_numero_conta           drop not null;
alter table acgsm001.acgtb075_veiculo alter column co_digito_conta           drop not null;
alter table acgsm001.acgtb075_veiculo alter column qt_meses_contrato         drop not null;
alter table acgsm001.acgtb075_veiculo alter column no_cidade_contrato        drop not null;
alter table acgsm001.acgtb075_veiculo alter column sg_uf_liberacao_operacao  drop not null;
alter table acgsm001.acgtb075_veiculo alter column no_indice                 drop not null;
alter table acgsm001.acgtb075_veiculo alter column co_matricula_cadastrou    drop not null;
alter table acgsm001.acgtb075_veiculo alter column co_matricula_autorizou    drop not null;

/*==============================================================*/
/* Table: acgtb108_garantia_bem_cliente                         */
/*==============================================================*/
create table acgsm001.acgtb108_garantia_bem_cliente (
   nu_bem_cliente       integer              not null,
   nu_garantia_contrato integer              not null,
   constraint pk_acgtb108_garantia_bem_clien primary key (nu_bem_cliente, nu_garantia_contrato)
);

comment on column  acgsm001.acgtb108_garantia_bem_cliente.nu_bem_cliente is
'Representa o identificador do bem do cliente.';

comment on column  acgsm001.acgtb108_garantia_bem_cliente.nu_garantia_contrato is
'Identificador da garantia do contrato. Gerado automaticamente pelo sistema.';

alter table  acgsm001.acgtb108_garantia_bem_cliente add constraint fk_acgtb108_acgtb009 foreign key (nu_garantia_contrato)
      references  acgsm001.acgtb009_garantia_contrato (nu_garantia_contrato) on delete restrict on update restrict;

alter table  acgsm001.acgtb108_garantia_bem_cliente add constraint fk_acgtb108_acgtb106 foreign key (nu_bem_cliente)
      references  acgsm001.acgtb106_bem_cliente (nu_bem_cliente) on delete restrict on update restrict;

      
/*==============================================================*/
/* Table: acgtb077_maquina_equipamento                          */
/*==============================================================*/      
ALTER TABLE acgsm001.acgtb077_maquina_equipamento ADD CONSTRAINT ckc_acgtb077_01 CHECK (ic_documento_comprobatorio is null or (ic_documento_comprobatorio in ('N','L')));
comment on column acgsm001.acgtb077_maquina_equipamento.ic_documento_comprobatorio is
'Tipos de documento comprobatorio, podendo ser:
N - Nota Fiscal,
L - Laudo de Avaliação';

/*==============================================================*/
/* Table: acgtb008_grupo_garantia                               */
/*==============================================================*/  
ALTER TABLE acgsm001.acgtb008_grupo_garantia ADD COLUMN  dt_tratar_acompanhamento DATE;
ALTER TABLE acgsm001.acgtb008_grupo_garantia ADD COLUMN  dt_corte_calculo_garantia DATE;
   
comment on column acgsm001.acgtb008_grupo_garantia.dt_tratar_acompanhamento is 'Data da garantia tratada como acompanhada';
comment on column acgsm001.acgtb008_grupo_garantia.dt_corte_calculo_garantia is 'Data de corte do calculo da garantia';

/*==============================================================*/
/* Revert Table: acgtb106_bem_cliente                           */
/*==============================================================*/
--drop table acgsm001.acgtb107_contrato_bem_cliente;
--drop table acgsm001.acgtb108_garantia_bem_cliente;
--drop table acgsm001.acgtb106_bem_cliente;
--drop sequence acgsm001.sq106_bem_cliente;

--alter table acgsm001.acgtb075_veiculo alter column de_cor                    set not null;
--alter table acgsm001.acgtb075_veiculo alter column ic_tipo_chassi            set not null;
--alter table acgsm001.acgtb075_veiculo alter column sg_uf_veiculo             set not null;
--alter table acgsm001.acgtb075_veiculo alter column ic_cpf_cnpj_vendedor      set not null;
--alter table acgsm001.acgtb075_veiculo alter column co_identificador_vendedor set not null;
--alter table acgsm001.acgtb075_veiculo alter column ic_tipo_restricao         set not null;
--alter table acgsm001.acgtb075_veiculo alter column ed_logradouro_origem      set not null;
--alter table acgsm001.acgtb075_veiculo alter column ed_numero_origem          set not null;
--alter table acgsm001.acgtb075_veiculo alter column ed_complemento_origem     set not null;
--alter table acgsm001.acgtb075_veiculo alter column ed_bairro_origem          set not null;
--alter table acgsm001.acgtb075_veiculo alter column co_municipio_origem       set not null;
--alter table acgsm001.acgtb075_veiculo alter column sg_uf_origem              set not null;
--alter table acgsm001.acgtb075_veiculo alter column ed_cep_origem             set not null;
--alter table acgsm001.acgtb075_veiculo alter column de_ddd_origem             set not null;
--alter table acgsm001.acgtb075_veiculo alter column de_telefone_origem        set not null;
--alter table acgsm001.acgtb075_veiculo alter column ic_identificador_cliente  set not null;
--alter table acgsm001.acgtb075_veiculo alter column ed_logradouro_cliente     set not null;
--alter table acgsm001.acgtb075_veiculo alter column ed_numero_cliente         set not null;
--alter table acgsm001.acgtb075_veiculo alter column ed_complemento_cliente    set not null;
--alter table acgsm001.acgtb075_veiculo alter column ed_bairro_cliente         set not null;
--alter table acgsm001.acgtb075_veiculo alter column co_municipio_cliente      set not null;
--alter table acgsm001.acgtb075_veiculo alter column sg_uf_cliente             set not null;
--alter table acgsm001.acgtb075_veiculo alter column ed_cep_cliente            set not null;
--alter table acgsm001.acgtb075_veiculo alter column de_ddd_cliente            set not null;
--alter table acgsm001.acgtb075_veiculo alter column de_telefone_cliente       set not null;
--alter table acgsm001.acgtb075_veiculo alter column no_nome_cliente           set not null;
--alter table acgsm001.acgtb075_veiculo alter column co_agencia                set not null;
--alter table acgsm001.acgtb075_veiculo alter column co_operacao               set not null;
--alter table acgsm001.acgtb075_veiculo alter column co_numero_conta           set not null;
--alter table acgsm001.acgtb075_veiculo alter column co_digito_conta           set not null;
--alter table acgsm001.acgtb075_veiculo alter column qt_meses_contrato         set not null;
--alter table acgsm001.acgtb075_veiculo alter column no_cidade_contrato        set not null;
--alter table acgsm001.acgtb075_veiculo alter column sg_uf_liberacao_operacao  set not null;
--alter table acgsm001.acgtb075_veiculo alter column no_indice                 set not null;
--alter table acgsm001.acgtb075_veiculo alter column co_matricula_cadastrou    set not null;
--alter table acgsm001.acgtb075_veiculo alter column co_matricula_autorizou    set not null;

--alter table acgsm001.acgtb077_maquina_equipamento drop column dt_documento_comprobatorio;
--alter table acgsm001.acgtb077_maquina_equipamento drop column ic_documento_comprobatorio;
   
--alter table acgsm001.acgtb008_grupo_garantia drop column  dt_tratar_acompanhamento;
--alter table acgsm001.acgtb008_grupo_garantia drop column  dt_corte_calculo_garantia;