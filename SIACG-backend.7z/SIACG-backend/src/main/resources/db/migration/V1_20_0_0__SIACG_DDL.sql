--========================================
--Data: 27/01/2018
--Versão 1.20.0
--Adequações no banco de dados para implementar ParametroProduto.
--========================================

ALTER TABLE acgsm001.acgtb057_produto DROP CONSTRAINT IF EXISTS fk_acgtb057_acgtb059;
  
DROP TABLE IF EXISTS acgsm001.acgtb059_gestor_produto;
DROP TABLE IF EXISTS acgsm001.acgtb060_parametro_garantia;
DROP TABLE IF EXISTS acgsm001.acgtb057_parametro_produto;

CREATE TABLE acgsm001.acgtb057_parametro_produto
(
  nu_produto smallint NOT NULL, -- Identificador do produto
  nu_modalidade smallint NOT NULL, -- Código da modalidade
  no_modalidade character varying(50), -- Nome da modalidade do produto
  ic_aceita_garantia_terceiro boolean DEFAULT false, -- indicador de aceite de garantia de terceiro
  de_homologacao character varying(255), -- Justificaticativa homologação gestor GEGAR
  co_produto_origem character varying(4),
  CONSTRAINT pk_acgtb057 PRIMARY KEY (nu_produto, nu_modalidade)
)
WITH (
  OIDS=FALSE
);
COMMENT ON TABLE acgsm001.acgtb057_parametro_produto IS 'Produto do segmento emprestimo, apto para contração conforme a parametrização de suas garantias';
COMMENT ON COLUMN acgsm001.acgtb057_parametro_produto.nu_produto IS 'Identificador do produto';
COMMENT ON COLUMN acgsm001.acgtb057_parametro_produto.nu_modalidade IS 'Código da modalidade';
COMMENT ON COLUMN acgsm001.acgtb057_parametro_produto.no_modalidade IS 'Nome da modalidade do produto';
COMMENT ON COLUMN acgsm001.acgtb057_parametro_produto.ic_aceita_garantia_terceiro IS 'indicador de aceite de garantia de terceiro';
COMMENT ON COLUMN acgsm001.acgtb057_parametro_produto.de_homologacao IS 'Justificaticativa homologação gestor GEGAR';

DROP MATERIALIZED VIEW IF EXISTS acgsm001.acgvw006_unidade;

CREATE MATERIALIZED VIEW acgsm001.acgvw006_unidade AS 
 WITH listagerenteunidade(nu_unidade, nu_matricula_h01) AS (
         SELECT un.nu_unidade,
            rsp.nu_matricula_h01
           FROM icosm001.icotbu24_unidade un
             JOIN icosm001.icotbh02_prdo_rspe rsp ON rsp.nu_unidade_u24 = un.nu_unidade AND rsp.nu_natural_u24 = un.nu_natural
          WHERE rsp.dt_fim IS NULL AND rsp.ic_eventual = 'S'::bpchar
        ), listatiposunidade(nu_tp_unidade_u21, sg_tipo_unidade) AS (
         SELECT icotbu21_tpunidade.nu_tipo_unidade,
            icotbu21_tpunidade.sg_tipo_unidade
           FROM icosm001.icotbu21_tpunidade
          WHERE icotbu21_tpunidade.dt_fim = '1760-01-01'::date
        )
 SELECT tabunidade.nu_unidade,
    tabunidade.nu_natural,
    tabunidade.no_unidade,
    tabunidade.sg_unidade,
    tabunidade.nu_cgc_unidade,
    tabunidade.dt_fim,
    tabunidade.nu_tp_unidade_u21,
    tabunidade.sg_uf_l22,
    tabunidade.sg_localizacao,
    tabtipounidade.sg_tipo_unidade,
        CASE
            WHEN tabunidade.nu_unidade = 5802 THEN tabunidade.no_unidade::text
            WHEN tabunidade.nu_tp_unidade_u21 = 12 THEN tabunidade.sg_unidade::text
            WHEN tabunidade.nu_tp_unidade_u21 = 22 THEN tabunidade.sg_unidade::text
            WHEN tabunidade.nu_tp_unidade_u21 = 23 THEN tabunidade.sg_unidade::text
            WHEN tabunidade.nu_tp_unidade_u21 = 28 THEN tabunidade.sg_unidade::text
            WHEN tabunidade.nu_tp_unidade_u21 = 38 THEN tabunidade.sg_unidade::text
            WHEN tabunidade.nu_tp_unidade_u21 = 37 THEN tabunidade.sg_unidade::text
            WHEN tabunidade.nu_tp_unidade_u21 = 41 THEN tabunidade.sg_unidade::text
            WHEN tabunidade.nu_tp_unidade_u21 = 43 THEN tabunidade.sg_unidade::text
            WHEN tabunidade.nu_tp_unidade_u21 = 44 THEN tabunidade.sg_unidade::text
            WHEN tabunidade.nu_tp_unidade_u21 = 46 THEN tabunidade.sg_unidade::text
            WHEN tabunidade.nu_tp_unidade_u21 = 5 THEN (tabunidade.sg_unidade::text || '/'::text) || tabunidade.sg_localizacao::text
            WHEN tabunidade.nu_tp_unidade_u21 = 14 THEN (tabunidade.sg_unidade::text || '/'::text) || tabunidade.sg_localizacao::text
            WHEN tabunidade.nu_tp_unidade_u21 = 15 THEN (tabunidade.sg_unidade::text || '/'::text) || tabunidade.sg_localizacao::text
            WHEN tabunidade.nu_tp_unidade_u21 = 16 THEN (tabunidade.sg_unidade::text || '/'::text) || tabunidade.sg_localizacao::text
            WHEN tabunidade.nu_tp_unidade_u21 = 29 THEN (tabunidade.sg_unidade::text || '/'::text) || tabunidade.sg_localizacao::text
            WHEN tabunidade.nu_tp_unidade_u21 = 30 THEN (tabunidade.sg_unidade::text || '/'::text) || tabunidade.sg_localizacao::text
            WHEN tabunidade.nu_tp_unidade_u21 = 48 THEN (tabunidade.sg_unidade::text || '/'::text) || tabunidade.sg_localizacao::text
            ELSE btrim((tabtipounidade.sg_tipo_unidade::text || ' '::text) || tabunidade.no_unidade::text, ' '::text)
        END AS nome_fantasia_unidade,
    tabresponsavel.nu_matricula_h01 AS gerente_unidade,
    'now'::text::date AS dt_materializacao
   FROM icosm001.icotbu24_unidade tabunidade
     LEFT JOIN listatiposunidade tabtipounidade ON tabtipounidade.nu_tp_unidade_u21 = tabunidade.nu_tp_unidade_u21
     LEFT JOIN listagerenteunidade tabresponsavel ON tabresponsavel.nu_unidade = tabunidade.nu_unidade
  WHERE tabunidade.dt_fim IS NULL AND tabunidade.ic_ultima_situacao = 'AT'::bpchar
WITH DATA;

COMMENT ON MATERIALIZED VIEW acgsm001.acgvw006_unidade IS 'View materializada com informações das unidades da Caixa que estão em situação ativa.';

DROP INDEX IF EXISTS acgsm001.ix_acgvw006_01;
CREATE INDEX ix_acgvw006_01
  ON acgsm001.acgvw006_unidade
  USING btree
  (nu_unidade);

DROP INDEX IF EXISTS acgsm001.ix_acgvw006_02;
CREATE INDEX ix_acgvw006_02
  ON acgsm001.acgvw006_unidade
  USING btree
  (nu_natural);

DROP INDEX IF EXISTS acgsm001.ix_acgvw006_03;
CREATE INDEX ix_acgvw006_03
  ON acgsm001.acgvw006_unidade
  USING btree
  (nu_unidade, nu_natural);

CREATE TABLE acgsm001.acgtb060_parametro_garantia
(
  nu_parametro_garantia integer NOT NULL, -- Codigo da garantia do produto
  nu_produto smallint, -- Indentificador da tabela produto
  nu_modalidade smallint,
  qt_dia_prazo_minimo integer NOT NULL, -- Valor do prazo minimo da garantia
  qt_dia_prazo_maximo integer NOT NULL, -- Valor do prazo maximo da garantia
  vr_minimo numeric(16,2) NOT NULL, -- Valor minimo aceito para garantia
  vr_maximo numeric(16,2) NOT NULL, -- Valor máximo aceito para garantia
  vr_percentual_minimo numeric(16,2) NOT NULL, -- Valor do percentual minimo para bloqueio garantia
  vr_percentual_maximo numeric(16,2) NOT NULL, -- Valor do percentual  maximo para bloqueio garantia
  ic_forma_bloqueio character(1) NOT NULL, -- Indica a forma de bloqueio. 1- SD (saldo devedor), 2- PMT (Parcela), 3- VC (Valor Contrato)
  ic_homologacao boolean, -- Indica se os parametros cadastrados foram homologados pelo Gestor
  nu_ordem_bloqueio character(4), -- Ordem de prioridade de bloqueio da garantia
  nu_ordem_desbloqueio character(4), -- Ordem de prioridade de desbloqueio da grantia
  nu_garantia smallint,
  nu_produto_garantia smallint,
  qt_prazo_maximo smallint,
  CONSTRAINT pk_acgtb060_parametro_garantia PRIMARY KEY (nu_parametro_garantia),
  CONSTRAINT fk_acgtb060_fk_acgtb011 FOREIGN KEY (nu_garantia)
      REFERENCES acgsm001.acgtb011_garantia (nu_garantia) MATCH SIMPLE
      ON UPDATE NO ACTION ON DELETE NO ACTION,
  CONSTRAINT fk_acgtb060_fk_acgtb057 FOREIGN KEY (nu_produto, nu_modalidade)
      REFERENCES acgsm001.acgtb057_parametro_produto (nu_produto, nu_modalidade) MATCH SIMPLE
      ON UPDATE NO ACTION ON DELETE NO ACTION,
  CONSTRAINT ckc_ic_forma_bloqueio_acgtb060 CHECK (ic_forma_bloqueio = ANY (ARRAY['1'::bpchar, '2'::bpchar, '3'::bpchar]))
)
WITH (
  OIDS=FALSE
);
COMMENT ON TABLE acgsm001.acgtb060_parametro_garantia IS 'Garantias do produto constituida por aplicações financeiras';
COMMENT ON COLUMN acgsm001.acgtb060_parametro_garantia.nu_parametro_garantia IS 'Codigo da garantia do produto';
COMMENT ON COLUMN acgsm001.acgtb060_parametro_garantia.nu_produto IS 'Indentificador da tabela produto';
COMMENT ON COLUMN acgsm001.acgtb060_parametro_garantia.qt_dia_prazo_minimo IS 'Valor do prazo minimo da garantia';
COMMENT ON COLUMN acgsm001.acgtb060_parametro_garantia.qt_dia_prazo_maximo IS 'Valor do prazo maximo da garantia';
COMMENT ON COLUMN acgsm001.acgtb060_parametro_garantia.vr_minimo IS 'Valor minimo aceito para garantia';
COMMENT ON COLUMN acgsm001.acgtb060_parametro_garantia.vr_maximo IS 'Valor máximo aceito para garantia';
COMMENT ON COLUMN acgsm001.acgtb060_parametro_garantia.vr_percentual_minimo IS 'Valor do percentual minimo para bloqueio garantia';
COMMENT ON COLUMN acgsm001.acgtb060_parametro_garantia.vr_percentual_maximo IS 'Valor do percentual  maximo para bloqueio garantia';
COMMENT ON COLUMN acgsm001.acgtb060_parametro_garantia.ic_forma_bloqueio IS 'Indica a forma de bloqueio. 1- SD (saldo devedor), 2- PMT (Parcela), 3- VC (Valor Contrato)';
COMMENT ON COLUMN acgsm001.acgtb060_parametro_garantia.ic_homologacao IS 'Indica se os parametros cadastrados foram homologados pelo Gestor';
COMMENT ON COLUMN acgsm001.acgtb060_parametro_garantia.nu_ordem_bloqueio IS 'Ordem de prioridade de bloqueio da garantia';
COMMENT ON COLUMN acgsm001.acgtb060_parametro_garantia.nu_ordem_desbloqueio IS 'Ordem de prioridade de desbloqueio da grantia';

DROP INDEX IF EXISTS acgsm001.ix_acgtb060_01;
CREATE UNIQUE INDEX idx_acgtb060_01
  ON acgsm001.acgtb060_parametro_garantia
  USING btree
  (nu_parametro_garantia);

DROP SEQUENCE IF EXISTS acgsm001.sq060_parametro_garantia;
CREATE SEQUENCE acgsm001.sq060_parametro_garantia
  INCREMENT 1
  MINVALUE 1
  MAXVALUE 9223372036854775807
  START 1
  CACHE 1;

CREATE TABLE acgsm001.acgtb059_gestor_produto
(
  nu_unidade integer NOT NULL,
  nu_natural integer NOT NULL,
  nu_produto integer NOT NULL,
  nu_modalidade integer NOT NULL,
  CONSTRAINT pk_acgtb059 PRIMARY KEY (nu_unidade, nu_natural, nu_produto, nu_modalidade),
  CONSTRAINT fk_acgtb059_fk_acgtb057 FOREIGN KEY (nu_produto, nu_modalidade)
      REFERENCES acgsm001.acgtb057_parametro_produto (nu_produto, nu_modalidade) MATCH SIMPLE
      ON UPDATE NO ACTION ON DELETE NO ACTION
)
WITH (
  OIDS=FALSE
);
COMMENT ON TABLE acgsm001.acgtb059_gestor_produto IS 'Gestores de produto são unidades extras vinculadas ao produto.
Ex.: O produto 739 já possui a unidade 7887 vinculada no SIICO. Além dela, é necessário também vincular a unidade 7879 para este produto e com modalidade 002 e é nesta tabela que será realizado o vinculo.';

DROP TABLE IF EXISTS acgsm001.acgtb067_produto_garantia;
CREATE TABLE acgsm001.acgtb067_produto_garantia
(
  nu_produto integer NOT NULL, -- Produto Caixa
  nu_produto_garantia integer NOT NULL, -- Produto que pode ser garantia de um produto.
  CONSTRAINT pk_acgtb067 PRIMARY KEY (nu_produto)
)
WITH (
  OIDS=FALSE
);
COMMENT ON TABLE acgsm001.acgtb067_produto_garantia IS 'Relação de produtos que podem ser garantia de outros produtos.

Ex.: Produto 739 tem como garantia os produtos 118 e 201.';
COMMENT ON COLUMN acgsm001.acgtb067_produto_garantia.nu_produto IS 'Produto Caixa';
COMMENT ON COLUMN acgsm001.acgtb067_produto_garantia.nu_produto_garantia IS 'Produto que pode ser garantia de um produto.';

DROP VIEW IF EXISTS acgsm001.acgvw009_produto;
CREATE OR REPLACE VIEW acgsm001.acgvw009_produto AS 
  SELECT DISTINCT sa.nu_segmento_atndo,
    sa.no_segmento_atndo,
    o.nu_operacao,
    o.no_operacao,
    p.nu_produto,
    p.no_produto,
    p.no_comercial_prdto,
    p.co_ultima_situacao,
    s.nu_natural_sistema,
    s.sg_sistema,
    u.nu_unidade,
    u.nu_natural,
    u.sg_unidade,
    u.no_unidade
FROM icosm001.icotbo10_produto p
INNER JOIN icosm001.icotbo12_atndoprdo sap ON sap.nu_produto_o10 = p.nu_produto
INNER JOIN icosm001.icotbo11_sgmnoatnd sa ON sa.nu_segmento_atndo = sap.nu_sgmno_atndo_o11
INNER JOIN icosm001.icotbo23_operacao o ON o.nu_operacao = p.nu_operacao_o23
INNER JOIN icosm001.icotbo25_siscntprd scp ON scp.nu_produto_o10 = p.nu_produto 
INNER JOIN icosm001.icotbs03_sistema s ON scp.nu_sistema_s03 = s.nu_natural_sistema
INNER JOIN icosm001.icotbo07_gestao g ON g.nu_produto_o10 = p.nu_produto 
INNER JOIN icosm001.icotbu24_unidade u ON g.nu_unidade_u24 = u.nu_unidade AND g.nu_natural_u24 = u.nu_natural
WHERE p.co_ultima_situacao = 'AT'::bpchar
AND g.dt_fim_gestao IS NOT NULL
AND sap.dt_fim_atndo_prdto IS NULL
ORDER BY sa.no_segmento_atndo;

comment on view acgsm001.ACGVW009_PRODUTO is 'View de produtos ativos para comercialização pela Caixa.';

DROP TABLE IF EXISTS acgsm001.acgtb067_produto_garantia;  
DROP TABLE IF EXISTS acgsm001.acgtb067_operacao_garantia;

CREATE TABLE acgsm001.acgtb067_operacao_garantia
(
  nu_operacao integer NOT NULL,
  nu_operacao_garantia integer NOT NULL,
  CONSTRAINT pk_acgtb067_operacao_garantia PRIMARY KEY (nu_operacao, nu_operacao_garantia)
)
WITH (
  OIDS=FALSE
);
COMMENT ON TABLE acgsm001.acgtb067_operacao_garantia IS 'Relação de produtos que podem ser garantia de outros produtos.

Ex.: Produto 739 tem como garantia os produtos 118 e 201.';
COMMENT ON COLUMN acgsm001.acgtb067_operacao_garantia.nu_operacao IS 'Operacao Caixa';
COMMENT ON COLUMN acgsm001.acgtb067_operacao_garantia.nu_operacao_garantia IS 'Operação que pode ser garantia de um produto.';

--========================================
-- Melhorias Serviço Consulta Saldo
--========================================

-- Remoção registro
DELETE FROM acgsm001.acgtb017_propriedade WHERE no_propriedade = 'servico.saldo.produto' AND no_grupo = 'servico.saldo';

-- Check: acgsm001.ckc_ic_retorno_acgtb054
ALTER TABLE acgsm001.acgtb054_log_servico_saldo DROP CONSTRAINT ckc_ic_retorno_acgtb054;

COMMENT ON COLUMN acgsm001.acgtb054_log_servico_saldo.ic_retorno IS 'Indica o tipo de retorno realizado pelo serviço ao sistema solicitante, podendo ser:
00 - SUCESSO. Significa que a solicitação de consulta a saldos de aplicações/contas de uma pessoa foi atendida com sucesso.
01 - SINTAXE INVALIDA. Significa que a mensagem de solicitação (de_solicitacao) recebida pelo serviço estava fora do padrão esperado.
02 - PRODUTO/OPERACAO NAO POSSUI GARANTIAS CADASTRADAS. Significa que não existe produto/operação cadastrada ou não existem garantias cadastradas para o produto.
03 - SERVICO CONSULTA CONTAS INDISPONIVEL. Significa que o serviço que consulta as contas de uma pessoa estava indisponível.
04 - SERVICO CONSULTA CONTAS RETORNOU CODIGO DE ERRO. Significa que o serviço que consulta as contas de uma pessoa retornou um código de erro.
05 - SERVICO CONSULTA CONTAS RETORNOU MENSAGEM INESPERADA. Significa que o serviço que consulta as contas de uma pessoa retornou uma mensagem fora do padrão esperado.
06 - CLIENTE NAO POSSUI APLICACOES OU NAO POSSUI APLICACOES VALIDAS.
07 - ERRO INTERNO. Significa que ocorreu um erro interno durante o processamento da solicitação.';

UPDATE acgsm001.acgtb054_log_servico_saldo SET ic_retorno = '07' WHERE ic_retorno = '06';
UPDATE acgsm001.acgtb054_log_servico_saldo SET ic_retorno = '06' WHERE ic_retorno = '05';
UPDATE acgsm001.acgtb054_log_servico_saldo SET ic_retorno = '05' WHERE ic_retorno = '04';
UPDATE acgsm001.acgtb054_log_servico_saldo SET ic_retorno = '04' WHERE ic_retorno = '03';
UPDATE acgsm001.acgtb054_log_servico_saldo SET ic_retorno = '03' WHERE ic_retorno = '02';

ALTER TABLE acgsm001.acgtb054_log_servico_saldo ADD CONSTRAINT ckc_ic_retorno_acgtb054 CHECK (ic_retorno = ANY (ARRAY['00', '01', '02', '03', '04', '05', '06', '07']));
