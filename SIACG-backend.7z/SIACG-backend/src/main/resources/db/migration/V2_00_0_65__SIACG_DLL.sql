/*==============================================================*/
/* SCRIPT V2_00_0_65__SIACG_DLL									*/
/*==============================================================*/


-- Table: acgsm001.acgtb096_contrato_maquina_equipamento

-- DROP TABLE acgsm001.acgtb096_contrato_maquina_equipamento;

CREATE TABLE acgsm001.acgtb096_contrato_maquina_equipamento
(
  nu_contrato integer NOT NULL, -- Identificador da garantia do contrato. Tabela acgtb001_contrato.
  nu_maquina_equipamento integer NOT NULL, -- Identificador da tabela de imoveis (acgtb077_maquina_equipamento...
  CONSTRAINT pk_acgtb096_contrato_maquina_equipamento PRIMARY KEY (nu_contrato, nu_maquina_equipamento),
  CONSTRAINT fk_acgtb087_acgtb001 FOREIGN KEY (nu_contrato)
      REFERENCES acgsm001.acgtb001_contrato (nu_contrato) MATCH SIMPLE
      ON UPDATE NO ACTION ON DELETE NO ACTION,
  CONSTRAINT fk_acgtb087_acgtb077 FOREIGN KEY (nu_maquina_equipamento)
      REFERENCES acgsm001.acgtb077_maquina_equipamento (nu_maquina_equipamento) MATCH SIMPLE
      ON UPDATE NO ACTION ON DELETE NO ACTION
)
WITH (
  OIDS=FALSE
);

COMMENT ON COLUMN acgsm001.acgtb096_contrato_maquina_equipamento.nu_contrato IS 'Identificador da garantia do contrato. Tabela acgtb001_contrato.';
COMMENT ON COLUMN acgsm001.acgtb096_contrato_maquina_equipamento.nu_maquina_equipamento IS 'Identificador da tabela de imoveis (acgtb077_maquina_equipamento)';


-- Index: acgsm001.fk_acgtb087_acgtb001

-- DROP INDEX acgsm001.fk_acgtb087_acgtb001;

CREATE INDEX fk_acgtb087_acgtb001
  ON acgsm001.acgtb096_contrato_maquina_equipamento
  USING btree
  (nu_contrato);

-- Index: acgsm001.fki_pk_acgtb087_contrato_imovel

-- DROP INDEX acgsm001.fki_pk_acgtb087_contrato_imovel;

CREATE INDEX fki_pk_acgtb087_contrato_imovel
  ON acgsm001.acgtb096_contrato_maquina_equipamento
  USING btree
  (nu_maquina_equipamento);

