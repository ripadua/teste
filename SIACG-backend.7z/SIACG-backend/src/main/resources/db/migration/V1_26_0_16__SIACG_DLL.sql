--Sequence tabela acgsm001.sq077_maquina_equipamento;
create sequence acgsm001.sq077_maquina_equipamento;

/*==============================================================*/
/* Table: acgtb077_maquina_equipamento                          */
/*==============================================================*/
create table acgsm001.acgtb077_maquina_equipamento (
   nu_maquina_equipamento INT4                 not null default nextval('acgsm001.sq077_maquina_equipamento'),
   de_tipo_bem          VARCHAR(100)         not null,
   nu_ano               INT4                 not null,
   constraint PK_ACGTB077_MAQUINA_EQUIPAMENT primary key (nu_maquina_equipamento)
);

comment on column acgsm001.acgtb077_maquina_equipamento.nu_maquina_equipamento is
'Identificador da tabela maquinas_equipamentos.';

comment on column acgsm001.acgtb077_maquina_equipamento.de_tipo_bem is
'Coluna que descreve o tipo do bem.';

/*==============================================================*/
/* Table: acgtb076_garantia_maquina_eqpo                        */
/*==============================================================*/
create table acgsm001.acgtb076_garantia_maquina_eqpo (
   nu_garantia_contrato int4                 not null,
   nu_maquina_equipamento INT4                 not null,
   constraint PK_ACGTB076_GARANTIA_MAQUINA_E primary key (nu_garantia_contrato, nu_maquina_equipamento)
);

comment on column acgsm001.acgtb076_garantia_maquina_eqpo.nu_garantia_contrato is
'Identificador da garantia do contrato. Gerado automaticamente pelo sistema.';

comment on column acgsm001.acgtb076_garantia_maquina_eqpo.nu_maquina_equipamento is
'Identificador da tabela maquinas_equipamentos.';

-- set table ownership
--alter table acgsm001.acgtb076_garantia_maquina_eqpo owner to acgsm001
--;
alter table acgsm001.acgtb076_garantia_maquina_eqpo
   add constraint FK_ACGTB076_ACGTB009 foreign key (nu_garantia_contrato)
      references acgsm001.acgtb009_garantia_contrato (nu_garantia_contrato)
      on delete restrict on update restrict;

alter table acgsm001.acgtb076_garantia_maquina_eqpo
   add constraint FK_ACGTB076_ACGTB077 foreign key (nu_maquina_equipamento)
      references acgsm001.acgtb077_maquina_equipamento (nu_maquina_equipamento)
      on delete restrict on update restrict;

--Sequence tabela acgsm001.sq079_produto_agricola	  
create sequence acgsm001.sq079_produto_agricola;

/*==============================================================*/
/* Table: acgtb079_produto_agricola                             */
/*==============================================================*/
create table acgsm001.acgtb079_produto_agricola (
   nu_produto_agricola  INT4                 not null default nextval('acgsm001.sq079_produto_agricola'),
   de_tipo_insumo_agricola VARCHAR(100)         not null,
   nu_quantidade        INT4                 not null,
   nu_ano               INT4                 not null,
   constraint PK_ACGTB079_PRODUTO_AGRICOLA primary key (nu_produto_agricola)
);

comment on column acgsm001.acgtb079_produto_agricola.nu_produto_agricola is
'Identificador da garantia produtos_agricolas';

comment on column acgsm001.acgtb079_produto_agricola.de_tipo_insumo_agricola is
'Coluna que descreve o tipo do insumo agricula.';

comment on column acgsm001.acgtb079_produto_agricola.nu_quantidade is
'Coluna que identifica a quantidade de produto agrícula para cada registro.';

comment on column acgsm001.acgtb079_produto_agricola.nu_ano is
'Identifica o ano de cada produto registrado.';


/*==============================================================*/
/* Table: acgtb078_garantia_pro_agricola                        */
/*==============================================================*/
create table acgsm001.acgtb078_garantia_pro_agricola (
   nu_garantia_contrato int4                 not null,
   nu_produto_agricola  INT4                 not null,
   constraint PK_ACGTB078_GARANTIA_PRO_AGRIC primary key (nu_garantia_contrato, nu_produto_agricola)
);

comment on column acgsm001.acgtb078_garantia_pro_agricola.nu_garantia_contrato is
'Identificador da tabela de garantia contrato.';

comment on column acgsm001.acgtb078_garantia_pro_agricola.nu_produto_agricola is
'Identificador da tabela protuto agricola.';

alter table acgsm001.acgtb078_garantia_pro_agricola
   add constraint FK_ACGTB078_ACGTB009 foreign key (nu_garantia_contrato)
      references acgsm001.acgtb009_garantia_contrato (nu_garantia_contrato)
      on delete restrict on update restrict;

alter table acgsm001.acgtb078_garantia_pro_agricola
   add constraint FK_ACGTB078_ACGTB079 foreign key (nu_produto_agricola)
      references acgsm001.acgtb079_produto_agricola (nu_produto_agricola)
      on delete restrict on update restrict;
