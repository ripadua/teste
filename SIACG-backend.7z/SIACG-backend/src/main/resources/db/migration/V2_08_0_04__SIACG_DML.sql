/*============================================================*/
/*           SCRIPT V2_08_0_04__SIACG_DML				      */
/*============================================================*/

-- Insere informacoes sobre os manuais que ja existiam no servidor ftp
INSERT INTO acgsm001.acgtb111_info_manual_usuario(ts_inclusao, no_manual) VALUES
('2014-06-13 13:54', 'SIACG_Manual_Usuario_v1.pdf'),
('2015-01-27 13:50', 'SIACG_Manual_Usuario_v2.pdf'),
('2020-06-18 08:41', 'SIACG_Manual_Usuario.pdf');
