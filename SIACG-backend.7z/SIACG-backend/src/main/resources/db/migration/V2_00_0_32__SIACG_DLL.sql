ALTER TABLE acgsm001.acgtb080_garantia_imovel
  DROP COLUMN vr_garantia;