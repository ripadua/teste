
--Acrescentando coluna para pk do identificador de UH.

ALTER TABLE acgsm001.acgtb049_unidade_habitacional ADD COLUMN nu_identificador_unidade bigint;

comment on column acgsm001.acgtb049_unidade_habitacional.nu_identificador_unidade is
'Chave Primária da Unidade. Esse campo vai permitir que o SIACG consiga identificar quais unidades sofreram alteração, uma vez que o arquivo é incremental. Trata-se de um registro único para cada unidade, permitindo identificar aquela unidade de forma unívoca. ';
