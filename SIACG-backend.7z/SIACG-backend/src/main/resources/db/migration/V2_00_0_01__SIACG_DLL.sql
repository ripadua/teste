ALTER TABLE acgsm001.acgtb054_acao_preventiva 
drop column ic_ds200,
ADD column ic_marca_ds200 integer NOT NULL default 0,
ADD column ic_desmarca_ds200 integer NOT NULL default 0,
ADD column ic_bloqueio_ds200 integer NOT NULL default 0,
ADD column ic_desbloqueio_ds200 integer NOT NULL default 0,
ADD column de_retorno_marca_ds200 character varying(300) NULL,
ADD column de_retorno_desmarca_ds200 character varying(300) NULL,
ADD column de_retorno_bloqueio_ds200 character varying(300) NULL,
ADD column de_retorno_desbloqueio_ds200 character varying(300) NULL;

COMMENT ON COLUMN acgsm001.acgtb054_acao_preventiva.de_retorno_marca_ds200 IS 'Descricao do retorno do envio da marcacao da Conta no arquivo DS200';
COMMENT ON COLUMN acgsm001.acgtb054_acao_preventiva.de_retorno_desmarca_ds200 IS 'Descricao do retorno do envio da desmarcacao da Conta no arquivo DS200';
COMMENT ON COLUMN acgsm001.acgtb054_acao_preventiva.de_retorno_bloqueio_ds200 IS 'Descricao do retorno do envio do bloqueio da Conta no arquivo DS200';
COMMENT ON COLUMN acgsm001.acgtb054_acao_preventiva.de_retorno_desbloqueio_ds200 IS 'Descrição do retorno do envio do desbloqueio da Conta no arquivo DS200';

COMMENT ON COLUMN acgsm001.acgtb054_acao_preventiva.ic_marca_ds200 IS 'Indicador de envio da marcacao da Conta no arquivo DS200:
0 - Não é necessário enviar o DS200 ou a garantia não é um conta SIDEC.
1 - Aguardando envio do DS200.
2 - Enviado ao DS200.
3 - Resposta do DS200 de Sucesso.
4 - Resposta do DS200 de Erro.';

COMMENT ON COLUMN acgsm001.acgtb054_acao_preventiva.ic_desmarca_ds200 IS 'Indicador de envio da desmarcacao da Conta no arquivo DS200:
0 - Não é necessário enviar o DS200 ou a garantia não é um conta SIDEC.
1 - Aguardando envio do DS200.
2 - Enviado ao DS200.
3 - Resposta do DS200 de Sucesso.
4 - Resposta do DS200 de Erro.';

COMMENT ON COLUMN acgsm001.acgtb054_acao_preventiva.ic_bloqueio_ds200 IS 'Indicador de envio do bloqueio da Conta no arquivo DS200:
0 - Não é necessário enviar o DS200 ou a garantia não é um conta SIDEC.
1 - Aguardando envio do DS200.
2 - Enviado ao DS200.
3 - Resposta do DS200 de Sucesso.
4 - Resposta do DS200 de Erro.';

COMMENT ON COLUMN acgsm001.acgtb054_acao_preventiva.de_retorno_desbloqueio_ds200 IS 'Indicador de envio do desbloqueio da Conta no arquivo DS200:
0 - Não é necessário enviar o DS200 ou a garantia não é um conta SIDEC.
1 - Aguardando envio do DS200.
2 - Enviado ao DS200.
3 - Resposta do DS200 de Sucesso.
4 - Resposta do DS200 de Erro.';