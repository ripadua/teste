--========================================
--Data: 12/04/2018
--Versão 1.22.0
--Adequações no banco de dados para implementação da Unidade Habitacional Prospectos.
--========================================

CREATE SEQUENCE acgsm001.acgsq065_tipo_parcela
  INCREMENT 1
  MINVALUE 1
  MAXVALUE 9223372036854775807
  START 1
  CACHE 1;


create table acgsm001.acgtb065_tipo_parcela (
   nu_tipo_parcela      int4                 not null,
   no_tipo_parcela      VARCHAR(100)         not null,
   ic_periodicidade_prevista int2            not null default 0 constraint CKC_IC_PERIODICIDADE__ACGTB065 check (ic_periodicidade_prevista in (0,1,2,3,4,6,12)),
   qt_ocorrencia_prevista int4               not null,
   constraint PK_ACGTB065_TIPO_PARCELA primary key (nu_tipo_parcela)
);

comment on table acgsm001.acgtb065_tipo_parcela is
'Tipo de parcela que pode ser utilizada no propecto de um contrato.

Ex: 
- Sinal
- Parcela
- Repasse bancário
- Chave
- Sinal
- Balão
- Parcela
- Encargo
- Amortização';

comment on column acgsm001.acgtb065_tipo_parcela.nu_tipo_parcela is 'Número identificado automático gerado pelo sistema.';

comment on column acgsm001.acgtb065_tipo_parcela.no_tipo_parcela is 'Nome do tipo de parcela que pode ser utilizada como base de prospecção de um contrato de comercialização de uma unidade habitacional.

Ex:
- Sinal
- Parcela
- Repasse bancário
- Balão
- Chave';

comment on column acgsm001.acgtb065_tipo_parcela.ic_periodicidade_prevista is 'Periodicidade prevista para o tipo de parcela. Essa periodicidade será sugerida no lançamento do prospecto de parcelas do contrato, podendo ser alterado de acordo com as características do contrato.

Valores possiveis:

0 - Única
1 - Mensal
2 - Bimestral
3 - Trimestral
4 - Quadrimestral
6 - Semestral
12 - Anual';

comment on column acgsm001.acgtb065_tipo_parcela.qt_ocorrencia_prevista is 'Quantidade de ocorrências previstas para o tipo de parcela. 
Essa informação será sugerida para facilitar o preenchimento do prospecto do contrato.';

DROP TABLE acgsm001.acgtb052_prospecto_recebimento;
DROP SEQUENCE acgsm001.acgsq052_prospecto_recebimento;

CREATE SEQUENCE acgsm001.acgsq052_prmto_comercializacao
  INCREMENT 1
  MINVALUE 1
  MAXVALUE 9223372036854775807
  START 1
  CACHE 1;
  
  create table acgsm001.acgtb052_prmto_comercializacao (
   nu_prmto_comercializao int8               not null,
   nu_ctrto_comercializacao int8             not null,
   nu_tipo_parcela      int4                 null,
   ic_periodicidade     int2                 not null default 0 constraint CKC_IC_PERIODICIDADE_ACGTB052 check (ic_periodicidade in (0,1,2,3,4,6,12)),
   dt_prevista_inicio   DATE                 not null,
   vr_previsto          NUMERIC(15,2)        not null,
   qt_ocorrencia        int4                 not null,
   ic_exclusao_distrato boolean              null,
   dh_inclusao          DATE                 null,
   co_responsavel       VARCHAR(7)           not null,
   constraint PK_ACGTB052_PRMTO_COMERCIALIZA primary key (nu_prmto_comercializao)
);

comment on table acgsm001.acgtb052_prmto_comercializacao is 'Parâmetros de comercialização da unidade habitacional que irá gerar os prospectos de recebimento do contrato.

São as informações das parcelas e sua recorrência ao longo da vigência do contrato.

Ex:
- Entrada no valor de R$ 30.000,00, para a data de 01/01/2018, com recorrência única e quantidade de ocorrências igual a 1.

- Balão no valor de R$ 10.000,00, iniciando em 01/07/2018, com recorrência semestral e quantidade de ocorrências igual a 5.

- Parcelas no valor de R$ 2.000,00, iniicando em 01/02/2018, com recorrência mensal e quantidade de ocorrências igual a 120.';

comment on column acgsm001.acgtb052_prmto_comercializacao.nu_prmto_comercializao is 'Identificador unico';
comment on column acgsm001.acgtb052_prmto_comercializacao.nu_ctrto_comercializacao is 'Chave estrangeira para comercialização';
comment on column acgsm001.acgtb052_prmto_comercializacao.nu_tipo_parcela is 'Número identificado automático gerado pelo sistema.';
comment on column acgsm001.acgtb052_prmto_comercializacao.ic_periodicidade is 'Periodicidade do recebimento prospectado. Valores possiveis:

0 - Única
1 - Mensal
2 - Bimestral
3 - Trimestral
4 - Quadrimestral
6 - Semestral
12 - Anual';
comment on column acgsm001.acgtb052_prmto_comercializacao.dt_prevista_inicio is 'Data prevista para início dos recebimentos do tipo de prospecto de recebimento.';
comment on column acgsm001.acgtb052_prmto_comercializacao.vr_previsto is 'Valor previsto de recebimento, conforme contratado de comercialização da unidade habitacional.';
comment on column acgsm001.acgtb052_prmto_comercializacao.qt_ocorrencia is 'Quantidade de ocorrências de prospectos gerados a partir da data de início, baseado na periodicidade definida para o parâmetro.';
comment on column acgsm001.acgtb052_prmto_comercializacao.ic_exclusao_distrato is '?? Retirar e tratar na situação do contrato???';
comment on column acgsm001.acgtb052_prmto_comercializacao.dh_inclusao is 'Data e hora de cadastramento do parâmetro de prospecção para o contrato.';
comment on column acgsm001.acgtb052_prmto_comercializacao.co_responsavel is 'Matricula do responsavel pela inclusão da informação.';

create  index ix_acgtb052_01 on acgsm001.acgtb052_prmto_comercializacao (nu_ctrto_comercializacao);
create  index ix_acgtb052_02 on acgsm001.acgtb052_prmto_comercializacao (dt_prevista_inicio);

alter table acgsm001.acgtb052_prmto_comercializacao
   add constraint FK_ACGTB052_ACGTB051 foreign key (nu_ctrto_comercializacao)
      references acgsm001.acgtb051_comercializacao (nu_comercializacao)
      on delete restrict on update restrict;

alter table acgsm001.acgtb052_prmto_comercializacao
   add constraint FK_ACGTB052_ACGTB065 foreign key (nu_tipo_parcela)
      references acgsm001.acgtb065_tipo_parcela (nu_tipo_parcela)
      on delete restrict on update restrict;

CREATE SEQUENCE acgsm001.acgsq056_prospecto
  INCREMENT 1
  MINVALUE 1
  MAXVALUE 9223372036854775807
  START 1
  CACHE 1;

create table acgsm001.acgtb056_prospecto (
   nu_prospecto         INT8                 not null,
   nu_prmto_comercializao int8               not null,
   nu_recebido          INT8                 not null,
   dt_prevista          DATE                 not null,
   vr_prospecto         NUMERIC(15,2)        not null,
   vr_atualizado        NUMERIC(15,2)        not null,
   dh_atualizacao       DATE                 null,
   dt_referencia_indicador DATE              null,
   dt_prospecto         DATE                 null,
   dh_inclusao          DATE                 null,
   co_responsavel       VARCHAR(7)           not null,
   constraint PK_ACGTB056_PROSPECTO primary key (nu_prospecto)
);

comment on table acgsm001.acgtb056_prospecto is 'Valores gerados automaticamente a partir da parametrização do prospecto de recebimento. São as parcelas efetivamente previstas para recebimento dos valores do contrato de comercialização de uma unidade habitacional.';
comment on column acgsm001.acgtb056_prospecto.nu_prospecto is 'Identificador único';
comment on column acgsm001.acgtb056_prospecto.nu_prmto_comercializao is 'Identificador unico';
comment on column acgsm001.acgtb056_prospecto.nu_recebido is 'Identifica um recebimento recebido para o valor prospectado através da conciliação do valores (automática ou manual).';
comment on column acgsm001.acgtb056_prospecto.dt_prevista is 'Data prevista para recebimento do valor prospectado no contrato de comercialização da unidade habitacional.';
comment on column acgsm001.acgtb056_prospecto.vr_prospecto is 'Valor previsto para recebimento do valor prospectado no contrato de comercialização da unidade habitacional.';
comment on column acgsm001.acgtb056_prospecto.vr_atualizado is 'Valor atualizado com base no indicador de atualização monetária definido para o contrato de comercialização da unidade habitacional.';
comment on column acgsm001.acgtb056_prospecto.dh_atualizacao is 'Data e hora de atualização do valor prospectado a ser recebido do proponente.';
comment on column acgsm001.acgtb056_prospecto.dt_referencia_indicador is 'Data de referência do indicador de atualização monetária utilizado na atualização dos valores a serem recebidos conforme prospecto do contrato.';
comment on column acgsm001.acgtb056_prospecto.dt_prospecto is 'Data de referência da prospecção do contrato. Essa informação é utilizada para definir o período de início para atualização monetário do valor do prospecto.';
comment on column acgsm001.acgtb056_prospecto.dh_inclusao is 'Data e hora de cadastramento das informações do prospecto.';
comment on column acgsm001.acgtb056_prospecto.co_responsavel is 'Matricula do responsavel pela inclusão da informação.';

create  index ix_acgtb056_01 on acgsm001.acgtb056_prospecto (nu_prmto_comercializao);

alter table acgsm001.acgtb056_prospecto
   add constraint FK_ACGTB056_FK_ACGTB0_ACGTB052 foreign key (nu_prmto_comercializao)
      references acgsm001.acgtb052_prmto_comercializacao (nu_prmto_comercializao)
      on delete restrict on update restrict;

alter table acgsm001.acgtb056_prospecto
   add constraint FK_ACGTB056_REFERENCE_ACGTB053 foreign key (nu_recebido)
      references acgsm001.acgtb053_recebido (nu_recebido)
      on delete restrict on update restrict;

ALTER TABLE acgsm001.acgtb056_prospecto ALTER COLUMN nu_recebido DROP NOT NULL;
COMMENT ON COLUMN acgsm001.acgtb056_prospecto.nu_recebido IS 'Identifica um recebimento recebido para o valor prospectado através da conciliação do valores (automática ou manual).';
