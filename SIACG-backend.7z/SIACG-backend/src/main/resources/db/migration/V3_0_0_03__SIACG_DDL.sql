/*==============================================================*/
/* V3_0_0_03__SIACG_DDL.sql                                     */
/*==============================================================*/

/*==============================================================*/
/* Table: acgtb081_imovel                                       */
/*==============================================================*/
ALTER TABLE ACG.acgtb081_imovel MODIFY co_livro_serventia VARCHAR2(4);

/*==============================================================*/
/* Table: acgtb112_papel_proprietario                           */
/*==============================================================*/
create table ACG.acgtb112_papel_proprietario (
   nu_papel_proprietario NUMBER(10,0)                 not null,
   de_papel_proprietario VARCHAR2(100)                not null,
   nu_grupo_papel_proprietario NUMBER(4,0)                null,
   constraint PK_ACGTB112_PAPEL_PROPRIETARIO primary key (nu_papel_proprietario)
   USING INDEX TABLESPACE "ACGTSIX001" ENABLE
) TABLESPACE "ACGTSDT001";

comment on table ACG.acgtb112_papel_proprietario is
'Tabela domínio para armazenamento dos papéis de um proprietário de imóvel.
As informações armazenadas foram fornecidas pelo SIOPI - 12/2020.';

comment on column ACG.acgtb112_papel_proprietario.nu_papel_proprietario is
'Número identificador do registro.';

comment on column ACG.acgtb112_papel_proprietario.de_papel_proprietario is
'Descrição do papel do proprietário.';

comment on column ACG.acgtb112_papel_proprietario.nu_grupo_papel_proprietario is
'Número que identifica a qual grupo pertence um determinado papel do proprietário:
1 – Comprador
2 – Vendedor
3 – Agente Promotor
4 – Poder Público';

/*==============================================================*/
/* Table: acgtb113_proprietario_imovel                          */
/*==============================================================*/

create sequence ACG.acgsq113_proprietario_imovel;

create table ACG.acgtb113_proprietario_imovel(
   nu_proprietario_imovel  NUMBER(10,0)        DEFAULT ACG.acgsq113_proprietario_imovel.nextval not null,
   nu_imovel            NUMBER(10,0)          not null,
   nu_pessoa            NUMBER(10,0)          not null,
   nu_papel_proprietario NUMBER(10,0)             null,
   pc_participacao NUMBER(16,2) DEFAULT 100 not null,
   constraint ck_acgtb113_01 unique (nu_imovel, nu_pessoa),
   constraint PK_ACGTB113_PROPRIETARIO_IMOVE primary key (nu_proprietario_imovel)
   USING INDEX TABLESPACE "ACGTSIX001" ENABLE
) TABLESPACE "ACGTSDT001";

comment on table ACG.acgtb113_proprietario_imovel is
'Armazena os proprietários de um determinado imóvel.';

comment on column ACG.acgtb113_proprietario_imovel.nu_proprietario_imovel is
'Identificador do registro, gerado automaticamente.';

comment on column ACG.acgtb113_proprietario_imovel.nu_imovel is
'Identificador da tabela acgtb081_imovel.';

comment on column ACG.acgtb113_proprietario_imovel.nu_pessoa is
'Identificador da tabela acgtb003_pessoa.';

comment on column ACG.acgtb113_proprietario_imovel.nu_papel_proprietario is
'Identificador da tabela acgtb112_papel_proprietario.';

comment on column ACG.acgtb113_proprietario_imovel.pc_participacao is
'Valor do percentual de participação do proprietário do imóvel.';

alter table ACG.acgtb113_proprietario_imovel
   add constraint FK_ACGTB113_REFERENCE_ACGTB081 foreign key (nu_imovel)
      references ACG.acgtb081_imovel (nu_imovel);

alter table ACG.acgtb113_proprietario_imovel
   add constraint FK_ACGTB113_REFERENCE_ACGTB003 foreign key (nu_pessoa)
      references ACG.acgtb003_pessoa (nu_pessoa);

alter table ACG.acgtb113_proprietario_imovel
   add constraint FK_ACGTB113_REFERENCE_ACGTB112 foreign key (nu_papel_proprietario)
      references ACG.acgtb112_papel_proprietario (nu_papel_proprietario);


/*==============================================================*/
/* REVERT														*/
/*==============================================================*/
--drop table ACG.acgtb112_papel_proprietario;
--drop table ACG.acgtb113_proprietario_imovel;
--drop sequence if exists ACG.acgsq113_proprietario_imovel;
--ALTER TABLE ACG.acgtb081_imovel MODIFY co_livro_serventia VARCHAR2(3);
      