/*==============================================================*/
/* Index: acgsm001.acgtb070_anlse_cartao_bandeira               */
/*==============================================================*/
CREATE INDEX ix_acgtb070_01 ON acgsm001.acgtb070_anlse_cartao_bandeira USING btree (nu_analise_cartao_credito);


/*==============================================================*/
/* Table: acgsm002.acgtbs10_empreendimento                      */
/*==============================================================*/
ALTER TABLE acgsm002.acgtbs10_empreendimento ALTER COLUMN co_apf TYPE VARCHAR(9); 

/*==============================================================*/
/* Reverse: acgsm001.acgtb070_anlse_cartao_bandeira              */
/*==============================================================*/      
--DROP INDEX acgsm001.ix_acgtb070_01;

/*==============================================================*/
/* Reverse: acgsm001.acgtbs10_empreendimento                    */
/*==============================================================*/      
--ALTER TABLE acgsm002.acgtbs10_empreendimento ALTER COLUMN co_apf TYPE integer USING (co_apf::integer);