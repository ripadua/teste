/*==============================================================*/
/* SCRIPT V2_00_0_68__SIACG_DLL									*/
/*==============================================================*/
 
INSERT INTO acgsm001.acgtb040_relatorio (nu_relatorio, de_relatorio, de_endereco, de_funcionalidade, de_acao, ic_ativo)
				VALUES( (select max(r.nu_relatorio) from acgsm001.acgtb040_relatorio r) + 1,'Relatório de Apetite por Risco até 2018',
				       'ftp://ftp.go.caixa/PEDES/SIACG/relatorio-apetite-risco-ate-2018/',
					   'rel_apetite_risco_2018', 'consultar', TRUE)



/*########################### SCRIPT ROLLBACK ##############################*/
/* 
DELETE FROM acgsm001.acgtb040_relatorio
 where nu_relatorio = (select max(r.nu_relatorio) from acgsm001.acgtb040_relatorio r where de_funcionalidade = 'rel_apetite_risco_2018');
*/
