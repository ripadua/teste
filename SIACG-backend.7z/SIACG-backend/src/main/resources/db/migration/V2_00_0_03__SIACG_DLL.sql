/*==============================================================*/
/* Table: acgtb083_indicador_financeiro                         */
/*==============================================================*/

-- Sequence: acgsm001.sq083_indicador_financeiro

CREATE SEQUENCE acgsm001.sq083_indicador_financeiro
  INCREMENT 1
  MINVALUE 1
  MAXVALUE 9223372036854775807
  START 1
  CACHE 1;
  
create table acgsm001.acgtb083_indicador_financeiro (
   nu_indicador_financeiro bigint               not null default nextval('acgsm001.sq083_indicador_financeiro'::regclass),
   no_indicador_financeiro VARCHAR(20)          not null,
   ic_situacao             boolean			    DEFAULT true,
   constraint PK_ACGTB083_INDICADOR_FINANCEIRO primary key (nu_indicador_financeiro)
);

comment on table acgsm001.acgtb083_indicador_financeiro is
'Registra os indicadores financeiros que serão utilizados no sistema.';

comment on column acgsm001.acgtb083_indicador_financeiro.nu_indicador_financeiro is
'pk Identificador Financeiro';

comment on column acgsm001.acgtb083_indicador_financeiro.no_indicador_financeiro is
'Nome do Indentificador Financeiro';

comment on column acgsm001.acgtb083_indicador_financeiro.ic_situacao is
'Indica se situação do indicador esta ativa ou inativa.';


