/*============================================================*/
/*           SCRIPT V2_11_0_01__SIACG_DDL		              */
/*============================================================*/

-- Correção do tipo do campo dt_renegociacao_contrato de timestamp para date nas bases de des.

/*==============================================================*/
/* ALTERA STAGING                                               */
/*==============================================================*/
ALTER TABLE acgsm002.acgtbs10_empreendimento DROP COLUMN ic_contrato_execucao_judicial;
ALTER TABLE acgsm002.acgtbs10_empreendimento DROP COLUMN ic_contrato_renegociado;       
ALTER TABLE acgsm002.acgtbs10_empreendimento DROP COLUMN dt_renegociacao_contrato;
ALTER TABLE acgsm002.acgtbs10_empreendimento DROP COLUMN nu_produto;           
ALTER TABLE acgsm002.acgtbs10_empreendimento DROP COLUMN vr_encargo_atraso;  
ALTER TABLE acgsm002.acgtbs10_empreendimento DROP COLUMN vr_mora_multa;  
ALTER TABLE acgsm002.acgtbs10_empreendimento DROP COLUMN vr_iof_complementar;  
ALTER TABLE acgsm002.acgtbs10_empreendimento DROP COLUMN vr_diferenca_prestacao;
ALTER TABLE acgsm002.acgtbs10_empreendimento DROP COLUMN vr_total_atraso;  
ALTER TABLE acgsm002.acgtbs10_empreendimento DROP COLUMN vr_saldo_pro_rata;  
ALTER TABLE acgsm002.acgtbs10_empreendimento DROP COLUMN vr_divida_total;  

ALTER TABLE acgsm002.acgtbs10_empreendimento ADD COLUMN ic_contrato_execucao_judicial boolean;
ALTER TABLE acgsm002.acgtbs10_empreendimento ADD COLUMN ic_contrato_renegociado boolean;       
ALTER TABLE acgsm002.acgtbs10_empreendimento ADD COLUMN dt_renegociacao_contrato DATE;
ALTER TABLE acgsm002.acgtbs10_empreendimento ADD COLUMN nu_produto           INT2;           
ALTER TABLE acgsm002.acgtbs10_empreendimento ADD COLUMN vr_encargo_atraso    NUMERIC(16,2);  
ALTER TABLE acgsm002.acgtbs10_empreendimento ADD COLUMN vr_mora_multa        NUMERIC(16,2);  
ALTER TABLE acgsm002.acgtbs10_empreendimento ADD COLUMN vr_iof_complementar  NUMERIC(16,2);  
ALTER TABLE acgsm002.acgtbs10_empreendimento ADD COLUMN vr_diferenca_prestacao NUMERIC(16,2);
ALTER TABLE acgsm002.acgtbs10_empreendimento ADD COLUMN vr_total_atraso      NUMERIC(16,2);  
ALTER TABLE acgsm002.acgtbs10_empreendimento ADD COLUMN vr_saldo_pro_rata    NUMERIC(16,2);  
ALTER TABLE acgsm002.acgtbs10_empreendimento ADD COLUMN vr_divida_total      NUMERIC(16,2);  

comment on column acgsm002.acgtbs10_empreendimento.ic_contrato_execucao_judicial is
'Indica se o contrato possui inclusão das SE de execução judicial ou extra judicial (Grupo 40 - da SE041 até SE049).';

comment on column acgsm002.acgtbs10_empreendimento.ic_contrato_renegociado is
'Indica se o contrato foi renegociado ou repactuado (Tipo de Pedido - TP098).';

comment on column acgsm002.acgtbs10_empreendimento.dt_renegociacao_contrato is
'Data de renegociação/ repactuação do contrato (Inclusão TP098).';

comment on column acgsm002.acgtbs10_empreendimento.nu_produto is
'Número do SIICO/Produto.';

comment on column acgsm002.acgtbs10_empreendimento.vr_encargo_atraso is
'Valor do Encargo em Atraso.';

comment on column acgsm002.acgtbs10_empreendimento.vr_mora_multa is
'Valor Mora + Multa.';

comment on column acgsm002.acgtbs10_empreendimento.vr_iof_complementar is
'Valor do IOF Complementar.';

comment on column acgsm002.acgtbs10_empreendimento.vr_diferenca_prestacao is
'Valor da diferença de prestação.';

comment on column acgsm002.acgtbs10_empreendimento.vr_total_atraso is
'Valor do total em atraso.';

comment on column acgsm002.acgtbs10_empreendimento.vr_saldo_pro_rata is
'Valor do saldo pro-rata.';

comment on column acgsm002.acgtbs10_empreendimento.vr_divida_total is
'Valor da dívida total. É a soma dos campos: vr_encargo_atraso, vr_mora_multa, vr_iof_complementar, vr_diferenca_prestacao, vr_total_atraso e vr_saldo_pro_rata.';

/*==============================================================*/
/* ALTERA RELACIONAL                                            */
/*==============================================================*/
ALTER TABLE acgsm001.acgtb050_empreendimento DROP COLUMN ic_contrato_execucao_judicial;
ALTER TABLE acgsm001.acgtb050_empreendimento DROP COLUMN ic_contrato_renegociado;       
ALTER TABLE acgsm001.acgtb050_empreendimento DROP COLUMN dt_renegociacao_contrato;
ALTER TABLE acgsm001.acgtb050_empreendimento DROP COLUMN nu_produto;           
ALTER TABLE acgsm001.acgtb050_empreendimento DROP COLUMN vr_encargo_atraso;  
ALTER TABLE acgsm001.acgtb050_empreendimento DROP COLUMN vr_mora_multa;  
ALTER TABLE acgsm001.acgtb050_empreendimento DROP COLUMN vr_iof_complementar;  
ALTER TABLE acgsm001.acgtb050_empreendimento DROP COLUMN vr_diferenca_prestacao;
ALTER TABLE acgsm001.acgtb050_empreendimento DROP COLUMN vr_total_atraso;  
ALTER TABLE acgsm001.acgtb050_empreendimento DROP COLUMN vr_saldo_pro_rata;  
ALTER TABLE acgsm001.acgtb050_empreendimento DROP COLUMN vr_divida_total;  

ALTER TABLE acgsm001.acgtb050_empreendimento ADD COLUMN ic_contrato_execucao_judicial boolean;
ALTER TABLE acgsm001.acgtb050_empreendimento ADD COLUMN ic_contrato_renegociado boolean;       
ALTER TABLE acgsm001.acgtb050_empreendimento ADD COLUMN dt_renegociacao_contrato DATE;
ALTER TABLE acgsm001.acgtb050_empreendimento ADD COLUMN nu_produto           INT2;           
ALTER TABLE acgsm001.acgtb050_empreendimento ADD COLUMN vr_encargo_atraso    NUMERIC(16,2);  
ALTER TABLE acgsm001.acgtb050_empreendimento ADD COLUMN vr_mora_multa        NUMERIC(16,2);  
ALTER TABLE acgsm001.acgtb050_empreendimento ADD COLUMN vr_iof_complementar  NUMERIC(16,2);  
ALTER TABLE acgsm001.acgtb050_empreendimento ADD COLUMN vr_diferenca_prestacao NUMERIC(16,2);
ALTER TABLE acgsm001.acgtb050_empreendimento ADD COLUMN vr_total_atraso      NUMERIC(16,2);  
ALTER TABLE acgsm001.acgtb050_empreendimento ADD COLUMN vr_saldo_pro_rata    NUMERIC(16,2);  
ALTER TABLE acgsm001.acgtb050_empreendimento ADD COLUMN vr_divida_total      NUMERIC(16,2); 

comment on column acgsm001.acgtb050_empreendimento.ic_contrato_execucao_judicial is
'Indica se o contrato possui inclusão das SE de execução judicial ou extra judicial (Grupo 40 - da SE041 até SE049).';

comment on column acgsm001.acgtb050_empreendimento.ic_contrato_renegociado is
'Indica se o contrato foi renegociado ou repactuado (Tipo de Pedido - TP098).';

comment on column acgsm001.acgtb050_empreendimento.dt_renegociacao_contrato is
'Data de renegociação/ repactuação do contrato (Inclusão TP098).';

comment on column acgsm001.acgtb050_empreendimento.nu_produto is
'Número do SIICO/Produto.';

comment on column acgsm001.acgtb050_empreendimento.vr_encargo_atraso is
'Valor do Encargo em Atraso.';

comment on column acgsm001.acgtb050_empreendimento.vr_mora_multa is
'Valor Mora + Multa.';

comment on column acgsm001.acgtb050_empreendimento.vr_iof_complementar is
'Valor do IOF Complementar.';

comment on column acgsm001.acgtb050_empreendimento.vr_diferenca_prestacao is
'Valor da diferença de prestação.';

comment on column acgsm001.acgtb050_empreendimento.vr_total_atraso is
'Valor do total em atraso.';

comment on column acgsm001.acgtb050_empreendimento.vr_saldo_pro_rata is
'Valor do saldo pro-rata.';

comment on column acgsm001.acgtb050_empreendimento.vr_divida_total is
'Valor da dívida total. É a soma dos campos: vr_encargo_atraso, vr_mora_multa, vr_iof_complementar, vr_diferenca_prestacao, vr_total_atraso e vr_saldo_pro_rata.';