/*==============================================================*/
/*           SCRIPT V2_00_0_78__SIACG_DLL						*/
/*==============================================================*/

-- Atualização do co_evento_despesa
update acgsm001.acgtb094_gestao_tipo_despesa
set nu_dv_tipo_despesa=substring(co_evento_despesa, length(co_evento_despesa),length(co_evento_despesa)-1);

-- Atualização do dv_tipo_despesa
update acgsm001.acgtb094_gestao_tipo_despesa
set co_evento_despesa=lpad(substring(co_evento_despesa, 1,length(co_evento_despesa)-1), 5, '0')