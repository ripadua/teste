/*==============================================================*/
/*           SCRIPT V2_00_0_79__SIACG_DLL						*/
/*==============================================================*/

COMMENT ON COLUMN acgsm001.acgtb097_fonte_expressao.de_representacao IS 'Campo que irá armazenar a representação da fonte de expressão, quando o tipo da expressão for: 3 - Operador e 4 - Condicionante.';


ALTER TABLE acgsm001.acgtb101_formula ADD COLUMN ic_situacao boolean NOT NULL default true;
COMMENT ON COLUMN acgsm001.acgtb101_formula.ic_situacao IS 'Campo que irá armazenar a situação da Fórmula: true - ativo, false - inativo';

/*==============================================================*/
/*  Reverse   SCRIPT V2_00_0_79__SIACG_DLL						*/
/*==============================================================*/

--ALTER TABLE acgsm001.acgtb097_fonte_expressao DROP COLUMN de_representacao;
--ALTER TABLE acgsm001.acgtb101_formula DROP COLUMN ic_situacao;