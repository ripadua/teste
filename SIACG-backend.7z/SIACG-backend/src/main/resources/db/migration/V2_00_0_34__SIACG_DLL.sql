/*==============================================================*/
/* SCRIPT V2_00_0_34__SIACG_DLL									*/
/*==============================================================*/


ALTER TABLE acgsm001.acgtb081_imovel ALTER COLUMN no_cartorio TYPE character varying;
COMMENT ON COLUMN acgsm001.acgtb081_imovel.no_cartorio IS 'Nome do cartorio de registro do imóvel,';