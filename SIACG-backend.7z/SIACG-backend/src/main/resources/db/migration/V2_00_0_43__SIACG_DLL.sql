/*==============================================================*/
/* SCRIPT V2_00_0_43__SIACG_DLL									*/
/*==============================================================*/

-- Add colunas na acgtb060_parametro_garantia
ALTER TABLE acgsm001.acgtb060_parametro_garantia ADD COLUMN vr_maximo_contrato numeric(16,2);
ALTER TABLE acgsm001.acgtb060_parametro_garantia ADD COLUMN vr_minimo_contrato numeric(16,2);
ALTER TABLE acgsm001.acgtb060_parametro_garantia ADD COLUMN dh_inicio_prazo date;
ALTER TABLE acgsm001.acgtb060_parametro_garantia ADD COLUMN dh_fim_prazo date;
ALTER TABLE acgsm001.acgtb060_parametro_garantia ADD COLUMN pc_juros numeric(16,2);
ALTER TABLE acgsm001.acgtb060_parametro_garantia ADD COLUMN de_homologacao character varying(255);

COMMENT ON COLUMN acgsm001.acgtb060_parametro_garantia.vr_maximo_contrato IS 'Valor máximo aceito para o contrato';
COMMENT ON COLUMN acgsm001.acgtb060_parametro_garantia.vr_minimo_contrato IS 'Valor mínimo aceito para o contrato';
COMMENT ON COLUMN acgsm001.acgtb060_parametro_garantia.dh_inicio_prazo IS 'Inicio do prazo do Parametro Garantia.';
COMMENT ON COLUMN acgsm001.acgtb060_parametro_garantia.dh_fim_prazo IS 'Fim do prazo do Parametro Garantia.';
COMMENT ON COLUMN acgsm001.acgtb060_parametro_garantia.pc_juros IS 'Percentual de juros do Parametro produto.';
COMMENT ON COLUMN acgsm001.acgtb060_parametro_garantia.de_homologacao IS 'Justificaticativa homologação gestor GEGAR.';

-- Atualiza colunas que foram adicionadas na tabela acgtb060_parametro_garantia e que originaram da tabela acgtb057_parametro_produto
UPDATE 
	acgsm001.acgtb060_parametro_garantia garantia
SET 
	dh_inicio_prazo = produto.dh_inicio_prazo,
	dh_fim_prazo = produto.dh_fim_prazo,
	pc_juros = produto.pc_juros,
	de_homologacao = produto.de_homologacao
FROM 
	(
		SELECT 
			nu_produto, nu_modalidade, pc_juros, dh_inicio_prazo, dh_fim_prazo, de_homologacao 
		FROM 
			acgsm001.acgtb057_parametro_produto pp
	) produto

WHERE
	garantia.nu_produto = produto.nu_produto 
	AND garantia.nu_modalidade = produto.nu_modalidade;

-- Criando tabela intermediária entre acgtb060_parametro_garantia e acgtb085_segmento_cliente
CREATE TABLE acgsm001.acgtb086_segmento_garantia
(
	nu_segmento_cliente integer,
	nu_parametro_garantia integer,
	CONSTRAINT fk_acgtb086_acgtb085 FOREIGN KEY (nu_segmento_cliente)
		REFERENCES acgsm001.acgtb085_segmento_cliente (nu_segmento_cliente) MATCH SIMPLE
		ON UPDATE RESTRICT ON DELETE RESTRICT,
	CONSTRAINT fk_acgtb086_acgtb060 FOREIGN KEY (nu_parametro_garantia)
		REFERENCES acgsm001.acgtb060_parametro_garantia (nu_parametro_garantia) MATCH SIMPLE
		ON UPDATE RESTRICT ON DELETE RESTRICT
);
COMMENT ON TABLE acgsm001.acgtb086_segmento_garantia IS 'Tabela de relacionamento entre a tabela 057_parametro_produto e a 060_parametro_garantia.';
COMMENT ON COLUMN acgsm001.acgtb086_segmento_garantia.nu_segmento_cliente IS 'Número identificador do segmento do cliente.';
COMMENT ON COLUMN acgsm001.acgtb086_segmento_garantia.nu_parametro_garantia IS 'Número da garantia do produto.';

-- Alimenta tabela acgtb086_parametro_garantia_seg e que originaram da tabela acgtb086_parametro_produto_seg
INSERT INTO acgsm001.acgtb086_segmento_garantia(
	SELECT DISTINCT
		pgs.nu_segmento_cliente, pg.nu_parametro_garantia
	FROM  	
		acgsm001.acgtb060_parametro_garantia pg
	INNER JOIN 
		acgsm001.acgtb086_parametro_produto_seg pgs ON pg.nu_produto = pgs.nu_produto AND pg.nu_modalidade = pgs.nu_modalidade
);

DROP TABLE IF EXISTS acgsm001.acgtb086_parametro_produto_seg;

/*==============================================================*/
/* Table: acgtb060_parametro_garantia  Reverse Script           */
/*==============================================================*/
-- Deletando colunas na acgtb060_parametro_garantia
--ALTER TABLE acgsm001.acgtb060_parametro_garantia DROP COLUMN vr_maximo_contrato;
--ALTER TABLE acgsm001.acgtb060_parametro_garantia DROP COLUMN vr_minimo_contrato;
--ALTER TABLE acgsm001.acgtb060_parametro_garantia DROP COLUMN dh_inicio_prazo;
--ALTER TABLE acgsm001.acgtb060_parametro_garantia DROP COLUMN dh_fim_prazo;
--ALTER TABLE acgsm001.acgtb060_parametro_garantia DROP COLUMN pc_juros;
--ALTER TABLE acgsm001.acgtb060_parametro_garantia DROP COLUMN de_homologacao;