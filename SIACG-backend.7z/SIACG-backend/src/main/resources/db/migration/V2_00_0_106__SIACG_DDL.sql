/*==============================================================*/
/*           SCRIPT V2_00_0_106__SIACG_DDL				        */
/*==============================================================*/

/*============================================================================*/

ALTER TABLE acgsm001.acgtb001_contrato
  ADD COLUMN dt_ultima_atualizacao date;
  
  comment on column acgsm001.acgtb001_contrato.dt_ultima_atualizacao is
'Indica quando o contrato sofreu alguma alteração em carga/rotina pentaho';

/*========================================*/
/* Script de reversão					  */
/*========================================*/
--ALTER TABLE acgsm001.acgtb001_contrato DROP COLUMN dt_ultima_atualizacao;