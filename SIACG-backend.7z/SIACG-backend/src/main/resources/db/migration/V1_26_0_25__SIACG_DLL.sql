--Script atualização tabela 40.
UPDATE acgsm001.acgtb040_relatorio r
   SET de_endereco= 'ftp://ftp.go.caixa/PEDES/SIACG/rel-app-financeira-bloqueada/'
 WHERE r.nu_relatorio = 6;