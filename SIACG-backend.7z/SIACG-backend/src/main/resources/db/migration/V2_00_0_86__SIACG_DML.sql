/*==============================================================*/
/*           SCRIPT V2_00_0_86__SIACG_DLL						*/
/*==============================================================*/


/*==============================================================*/
/* Table: acgtb105_tipo_expressao                               */
/*==============================================================*/
create table acgsm001.acgtb105_tipo_expressao (
   nu_tipo_expressao    integer                 not null,
   no_tipo_expressao    character varying(20)          not null,
   constraint PK_ACGTB105_TIPO_EXPRESSAO primary key (nu_tipo_expressao)
);

comment on table acgsm001.acgtb105_tipo_expressao is
'Tabela responsável por armazenar os tipos de expressão utilizados na composição de fórmulas.';

comment on column acgsm001.acgtb105_tipo_expressao.nu_tipo_expressao is
'Identificador que representa o tipo de expressão e que irá compor as fórmulas.';

comment on column acgsm001.acgtb105_tipo_expressao.no_tipo_expressao is
'Armazena a descrição do tipo de expressão, podendo ser:

1 - Dado
2 - Valor
3 - Operador
4 - Condicionante
5 - Função
6 - Fórmula.';

INSERT INTO acgsm001.acgtb105_tipo_expressao(nu_tipo_expressao, no_tipo_expressao) VALUES (1, 'Dado');
INSERT INTO acgsm001.acgtb105_tipo_expressao(nu_tipo_expressao, no_tipo_expressao) VALUES (2, 'Valor');
INSERT INTO acgsm001.acgtb105_tipo_expressao(nu_tipo_expressao, no_tipo_expressao) VALUES (3, 'Operador');
INSERT INTO acgsm001.acgtb105_tipo_expressao(nu_tipo_expressao, no_tipo_expressao) VALUES (4, 'Condicionante');
INSERT INTO acgsm001.acgtb105_tipo_expressao(nu_tipo_expressao, no_tipo_expressao) VALUES (5, 'Função');
INSERT INTO acgsm001.acgtb105_tipo_expressao(nu_tipo_expressao, no_tipo_expressao) VALUES (6, 'Fórmula');


/*==============================================================*/
/* Table: acgtb097_fonte_expressao                              */
/*==============================================================*/
alter table acgsm001.acgtb097_fonte_expressao rename ic_tipo_expressao to nu_tipo_expressao;
alter table acgsm001.acgtb097_fonte_expressao drop constraint ckc_acgtb097_01;
alter table acgsm001.acgtb097_fonte_expressao add constraint fk_acgtb097_acgtb105 foreign key (nu_tipo_expressao)
      references acgsm001.acgtb105_tipo_expressao (nu_tipo_expressao) on delete restrict on update restrict;
      
/*==============================================================*/
/* Table: acgtb100_formula_item                                 */
/*==============================================================*/
alter table acgsm001.acgtb100_formula_item alter column nu_fonte_expressao drop not null;
alter table acgsm001.acgtb100_formula_item add column nu_tipo_expressao integer not null;
comment on column acgsm001.acgtb100_formula_item.nu_tipo_expressao IS 'Identificador que representa o tipo de expressão e que irá compor as fórmulas.';

alter table acgsm001.acgtb100_formula_item add constraint fk_acgtb100_acgtb105 foreign key (nu_tipo_expressao)
      references acgsm001.acgtb105_tipo_expressao (nu_tipo_expressao) on delete restrict on update restrict;


/*==============================================================*/
/* Table: acgtb099_parametro_frmla_item                         */
/*==============================================================*/
alter table acgsm001.acgtb099_parametro_frmla_item add column nu_tipo_expressao integer not null;
comment on column acgsm001.acgtb099_parametro_frmla_item.nu_tipo_expressao IS 'Identificador que representa o tipo de expressão e que irá compor as fórmulas.';

alter table acgsm001.acgtb099_parametro_frmla_item alter column de_valor_parametro drop not null;

alter table acgsm001.acgtb099_parametro_frmla_item add column nu_fonte_expressao integer;
COMMENT ON COLUMN acgsm001.acgtb099_parametro_frmla_item.nu_fonte_expressao IS 'Identificador da fonte da expressão, equivalente ao tipo informado.
Sendo do tipo Operador ou Condicionante, os valores da fonte de expressão serão pré definidos;
Sendo do tipo Dado, haverá um cadastro para alimentar a tabela;
Sendo do tipo Fórmula ou Função, os valores serão adicionados automaticamente ao ser criados uma fórmula ou função.';

alter table acgsm001.acgtb099_parametro_frmla_item add constraint fk_acgtb099_acgtb105 foreign key (nu_tipo_expressao)
      references acgsm001.acgtb105_tipo_expressao (nu_tipo_expressao) on delete restrict on update restrict;

alter table acgsm001.acgtb099_parametro_frmla_item add constraint fk_acgtb099_acgtb097 foreign key (nu_fonte_expressao)
      references acgsm001.acgtb097_fonte_expressao (nu_fonte_expressao) on delete restrict on update restrict;



/*==============================================================*/
/* Table: acgtb101_formula                                      */
/*==============================================================*/
alter table acgsm001.acgtb101_formula add column nu_fonte_expressao integer;
COMMENT ON COLUMN acgsm001.acgtb101_formula.nu_fonte_expressao IS 'Identificador da fonte da expressão, equivalente ao tipo informado.
Sendo do tipo Operador ou Condicionante, os valores da fonte de expressão serão pré definidos;
Sendo do tipo Dado, haverá um cadastro para alimentar a tabela;
Sendo do tipo Fórmula ou Função, os valores serão adicionados automaticamente ao ser criados uma fórmula ou função.';

alter table acgsm001.acgtb101_formula add constraint fk_acgtb101_acgtb097 foreign key (nu_fonte_expressao)
      references acgsm001.acgtb097_fonte_expressao (nu_fonte_expressao) on delete restrict on update restrict;
      

/*==============================================================*/
/* Revert Table: acgtb105_tipo_expressao                        */
/*==============================================================*/
--alter table acgsm001.acgtb097_fonte_expressao drop constraint fk_acgtb097_acgtb105;
--alter table acgsm001.acgtb097_fonte_expressao rename nu_tipo_expressao to ic_tipo_expressao;

/*COMMENT ON COLUMN acgsm001.acgtb097_fonte_expressao.ic_tipo_expressao IS 'Indentificador que representa o tipo de expressão, podendo ser:
1 - Dado
2 - Valor
3 - Operador
4 - Condicionante
5 - Função
6 - Fórmula';*/

--alter table acgsm001.acgtb097_fonte_expressao add constraint ckc_acgtb097_01 CHECK (ic_tipo_expressao = ANY (ARRAY[1, 2, 3, 4, 5, 6]));

--alter table acgsm001.acgtb100_formula_item alter column nu_fonte_expressao set not null;

--alter table acgsm001.acgtb100_formula_item drop constraint fk_acgtb100_acgtb105;
--alter table acgsm001.acgtb100_formula_item drop column nu_tipo_expressao;

--alter table acgsm001.acgtb099_parametro_frmla_item drop constraint fk_acgtb099_acgtb105;
--alter table acgsm001.acgtb099_parametro_frmla_item drop column nu_tipo_expressao;

--alter table acgsm001.acgtb099_parametro_frmla_item drop constraint fk_acgtb099_acgtb097;
--alter table acgsm001.acgtb099_parametro_frmla_item drop column nu_fonte_expressao;

--drop table acgsm001.acgtb105_tipo_expressao;