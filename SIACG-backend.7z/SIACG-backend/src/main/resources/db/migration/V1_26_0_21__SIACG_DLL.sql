
-- Alteração onome tabela acgsm001.acgtb076_garantia_maquina_eqpo
ALTER TABLE acgsm001.acgtb076_garantia_maquina_eqpo RENAME TO acgtb076_garantia_maquina_eqpmo;

-- Alteração onome tabela acgsm001.acgtb078_garantia_pro_agricola
ALTER TABLE acgsm001.acgtb078_garantia_pro_agricola RENAME TO acgtb078_garantia_prdto_agricola;
