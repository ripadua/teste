/*==============================================================*/
/*           SCRIPT V2_00_0_84__SIACG_DLL						*/
/*==============================================================*/

ALTER TABLE acgsm001.acgtb103_documento_lancamento_evento ALTER COLUMN no_titular_imovel  DROP NOT NULL;
ALTER TABLE acgsm001.acgtb103_documento_lancamento_evento ALTER COLUMN dt_movimento  DROP NOT NULL;
      
/*########################### SCRIPT ROLLBACK ##############################*/
--DROP SEQUENCE acgsm001.sq0103_documento_lancamento_evento;