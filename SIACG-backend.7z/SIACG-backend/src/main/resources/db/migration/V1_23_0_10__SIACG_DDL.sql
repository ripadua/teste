/*Criando Coluna na tabela acgtb053_recebido*/
ALTER TABLE "acgsm001"."acgtb053_recebido" ADD COLUMN "nu_ctrto_comercializacao" INT8 NOT NULL;
ALTER TABLE "acgsm001"."acgtb053_recebido" ADD COLUMN "ic_situacao_conciliacao" INT8 NOT NULL;

/*Criando sequence para tabela sq053_recebido*/
CREATE SEQUENCE acgsm001.sq053_recebido
  INCREMENT 1
  MINVALUE 1
  MAXVALUE 9223372036854775807
  START 1
  CACHE 1;
ALTER TABLE acgsm001.sq053_recebido
  OWNER TO postgres;
  
/*Inserindo valores na tabela acgtb008_grupo_garantia*/
INSERT INTO acgsm001.acgtb008_grupo_garantia( nu_grupo_garantia, no_grupo_garantia, ic_acompanha, ic_ativo) VALUES (10, 'CESSÃO', FALSE, TRUE);
INSERT INTO acgsm001.acgtb008_grupo_garantia( nu_grupo_garantia, no_grupo_garantia, ic_acompanha, ic_ativo) VALUES (11, 'ALIENAÇÃO FIDUCIÁRIA', FALSE, TRUE);
INSERT INTO acgsm001.acgtb008_grupo_garantia( nu_grupo_garantia, no_grupo_garantia, ic_acompanha, ic_ativo) VALUES (12, 'HIPOTECA', FALSE, TRUE);
INSERT INTO acgsm001.acgtb008_grupo_garantia( nu_grupo_garantia, no_grupo_garantia, ic_acompanha, ic_ativo) VALUES (13, 'CESSÃO DE DIREITOS CREDITÓRIOS', FALSE, TRUE);
INSERT INTO acgsm001.acgtb008_grupo_garantia( nu_grupo_garantia, no_grupo_garantia, ic_acompanha, ic_ativo) VALUES (14, 'CAUÇÃO', FALSE, TRUE);
INSERT INTO acgsm001.acgtb008_grupo_garantia( nu_grupo_garantia, no_grupo_garantia, ic_acompanha, ic_ativo) VALUES (15, 'OUTRAS GARANTIAS NÃO FIDEJUSSÓRIAS', FALSE, TRUE);

/*Alterando a coluna nu_garantiapara auto Incremento da tabela acgsm001.acgtb011_garantia*/
ALTER TABLE "acgsm001"."acgtb011_garantia" ALTER COLUMN "nu_garantia" SET DEFAULT nextval('acgsm001.sq011_garantia'::regclass);
/*Inserir valores na tabela acgtb011_garantia*/
INSERT INTO acgsm001.acgtb011_garantia(nu_grupo_garantia, no_garantia, co_operacao, ic_ativo, ic_cadastro_manual) VALUES (10, 'OUTROS', 0199, TRUE, FALSE);
INSERT INTO acgsm001.acgtb011_garantia(nu_grupo_garantia, no_garantia, co_operacao, ic_ativo, ic_cadastro_manual) VALUES (11, 'BENS E DIREITOS INTEGRANTES DE PATRIMÔNIO DE AFETAÇÃO', 0128, TRUE, FALSE);
INSERT INTO acgsm001.acgtb011_garantia(nu_grupo_garantia, no_garantia, co_operacao, ic_ativo, ic_cadastro_manual) VALUES (12, 'PESSOA JURÍDICA', 0502, TRUE, FALSE);
INSERT INTO acgsm001.acgtb011_garantia(nu_grupo_garantia, no_garantia, co_operacao, ic_ativo, ic_cadastro_manual) VALUES (12, 'OUTROS IMÓVEIS', 0527, TRUE, FALSE);
INSERT INTO acgsm001.acgtb011_garantia(nu_grupo_garantia, no_garantia, co_operacao, ic_ativo, ic_cadastro_manual) VALUES (12, 'BENS E DIREITOS INTEGRANTES DE PATRIMÔNIO DE AFETAÇÃO', 0565, TRUE, FALSE);
INSERT INTO acgsm001.acgtb011_garantia(nu_grupo_garantia, no_garantia, co_operacao, ic_ativo, ic_cadastro_manual) VALUES (13, 'APLICAÇÕES FINANCEIRAS - RENDA FIXA', 0105, TRUE, FALSE);
INSERT INTO acgsm001.acgtb011_garantia(nu_grupo_garantia, no_garantia, co_operacao, ic_ativo, ic_cadastro_manual) VALUES (13, 'AÇÕES E DEBÊNTURES', 0106, TRUE, FALSE);
INSERT INTO acgsm001.acgtb011_garantia(nu_grupo_garantia, no_garantia, co_operacao, ic_ativo, ic_cadastro_manual) VALUES (13, 'OUTROS', 0199, TRUE, FALSE);
INSERT INTO acgsm001.acgtb011_garantia(nu_grupo_garantia, no_garantia, co_operacao, ic_ativo, ic_cadastro_manual) VALUES (14, 'APLICAÇÕES FINANCEIRAS - RENDA VARIÁVEL', 0205, TRUE, FALSE);
INSERT INTO acgsm001.acgtb011_garantia(nu_grupo_garantia, no_garantia, co_operacao, ic_ativo, ic_cadastro_manual) VALUES (14, 'DEPÓSITO À VISTA, PRAZO, POUPANÇA, OURO, TÍTULOS FEDERAIS.', 0210, TRUE, FALSE);
INSERT INTO acgsm001.acgtb011_garantia(nu_grupo_garantia, no_garantia, co_operacao, ic_ativo, ic_cadastro_manual) VALUES (15, 'OUTRAS', 0799, TRUE, FALSE);