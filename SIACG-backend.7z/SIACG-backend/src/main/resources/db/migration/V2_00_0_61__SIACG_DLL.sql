/*==============================================================*/
/* Table: acgsm001.acgtb091_gestao_tipo_fornecedor              */
/*==============================================================*/


ALTER TABLE acgsm001.acgtb091_gestao_tipo_fornecedor
	add column ic_situacao BOOLEAN null;
	
COMMENT ON COLUMN acgsm001.acgtb091_gestao_tipo_fornecedor.ic_situacao IS 'Situação do tipo Fornecedor se esta ativo';

	

/*==============================================================*/
/* Reverse: acgsm001.acgtb091_gestao_tipo_fornecedor           */
/*==============================================================*/


--ALTER TABLE acgsm001.acgtb091_gestao_tipo_fornecedor
--	DROP column ic_situacao BOOLEAN null;
	
