/*Criando Coluna na tabela acgtb053_recebido*/
ALTER TABLE "acgsm001"."acgtb053_recebido" ALTER COLUMN "no_sacado" DROP NOT NULL;
