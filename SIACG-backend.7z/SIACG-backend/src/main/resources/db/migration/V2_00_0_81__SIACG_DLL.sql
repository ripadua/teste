/*==============================================================*/
/*           SCRIPT V2_00_0_80__SIACG_DLL						*/
/*==============================================================*/

ALTER TABLE acgsm001.acgtb081_imovel ADD COLUMN ic_tipo_execucao character varying(1); 
COMMENT ON COLUMN acgsm001.acgtb081_imovel.ic_tipo_execucao IS 'Tipo do valor de execucao do Imovel 1-Sem execução 2-Em execução 3-Em averbação 4- Conformidade 5- Consolidação';

      
/*########################### SCRIPT ROLLBACK ##############################*/
--ALTER TABLE acgsm001.acgtb081_imovel DROP COLUMN ic_tipo_execucao;