ALTER TABLE acgsm001.acgtb068_garantia_produto DROP CONSTRAINT fk_acgtb068_reference_acgtb011;

ALTER TABLE acgsm001.acgtb068_garantia_produto
  ADD CONSTRAINT fk_acgtb068_acgtb011 FOREIGN KEY (nu_garantia)
      REFERENCES acgsm001.acgtb011_garantia (nu_garantia) MATCH SIMPLE
      ON UPDATE RESTRICT ON DELETE RESTRICT;
      
COMMENT ON COLUMN acgsm001.acgtb068_garantia_produto.nu_garantia IS 'Número de identificação da garantia BACEN.';
COMMENT ON COLUMN acgsm001.acgtb068_garantia_produto.nu_produto IS 'Identifica o produto de crédito. Dado retornado da view acgvw009_produto.';
COMMENT ON COLUMN acgsm001.acgtb068_garantia_produto.nu_modalidade IS 'Número da modalidade de contratação do produto.';
COMMENT ON TABLE acgsm001.acgtb073_garantia_caixa_produto IS 'Tabela de vinculação entre os produtos Caixa e o produto de crédito.';
COMMENT ON COLUMN acgsm001.acgtb073_garantia_caixa_produto.nu_produto_caixa IS 'Número de identificação do produto caixa (garantia Caixa). Referente ao produto que pode ser garantia (Caixa) de outro produto.';
COMMENT ON COLUMN acgsm001.acgtb073_garantia_caixa_produto.nu_produto IS 'Identifica o produto de crédito. Dado retornado da view acgvw009_produto.';
COMMENT ON COLUMN acgsm001.acgtb073_garantia_caixa_produto.nu_modalidade IS 'Número da modalidade de contratação do produto.';      

