/*==============================================================*/
/*           SCRIPT V2_00_0_98__SIACG_DLL						*/
/*==============================================================*/

/*==============================================================*/
/* Table: acgsm001.acgtb081_imovel                              */
/*==============================================================*/

ALTER TABLE acgsm001.acgtb104_execucao_imovel DROP CONSTRAINT ck_acgtb104_01;

ALTER TABLE acgsm001.acgtb104_execucao_imovel
  ADD CONSTRAINT ck_acgtb104_01 CHECK (ic_execucao_conformidade::bpchar = ANY (ARRAY['CFC'::bpchar, 'CIM'::bpchar, 'CGE'::bpchar, 'LAI'::bpchar, 'VAR'::bpchar, 'ITR'::bpchar, 'CIR'::bpchar, 'CPD'::bpchar, 'TDI'::bpchar, 'ITI'::bpchar]));
