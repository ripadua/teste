/*==============================================================*/
/*           SCRIPT V2_00_0_92__SIACG_DLL						*/
/*==============================================================*/

/*==============================================================*/
/* Table: acgsm001.acgtb041_segmento                            */
/*==============================================================*/
alter table acgsm001.acgtb041_segmento add column ic_visualiza_novo_cartao boolean not null default false;

comment on column acgsm001.acgtb041_segmento.ic_visualiza_novo_cartao is
'Campo que define quais segmentos (portes) poderão visualizar a nova tela de parametrização de cartão de crédito.';

create sequence acgsm001.acgsq041_segmento;
ALTER SEQUENCE acgsm001.acgsq041_segmento RESTART WITH 5;
ALTER TABLE acgsm001.acgtb041_segmento ALTER COLUMN nu_segmento SET DEFAULT nextval('acgsm001.acgsq041_segmento'::regclass);


/*==============================================================*/
/* Table: acgsm001.acgtb081_imovel                              */
/*==============================================================*/
alter table acgsm001.acgtb081_imovel add column co_livro_serventia character varying(3);
alter table acgsm001.acgtb081_imovel add column co_cnm  character varying(15);

/*==============================================================*/
/* Reverse Table                                                */
/*==============================================================*/
--alter table acgsm001.acgtb041_segmento drop column ic_visualiza_novo_cartao;
--ALTER TABLE acgsm001.acgtb041_segmento ALTER COLUMN nu_segmento drop DEFAULT;
--drop sequence acgsm001.acgsq041_segmento;

--alter table acgsm001.acgtb081_imovel drop column co_livro_serventia;
--alter table acgsm001.acgtb081_imovel drop column co_cnm;