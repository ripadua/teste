/*==============================================================*/
/* Table: acgtb051_ctrto_comercializacao
 * Acescentando coluna nu_indicador_financeiro fk da tabela acgtb083_indicador_financeiro */
/*==============================================================*/

ALTER TABLE acgsm001.acgtb051_ctrto_comercializacao ADD COLUMN nu_indicador_financeiro bigint;

comment on column acgsm001.acgtb051_ctrto_comercializacao.nu_indicador_financeiro is
'Identificador da tabela indicador financeiro. (FK)';

alter table acgsm001.acgtb051_ctrto_comercializacao
   add constraint FK_ACGTB051_ACGTB083 foreign key (nu_indicador_financeiro)
      references acgsm001.acgtb083_indicador_financeiro (nu_indicador_financeiro)
      on delete restrict on update restrict;