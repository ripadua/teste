/*==============================================================*/
/*           SCRIPT V2_00_0_108__SIACG_DLL						*/
/*==============================================================*/

INSERT INTO acgsm001.acgtb017_propriedade(no_propriedade, no_valor_propriedade, no_grupo, de_comentario) 
    SELECT 'relatorio.monitoramento', 'http://relatoriapedes.bi.caixa/reportspbi/powerbi/PEDESGO%20-%207875/SIACG/DES/SIACG_PAINEL_ROTINA', 'relatorio', 'Path do relatório de monitoramento no ambiente de realórios'
    WHERE NOT EXISTS (
        select * from acgsm001.acgtb017_propriedade where no_propriedade = 'relatorio.monitoramento'
);

/*========================================*/
/* Script de reversão					  */
/*========================================*/
--delete from acgsm001.acgtb017_propriedade
--where 
--no_propriedade = 'relatorio.monitoramento';
