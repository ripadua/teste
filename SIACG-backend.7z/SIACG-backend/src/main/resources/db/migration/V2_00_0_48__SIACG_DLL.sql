
/*==============================================================*/
/* Table: acgtb060_parametro_garantia                           */
/*==============================================================*/
ALTER TABLE acgsm001.acgtb060_parametro_garantia ALTER COLUMN vr_maximo SET DEFAULT 0;


/*==============================================================*/
/* Table: acgtb060_parametro_garantia      Reverse Script       */
/*==============================================================*/

 -- ALTER TABLE acgsm001.acgtb060_parametro_garantia ALTER COLUMN vr_maximo DROP DEFAULT;