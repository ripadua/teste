
/*==============================================================*/
/* Alter Table: acgtb092_fornecedor                             */
/*==============================================================*/
alter table acgsm001.acgtb092_fornecedor 
  ALTER COLUMN de_telefone TYPE varchar(20);
   


/*==============================================================*/
/* Reverse  Alter Table: acgtb092_fornecedor                    */
/*==============================================================*/
-- alter table acgsm001.acgtb092_fornecedor 
-- DROP COLUMN de_telefone TYPE varchar(20) ;
   