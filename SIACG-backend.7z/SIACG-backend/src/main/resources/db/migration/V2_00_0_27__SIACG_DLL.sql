CREATE TABLE acgsm002.acgtbs10_empreendimento
(
  nu_tp_registro character varying(1),
  dt_contratacao date,
  nu_contrato_pj character varying(12),
  nu_contrato_pai bigint,
  vr_financiamento numeric(15,2),
  co_modalidade_rcr integer,
  vr_saldo_devedor numeric(15,2),
  vr_saldo_credor numeric(15,2),
  vr_financiamento_pj_liberado numeric(15,2),
  no_empreendimento text,
  co_apf integer,
  dt_finalizacao_obras date,
  vr_custo_total_obra numeric(15,2),
  ic_situacao_especial boolean,
  no_tomador text,
  nu_unidade integer,
  nu_cnpj_tomador text,
  ts_processamento timestamp without time zone,
  ts_grupo_processamento timestamp without time zone,
  sg_sistema_origem character varying(5)
);

COMMENT ON TABLE acgsm002.acgtbs10_empreendimento IS 'Tabela de Stage Area que armazena as informações de empreendimentos referente ao arquivo de interface do SIACI.';  
COMMENT ON COLUMN acgsm002.acgtbs10_empreendimento.nu_tp_registro IS 'Tipo de registro (dados do contrato).';
COMMENT ON COLUMN acgsm002.acgtbs10_empreendimento.dt_contratacao IS 'Data em que foi firmado o contrato entre CEF e construtora.';
COMMENT ON COLUMN acgsm002.acgtbs10_empreendimento.nu_contrato_pj IS 'Número do contrato PJ.';
COMMENT ON COLUMN acgsm002.acgtbs10_empreendimento.nu_contrato_pai IS 'Número do contrato pai.';
COMMENT ON COLUMN acgsm002.acgtbs10_empreendimento.vr_financiamento IS 'Valor do financiamento.';
COMMENT ON COLUMN acgsm002.acgtbs10_empreendimento.co_modalidade_rcr IS 'Codigo interno, SIACI que define a modalidade do contrato.';
COMMENT ON COLUMN acgsm002.acgtbs10_empreendimento.vr_saldo_devedor IS 'Saldo devedor do contrato.';
COMMENT ON COLUMN acgsm002.acgtbs10_empreendimento.vr_saldo_credor IS 'Saldo credor do contrato.';
COMMENT ON COLUMN acgsm002.acgtbs10_empreendimento.vr_financiamento_pj_liberado IS 'Soma de todos os TP285.';
COMMENT ON COLUMN acgsm002.acgtbs10_empreendimento.no_empreendimento IS 'Razão social do empreendimento.';
COMMENT ON COLUMN acgsm002.acgtbs10_empreendimento.co_apf IS 'Código APF.';
COMMENT ON COLUMN acgsm002.acgtbs10_empreendimento.dt_finalizacao_obras IS 'Data de finalização das obras.';
COMMENT ON COLUMN acgsm002.acgtbs10_empreendimento.vr_custo_total_obra IS 'Custo total da obra.';
COMMENT ON COLUMN acgsm002.acgtbs10_empreendimento.ic_situacao_especial IS 'Garantia dos Recebíveis. Campos Situação Especial do contrato PJ(079)= SE 404 possui garantia dos recebíveis, SE <> de 404 não possui garantia dos recebíveis.';
COMMENT ON COLUMN acgsm002.acgtbs10_empreendimento.no_tomador IS 'Nome da pessoa física/jurídica tomadora do Crédito.';
COMMENT ON COLUMN acgsm002.acgtbs10_empreendimento.nu_unidade IS 'Identificador da agência/SR contratante.';
COMMENT ON COLUMN acgsm002.acgtbs10_empreendimento.NU_CNPJ_TOMADOR IS 'CNPJ do tomador.';
COMMENT ON COLUMN acgsm002.acgtbs10_empreendimento.ts_processamento IS 'Data e hora do processamento das informações.';
COMMENT ON COLUMN acgsm002.acgtbs10_empreendimento.sg_sistema_origem IS 'Sigla do sistema de origem dos empreendimentos.';


CREATE TABLE acgsm002.acgtbs09_tipologia_unidade
(
  nu_tp_registro character varying(1),
  co_apf character varying(9),
  no_tipologia character varying(15),
  co_unidade bigint,
  de_complemento text,
  ic_situacao_origem text,
  vr_contratacao numeric(15,2),
  vr_atualizado numeric(15,2),
  ic_hipotecada_contratacao boolean,
  ic_mantida_hipoteca boolean,
  nu_unidade bigint, 
  ts_processamento timestamp without time zone,
  ts_grupo_processamento timestamp without time zone,
  sg_sistema_origem character varying(5)
);

COMMENT ON TABLE acgsm002.acgtbs09_tipologia_unidade IS 'Tabela de Stage Area que armazena as informações de tipologias e unidades habitacionais referente ao arquivo de interface do SIACI.';
COMMENT ON COLUMN acgsm002.acgtbs09_tipologia_unidade.nu_tp_registro IS 'Tipo de registro (dados do contrato).';
COMMENT ON COLUMN acgsm002.acgtbs09_tipologia_unidade.co_apf IS 'Código APF.';
COMMENT ON COLUMN acgsm002.acgtbs09_tipologia_unidade.no_tipologia IS 'Tipologia da UH.';
COMMENT ON COLUMN acgsm002.acgtbs09_tipologia_unidade.co_unidade IS 'Código identificador da unidade (siopi).';
COMMENT ON COLUMN acgsm002.acgtbs09_tipologia_unidade.de_complemento IS 'Campo complemento que identifica a unidade (siaci).';
COMMENT ON COLUMN acgsm002.acgtbs09_tipologia_unidade.vr_contratacao IS 'Valor de avaliação na contratação.';
COMMENT ON COLUMN acgsm002.acgtbs09_tipologia_unidade.vr_atualizado IS 'Valor de avaliação atualizado.';
COMMENT ON COLUMN acgsm002.acgtbs09_tipologia_unidade.ic_hipotecada_contratacao IS 'Unidade foi hipotecada na contratação.';
COMMENT ON COLUMN acgsm002.acgtbs09_tipologia_unidade.ic_mantida_hipoteca IS 'Unidade está mantida em hipoteca.';
COMMENT ON COLUMN acgsm002.acgtbs09_tipologia_unidade.nu_unidade IS 'Chave Primária da Unidade. Esse campo vai permitir que o SIACG consiga identificar quais unidades sofreram alteração, uma vez que o arquivo é incremental. Trata-se de um registro único para cada unidade, permitindo identificar aquela unidade de forma unívoca.';
COMMENT ON COLUMN acgsm002.acgtbs09_tipologia_unidade.ts_processamento IS 'Data e hora do processamento das informações.';
COMMENT ON COLUMN acgsm002.acgtbs09_tipologia_unidade.sg_sistema_origem IS 'Sigla do sistema de origem das unidades habitacionais.';