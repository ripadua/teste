-- inserts credenciador
 INSERT INTO  acgsm001.acgtb072_credenciador(no_credenciador, co_cnpj_credenciador) VALUES ('Banco Cooperativo do Brasil S.A. - Bancoob Adquirente', '02038232000164');
 INSERT INTO  acgsm001.acgtb072_credenciador(no_credenciador, co_cnpj_credenciador) VALUES ('Banrisul Cartões S.A.', '92934215000106');
 INSERT INTO  acgsm001.acgtb072_credenciador(no_credenciador, co_cnpj_credenciador) VALUES ('Bonsucesso Adquirencia Ltda', '20520298000178');
 INSERT INTO  acgsm001.acgtb072_credenciador(no_credenciador, co_cnpj_credenciador) VALUES ('Cielo S.A.', '01027058000191');
 INSERT INTO  acgsm001.acgtb072_credenciador(no_credenciador, co_cnpj_credenciador) VALUES ('Elavon do Brasil Soluções de Pagamento S.A.', '12592831000189');
 INSERT INTO  acgsm001.acgtb072_credenciador(no_credenciador, co_cnpj_credenciador) VALUES ('Getnet Adquirência e Serviços para Meios de Pagamentos S.A.', '10440482000154');
 INSERT INTO  acgsm001.acgtb072_credenciador(no_credenciador, co_cnpj_credenciador) VALUES ('Global Payments - Serviços de Pagamentos S.A.', '17887874000105');
 INSERT INTO  acgsm001.acgtb072_credenciador(no_credenciador, co_cnpj_credenciador) VALUES ('Redecard S.A', '01425787000104');
 INSERT INTO  acgsm001.acgtb072_credenciador(no_credenciador, co_cnpj_credenciador) VALUES ('Redecard S.A. (Credicard)', '01425787003383');
 INSERT INTO  acgsm001.acgtb072_credenciador(no_credenciador, co_cnpj_credenciador) VALUES ('Santander Adquirência', '05127438000230');