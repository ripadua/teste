/*============================================================*/
/*           SCRIPT V2_08_0_01__SIACG_DML				      */
/*============================================================*/

/*============================================================*/
/* Insere em acgsm001.acgtb081_imovel_bkp                     */
/*============================================================*/
INSERT INTO acgsm001.acgtb081_imovel_bkp (nu_imovel, co_livro_serventia, co_cnm)
SELECT nu_imovel, co_livro_serventia, co_cnm FROM acgsm001.acgtb081_imovel ORDER BY 1;

/*============================================================*/
/* Atualiza 1° dígito do co_livro_serventia para '2'         */
/*============================================================*/
UPDATE acgsm001.acgtb081_imovel 
SET co_livro_serventia = REPLACE(co_livro_serventia, substring(co_livro_serventia, 1, 1), '2') 
WHERE (co_livro_serventia IS NOT NULL AND co_livro_serventia != '');

/*============================================================*/
/* Recalcula o co_cnm                                         */
/*============================================================*/
UPDATE acgsm001.acgtb081_imovel 
SET co_cnm = (SELECT acgsm001.acgfn001_retorna_cnm_imovel(nu_imovel))
WHERE nu_imovel in (
			SELECT nu_imovel
			FROM acgsm001.acgtb081_imovel
			WHERE (co_livro_serventia IS NOT NULL AND co_livro_serventia != '')
			AND   (co_registro_garantia IS NOT NULL AND co_registro_garantia != '') 
		);

/*============================================================*/
/* Revert co_livro_serventia e co_cnm                         */
/*============================================================*/
-- UPDATE acgsm001.acgtb081_imovel i
-- SET 
-- co_livro_serventia = bkp.co_livro_serventia
-- ,co_cnm = bkp.co_cnm
-- FROM acgsm001.acgtb081_imovel_bkp bkp 
-- WHERE i.nu_imovel = bkp.nu_imovel;
		