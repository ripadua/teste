/*============================================================*/
/*           SCRIPT V3_0_0_02__SIACG_DDL		              */
/*============================================================*/

ALTER TABLE ACG.ACGTB001_CONTRATO ADD CO_IDNTR_OPERACAO_CANCELAMENTO VARCHAR2(22);

COMMENT ON COLUMN ACG.ACGTB001_CONTRATO.CO_IDNTR_OPERACAO_CANCELAMENTO IS 'Identificador da operação de cancelamento do gravame na CIP. Indica que o contrato já foi cancelado na CIP';

/*==============================================================*/
/* Reverter                                                     */
/*==============================================================*/
-- ALTER TABLE ACG.ACGTB001_CONTRATO DROP COLUMN CO_IDNTR_OPERACAO_CANCELAMENTO;