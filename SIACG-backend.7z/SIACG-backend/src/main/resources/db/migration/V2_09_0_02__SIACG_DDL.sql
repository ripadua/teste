/*============================================================*/
/*           SCRIPT V2_09_0_02__SIACG_DDL				      */
/*============================================================*/

--OBS: NÃO É NECESSÁRIO CRIAR REVERT DA EXCLUSÃO DESSAS TABELAS,
--POIS ELAS JÁ FORAM SUBSTITUIDAS PELA acgsm001.acgtb108_garantia_bem_cliente
drop table acgsm001.acgtb080_garantia_imovel;
drop table acgsm001.acgtb087_contrato_imovel;


/*==============================================================*/
/* Table: acgsm002.acgtb108_garantia_bem_cliente                */
/*==============================================================*/
CREATE SEQUENCE acgsm001.sq108_garantia_bem_cliente
  INCREMENT 1
  MINVALUE 1
  MAXVALUE 9223372036854775807
  START 1
  CACHE 1;

alter table acgsm001.acgtb108_garantia_bem_cliente add column nu_garantia_bem_cliente integer NOT NULL DEFAULT nextval('acgsm001.sq108_garantia_bem_cliente'::regclass);
alter table acgsm001.acgtb108_garantia_bem_cliente add column vr_utilizado numeric(16,2);

COMMENT ON COLUMN acgsm001.acgtb108_garantia_bem_cliente.nu_garantia_bem_cliente IS 'Identificador da garantia de bens do cliente, gerado automaticamente pelo sistema.';
COMMENT ON COLUMN acgsm001.acgtb108_garantia_bem_cliente.vr_utilizado IS 'Armazena o valor consumido pela garantia';

ALTER TABLE acgsm001.acgtb108_garantia_bem_cliente DROP CONSTRAINT pk_acgtb108_garantia_bem_clien;

alter table acgsm001.acgtb108_garantia_bem_cliente add CONSTRAINT pk_acgtb108_garantia_bem_clien PRIMARY KEY (nu_garantia_bem_cliente);


/* Retira espaços vazios da coluna no_sistema (HMP e PROD)
 * BUG 183710 - Correção para seguir sugestão do Welber
 * */
UPDATE acgsm001.acgtb038_operacao_sistema SET no_sistema = Trim(no_sistema);
