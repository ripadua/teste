-- Sequence: acgsm001.sq089_gestao_serventia

-- DROP SEQUENCE acgsm001.sq089_gestao_serventia;

CREATE SEQUENCE acgsm001.sq089_gestao_serventia
  INCREMENT 1
  MINVALUE 1
  MAXVALUE 9223372036854775807
  START 1
  CACHE 1;


-- Table: acgsm001.acgtb089_gestao_serventia

-- DROP TABLE acgsm001.acgtb089_gestao_serventia;

CREATE TABLE acgsm001.acgtb089_gestao_serventia
(	
  nu_gestao_serventia integer NOT NULL DEFAULT nextval('acgsm001.sq089_gestao_serventia'::regclass),
  co_cns character varying(6) NOT NULL UNIQUE,
  denominacao character varying NOT NULL,
  sg_uf character varying NOT NULL,
  de_municipio character varying NOT NULL,
  observacao character varying,
  ic_ativo boolean default true,
  CONSTRAINT pk_acgtb089_gestao_serventia PRIMARY KEY (nu_gestao_serventia)
)
WITH (
  OIDS=FALSE
);
COMMENT ON COLUMN acgsm001.acgtb089_gestao_serventia.nu_gestao_serventia IS 'Identificador da serventia';
