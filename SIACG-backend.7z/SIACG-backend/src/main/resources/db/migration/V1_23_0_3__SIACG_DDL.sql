ALTER TABLE acgsm001.acgtb050_empreendimento  ALTER COLUMN nu_contrato_pai TYPE bigint;
