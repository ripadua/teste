alter table acgsm001.acgtb055_log_bloqueio DROP COLUMN de_solicitacao;
alter table acgsm001.acgtb055_log_bloqueio DROP COLUMN de_retorno;

CREATE TABLE acgsm001.acgtb058_objeto_servico(
 nu_objeto_servico serial PRIMARY KEY,
 de_solicitacao text not null,
 de_retorno text NOT NULL
);

ALTER TABLE acgsm001.acgtb055_log_bloqueio ADD COLUMN nu_objeto_servico integer;

ALTER TABLE acgsm001.acgtb055_log_bloqueio
ADD CONSTRAINT fk_acgtb055_fk_acgtb058 FOREIGN KEY (nu_objeto_servico)
      REFERENCES acgsm001.acgtb058_objeto_servico (nu_objeto_servico);


CREATE SEQUENCE acgsm001.sq058_objeto_servico
  INCREMENT 1
  MINVALUE 1
  MAXVALUE 9223372036854775807
  START 1
  CACHE 1;
ALTER TABLE acgsm001.sq058_objeto_servico
  OWNER TO postgres;