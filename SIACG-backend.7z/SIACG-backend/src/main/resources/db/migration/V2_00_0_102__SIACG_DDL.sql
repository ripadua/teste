/*==============================================================*/
/*           SCRIPT V2_00_0_102__SIACG_DLL						*/
/*==============================================================*/

/*==============================================================*/
/* Table: acgsm001.acgtb109_undde_hbtcl_historico               */
/*==============================================================*/

truncate table acgsm001.acgtb109_undde_hbtcl_historico;

alter table acgsm001.acgtb109_undde_hbtcl_historico drop constraint fk_acgtb109_acgtb052;

alter table acgsm001.acgtb109_undde_hbtcl_historico rename nu_prmto_comercializao to nu_unidade_habitacional;

alter table acgsm001.acgtb109_undde_hbtcl_historico add constraint FK_ACGTB109_ACGTB049 foreign key (nu_unidade_habitacional)
      references acgsm001.acgtb049_unidade_habitacional (nu_unidade_habitacional) on delete restrict on update restrict;