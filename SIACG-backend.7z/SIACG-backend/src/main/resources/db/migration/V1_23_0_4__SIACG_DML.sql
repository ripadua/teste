BEGIN;
    INSERT INTO acgsm001.acgtb041_segmento(nu_segmento, no_segmento, de_funcionalidade, de_acao, vr_faixa_inicial, vr_faixa_final)
    VALUES ((select max(nu_segmento) + 1 from acgsm001.acgtb041_segmento), 'segmento pessoa física habitacional', 'segmento pessoa física habitacional', 'alterar', '0.0', '0.0');
COMMIT;
