/*==============================================================*/
/*           SCRIPT V2_00_0_104__SIACG_DLL						*/
/*==============================================================*/

/*============================================================================*/
/* #156120 - Alteração de destinatário nas rotinas do SIACG que mandam email  */
/*============================================================================*/

COMMENT ON COLUMN acgsm001.acgtb110_relatorio_destinatario.ic_relatorio IS 'Identificador do relatorio, podendo ser:
NP - Relatório de contratos não parametrizados
NO - Relatório de contratos novos';

/*========================================*/
/* Script de reversão					  */
/*========================================*/


-- DROP TABLE IF EXISTS acgsm001.acgtb110_relatorio_destinatario;