-- ###############    acgsm001.acgtb008_grupo_garantia
-- Adicionado novo grupo de garantia

INSERT INTO acgsm001.acgtb008_grupo_garantia(
            nu_grupo_garantia, no_grupo_garantia, ic_acompanha, ic_ativo)
    VALUES ((select max(coalesce(nu_grupo_garantia,0)) + 1 as nu from acgsm001.acgtb008_grupo_garantia), 'PRODUTOS AGRÍCOLAS', TRUE, TRUE);


-- Atualizando campo de acompanhamento de garantia

UPDATE acgsm001.acgtb008_grupo_garantia
   SET ic_acompanha= TRUE
 WHERE nu_grupo_garantia in (6, 8);
