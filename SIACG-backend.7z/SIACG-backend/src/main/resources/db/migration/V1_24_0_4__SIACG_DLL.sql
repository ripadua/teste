ALTER TABLE acgsm001.acgtb053_recebido
   ALTER COLUMN nu_recebido DROP DEFAULT;
ALTER TABLE acgsm001.acgtb053_recebido
   ALTER COLUMN nu_empreendimento DROP DEFAULT;
COMMENT ON COLUMN acgsm001.acgtb053_recebido.nu_empreendimento IS 'Arrmazena a informação do empreendimento de vinculação de um título recebido. Essa informação é importante quando é realizado o cruzamento das informações dos títulos recebidos com os cedentes vinculados as garantias do empreendimento. Os títulos que tiverem um cedente vinculado a garantia de um empreendimento devem ter a vinculação de pagamento a esse emprrendimento. Essa vinculação será utilizada na rotina de conciliação do prospecto com os recebimentos.';
