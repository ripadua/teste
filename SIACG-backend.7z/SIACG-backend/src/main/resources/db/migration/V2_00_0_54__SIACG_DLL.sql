/*==============================================================*/
/* Table: acgtb077_maquina_equipamento                          */
/*==============================================================*/
 ALTER TABLE acgsm001.acgtb077_maquina_equipamento ALTER COLUMN de_tipo_bem TYPE varchar(250);

/*==============================================================*/
/* Script Reverse  acgtb077_maquina_equipamento                 */
/*==============================================================*/
 --ALTER TABLE acgsm001.acgtb077_maquina_equipamento ALTER COLUMN de_tipo_bem TYPE varchar(100);