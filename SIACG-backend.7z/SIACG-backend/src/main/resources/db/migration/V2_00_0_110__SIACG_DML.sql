/*==============================================================*/
/*           SCRIPT V2_00_0_110__SIACG_DLL						*/
/*==============================================================*/


/* Gilberto Nery - 30-04-2020 - #114683 - Melhoria no tratamento de cedentes - Exclusão lógica	*/
/* Corrigindo script 109, o campo alterado será not null	*/

alter table IF EXISTS acgsm001.acgtb004_cedente drop column ic_ativo;

alter table acgsm001.acgtb004_cedente add column ic_ativo boolean not null DEFAULT true;
COMMENT ON COLUMN acgsm001.acgtb004_cedente.ic_ativo IS 'Caso verdadeiro informa que o cedente está ativo, caso falso informa que o cedente foi excluido e não está vinculado a nenhum contrato';


/*========================================*/
/* Script de reversão					  */
/*========================================*/
--alter table acgsm001.acgtb004_cedente drop column ic_ativo;