/*==============================================================*/
/* Table: acgtb091_gestao_tipo_fornecedor                       */
/*==============================================================*/
ALTER table acgsm001.acgtb091_gestao_tipo_fornecedor 
   ADD COLUMN co_tipo_fornecedor   INT    not null;

comment on column acgsm001.acgtb091_gestao_tipo_fornecedor.co_tipo_fornecedor is
'Codigo de indentificação do tipo de Fornecedor Credor';

/*==============================================================*/
/* Table: acgtb091_gestao_tipo_fornecedor INSERTS               */
/*==============================================================*/

  INSERT INTO acgsm001.acgtb091_gestao_tipo_fornecedor(co_tipo_fornecedor, no_tipo_fornecedor, de_tipo_fornecedor, dt_criacao) VALUES(1,'CARTORIO','CARTORIO', now());
  INSERT INTO acgsm001.acgtb091_gestao_tipo_fornecedor(co_tipo_fornecedor, no_tipo_fornecedor, de_tipo_fornecedor, dt_criacao) VALUES(2,'DESPACHANTE','DESPACHANTE', now());
  INSERT INTO acgsm001.acgtb091_gestao_tipo_fornecedor(co_tipo_fornecedor, no_tipo_fornecedor, de_tipo_fornecedor, dt_criacao) VALUES(3,'ENGENHARIA','ENGENHARIA', now());
  INSERT INTO acgsm001.acgtb091_gestao_tipo_fornecedor(co_tipo_fornecedor, no_tipo_fornecedor, de_tipo_fornecedor, dt_criacao) VALUES(4,'JORNAL','JORNAL', now());
  INSERT INTO acgsm001.acgtb091_gestao_tipo_fornecedor(co_tipo_fornecedor, no_tipo_fornecedor, de_tipo_fornecedor, dt_criacao) VALUES(5,'JUSTICA FEDERAL','JUSTICA FEDERAL', now());
  INSERT INTO acgsm001.acgtb091_gestao_tipo_fornecedor(co_tipo_fornecedor, no_tipo_fornecedor, de_tipo_fornecedor, dt_criacao) VALUES(6,'OUTROS','OUTROS', now());
  INSERT INTO acgsm001.acgtb091_gestao_tipo_fornecedor(co_tipo_fornecedor, no_tipo_fornecedor, de_tipo_fornecedor, dt_criacao) VALUES(7,'PREFEITURA/UNIAO','PREFEITURA/UNIAO', now());
  INSERT INTO acgsm001.acgtb091_gestao_tipo_fornecedor(co_tipo_fornecedor, no_tipo_fornecedor, de_tipo_fornecedor, dt_criacao) VALUES(8,'SENHORIO','SENHORIO', now());
 