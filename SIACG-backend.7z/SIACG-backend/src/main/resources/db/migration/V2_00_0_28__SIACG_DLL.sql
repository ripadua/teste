ALTER TABLE acgsm001.acgtb081_imoveis
  ADD COLUMN nu_gestao_serventia integer;
ALTER TABLE acgsm001.acgtb081_imoveis
  ADD FOREIGN KEY (nu_gestao_serventia) REFERENCES acgsm001.acgtb089_gestao_serventia (nu_gestao_serventia) ON UPDATE NO ACTION ON DELETE NO ACTION;  