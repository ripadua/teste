/*==============================================================*/
/* Table: acgtb084_valor_indice_financeiro                       */
/*==============================================================*/

-- Sequence: acgsm001.sq084_valor_indice_financeiro

CREATE SEQUENCE acgsm001.sq084_valor_indice_financeiro
  INCREMENT 1
  MINVALUE 1
  MAXVALUE 9223372036854775807
  START 1
  CACHE 1;
  
create table acgsm001.acgtb084_valor_indice_financeiro (
   nu_valor_indice      bigint               not null default nextval('acgsm001.sq084_valor_indice_financeiro'::regclass),
   nu_indicador_financeiro bigint            not null,
   vr_indice            NUMERIC(5,3)         not null,
   dt_vigencia_inicial  timestamp without time zone  not null,
   dt_vigencia_final    timestamp without time zone  not null,
   dt_alteracao_indicador DATE               not null,
   ic_ativo             boolean              DEFAULT true,
   constraint PK_ACGTB084_VALOR_INDICE_FINANCEIRO primary key (nu_valor_indice)
);

comment on column acgsm001.acgtb084_valor_indice_financeiro.nu_valor_indice is
'Identificador do valor de indice (PK)';

comment on column acgsm001.acgtb084_valor_indice_financeiro.nu_indicador_financeiro is
'Identificador da tabela indicador financeiro. (FK)';

comment on column acgsm001.acgtb084_valor_indice_financeiro.vr_indice is
'Percentual do Indice vindo do serviço SIBDO.';

comment on column acgsm001.acgtb084_valor_indice_financeiro.dt_vigencia_inicial is
'Data vigência Inicial vindo do serviço SIBDO.';

comment on column acgsm001.acgtb084_valor_indice_financeiro.dt_vigencia_final is
'Data vigência Final vindo do serviço SIBDO.';

alter table acgsm001.acgtb084_valor_indice_financeiro
   add constraint FK_ACGTB084_ACGTB083 foreign key (nu_indicador_financeiro)
      references acgsm001.acgtb083_indicador_financeiro (nu_indicador_financeiro)
      on delete restrict on update restrict;

