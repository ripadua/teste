ALTER TABLE acgsm001.acgtb075_veiculo 
ADD COLUMN co_retorno_gravame character varying(3),
ADD COLUMN de_retorno_gravame text,
ADD COLUMN dt_transacao_gravame date;

COMMENT ON COLUMN acgsm001.acgtb075_veiculo.co_retorno_gravame IS 'Código da situação do gravame na CETIP';
COMMENT ON COLUMN acgsm001.acgtb075_veiculo.de_retorno_gravame IS 'Descrição da transação do Gravame na CETIP';
COMMENT ON COLUMN acgsm001.acgtb075_veiculo.dt_transacao_gravame IS 'Data da transação do Gravame na CETIP';

create index ix_acgtb053_04 on acgsm001.acgtb053_recebido (ic_situacao_conciliacao);