-- Index: acgsm001.ix_acgtb080_01
CREATE INDEX ix_acgtb080_01
  ON acgsm001.acgtb080_garantia_imovel
  USING btree
  (nu_garantia_contrato);
  
  

-- Index: acgsm001.ix_acgtb080_02
CREATE INDEX ix_acgtb080_02
  ON acgsm001.acgtb080_garantia_imovel
  USING btree
  (nu_imovel);

  
-- Index: acgsm001.ix_acgtb081_01
	CREATE INDEX ix_acgtb081_01
	  ON acgsm001.acgtb081_imovel
	  USING btree
	  (nu_pessoa);
	  
	
	
	-- Index: acgsm001.ix_acgtb081_02
	CREATE INDEX ix_acgtb081_02
	  ON acgsm001.acgtb081_imovel
	  USING btree
	  (nu_gestao_serventia);
	  
	
	
	-- Index: acgsm001.ix_acgtb001_08
	CREATE INDEX ix_acgtb001_08
	  ON acgsm001.acgtb001_contrato
	  USING btree
	  (ic_parametrizado, dt_ultma_parametrizacao_manual, ic_situacao COLLATE pg_catalog."default", ic_categoria COLLATE pg_catalog."default");
	
  
	-- Index: acgsm001.ix_acgtb001_09
	CREATE INDEX ix_acgtb001_09
	  ON acgsm001.acgtb001_contrato
	  USING btree
	  (ic_situacao COLLATE pg_catalog."default", ic_categoria COLLATE pg_catalog."default", nu_operacao, nu_contrato);
	  
	  
	
	
	-- Index: acgsm001.ix_acgtb001_10
	CREATE INDEX ix_acgtb001_10
	  ON acgsm001.acgtb001_contrato
	  USING btree
	  (ic_situacao COLLATE pg_catalog."default", co_identificador_contrato COLLATE pg_catalog."default", nu_contrato);
	  
	    
	
	
	-- Index: acgsm001.ix_acgtb001_11
	CREATE INDEX ix_acgtb001_11
	  ON acgsm001.acgtb001_contrato
	  USING btree
	  (ic_garantia_compartilhada, ic_parametrizado, ic_situacao COLLATE pg_catalog."default", nu_pessoa);
	  
	  
	-- Index: acgsm001.ix_acgtb007_08
	CREATE INDEX ix_acgtb007_08
	  ON acgsm001.acgtb007_conta_contrato
	  USING btree
	  (nu_contrato, nu_conta COLLATE pg_catalog."default", nu_agencia COLLATE pg_catalog."default", nu_operacao COLLATE pg_catalog."default", nu_dv_conta COLLATE pg_catalog."default");
	  
  
	-- Index: acgsm001.ix_acgtb087_01  
	CREATE INDEX ix_acgtb087_01
	  ON acgsm001.acgtb087_contrato_imovel
	  USING btree
	  (nu_contrato);
	  
	  
	  
	-- Index: acgsm001.ix_acgtb087_02  
	CREATE INDEX ix_acgtb087_02
	  ON acgsm001.acgtb087_contrato_imovel
	  USING btree
	  (nu_imovel);
	  
	  
	
	-- Index: acgsm001.ix_acgtb071_01
	  CREATE INDEX ix_acgtb071_01
	  ON acgsm001.acgtb071_saldo_cartao_bandeira
	  USING btree
	  (nu_saldo);
	  
	  --
  --DROP INDEX acgsm001.ix_acgtb080_01;
  --DROP INDEX acgsm001.ix_acgtb080_02;
  --DROP INDEX acgsm001.ix_acgtb081_01;
  --DROP INDEX acgsm001.ix_acgtb081_02;
  --DROP INDEX acgsm001.ix_acgtb001_08;
  --DROP INDEX acgsm001.ix_acgtb001_09;
  --DROP INDEX acgsm001.ix_acgtb001_10;
  --DROP INDEX acgsm001.ix_acgtb001_11;
  --DROP INDEX acgsm001.ix_acgtb007_08;
  --DROP INDEX acgsm001.ix_acgtb087_01;
  	--DROP INDEX acgsm001.ix_acgtb087_02;
	--DROP INDEX acgsm001.ix_acgtb071_01;