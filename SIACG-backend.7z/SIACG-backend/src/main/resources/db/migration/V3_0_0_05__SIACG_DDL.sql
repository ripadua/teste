/*==============================================================*/
/*V3_0_0_05__SIACG_DDL.sql                                      */
/*==============================================================*/

/*==============================================================*/
/* Table: acgtb081_imovel                                       */
/*==============================================================*/
-- Descomentar o script e executar em produção, somente após a migração dos dados em produção. 
--ALTER TABLE ACG.acgtb081_imovel DROP COLUMN nu_pessoa;