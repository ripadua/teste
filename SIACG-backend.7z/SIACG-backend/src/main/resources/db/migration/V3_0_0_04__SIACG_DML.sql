/*==============================================================*/
/* V3_0_0_04__SIACG_DML.sql                                     */
/*==============================================================*/

/*==============================================================*/
/* Insert acgtb112_papel_proprietario                           */
/*==============================================================*/
--INSERT CONFORME VALORES INFORMADOS PELO SIOPI - ANEXO EM ALM-191712 
INSERT INTO ACG.acgtb112_papel_proprietario(nu_papel_proprietario, de_papel_proprietario, nu_grupo_papel_proprietario)
       select 1,	'Proponente/Comprador',	1 from dual union
	   select 2,	'Vendedor (a)',	2 from dual union
	   select 3,	'Agente Promotor',	3 from dual union
	   select 4,	'Anuente',	3 from dual union
	   select 5,	'Avalista',	1 from dual union
	   select 6,	'Cessionário do Crédito',	3 from dual union
	   select 7,	'Companhia Securitizadora', null from dual union
	   select 8,	'Companhia Seguradora',	null from dual union
	   select 9,	'Administradora de Consórcio',	3 from dual union
	   select 10,	'Cônjuge do Comprador',	1 from dual union
	   select 11,	'Construtor (a)',	3 from dual union
	   select 12,	'Representante Legal',	null from dual union
	   select 13,	'Cooperativa Habitacional',	3 from dual union
	   select 14,	'Credor (a)',	3 from dual union
	   select 15,	'Custodiante',	3 from dual union
	   select 16,	'Dador em Garantia',	1 from dual union
	   select 17,	'Doador (a)',	4 from dual union
	   select 18,	'Emissor da CCI',	null from dual union
	   select 19,	'Empreiteiro',	3 from dual union
	   select 20,	'Endossatário',	1 from dual union
	   select 21,	'Entidade Organizadora',	3 from dual union
	   select 22,	'Fiador',	1 from dual union
	   select 23,	'Interveniente Anuente',	3 from dual union
	   select 24,	'Interveniente Quitante',	3 from dual union
	   select 25,	'Poder Público/Estados',	4 from dual union
	   select 26,	'Procurador',	null from dual union
	   select 27,	'Responsável Técnico',	null from dual union
	   select 28,	'Agente não Integrante do SFH',	null from dual union
	   select 29,	'Coobrigado/Proponente',	1 from dual union
	   select 30,	'Arrendatário',	1 from dual union
	   select 31,	'Garantidor',	3 from dual union
	   select 32,	'Fundo Garantidor',	3 from dual union
	   select 33,	'Membros da Comissão de Representantes',	3 from dual union
	   select 36,	'Sociedade de Propósitos Específicos select SPE)', 	3 from dual union
	   select 37,	'Devedor Anuente',	1 from dual union
	   select 38,	'Fiduciante',	1 from dual union
	   select 39,	'Incorporador',	3 from dual union
	   select 40,	'Sócio',	null from dual union
	   select 41,	'Anterior Proprietário',	null from dual union
	   select 42,	'Tutor/Curador', 	null from dual union
	   select 43,	'Dependente',	1 from dual union
	   select 44,	'Titular da Caução',	null from dual;
	   
/*==============================================================*/
/* Insert acgtb113_proprietario_imovel                           */
/*==============================================================*/	   
INSERT INTO ACG.acgtb113_proprietario_imovel(nu_imovel, nu_pessoa)
SELECT DISTINCT i.nu_imovel, i.nu_pessoa
FROM ACG.acgtb081_imovel i 
WHERE i.nu_pessoa is not null
ORDER BY i.nu_imovel asc;
