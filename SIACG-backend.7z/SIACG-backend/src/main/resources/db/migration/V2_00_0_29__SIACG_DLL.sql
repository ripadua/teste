ALTER TABLE acgsm001.acgtb001_contrato
  DROP COLUMN dt_atualizacao;