/*================================================================================================*/
                                    -- V2_00_0_06__SIACG_DLL.sql
/*================================================================================================*/
CREATE SEQUENCE acgsm001.sq054_acao_preventiva_nrodoc
  INCREMENT 1
  MINVALUE 1
  MAXVALUE 999999
  START 1
  CACHE 1;


ALTER TABLE acgsm001.acgtb054_acao_preventiva 
ADD column co_nrodoc_bloqueio integer NOT NULL DEFAULT nextval('acgsm001.sq054_acao_preventiva_nrodoc'::regclass),
ADD column co_nrodoc_desbloqueio integer NOT NULL DEFAULT nextval('acgsm001.sq054_acao_preventiva_nrodoc'::regclass);