/*============================================================*/
/*           SCRIPT V2_10_0_03__SIACG_DDL		              */
/*============================================================*/

ALTER TABLE acgsm001.acgtb009_garantia_contrato ADD COLUMN dt_parametrizacao_manual DATE ;

COMMENT ON COLUMN acgsm001.acgtb009_garantia_contrato.dt_parametrizacao_manual IS 'Indica a data em que a garantia foi parametrizada pela primeira vez, essa data não é alterada.';


/*==============================================================*/
/* REVERT                                                       */
/*==============================================================*/ 

-- ALTER TABLE acgsm001.acgtb009_garantia_contrato DROP COLUMN dt_parametrizacao_manual;
