INSERT INTO acgsm001.acgtb017_propriedade(
            no_propriedade, no_valor_propriedade, no_grupo, de_comentario)
    VALUES ('numero_canal_siacg', '3200', 'consulta', 'Código do sistema SIACG para consultar saldos de aplicações de Renda Fixa');