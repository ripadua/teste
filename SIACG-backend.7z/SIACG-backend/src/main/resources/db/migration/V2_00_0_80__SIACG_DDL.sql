/*==============================================================*/
/*           SCRIPT V2_00_0_80__SIACG_DLL						*/
/*==============================================================*/

CREATE TABLE acgsm001.acgtb103_documento_lancamento_evento
(
  nu_documento_lancamento_evento integer NOT NULL,
  nu_analitico_codigo character varying(5),
  nu_analitico_codigo_dv integer,
  de_aviso character varying(255),
  nu_centro_custo character varying(5),
  nu_centro_custo_dv integer,
  cl integer,
  cldv integer,
  nu_cnpj character varying(14),
  co_tipo_despesa character varying(6),
  nu_cpfcnpj_favorecido character varying(14),
  dt_efetiva date,
  dt_movimento date NOT NULL,
  dt_transferencia date,
  dt_valorizacao date,
  de_empenho character varying(100),
  nu_dv_tipo_despesa integer,
  de_historico character varying(255),
  ic_aviso_credito boolean,
  ic_indicador_registro integer,
  nu_banco character varying(100),
  no_evento character varying(50),
  nu_agencia character varying(6),
  nu_conciliacao character varying(14),
  nu_conta character varying(10),
  nu_conta_dv integer,
  nu_documento integer,
  nu_matricula_imovel bigint,
  operacao character varying(255),
  nu_codigo_produto character varying(5),
  nu_produto_dv integer,
  de_projeto character varying(255),
  nu_quantidade integer,
  no_remetente character varying(255),
  nu_seg_carteira integer,
  ic_situacao_lancamento integer,
  nu_telefone character varying(20),
  ic_tipo_emissao integer,
  ic_tipo_analitico integer,
  no_titular_conta character varying(100),
  no_titular_imovel character varying(100) NOT NULL,
  nu_unidade_destino character varying(5),
  nu_unidade_destino_dv integer,
  nu_unidade_movimento character varying(5),
  nu_unidade_movimento_dv integer,
  vr_despesa numeric(16,2),
  CONSTRAINT acgtb103_documento_lancamento_evento_pkey PRIMARY KEY (nu_documento_lancamento_evento),
  CONSTRAINT ck_acgtb103_01 CHECK (ic_indicador_registro = ANY (ARRAY[0,4,5])),
  CONSTRAINT ck_acgtb103_02 CHECK (ic_situacao_lancamento = ANY (ARRAY[0,1,2])),
  CONSTRAINT ck_acgtb103_03 CHECK (ic_tipo_analitico = ANY (ARRAY[0,1,2,3,4]))
);
COMMENT ON COLUMN acgsm001.acgtb103_documento_lancamento_evento.nu_documento_lancamento_evento IS 'Identifica o número de emissão da DLE';
COMMENT ON COLUMN acgsm001.acgtb103_documento_lancamento_evento.nu_analitico_codigo IS 'Identifica o número de código analítico';
COMMENT ON COLUMN acgsm001.acgtb103_documento_lancamento_evento.nu_analitico_codigo_dv IS 'Identifica o DV do código analítico';
COMMENT ON COLUMN acgsm001.acgtb103_documento_lancamento_evento.de_aviso IS 'Descrição do aviso';
COMMENT ON COLUMN acgsm001.acgtb103_documento_lancamento_evento.nu_centro_custo IS 'Número do centro de custo';
COMMENT ON COLUMN acgsm001.acgtb103_documento_lancamento_evento.nu_centro_custo_dv IS 'Número do DV do centro de custo';
COMMENT ON COLUMN acgsm001.acgtb103_documento_lancamento_evento.cl IS 'Número do cl';
COMMENT ON COLUMN acgsm001.acgtb103_documento_lancamento_evento.cldv IS 'Número do DV do cl';
COMMENT ON COLUMN acgsm001.acgtb103_documento_lancamento_evento.nu_cnpj IS 'Identifica o CNPJ';
COMMENT ON COLUMN acgsm001.acgtb103_documento_lancamento_evento.nu_cpfcnpj_favorecido IS 'Identifica o CPF/CNPJ do favorecido';

COMMENT ON COLUMN acgsm001.acgtb103_documento_lancamento_evento.vr_despesa IS 'Valor do lançado na despesa';
COMMENT ON COLUMN acgsm001.acgtb103_documento_lancamento_evento.vr_despesa IS 'Valor do lançado na despesa';
COMMENT ON COLUMN acgsm001.acgtb103_documento_lancamento_evento.ic_indicador_registro IS 'Identifica o tipo de indicador de registro:
0 - Não definido
4 - Recebimento/Crédito
5 - Pagamento/Débito
';
COMMENT ON COLUMN acgsm001.acgtb103_documento_lancamento_evento.ic_situacao_lancamento IS 'Identifica a situação do lançamento:
0 - Não definido
1 - Normal
2 - Estorno
';
COMMENT ON COLUMN acgsm001.acgtb103_documento_lancamento_evento.ic_tipo_analitico IS 'Identifica o tipo analítico:
0 - Não definido
1 - Sequencial
2 - CPF
3 - CNPJ
4 - DPJ
';
/*==============================================================*/
/*  Reverse   SCRIPT V2_00_0_80__SIACG_DLL						*/
/*==============================================================*/

-- DROP TABLE acgsm001.acgtb103_documento_lancamento_evento;