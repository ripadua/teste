/*==============================================================*/
/*           SCRIPT V2_00_0_87__SIACG_DLL						*/
/*==============================================================*/

ALTER TABLE acgsm001.acgtb077_maquina_equipamento ADD COLUMN dt_documento_comprobatorio date; 
COMMENT ON COLUMN acgsm001.acgtb077_maquina_equipamento.dt_documento_comprobatorio IS 'Data do documento comprobatorio';

ALTER TABLE acgsm001.acgtb077_maquina_equipamento ADD COLUMN ic_documento_comprobatorio character varying(1); 
COMMENT ON COLUMN acgsm001.acgtb077_maquina_equipamento.ic_documento_comprobatorio IS 'Tipos de documento comprobatorio N - Nota fiscal - L -Laudo de avaliação';


      
/*########################### SCRIPT ROLLBACK ##############################*/
--ALTER TABLE acgsm001.acgtb077_maquina_equipamento DROP COLUMN dt_documento_comprobatorio;
--ALTER TABLE acgsm001.acgtb077_maquina_equipamento DROP COLUMN ic_documento_comprobatorio;
