ALTER TABLE acgsm001.acgtb057_parametro_produto ADD COLUMN no_normativo VARCHAR(7);
comment on column acgsm001.acgtb057_parametro_produto.no_normativo is
'Normativo da parametrização.';
