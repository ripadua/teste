ALTER TABLE acgsm001.acgtb011_garantia ADD COLUMN ic_cedente boolean DEFAULT false;

COMMENT ON COLUMN acgsm001.acgtb011_garantia.ic_cedente IS 'Coluna que identifica se garantia precisa de cedente';