/*==============================================================*/
/* Table: acgtb081_imovel                                       */
/*==============================================================*/
ALTER TABLE acgsm001.acgtb081_imovel RENAME no_logadouro TO no_logradouro;
ALTER TABLE acgsm001.acgtb081_imovel RENAME nu_numero TO nu_logradouro;
comment on column acgsm001.acgtb081_imovel.no_logradouro is 'Nome do logradouro do imóvel.';
comment on column acgsm001.acgtb081_imovel.nu_logradouro is 'Número do endereço do imóvel.'; 
/*==============================================================*/
/* Table: acgtb086_parametro_produto_seg                        */
/*==============================================================*/
ALTER TABLE IF EXISTS acgsm001.acgtb086_parametro_produto_seg RENAME TO acgtb086_segmento_produto;