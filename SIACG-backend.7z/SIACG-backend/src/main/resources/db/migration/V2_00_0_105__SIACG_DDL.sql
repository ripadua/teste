/*==============================================================*/
/*           SCRIPT V2_00_0_105__SIACG_DLL						*/
/*==============================================================*/

/*============================================================================*/
/* #165001 - Tela do Manual do Usuário não exibida                            */
/*============================================================================*/

-- ATENÇÃO!!! ESTE SCRIPT NÃO PRECISARÁ SER EXECUTADO EM PRODUÇÃO, POIS OS VALORES JÁ ESTÃO CORRETOS.
-- ESTE SCRIPT ESTÁ SENDO GERADO APENAS PARA CORREÇÃO EM DES, TST, TQS (HMP) e HMP. 

update acgsm001.acgtb017_propriedade set no_valor_propriedade = 'ftp://ftp.go.caixa/Gisutgo/PEDES/SIACG/' where no_propriedade = 'caminho.ftp';
update acgsm001.acgtb017_propriedade set no_valor_propriedade = 'SIACG_Manual_Usuario.pdf' where no_propriedade = 'manual.usuario';

/*========================================*/
/* Script de reversão					  */
/*========================================*/
--update acgsm001.acgtb017_propriedade set no_valor_propriedade = 'http://www.geopc.mz.caixa/fonte/backoffice/pdf/' where no_propriedade = 'caminho.ftp';
--update acgsm001.acgtb017_propriedade set no_valor_propriedade = 'Cartilha_Painel_de_Garantias.pdf' where no_propriedade = 'manual.usuario';