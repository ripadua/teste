ALTER SEQUENCE acgsm001.sq003_empresa RENAME TO sq003_pessoa;
