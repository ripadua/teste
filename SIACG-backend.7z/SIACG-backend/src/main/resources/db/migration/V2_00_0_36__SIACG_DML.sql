/*==============================================================*/
/* SCRIPT V2_00_0_36__SIACG_DML									*/
/*==============================================================*/


-- **********************************************************  
-- ==> Scripts para eliminação de dados duplicados
-- (Pessoa e conta NLM)
-- **********************************************************
DO $$

BEGIN

-- **********************************************************  
--1) ==> Script de ajuste de dados  - Pessoas duplicadas
-- **********************************************************

-- Cria tabela temporária com valores para correção
CREATE TABLE acgsm001.pessoa_tmp AS 
 SELECT 
  p1.nu_pessoa AS nu_pessoa_duplicada, 
  p2.nu_pessoa AS nu_pessoa_certa, 
  p2.nu_identificador_pessoa
 FROM 
  acgsm001.acgtb003_pessoa p1, 
  (SELECT MIN(nu_pessoa) nu_pessoa, nu_identificador_pessoa 
   FROM acgsm001.acgtb003_pessoa
   WHERE nu_identificador_pessoa IN (

      SELECT nu_identificador_pessoa 
      FROM acgsm001.acgtb003_pessoa
      GROUP BY nu_identificador_pessoa
      HAVING COUNT(nu_identificador_pessoa) > 1
   )
   GROUP BY nu_identificador_pessoa
  ) AS p2
 WHERE p1.nu_identificador_pessoa = p2.nu_identificador_pessoa
 AND p1.nu_pessoa <> p2.nu_pessoa;

-------------------


-- Ajusta pessoa em contrato
UPDATE acgsm001.acgtb001_contrato c
   SET nu_pessoa = p.nu_pessoa_certa
FROM (SELECT * FROM acgsm001.pessoa_tmp) AS p
WHERE c.nu_pessoa = p.nu_pessoa_duplicada;

-- Ajusta pessoa em cedente
UPDATE acgsm001.acgtb004_cedente c
   SET nu_pessoa = p.nu_pessoa_certa
FROM (SELECT * FROM acgsm001.pessoa_tmp) AS p
WHERE c.nu_pessoa = p.nu_pessoa_duplicada;

-- Ajusta pessoa em conta_corrente
UPDATE acgsm001.acgtb006_conta_corrente c
   SET nu_pessoa = p.nu_pessoa_certa
FROM (SELECT * FROM acgsm001.pessoa_tmp) AS p
WHERE c.nu_pessoa = p.nu_pessoa_duplicada;

-- Ajusta pessoa em solicitacao_preanalise
UPDATE acgsm001.acgtb010_solicitacao_preanalise c
   SET nu_pessoa = p.nu_pessoa_certa
FROM (SELECT * FROM acgsm001.pessoa_tmp) AS p
WHERE c.nu_pessoa = p.nu_pessoa_duplicada;


-- Ajusta pessoa em custodia_cheque
UPDATE acgsm001.acgtb027_custodia_cheque c
   SET nu_pessoa = p.nu_pessoa_certa
FROM (SELECT * FROM acgsm001.pessoa_tmp) AS p
WHERE c.nu_pessoa = p.nu_pessoa_duplicada;


-- Ajusta pessoa em acompanhamento_endvto
UPDATE acgsm001.acgtb039_acompanhamento_endvto c
   SET nu_pessoa = p.nu_pessoa_certa
FROM (SELECT * FROM acgsm001.pessoa_tmp) AS p
WHERE c.nu_pessoa = p.nu_pessoa_duplicada;

-- Ajusta pessoa em saldo_cartao_bandeira
DELETE FROM acgsm001.acgtb071_saldo_cartao_bandeira c
WHERE c.nu_saldo in (SELECT nu_pessoa_duplicada FROM acgsm001.pessoa_tmp);

-- Ajusta pessoa em saldo
DELETE FROM acgsm001.acgtb042_saldo c
WHERE c.nu_saldo in (SELECT nu_pessoa_duplicada FROM acgsm001.pessoa_tmp);

-- Ajusta pessoa em historico_ftrmo_empsa
UPDATE acgsm001.acgtb046_historico_ftrmo_empsa c
   SET nu_pessoa = p.nu_pessoa_certa
FROM (SELECT * FROM acgsm001.pessoa_tmp) AS p
WHERE c.nu_pessoa = p.nu_pessoa_duplicada;


-- Deleta pessoas duplicadas
DELETE FROM acgsm001.acgtb003_pessoa
WHERE nu_pessoa IN (SELECT nu_pessoa_duplicada FROM acgsm001.pessoa_tmp);

--------------------------
-- ações pós
--------------------------
DROP TABLE acgsm001.pessoa_tmp;




--*********************************************************************
---2) ==> Script de ajuste de dados  - Contas NLM duplicadas
--*********************************************************************

-- Busca dados a serem eliminados
CREATE TABLE acgsm001.conta_tmp AS
  SELECT 
  cc.nu_conta_contrato as nu_conta_contrato_duplicado,
  tb.nu_conta_contrato as nu_conta_contrato_certo,
  tb.co_identificador_contrato
FROM 
(SELECT nu_conta_contrato, co_identificador_contrato 
 FROM acgsm001.acgtb001_contrato c, acgsm001.acgtb007_conta_contrato cc
 WHERE c.nu_contrato = cc.nu_contrato
) cc,
(
SELECT MIN(nu_conta_contrato) nu_conta_contrato,
   cc.nu_contrato, 
   cc.nu_conta, 
   cc.ic_conta, 
   cc.nu_agencia, 
   cc.nu_dv_conta, 
   cc.ic_origem, 
   cc.nu_operacao, 
   cc.ic_utilizar_saldo, 
   cc.ic_utilizar_saldo_cheque,
   c.co_identificador_contrato 
FROM acgsm001.acgtb001_contrato c, acgsm001.acgtb007_conta_contrato cc
WHERE c.nu_contrato = cc.nu_contrato
AND co_identificador_contrato = '19100717000002150'
AND (cc.nu_contrato, 
  cc.nu_conta, 
  cc.ic_conta, 
  cc.nu_agencia, 
  cc.nu_dv_conta, 
  cc.ic_origem, 
  cc.nu_operacao, 
  cc.ic_utilizar_saldo, 
  cc.ic_utilizar_saldo_cheque,
  c.co_identificador_contrato) IN (
SELECT 
  cc.nu_contrato, 
  cc.nu_conta, 
  cc.ic_conta, 
  cc.nu_agencia, 
  cc.nu_dv_conta, 
  cc.ic_origem, 
  cc.nu_operacao, 
  cc.ic_utilizar_saldo, 
  cc.ic_utilizar_saldo_cheque,
  c.co_identificador_contrato 
FROM acgsm001.acgtb001_contrato c, acgsm001.acgtb007_conta_contrato cc
WHERE c.nu_contrato = cc.nu_contrato
AND co_identificador_contrato = '19100717000002150'
GROUP BY 1,2,3,4,5,6,7,8,9,10
HAVING count(*) > 1
) 
GROUP BY cc.nu_contrato, 
   cc.nu_conta, 
   cc.ic_conta, 
   cc.nu_agencia, 
   cc.nu_dv_conta, 
   cc.ic_origem, 
   cc.nu_operacao, 
   cc.ic_utilizar_saldo, 
   cc.ic_utilizar_saldo_cheque,
   c.co_identificador_contrato 
) AS tb
WHERE cc.co_identificador_contrato = tb.co_identificador_contrato
AND cc.nu_conta_contrato <> tb.nu_conta_contrato;


-- Remove duplicados
DELETE FROM acgsm001.acgtb007_conta_contrato cc
WHERE nu_conta_contrato IN(SELECT nu_conta_contrato_duplicado 
FROM acgsm001.conta_tmp tmp);

--------------------------
-- ações pós
--------------------------

DROP TABLE acgsm001.conta_tmp;



  RAISE NOTICE 'Script executado com sucesso';
EXCEPTION WHEN OTHERS THEN

  RAISE NOTICE 'Falha!! Script não foi aplicado!';

END; $$