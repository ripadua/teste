/*==============================================================*/
/*           SCRIPT V2_00_0_74__SIACG_DLL						*/
/*==============================================================*/

ALTER TABLE acgsm001.acgtb094_gestao_tipo_despesa ADD COLUMN nu_dv_tipo_despesa character varying(1);
COMMENT ON COLUMN acgsm001.acgtb094_gestao_tipo_despesa.nu_dv_tipo_despesa IS 'Número do dígito verificador do tipo despesa';

ALTER TABLE acgsm001.acgtb094_gestao_tipo_despesa ALTER COLUMN co_tipo_despesa TYPE character varying(6);
      
/*########################### SCRIPT ROLLBACK ##############################*/
--ALTER TABLE acgsm001.acgtb094_gestao_tipo_despesa DROP COLUMN nu_dv_tipo_despesa;