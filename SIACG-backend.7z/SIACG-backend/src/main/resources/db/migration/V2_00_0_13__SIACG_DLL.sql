ALTER TABLE acgsm001.acgtb081_imoveis
  ADD COLUMN identificacao_cartorio character varying(50);
  
ALTER TABLE acgsm001.acgtb081_imoveis
  ADD COLUMN nu_registro_garantia character varying(50);
  
ALTER TABLE acgsm001.acgtb081_imoveis
  ADD COLUMN dt_registro_garantia date;
  
ALTER TABLE acgsm001.acgtb081_imoveis
  ADD COLUMN grau_garantia_constituida character varying(50);
  
ALTER TABLE acgsm001.acgtb081_imoveis
  ADD COLUMN tipo_logradouro character varying(50);
  
ALTER TABLE acgsm001.acgtb081_imoveis
  ADD COLUMN uso_imovel character varying(50);
  
ALTER TABLE acgsm001.acgtb081_imoveis
  ADD COLUMN categoria_imovel character varying(50);

ALTER TABLE acgsm001.acgtb081_imoveis
  ADD COLUMN tipo_implantacao character varying(50);

ALTER TABLE acgsm001.acgtb081_imoveis
  ADD COLUMN qtd_dormitorio int4;

ALTER TABLE acgsm001.acgtb081_imoveis
  ADD COLUMN qtd_vagas_garagem int4;

ALTER TABLE acgsm001.acgtb081_imoveis
  ADD COLUMN estado_cnsrvcao_condominio character varying(50);

ALTER TABLE acgsm001.acgtb081_imoveis
  ADD COLUMN area_terreno numeric(16,2);

ALTER TABLE acgsm001.acgtb081_imoveis
  ADD COLUMN testada character varying(50);

ALTER TABLE acgsm001.acgtb081_imoveis
  ADD COLUMN estado_conservacao_imovel character varying(50);

ALTER TABLE acgsm001.acgtb081_imoveis
  ADD COLUMN padrao_acabamento character varying(50);

ALTER TABLE acgsm001.acgtb081_imoveis
  ADD COLUMN dt_avaliacao date;

ALTER TABLE acgsm001.acgtb081_imoveis
  ADD COLUMN vr_avaliacao numeric(16,2);

ALTER TABLE acgsm001.acgtb081_imoveis
  ADD COLUMN dt_compra_venda date;

ALTER TABLE acgsm001.acgtb081_imoveis
  ADD COLUMN vr_compra_cdgo_avlacao_engnharia numeric(16,2);

ALTER TABLE acgsm001.acgtb081_imoveis
  ADD COLUMN classificacao character varying(50);

ALTER TABLE acgsm001.acgtb081_imoveis
  ADD COLUMN indece_reajuste numeric(16,2);

ALTER TABLE acgsm001.acgtb081_imoveis
  ADD COLUMN vr_imovel_dt_contratacao numeric(16,2);

ALTER TABLE acgsm001.acgtb081_imoveis
  ADD COLUMN vr_atualizado_imovel numeric(16,2);

ALTER TABLE acgsm001.acgtb081_imoveis
  ADD COLUMN forma_garantia_vr_contrato character varying(50);

ALTER TABLE acgsm001.acgtb081_imoveis
  ADD COLUMN dados_fiduciante character varying(50);

ALTER TABLE acgsm001.acgtb081_imoveis
  ADD COLUMN tipo_pessoa character varying(50);

ALTER TABLE acgsm001.acgtb081_imoveis
  ADD COLUMN cpf_cnpj character varying(50);

ALTER TABLE acgsm001.acgtb081_imoveis
  ADD COLUMN nome_razacao_social character varying(50);

ALTER TABLE acgsm001.acgtb081_imoveis
  ADD COLUMN devedor_informado_scr character varying(50);
