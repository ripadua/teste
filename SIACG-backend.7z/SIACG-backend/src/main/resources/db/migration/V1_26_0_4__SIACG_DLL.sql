/*==============================================================*/
/* Table: acgtb068_garantia_produto                             */
/*==============================================================*/
create table acgsm001.acgtb068_garantia_produto (
   nu_garantia          	integer                 not null,
   nu_produto       		integer                 not null,
   nu_modalidade        	integer                 not null,
   ic_garantia_obrigatoria	boolean 				DEFAULT false,
   CONSTRAINT PK_ACGTB068_GARANTIA_PRODUTO primary key (nu_garantia, nu_produto, nu_modalidade),
   CONSTRAINT fk_acgtb068_reference_acgtb011 FOREIGN KEY (nu_garantia)
      REFERENCES acgsm001.acgtb011_garantia (nu_garantia) MATCH SIMPLE
      ON UPDATE RESTRICT ON DELETE RESTRICT
);
COMMENT ON TABLE acgsm001.acgtb068_garantia_produto is 'Tabela de vinculação entre as garantias Bacen e o produto de crédito.';
COMMENT ON COLUMN acgsm001.acgtb068_garantia_produto.nu_garantia IS 'Número de identificação da garantia.';
COMMENT ON COLUMN acgsm001.acgtb068_garantia_produto.nu_produto IS 'Número de identificação do produto.';
COMMENT ON COLUMN acgsm001.acgtb068_garantia_produto.nu_modalidade IS 'Número da modalidade de contratação do produto.';
