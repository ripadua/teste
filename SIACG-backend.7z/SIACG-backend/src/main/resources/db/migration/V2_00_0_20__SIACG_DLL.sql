ALTER TABLE acgsm001.acgtb012_analise_contrato ADD COLUMN vr_nao_utilizado numeric(16,2);
comment on column acgsm001.acgtb012_analise_contrato.vr_nao_utilizado is
'Armazena o Valor Não Utilizado, e é utilizado caso o valor apurado seja superior ao esperado.';