ALTER TABLE acgsm001.acgtb001_contrato
  ADD COLUMN dt_atualizacao timestamp without time zone;
  
ALTER TABLE acgsm001.acgtb001_contrato DROP CONSTRAINT ckc_ic_situacao_acgtb001;
ALTER TABLE acgsm001.acgtb001_contrato ADD CONSTRAINT ckc_ic_situacao_acgtb001 CHECK (ic_situacao = ANY (ARRAY['01'::bpchar, '02'::bpchar, '03'::bpchar, '04'::bpchar, '05'::bpchar, '06'::bpchar]));

COMMENT ON COLUMN acgsm001.acgtb001_contrato.ic_situacao IS 'Identifica a situação do contrato:
01 - Aberto
02 - Atrasado
03 - Fechado
04 - Cancelado
05 - Pré-Análise
06 - Crédito em Atraso';