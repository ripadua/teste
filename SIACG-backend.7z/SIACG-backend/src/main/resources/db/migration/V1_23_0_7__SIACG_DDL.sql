DROP TABLE "acgsm001"."acgtb064_tipo_parcela" CASCADE;

ALTER TABLE "acgsm001"."acgtb065_tipo_parcela" RENAME TO "acgtb064_tipo_parcela";

ALTER TABLE "acgsm001"."acgtb052_prmto_comercializacao" DROP CONSTRAINT "fk_acgtb052_acgtb065";

COMMENT ON TABLE "acgsm001"."acgtb055_log_bloqueio" IS 'Armazena registros de log referentes ao serviço que recebe solicitações de consulta a saldos de aplicações/contas de uma pessoa.';

ALTER TABLE "acgsm001"."acgtb055_log_bloqueio" ADD COLUMN "nu_log_servico_saldo" int4 NOT NULL;

COMMENT ON COLUMN "acgsm001"."acgtb055_log_bloqueio"."nu_log_servico_saldo" IS 'Número identificador do registro de log.';

ALTER TABLE "acgsm001"."acgtb055_log_bloqueio" ADD COLUMN "ts_solicitacao" timestamp(6) NOT NULL;

COMMENT ON COLUMN "acgsm001"."acgtb055_log_bloqueio"."ts_solicitacao" IS 'Data e hora em que o serviço recebeu a solicitação de consulta a saldos de aplicações/contas.';

ALTER TABLE "acgsm001"."acgtb055_log_bloqueio" ADD COLUMN "no_sistema_solicitante" varchar(5) COLLATE "pg_catalog"."default";

COMMENT ON COLUMN "acgsm001"."acgtb055_log_bloqueio"."no_sistema_solicitante" IS 'Nome do sistema que enviou a solicitação de consulta a saldos de aplicações/contas.';

ALTER TABLE "acgsm001"."acgtb055_log_bloqueio" ADD COLUMN "co_identificador_pessoa" varchar(14) COLLATE "pg_catalog"."default";

COMMENT ON COLUMN "acgsm001"."acgtb055_log_bloqueio"."co_identificador_pessoa" IS 'Código identificador da pessoa (cpf/cnpj) cujos saldos de aplicações/contas foram consultados.';

ALTER TABLE "acgsm001"."acgtb055_log_bloqueio" ADD COLUMN "de_solicitacao" text COLLATE "pg_catalog"."default" NOT NULL;

COMMENT ON COLUMN "acgsm001"."acgtb055_log_bloqueio"."de_solicitacao" IS 'Descrição da solicitação recebida pelo serviço.';

ALTER TABLE "acgsm001"."acgtb055_log_bloqueio" ALTER COLUMN "ic_retorno" TYPE char(2) COLLATE "pg_catalog"."default" USING "ic_retorno"::char(2);

COMMENT ON COLUMN "acgsm001"."acgtb055_log_bloqueio"."ic_retorno" IS 'Indica o tipo de retorno realizado pelo serviço ao sistema solicitante, podendo ser:
00 - SUCESSO. Significa que a solicitação de consulta a saldos de aplicações/contas de uma pessoa foi atendida com sucesso.
01 - SINTAXE INVALIDA. Significa que a mensagem de solicitação (de_solicitacao) recebida pelo serviço estava fora do padrão esperado.
02 - PRODUTO/OPERACAO NAO POSSUI GARANTIAS CADASTRADAS. Significa que não existe produto/operação cadastrada ou não existem garantias cadastradas para o produto.
03 - SERVICO CONSULTA CONTAS INDISPONIVEL. Significa que o serviço que consulta as contas de uma pessoa estava indisponível.
04 - SERVICO CONSULTA CONTAS RETORNOU CODIGO DE ERRO. Significa que o serviço que consulta as contas de uma pessoa retornou um código de erro.
05 - SERVICO CONSULTA CONTAS RETORNOU MENSAGEM INESPERADA. Significa que o serviço que consulta as contas de uma pessoa retornou uma mensagem fora do padrão esperado.
06 - CLIENTE NAO POSSUI APLICACOES OU NAO POSSUI APLICACOES VALIDAS.
07 - ERRO INTERNO. Significa que ocorreu um erro interno durante o processamento da solicitação.';

ALTER TABLE "acgsm001"."acgtb055_log_bloqueio" ADD COLUMN "de_retorno" text COLLATE "pg_catalog"."default" NOT NULL;

COMMENT ON COLUMN "acgsm001"."acgtb055_log_bloqueio"."de_retorno" IS 'Descrição do retorno realizado pelo serviço ao sistema solicitante.';

ALTER TABLE "acgsm001"."acgtb055_log_bloqueio" ADD COLUMN "co_matricula" varchar(7) COLLATE "pg_catalog"."default";

COMMENT ON COLUMN "acgsm001"."acgtb055_log_bloqueio"."co_matricula" IS 'Número de matrícula do usuário que está realizando a operação.';

ALTER TABLE "acgsm001"."acgtb055_log_bloqueio" ADD COLUMN "co_garantia" varchar(30) COLLATE "pg_catalog"."default";

COMMENT ON COLUMN "acgsm001"."acgtb055_log_bloqueio"."co_garantia" IS 'Número da aplicação. Exemplo: 0002001000002002 onde:
Agencia: 0002;
Operação: 001;
Conta:00000200;
DV: 2.';

ALTER TABLE "acgsm001"."acgtb055_log_bloqueio" ALTER COLUMN "ic_comando" TYPE int4 USING "ic_comando"::int4;

COMMENT ON COLUMN "acgsm001"."acgtb055_log_bloqueio"."ic_comando" IS 'Comando de ação solicitada. Será:
0 - saldos;
1 - bloqueio;
2 - desbloqueio.';

ALTER TABLE "acgsm001"."acgtb055_log_bloqueio" ADD COLUMN "no_sistema_solicitado" varchar(5) COLLATE "pg_catalog"."default";

COMMENT ON COLUMN "acgsm001"."acgtb055_log_bloqueio"."no_sistema_solicitado" IS 'Nome do sistema ao qual foi enviado a solicitação de consulta a saldos e bloqueio de aplicações/contas.';

ALTER TABLE "acgsm001"."acgtb055_log_bloqueio" ADD COLUMN "vr_opecao" numeric(16,2);

COMMENT ON COLUMN "acgsm001"."acgtb055_log_bloqueio"."vr_opecao" IS 'Valor operação realizada. Exemplo:
Para uma operação de bloqueio, corresponde ao valor bloqueado por aplicação.
Para uma operação de consulta, corresponde ao valor da consulta por aplicação.
Para uma operação de desbloqueio, corresponde ao valor desbloqueado por aplicação.';

ALTER TABLE "acgsm001"."acgtb055_log_bloqueio" DROP COLUMN "nu_log_bloqueio";

ALTER TABLE "acgsm001"."acgtb055_log_bloqueio" DROP COLUMN "nu_bloqueio";

ALTER TABLE "acgsm001"."acgtb055_log_bloqueio" DROP COLUMN "nu_pessoa";

ALTER TABLE "acgsm001"."acgtb055_log_bloqueio" DROP COLUMN "no_tomador";

ALTER TABLE "acgsm001"."acgtb055_log_bloqueio" DROP COLUMN "nu_agencia";

ALTER TABLE "acgsm001"."acgtb055_log_bloqueio" DROP COLUMN "nu_operacao";

ALTER TABLE "acgsm001"."acgtb055_log_bloqueio" DROP COLUMN "nu_contrato";

ALTER TABLE "acgsm001"."acgtb055_log_bloqueio" DROP COLUMN "acg_nu_pessoa";

ALTER TABLE "acgsm001"."acgtb055_log_bloqueio" DROP COLUMN "ic_tipo_relacao";

ALTER TABLE "acgsm001"."acgtb055_log_bloqueio" DROP COLUMN "nu_digito_verificador";

ALTER TABLE "acgsm001"."acgtb055_log_bloqueio" DROP COLUMN "ic_sistema_origem";

ALTER TABLE "acgsm001"."acgtb055_log_bloqueio" DROP COLUMN "vr_contrato";

ALTER TABLE "acgsm001"."acgtb055_log_bloqueio" DROP COLUMN "ic_indicativo_liquidacao";

ALTER TABLE "acgsm001"."acgtb055_log_bloqueio" DROP COLUMN "vr_garantia";

ALTER TABLE "acgsm001"."acgtb055_log_bloqueio" DROP COLUMN "ic_transacao";

ALTER TABLE "acgsm001"."acgtb055_log_bloqueio" DROP COLUMN "qt_dia_vigencia";

ALTER TABLE "acgsm001"."acgtb055_log_bloqueio" DROP COLUMN "no_aplicacao";

ALTER TABLE "acgsm001"."acgtb055_log_bloqueio" DROP COLUMN "ic_bloqueio";

ALTER TABLE "acgsm001"."acgtb055_log_bloqueio" DROP COLUMN "vr_bloqueado";

ALTER TABLE "acgsm001"."acgtb055_log_bloqueio" DROP COLUMN "nu_prioridade_bloqueio";

ALTER TABLE "acgsm001"."acgtb055_log_bloqueio" ADD CONSTRAINT "pk_acgtb055_log_bloqueio" PRIMARY KEY ("nu_log_servico_saldo");

ALTER TABLE "acgsm001"."acgtb055_log_bloqueio" ADD CONSTRAINT "ckc_ic_retorno_acgtb054" CHECK (((ic_retorno)::text = ANY (ARRAY['00'::text, '01'::text, '02'::text, '03'::text, '04'::text, '05'::text, '06'::text, '07'::text])));

ALTER TABLE "acgsm001"."acgtb063_proponente_habitacional" DROP CONSTRAINT "fk_acgtb064_reference_acgtb003";

ALTER TABLE "acgsm001"."acgtb052_prmto_comercializacao" ADD CONSTRAINT "fk_acgtb052_acgtb064" FOREIGN KEY ("nu_tipo_parcela") REFERENCES "acgsm001"."acgtb064_tipo_parcela" ("nu_tipo_parcela") ON DELETE RESTRICT ON UPDATE RESTRICT;

DROP TABLE "acgsm001"."acgtb054_log_servico_saldo";

DROP TABLE "acgsm001"."acgtb057_produto" CASCADE;

DROP TABLE "acgsm001"."acgtb058_modalidade";

DROP TABLE "acgsm001"."acgtb062_sgmno_prdto";

DROP TABLE "acgsm001"."acgtb063_sistema";

DROP TABLE "acgsm001"."acgtbs01_contrato";

DROP TABLE "acgsm001"."acgtbs08_duplicata";
