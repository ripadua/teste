/*==============================================================*/
/* Sequence: acgsq092_fornecedor                                */
/*==============================================================*/


create sequence acgsm001.acgsq092_fornecedor;



/*==============================================================*/
/* Table: acgtb092_fornecedor                                   */
/*==============================================================*/

create table acgsm001.acgtb092_fornecedor (

   nu_fornecedor        INT                  not null default nextval('acgsm001.acgsq092_fornecedor'),
   nu_tipo_fornecedor   INT                  not null,
   nu_instituicao_bancaria INT                  not null,
   nu_identificardor_frncr CHAR(14)             not null,
   no_fornecedor        CHAR(50)             null,
   de_telefone          CHAR(12)             null,
   no_email             CHAR(40)              null,
   nu_agencia           INT               null,
   nu_conta             INT               null,
   nu_idntr_conta_fmcr  CHAR(14)             null,
   no_titular           CHAR(50)             null,
   constraint PK_ACGTB092_FORNECEDOR primary key (nu_fornecedor)

   );

comment on table acgsm001.acgtb092_fornecedor is
'tabela de registo dos fornecedores';

comment on column acgsm001.acgtb092_fornecedor.nu_tipo_fornecedor is
'Identificador unico do tipo de fornecedor';

comment on column acgsm001.acgtb092_fornecedor.nu_instituicao_bancaria is
'Identificador unico de instituição bancaria';

comment on column acgsm001.acgtb092_fornecedor.no_email is
'endereço de emal principal do fornecedor';

comment on column acgsm001.acgtb092_fornecedor.nu_agencia is
'Informações fiscais, numero de agencia';

comment on column acgsm001.acgtb092_fornecedor.nu_conta is
'Informações fiscais numero da conta';

comment on column acgsm001.acgtb092_fornecedor.nu_idntr_conta_fmcr is
'identificação (CPF/CNPJ) do titular da conta bancaria';

comment on column acgsm001.acgtb092_fornecedor.no_titular is
'Nome do  titular da conta Bancaria';

alter table acgsm001.acgtb092_fornecedor
   add constraint FK_ACGTB092_REFERENCE_ACGTB091 foreign key (nu_tipo_fornecedor)
      references acgsm001.acgtb091_gestao_tipo_fornecedor (nu_tipo_fornecedor)
      on delete restrict on update restrict;

alter table acgsm001.acgtb092_fornecedor
   add constraint FK_ACGTB092_REFERENCE_ACGTB093 foreign key (nu_instituicao_bancaria)
      references acgsm001.acgtb093_instituicao_bancaria (nu_instituicao_bancaria)
      on delete restrict on update restrict;


      
/*==============================================================*/
/* Script Reverse: acgsm001.acgtb092_fornecedor                          */
/*==============================================================*/ 
      
--drop sequence acgsm001.acgsq092_fornecedor;
      
--drop table acgsm001.acgtb092_fornecedor;
      
      
      