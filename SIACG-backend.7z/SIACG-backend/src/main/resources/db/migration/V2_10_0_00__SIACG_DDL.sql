/*============================================================*/
/*           SCRIPT V2_10_0_00__SIACG_DDL		              */
/*============================================================*/

ALTER TABLE acgsm001.acgtb069_bandeira_cartao ADD COLUMN co_cnpj_instituidor character varying(14) null;
comment on column acgsm001.acgtb069_bandeira_cartao.co_cnpj_instituidor is 'Código do CNPJ do Instituidor do Arranjo de Pagamento.';

/*==============================================================*/
/* Index: ix_acgtb069_01                                        */
/*==============================================================*/
create index ix_acgtb069_01 on acgsm001.acgtb069_bandeira_cartao (co_cnpj_instituidor);

/*============================================================*/
/* Revert                                                     */
/*============================================================*/
-- drop index acgsm001.ix_acgtb069_01;
-- ALTER TABLE acgsm001.acgtb069_bandeira_cartao DROP COLUMN co_cnpj_instituidor;