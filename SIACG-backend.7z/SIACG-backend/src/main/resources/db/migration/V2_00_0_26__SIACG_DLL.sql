ALTER TABLE acgsm001.acgtb081_imoveis ALTER COLUMN nu_numero TYPE CHARACTER VARYING(6);

ALTER TABLE acgsm001.acgtb081_imoveis ALTER COLUMN  nu_numero DROP NOT NULL;
ALTER TABLE acgsm001.acgtb081_imoveis ALTER COLUMN  no_logadouro DROP NOT NULL;
ALTER TABLE acgsm001.acgtb081_imoveis ALTER COLUMN  no_complemento DROP NOT NULL;
ALTER TABLE acgsm001.acgtb081_imoveis ALTER COLUMN  no_bairro DROP NOT NULL;
ALTER TABLE acgsm001.acgtb081_imoveis ALTER COLUMN  nu_cep DROP NOT NULL;

ALTER TABLE acgsm001.acgtb081_imoveis ADD COLUMN cod_avaliacao_consessao CHARACTER VARYING(50);
ALTER TABLE acgsm001.acgtb081_imoveis ADD COLUMN cod_avaliacao_consolidado CHARACTER VARYING(50);