/*================================================================================================*/
                                    -- V2_00_0_15__SIACG_DLL.sql
/*================================================================================================*/

INSERT INTO acgsm001.acgtb008_grupo_garantia(
            nu_grupo_garantia, no_grupo_garantia, ic_acompanha, ic_ativo)
    VALUES ((select max(coalesce(nu_grupo_garantia,0)) + 1 as nu from acgsm001.acgtb008_grupo_garantia), 'EMPREENDIMENTOS HIPOTECA', TRUE, TRUE);
    
    
UPDATE acgsm001.acgtb008_grupo_garantia SET no_grupo_garantia = 'EMPREENDIMENTOS RECEBIVEIS' WHERE nu_grupo_garantia = 19;
    