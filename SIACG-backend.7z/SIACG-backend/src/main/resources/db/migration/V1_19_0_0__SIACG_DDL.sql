DROP SEQUENCE IF EXISTS acgsm001.sq054_log_servico_saldo;
create sequence acgsm001.sq054_log_servico_saldo;

DROP TABLE IF EXISTS acgsm001.acgtb054_log_servico_saldo;

create table acgsm001.acgtb054_log_servico_saldo (
   nu_log_servico_saldo INT4                 not null,
   ts_solicitacao       TIMESTAMP            not null,
   no_sistema_solicitante VARCHAR(5)         null,
   co_identificador_pessoa VARCHAR(14)       null,
   de_solicitacao       TEXT                 not null,
   ic_retorno           CHAR(2)              not null
      constraint CKC_IC_RETORNO_ACGTB054 check (ic_retorno in ('00','01','02','03','04','05','06')),
   de_retorno           TEXT                 not null,
   constraint PK_ACGTB054_LOG_SERVICO_SALDO primary key (nu_log_servico_saldo)
);

comment on table acgsm001.acgtb054_log_servico_saldo is 'Armazena registros de log referentes ao serviço que recebe solicitações de consulta a saldos de aplicações/contas de uma pessoa.';
comment on column acgsm001.acgtb054_log_servico_saldo.nu_log_servico_saldo is 'Número identificador do registro de log.';
comment on column acgsm001.acgtb054_log_servico_saldo.ts_solicitacao is 'Data e hora em que o serviço recebeu a solicitação de consulta a saldos de aplicações/contas.';
comment on column acgsm001.acgtb054_log_servico_saldo.no_sistema_solicitante is 'Nome do sistema que enviou a solicitação de consulta a saldos de aplicações/contas.';
comment on column acgsm001.acgtb054_log_servico_saldo.co_identificador_pessoa is 'Código identificador da pessoa (cpf/cnpj) cujos saldos de aplicações/contas foram consultados.';
comment on column acgsm001.acgtb054_log_servico_saldo.de_solicitacao is 'Descrição da solicitação recebida pelo serviço.';
comment on column acgsm001.acgtb054_log_servico_saldo.ic_retorno is 'Indica o tipo de retorno realizado pelo serviço ao sistema solicitante, podendo ser:
00 - SUCESSO. Significa que a solicitação de consulta a saldos de aplicações/contas de uma pessoa foi atendida com sucesso.
01 - SINTAXE INVALIDA. Significa que a mensagem de solicitação (de_solicitacao) recebida pelo serviço estava fora do padrão esperado.
02 - SERVICO CONSULTA CONTAS INDISPONIVEL. Significa que o serviço que consulta as contas de uma pessoa estava indisponível.
03 - SERVICO CONSULTA CONTAS RETORNOU CODIGO DE ERRO. Significa que o serviço que consulta as contas de uma pessoa retornou um código de erro.
04 - SERVICO CONSULTA CONTAS RETORNOU MENSAGEM INESPERADA. Significa que o serviço que consulta as contas de uma pessoa retornou uma mensagem fora do padrão esperado.
05 - CLIENTE NAO POSSUI APLICACOES OU NAO POSSUI APLICACOES VALIDAS.
06 - ERRO INTERNO. Significa que ocorreu um erro interno durante o processamento da solicitação.';
comment on column acgsm001.acgtb054_log_servico_saldo.de_retorno is 'Descrição do retorno realizado pelo serviço ao sistema solicitante.';

-- insert
INSERT INTO acgsm001.acgtb017_propriedade(no_propriedade, no_valor_propriedade, no_grupo, de_comentario)
VALUES ('servico.saldo.produto', '13;22', 'servico.saldo', 'Corresponde aos produtos que serão aceitos pelo serviço que recebe solicitações de consulta a saldos de aplicações/contas de uma pessoa. Inserir separando-os por ponto e vírgula (exemplo: 13;22).');
