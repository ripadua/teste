/*==============================================================*/
/*           SCRIPT V2_00_0_72__SIACG_DLL						*/
/*==============================================================*/

create view acgsm001.acgvw011_instituicao_bancaria as 
select nu_banco nu_instituicao_bancaria, no_banco no_banco_reduzido from icosm001.icotbn01_banco
where ic_stco_banco = 'A'
order by 1;

-- Remoção das chaves antigas
ALTER TABLE acgsm001.acgtb092_fornecedor DROP CONSTRAINT fk_acgtb092_reference_acgtb093;
ALTER TABLE acgsm001.acgtb089_gestao_serventia DROP CONSTRAINT fk_acgtb089_reference_acgtb093;

-- Criação das chaves novas
/*
ALTER TABLE acgsm001.acgtb092_fornecedor
  ADD CONSTRAINT fk_acgtb092_reference_acgvw011 FOREIGN KEY (nu_instituicao_bancaria)
      REFERENCES icosm001.icotbn01_banco (nu_banco) MATCH SIMPLE
      ON UPDATE RESTRICT ON DELETE RESTRICT;

ALTER TABLE acgsm001.acgtb089_gestao_serventia
  ADD CONSTRAINT fk_acgtb089_reference_acgvw011 FOREIGN KEY (nu_instituicao_bancaria)
      REFERENCES icosm001.icotbn01_banco (nu_banco) MATCH SIMPLE
      ON UPDATE RESTRICT ON DELETE RESTRICT;
*/
-- DROP TABLE if exists acgsm001.acgtb093_instituicao_bancaria;
      
/*########################### SCRIPT ROLLBACK ##############################*/      