/*==============================================================*/
/*           SCRIPT V2_00_0_96__SIACG_DLL						*/
/*==============================================================*/

/*==============================================================*/
/* Table: acgsm001.acgtb051_ctrto_comercializacao               */
/*==============================================================*/

ALTER TABLE acgsm001.acgtb051_ctrto_comercializacao add column ic_origem_plano_pagamento integer null constraint ckc_acgtb051_01 check (ic_origem_plano_pagamento is null or (ic_origem_plano_pagamento in ('1','2')));
	  
comment on column acgsm001.acgtb051_ctrto_comercializacao.ic_origem_plano_pagamento is
'Define a origem do plano de pagamento do contrato de comercialização, podendo ser:
1 - CCV
2 - Extrato Consolidado';

/*==============================================================*/
/* Table: cgsm001.acgtb001_contrato                             */
/*==============================================================*/

ALTER TABLE acgsm001.acgtb001_contrato add column sg_sistema_origem character varying(5) null;

comment on column acgsm001.acgtb001_contrato.sg_sistema_origem is 'sigla do sistema de origem do contrato';

/*==============================================================*/
/* Reverse Table                                                */
/*==============================================================*/
--ALTER TABLE acgsm001.acgtb051_ctrto_comercializacao drop column ic_origem_plano_pagamento;
--ALTER TABLE acgsm001.acgtb001_contrato drop column sg_sistema_origem;