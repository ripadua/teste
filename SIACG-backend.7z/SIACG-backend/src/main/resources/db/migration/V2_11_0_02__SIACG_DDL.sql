/*============================================================*/
/*           SCRIPT V2_11_0_02__SIACG_DDL		              */
/*============================================================*/
ALTER TABLE acgsm001.acgtb001_contrato ADD COLUMN de_motivo_tratamento_especial TEXT;
ALTER TABLE acgsm001.acgtb001_contrato ADD COLUMN dh_tratamento_especial TIMESTAMP;

comment on column acgsm001.acgtb001_contrato.de_motivo_tratamento_especial is
'Descrição do motivo do tratamento especial (ic_tratamento_especial = true).';

comment on column acgsm001.acgtb001_contrato.dh_tratamento_especial is
'Data e hora em que foi dado o tratamento especial (ic_tratamento_especial = true).';

/*==============================================================*/
/* REVERT                                                       */
/*==============================================================*/
-- ALTER TABLE acgsm001.acgtb001_contrato DROP COLUMN de_motivo_tratamento_especial;
-- ALTER TABLE acgsm001.acgtb001_contrato DROP COLUMN dh_tratamento_especial;