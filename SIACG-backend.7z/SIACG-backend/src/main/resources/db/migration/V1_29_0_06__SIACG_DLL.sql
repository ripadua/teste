﻿CREATE TABLE acgsm001.acgtb082_garantia_contrato_veiculo
(
  nu_veiculo bigint not null,
  nu_garantia_contrato integer NOT NULL
);

COMMENT ON TABLE acgsm001.acgtb082_garantia_contrato_veiculo IS 'Associação entre Garantia Contrato e Veiculos.';
COMMENT ON COLUMN acgsm001.acgtb082_garantia_contrato_veiculo.nu_veiculo IS 'Identificador do veículo.';
COMMENT ON COLUMN acgsm001.acgtb082_garantia_contrato_veiculo.nu_garantia_contrato IS 'Identificador da garantia do contrato.';

alter table acgsm001.acgtb009_garantia_contrato
add column nu_conta character varying(20), 
add column nu_agencia_conta character varying(10), 
add column nu_operacao_conta character varying(6), 
add column nu_dv_conta character varying(1);

COMMENT ON COLUMN acgsm001.acgtb009_garantia_contrato.nu_conta IS 'Número da conta.';
COMMENT ON COLUMN acgsm001.acgtb009_garantia_contrato.nu_agencia_conta IS 'Número da agencia.';
COMMENT ON COLUMN acgsm001.acgtb009_garantia_contrato.nu_operacao_conta IS 'Número da operação.';
COMMENT ON COLUMN acgsm001.acgtb009_garantia_contrato.nu_dv_conta IS 'Número do dígito verificador da conta.';

ALTER TABLE acgsm001.acgtb054_acao_preventiva 
ADD column nu_garantia_contrato integer NOT NULL,
ADD CONSTRAINT fk_acgtb054_acgtb009 FOREIGN KEY (nu_garantia_contrato)REFERENCES acgsm001.acgtb009_garantia_contrato (nu_garantia_contrato) 
MATCH SIMPLE ON UPDATE RESTRICT ON DELETE RESTRICT;

COMMENT ON COLUMN acgsm001.acgtb054_acao_preventiva.nu_garantia_contrato IS 'Identificador da garantia do contrato.';

CREATE SEQUENCE acgsm001.sq054_acao_preventiva_chave_bloqueio_nsgd;

ALTER TABLE acgsm001.acgtb054_acao_preventiva 
ADD column ic_ds200 integer NOT NULL default 0;

COMMENT ON COLUMN acgsm001.acgtb054_acao_preventiva.ic_ds200 IS 'Indicador do DS200:
0 - Não é necessário enviar o DS200 ou a garantia não é um conta SIDEC.
1 - Aguardando envio do DS200.
2 - Enviado ao DS200.
3 - Resposta do DS200 de Sucesso.';