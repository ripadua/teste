BEGIN;
    INSERT INTO acgsm001.acgtb038_operacao_sistema(nu_operacao, no_sistema, de_mascara)
    VALUES ((select max(cast(coalesce(nu_operacao, '') as integer)) + 1 as nu from acgsm001.acgtb038_operacao_sistema), 'SIOPI', '_.____._______-xx');
COMMIT;

BEGIN;
    INSERT INTO acgsm001.acgtb038_operacao_sistema(nu_operacao, no_sistema, de_mascara)
    VALUES ((select max(cast(coalesce(nu_operacao, '') as integer)) + 1 as nu from acgsm001.acgtb038_operacao_sistema), 'SIACI', '_.____._______-xx');
COMMIT;
