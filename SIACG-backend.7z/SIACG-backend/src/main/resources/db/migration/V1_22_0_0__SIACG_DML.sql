--========================================
--Data: 29/03/2018
--Versão 1.21.0
--Adequações no banco de dados para implementação do bloqueio/desbloqueio de saldo.
--========================================

INSERT INTO acgtb017_propriedade(no_propriedade, no_valor_propriedade, no_grupo, de_comentario) VALUES ('bloqueio.cl_dv','078','bloqueio','Código de CL para utilização na comunicação com o SID00');
INSERT INTO acgtb017_propriedade(no_propriedade, no_valor_propriedade, no_grupo, de_comentario) VALUES ('bloqueio.rede_trans_ori','9200','bloqueio','Código da Rede Transmissora utilizado na comunicação com o SID00');
INSERT INTO acgtb017_propriedade(no_propriedade, no_valor_propriedade, no_grupo, de_comentario) VALUES ('bloqueio.td_dv','116','bloqueio','Código de TD para utilização na comunicação com o SID00');
INSERT INTO acgtb017_propriedade(no_propriedade, no_valor_propriedade, no_grupo, de_comentario) VALUES ('bloqueio.versao','002','bloqueio','Codigo de versão para utilização na comunicação com o SID00');
INSERT INTO acgtb017_propriedade(no_propriedade, no_valor_propriedade, no_grupo, de_comentario) VALUES ('bloqueio.tipo','80','bloqueio','Codigo de Tipo vinculado ao TD-CL para utilização na comunicação com o SID00');

