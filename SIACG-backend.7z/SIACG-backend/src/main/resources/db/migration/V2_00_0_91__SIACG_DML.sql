/*==============================================================*/
/*           SCRIPT V2_00_0_91__SIACG_DLL						*/
/*==============================================================*/

/*==============================================================*/
/* Table: acgsm001.acgtb106_bem_cliente                         */
/*==============================================================*/

INSERT INTO acgsm001.acgtb106_bem_cliente(ic_tipo_bem, nu_imovel, nu_pessoa) (SELECT 1, nu_imovel, nu_pessoa FROM acgsm001.acgtb081_imovel);
INSERT INTO acgsm001.acgtb106_bem_cliente(ic_tipo_bem, nu_maquina_equipamento, nu_pessoa) (SELECT 2, nu_maquina_equipamento, nu_pessoa FROM acgsm001.acgtb077_maquina_equipamento);
INSERT INTO acgsm001.acgtb106_bem_cliente(ic_tipo_bem, nu_veiculo) (SELECT 3, nu_veiculo FROM acgsm001.acgtb075_veiculo);


/*==============================================================*/
/* Table: acgsm001.acgtb107_contrato_bem_cliente                */
/*==============================================================*/

insert into acgsm001.acgtb107_contrato_bem_cliente(nu_contrato, nu_bem_cliente) 
(select nu_contrato, nu_bem_cliente from acgsm001.acgtb087_contrato_imovel ci inner join acgsm001.acgtb106_bem_cliente bc on ci.nu_imovel = bc.nu_imovel);

insert into acgsm001.acgtb107_contrato_bem_cliente(nu_contrato, nu_bem_cliente) 
(select nu_contrato, nu_bem_cliente from acgsm001.acgtb096_contrato_maquina_equipamento cm inner join acgsm001.acgtb106_bem_cliente bc on cm.nu_maquina_equipamento = bc.nu_maquina_equipamento);


/*==============================================================*/
/* Table: acgsm001.acgtb108_garantia_bem_cliente                */
/*==============================================================*/

INSERT INTO acgsm001.acgtb108_garantia_bem_cliente(nu_bem_cliente, nu_garantia_contrato) (select bem.nu_bem_cliente, gm.nu_garantia_contrato from acgsm001.acgtb106_bem_cliente bem inner join acgsm001.acgtb076_garantia_maquina_eqpmo gm on gm.nu_maquina_equipamento = bem.nu_maquina_equipamento);
INSERT INTO acgsm001.acgtb108_garantia_bem_cliente(nu_bem_cliente, nu_garantia_contrato) (select bem.nu_bem_cliente, gi.nu_garantia_contrato from acgsm001.acgtb106_bem_cliente bem inner join acgsm001.acgtb080_garantia_imovel gi on gi.nu_imovel = bem.nu_imovel);
INSERT INTO acgsm001.acgtb108_garantia_bem_cliente(nu_bem_cliente, nu_garantia_contrato) (select bem.nu_bem_cliente, gv.nu_garantia_contrato from acgsm001.acgtb106_bem_cliente bem inner join acgsm001.acgtb082_garantia_contrato_veiculo gv on gv.nu_veiculo = bem.nu_veiculo);