/*==============================================================*/
/* SCRIPT V2_00_0_66__SIACG_DLL									*/
/*==============================================================*/



ALTER TABLE acgsm001.acgtb077_maquina_equipamento
  ADD COLUMN nu_pessoa integer,
  ADD COLUMN nu_grupo_garantia integer,
  ADD COLUMN co_tipo_pessoa character varying(1);
  
  COMMENT ON COLUMN acgsm001.acgtb077_maquina_equipamento.nu_pessoa IS 'id pessoa';
  COMMENT ON COLUMN acgsm001.acgtb077_maquina_equipamento.nu_grupo_garantia IS 'id grupo garantia';
  COMMENT ON COLUMN acgsm001.acgtb077_maquina_equipamento.co_tipo_pessoa IS 'tipo pessoa - JURIDICA, PESSOA';
  
  -- ROOLBACK
  --ALTER TABLE acgsm001.acgtb077_maquina_equipamento
  --DROP COLUMN nu_pessoa,
  --DROP COLUMN nu_grupo_garantia,
  --DROP COLUMN co_tipo_pessoa;

  