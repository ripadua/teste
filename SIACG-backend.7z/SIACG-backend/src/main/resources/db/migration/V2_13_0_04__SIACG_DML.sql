/*============================================================*/
/*           SCRIPT V2_13_0_04__SIACG_DML		              */
/*============================================================*/

--RETORNA PARA 80 POIS O SID00 AINDA NÃO IMPLEMENTOU O TIPO 58
UPDATE acgsm001.acgtb017_propriedade SET no_valor_propriedade='80' WHERE no_propriedade='bloqueio.tipo';