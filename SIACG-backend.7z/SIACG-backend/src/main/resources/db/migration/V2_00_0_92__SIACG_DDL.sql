/*==============================================================*/
/*           SCRIPT V2_00_0_92__SIACG_DDL						*/
/*==============================================================*/

/*==============================================================*/
/* Table: acgsm001.acgtb076_garantia_maquina_eqpmo              */
/*==============================================================*/

ALTER TABLE acgsm001.acgtb076_garantia_maquina_eqpmo
DROP CONSTRAINT fk_acgtb076_acgtb009,
DROP CONSTRAINT fk_acgtb076_acgtb077;


/*==============================================================*/
/* Table: acgsm001.acgtb080_garantia_imovel                         */
/*==============================================================*/
ALTER TABLE acgsm001.acgtb080_garantia_imovel
DROP CONSTRAINT fk_acgtb080_acgtb009,
DROP CONSTRAINT fk_acgtb080_acgtb081;
