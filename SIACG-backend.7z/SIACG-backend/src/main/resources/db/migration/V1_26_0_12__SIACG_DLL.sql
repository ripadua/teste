-- ###############   Tabela: acgtb053_recebido
-- Adicionado comentarios da coluna: ic_situacao_conciliacao

ALTER TABLE acgsm001.acgtb053_recebido
  OWNER TO postgres;
COMMENT ON COLUMN acgsm001.acgtb053_recebido.ic_situacao_conciliacao IS '
	0 - Conciliado automaticamente pelo sistema
	1 - Conciliado manualmente por tratamento de pendência.
	2 - Pendência de identificação de contrato por falta do sacado
	3 - Pendência de identificação do contrato por duplicação de sacado
	4 - Pendência de conciliação de valores com o prospecto do contrato
	5 - Pendência resolvida sem conciliação.';