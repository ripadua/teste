INSERT INTO acgsm001.acgtb017_propriedade(no_propriedade, no_valor_propriedade, no_grupo, de_comentario)VALUES ('nsgd.grupo.desbloqueio', '4', 'bloqueio', 'Código do CIF.GRUPO para utilização na comunicação com o NSGD para desbloqueio'); 

create  index ix_acgtb008_01 on acgsm001.acgtb008_grupo_garantia (ic_acompanha);