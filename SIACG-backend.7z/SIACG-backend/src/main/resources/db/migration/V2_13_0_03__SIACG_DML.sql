/*============================================================*/
/*           SCRIPT V2_13_0_03__SIACG_DML		              */
/*============================================================*/

--RETORNA PARA 80 POIS O SIFIX AINDA NÃO IMPLEMENTOU O TIPO 58
UPDATE acgsm001.acgtb017_propriedade SET no_valor_propriedade = '80' WHERE no_propriedade = 'sifix.tipo';