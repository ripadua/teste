/*==============================================================*/
/*           SCRIPT V2_00_0_97__SIACG_DLL						*/
/*==============================================================*/

/*==============================================================*/
/* Table: acgsm001.acgtb081_imovel                              */
/*==============================================================*/

ALTER TABLE acgsm001.acgtb081_imovel DROP CONSTRAINT ck_acgtb081_02;

ALTER TABLE acgsm001.acgtb081_imovel
  ADD CONSTRAINT ck_acgtb081_02 CHECK (nu_categoria_imovel IS NULL OR (nu_categoria_imovel = ANY (ARRAY[1, 2, 3, 4,5])));

comment on column acgsm001.acgtb081_imovel.nu_categoria_imovel is
'-- Categoria do imóvel: 1 - Casa, 2 - Apartamento, 3 - Lote, 4 - Sala. 5 - Terreno';