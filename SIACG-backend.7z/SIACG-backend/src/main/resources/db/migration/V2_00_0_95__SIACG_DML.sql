/*==============================================================*/
/*           SCRIPT V2_00_0_93__SIACG_DLL						*/
/*==============================================================*/

/*==============================================================*/
/* Table: acgsm001.acgtb041_segmento                            */
/*==============================================================*/
insert into acgsm001.acgtb041_segmento(nu_segmento, no_segmento, de_funcionalidade) values (0, 'Pessoa Física', 'pessoa_fisica');
update acgsm001.acgtb003_pessoa set nu_segmento = 0 where nu_segmento = 5;
delete from acgsm001.acgtb041_segmento where nu_segmento = 5;

update acgsm001.acgtb041_segmento set ic_visualiza_novo_cartao = true where nu_segmento = 1;