ALTER TABLE acgsm001.acgtb081_imovel
   ALTER COLUMN vr_area_privativa DROP NOT NULL;
COMMENT ON COLUMN acgsm001.acgtb081_imovel.vr_area_privativa IS 'Valor da área privativa (área construida do imóvel).';