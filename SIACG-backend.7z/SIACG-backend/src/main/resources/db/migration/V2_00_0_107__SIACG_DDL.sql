/*==============================================================*/
/*           SCRIPT V2_00_0_107__SIACG_DLL						*/
/*==============================================================*/

 ALTER TABLE acgsm001.acgtb032_envio_notificacao DROP CONSTRAINT ckc_ic_nivel_acgtb032;

ALTER TABLE acgsm001.acgtb032_envio_notificacao
  ADD CONSTRAINT ckc_ic_nivel_acgtb032 CHECK (ic_nivel = ANY (ARRAY['0'::bpchar, '1'::bpchar, '2'::bpchar, '3'::bpchar]));
  
  -- Criacao de indices para a tabela de trilha historico
  CREATE INDEX ix_acgtbx02_01
  ON acgsm001.acgtbx02_trilha_historico
  USING btree
  (ic_acao COLLATE pg_catalog."default");

CREATE INDEX ix_acgtbx02_02
  ON acgsm001.acgtbx02_trilha_historico
  USING btree
  (no_acao COLLATE pg_catalog."default");
  
  CREATE INDEX ix_acgtbx02_03
  ON acgsm001.acgtbx02_trilha_historico
  USING btree
  (co_responsavel_acao COLLATE pg_catalog."default");
  
  
/*========================================*/
/* Script de reversão					  */
/*========================================*/
  
  --ALTER TABLE acgsm001.acgtb032_envio_notificacao DROP CONSTRAINT ckc_ic_nivel_acgtb032;
  
  -- ALTER TABLE acgsm001.acgtb032_envio_notificacao
  -- ADD CONSTRAINT ckc_ic_nivel_acgtb032 CHECK (ic_nivel = ANY (ARRAY['1'::bpchar, '2'::bpchar, '3'::bpchar]))
  
  -- DROP INDEX acgsm001.ix_acgtbx02_01;
  
  -- DROP INDEX acgsm001.ix_acgtbx02_02;
  
  -- DROP INDEX acgsm001.ix_acgtbx02_03;