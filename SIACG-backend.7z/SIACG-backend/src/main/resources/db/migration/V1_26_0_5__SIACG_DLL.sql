ALTER TABLE acgsm001.acgtbi01_mov_cartoes
   ADD COLUMN co_cnpj_credenciador character varying(14);


COMMENT ON COLUMN acgsm001.acgtbi01_mov_cartoes.co_cnpj_credenciador IS 'Armazena o cnpj do credenciador para descartar os registros que não estejam relacionados com a tabela acgtb072_credenciador,
via cnpj';
