/*============================================================*/
/*           SCRIPT V2_08_0_05__SIACG_DML				      */
/*============================================================*/

-- Alterar a informacao de no_valor_propriedade conforme cada ambiente (HMP e PROD)
UPDATE acgsm001.acgtb017_propriedade SET no_valor_propriedade='10.123.15.76' WHERE no_propriedade='caminho.ftp';

