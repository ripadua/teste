/*==============================================================*/
/*           SCRIPT V2_00_0_70__SIACG_DLL						*/
/*==============================================================*/

ALTER TABLE acgsm001.acgtb095_despesa ADD COLUMN nu_fornecedor integer;
COMMENT ON COLUMN acgsm001.acgtb095_despesa.nu_fornecedor IS 'numero de identificador do fornecedor ';

ALTER TABLE acgsm001.acgtb095_despesa ADD COLUMN nu_gestao_serventia integer;
COMMENT ON COLUMN acgsm001.acgtb095_despesa.nu_gestao_serventia IS 'numero de identificador do Cartório ';

ALTER TABLE acgsm001.acgtb095_despesa
  ADD CONSTRAINT fk_acgtb095_reference_acgtb089 FOREIGN KEY (nu_gestao_serventia)
      REFERENCES acgsm001.acgtb089_gestao_serventia (nu_gestao_serventia) MATCH SIMPLE
      ON UPDATE RESTRICT ON DELETE RESTRICT;

ALTER TABLE acgsm001.acgtb095_despesa
  ADD CONSTRAINT fk_acgtb095_reference_acgtb092 FOREIGN KEY (nu_fornecedor)
      REFERENCES acgsm001.acgtb092_fornecedor (nu_fornecedor) MATCH SIMPLE
      ON UPDATE RESTRICT ON DELETE RESTRICT;        


/*########################### SCRIPT ROLLBACK ##############################*/
 --ALTER TABLE acgsm001.acgtb095_despesa DROP CONSTRAINT fk_acgtb095_reference_acgtb089;
 --ALTER TABLE acgsm001.acgtb095_despesa DROP CONSTRAINT fk_acgtb095_reference_acgtb092;      
      
 --ALTER TABLE acgsm001.acgtb095_despesa DROP COLUMN nu_fornecedor;
 --ALTER TABLE acgsm001.acgtb095_despesa DROP COLUMN nu_gestao_serventia;