CREATE SEQUENCE acgsq047_garantia_habitacao
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;

CREATE TABLE acgtb047_garantia_habitacao (
    nu_garantia_habitacao bigint NOT NULL,
    nu_garantia_contrato integer NOT NULL,
    nu_unidade_habitacional bigint
);

COMMENT ON COLUMN acgtb047_garantia_habitacao.nu_garantia_habitacao IS 'Identifica unicamente o registro. Gerado automaticamente pelo sistema.';
COMMENT ON COLUMN acgtb047_garantia_habitacao.nu_garantia_contrato IS 'Identifica a garantia do contrato. Chave estrangeira.';
COMMENT ON COLUMN acgtb047_garantia_habitacao.nu_unidade_habitacional IS 'Identifica a unidade habitacional. Chave estrangeira.';
    
CREATE SEQUENCE acgsm001.acgsq048_tipo_undd_habitacional
  INCREMENT 1
  MINVALUE 1
  MAXVALUE 9223372036854775807
  START 11
  CACHE 1;  

DROP TABLE IF EXISTS  acgsm001.acgtb048_tipologia_habitacional;
CREATE TABLE acgsm001.acgtb048_tipologia_habitacional
(
  nu_tipologia_habitacional bigint NOT NULL,
  no_tipologia_habitacional character varying(256) NOT NULL,
  vr_contratacao numeric(15,2) NOT NULL,
  vr_atualizado numeric(15,2) NOT NULL,
  dh_atualizacao_valor timestamp without time zone,
  nu_empreendimento bigint NOT NULL
)
WITH (
  OIDS=FALSE
);

ALTER TABLE ONLY acgtb048_tipologia_habitacional ADD CONSTRAINT "PK_ACGTB048_TIPOLOGIA_HABITACI" PRIMARY KEY (nu_tipologia_habitacional);
CREATE INDEX ix_acgtb048_01 ON acgtb048_tipologia_habitacional USING btree (no_tipologia_habitacional);

CREATE SEQUENCE acgsq049_unidade_habitacional
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;

CREATE TABLE acgtb049_unidade_habitacional (
    nu_unidade_habitacional bigint NOT NULL,
    nu_tipologia_habitacional bigint NOT NULL,
    nu_empreendimento bigint,
    co_identificador_unidade character varying(50) NOT NULL,
    no_grupo_unidade character varying(50),
    co_unidade_construtora character varying(50) NOT NULL,
    ic_situacao character(2) NOT NULL,
    ic_situacao_origem character varying(255) NOT NULL,
    ic_mantida_hipoteca boolean NOT NULL,
    ic_hipotecada_contratacao boolean NOT NULL,
    dh_baixa_hipoteca timestamp without time zone,
    co_responsavel_baixa_hipoteca character varying(8),
    pc_minimo_baixa numeric(15,2) NOT NULL,
    dh_inclusao timestamp without time zone,
    co_responsavel character varying(7),
    CONSTRAINT ckc_ic_situacao_acgtb049 CHECK ((ic_situacao = ANY (ARRAY['01'::bpchar, '02'::bpchar, '03'::bpchar, '04'::bpchar, '05'::bpchar, '06'::bpchar])))
);

COMMENT ON TABLE acgtb049_unidade_habitacional IS 'Unidade habitacional vinculada ao contrato de emprendimento e que pode ser apresentada como garantia do contrato de financiamento entre a construtora e a Caixa.';
COMMENT ON COLUMN acgtb049_unidade_habitacional.nu_unidade_habitacional IS 'Identificador unico da unidade habitacional';
COMMENT ON COLUMN acgtb049_unidade_habitacional.nu_tipologia_habitacional IS 'Tipologia da unidade habitacional. Define as características da unidade habitacional.';
COMMENT ON COLUMN acgtb049_unidade_habitacional.nu_empreendimento IS 'Identifica o empreendimento ao qual a unidade habitacional está vinculada, quando existe essa relação.

Quando uma unidade habitacional é vinculada a uma garantia de um contrato, é informado se ela está vinculada ao empreendimento ao qual o contrato de crédito está relacionado. Caso seja informado que ela está vinculada ao empreendimento, deverá ser informado o número do empreendimento para manter essa relação.';
COMMENT ON COLUMN acgtb049_unidade_habitacional.co_identificador_unidade IS 'Código identificador da unidade habitacional utilizado pela Caixa para identificar de forma única uma unidade de um emprrendimento. Não pode se repetir para o mesmo empreendimento.

Ex: 1-A101, 3-A103';
COMMENT ON COLUMN acgtb049_unidade_habitacional.no_grupo_unidade IS 'Nome do grupo habitacional (Bloco/Torre) ao qual a unidade habitacional faz parte.

Ex: Bloco 1, Primeiro Pavimento.';
COMMENT ON COLUMN acgtb049_unidade_habitacional.co_unidade_construtora IS 'Código utilizado pela contrutora para identificar a unidade habitacional.

Ex: 101, A103';
COMMENT ON COLUMN acgtb049_unidade_habitacional.ic_situacao IS 'Identifica a situação da unidade habitacional.

01 - Autofinanciamento
02 - Estoque
03 - Permuta por terreno
04 - Quitada
05 - Repasse Caixa
06 - Com VMD pago';
COMMENT ON COLUMN acgtb049_unidade_habitacional.ic_situacao_origem IS 'Situação da UH sistema de origem do contrato.';
COMMENT ON COLUMN acgtb049_unidade_habitacional.ic_mantida_hipoteca IS 'Indica se UH é mantida hipoteca após sua comercialização.';
COMMENT ON COLUMN acgtb049_unidade_habitacional.ic_hipotecada_contratacao IS 'Indica se UH está hipotecada quando comercializada.';
COMMENT ON COLUMN acgtb049_unidade_habitacional.dh_baixa_hipoteca IS 'Data e hora em que foi realizada a baixa da hipoteca da unidade habitacional.';
COMMENT ON COLUMN acgtb049_unidade_habitacional.co_responsavel_baixa_hipoteca IS 'Código da matrícula do responsável pela baixa da hipoteca da unidade habitacional.';
COMMENT ON COLUMN acgtb049_unidade_habitacional.pc_minimo_baixa IS 'Percentual utilizado para o cálculo do valor mínimo devedor que deverá ser repassado pela construtora para a Caixa no momento da baixa de hipoteca de uma unidade habitacional.

Esse percentual será aplicado sobre o valor de avaliação da UH atualizado.

Ex. Caso o percentual seja de 50% e o valor atualizado da unidade habitacional seja de R$ 100.000,00, o valor mínimo de baixa será de R$ 50.000,00.
';
COMMENT ON COLUMN acgtb049_unidade_habitacional.dh_inclusao IS 'Data e hora de cadastro da unidade habitacional no SIACG. Esse cadastramento pode ser realizado em data posterior a data da contratação, portano é importante ter esse registro.';
COMMENT ON COLUMN acgtb049_unidade_habitacional.co_responsavel IS 'Código da matrícula do responsável pelo cadastramento das informações da unidade habitacional.

Caso a informação seja recebida por carga de sistema deverá ser registrado s000001.';

CREATE SEQUENCE acgsq050_empreendimento
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;

CREATE TABLE acgtb050_empreendimento (
    nu_empreendimento bigint NOT NULL,
    nu_contrato integer NOT NULL,
    nu_contrato_pai integer NOT NULL,
    no_empreendimento character varying(256) NOT NULL,
    in_esperado_hipoteca numeric(15,2),
    in_esperado_recebivel numeric(15,2),
    dt_fim_empreendimento date,
    vr_empreendimento numeric(15,2) NOT NULL,
    dt_inclusao timestamp without time zone NOT NULL,
    co_apf character varying(9),
    ic_forma_inclusao character(1) DEFAULT 1 NOT NULL,
    CONSTRAINT "CKC_IC_FORMA_INCLUSAO_ACGTB050" CHECK ((ic_forma_inclusao = ANY (ARRAY['1'::bpchar, '2'::bpchar])))
);

COMMENT ON TABLE acgtb050_empreendimento IS 'CONTRATO CEF X CONSTRUTORA, A construtora quer realizar um emprestimo para financiar o empreendimo, neste caso, ela oferece as';
COMMENT ON COLUMN acgtb050_empreendimento.nu_contrato IS 'Identificador do contrato. Virá da importação';
COMMENT ON COLUMN acgtb050_empreendimento.ic_forma_inclusao IS 'Indicar a origem da importação do contrato:

1- Rotina Carga
2- Manual';

CREATE SEQUENCE acgsq051_comercializacao
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;

CREATE TABLE acgsm001.acgtb051_comercializacao
(
  nu_comercializacao bigint NOT NULL,
  nu_unidade_habitacional bigint NOT NULL,
  dt_contrato date NOT NULL,
  vr_contrato numeric(15,2) NOT NULL,
  ic_indicador_reajuste character(1) NOT NULL, -- Identifica qual é o indice de reajuste dos valores prospectados:...
  ic_renegociada boolean DEFAULT false, -- Indica se houve renegociação para o contrato de comercialização da unidade habitacional....
  co_imagem_ged character varying(10),
  dh_inclusao date, -- Data e hora de cadastro do contrato no SIACG. Esse cadastramento pode ser realizado em data posterior a data da contratação, portano é importante ter esse registro.
  co_responsavel character varying(7), -- Código da matrícula do responsável pelo cadastramento das informações do contrato....
  ic_situacao character(2), -- comment on column acgtb051_ctrto_comercializacao.ic_situacao is...
  CONSTRAINT ckc_ic_reajuste_acgtb051 CHECK (ic_indicador_reajuste = ANY (ARRAY['1'::bpchar, '2'::bpchar, '3'::bpchar]))
)
WITH (
  OIDS=FALSE
);

COMMENT ON COLUMN acgsm001.acgtb051_comercializacao.ic_indicador_reajuste IS 'Identifica qual é o indice de reajuste dos valores prospectados:

1 - IGPM índice geral de preço de mercado
2 - INCC  índice nacional da construção civil 
3 - CUBI  custo unitário básico';
COMMENT ON COLUMN acgsm001.acgtb051_comercializacao.ic_renegociada IS 'Indica se houve renegociação para o contrato de comercialização da unidade habitacional.

TRUE: Houve renegociação para uma unidade comercializada
FALSE: Não houve renegociação. É também o valor padrão para unidades em estoque (ainda não comercializadas).';
COMMENT ON COLUMN acgsm001.acgtb051_comercializacao.dh_inclusao IS 'Data e hora de cadastro do contrato no SIACG. Esse cadastramento pode ser realizado em data posterior a data da contratação, portano é importante ter esse registro.
';
COMMENT ON COLUMN acgsm001.acgtb051_comercializacao.co_responsavel IS 'Código da matrícula do responsável pelo cadastramento das informações do contrato.

Caso a informação seja recebida por carga de sistema deverá ser registrado s000001.';
COMMENT ON COLUMN acgsm001.acgtb051_comercializacao.ic_situacao IS 'comment on column acgtb051_ctrto_comercializacao.ic_situacao is
''Identifica a situação do contrato de comercialização de uma unidade habitacional:
01 - Aberto
02 - Atrasado
03 - Fechado
04 - Cancelado
05 - Pré-Análise
06 - Contratado
'';';

CREATE SEQUENCE acgsq052_prospecto_recebimento
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;

CREATE TABLE acgtb052_prospecto_recebimento (
    nu_prospecto_recebimento bigint NOT NULL,
    nu_comercializacao bigint NOT NULL,
    vr_encargo numeric(15,2) NOT NULL,
    dt_encargo date NOT NULL,
    qt_periodicidade integer NOT NULL,
    qt_ocorrencia integer NOT NULL,
    ic_exclusao_distrato boolean,
    vr_compra_venda numeric(15,2) NOT NULL,
    ic_ocorrencia character(1) NOT NULL,
    CONSTRAINT ckc_ic_ocorrencia_acgtb052 CHECK ((ic_ocorrencia = ANY (ARRAY['1'::bpchar, '2'::bpchar, '3'::bpchar, '4'::bpchar])))
);

COMMENT ON COLUMN acgtb052_prospecto_recebimento.ic_ocorrencia IS '1 - Sinal
2 - Parcela
3 - Repasse bancário
4 - Chave';

CREATE SEQUENCE acgsq053_recebido
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;

CREATE TABLE acgtb053_recebido (
    nu_recebido bigint NOT NULL,
    nu_comercializacao bigint,
    ic_recebido character(1) NOT NULL,
    co_nosso_numero character varying(200) NOT NULL,
    dt_vencimento date NOT NULL,
    vr_recebido numeric(16,2) NOT NULL,
    no_sacado character varying(100) NOT NULL,
    vr_titulo numeric(16,2) NOT NULL,
    vr_pago numeric(16,2) NOT NULL,
    nu_documento integer,
    nu_identificador_sacado character varying(14) NOT NULL,
    nu_cedente integer NOT NULL,
    dh_recebimento timestamp without time zone,
    dh_inclusao timestamp without time zone NOT NULL,
    co_responsavel character varying(7) NOT NULL,
    CONSTRAINT ckc_ic_recebido_acgtb053 CHECK ((ic_recebido = ANY (ARRAY['1'::bpchar, '2'::bpchar, '3'::bpchar, '4'::bpchar, '5'::bpchar])))
);

COMMENT ON COLUMN acgtb053_recebido.ic_recebido IS 'Identifica o tipo do recebimento

1- Sinal
2- Balão
3- Parcela
4- Encargo
5- Amortização';

COMMENT ON COLUMN acgtb053_recebido.nu_identificador_sacado IS 'Armazena o cnpj/cpf do sacado';

ALTER TABLE ONLY acgtb047_garantia_habitacao ADD CONSTRAINT pk_acgtb047_garantia_habitacao PRIMARY KEY (nu_garantia_habitacao);
ALTER TABLE ONLY acgtb049_unidade_habitacional ADD CONSTRAINT pk_acgtb049_unidade_habitacion PRIMARY KEY (nu_unidade_habitacional);
ALTER TABLE ONLY acgtb050_empreendimento ADD CONSTRAINT pk_acgtb050_empreendimento PRIMARY KEY (nu_empreendimento);
ALTER TABLE ONLY acgtb051_comercializacao ADD CONSTRAINT pk_acgtb051_comercializacao PRIMARY KEY (nu_comercializacao);
ALTER TABLE ONLY acgtb052_prospecto_recebimento ADD CONSTRAINT pk_acgtb052_prospecto_recebime PRIMARY KEY (nu_prospecto_recebimento);
ALTER TABLE ONLY acgtb053_recebido ADD CONSTRAINT pk_acgtb053_recebido PRIMARY KEY (nu_recebido);

CREATE UNIQUE INDEX ix_acgtb047_01 ON acgtb047_garantia_habitacao USING btree (nu_garantia_contrato, nu_unidade_habitacional);
CREATE INDEX ix_acgtb049_01 ON acgtb049_unidade_habitacional USING btree (nu_tipologia_habitacional);
CREATE INDEX ix_acgtb049_02 ON acgtb049_unidade_habitacional USING btree (co_identificador_unidade);
CREATE UNIQUE INDEX ix_acgtb050_01 ON acgtb050_empreendimento USING btree (nu_contrato);
CREATE INDEX ix_acgtb050_02 ON acgtb050_empreendimento USING btree (no_empreendimento);
CREATE INDEX ix_acgtb050_03 ON acgtb050_empreendimento USING btree (dt_fim_empreendimento);
CREATE INDEX ix_acgtb050_04 ON acgtb050_empreendimento USING btree (dt_inclusao);
CREATE INDEX ix_acgtb051_01 ON acgtb051_comercializacao USING btree (nu_unidade_habitacional);
CREATE INDEX ix_acgtb051_02 ON acgtb051_comercializacao USING btree (dt_contrato);
CREATE INDEX ix_acgtb052_01 ON acgtb052_prospecto_recebimento USING btree (nu_comercializacao);
CREATE INDEX ix_acgtb052_02 ON acgtb052_prospecto_recebimento USING btree (dt_encargo);
CREATE INDEX ix_acgtb053_01 ON acgtb053_recebido USING btree (nu_comercializacao);
CREATE INDEX ix_acgtb053_02 ON acgtb053_recebido USING btree (dt_vencimento);
CREATE INDEX ix_acgtb053_03 ON acgtb053_recebido USING btree (nu_identificador_sacado);

ALTER TABLE ONLY acgtb047_garantia_habitacao ADD CONSTRAINT fk_acgtb047_acgtb009 FOREIGN KEY (nu_garantia_contrato) REFERENCES acgtb009_garantia_contrato(nu_garantia_contrato) ON UPDATE RESTRICT ON DELETE RESTRICT;
ALTER TABLE ONLY acgtb047_garantia_habitacao ADD CONSTRAINT fk_acgtb047_acgtb049 FOREIGN KEY (nu_unidade_habitacional) REFERENCES acgtb049_unidade_habitacional(nu_unidade_habitacional);
ALTER TABLE ONLY acgtb049_unidade_habitacional ADD CONSTRAINT fk_acgtb049_acgtb048 FOREIGN KEY (nu_tipologia_habitacional) REFERENCES acgtb048_tipologia_habitacional(nu_tipologia_habitacional) ON UPDATE RESTRICT ON DELETE RESTRICT;
ALTER TABLE ONLY acgtb050_empreendimento ADD CONSTRAINT fk_acgtb050_acgtb001 FOREIGN KEY (nu_contrato) REFERENCES acgtb001_contrato(nu_contrato) ON UPDATE RESTRICT ON DELETE RESTRICT;
ALTER TABLE ONLY acgtb051_comercializacao ADD CONSTRAINT fk_acgtb051_acgtb049 FOREIGN KEY (nu_unidade_habitacional) REFERENCES acgtb049_unidade_habitacional(nu_unidade_habitacional);
ALTER TABLE ONLY acgtb052_prospecto_recebimento ADD CONSTRAINT fk_acgtb052_acgtb051 FOREIGN KEY (nu_comercializacao) REFERENCES acgtb051_comercializacao(nu_comercializacao) ON UPDATE RESTRICT ON DELETE RESTRICT;
ALTER TABLE ONLY acgtb053_recebido ADD CONSTRAINT fk_acgtb053_acgtb051 FOREIGN KEY (nu_comercializacao) REFERENCES acgtb051_comercializacao(nu_comercializacao) ON UPDATE RESTRICT ON DELETE RESTRICT;
ALTER TABLE ONLY acgtb049_unidade_habitacional ADD CONSTRAINT fk_acttb049_acgtb050 FOREIGN KEY (nu_empreendimento) REFERENCES acgtb050_empreendimento(nu_empreendimento) ON UPDATE RESTRICT ON DELETE RESTRICT;
ALTER TABLE ONLY acgtb048_tipologia_habitacional ADD CONSTRAINT "FK_ACGTB048_ACGTB050" FOREIGN KEY (nu_empreendimento) REFERENCES acgtb050_empreendimento(nu_empreendimento);
