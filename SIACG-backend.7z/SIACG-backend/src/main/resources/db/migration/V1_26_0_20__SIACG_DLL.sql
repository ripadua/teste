-- Script para adicionar garantias ao novo tipo de garantia (Produto Agrícola).

UPDATE acgsm001.acgtb011_garantia
   SET nu_grupo_garantia= 18
 WHERE co_operacao in ('0321', '0322');
