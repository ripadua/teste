/*==============================================================*/
/*           SCRIPT V2_00_0_69__SIACG_DLL						*/
/*==============================================================*/
ALTER TABLE acgsm001.acgtb089_gestao_serventia ADD COLUMN nu_instituicao_bancaria integer;
COMMENT ON COLUMN acgsm001.acgtb089_gestao_serventia.nu_instituicao_bancaria IS 'Identificador unico de instituição bancaria';

ALTER TABLE acgsm001.acgtb089_gestao_serventia ADD COLUMN nu_agencia integer;
COMMENT ON COLUMN acgsm001.acgtb089_gestao_serventia.nu_agencia IS 'Informações fiscais, numero de agencia';

ALTER TABLE acgsm001.acgtb089_gestao_serventia ADD COLUMN nu_conta integer;
COMMENT ON COLUMN acgsm001.acgtb089_gestao_serventia.nu_conta IS 'Informações fiscais numero da conta';

ALTER TABLE acgsm001.acgtb089_gestao_serventia ADD COLUMN nu_idntr_conta_fmcr character(14);
COMMENT ON COLUMN acgsm001.acgtb089_gestao_serventia.nu_idntr_conta_fmcr IS 'identificação (CPF/CNPJ) do titular da conta bancaria';

ALTER TABLE acgsm001.acgtb089_gestao_serventia ADD COLUMN no_titular character(50);
COMMENT ON COLUMN acgsm001.acgtb089_gestao_serventia.no_titular IS 'Nome do  titular da conta Bancaria';

ALTER TABLE acgsm001.acgtb089_gestao_serventia ADD COLUMN nu_agencia_dv integer;
COMMENT ON COLUMN acgsm001.acgtb089_gestao_serventia.nu_agencia_dv IS 'Digito verificador da agencia';

ALTER TABLE acgsm001.acgtb089_gestao_serventia ADD COLUMN nu_conta_dv integer;
COMMENT ON COLUMN acgsm001.acgtb089_gestao_serventia.nu_conta_dv IS 'Digito verificador da conta';

ALTER TABLE acgsm001.acgtb095_despesa ADD COLUMN dt_inclusao_despesa timestamp without time zone;
ALTER TABLE acgsm001.acgtb095_despesa ALTER COLUMN dt_inclusao_despesa SET DEFAULT now();
COMMENT ON COLUMN acgsm001.acgtb095_despesa.dt_inclusao_despesa IS 'Informação da data e hora de inclusão da despesa no SIACG.';

ALTER TABLE acgsm001.acgtb089_gestao_serventia
  ADD CONSTRAINT fk_acgtb089_reference_acgtb093 FOREIGN KEY (nu_instituicao_bancaria)
      REFERENCES acgsm001.acgtb093_instituicao_bancaria (nu_instituicao_bancaria) MATCH SIMPLE
      ON UPDATE RESTRICT ON DELETE RESTRICT;

/*########################### SCRIPT ROLLBACK ##############################*/
-- ALTER TABLE acgsm001.acgtb089_gestao_serventia DROP CONSTRAINT fk_acgtb089_reference_acgtb093;
-- ALTER TABLE acgsm001.acgtb089_gestao_serventia DROP COLUMN nu_agencia;
-- ALTER TABLE acgsm001.acgtb089_gestao_serventia DROP COLUMN nu_conta;
-- ALTER TABLE acgsm001.acgtb089_gestao_serventia DROP COLUMN nu_idntr_conta_fmcr;
-- ALTER TABLE acgsm001.acgtb089_gestao_serventia DROP COLUMN no_titular;
-- ALTER TABLE acgsm001.acgtb089_gestao_serventia DROP COLUMN nu_agencia_dv;
-- ALTER TABLE acgsm001.acgtb089_gestao_serventia DROP COLUMN nu_conta_dv;
-- ALTER TABLE acgsm001.acgtb092_fornecedor DROP COLUMN nu_instituicao_bancaria;     
-- ALTER TABLE acgsm001.acgtb095_despesa DROP COLUMN dt_inclusao_despesa; 