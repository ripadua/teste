/*==============================================================*/
/*           SCRIPT V2_00_0_77__SIACG_DLL						*/
/*==============================================================*/

-- Criação de novas colunas
ALTER TABLE acgsm001.acgtb001_contrato ADD COLUMN ic_origem integer default 1;
ALTER TABLE acgsm001.acgtb001_contrato ALTER COLUMN ic_origem SET NOT NULL;
COMMENT ON COLUMN acgsm001.acgtb001_contrato.ic_origem IS '1 - ETL, 2 - API';

      
/*########################### SCRIPT ROLLBACK ##############################*/      

-- ALTER TABLE acgsm001.acgtb001_contrato DROP COLUMN ic_origem;