/*==============================================================*/
/*           SCRIPT V2_00_0_82__SIACG_DLL						*/
/*==============================================================*/

create sequence acgsm001.sq0103_documento_lancamento_evento;
  
ALTER TABLE acgsm001.acgtb103_documento_lancamento_evento ALTER COLUMN nu_documento_lancamento_evento SET DEFAULT nextval('acgsm001.sq0103_documento_lancamento_evento'::regclass);
      
/*########################### SCRIPT ROLLBACK ##############################*/
--DROP SEQUENCE acgsm001.sq0103_documento_lancamento_evento;