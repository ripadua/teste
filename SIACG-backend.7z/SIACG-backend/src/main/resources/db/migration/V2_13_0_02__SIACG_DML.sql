/*============================================================*/
/*           SCRIPT V2_13_0_02__SIACG_DML		              */
/*============================================================*/

INSERT INTO acgsm001.acgtb017_propriedade(no_propriedade, no_valor_propriedade, no_grupo, de_comentario)
VALUES ('sifix.tipo', '58', 'bloqueio', 'Código do Tipo de bloqueio de garantia para utilização na comunicação com o SIFIX');

/*============================================================*/
/* Revert 								                      */
/*============================================================*/
--DELETE FROM acgsm001.acgtb017_propriedade WHERE no_propriedade = 'sifix.tipo';