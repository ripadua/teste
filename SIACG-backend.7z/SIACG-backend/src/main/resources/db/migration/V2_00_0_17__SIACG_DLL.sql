/*================================================================================================*/
                                    -- V2_00_0_17__SIACG_DLL.sql
/*================================================================================================*/


ALTER TABLE acgsm001.acgtb009_garantia_contrato DROP CONSTRAINT ckc_ic_forma_garantia_acgtb009;

ALTER TABLE acgsm001.acgtb009_garantia_contrato ADD CONSTRAINT ckc_ic_forma_garantia_acgtb009 CHECK (ic_forma_garantia1 IS NULL OR (ic_forma_garantia1 = ANY (ARRAY['01'::bpchar, '02'::bpchar, '03'::bpchar, '04'::bpchar])))