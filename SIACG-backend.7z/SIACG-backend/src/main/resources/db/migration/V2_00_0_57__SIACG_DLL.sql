/*==============================================================*/
/* Table: acgsm001.acgsq094_gestao_tipo_despesa                 */
/*==============================================================*/


create sequence acgsm001.acgsq094_gestao_tipo_despesa;


/*==============================================================*/
/* Table: acgsm001.acgtb094_gestao_tipo_despesa                 */
/*==============================================================*/
create table acgsm001.acgtb094_gestao_tipo_despesa (
   nu_tipo_despesa      INT                  not null default nextval('acgsq094_gestao_tipo_despesa'),
   co_tipo_despesa      INT                  null,
    no_tipo_despesa     CHAR(50)             not null,
   nu_tipo_fornecedor   INT                  null,
   co_evento_despesa    CHAR(10)             not null,
 
   constraint PK_ACGTB094_GESTAO_TIPO_DESPES primary key (nu_tipo_despesa)
);

comment on table acgsm001.acgtb094_gestao_tipo_despesa is
'Tabela de dominio de tipo de despesa';

comment on column acgsm001.acgtb094_gestao_tipo_despesa.nu_tipo_despesa is
'Identificador unico do tipo de despesa';

comment on column acgsm001.acgtb094_gestao_tipo_despesa.nu_tipo_fornecedor is
'Identificador unico do tipo de fornecedor FK';

comment on column acgsm001.acgtb094_gestao_tipo_despesa.co_tipo_despesa is
'codigo de representacao do tipo de despesa.';

comment on column acgsm001.acgtb094_gestao_tipo_despesa.no_tipo_despesa is
'Nome descritivo tipo de despesa. ';

comment on column acgsm001.acgtb094_gestao_tipo_despesa.co_evento_despesa is
'Codigo de evento referente a despesa.';

alter table acgsm001.acgtb094_gestao_tipo_despesa
   add constraint FK_ACGTB094_REFERENCE_ACGTB091 foreign key (nu_tipo_fornecedor)
      references acgsm001.acgtb091_gestao_tipo_fornecedor (nu_tipo_fornecedor)
      on delete restrict on update restrict;

	  	  
/*==============================================================*/
/* Script Reverse: acgsm001.acgsq094_gestao_tipo_despesa        */
/*==============================================================*/

--drop table acgsm001.acgtb094_gestao_tipo_despesa;

--drop sequence acgsm001.acgsq094_gestao_tipo_despesa;
      
      