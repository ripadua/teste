/*==============================================================*/
/* Table: acgtb077_maquina_equipamento                          */
/*==============================================================*/

ALTER TABLE acgsm001.acgtb077_maquina_equipamento ADD COLUMN ic_tipo_co_bem smallint;
ALTER TABLE acgsm001.acgtb077_maquina_equipamento ADD COLUMN co_bem VARCHAR(20);

COMMENT ON COLUMN acgsm001.acgtb077_maquina_equipamento.ic_tipo_co_bem IS 
'Define o tipo do código do bem:

1 - Número de Série;
2 - Número do Chassi.';


COMMENT ON COLUMN acgsm001.acgtb077_maquina_equipamento.co_bem IS 'Define o código do bem, podendo ser um chassi ou número de série';


--ALTER TABLE acgsm001.acgtb077_maquina_equipamento DROP COLUMN ic_tipo_co_bem;
--ALTER TABLE acgsm001.acgtb077_maquina_equipamento DROP COLUMN co_bem;