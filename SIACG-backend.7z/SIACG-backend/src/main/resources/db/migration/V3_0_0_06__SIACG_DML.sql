/*==============================================================*/
/* V3_0_0_06__SIACG_DML.sql                                     */
/*==============================================================*/
/*==============================================================*/
/* Insert acgtb113_proprietario_imovel                          */
/*==============================================================*/	 
-- Descomentar os scripts e executa los em produção, somente após a migração dos dados em produção. 

-- DELETE FROM acgsm001.acgtb113_proprietario_imovel;

-- INSERT INTO acgsm001.acgtb113_proprietario_imovel(nu_imovel, nu_pessoa)
-- SELECT DISTINCT i.nu_imovel, i.nu_pessoa
-- FROM acgsm001.acgtb081_imovel i 
-- WHERE i.nu_pessoa is not null
-- ORDER BY i.nu_imovel asc;

