/*==============================================================*/
/* Sequence: acgsq091_gestao_tipo_fornecedor                    */
/*==============================================================*/

create sequence acgsm001.acgsq091_gestao_tipo_fornecedor;



/*==============================================================*/
/* Table: acgtb091_gestao_tipo_fornecedor                       */
/*==============================================================*/
create table acgsm001.acgtb091_gestao_tipo_fornecedor (
   nu_tipo_fornecedor   INT                  not null default nextval('acgsm001.acgsq091_gestao_tipo_fornecedor'),
   no_tipo_fornecedor   CHAR(40)             null,
   de_tipo_fornecedor   CHAR(100)            null,
   dt_criacao           DATE                 null,
   constraint PK_ACGTB091_GESTAO_TIPO_FORNEC primary key (nu_tipo_fornecedor)
);

comment on table acgsm001.acgtb091_gestao_tipo_fornecedor is
'Tabela de dominio de tipo fornecedor';

comment on column acgsm001.acgtb091_gestao_tipo_fornecedor.nu_tipo_fornecedor is
'Identificador unico do tipo de fornecedor';

comment on column acgsm001.acgtb091_gestao_tipo_fornecedor.no_tipo_fornecedor is
'Nome do tipo de fornecedor';

comment on column acgsm001.acgtb091_gestao_tipo_fornecedor.de_tipo_fornecedor is
'Descrição do tipo fornecedor';

comment on column acgsm001.acgtb091_gestao_tipo_fornecedor.dt_criacao is
'Data criação e inclusão no sistema';


/*==============================================================*/
/* Script Reverse    acgsm001.acgtb091_gestao_tipo_fornecedor            */
/*==============================================================*/

	--drop sequence acgsq091_gestao_tipo_fornecedor;
	--drop table acgtb091_gestao_tipo_fornecedor;

