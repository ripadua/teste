/*============================================================*/
/*           SCRIPT V2_09_0_05__SIACG_DML				      */
/*============================================================*/

/*============================================================*/
/* Insere em acgsm001.acgtb081_imovel_bkp2                     */
/*============================================================*/
INSERT INTO acgsm001.acgtb081_imovel_bkp2 (nu_imovel, nu_matricula, co_cnm)
SELECT nu_imovel, nu_matricula, co_cnm FROM acgsm001.acgtb081_imovel ORDER BY 1;

/*============================================================*/
/* Recalcula o co_cnm                                         */
/*============================================================*/
UPDATE acgsm001.acgtb081_imovel 
SET co_cnm = (SELECT acgsm001.acgfn001_retorna_cnm_imovel_por_matricula(nu_imovel))
WHERE nu_imovel in (
			SELECT nu_imovel
			FROM acgsm001.acgtb081_imovel
			WHERE (co_livro_serventia IS NOT NULL AND co_livro_serventia != '')
		);

/*============================================================*/
/* Revert co_livro_serventia e co_cnm                         */
/*============================================================*/
-- UPDATE acgsm001.acgtb081_imovel i
-- SET 
-- co_cnm = bkp.co_cnm
-- FROM acgsm001.acgtb081_imovel_bkp2 bkp 
-- WHERE i.nu_imovel = bkp.nu_imovel;
		