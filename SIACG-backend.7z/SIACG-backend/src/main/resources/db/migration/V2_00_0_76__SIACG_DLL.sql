/*==============================================================*/
/*           SCRIPT V2_00_0_76__SIACG_DLL						*/
/*==============================================================*/

-- Criação de novas colunas
ALTER TABLE acgsm001.acgtb023_aplicacao_financeira ADD COLUMN vr_bruto numeric(20,10);
ALTER TABLE acgsm001.acgtb023_aplicacao_financeira ADD COLUMN ic_origem integer default 1;
ALTER TABLE acgsm001.acgtb023_aplicacao_financeira ALTER COLUMN ic_origem SET NOT NULL;
COMMENT ON COLUMN acgsm001.acgtb023_aplicacao_financeira.ic_origem IS '1 - ETL, 2 - API';

      
/*########################### SCRIPT ROLLBACK ##############################*/      

-- ALTER TABLE acgsm001.acgtb023_aplicacao_financeira DROP COLUMN vr_bruto;
-- ALTER TABLE acgsm001.acgtb023_aplicacao_financeira DROP COLUMN ic_origem;