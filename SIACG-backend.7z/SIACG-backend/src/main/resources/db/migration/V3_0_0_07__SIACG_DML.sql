/*============================================================*/
/*           SCRIPT V3_0_0_07__SIACG_DDL		              */
/*============================================================*/

-- Cria a view de produtos do SIICO
CREATE OR REPLACE VIEW ACG.acgvw009_produto AS 
 SELECT DISTINCT sa.nu_segmento_atndo,
    sa.no_segmento_atndo,
    o.nu_operacao,
    o.no_operacao,
    p.nu_produto,
    p.no_produto,
    p.no_comercial_prdto,
    p.co_ultima_situacao,
    s.nu_natural_sistema,
    s.sg_sistema,
    u.nu_unidade,
    u.nu_natural,
    u.sg_unidade,
    u.no_unidade
   FROM ico.icotbo10_produto p
     JOIN ico.icotbo12_atndoprdo sap ON sap.nu_produto_o10 = p.nu_produto
     JOIN ico.icotbo11_sgmnoatnd sa ON sa.nu_segmento_atndo = sap.nu_sgmno_atndo_o11
     JOIN ico.icotbo23_operacao o ON o.nu_operacao = p.nu_operacao_o23
     JOIN ico.icotbo25_siscntprd scp ON scp.nu_produto_o10 = p.nu_produto
     JOIN ico.icotbs03_sistema s ON scp.nu_sistema_s03 = s.nu_natural_sistema
     JOIN ico.icotbo07_gestao g ON g.nu_produto_o10 = p.nu_produto
     JOIN ico.icotbu24_unidade u ON g.nu_unidade_u24 = u.nu_unidade AND g.nu_natural_u24 = u.nu_natural
  WHERE p.co_ultima_situacao = 'AT' AND g.dt_fim_gestao IS NULL AND sap.dt_fim_atndo_prdto IS NULL;


/*==============================================================*/
/* Reverter                                                     */
/*==============================================================*/
-- DROP VIEW ACG.acgvw009_produto;