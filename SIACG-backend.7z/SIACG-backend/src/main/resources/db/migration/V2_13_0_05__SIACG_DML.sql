/*============================================================*/
/*           SCRIPT V2_13_0_05__SIACG_DML		              */
/*============================================================*/

--RETORNA PARA 58 POIS O SID00 IMPLEMENTOU O TIPO 58
UPDATE acgsm001.acgtb017_propriedade SET no_valor_propriedade='58' WHERE no_propriedade='bloqueio.tipo';