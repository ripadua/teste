/*==============================================================*/
/* Table: acgtb097_fonte_expressao                              */
/*==============================================================*/

DROP sequence IF EXISTS acgsm001.sq097_fonte_expressao CASCADE;

DROP table IF EXISTS acgsm001.acgtb097_fonte_expressao CASCADE;  

create sequence acgsm001.sq097_fonte_expressao;

create table acgsm001.acgtb097_fonte_expressao (
   nu_fonte_expressao   integer not null default nextval('acgsm001.sq097_fonte_expressao'::regclass),
   ic_tipo_expressao    integer                 not null constraint ckc_acgtb097_01 check (ic_tipo_expressao in (1,2,3,4,5,6)),
   no_fonte_expressao   character varying(100)  not null,
   de_expressao         character varying(250)  not null,
   de_consulta_expressao TEXT                 null,
   de_representacao     character varying(20),
   constraint pk_acgtb097_fonte_expressao primary key (nu_fonte_expressao)
);

comment on table acgsm001.acgtb097_fonte_expressao is
'Tabela que irá armazenar as fontes de expressão, de acordo com o tipo de expressão informado e que irá compor as fórmulas.';
comment on column acgsm001.acgtb097_fonte_expressao.nu_fonte_expressao is
'Identificador da fonte da expressão, equivalente ao tipo informado.
Sendo do tipo Operador ou Condicionante, os valores da fonte de expressão serão pré definidos;
Sendo do tipo Dado, haverá um cadastro para alimentar a tabela;
Sendo do tipo Fórmula ou Função, os valores serão adicionados automaticamente ao ser criados uma fórmula ou função.';
comment on column acgsm001.acgtb097_fonte_expressao.ic_tipo_expressao is
'Indentificador que representa o tipo de expressão, podendo ser:
1 - Dado
2 - Valor
3 - Operador
4 - Condicionante
5 - Função
6 - Fórmula';
comment on column acgsm001.acgtb097_fonte_expressao.no_fonte_expressao is
'Nome amigável que identifica a fonte da expressão.';
comment on column acgsm001.acgtb097_fonte_expressao.de_expressao is
'Campo que irá armazenar o detalhe da fonte da expressão (descritivo).';
comment on column acgsm001.acgtb097_fonte_expressao.de_consulta_expressao is
'Campo que irá armazenar, quando necessário, a consulta SQL (template) associada a fonte de expressão.';

	  
/*==============================================================*/
/* Table: acgtb098_parametro_funcao                             */
/*==============================================================*/

DROP sequence IF EXISTS acgsm001.sq098_parametro_funcao CASCADE;

DROP table IF EXISTS acgsm001.acgtb098_parametro_funcao CASCADE;

create sequence acgsm001.sq098_parametro_funcao;

create table acgsm001.acgtb098_parametro_funcao (
   nu_parametro_funcao  integer not null default nextval('acgsm001.sq098_parametro_funcao'::regclass),
   nu_fonte_expressao   integer                not null,
   no_parametro_funcao  character varying(20)  not null,
   ic_obrigatorio       boolean                not null default true,
   nu_ordem             integer                not null,
   constraint pk_acgtb098_parametro_funcao primary key (nu_parametro_funcao)
);

comment on table acgsm001.acgtb098_parametro_funcao is
'Tabela que identifica os parâmetros de uma função, utilizada em uma fórmula.';
comment on column acgsm001.acgtb098_parametro_funcao.nu_parametro_funcao is
'Representa o identificador do parâmetro da função.';
comment on column acgsm001.acgtb098_parametro_funcao.nu_fonte_expressao is
'Identificador da fonte da expressão, equivalente ao tipo informado.
Sendo do tipo Operador ou Condicionante, os valores da fonte de expressão serão pré definidos;
Sendo do tipo Dado, haverá um cadastro para alimentar a tabela;
Sendo do tipo Fórmula ou Função, os valores serão adicionados automaticamente ao ser criados uma fórmula ou função.';
comment on column acgsm001.acgtb098_parametro_funcao.no_parametro_funcao is
'Representa o nome amigável do parâmetro da funçao.';
comment on column acgsm001.acgtb098_parametro_funcao.ic_obrigatorio is
'Define se o parâmetro é obrigatório.';
comment on column acgsm001.acgtb098_parametro_funcao.nu_ordem is
'Representa a ordem do parâmetro na função.';

alter table acgsm001.acgtb098_parametro_funcao add constraint fk_acgtb098_acgtb097 foreign key (nu_fonte_expressao)
      references acgsm001.acgtb097_fonte_expressao (nu_fonte_expressao) on delete restrict on update restrict;

	  
/*==============================================================*/
/* Table: acgtb101_formula                                      */
/*==============================================================*/

DROP sequence IF EXISTS acgsm001.sq101_formula CASCADE;

DROP table IF EXISTS acgsm001.acgtb101_formula CASCADE;

create sequence acgsm001.sq101_formula;

create table acgsm001.acgtb101_formula (
   nu_formula           integer not null default nextval('acgsm001.sq101_formula'::regclass),
   no_formula           character varying(150) not null,
   ic_tipo_vinculo      integer                not null constraint ckc_acgtb101_01 check (ic_tipo_vinculo in (1)),
   constraint pk_acgtb101_formula primary key (nu_formula)
);

comment on table acgsm001.acgtb101_formula is
'Tabela que identifica as fórmulas criadas para uso dos cálculos, de acordo com o tipo do vínculo.';
comment on column acgsm001.acgtb101_formula.nu_formula is
'Identificador das fórmulas criadas para automatização dos cálculos utilizados no sistema.';
comment on column acgsm001.acgtb101_formula.no_formula is
'Descreve o nome da fórmula criada pelo usuário.';
comment on column acgsm001.acgtb101_formula.ic_tipo_vinculo is
'Especifica o tipo de vínculo referente a área do sistema que irá utilizar a fórmula:

1 - HABITACIONAL

Este campo será alimentado automaticamente pelo pela área do usuário autorizado a cadastrar a fórmula. Ex: usuário lotado na GEHAB irá criar fórmulas somente do tipo 1.';

	  
/*==============================================================*/
/* Table: acgtb100_formula_item                                 */
/*==============================================================*/
DROP sequence IF EXISTS acgsm001.sq100_formula_item CASCADE;

DROP table IF EXISTS acgsm001.acgtb100_formula_item CASCADE;

create sequence acgsm001.sq100_formula_item;

create table acgsm001.acgtb100_formula_item (
   nu_formula_item      integer not null default nextval('acgsm001.sq100_formula_item'::regclass),
   nu_formula           integer                 not null,
   nu_fonte_expressao   integer                 not null,
   de_valor_formula     character varying(50),
   nu_ordem             integer                 not null,
   constraint pk_acgtb100_formula_item primary key (nu_formula_item)
);

comment on table acgsm001.acgtb100_formula_item is
'Define o conjunto de expressões que irão compor a fórmula.';
comment on column acgsm001.acgtb100_formula_item.nu_formula_item is
'Identificador que representa o item da fórmula associado a uma expressão de cálculo.';
comment on column acgsm001.acgtb100_formula_item.nu_formula is
'Identificador das fórmulas criadas para automatização dos cálculos utilizados no sistema.';
comment on column acgsm001.acgtb100_formula_item.nu_fonte_expressao is
'Identificador da fonte da expressão, equivalente ao tipo informado.
Sendo do tipo Operador ou Condicionante, os valores da fonte de expressão serão pré definidos;
Sendo do tipo Dado, haverá um cadastro para alimentar a tabela;
Sendo do tipo Fórmula ou Função, os valores serão adicionados automaticamente ao ser criados uma fórmula ou função.';
comment on column acgsm001.acgtb100_formula_item.de_valor_formula is
'Representa, quando pertinente, o conteúdo inserido na expressão do tipo "Valor".';
comment on column acgsm001.acgtb100_formula_item.nu_ordem is
'Representa a ordem da expressão dentro da fórmula.';

alter table acgsm001.acgtb100_formula_item add constraint fk_acgtb100_acgtb101 foreign key (nu_formula)
      references acgsm001.acgtb101_formula (nu_formula) on delete restrict on update restrict;

alter table acgsm001.acgtb100_formula_item add constraint fk_acgtb100_acgtb097 foreign key (nu_fonte_expressao)
      references acgsm001.acgtb097_fonte_expressao (nu_fonte_expressao) on delete restrict on update restrict;

	  
/*==============================================================*/
/* Table: acgtb99_parametro_frmla_item                          */
/*==============================================================*/
DROP sequence IF EXISTS acgsm001.sq099_parametro_frmla_item CASCADE;

DROP table IF EXISTS acgsm001.acgtb099_parametro_frmla_item CASCADE;

create sequence acgsm001.sq099_parametro_frmla_item;
      
create table acgsm001.acgtb099_parametro_frmla_item (
   nu_parametro_formula_item integer not null default nextval('acgsm001.sq099_parametro_frmla_item'::regclass),
   nu_formula_item      integer                 not null,
   nu_parametro_funcao  integer                 not null,
   de_valor_parametro   character varying(50)   not null,
   constraint pk_acgtb99_parametro_frmla_it primary key (nu_parametro_formula_item)
);

comment on table acgsm001.acgtb099_parametro_frmla_item is
'Armazena, quando necessário, o conteúdo inserido no parâmetro, cuja expressão seja do tipo "Valor".';
comment on column acgsm001.acgtb099_parametro_frmla_item.nu_parametro_formula_item is
'Representa o identificador da expressão, do tipo "Valor", associado à uma função.';
comment on column acgsm001.acgtb099_parametro_frmla_item.nu_formula_item is
'Identificador que representa o item da fórmula associado a uma expressão de cálculo.';
comment on column acgsm001.acgtb099_parametro_frmla_item.nu_parametro_funcao is
'Representa o nome amigável do parâmetro da funçao.';
comment on column acgsm001.acgtb099_parametro_frmla_item.de_valor_parametro is
'Representa, quando pertinente, o conteúdo inserido na expressão do tipo "Valor" associado ao parâmetro da fórmula.';

alter table acgsm001.acgtb099_parametro_frmla_item add constraint fk_acgtb099_acgtb098 foreign key (nu_parametro_funcao)
      references acgsm001.acgtb098_parametro_funcao (nu_parametro_funcao) on delete restrict on update restrict;

alter table acgsm001.acgtb099_parametro_frmla_item add constraint fk_acgtb099_acgtb100 foreign key (nu_formula_item)
      references acgsm001.acgtb100_formula_item (nu_formula_item) on delete restrict on update restrict;

/*==============================================================*/
/* Table: acgtb102_vinculo_calculo                              */
/*==============================================================*/
DROP sequence IF EXISTS acgsm001.sq102_vinculo_calculo CASCADE;

DROP table IF EXISTS acgsm001.acgtb102_vinculo_calculo CASCADE;

create sequence acgsm001.sq102_vinculo_calculo;

create table acgsm001.acgtb102_vinculo_calculo (
   nu_vinculo_calculo   integer not null default nextval('acgsm001.sq102_vinculo_calculo'::regclass),
   nu_unidade_habitacional integer           null,
   nu_empreendimento       integer            null,
   nu_tipologia_habitacional integer         null,
   nu_formula           integer                 not null,
   no_vinculo_calculo   character varying(150)         not null,
   dt_inicio_vigencia   DATE                 not null,
   dt_fim_vigencia      DATE                 null,
   constraint pk_acgtb102_vinculo_calculo primary key (nu_vinculo_calculo)
);

comment on table acgsm001.acgtb102_vinculo_calculo is
'Tabela que representa o vínculo entre as fórmulas criadas e as entidades negociais da área do usuário.';
comment on column acgsm001.acgtb102_vinculo_calculo.nu_vinculo_calculo is
'Responsável por identificar o vínculo de cálculo associado a uma área negocial.';
comment on column acgsm001.acgtb102_vinculo_calculo.nu_unidade_habitacional is
'Identificador unico da unidade habitacional';
comment on column acgsm001.acgtb102_vinculo_calculo.nu_empreendimento is
'Representa o identificador único gerado pelo sistema para cada Empreendimento Habitaciona.';
comment on column acgsm001.acgtb102_vinculo_calculo.nu_tipologia_habitacional is
'Identificador unico da unidade habitacional';
comment on column acgsm001.acgtb102_vinculo_calculo.nu_formula is
'Identificador das fórmulas criadas para automatização dos cálculos utilizados no sistema.';
comment on column acgsm001.acgtb102_vinculo_calculo.no_vinculo_calculo is
'Descreve o nome do vínculo de cálculo associado à uma área negocial.';
comment on column acgsm001.acgtb102_vinculo_calculo.dt_inicio_vigencia is
'Define a vigência incial do vínculo de cálculo.';
comment on column acgsm001.acgtb102_vinculo_calculo.dt_fim_vigencia is
'Define a vigência final do vínculo de cálculo.';


alter table acgsm001.acgtb102_vinculo_calculo add constraint fk_acgtb102_acgtb048 foreign key (nu_tipologia_habitacional)
      references acgsm001.acgtb048_tipologia_habitacional (nu_tipologia_habitacional) on delete restrict on update restrict;

alter table acgsm001.acgtb102_vinculo_calculo add constraint fk_acgtb102_acgtb049 foreign key (nu_unidade_habitacional)
      references acgsm001.acgtb049_unidade_habitacional (nu_unidade_habitacional) on delete restrict on update restrict;

alter table acgsm001.acgtb102_vinculo_calculo add constraint fk_acgtb102_acgtb050 foreign key (nu_empreendimento)
      references acgsm001.acgtb050_empreendimento (nu_empreendimento) on delete restrict on update restrict;

alter table acgsm001.acgtb102_vinculo_calculo add constraint fk_acgtb102_acgtb101 foreign key (nu_formula)
      references acgsm001.acgtb101_formula (nu_formula) on delete restrict on update restrict;

	  
	  

/*==============================================================*/
/* Reverse Table: acgtb102_vinculo_calculo                      */
/*==============================================================*/
--drop table acgsm001.acgtb102_vinculo_calculo;
--drop sequence acgsm001.sq102_vinculo_calculo;

/*==============================================================*/
/* Reverse Table: acgtb99_parametro_frmla_item                  */
/*==============================================================*/
--drop table acgsm001.acgtb099_parametro_frmla_item;
--drop sequence acgsm001.sq099_parametro_frmla_item;
      
/*==============================================================*/
/* References Table: acgtb100_formula_item                      */
/*==============================================================*/
--drop table acgsm001.acgtb100_formula_item;
--drop sequence acgsm001.sq100_formula_item;

/*==============================================================*/
/* Reverse Table: acgtb101_formula                              */
/*==============================================================*/
--drop table acgsm001.acgtb101_formula;
--drop sequence acgsm001.sq101_formula;

/*==============================================================*/
/* Reverse Table: acgtb098_parametro_funcao                     */
/*==============================================================*/
--drop table acgsm001.acgtb098_parametro_funcao;
--drop sequence acgsm001.sq098_parametro_funcao;

/*==============================================================*/
/* Reverse Table: acgtb097_fonte_expressao                      */
/*==============================================================*/
--drop table acgsm001.acgtb097_fonte_expressao;
--drop sequence acgsm001.sq097_fonte_expressao;