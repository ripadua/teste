﻿-- ********************************************************************
--  ALTERAÇÕES PARA ROTINA PENTAHO SIACG_IMPORTA_ARQUIVOS
-- ********************************************************************

CREATE TABLE IF NOT EXISTS acgsm002.acgtbs02_cartao_fluxo AS SELECT * FROM acgsm001.acgtbi01_mov_cartoes limit 1;
TRUNCATE TABLE acgsm002.acgtbs02_cartao_fluxo;
ALTER TABLE acgsm001.acgtbi01_mov_cartoes RENAME TO acgtbi01_mov_cartoes_bkp;
ALTER TABLE acgsm002.acgtbs02_cartao_fluxo ADD COLUMN co_identificador_cartao varchar;

CREATE TABLE IF NOT EXISTS acgsm002.acgtbs03_cheque AS SELECT * FROM acgsm001.acgtbi02_mov_cheque;
ALTER TABLE acgsm001.acgtbi02_mov_cheque RENAME TO acgtbi02_mov_cheque_bkp;


create table IF NOT EXISTS acgsm002.acgtbs04_aplicacao (
   tp_registro          integer              null,
   co_produto           varchar(4)           null,
   co_cpf_cnpj          varchar(14)          null,
   no_cliente           varchar(32)          null,
   de_certificado       varchar(16)          null,
   co_agencia           varchar(4)           null,
   co_operacao          varchar(4)           null,
   co_contrato          varchar(9)           null,
   co_conta             varchar(20)          null,
   co_contrato_dv       varchar(1)           null,
   vr_saldo             numeric(15,2)        null,
   ic_situacao          varchar(2)           null,
   vr_bloqueado         numeric(15,2)        null,
   ic_bloqueio          varchar(20)          null,
   co_modalidade        varchar(4)           null,
   no_modalidade        varchar(55)          null,
   dt_aplicacao         date                 null,
   de_descarte          varchar(10)          null,
   vr_base              numeric(15,2)        null,
   vr_atualizado        numeric(15,2)        null,
   dt_movimento         date                 null,
   de_nota              varchar(14)          null,
   dt_vencimento        date                 null,
   vr_liquido           numeric(15,2)        null,
   de_bloqueio          varchar(20)          null,
   de_origem_bloqueio   varchar(10)          null,
   ts_processamento     timestamp            null,
   ts_grupo_processamento timestamp            null,
   sg_sistema_origem    varchar(10)          null,
   de_aplicacao_financeira text                 null,
   qt_registro_arquivo  integer              null,
   no_arquivo           text                 null,
   vr_comprometido      numeric(15,2)        null
);

create table IF NOT EXISTS acgsm002.acgtbs05_atualiza_saldo (
   tp_registro          integer              null,
   co_produto           varchar(4)           null,
   co_cpf_cnpj          varchar(14)          null,
   no_cliente           varchar(32)          null,
   co_agencia           varchar(4)           null,
   co_operacao          varchar(4)           null,
   co_contrato          varchar(20)          null,
   co_conta             varchar(20)          null,
   co_contrato_dv       varchar(1)           null,
   vr_contrato          double precision     null,
   ic_situacao          varchar(2)           null,
   vr_saldo_devedor     double precision     null,
   dt_concessao         date                 null,
   ts_processamento     timestamp            null,
   ts_grupo_processamento timestamp          null,
   sg_sistema_origem    varchar(10)          null,
   no_arquivo           text                 null,
   dt_ultimo_saldo      date                 null,
   vr_comprometido      double precision     null,
   de_avalop            varchar(50)          null,
   dt_movimento         date                 null
);


-- column default sequence nextval
ALTER TABLE acgsm001.acgtb003_pessoa ALTER COLUMN nu_pessoa SET DEFAULT NEXTVAL('acgsm001.sq003_pessoa');
ALTER TABLE acgsm001.acgtb023_aplicacao_financeira ALTER COLUMN nu_aplicacao_financeira SET DEFAULT NEXTVAL('acgsm001.sq023_aplicacao_finaceira');
ALTER TABLE acgsm001.acgtb005_sacado ALTER COLUMN nu_sacado SET DEFAULT NEXTVAL('acgsm001.sq005_sacado');
ALTER TABLE acgsm001.acgtb004_cedente ALTER COLUMN nu_cedente SET DEFAULT NEXTVAL('acgsm001.sq004_cedente');
ALTER TABLE acgsm001.acgtb027_custodia_cheque ALTER COLUMN nu_custodia_cheque SET DEFAULT NEXTVAL('acgsm001.sq027_custodia_cheque');
ALTER TABLE acgsm001.acgtb028_cheque ALTER COLUMN nu_cheque SET DEFAULT NEXTVAL('acgsm001.sq028_cheque');
ALTER TABLE acgsm001.acgtb007_conta_contrato ALTER COLUMN nu_conta_contrato SET DEFAULT NEXTVAL('acgsm001.sq007_conta_contrato');
      
-- tabelas stage area
ALTER TABLE acgsm002.acgtbs01_contrato ADD COLUMN ts_grupo_processamento timestamp without time zone;
ALTER TABLE acgsm002.acgtbs08_duplicata ADD COLUMN ts_grupo_processamento timestamp without time zone;
ALTER TABLE acgsm002.acgtbs02_cartao_fluxo ADD COLUMN ts_grupo_processamento timestamp without time zone;
ALTER TABLE acgsm002.acgtbs02_cartao_fluxo ADD COLUMN ts_processamento timestamp without time zone;
ALTER TABLE acgsm002.acgtbs02_cartao_fluxo ADD COLUMN de_grupo_arquivo varchar(20);
ALTER TABLE acgsm002.acgtbs02_cartao_fluxo ADD COLUMN co_unico_liquidacao varchar;

CREATE INDEX ix_acgtbs02_01 ON acgsm002.acgtbs02_cartao_fluxo(co_unico_liquidacao);


CREATE table IF NOT EXISTS acgsm002.acgtbs06_cartao_fluxo_tmpro AS SELECT * FROM acgsm002.acgtbs02_cartao_fluxo limit 1;
TRUNCATE TABLE acgsm002.acgtbs06_cartao_fluxo_tmpro;


CREATE table IF NOT EXISTS acgsm002.acgtbs07_cartao_estoque AS SELECT * FROM acgsm002.acgtbs02_cartao_fluxo limit 1;
TRUNCATE TABLE acgsm002.acgtbs07_cartao_estoque; 


ALTER TABLE acgsm002.acgtbs03_cheque ADD COLUMN ts_processamento timestamp without time zone;
ALTER TABLE acgsm002.acgtbs03_cheque ADD COLUMN ts_grupo_processamento timestamp without time zone;
ALTER TABLE acgsm002.acgtbs03_cheque ADD COLUMN no_arquivo text;





CREATE UNIQUE INDEX ix_acgtbi02_01
  ON acgsm002.acgtbs03_cheque
  USING btree
  (co_cheque COLLATE pg_catalog."default");


CREATE INDEX ix_acgtbi02_02
  ON acgsm002.acgtbs03_cheque
  USING btree
  (nu_agencia COLLATE pg_catalog."default", nu_operacao COLLATE pg_catalog."default", nu_conta COLLATE pg_catalog."default", nu_dv_conta COLLATE pg_catalog."default");



CREATE INDEX ix_acgtbi02_03
  ON acgsm002.acgtbs03_cheque
  USING btree
  (co_cnpj COLLATE pg_catalog."default");
  
  
  
COMMENT ON COLUMN acgsm002.acgtbs02_cartao_fluxo.nu_agencia IS 'Número da agencia';
COMMENT ON COLUMN acgsm002.acgtbs02_cartao_fluxo.nu_operacao IS 'Número da operação';
COMMENT ON COLUMN acgsm002.acgtbs02_cartao_fluxo.nu_conta IS 'Número da conta. Importado do ITSM';
COMMENT ON COLUMN acgsm002.acgtbs02_cartao_fluxo.nu_dv_conta IS 'Número do dígito verificador da conta corrente';
COMMENT ON COLUMN acgsm002.acgtbs02_cartao_fluxo.vr_saldo IS 'Valor do crédito';
COMMENT ON COLUMN acgsm002.acgtbs02_cartao_fluxo.ic_origem IS 'Define qual arquivo de interface que originou este movimento:
1 - CIELO AGENDA A VISTA
2 - CIELO AGENDA PARCELADO
3 - CIELO FLUXO
4 - REDECARD AGENDA
5 - REDECARD FLUXO.';
COMMENT ON COLUMN acgsm002.acgtbs02_cartao_fluxo.nu_bandeira_cartao IS 'Identifica qual a bandeira do movimento:
Ex: Visa, Mastercard, etc.
Essas bandeiras estão relacionadas com as bandeiras da tabela acgtb069_bandeira_cartao';
COMMENT ON COLUMN acgsm002.acgtbs02_cartao_fluxo.no_arquivo IS 'Identifica qual é o arquivo de origem dos dados do cartão. Essa coluna será usada para agrupar os 
dados da stage área por arquivos e permitir armazenar na tabela de log de importação as quantidades de cada arquivo.';
COMMENT ON COLUMN acgsm002.acgtbs02_cartao_fluxo.co_cnpj_credenciador IS 'Armazena o cnpj do credenciador para descartar os registros que não estejam relacionados com a tabela acgtb072_credenciador,
via cnpj';



COMMENT ON TABLE acgsm002.acgtbs03_cheque
  IS 'Tabela que realizada o armazenamento das informações de movimento de cheques. Essas informações são então consolidadas e utilizadas na geração das análises.';
COMMENT ON COLUMN acgsm002.acgtbs03_cheque.vr_cheque IS 'Valor do crédito de cartões realizado na conta em garantia.';
COMMENT ON COLUMN acgsm002.acgtbs03_cheque.nu_agencia IS 'Número da agencia de vinculação da garantia de cartão.';
COMMENT ON COLUMN acgsm002.acgtbs03_cheque.nu_operacao IS 'Número da operação da conta de vinculação da garantia de cartão.';
COMMENT ON COLUMN acgsm002.acgtbs03_cheque.nu_conta IS 'Número da conta de vinculação da garantia de cartão.';
COMMENT ON COLUMN acgsm002.acgtbs03_cheque.nu_dv_conta IS 'Número do dígito verificador da conta corrente.';
COMMENT ON COLUMN acgsm002.acgtbs03_cheque.dt_referencia IS 'Data de referência das informações.';




COMMENT ON COLUMN acgsm002.acgtbs07_cartao_estoque.nu_agencia IS 'Número da agencia';
COMMENT ON COLUMN acgsm002.acgtbs07_cartao_estoque.nu_operacao IS 'Número da operação';
COMMENT ON COLUMN acgsm002.acgtbs07_cartao_estoque.nu_conta IS 'Número da conta. Importado do ITSM';
COMMENT ON COLUMN acgsm002.acgtbs07_cartao_estoque.nu_dv_conta IS 'Número do dígito verificador da conta corrente';
COMMENT ON COLUMN acgsm002.acgtbs07_cartao_estoque.vr_saldo IS 'Valor do crédito';
COMMENT ON COLUMN acgsm002.acgtbs07_cartao_estoque.ic_origem IS 'Define qual arquivo de interface que originou este movimento:
1 - CIELO AGENDA A VISTA
2 - CIELO AGENDA PARCELADO
3 - CIELO FLUXO
4 - REDECARD AGENDA
5 - REDECARD FLUXO.';
COMMENT ON COLUMN acgsm002.acgtbs07_cartao_estoque.nu_bandeira_cartao IS 'Identifica qual a bandeira do movimento:
Ex: Visa, Mastercard, etc.
Essas bandeiras estão relacionadas com as bandeiras da tabela acgtb069_bandeira_cartao';
COMMENT ON COLUMN acgsm002.acgtbs07_cartao_estoque.no_arquivo IS 'Identifica qual é o arquivo de origem dos dados do cartão. Essa coluna será usada para agrupar os 
dados da stage área por arquivos e permitir armazenar na tabela de log de importação as quantidades de cada arquivo.';
COMMENT ON COLUMN acgsm002.acgtbs07_cartao_estoque.co_cnpj_credenciador IS 'Armazena o cnpj do credenciador para descartar os registros que não estejam relacionados com a tabela acgtb072_credenciador,
via cnpj';

-- ********************************************************************
-- FIM DAS ALTERAÇÕES PARA ROTINA PENTAHO SIACG_IMPORTA_ARQUIVOS
-- ********************************************************************
