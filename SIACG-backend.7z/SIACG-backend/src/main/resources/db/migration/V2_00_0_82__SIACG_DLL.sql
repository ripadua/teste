/*==============================================================*/
/* Table: acgtb098_execucao_imovel                              */
/*==============================================================*/
CREATE SEQUENCE acgsm001.sq104_execucacao_imovel
  INCREMENT 1
  MINVALUE 1
  MAXVALUE 9223372036854775807
  START 1
  CACHE 1;

create table acgsm001.acgtb104_execucao_imovel (
	nu_execucao_imovel       bigint                   not null default nextval('acgsm001.sq104_execucacao_imovel'::regclass),
	nu_imovel                integer                  not null,
	ic_execucao_conformidade character varying(3)     not null,
	ic_marcado               Boolean                  not null,

    CONSTRAINT PK_ACGTB104_EXECUCACAO_IMOVEL primary key (nu_execucao_imovel),
    
    CONSTRAINT ck_acgtb104_01 CHECK 
    (ic_execucao_conformidade = ANY (ARRAY['CFC'::bpchar, 'CIM'::bpchar, 'CGE'::bpchar, 'LAI'::bpchar, 'VAR'::bpchar, 'ITR'::bpchar, 'CIR'::bpchar,'CPD'::bpchar,'TDI'::bpchar])),
    
    CONSTRAINT fk_acgtb104_fk_acgtb081 FOREIGN KEY (nu_imovel)
      REFERENCES acgsm001.acgtb081_imovel (nu_imovel) MATCH SIMPLE
      ON UPDATE NO ACTION ON DELETE NO ACTION
);

comment on table acgsm001.acgtb104_execucao_imovel is
'Tabela que representa o vínculo entre o checklist de conformidade de execucao sobre o Imovel.';

comment on column acgsm001.acgtb104_execucao_imovel.nu_imovel is
'Identificador do imóvel.';

comment on column acgsm001.acgtb104_execucao_imovel.ic_execucao_conformidade is
'Tipo do valor de execucao de conformidade que foi Marcado para o Imovel
	CFC - "CONTRATO DE FINANCIAMENTO COMERCIAL (CCB)"), 
	CIM - "CERTIDÃO DO IMÓVEL(MATRÍCULA)"),
	CGE - "CERTIDÃO DE GARAGEM / ESCANINHO"),
	LAI - "LAUDO DE AVALIAÇÃO DO IMÓVEL"),
	VAR - "VERTIDÃO DE AFORAMENTO"),
	ITR - "ITR – IMPOSTO SOBRE A PROPRIEDADE TERRITORIAL RURAL"),
	CIR - "CCIR – CERTIFICADO DE CADASTRO RURAL"),
	CPD - "COMPROVANTE DE PAGAMENTO DE DESPESAS PARA CONSOLIDAÇÃO"),
	TDI - "TERMO DE DISPONIBILIZAÇÃO DE IMÓVEL PARA ALIENAÇÃO (MO29323)")';

comment on column acgsm001.acgtb104_execucao_imovel.ic_marcado is
'Identifica se foi Marcado para o Imovel';
	  
/*==============================================================*/
/* Reverse Table: acgtb104_execucao_imovel                      */
/*==============================================================*/
--drop table acgsm001.acgtb104_execucao_imovel;
--drop sequence acgsm001.sq104_execucacao_imovel;
