/*============================================================*/
/*           SCRIPT V3_01_0_01__SIACG_DDL		              */
/*============================================================*/

CREATE INDEX ix_acgtb035_01 ON acg.ACGTB035_PRE_ANALISE(nu_contrato)
      TABLESPACE ACGTSIX001;
 
CREATE INDEX ix_acgtb001_13 ON acg.ACGTB001_CONTRATO(nu_ultima_analise_contrato)
      TABLESPACE ACGTSIX001;
 
CREATE INDEX ix_acgtb001_14 ON acg.ACGTB001_CONTRATO(dt_contrato)
      TABLESPACE ACGTSIX001;
 
CREATE INDEX ix_acgtb106_01 ON acg.ACGTB106_BEM_CLIENTE(nu_pessoa)
      TABLESPACE ACGTSIX001;
     
CREATE INDEX ix_acgtb106_02 ON acg.ACGTB106_BEM_CLIENTE(nu_maquina_equipamento)
      TABLESPACE ACGTSIX001;
     
CREATE INDEX ix_acgtb106_03 ON acg.ACGTB106_BEM_CLIENTE(nu_imovel)
      TABLESPACE ACGTSIX001;
     
CREATE INDEX ix_acgtb106_04 ON acg.ACGTB106_BEM_CLIENTE(nu_veiculo)
      TABLESPACE ACGTSIX001;
     
CREATE INDEX ix_acgtb106_05 ON acg.ACGTB106_BEM_CLIENTE(nu_produto_agricola)
      TABLESPACE ACGTSIX001;
 
CREATE INDEX ix_acgtb107_01 ON acg.ACGTB107_CONTRATO_BEM_CLIENTE(nu_contrato)
      TABLESPACE ACGTSIX001;
     
CREATE INDEX ix_acgtb107_02 ON acg.ACGTB107_CONTRATO_BEM_CLIENTE(nu_bem_cliente)
      TABLESPACE ACGTSIX001;
      
CREATE INDEX IX_ACGTB108_01 ON ACG.ACGTB108_GARANTIA_BEM_CLIENTE (NU_GARANTIA_CONTRATO) 
       TABLESPACE ACGTSIX001;
       
CREATE INDEX IX_ACGTB028_01 ON ACG.ACGTB028_CHEQUE (NU_CUSTODIA_CHEQUE) 
       TABLESPACE ACGTSIX001;
       
CREATE INDEX IX_ACGTB027_01 ON ACG.ACGTB027_CUSTODIA_CHEQUE (nu_agencia, nu_conta, nu_operacao, nu_dv_conta) 
       TABLESPACE ACGTSIX001;
      
CREATE INDEX IX_ACGTB003_04 ON ACG.ACGTB003_PESSOA (nu_pessoa, nu_segmento) 
       TABLESPACE ACGTSIX001;
       
CREATE INDEX IX_ACGTB001_15 ON ACG.ACGTB001_CONTRATO (nu_pessoa, ic_parametrizado, ic_situacao) 
       TABLESPACE ACGTSIX001;

/*==============================================================*/
/* Reverter                                                     */
/*==============================================================*/
--DROP INDEX ACG.ix_acgtb035_01;
 
--DROP INDEX ACG.ix_acgtb001_13;
 
--DROP INDEX ACG.ix_acgtb001_14;
 
--DROP INDEX ACG.ix_acgtb106_01;
     
--DROP INDEX ACG.ix_acgtb106_02;
     
--DROP INDEX ACG.ix_acgtb106_03;
     
--DROP INDEX ACG.ix_acgtb106_04;
     
--DROP INDEX ACG.ix_acgtb106_05;
 
--DROP INDEX ACG.ix_acgtb107_01;
     
--DROP INDEX ACG.ix_acgtb107_02;
      
--DROP INDEX ACG.IX_ACGTB108_01;

--DROP INDEX ACG.IX_ACGTB028_01;
       
--DROP INDEX ACG.IX_ACGTB027_01;
      
--DROP INDEX ACG.IX_ACGTB003_04;
       
--DROP INDEX ACG.IX_ACGTB001_15;
