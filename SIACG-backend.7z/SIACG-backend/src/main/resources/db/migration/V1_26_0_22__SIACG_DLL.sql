drop table acgsm001.acgtb075_veiculo;

/*==============================================================*/
/* Table: acgtb075_veiculo                                      */
/*==============================================================*/
create table acgsm001.acgtb075_veiculo (
   nu_veiculo           bigint               not null,
   no_marca             VARCHAR(100)         not null,
   no_modelo            VARCHAR(100)         not null,
   aa_fabricacao        INT4                 not null,
   aa_modelo            INT4                 not null,
   ic_zero_km           VARCHAR(1)           not null,
   de_cor              VARCHAR(100)         not null,
   co_renavam           VARCHAR(30)          not null,
   co_chassi            VARCHAR(30)          not null,
   ic_tipo_chassi       VARCHAR(1)           not null,
   sg_uf_licenciamento  VARCHAR(2)           not null,
   sg_uf_veiculo        VARCHAR(2)           not null,
   co_placa             VARCHAR(7)           not null,
   ic_cpf_cnpj_vendedor VARCHAR(1)           not null,
   co_identificador_vendedor VARCHAR(14)     not null,
   ic_tipo_restricao    VARCHAR(1)           not null,
   ed_logradouro_origem VARCHAR(50)          not null,
   ed_numero_origem     VARCHAR(5)           not null,
   ed_complemento_origem VARCHAR(50)         not null,
   ed_bairro_origem     VARCHAR(50)          not null,
   co_municipio_origem  VARCHAR(5)           not null,
   sg_uf_origem         VARCHAR(2)           not null,
   ed_cep_origem        VARCHAR(8)           not null,
   de_ddd_origem        VARCHAR(3)           not null,
   de_telefone_origem   VARCHAR(9)           not null,
   ic_identificador_cliente VARCHAR(1)           not null,
   ed_logradouro_cliente VARCHAR(50)          not null,
   ed_numero_cliente    VARCHAR(5)           not null,
   ed_complemento_cliente VARCHAR(50)          not null,
   ed_bairro_cliente    VARCHAR(50)          not null,
   co_municipio_cliente VARCHAR(5)           not null,
   sg_uf_cliente        VARCHAR(2)           not null,
   ed_cep_cliente       VARCHAR(8)           not null,
   de_ddd_cliente       VARCHAR(3)           not null,
   de_telefone_cliente  VARCHAR(9)           not null,
   no_nome_cliente      VARCHAR(100)         not null,
   co_agencia           VARCHAR(4)           not null,
   co_operacao          VARCHAR(4)           not null,
   co_numero_conta      VARCHAR(16)          not null,
   co_digito_conta      VARCHAR(2)           not null,
   qt_meses_contrato    INT4                 not null,
   dt_vencto_primeira_parcela DATE                 null,
   dt_vencto_ultima_parcela DATE                 null,
   no_cidade_contrato   VARCHAR(50)          not null,
   sg_uf_liberacao_operacao VARCHAR(2)           not null,
   dt_liberacao_operacao DATE                 null,
   no_indice            VARCHAR(10)          not null,
   co_matricula_cadastrou VARCHAR(7)           not null,
   co_matricula_autorizou VARCHAR(7)           not null,
   pc_juros_mes         NUMERIC(16,2)        null,
   pc_juros_ano         NUMERIC(16,2)        null,
   vr_taxa_contrato     NUMERIC(16,2)        null,
   vr_iof               NUMERIC(16,2)        null,
   constraint PK_ACGTB075_VEICULO primary key (nu_veiculo)
);

comment on table acgsm001.acgtb075_veiculo is
'Tabela responsável por manter os dados de veiculo.';

comment on column acgsm001.acgtb075_veiculo.nu_veiculo is
'Identificador único';

comment on column acgsm001.acgtb075_veiculo.no_marca is
'Marca do Veículo';

comment on column acgsm001.acgtb075_veiculo.no_modelo is
'Modelo do Veículo';

comment on column acgsm001.acgtb075_veiculo.aa_fabricacao is
'Ano de Fabricação do Veículo';

comment on column acgsm001.acgtb075_veiculo.aa_modelo is
'Ano do modelo do Veículo';

comment on column acgsm001.acgtb075_veiculo.ic_zero_km is
'Identifica se é Zero Km:
 S- é Zero KM.
 N - Não é Zero.''';

comment on column acgsm001.acgtb075_veiculo.de_cor is
'Cor do Veículo';

comment on column acgsm001.acgtb075_veiculo.co_renavam is
'RENAVAN';

comment on column acgsm001.acgtb075_veiculo.co_chassi is
'CHASSI';

comment on column acgsm001.acgtb075_veiculo.ic_tipo_chassi is
'Tipo do Chassi: 
R = Remarcado 
N = Normal';

comment on column acgsm001.acgtb075_veiculo.sg_uf_licenciamento is
'Sigla da Unidade da Federação do Licenciamento do Veículo';

comment on column acgsm001.acgtb075_veiculo.sg_uf_veiculo is
'Sigla da Unidade da Federação do Veículo';

comment on column acgsm001.acgtb075_veiculo.co_placa is
'Placa do Veículo';

comment on column acgsm001.acgtb075_veiculo.ic_cpf_cnpj_vendedor is
'Indicador do identificador do Vendedor:
 1 - CPF
 2 - CNPJ ';

comment on column acgsm001.acgtb075_veiculo.co_identificador_vendedor is
'CPF ou CNPJ do Vendedor';

comment on column acgsm001.acgtb075_veiculo.ic_tipo_restricao is
'Informar o código do tipo de restrição:
1 - Arrendamento  Mercantil / Leasing 
2 - Reserva de Domínio 
3 - Alienação Fiduciária 
9 - Penhor';

comment on column acgsm001.acgtb075_veiculo.ed_logradouro_origem is
'Logradouro da Origem';

comment on column acgsm001.acgtb075_veiculo.ed_numero_origem is
'Número da Origem';

comment on column acgsm001.acgtb075_veiculo.ed_complemento_origem is
'Complemento da Origem';

comment on column acgsm001.acgtb075_veiculo.ed_bairro_origem is
'Bairro da Origem';

comment on column acgsm001.acgtb075_veiculo.co_municipio_origem is
'Código do Município da Origem';

comment on column acgsm001.acgtb075_veiculo.sg_uf_origem is
'Sigla da Unidade da Federação da Origem';

comment on column acgsm001.acgtb075_veiculo.ed_cep_origem is
'CEP da Origem';

comment on column acgsm001.acgtb075_veiculo.de_ddd_origem is
'DDD da Origem';

comment on column acgsm001.acgtb075_veiculo.de_telefone_origem is
'Telefone da Origem';

comment on column acgsm001.acgtb075_veiculo.ic_identificador_cliente is
'Indicador do Identificado:
 1 - CPF
 2 - CNPJ';

comment on column acgsm001.acgtb075_veiculo.ed_logradouro_cliente is
'Logradouro Cliente';

comment on column acgsm001.acgtb075_veiculo.ed_numero_cliente is
'Número do complemento do Cliente';

comment on column acgsm001.acgtb075_veiculo.ed_complemento_cliente is
'Complemento Endereço do Cliente';

comment on column acgsm001.acgtb075_veiculo.ed_bairro_cliente is
'Bairro do Cliente';

comment on column acgsm001.acgtb075_veiculo.co_municipio_cliente is
'Código IBGE Município do Cliente';

comment on column acgsm001.acgtb075_veiculo.sg_uf_cliente is
'Sigla da Unidade da Federação do Cliente';

comment on column acgsm001.acgtb075_veiculo.ed_cep_cliente is
'CEP do Cliente';

comment on column acgsm001.acgtb075_veiculo.de_ddd_cliente is
'DDD do Cliente';

comment on column acgsm001.acgtb075_veiculo.de_telefone_cliente is
'Telefone do Cliente';

comment on column acgsm001.acgtb075_veiculo.no_nome_cliente is
'Nome do cliente';

comment on column acgsm001.acgtb075_veiculo.co_agencia is
'Agência';

comment on column acgsm001.acgtb075_veiculo.co_operacao is
'Operação';

comment on column acgsm001.acgtb075_veiculo.co_numero_conta is
'Número Conta';

comment on column acgsm001.acgtb075_veiculo.co_digito_conta is
'Digito Conta';

comment on column acgsm001.acgtb075_veiculo.qt_meses_contrato is
'Quantidade de meses em que o contrato estará em vigor';

comment on column acgsm001.acgtb075_veiculo.dt_vencto_primeira_parcela is
'Data de Vencimento da Primeira Parcela';

comment on column acgsm001.acgtb075_veiculo.dt_vencto_ultima_parcela is
'Data de Vencimento da Última Parcela';

comment on column acgsm001.acgtb075_veiculo.no_cidade_contrato is
'Nome da Cidade da Operação';

comment on column acgsm001.acgtb075_veiculo.sg_uf_liberacao_operacao is
'Sigla do UF da liberação da Operação';

comment on column acgsm001.acgtb075_veiculo.dt_liberacao_operacao is
'Data da liberação da Operação';

comment on column acgsm001.acgtb075_veiculo.no_indice is
'Nome do Indice Utilizado';

comment on column acgsm001.acgtb075_veiculo.co_matricula_cadastrou is
'Matricula que cadastrou o contrato';

comment on column acgsm001.acgtb075_veiculo.co_matricula_autorizou is
'Matricula que autorizou o contrato';

comment on column acgsm001.acgtb075_veiculo.pc_juros_mes is
'Taxa de Juros Mês';

comment on column acgsm001.acgtb075_veiculo.pc_juros_ano is
'Taxa de Juros Ano';

comment on column acgsm001.acgtb075_veiculo.vr_taxa_contrato is
'Valor da Taxa do Contrato';

comment on column acgsm001.acgtb075_veiculo.vr_iof is
'Valor do IOF';

/*==============================================================*/
/* Index: ix_acgtb075_01                                        */
/*==============================================================*/
create  index ix_acgtb075_01 on acgsm001.acgtb075_veiculo using BTREE (
nu_veiculo
);

/*==============================================================*/
/* Index: ix_acgtb075_02                                        */
/*==============================================================*/
create  index ix_acgtb075_02 on acgsm001.acgtb075_veiculo using BTREE (
co_chassi
);