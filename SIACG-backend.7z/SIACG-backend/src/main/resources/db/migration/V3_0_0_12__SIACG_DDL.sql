/*============================================================*/
/*           SCRIPT V3_0_0_12__SIACG_DDL		              */
/*============================================================*/

ALTER TABLE ACG.ACGTB081_IMOVEL ADD CONSTRAINT FK_ACGTB081_ACGTB115 FOREIGN KEY (NU_USO_IMOVEL) REFERENCES ACG.ACGTB115_TIPO_USO_IMOVEL(NU_TIPO_USO_IMOVEL);
ALTER TABLE ACG.ACGTB081_IMOVEL ADD CONSTRAINT FK_ACGTB081_ACGTB116 FOREIGN KEY (NU_CATEGORIA_IMOVEL) REFERENCES ACG.ACGTB116_CATEGORIA_IMOVEL(NU_CATEGORIA_IMOVEL);

/*==============================================================*/
/* Reverter                                                     */
/*==============================================================*/
-- ALTER TABLE ACG.ACGTB081_IMOVEL DROP CONSTRAINT FK_ACGTB081_ACGTB115;
-- ALTER TABLE ACG.ACGTB081_IMOVEL DROP CONSTRAINT FK_ACGTB081_ACGTB116;
