/*============================================================*/
/*           SCRIPT V2_10_0_01__SIACG_DDL		              */
/*============================================================*/

ALTER TABLE acgsm001.acgtb001_contrato ADD COLUMN ic_garantia_bloqueada boolean default false;
ALTER TABLE acgsm001.acgtb001_contrato ALTER COLUMN ic_garantia_bloqueada SET NOT NULL;

COMMENT ON COLUMN acgsm001.acgtb001_contrato.ic_garantia_bloqueada IS 'Indica se o contrato possui uma ou mais garantias bloqueadas. Essa informação é atualizada quando o contrato passa pelo serviço de bloqueio/ desbloqueio de garantias.';

/*==============================================================*/
/* Index: ix_acgtb001_12                                        */
/*==============================================================*/
create index ix_acgtb001_12 on acgsm001.acgtb001_contrato (ic_garantia_bloqueada);

/*==============================================================*/
/* REVERT                                                       */
/*==============================================================*/ 
-- drop index acgsm001.ix_acgtb001_12;
-- ALTER TABLE acgsm001.acgtb001_contrato DROP COLUMN ic_garantia_bloqueada;