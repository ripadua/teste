/*==============================================================*/
/* CARGA NA TABELA acgsm001.acgtb083_indicador_financeiro*/
/*==============================================================*/

INSERT INTO acgsm001.acgtb083_indicador_financeiro(
            no_indicador_financeiro, ic_situacao)
    VALUES ('SELIC', true);

INSERT INTO acgsm001.acgtb083_indicador_financeiro(
            no_indicador_financeiro, ic_situacao)
    VALUES ('IPCA', true);

INSERT INTO acgsm001.acgtb083_indicador_financeiro(
            no_indicador_financeiro, ic_situacao)
    VALUES ('INCC-DI', true);

INSERT INTO acgsm001.acgtb083_indicador_financeiro(
            no_indicador_financeiro, ic_situacao)
    VALUES ('INCC-M', true);

INSERT INTO acgsm001.acgtb083_indicador_financeiro(
            no_indicador_financeiro, ic_situacao)
    VALUES ('IGPM-FGV', true);


INSERT INTO acgsm001.acgtb083_indicador_financeiro(
            no_indicador_financeiro, ic_situacao)
    VALUES ('IGP-DI-FGV', true);

INSERT INTO acgsm001.acgtb083_indicador_financeiro(
            no_indicador_financeiro, ic_situacao)
    VALUES ('INPC-IBGE', true);


INSERT INTO acgsm001.acgtb083_indicador_financeiro(
            no_indicador_financeiro, ic_situacao)
    VALUES ('IPC-FIPE Habitacao', true);

INSERT INTO acgsm001.acgtb083_indicador_financeiro(
            no_indicador_financeiro, ic_situacao)
    VALUES ('CUB-CE Residencial', true);


INSERT INTO acgsm001.acgtb083_indicador_financeiro(
            no_indicador_financeiro, ic_situacao)
    VALUES ('CUB-CE Desoneracao', true);

    
    
    
/*==============================================================*/
/* ATUALIZANDO coluna nu_indicador_financeiro da tabela: acgsm001.acgtb051_ctrto_comercializacao*/
/*============================================================== */

    
 UPDATE acgsm001.acgtb051_ctrto_comercializacao
   SET  nu_indicador_financeiro= (SELECT nu_indicador_financeiro FROM acgsm001.acgtb083_indicador_financeiro WHERE no_indicador_financeiro = 'IGPM-FGV')
 WHERE ic_indicador_reajuste = '1';


UPDATE acgsm001.acgtb051_ctrto_comercializacao
   SET  nu_indicador_financeiro= (SELECT nu_indicador_financeiro FROM acgsm001.acgtb083_indicador_financeiro WHERE no_indicador_financeiro = 'INCC-M')
 WHERE ic_indicador_reajuste = '2';


UPDATE acgsm001.acgtb051_ctrto_comercializacao
   SET  nu_indicador_financeiro= (SELECT nu_indicador_financeiro FROM acgsm001.acgtb083_indicador_financeiro WHERE no_indicador_financeiro = 'CUB-CE Residencial')
 WHERE ic_indicador_reajuste = '3';

