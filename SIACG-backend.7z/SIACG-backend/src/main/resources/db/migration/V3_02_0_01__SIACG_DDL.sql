alter table acg.ACGTB095_DESPESA add dt_inicio date;
alter table acg.ACGTB095_DESPESA add dt_fim date;