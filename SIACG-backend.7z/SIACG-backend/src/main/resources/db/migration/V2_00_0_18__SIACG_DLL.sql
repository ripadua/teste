-- Sequence: acgsm001.sq088_representate_imovel

-- DROP SEQUENCE acgsm001.sq088_representate_imovel;

CREATE SEQUENCE acgsm001.sq088_representate_imovel
  INCREMENT 1
  MINVALUE 1
  MAXVALUE 9223372036854775807
  START 1
  CACHE 1;


-- Table: acgsm001.acgtb088_representante_imovel

-- DROP TABLE acgsm001.acgtb088_representante_imovel;

CREATE TABLE acgsm001.acgtb088_representante_imovel
(	
  nu_representante_imovel integer NOT NULL DEFAULT nextval('acgsm001.sq088_representate_imovel'::regclass),
  nu_representante_legal integer NOT NULL, -- Identificador da garantia do contrato. Tabela acgtb003_pessoa.
  nu_imovel integer NOT NULL, -- Identificador da tabela de imoveis (acgtb081_imoveis)
  CONSTRAINT pk_acgtb088_representante_imovel PRIMARY KEY (nu_representante_imovel),
  CONSTRAINT fk_acgtb003_acgtb001 FOREIGN KEY (nu_representante_legal)
      REFERENCES acgsm001.acgtb003_pessoa (nu_pessoa) MATCH SIMPLE
      ON UPDATE RESTRICT ON DELETE RESTRICT,
  CONSTRAINT fk_acgtb088_acgtb081 FOREIGN KEY (nu_imovel)
      REFERENCES acgsm001.acgtb081_imoveis (nu_imoveis) MATCH SIMPLE
      ON UPDATE RESTRICT ON DELETE RESTRICT
)
WITH (
  OIDS=FALSE
);
COMMENT ON COLUMN acgsm001.acgtb088_representante_imovel.nu_representante_legal IS 'Identificador da pesssoa. Tabela acgtb003_pessoa.';
COMMENT ON COLUMN acgsm001.acgtb088_representante_imovel.nu_imovel IS 'Identificador da tabela de imoveis (acgtb081_imoveis)';



ALTER TABLE acgsm001.acgtb081_imoveis ADD COLUMN tipo_garantia character varying(4);

ALTER TABLE acgsm001.acgtb081_imoveis ADD COLUMN numero_cartorio character varying(10);

ALTER TABLE acgsm001.acgtb081_imoveis
  DROP COLUMN cpf_cnpj;

ALTER TABLE acgsm001.acgtb081_imoveis
  DROP COLUMN nome_razacao_social;
  
ALTER TABLE acgsm001.acgtb081_imoveis
  ADD COLUMN nu_titular_imovel integer;

ALTER TABLE acgsm001.acgtb081_imoveis
  ADD CONSTRAINT nu_titular_imovel_fk FOREIGN KEY (nu_titular_imovel) REFERENCES acgsm001.acgtb003_pessoa (nu_pessoa) ON UPDATE NO ACTION ON DELETE NO ACTION;
