/*============================================================*/
/*           SCRIPT V2_14_0_00__SIACG_DDL		              */
/*============================================================*/

/*==============================================================*/
/* ALTERA STAGING                                               */
/*==============================================================*/

-- Remove a tabela errada (Não colocar isso no roteiro)
DROP TABLE IF EXISTS acgsm002.acgtbs11_contas_atacado;

-- Cria a tabela certa
CREATE TABLE acgsm002.acgtbs17_contas_atacado
(
  co_identificador_contrato character varying(30),
  nu_cnpj character varying(14),
  nu_agencia_origem character varying(4),
  nu_operacao_origem character varying(6),
  nu_conta_origem character varying(20),
  nu_dv_conta_origem character varying(1),
  nu_agencia_destino character varying(4),
  nu_operacao_destino character varying(6),
  nu_conta_destino character varying(20),
  nu_dv_conta_destino character varying(1),
  dt_referencia date,
  ts_processamento timestamp without time zone,
  ts_grupo_processamento timestamp without time zone,
  no_arquivo character varying(100)
);


/*==============================================================*/
/* ALTERA RELACIONAL                                            */
/*==============================================================*/
ALTER TABLE acgsm001.acgtb006_conta_corrente ADD COLUMN ic_ativo boolean;
-- Atualizar dos dados existentes
update acgsm001.acgtb006_conta_corrente
set ic_ativo = true;
ALTER TABLE acgsm001.acgtb006_conta_corrente ALTER COLUMN ic_ativo SET NOT NULL;
ALTER TABLE acgsm001.acgtb006_conta_corrente ALTER COLUMN ic_ativo SET DEFAULT true;
COMMENT ON COLUMN acgsm001.acgtb006_conta_corrente.ic_ativo IS 'TRUE = Conta Corrente ativa, FALSE = Grupo de garantias inativo';


/*==============================================================*/
/* Reverter                                                     */
/*==============================================================*/
-- ALTER TABLE acgsm001.acgtb006_conta_corrente DROP COLUMN ic_ativo;
-- DROP TABLE acgsm002.acgtbs17_contas_atacado;