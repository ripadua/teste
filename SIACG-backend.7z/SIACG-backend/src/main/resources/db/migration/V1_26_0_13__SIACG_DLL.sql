-- ###############   Tabela: acgtb053_recebido
-- Aletrando coluna: nu_ctrto_comercializacao para aceitar valores null, conforme modelo.
	
ALTER TABLE acgsm001.acgtb053_recebido
   ALTER COLUMN nu_ctrto_comercializacao DROP NOT NULL;