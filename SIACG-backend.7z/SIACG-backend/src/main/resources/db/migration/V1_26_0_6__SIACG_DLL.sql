/*==============================================================*/
/* Table: acgtb073_garantia_caixa_produto                             */
/*==============================================================*/
CREATE TABLE acgsm001.acgtb073_garantia_caixa_produto
(
  nu_produto integer NOT NULL, -- Número de identificação do produto de crédito.
  nu_modalidade integer NOT NULL, -- Número da modalidade de contratação do produto.
  nu_produto_caixa integer NOT NULL, -- Número de identificação do produto caixa.
  CONSTRAINT pk_acgtb073_garantia_caixa_produto PRIMARY KEY (nu_produto, nu_modalidade, nu_produto_caixa)
);

COMMENT ON TABLE acgsm001.acgtb073_garantia_caixa_produto
  IS 'Tabela de vinculação entre os produtos Caixa e o produto de crédito.';
COMMENT ON COLUMN acgsm001.acgtb073_garantia_caixa_produto.nu_produto_caixa IS 'Número de identificação do produto caixa.';
COMMENT ON COLUMN acgsm001.acgtb073_garantia_caixa_produto.nu_produto IS 'Número de identificação do produto de crédito.';
COMMENT ON COLUMN acgsm001.acgtb073_garantia_caixa_produto.nu_modalidade IS 'Número da modalidade de contratação do produto.';
