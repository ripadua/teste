/*==============================================================*/
/* SCRIPT V2_00_0_39__SIACG_DLL									*/
/*==============================================================*/
 
INSERT INTO acgsm001.acgtb040_relatorio (nu_relatorio, de_relatorio, de_endereco, de_funcionalidade, de_acao, ic_ativo)
				VALUES( (select max(r.nu_relatorio) from acgsm001.acgtb040_relatorio r) + 1,'Relatório de Apetite por Risco',
				       'ftp://ftp.go.caixa/PEDES/SIACG/relatorio-apetite-risco/',
					   'rel_apetite_risco', 'consultar', TRUE)



/*########################### SCRIPT ROLLBACK ##############################*/
/* 
DELETE FROM acgsm001.acgtb040_relatorio
 where nu_relatorio = (select max(r.nu_relatorio) from acgsm001.acgtb040_relatorio r where de_funcionalidade = 'rel_apetite_risco');
*/