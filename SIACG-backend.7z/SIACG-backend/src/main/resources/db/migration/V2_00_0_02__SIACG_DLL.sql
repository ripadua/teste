/*================================================================================================*/
                                    -- V2_00_0_02__SIACG_DLL.sql
/*================================================================================================*/
ALTER TABLE acgsm001.acgtb054_acao_preventiva ALTER COLUMN nu_contrato TYPE character varying(30);

UPDATE acgsm001.acgtb008_grupo_garantia
   SET ic_acompanha = FALSE
 WHERE no_grupo_garantia = 'PRODUTOS AGRÍCOLAS' AND ic_acompanha is true;

COMMENT ON TABLE acgsm001.acgtb008_grupo_garantia IS
'Agrupamento dos tipos de garantias aceitos pela aplicação (garantias BACEN), para possibilitar que as análises sejam realizadas pelos grupos de garantias.

Exemplo:
DUPLICATAS
APLICACOES FINANCEIRAS
CHEQUES
CARTAO DE CREDITO
OUTRAS
MAQUINAS/EQUIPAMENTOS
VEICULOS
IMOVEIS
FIANCA BANCARIA
...
'; 
COMMENT ON COLUMN acgsm001.acgtb008_grupo_garantia.no_grupo_garantia IS 'Nome do grupo garantia';
COMMENT ON COLUMN acgsm001.acgtb008_grupo_garantia.ic_acompanha IS 'TRUE = Garantias acompanhadas pela Caixa, FALSE = Garantias não acompanhadas pela Caixa';
COMMENT ON COLUMN acgsm001.acgtb008_grupo_garantia.ic_ativo IS 'TRUE = Grupo de garantias ativo, FALSE = Grupo de garantias inativo';
