ALTER TABLE acgsm001.acgtb049_unidade_habitacional
   ALTER COLUMN pc_minimo_baixa DROP NOT NULL;
COMMENT ON COLUMN acgsm001.acgtb049_unidade_habitacional.pc_minimo_baixa IS 'Percentual utilizado para o cálculo do valor mínimo devedor que deverá ser repassado pela construtora para a Caixa no momento da baixa de hipoteca de uma unidade habitacional.

Esse percentual será aplicado sobre o valor de avaliação da UH atualizado.

Ex. Caso o percentual seja de 50% e o valor atualizado da unidade habitacional seja de R$ 100.000,00, o valor mínimo de baixa será de R$ 50.000,00.
';

-- Table: acgsm001.acgtb051_comercializacao

-- DROP TABLE acgsm001.acgtb051_comercializacao;

CREATE TABLE acgsm001.acgtb051_comercializacao
(
  nu_comercializacao bigint NOT NULL DEFAULT nextval('acgsm001.acgsq051_comercializacao'::regclass),
  nu_unidade_habitacional bigint NOT NULL,
  dt_contrato date NOT NULL,
  vr_contrato numeric(15,2) NOT NULL,
  ic_indicador_reajuste character(1) NOT NULL, -- Identifica qual é o indice de reajuste dos valores prospectados:...
  ic_renegociada boolean DEFAULT false, -- Indica se houve renegociação para o contrato de comercialização da unidade habitacional....
  co_imagem_ged character varying(10),
  dh_inclusao date, -- Data e hora de cadastro do contrato no SIACG. Esse cadastramento pode ser realizado em data posterior a data da contratação, portano é importante ter esse registro.
  co_responsavel character varying(7), -- Código da matrícula do responsável pelo cadastramento das informações do contrato....
  ic_situacao character(2), -- comment on column acgtb051_ctrto_comercializacao.ic_situacao is...
  CONSTRAINT pk_acgtb051_comercializacao PRIMARY KEY (nu_comercializacao),
  CONSTRAINT fk_acgtb051_acgtb049 FOREIGN KEY (nu_unidade_habitacional)
      REFERENCES acgsm001.acgtb049_unidade_habitacional (nu_unidade_habitacional) MATCH SIMPLE
      ON UPDATE NO ACTION ON DELETE NO ACTION,
  CONSTRAINT ckc_ic_reajuste_acgtb051 CHECK (ic_indicador_reajuste = ANY (ARRAY['1'::bpchar, '2'::bpchar, '3'::bpchar]))
)
WITH (
  OIDS=FALSE
);

ALTER TABLE acgsm001.acgtb051_comercializacao
   ALTER COLUMN nu_comercializacao DROP DEFAULT;


COMMENT ON COLUMN acgsm001.acgtb051_comercializacao.ic_indicador_reajuste IS 'Identifica qual é o indice de reajuste dos valores prospectados:

1 - IGPM índice geral de preço de mercado
2 - INCC  índice nacional da construção civil 
3 - CUBI  custo unitário básico';
COMMENT ON COLUMN acgsm001.acgtb051_comercializacao.ic_renegociada IS 'Indica se houve renegociação para o contrato de comercialização da unidade habitacional.

TRUE: Houve renegociação para uma unidade comercializada
FALSE: Não houve renegociação. É também o valor padrão para unidades em estoque (ainda não comercializadas).';
COMMENT ON COLUMN acgsm001.acgtb051_comercializacao.dh_inclusao IS 'Data e hora de cadastro do contrato no SIACG. Esse cadastramento pode ser realizado em data posterior a data da contratação, portano é importante ter esse registro.
';
COMMENT ON COLUMN acgsm001.acgtb051_comercializacao.co_responsavel IS 'Código da matrícula do responsável pelo cadastramento das informações do contrato.

Caso a informação seja recebida por carga de sistema deverá ser registrado s000001.';
COMMENT ON COLUMN acgsm001.acgtb051_comercializacao.ic_situacao IS 'comment on column acgtb051_ctrto_comercializacao.ic_situacao is
''Identifica a situação do contrato de comercialização de uma unidade habitacional:
01 - Aberto
02 - Atrasado
03 - Fechado
04 - Cancelado
05 - Pré-Análise
06 - Contratado
'';';

create table acgsm001.acgtb064_proponente_habitaciona (
   nu_comercializacao   int8,
   nu_pessoa            int4                 not null,
   constraint PK_ACGTB064_PROPONENTE_HABITAC primary key (nu_comercializacao, nu_pessoa)
);

comment on table acgsm001.acgtb064_proponente_habitaciona is
'Vinculação dos proponentes da contratação de um unidade habitacional.';

comment on column acgsm001.acgtb064_proponente_habitaciona.nu_comercializacao is
'Identificador únido';

comment on column acgsm001.acgtb064_proponente_habitaciona.nu_pessoa is
'Identificador da empresa. Gerado automaticamente pelo sistema.';

alter table acgsm001.acgtb064_proponente_habitaciona
   add constraint FK_ACGTB064_REFERENCE_ACGTB051 foreign key (nu_comercializacao)
      references acgsm001.acgtb051_comercializacao (nu_comercializacao)
      on delete restrict on update restrict;

alter table acgsm001.acgtb064_proponente_habitaciona
   add constraint FK_ACGTB064_REFERENCE_ACGTB003 foreign key (nu_pessoa)
      references acgsm001.acgtb003_pessoa (nu_pessoa)
      on delete restrict on update restrict;