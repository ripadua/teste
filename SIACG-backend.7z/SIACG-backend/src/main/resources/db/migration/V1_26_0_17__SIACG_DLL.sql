
CREATE TABLE acgsm001.acgtb075_veiculo
(
  nu_veiculo bigint NOT NULL, 
  no_marca character varying(100) NOT NULL,
  no_modelo character varying(100) NOT NULL,
  aa_fabricacao int NOT NULL, 
  aa_modelo int NOT NULL, 
  ic_zero_km character varying(1) NOT NULL,
  de_cor character varying(100) NOT NULL,
  co_renavam character varying(30) NOT NULL,
  co_chassi character varying(30) NOT NULL,
  ic_tipo_chassi character varying(1) NOT NULL,
  sg_uf_licenciamento character varying(2) NOT NULL,
  sg_uf_veiculo character varying(2) NOT NULL,
  co_placa character varying(7) NOT NULL,
  ic_cpf_cnpj_vendedor int NOT NULL,
  nu_identificador_vendedor character varying(14) NOT NULL,
  ic_tipo_restricao character varying(1) NOT NULL,
  ed_logradouro_matriz character varying(50) NOT NULL,
  ed_numero_matriz character varying(5) NOT NULL,
  ed_complemento_matriz character varying(50) NOT NULL,
  ed_bairro_matriz character varying(50) NOT NULL,
  co_municipio_matriz character varying(5) NOT NULL,
  sg_uf_matriz character varying(2) NOT NULL,
  ed_cep_matriz character varying(7) NOT NULL,
  de_ddd_matriz character varying(3) NOT NULL,
  de_telefone_matriz character varying(9) NOT NULL,  
  ic_identificador_cliente character varying(1) NOT NULL,
  ed_logradouro_cliente character varying(50) NOT NULL,
  ed_numero_cliente character varying(5) NOT NULL,
  ed_complemento_cliente character varying(50) NOT NULL,
  ed_bairro_cliente character varying(50) NOT NULL,
  co_municipio_cliente character varying(5) NOT NULL,
  sg_uf_cliente character varying(2) NOT NULL,
  ed_cep_cliente character varying(7) NOT NULL,
  de_ddd_cliente character varying(3) NOT NULL,
  de_telefone_cliente character varying(9) NOT NULL,
  no_nome_cliente character varying(100) NOT NULL,  
  co_agencia character varying(4) NOT NULL,
  co_operacao character varying(4) NOT NULL,
  co_numero_conta character varying(16) NOT NULL,
  co_digito_conta character varying(2) NOT NULL,  
  qt_meses_contrato int NOT NULL,  
  dt_vencto_primeira_parcela date, 
  dt_vencto_ultima_parcela date, 
  no_cidade_contrato character varying(50) NOT NULL,
  sg_uf_liberacao_operacao character varying(2) NOT NULL,
  dt_liberacao_operacao date, 
  no_indice character varying(10) NOT NULL,  
  co_matricula_cadastrou character varying(7) NOT NULL,  
  co_matricula_autorizou character varying(7) NOT NULL,  
  pc_juros_mes numeric(16,2),
  pc_juros_ano numeric(16,2),
  vr_taxa_contrato numeric(16,2),
  vr_iof numeric(16,2)
);

	
COMMENT ON TABLE acgsm001.acgtb075_veiculo IS 'Dados de veiculos dados como garantia de algum contrato.';
COMMENT ON COLUMN acgsm001.acgtb075_veiculo.nu_veiculo IS 'Identificador único';
COMMENT ON COLUMN acgsm001.acgtb075_veiculo.no_marca IS 'Marca';
COMMENT ON COLUMN acgsm001.acgtb075_veiculo.no_modelo IS 'Modelo';
COMMENT ON COLUMN acgsm001.acgtb075_veiculo.aa_fabricacao IS ' Ano de Fabricação';
COMMENT ON COLUMN acgsm001.acgtb075_veiculo.aa_modelo IS 'Ano do modelo';
COMMENT ON COLUMN acgsm001.acgtb075_veiculo.ic_zero_km IS 'Identifica se é Zero Km:
 S- é Zero KM.
 N - Não é Zero.';
COMMENT ON COLUMN acgsm001.acgtb075_veiculo.de_cor IS 'Cor';
COMMENT ON COLUMN acgsm001.acgtb075_veiculo.co_renavam IS 'RENAVAN';
COMMENT ON COLUMN acgsm001.acgtb075_veiculo.co_chassi IS 'CHASSI';
COMMENT ON COLUMN acgsm001.acgtb075_veiculo.ic_tipo_chassi IS 'Tipo do Chassi: 
R = Remarcado 
N = Normal';
COMMENT ON COLUMN acgsm001.acgtb075_veiculo.sg_uf_licenciamento IS 'Sigla da Unidade da Federação do Licenciamento';
COMMENT ON COLUMN acgsm001.acgtb075_veiculo.sg_uf_veiculo IS 'Sigla da Unidade da Federação do Veículo';
COMMENT ON COLUMN acgsm001.acgtb075_veiculo.co_placa IS 'Placa';
COMMENT ON COLUMN acgsm001.acgtb075_veiculo.ic_cpf_cnpj_vendedor IS 'Indicador do identificador do Vendedor:
 1 - CPF
 2 - CNPJ ';
COMMENT ON COLUMN acgsm001.acgtb075_veiculo.nu_identificador_vendedor IS 'CPF ou CNPJ do Vendedor';
COMMENT ON COLUMN acgsm001.acgtb075_veiculo.ic_tipo_restricao IS 'Informar o código do tipo de restrição:
1 - Arrendamento  Mercantil / Leasing 
2 - Reserva de Domínio 
3 - Alienação Fiduciária 
9 - Penhor';
COMMENT ON COLUMN acgsm001.acgtb075_veiculo.ed_logradouro_matriz IS 'Logradouro da Matriz';
COMMENT ON COLUMN acgsm001.acgtb075_veiculo.ed_numero_matriz IS 'Número do Matriz';
COMMENT ON COLUMN acgsm001.acgtb075_veiculo.ed_complemento_matriz IS 'Complemento Matriz';
COMMENT ON COLUMN acgsm001.acgtb075_veiculo.ed_bairro_matriz IS 'Bairro Matriz';
COMMENT ON COLUMN acgsm001.acgtb075_veiculo.co_municipio_matriz IS 'Código do Município Matriz';
COMMENT ON COLUMN acgsm001.acgtb075_veiculo.sg_uf_matriz IS 'Sigla da Unidade da Federação da Matriz';
COMMENT ON COLUMN acgsm001.acgtb075_veiculo.ed_cep_matriz IS 'CEP Matriz';
COMMENT ON COLUMN acgsm001.acgtb075_veiculo.de_ddd_matriz IS 'Número Matriz';
COMMENT ON COLUMN acgsm001.acgtb075_veiculo.de_telefone_matriz IS 'Telefone da Matriz';
COMMENT ON COLUMN acgsm001.acgtb075_veiculo.ic_identificador_cliente IS 'Indicador do Identificado:
 1 - CPF
 2 - CNPJ ';
COMMENT ON COLUMN acgsm001.acgtb075_veiculo.ed_logradouro_cliente IS 'Complemento do Cliente';
COMMENT ON COLUMN acgsm001.acgtb075_veiculo.ed_numero_cliente IS 'Número do complemento do Cliente';
COMMENT ON COLUMN acgsm001.acgtb075_veiculo.ed_complemento_cliente IS 'Complemento do Cliente';
COMMENT ON COLUMN acgsm001.acgtb075_veiculo.ed_bairro_cliente IS 'Bairro do Cliente';
COMMENT ON COLUMN acgsm001.acgtb075_veiculo.co_municipio_cliente IS 'Município do Cliente';
COMMENT ON COLUMN acgsm001.acgtb075_veiculo.sg_uf_cliente IS 'Sigla da Unidade da Federação do Cliente';
COMMENT ON COLUMN acgsm001.acgtb075_veiculo.ed_cep_cliente IS 'CEP do Cliente';
COMMENT ON COLUMN acgsm001.acgtb075_veiculo.de_ddd_cliente IS 'DDD do Cliente';
COMMENT ON COLUMN acgsm001.acgtb075_veiculo.de_telefone_cliente IS 'Telefone do Cliente';
COMMENT ON COLUMN acgsm001.acgtb075_veiculo.no_nome_cliente IS 'Nome do cliente';
COMMENT ON COLUMN acgsm001.acgtb075_veiculo.co_agencia IS 'Agência';
COMMENT ON COLUMN acgsm001.acgtb075_veiculo.co_operacao IS 'Operação';
COMMENT ON COLUMN acgsm001.acgtb075_veiculo.co_numero_conta IS 'Número Conta';
COMMENT ON COLUMN acgsm001.acgtb075_veiculo.co_digito_conta IS 'Digito Conta';
COMMENT ON COLUMN acgsm001.acgtb075_veiculo.qt_meses_contrato IS 'Quantidade de meses do contrato estará em vigor';
COMMENT ON COLUMN acgsm001.acgtb075_veiculo.dt_vencto_primeira_parcela IS 'Data de Vencimento da Primeira Parcela';
COMMENT ON COLUMN acgsm001.acgtb075_veiculo.dt_vencto_ultima_parcela IS 'Data de Vencimento da Última Parcela';
COMMENT ON COLUMN acgsm001.acgtb075_veiculo.no_cidade_contrato IS 'Nome da Cidade do Contrato';
COMMENT ON COLUMN acgsm001.acgtb075_veiculo.sg_uf_liberacao_operacao IS 'Sigla do UF da liberação da Operação';
COMMENT ON COLUMN acgsm001.acgtb075_veiculo.dt_liberacao_operacao IS 'Data da liberação da Operação';
COMMENT ON COLUMN acgsm001.acgtb075_veiculo.no_indice IS 'Nome do Indice Utilizado';
COMMENT ON COLUMN acgsm001.acgtb075_veiculo.co_matricula_cadastrou IS 'Matricula que cadastrou o contrato';
COMMENT ON COLUMN acgsm001.acgtb075_veiculo.co_matricula_autorizou IS 'Matricula que autorizou o contrato';
COMMENT ON COLUMN acgsm001.acgtb075_veiculo.pc_juros_mes IS 'Taxa de Juros Mês';
COMMENT ON COLUMN acgsm001.acgtb075_veiculo.pc_juros_ano IS 'Taxa de Juros Ano';
COMMENT ON COLUMN acgsm001.acgtb075_veiculo.vr_taxa_contrato IS 'Valor da Taxa do Contrato';
COMMENT ON COLUMN acgsm001.acgtb075_veiculo.vr_iof IS 'Valor do IOF';

CREATE INDEX ix_acgtb075_01 ON acgsm001.acgtb075_veiculo USING btree (nu_veiculo);  
CREATE INDEX ix_acgtb075_02 ON acgsm001.acgtb075_veiculo USING btree (co_chassi); 
 
CREATE SEQUENCE acgsm001.acgsq075_veiculo INCREMENT 1 MINVALUE 1 MAXVALUE 9223372036854775807 START 1 CACHE 1;