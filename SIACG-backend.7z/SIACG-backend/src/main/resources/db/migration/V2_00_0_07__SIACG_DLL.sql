/*================================================================================================*/
                                    -- V2_00_0_07__SIACG_DLL.sql
/*================================================================================================*/
ALTER SEQUENCE acgsm001.sq054_acao_preventiva_nrodoc
  INCREMENT 1
  MINVALUE 1
  MAXVALUE 999999
  START 1
  CACHE 1
  CYCLE;

COMMENT ON COLUMN acgsm001.acgtb054_acao_preventiva.ic_marca_ds200 IS 'Indicador do DS200:
0 - Não é necessário enviar o DS200 ou a garantia não é um conta SIDEC.
1 - Aguardando envio do DS200.
2 - Enviado ao DS200.
3 - Resposta do DS200 de Sucesso.
4 - Resposta do DS200 de Erro.
5 - Resposta Inexistente no Arquivo DS200.';

COMMENT ON COLUMN acgsm001.acgtb054_acao_preventiva.ic_desmarca_ds200 IS 'Indicador do DS200:
0 - Não é necessário enviar o DS200 ou a garantia não é um conta SIDEC.
1 - Aguardando envio do DS200.
2 - Enviado ao DS200.
3 - Resposta do DS200 de Sucesso.
4 - Resposta do DS200 de Erro.
5 - Resposta Inexistente no Arquivo DS200.';

COMMENT ON COLUMN acgsm001.acgtb054_acao_preventiva.ic_bloqueio_ds200 IS 'Indicador do DS200:
0 - Não é necessário enviar o DS200 ou a garantia não é um conta SIDEC.
1 - Aguardando envio do DS200.
2 - Enviado ao DS200.
3 - Resposta do DS200 de Sucesso.
4 - Resposta do DS200 de Erro.
5 - Resposta Inexistente no Arquivo DS200.';

COMMENT ON COLUMN acgsm001.acgtb054_acao_preventiva.ic_desbloqueio_ds200 IS 'Indicador do DS200:
0 - Não é necessário enviar o DS200 ou a garantia não é um conta SIDEC.
1 - Aguardando envio do DS200.
2 - Enviado ao DS200.
3 - Resposta do DS200 de Sucesso.
4 - Resposta do DS200 de Erro.
5 - Resposta Inexistente no Arquivo DS200.';