BEGIN;
    INSERT INTO acgsm001.acgtb040_relatorio(nu_relatorio, de_relatorio, de_endereco, de_funcionalidade, de_acao, ic_ativo)
    VALUES ((select max(coalesce(nu_relatorio,0)) + 1 as nu from acgsm001.acgtb040_relatorio),'Aplicacao financeira bloqueada', 'ftp://ftp.go.caixa/PEDES/SIACG/relatorio_aplicacao_financeira/',
    'rel_aplicacao_financ_blq', 'consultar', 't');
COMMIT;