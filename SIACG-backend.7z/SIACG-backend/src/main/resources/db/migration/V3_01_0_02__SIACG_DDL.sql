/*============================================================*/
/*           SCRIPT V3_01_0_02__SIACG_DDL		              */
/*============================================================*/

/*==============================================================*/
/* Table: ACGTB119_ORIGEM_FINANCEIRA                            */
/*==============================================================*/
create table ACG.ACGTB119_ORIGEM_FINANCEIRA 
(
   NU_PRODUTO           NUMBER(4)            not null,
   IC_ORIGEM_FINANCEIRA VARCHAR(1)           not null
      constraint CK_ACGTB119_01 check (IC_ORIGEM_FINANCEIRA in ('1','2','3','4','5','6')),
   constraint PK_ACGTB119 primary key (NU_PRODUTO)
    USING INDEX TABLESPACE "ACGTSIX001" ENABLE
) TABLESPACE "ACGTSDT001";

comment on table ACG.ACGTB119_ORIGEM_FINANCEIRA is
'Identifica a origem financeira do recurso utilizado (produto/ operação).';

comment on column ACG.ACGTB119_ORIGEM_FINANCEIRA.NU_PRODUTO is
'Número do produto/ operação.';

comment on column ACG.ACGTB119_ORIGEM_FINANCEIRA.IC_ORIGEM_FINANCEIRA is
'Indicador da origem financeira do recurso utilizado, podendo ser:
1 - SBPE
2 - FGTS
3 - PMCMV
4 - COMERCIAL - CIP
5 - COMERCIAL - OUTROS
6 - PATRIMONIAL';

/*==============================================================*/
/* Table: ACGTB120_VALOR_DESAGIO                                */
/*==============================================================*/
create sequence ACG.ACGSQ120_VALOR_DESAGIO;

create table ACG.ACGTB120_VALOR_DESAGIO 
(
   NU_VALOR_DESAGIO     NUMBER(10)           default ACG.ACGSQ120_VALOR_DESAGIO.NEXTVAL not null,
   IC_ORIGEM_FINANCEIRA VARCHAR(1)          
      constraint CK_ACGTB120_01 check (IC_ORIGEM_FINANCEIRA is null or (IC_ORIGEM_FINANCEIRA in ('1','2','3','4','5','6'))),
   IC_ESTADO_OCUPACAO_IMOVEL CHAR(1)              not null
      constraint CK_ACGTB120_02 check (IC_ESTADO_OCUPACAO_IMOVEL in ('1','2')),
   VALOR_DESAGIO        NUMBER(6,4)          not null,
   constraint PK_ACGTB120 primary key (NU_VALOR_DESAGIO)
   USING INDEX TABLESPACE "ACGTSIX001" ENABLE
) TABLESPACE "ACGTSDT001";

comment on table ACG.ACGTB120_VALOR_DESAGIO is
'Identifica, a partir da origem financeira do recurso utilizado e do estado de ocupação de um imóvel, o valor do deságio para o imóvel.';

comment on column ACG.ACGTB120_VALOR_DESAGIO.NU_VALOR_DESAGIO is
'Identifcador do registro, gerado automaticamente.';

comment on column ACG.ACGTB120_VALOR_DESAGIO.IC_ORIGEM_FINANCEIRA is
'Indicador da origem financeira do recurso utilizado, podendo ser:
1 - SBPE
2 - FGTS
3 - PMCMV
4 - COMERCIAL - CIP
5 - COMERCIAL - OUTROS
6 - PATRIMONIAL';

comment on column ACG.ACGTB120_VALOR_DESAGIO.IC_ESTADO_OCUPACAO_IMOVEL is
'Identifica o estado de ocupação de um imóvel, podendo ser:
1 - Desocupado
2 - Ocupado';

comment on column ACG.ACGTB120_VALOR_DESAGIO.VALOR_DESAGIO is
'O valor do deságio.';

/*==============================================================*/
/* Table: ACGTB121_HSTRO_CLCLO_VLR_IMVL                         */
/*==============================================================*/
create sequence ACG.ACGSQ121_HSTRO_CLCLO_VLR_IMVL;

create table ACG.ACGTB121_HSTRO_CLCLO_VLR_IMVL 
(
   NU_HSTRO_CLCLO_VLR_IMVL NUMBER(19)           default ACG.ACGSQ121_HSTRO_CLCLO_VLR_IMVL.NEXTVAL not null,
   NU_CONTRATO          NUMBER(10)           not null,
   NU_IMOVEL            NUMBER(10)           not null,
   CO_OS                VARCHAR(45),
   IC_ESTADO_OCUPACAO_IMOVEL CHAR(1)             
      constraint CK_ACGTB121_01 check (IC_ESTADO_OCUPACAO_IMOVEL is null or (IC_ESTADO_OCUPACAO_IMOVEL in ('1','2'))),
   VR_AVALIACAO_IMOVEL  NUMERIC(16, 2),
   VR_DESAGIO_IMOVEL    NUMERIC(6, 4),
   VR_JUSTO_IMOVEL      NUMERIC(16, 2)       not null,
   CO_IDENTIFICADOR_CALCULO VARCHAR2(45),
   TS_CALCULO           TIMESTAMP            not null,
   CO_MATRICULA         VARCHAR(7)           not null,
   constraint PK_ACGTB121 primary key (NU_HSTRO_CLCLO_VLR_IMVL)
   USING INDEX TABLESPACE "ACGTSIX001" ENABLE
) TABLESPACE "ACGTSDT001";

comment on table ACG.ACGTB121_HSTRO_CLCLO_VLR_IMVL is
'Armazena o histórico de cálculo de valor justo do imóvel.';

comment on column ACG.ACGTB121_HSTRO_CLCLO_VLR_IMVL.NU_HSTRO_CLCLO_VLR_IMVL is
'Identificador do registro, gerado automaticamente.';

comment on column ACG.ACGTB121_HSTRO_CLCLO_VLR_IMVL.NU_CONTRATO is
'Número identificador de um contrato.';

comment on column ACG.ACGTB121_HSTRO_CLCLO_VLR_IMVL.NU_IMOVEL is
'Número identificador de um imóvel.';

comment on column ACG.ACGTB121_HSTRO_CLCLO_VLR_IMVL.CO_OS is
'Código da Ordem de Serviço que deu origem à avaliação do imóvel.';

comment on column ACG.ACGTB121_HSTRO_CLCLO_VLR_IMVL.IC_ESTADO_OCUPACAO_IMOVEL is
'Identifica o estado de ocupação de um imóvel, podendo ser:
1 - Desocupado
2 - Ocupado';

comment on column ACG.ACGTB121_HSTRO_CLCLO_VLR_IMVL.VR_AVALIACAO_IMOVEL is
'Valor de avaliação do imóvel.';

comment on column ACG.ACGTB121_HSTRO_CLCLO_VLR_IMVL.VR_DESAGIO_IMOVEL is
'Valor de deságio do imóvel.';

comment on column ACG.ACGTB121_HSTRO_CLCLO_VLR_IMVL.VR_JUSTO_IMOVEL is
'Resultado do cálculo do valor justo do imóvel.';

comment on column ACG.ACGTB121_HSTRO_CLCLO_VLR_IMVL.CO_IDENTIFICADOR_CALCULO is
'Código identificador único do cálculo realizado.';

comment on column ACG.ACGTB121_HSTRO_CLCLO_VLR_IMVL.TS_CALCULO is
'Data e hora de realização do cálculo.';

comment on column ACG.ACGTB121_HSTRO_CLCLO_VLR_IMVL.CO_MATRICULA is
'Código da matrícula do responsável pelo cálculo.';

alter table ACG.ACGTB121_HSTRO_CLCLO_VLR_IMVL
   add constraint FK_ACGTB121_ACGTB001 foreign key (NU_CONTRATO)
      references ACG.ACGTB001_CONTRATO (NU_CONTRATO);

alter table ACG.ACGTB121_HSTRO_CLCLO_VLR_IMVL
   add constraint FK_ACGTB121_ACGTB081 foreign key (NU_IMOVEL)
      references ACG.ACGTB081_IMOVEL (NU_IMOVEL);
      
/*==============================================================*/
/* Index: "ix_acgtb121_01"                                      */
/* Index: "ix_acgtb121_02"                                      */
/* Index: "ix_acgtb121_03"                                      */
/*==============================================================*/
create index ACG."IX_ACGTB121_01" on ACG.ACGTB121_HSTRO_CLCLO_VLR_IMVL (NU_CONTRATO ASC) TABLESPACE ACGTSIX001;
create index ACG."IX_ACGTB121_02" on ACG.ACGTB121_HSTRO_CLCLO_VLR_IMVL (NU_IMOVEL ASC) TABLESPACE ACGTSIX001;
create index ACG."IX_ACGTB121_03" on ACG.ACGTB121_HSTRO_CLCLO_VLR_IMVL (IC_ESTADO_OCUPACAO_IMOVEL ASC) TABLESPACE ACGTSIX001;

/*==============================================================*/
/* Table: ACGTB057_PARAMETRO_PRODUTO                            */
/*==============================================================*/

ALTER TABLE ACG.ACGTB057_PARAMETRO_PRODUTO ADD NO_ORIGEM_CONTRATO VARCHAR(15);
ALTER TABLE ACG.ACGTB057_PARAMETRO_PRODUTO ADD IC_ORIGEM_FINANCEIRA VARCHAR(1);

comment on column ACG.ACGTB057_PARAMETRO_PRODUTO.NO_ORIGEM_CONTRATO is 'Nome da origem do contrato.';
comment on column ACG.ACGTB057_PARAMETRO_PRODUTO.IC_ORIGEM_FINANCEIRA is 'Indicador da origem financeira do recurso utilizado, podendo ser:
1 - SBPE
2 - FGTS
3 - PMCMV
4 - COMERCIAL - CIP
5 - COMERCIAL - OUTROS
6 - PATRIMONIAL';

ALTER TABLE ACG.ACGTB057_PARAMETRO_PRODUTO ADD constraint CK_ACGTB057_01 check (NO_ORIGEM_CONTRATO is null or (NO_ORIGEM_CONTRATO in ('CIP','COMERCIAL','EMPREENDIMENTO','HABITACIONAL','PATRIMONIAL')));
ALTER TABLE ACG.ACGTB057_PARAMETRO_PRODUTO ADD constraint CK_ACGTB057_02 check (IC_ORIGEM_FINANCEIRA is null or (IC_ORIGEM_FINANCEIRA in ('1','2','3','4','5','6')));

/*==============================================================*/
/* Table: ACGTB081_IMOVEL                                       */
/*==============================================================*/
ALTER TABLE ACG.ACGTB081_IMOVEL ADD IC_ESTADO_OCUPACAO_IMOVEL CHAR(1);

comment on column ACG.ACGTB081_IMOVEL.IC_ESTADO_OCUPACAO_IMOVEL is
'Identifica o estado de ocupação de um imóvel, podendo ser:
1 - Desocupado
2 - Ocupado';

ALTER TABLE ACG.ACGTB081_IMOVEL ADD constraint CK_ACGTB081_09 check (IC_ESTADO_OCUPACAO_IMOVEL is null or (IC_ESTADO_OCUPACAO_IMOVEL in ('1','2')));

/*==============================================================*/
/* Revert                                                       */
/*==============================================================*/
-- drop table ACG.ACGTB119_ORIGEM_FINANCEIRA cascade constraints;
-- drop table ACG.ACGTB120_VALOR_DESAGIO cascade constraints;
-- drop table ACG.ACGTB121_HSTRO_CLCLO_VLR_IMVL cascade constraints;
-- drop sequence ACG.ACGSQ120_VALOR_DESAGIO;
-- drop sequence ACG.ACGSQ121_HSTRO_CLCLO_VLR_IMVL;
-- ALTER TABLE ACG.ACGTB057_PARAMETRO_PRODUTO DROP COLUMN NO_ORIGEM_CONTRATO;
-- ALTER TABLE ACG.ACGTB057_PARAMETRO_PRODUTO DROP COLUMN NO_ORIGEM_FINANCEIRA;
-- ALTER TABLE ACG.ACGTB081_IMOVEL DROP COLUMN IC_ESTADO_OCUPACAO_IMOVEL;
