-- Table: acgsm001.acgtb087_contrato_imoveis

-- DROP TABLE acgsm001.acgtb087_contrato_imoveis;

CREATE TABLE acgsm001.acgtb087_contrato_imoveis
(
  nu_contrato integer NOT NULL, -- Identificador da garantia do contrato. Tabela acgtb001_contrato.
  nu_imovel integer NOT NULL, -- Identificador da tabela de imoveis (acgtb081_imoveis)
  CONSTRAINT pk_acgtb087_contrato_imoveis PRIMARY KEY (nu_imovel, nu_contrato),
  CONSTRAINT fk_acgtb087_acgtb001 FOREIGN KEY (nu_contrato)
      REFERENCES acgsm001.acgtb001_contrato (nu_contrato) MATCH SIMPLE
      ON UPDATE RESTRICT ON DELETE RESTRICT,
  CONSTRAINT fk_acgtb087_acgtb081 FOREIGN KEY (nu_imovel)
      REFERENCES acgsm001.acgtb081_imoveis (nu_imoveis) MATCH SIMPLE
      ON UPDATE RESTRICT ON DELETE RESTRICT
)
WITH (
  OIDS=FALSE
);

COMMENT ON COLUMN acgsm001.acgtb087_contrato_imoveis.nu_contrato IS 'Identificador da garantia do contrato. Tabela acgtb001_contrato.';
COMMENT ON COLUMN acgsm001.acgtb087_contrato_imoveis.nu_imovel IS 'Identificador da tabela de imoveis (acgtb081_imoveis)';


ALTER TABLE acgsm001.acgtb081_imoveis
  ADD COLUMN valor numeric;
  
ALTER TABLE acgsm001.acgtb081_imoveis
  ADD COLUMN descricao  character varying(500);
  
ALTER TABLE acgsm001.acgtb081_imoveis ADD COLUMN cod_grupo_garantia integer;
  
  