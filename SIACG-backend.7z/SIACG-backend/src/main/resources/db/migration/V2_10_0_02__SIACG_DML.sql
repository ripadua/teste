/*============================================================*/
/*           SCRIPT V2_10_0_02__SIACG_DML		              */
/*============================================================*/

--Atualiza somente os contratos que possuem garantia bloqueada
UPDATE acgsm001.acgtb001_contrato SET ic_garantia_bloqueada = true
WHERE nu_contrato in 
(SELECT distinct c.nu_contrato 
FROM acgsm001.acgtb001_contrato c
INNER JOIN acgsm001.acgtb009_garantia_contrato gc ON c.nu_contrato = gc.nu_contrato
INNER JOIN acgsm001.acgtb054_acao_preventiva ap ON gc.nu_garantia_contrato = ap.nu_garantia_contrato
WHERE ap.dt_desbloqueio is null);