/*============================================================*/
/*           SCRIPT V2_09_0_01__SIACG_DML				      */
/*============================================================*/

/*============================================================*/
/* Table: acgsm002.acgtbs12_pessoa                            */
/*============================================================*/

create table acgsm002.acgtbs12_pessoa (
	ic_tipo_pessoa integer,
	co_identificador_pessoa character varying(14),
	no_pessoa character varying(50),
	nu_agencia character varying(5),
	nu_operacao character varying(4),
	nu_conta character varying(12),
	nu_dv character varying(1),
	vr_faturamento_fiscal numeric(15,2),
	co_contrato character varying(20),
	co_produto character varying(4),
	co_sistema_origem character varying(4),
	no_arquivo text,
	ts_processamento timestamp without time zone,
	ts_grupo_processamento timestamp without time zone
);

COMMENT ON TABLE acgsm002.acgtbs12_pessoa
  IS 'Tabela de Stage Area que armazena as informações de pessoa após a definição do leiaute único.';
COMMENT ON COLUMN acgsm002.acgtbs12_pessoa.ic_tipo_pessoa IS 'Informa qual é o tipo de pessoa: 1 se for CPF, 
2 se for CNPJ, 
3  se for PF no exterior,  
4 se for PJ no exterior, 
5 se for PF Sem Identificação, 
6 se for PJ sem identificação.';
COMMENT ON COLUMN acgsm002.acgtbs12_pessoa.co_identificador_pessoa IS 'Define o identificador da pessoa (CPF/CNPJ), como os dígitos verificadores';
COMMENT ON COLUMN acgsm002.acgtbs12_pessoa.no_pessoa IS 'Define o nome/razão social da pessoa';
COMMENT ON COLUMN acgsm002.acgtbs12_pessoa.nu_agencia IS 'Define o código da agência (AAAAA)';
COMMENT ON COLUMN acgsm002.acgtbs12_pessoa.nu_operacao IS 'Define o código do produto (PPPP) em substituição à operação do SIDEC.';
COMMENT ON COLUMN acgsm002.acgtbs12_pessoa.nu_conta IS 'Define o código da conta (CCCCCCCCCCCC)único na CAIXA e sequencial.';
COMMENT ON COLUMN acgsm002.acgtbs12_pessoa.nu_dv IS 'Define o dígito verificador (D)';
COMMENT ON COLUMN acgsm002.acgtbs12_pessoa.vr_faturamento_fiscal IS 'Armazena o valor do faturamento da empresa informado via carga.';
COMMENT ON COLUMN acgsm002.acgtbs12_pessoa.co_contrato IS 'Define a identificaçao do contrato incluindo o dígito verificador.';
COMMENT ON COLUMN acgsm002.acgtbs12_pessoa.co_produto IS 'Define o código do Produto conforme tabela SIICO';
COMMENT ON COLUMN acgsm002.acgtbs12_pessoa.co_sistema_origem IS 'Define o código do sistema conforme tabela SIICO';
COMMENT ON COLUMN acgsm002.acgtbs12_pessoa.no_arquivo IS 'Define o nome do arquivo utilizado na importação do registro';
COMMENT ON COLUMN acgsm002.acgtbs12_pessoa.ts_processamento IS 'Define a data e hora do processamento das informações';

/*==============================================================*/
/* Table: acgsm001.acgtb003_pessoa                            */
/*==============================================================*/
alter table acgsm001.acgtb003_pessoa add column vr_faturamento_fiscal numeric(15,2);
COMMENT ON COLUMN acgsm001.acgtb003_pessoa.vr_faturamento_fiscal 
IS 'Armazena o valor do faturamento da empresa informado via carga.';


/*==============================================================*/
/* Table: acgsm002.acgtbs04_aplicacao                           */
/*==============================================================*/
alter table acgsm002.acgtbs04_aplicacao alter column co_contrato type character varying(20); 
alter table acgsm002.acgtbs04_aplicacao alter column no_cliente type character varying(50); 
alter table acgsm002.acgtbs04_aplicacao add column ic_tipo_pessoa integer;
alter table acgsm002.acgtbs04_aplicacao add column co_garantia_bacen integer;
alter table acgsm002.acgtbs04_aplicacao add column co_dv_garantia_bacen integer;

COMMENT ON COLUMN acgsm002.acgtbs04_aplicacao.ic_tipo_pessoa 
IS 'Informa qual é o tipo de pessoa: 1 se for CPF, 
2 se for CNPJ, 
3 se for PF no exterior,  
4 se for PJ no exterior, 
5 se for PF Sem Identificação, 
6 se for PJ sem identificação.';

COMMENT ON COLUMN acgsm002.acgtbs04_aplicacao.co_garantia_bacen 
IS 'Define o código da Garantia BACEN do Contrato';

COMMENT ON COLUMN acgsm002.acgtbs04_aplicacao.co_dv_garantia_bacen 
IS 'Define o dígito verficiador da Garantia BACEN';


/*==============================================================*/
/* Table: acgsm002.acgtbs11_garantia                            */
/*==============================================================*/

create table acgsm002.acgtbs11_garantia (
	co_contrato character varying(20),
	co_produto character varying(4),
	ic_tp_garantia integer,
	ic_tp_pessoa integer,
	co_identificador_pessoa character varying(14),
	no_pessoa character varying(50),
	nu_garantia integer,
	nu_dv_garantia integer,
	vr_garantia numeric(15,2),
	ic_caracteristica_garantia character(2),
	ic_forma_garantia character(2),
	vr_forma_garantia numeric(15,2),
	dt_reavaliacao date,
	vr_reavaliacao numeric(15,2),
	co_sistema_origem character varying(4),
	no_arquivo text,
	ts_processamento timestamp without time zone,
	ts_grupo_processamento timestamp without time zone
);

COMMENT ON TABLE acgsm002.acgtbs11_garantia
  IS 'Tabela de Stage Area que armazena as informações de garantias após a definição do leiaute único.';
COMMENT ON COLUMN acgsm002.acgtbs11_garantia.co_contrato IS 'Define o identificador do contrato incluindo o dígito verificador';
COMMENT ON COLUMN acgsm002.acgtbs11_garantia.co_produto IS 'Define o código do produto conforme tabela SIICO';
COMMENT ON COLUMN acgsm002.acgtbs11_garantia.ic_tp_garantia IS 'Define o tipo de garantia, podendo ser:
1 - Garantias Reais,
2 - Garantias Fidejussórias,
3 - Outros';
COMMENT ON COLUMN acgsm002.acgtbs11_garantia.ic_tp_pessoa IS 'Define o tipo da pessoa, podendo ser:
1 - CPF (Pessoa Física),
2 - CNPJ (Pessoa Jurídica)';
COMMENT ON COLUMN acgsm002.acgtbs11_garantia.co_identificador_pessoa IS 'Define o identificador da pessoa (CPF/CNPJ), como os dígitos verificadores';
COMMENT ON COLUMN acgsm002.acgtbs11_garantia.no_pessoa IS 'Define o nome/razão social da pessoa';
COMMENT ON COLUMN acgsm002.acgtbs11_garantia.nu_garantia IS 'Define o código da garantia BACEN do contrato';
COMMENT ON COLUMN acgsm002.acgtbs11_garantia.nu_dv_garantia IS 'Define o dígito da garantia BACEN do contrato';
COMMENT ON COLUMN acgsm002.acgtbs11_garantia.vr_garantia IS 'Define o valor da garantia BACEN do contrato';
COMMENT ON COLUMN acgsm002.acgtbs11_garantia.ic_caracteristica_garantia IS 'Define a característica da garantia, podendo ser:
1 - Fluxo,
2 - Estoque,
3 - Não é o Caso';
COMMENT ON COLUMN acgsm002.acgtbs11_garantia.ic_forma_garantia IS 'Define a fórmula matemática que irá gerar o valor da garantia pacutada no contrato, podendo ser:
1 - Saldo Devedor,
2 - Valor da Prestação (PMT),
3 - Valor do Contrato';
COMMENT ON COLUMN acgsm002.acgtbs11_garantia.vr_forma_garantia IS 'Define a porcentagem da primeira forma de garantia praticada no contrato. Essa porcentagem incide sobre a forma de garantia';
COMMENT ON COLUMN acgsm002.acgtbs11_garantia.dt_reavaliacao IS 'Define a data de reavaliação da garantia';
COMMENT ON COLUMN acgsm002.acgtbs11_garantia.vr_reavaliacao IS 'Define o valor da garantia na data de reavaliação';
COMMENT ON COLUMN acgsm002.acgtbs11_garantia.co_sistema_origem IS 'Define o código do sistema conforme tabela SIICO';
COMMENT ON COLUMN acgsm002.acgtbs11_garantia.no_arquivo IS 'Define o nome do arquivo utilizado na importação do registro';
COMMENT ON COLUMN acgsm002.acgtbs11_garantia.ts_processamento IS 'Define a data e hora do processamento das informações';
COMMENT ON COLUMN acgsm002.acgtbs11_garantia.no_arquivo IS 'Define o nome do arquivo utilizado na importação do registro';

drop table acgsm002.acgtbs11_garantia;

/*==============================================================*/
/* Table: acgsm002.acgtbs01_contrato                            */
/*==============================================================*/

alter table acgsm002.acgtbs01_contrato add column dt_reavaliacao date;
alter table acgsm002.acgtbs01_contrato add column vr_reavaliacao numeric(15,2);
alter table acgsm002.acgtbs01_contrato add column ic_caracteristica_garantia character(2);
alter table acgsm002.acgtbs01_contrato add column ic_forma_garantia character(2);
alter table acgsm002.acgtbs01_contrato add column vr_forma_garantia numeric(15,2);
alter table acgsm002.acgtbs01_contrato add column nu_dv_garantia integer;
alter table acgsm002.acgtbs01_contrato add column ic_tp_garantia integer;
alter table acgsm002.acgtbs01_contrato add column ic_tp_cliente integer;


COMMENT ON COLUMN acgsm002.acgtbs01_contrato.dt_reavaliacao IS 'Define a data de reavaliação da garantia';
COMMENT ON COLUMN acgsm002.acgtbs01_contrato.vr_reavaliacao IS 'Define o valor da garantia na data de reavaliação';
COMMENT ON COLUMN acgsm002.acgtbs01_contrato.ic_caracteristica_garantia IS 'Define a característica da garantia, podendo ser:
1 - Fluxo,
2 - Estoque,
3 - Não é o Caso';
COMMENT ON COLUMN acgsm002.acgtbs01_contrato.ic_forma_garantia IS 'Define a fórmula matemática que irá gerar o valor da garantia pacutada no contrato, podendo ser:
1 - Saldo Devedor,
2 - Valor da Prestação (PMT),
3 - Valor do Contrato';
COMMENT ON COLUMN acgsm002.acgtbs01_contrato.vr_forma_garantia IS 'Define a porcentagem da primeira forma de garantia praticada no contrato. Essa porcentagem incide sobre a forma de garantia';
COMMENT ON COLUMN acgsm002.acgtbs01_contrato.nu_dv_garantia IS 'Define o dígito da garantia BACEN do contrato';
COMMENT ON COLUMN acgsm002.acgtbs01_contrato.ic_tp_garantia IS 'Define o tipo de garantia, podendo ser:
1 - Garantias Reais,
2 - Garantias Fidejussórias,
3 - Outros';

COMMENT ON COLUMN acgsm002.acgtbs01_contrato.ic_tp_cliente IS 'Informa qual é o tipo de pessoa: 1 se for CPF, 
2 se for CNPJ, 
3  se for PF no exterior,  
4 se for PJ no exterior, 
5 se for PF Sem Identificação, 
6 se for PJ sem identificação.';

/*==============================================================*/
/* Table: acgsm001.acgtb009_garantia_contrato                   */
/*==============================================================*/

alter table acgsm001.acgtb009_garantia_contrato add column dt_reavaliacao date;
alter table acgsm001.acgtb009_garantia_contrato add column vr_reavaliacao numeric(15,2);

COMMENT ON COLUMN acgsm001.acgtb009_garantia_contrato.dt_reavaliacao IS 'Define a data de reavaliação da garantia';
COMMENT ON COLUMN acgsm001.acgtb009_garantia_contrato.vr_reavaliacao IS 'Define o valor da garantia na data de reavaliação';

/*==============================================================*/
/* Table: acgsm002.acgtbs13_veiculo                            */
/*==============================================================*/
create table acgsm002.acgtbs13_veiculo (
	co_contrato character varying(20),
	co_produto character varying(4),
	co_garantia_bacen integer,
	co_dv_garantia_bacen integer,
	ic_tp_cliente integer,
	co_identificador_cliente character varying(14),
	no_cliente character varying(50),
	no_marca character varying(30),
	no_modelo character varying(30),
	no_tipo_veiculo character varying(20),
	no_categoria character varying(20),
	dt_fabricacao date,
	dt_modelo_veiculo date,
	ic_zero_km integer,
	no_cor character varying(20),
	co_renavam character varying(30),
	co_chassi character varying(30),
	ic_tp_chassi integer,
	co_uf_licenciamento character varying(2),
	co_uf_veiculo character varying(2),
	co_placa character varying(10),
	ic_tp_vendedor integer,
	co_identificador_vendedor character varying(14),
	no_vendedor character varying(50),
	ic_restricao integer,
	vr_tabela_fipe numeric(15,2),
	co_tabela_fipe character varying(15),
	vr_veiculo numeric(15,2),
	vr_percenutal_quota numeric(15,2),
	co_sistema_origem character varying(4),
	no_arquivo text,
	ts_processamento timestamp without time zone,
	ts_grupo_processamento timestamp without time zone
);


COMMENT ON TABLE acgsm002.acgtbs13_veiculo
  IS 'Tabela de Stage Area que armazena as informações de veículo originadas do SIEMP após a definição do leiaute único.';

COMMENT ON COLUMN acgsm002.acgtbs13_veiculo.co_contrato IS 'Define a identificaçao do contrato incluindo o dígito verificador.';
COMMENT ON COLUMN acgsm002.acgtbs13_veiculo.co_produto IS 'Define o código do Produto conforme tabela SIICO';
COMMENT ON COLUMN acgsm002.acgtbs13_veiculo.co_garantia_bacen IS 'Define o código da Garantia BACEN do Contrato';
COMMENT ON COLUMN acgsm002.acgtbs13_veiculo.co_dv_garantia_bacen IS 'Define o dígito verficiador da Garantia BACEN';
COMMENT ON COLUMN acgsm002.acgtbs13_veiculo.ic_tp_cliente IS 'Informa qual é o tipo de pessoa: 1 se for CPF, 
2 se for CNPJ';
COMMENT ON COLUMN acgsm002.acgtbs13_veiculo.co_identificador_cliente IS 'Define o identificador do cliente (CPF/CNPJ), como os dígitos verificadores';
COMMENT ON COLUMN acgsm002.acgtbs13_veiculo.no_cliente IS 'Define o nome/razão social do cliente';
COMMENT ON COLUMN acgsm002.acgtbs13_veiculo.no_marca IS 'Define a marca do veículo conforme padrão utilizado pelo SIEMP.';
COMMENT ON COLUMN acgsm002.acgtbs13_veiculo.no_modelo IS 'Define o modelo do veículo conforme padrão utilizado pelo SIEMP.';
COMMENT ON COLUMN acgsm002.acgtbs13_veiculo.no_tipo_veiculo IS 'Define o tipo do veículo conforme padrão utilizado pelo SIEMP.';
COMMENT ON COLUMN acgsm002.acgtbs13_veiculo.no_categoria IS 'Define a categoria do veículo conforme padrão utilizado pelo SIEMP.';
COMMENT ON COLUMN acgsm002.acgtbs13_veiculo.dt_fabricacao IS 'Define a data de fabricação do veículo';
COMMENT ON COLUMN acgsm002.acgtbs13_veiculo.dt_modelo_veiculo IS 'Define a data do modelo do veículo';
COMMENT ON COLUMN acgsm002.acgtbs13_veiculo.ic_zero_km IS 'Define se o veículo é zero km:
1 - Sim,
2 - Não';
COMMENT ON COLUMN acgsm002.acgtbs13_veiculo.no_cor IS 'Define a cor do veículo';
COMMENT ON COLUMN acgsm002.acgtbs13_veiculo.co_renavam IS 'Define o código do Renavam do veículo';
COMMENT ON COLUMN acgsm002.acgtbs13_veiculo.co_chassi IS 'Define o código do chassi do veículo';
COMMENT ON COLUMN acgsm002.acgtbs13_veiculo.ic_tp_chassi IS 'Define o tipo de chassi do veículo:
1 - Remarcado
2 - Normal';
COMMENT ON COLUMN acgsm002.acgtbs13_veiculo.co_uf_licenciamento IS 'Define a sigla do estado de licenciamento';
COMMENT ON COLUMN acgsm002.acgtbs13_veiculo.co_uf_veiculo IS 'Define a sigla do estado do veículo';
COMMENT ON COLUMN acgsm002.acgtbs13_veiculo.co_placa IS 'Define a placa do veículo';
COMMENT ON COLUMN acgsm002.acgtbs13_veiculo.co_chassi IS 'Define o código do chassi do veículo';
COMMENT ON COLUMN acgsm002.acgtbs13_veiculo.ic_tp_vendedor IS 'Informa qual é o tipo de pessoa: 1 se for CPF, 
2 se for CNPJ';
COMMENT ON COLUMN acgsm002.acgtbs13_veiculo.co_identificador_vendedor IS 'Define o identificador do vendedor (CPF/CNPJ), como os dígitos verificadores';
COMMENT ON COLUMN acgsm002.acgtbs13_veiculo.no_vendedor IS 'Define o nome/razão social do vendedor';
COMMENT ON COLUMN acgsm002.acgtbs13_veiculo.ic_restricao IS 'Define o tipo de restrição do veículo:
1 - Arrendamento Mercantil / Leasing
2 - Reserva de Domínio
3 - Alienação Fiduciária
4 - Penhor';
COMMENT ON COLUMN acgsm002.acgtbs13_veiculo.vr_tabela_fipe IS 'Define o valor do veículo conforme tabela FIPE';
COMMENT ON COLUMN acgsm002.acgtbs13_veiculo.co_tabela_fipe IS 'Define o código do veículo na tabela FIPE';
COMMENT ON COLUMN acgsm002.acgtbs13_veiculo.vr_veiculo IS 'Define o valor do veículo';
COMMENT ON COLUMN acgsm002.acgtbs13_veiculo.vr_percenutal_quota IS 'Define o percentual de financiamento do carro';
COMMENT ON COLUMN acgsm002.acgtbs13_veiculo.co_sistema_origem IS 'Define o código do sistema conforme tabela SIICO';
COMMENT ON COLUMN acgsm002.acgtbs13_veiculo.no_arquivo IS 'Define o nome do arquivo utilizado na importação do registro';
COMMENT ON COLUMN acgsm002.acgtbs13_veiculo.ts_processamento IS 'Define a data e hora do processamento das informações';


/*==============================================================*/
/* Table: acgsm001.acgtb075_veiculo                             */
/*==============================================================*/
alter table acgsm001.acgtb075_veiculo add column ic_origem integer not null default 1;
alter table acgsm001.acgtb075_veiculo add column vr_tabela_fipe numeric(15,2);
alter table acgsm001.acgtb075_veiculo add column co_tabela_fipe character varying(15);
alter table acgsm001.acgtb075_veiculo alter column  nu_veiculo set DEFAULT nextval('acgsm001.acgsq075_veiculo'::regclass);

COMMENT ON COLUMN acgsm001.acgtb075_veiculo.ic_origem IS 'Define a origem do registro: 1 - ETL, 2 - API';
COMMENT ON COLUMN acgsm001.acgtb075_veiculo.vr_tabela_fipe IS 'Define o valor do veículo conforme tabela FIPE';
COMMENT ON COLUMN acgsm001.acgtb075_veiculo.co_tabela_fipe IS 'Define o código do veículo na tabela FIPE';


/*==============================================================*/
/* Table: acgsm002.acgtbs14_maquina_equipamento                 */
/*==============================================================*/
create table acgsm002.acgtbs14_maquina_equipamento (
	co_contrato character varying(20),
	co_produto character varying(4),
	co_garantia_bacen integer,
	co_dv_garantia_bacen integer,
	nu_qtd_bem integer,
	de_tipo_bem character varying(40),
	de_bem character varying(100),
	dt_fabricacao date,
	co_numero_serie character varying(20),
	co_numero_chassi character varying(20),
	ic_tp_identificacao_bem integer,
	ic_estado_bem integer,
	ic_tp_documento integer,
	dt_nota_fiscal date,
	ic_tp_cliente integer,
	co_identificador_cliente character varying(14),
	no_cliente character varying(50),
	vr_maquina numeric(15,2),
	co_sistema_origem character varying(4),
	no_arquivo text,
	ts_processamento timestamp without time zone,
	ts_grupo_processamento timestamp without time zone
);

COMMENT ON TABLE acgsm002.acgtbs14_maquina_equipamento IS 'Tabela de Stage Area que armazena as informações de máquinas/equipamento após a definição do leiaute único.';

COMMENT ON COLUMN acgsm002.acgtbs14_maquina_equipamento.co_contrato IS 'Define a identificaçao do contrato incluindo o dígito verificador.';
COMMENT ON COLUMN acgsm002.acgtbs14_maquina_equipamento.co_produto IS 'Define o código do Produto conforme tabela SIICO';
COMMENT ON COLUMN acgsm002.acgtbs14_maquina_equipamento.co_garantia_bacen IS 'Define o código da Garantia BACEN do Contrato';
COMMENT ON COLUMN acgsm002.acgtbs14_maquina_equipamento.co_dv_garantia_bacen IS 'Define o dígito verficiador da Garantia BACEN';
COMMENT ON COLUMN acgsm002.acgtbs14_maquina_equipamento.nu_qtd_bem IS 'Informa a quantidade de máquinas e/ou equipamentos que estão relacionadas a garantia';
COMMENT ON COLUMN acgsm002.acgtbs14_maquina_equipamento.de_tipo_bem IS 'Enquadra o bem em grupo de classificação a ser definido com a GEGAR e a área de produtos';
COMMENT ON COLUMN acgsm002.acgtbs14_maquina_equipamento.de_bem IS 'Define a descrição do bem.';
COMMENT ON COLUMN acgsm002.acgtbs14_maquina_equipamento.dt_fabricacao IS 'Define a data de fabricação do bem';
COMMENT ON COLUMN acgsm002.acgtbs14_maquina_equipamento.co_numero_serie IS 'Define o número de série do bem do cliente';
COMMENT ON COLUMN acgsm002.acgtbs14_maquina_equipamento.co_numero_chassi IS 'Define o número do chassi do bem do cliente';
COMMENT ON COLUMN acgsm002.acgtbs14_maquina_equipamento.ic_tp_identificacao_bem IS 'Define o tipo de identificação do bem, podendo ser: 1 - Número de Série, 2 - Chassi';
COMMENT ON COLUMN acgsm002.acgtbs14_maquina_equipamento.ic_estado_bem IS 'Define o estado do bem, podendo ser: 1 - Novo, 2 - Usado';
COMMENT ON COLUMN acgsm002.acgtbs14_maquina_equipamento.ic_tp_documento IS 'Define o tipo de documento comprobatório do bem, podendo ser: 1 - Nota Fiscal, 2 - Laudo de Avaliação';
COMMENT ON COLUMN acgsm002.acgtbs14_maquina_equipamento.dt_nota_fiscal IS 'Define a data da nota fiscal ou do laudo em que foi avaliado o valor do bem';
COMMENT ON COLUMN acgsm002.acgtbs14_maquina_equipamento.ic_tp_cliente IS 'Informa qual é o tipo de pessoa: 1 se for CPF, 2 se for CNPJ';
COMMENT ON COLUMN acgsm002.acgtbs14_maquina_equipamento.co_identificador_cliente IS 'Define o identificador do cliente (CPF/CNPJ), como os dígitos verificadores';
COMMENT ON COLUMN acgsm002.acgtbs14_maquina_equipamento.no_cliente IS 'Define o nome/razão social do cliente';
COMMENT ON COLUMN acgsm002.acgtbs14_maquina_equipamento.vr_maquina IS 'Define o valor da máquina/equipamento';
COMMENT ON COLUMN acgsm002.acgtbs14_maquina_equipamento.co_sistema_origem IS 'Define o código do sistema conforme tabela SIICO';
COMMENT ON COLUMN acgsm002.acgtbs14_maquina_equipamento.no_arquivo IS 'Define o nome do arquivo utilizado na importação do registro';
COMMENT ON COLUMN acgsm002.acgtbs14_maquina_equipamento.ts_processamento IS 'Define a data e hora do processamento das informações';

/*==============================================================*/
/* Table: acgsm001.acgtb077_maquina_equipamento                 */
/*==============================================================*/
alter table acgsm001.acgtb077_maquina_equipamento add column nu_qtd_bem integer;
alter table acgsm001.acgtb077_maquina_equipamento add column de_bem character varying(100);
alter table acgsm001.acgtb077_maquina_equipamento add column vr_maquina numeric(15,2);
alter table acgsm001.acgtb077_maquina_equipamento add column ic_origem integer NOT NULL DEFAULT 1;
 
COMMENT ON COLUMN acgsm001.acgtb077_maquina_equipamento.nu_qtd_bem IS 'Informa a quantidade de máquinas e/ou equipamentos que estão relacionadas a garantia';
COMMENT ON COLUMN acgsm001.acgtb077_maquina_equipamento.de_bem IS 'Define a descrição do bem.';
COMMENT ON COLUMN acgsm001.acgtb077_maquina_equipamento.vr_maquina IS 'Define o valor da máquina/equipamento';
COMMENT ON COLUMN acgsm001.acgtb077_maquina_equipamento.ic_origem IS 'Define a origem do registro: 1 - ETL, 2 - API';

/*==============================================================*/
/* Table: acgsm002.acgtb081_imovel                              */
/*==============================================================*/

CREATE TABLE acgsm002.acgtbs15_imovel(
	co_contrato character varying(20),
	co_produto character varying(4),
	co_garantia_bacen integer,
	co_dv_garantia_bacen integer,
	ic_tp_cliente integer,
	co_identificador_cliente character varying(14),
	no_cliente character varying(50),
	vr_imovel numeric(16,2),
	no_cartorio character varying(50),
	co_cns character varying(6),
	sg_uf_cartorio character varying(6),
	de_municipio_cartorio character varying(30),
	nu_matricula bigint,
	co_livro_serventia integer,
	co_registro character varying(3),
	dt_registro date,
	co_cnm character varying(15),
	co_dv_cnm character varying(2),
	co_tipo_logradouro character varying(3),
	no_logradouro character varying(100),
	nu_logradouro character varying(5),
	no_complemento character varying(100),
	no_bairro character varying(50),
	no_municipio character varying(50),
	no_uf character varying(2),
	nu_cep character varying(10),
	nu_uso_imovel smallint,
	nu_categoria_imovel smallint,
	nu_tipo_implantacao smallint,
	vr_area_total numeric(16,2),
	vr_area_privativa numeric(16,2),
	vr_area_terreno numeric(16,2),
	vr_area_testada numeric(16,2),
	qt_dormitorio integer,
	qt_vagas_garagem integer,
	nu_estado_cnsro_condominio smallint,
	nu_estado_conservacao_imovel smallint,
	nu_padrao_acabamento smallint,
	vr_avaliacao numeric(16,2),
	dt_avaliacao date,
	co_avaliacao_consessao character varying(20),
	co_sistema_origem character varying(4),
	no_arquivo text,
	ts_processamento timestamp without time zone,
	ts_grupo_processamento timestamp without time zone	
);

COMMENT ON TABLE acgsm002.acgtbs15_imovel
  IS 'Tabela de Stage Area que armazena as informações de imóvel após a definição do leiaute único.';
COMMENT ON COLUMN acgsm002.acgtbs15_imovel.co_contrato IS 'Define a identificaçao do contrato incluindo o dígito verificador.';
COMMENT ON COLUMN acgsm002.acgtbs15_imovel.co_produto IS 'Define o código do Produto conforme tabela SIICO';
COMMENT ON COLUMN acgsm002.acgtbs15_imovel.co_garantia_bacen IS 'Define o código da Garantia BACEN do Contrato';
COMMENT ON COLUMN acgsm002.acgtbs15_imovel.co_dv_garantia_bacen IS 'Informa qual é o tipo de pessoa: 1 se for CPF, 2 se for CNPJ';
COMMENT ON COLUMN acgsm002.acgtbs15_imovel.ic_tp_cliente IS 'Define a identificaçao do contrato incluindo o dígito verificador.';
COMMENT ON COLUMN acgsm002.acgtbs15_imovel.co_identificador_cliente IS 'Define o identificador do cliente (CPF/CNPJ), como os dígitos verificadores';
COMMENT ON COLUMN acgsm002.acgtbs15_imovel.no_cliente IS 'Define o nome/razão social do cliente';
COMMENT ON COLUMN acgsm002.acgtbs15_imovel.vr_imovel IS 'Valor do imóvel na contratação.';
COMMENT ON COLUMN acgsm002.acgtbs15_imovel.no_cartorio IS 'Nome do cartorio de registro do imóvel.';
COMMENT ON COLUMN acgsm002.acgtbs15_imovel.co_cns IS 'Descreve ao Cadastro Nacional de Serventias';
COMMENT ON COLUMN acgsm002.acgtbs15_imovel.sg_uf_cartorio IS 'Define a sigla da unidade federativa.';
COMMENT ON COLUMN acgsm002.acgtbs15_imovel.de_municipio_cartorio IS 'Define a descrição do municipio';
COMMENT ON COLUMN acgsm002.acgtbs15_imovel.nu_matricula IS 'Define o número de matrícula do imóvel.';
COMMENT ON COLUMN acgsm002.acgtbs15_imovel.co_livro_serventia IS 'Define o código do livro de serventia.';
COMMENT ON COLUMN acgsm002.acgtbs15_imovel.co_registro IS 'Define o código do registro da garantia.';
COMMENT ON COLUMN acgsm002.acgtbs15_imovel.dt_registro IS 'Define a data do registro da garantia.';
COMMENT ON COLUMN acgsm002.acgtbs15_imovel.co_cnm IS 'Define o Código Nacional de Matrícula do imóvel.';
COMMENT ON COLUMN acgsm002.acgtbs15_imovel.co_dv_cnm IS 'Define o dígito verificador do Código Nacional de Matrícula do imóvel.';
COMMENT ON COLUMN acgsm002.acgtbs15_imovel.co_tipo_logradouro IS 'Define o tipo do logradouro, podendo ser: 
	ACS - Acesso   
	AER - Aeroporto
	ALM - Alameda
	ARE - Área,
	ASS - Assentamento
	AVE - Avenida
	BAL - Balneário
	BEC - Beco
	CAI - Cais
	CAM - Caminho
	CPO - Campo
	COL - Colônia
	COM - Comunidade
	COR - Corredor
	DES - Desvio
	ESC - Escada
	ESQ - Esquina
	EST - Estrada
	ETC - Estação
	ETN - Estância
	FAZ - Fazenda
	GAL - Galeria
	GRJ - Granja
	HPD - Hipódromo
	ILH - Ilha
	JDM - Jardim
	LRG - Largo                    
	LAG - Lagoa                    
	LIN - Linha                    
	LOC - Localidade
	LOT - Loteamento
	MER - Mercado
	PAC - Paco
	PAS - Passeio
	PCA - Praça
	PIC - Picada
	POR - Porto
	PRA - Praia
	PRQ - Parque
	QDR - Quadra
	QTL - Quartel
	RDV - Rodoviária
	ROD - Rodovia
	RUA - Rua
	SQD - Super Quadra
	TRV - Travessão
	TRA - Travessa
	VDT - Viaduto
	VIA - Via
	VIE - Viela
	VIL - Vila                    
';
COMMENT ON COLUMN acgsm002.acgtbs15_imovel.no_logradouro IS 'Define o nome do logradouro.';
COMMENT ON COLUMN acgsm002.acgtbs15_imovel.nu_logradouro IS 'Define o número do logradouro.';
COMMENT ON COLUMN acgsm002.acgtbs15_imovel.no_complemento IS 'Define o complemento do imóvel.';
COMMENT ON COLUMN acgsm002.acgtbs15_imovel.no_bairro IS 'Define o bairro onde o imóvel está localizado.';
COMMENT ON COLUMN acgsm002.acgtbs15_imovel.no_municipio IS 'Define o nome do municipio onde o imóvel está localizado';
COMMENT ON COLUMN acgsm002.acgtbs15_imovel.no_uf IS 'Define a UF onde o imóvel está localizado.';
COMMENT ON COLUMN acgsm002.acgtbs15_imovel.nu_cep IS 'Define o CEP onde o imóvel está localizado.';
COMMENT ON COLUMN acgsm002.acgtbs15_imovel.nu_uso_imovel IS 'Define o tipo de uso do imóvel, podendo ser: 
1 - Residencial,
2 - Comercial, 
3 - Rural.';
COMMENT ON COLUMN acgsm002.acgtbs15_imovel.nu_categoria_imovel IS 'Define a categoria do imóvel, podendo ser:
1 - Casa, 
2 - Apartamento, 
3 - Lote, 
4 - Sala
5 - Terreno
';
COMMENT ON COLUMN acgsm002.acgtbs15_imovel.nu_tipo_implantacao IS 'Define o tiipo de implantação do imóvel, podendo ser: 
1 - Condomínio, 
2 - Isolado';
COMMENT ON COLUMN acgsm002.acgtbs15_imovel.vr_area_total IS 'Valor da área total do imóvel.';
COMMENT ON COLUMN acgsm002.acgtbs15_imovel.vr_area_privativa IS 'Valor da área privativa (área construida do imóvel).';
COMMENT ON COLUMN acgsm002.acgtbs15_imovel.vr_area_terreno IS 'Valor da área do terreno.';
COMMENT ON COLUMN acgsm002.acgtbs15_imovel.vr_area_testada IS 'Valor da Testada do terreno. Testada é a dimensão do terreno que corresponde à entrada da casa ou prédio.';
COMMENT ON COLUMN acgsm002.acgtbs15_imovel.vr_area_total IS 'Valor da área total do imóvel.';
COMMENT ON COLUMN acgsm002.acgtbs15_imovel.qt_dormitorio IS 'Define a quantidade de quartos.';
COMMENT ON COLUMN acgsm002.acgtbs15_imovel.qt_vagas_garagem IS 'Define a quantidade de vagas na garagem.';
COMMENT ON COLUMN acgsm002.acgtbs15_imovel.nu_estado_cnsro_condominio IS 'Define o estado de conservação do condomínio, podendo ser: 
1 - Bom, 
2 - Regular, 
3 - Ruim, 
4 - Em Construção.';
COMMENT ON COLUMN acgsm002.acgtbs15_imovel.nu_estado_conservacao_imovel IS 'Define o estado de conservação do imóvel, podendo ser: 
1 - Bom, 
2 - Regular, 
3 - Ruim, 
4 - Em Construção.';
COMMENT ON COLUMN acgsm002.acgtbs15_imovel.nu_padrao_acabamento IS 'Define o padrão de acabamento do imóvel, podendo ser: 
1 - Alto, 
2 - Normal, 
3 - Baixo, 
4 - Mínimo.';
COMMENT ON COLUMN acgsm002.acgtbs15_imovel.vr_avaliacao IS 'Valor da avaliação do imóvel pela engenharia Caixa';
COMMENT ON COLUMN acgsm002.acgtbs15_imovel.dt_avaliacao IS 'Data de avaliação do imóvel pela engenharia Caixa';
COMMENT ON COLUMN acgsm002.acgtbs15_imovel.co_avaliacao_consessao IS 'Código da avaliação pela engenharia na concessão.';
COMMENT ON COLUMN acgsm002.acgtbs15_imovel.co_sistema_origem IS 'Define o código do sistema conforme tabela SIICO';
COMMENT ON COLUMN acgsm002.acgtbs15_imovel.no_arquivo IS 'Define o nome do arquivo utilizado na importação do registro';
COMMENT ON COLUMN acgsm002.acgtbs15_imovel.ts_processamento IS 'Define a data e hora do processamento das informações';

/*==============================================================*/
/* Table: acgsm001.acgtb081_imovel                              */
/*==============================================================*/
alter table acgsm001.acgtb081_imovel add column ic_origem integer NOT NULL DEFAULT 1;

COMMENT ON COLUMN acgsm001.acgtb081_imovel.ic_origem IS 'Define a origem do registro: 1 - ETL, 2 - API';

/*==============================================================*/
/* Table: acgsm001.acgtbs16_produto_agricola                    */
/*==============================================================*/

create table acgsm002.acgtbs16_produto_agricola (
	co_contrato character varying(20),
	co_produto character varying(4),
	co_garantia_bacen integer,
	co_dv_garantia_bacen integer,
	ic_tp_cliente integer,
	co_identificador_cliente character varying(14),
	no_cliente character varying(50),
	no_modalidade character varying(70),
	de_bem character varying(100),
	dt_avaliacao date,
	de_qtd_bem character varying(20),
	vr_produto_agricola numeric(15,2),
	co_sistema_origem character varying(4),
	no_arquivo text,
	ts_processamento timestamp without time zone,
	ts_grupo_processamento timestamp without time zone
);

COMMENT ON TABLE acgsm002.acgtbs16_produto_agricola IS 'Tabela de Stage Area que armazena as informações de produtos agrícolas após a definição do leiaute único.';
COMMENT ON COLUMN acgsm002.acgtbs16_produto_agricola.co_contrato IS 'Define a identificaçao do contrato incluindo o dígito verificador.';
COMMENT ON COLUMN acgsm002.acgtbs16_produto_agricola.co_produto IS 'Define o código do Produto conforme tabela SIICO';
COMMENT ON COLUMN acgsm002.acgtbs16_produto_agricola.co_garantia_bacen IS 'Define o código da Garantia BACEN do Contrato';
COMMENT ON COLUMN acgsm002.acgtbs16_produto_agricola.co_dv_garantia_bacen IS 'Define o dígito verficiador da Garantia BACEN';
COMMENT ON COLUMN acgsm002.acgtbs16_produto_agricola.ic_tp_cliente IS 'Informa qual é o tipo de pessoa: 1 se for CPF, 2 se for CNPJ';
COMMENT ON COLUMN acgsm002.acgtbs16_produto_agricola.co_identificador_cliente IS 'Define o identificador do cliente (CPF/CNPJ), como os dígitos verificadores';
COMMENT ON COLUMN acgsm002.acgtbs16_produto_agricola.no_cliente IS 'Define o nome/razão social do cliente';
COMMENT ON COLUMN acgsm002.acgtbs16_produto_agricola.no_modalidade IS 'Define a modalidade do produto quando a garantia for 322 - Penhor de Produto Agropecuário sem Warrant';
COMMENT ON COLUMN acgsm002.acgtbs16_produto_agricola.de_bem IS 'Define a descrição do bem.';
COMMENT ON COLUMN acgsm002.acgtbs16_produto_agricola.dt_avaliacao IS 'Define a data de avaliação do bem';
COMMENT ON COLUMN acgsm002.acgtbs16_produto_agricola.de_qtd_bem IS 'Informa a quantidade do bem Informar a quantidade do bem (hectares, quantidades de grãos, cabeça de gados, etc.)';
COMMENT ON COLUMN acgsm002.acgtbs16_produto_agricola.vr_produto_agricola IS 'Define o valor da garantia do bem';
COMMENT ON COLUMN acgsm002.acgtbs16_produto_agricola.co_sistema_origem IS 'Define o código do sistema conforme tabela SIICO';
COMMENT ON COLUMN acgsm002.acgtbs16_produto_agricola.no_arquivo IS 'Define o nome do arquivo utilizado na importação do registro';
COMMENT ON COLUMN acgsm002.acgtbs16_produto_agricola.ts_processamento IS 'Define a data e hora do processamento das informações';


/*==============================================================*/
/* Table: acgsm001.acgtb079_produto_agricola                    */
/*==============================================================*/

alter table acgsm001.acgtb079_produto_agricola add column no_modalidade character varying(70);
alter table acgsm001.acgtb079_produto_agricola add column de_bem character varying(100);
alter table acgsm001.acgtb079_produto_agricola add column dt_avaliacao date;
alter table acgsm001.acgtb079_produto_agricola add column de_qtd_bem character varying(20);
alter table acgsm001.acgtb079_produto_agricola add column vr_produto_agricola numeric(15,2);
alter table acgsm001.acgtb079_produto_agricola add column ic_origem integer NOT NULL DEFAULT 1;
 
COMMENT ON COLUMN acgsm001.acgtb079_produto_agricola.no_modalidade IS 'Define a modalidade do produto quando a garantia for 322 - Penhor de Produto Agropecuário sem Warrant';
COMMENT ON COLUMN acgsm001.acgtb079_produto_agricola.de_bem IS 'Define a descrição do bem.';
COMMENT ON COLUMN acgsm001.acgtb079_produto_agricola.dt_avaliacao IS 'Define a data de avaliação do bem';
COMMENT ON COLUMN acgsm001.acgtb079_produto_agricola.de_qtd_bem IS 'Informa a quantidade do bem Informar a quantidade do bem (hectares, quantidades de grãos, cabeça de gados, etc.)';
COMMENT ON COLUMN acgsm001.acgtb079_produto_agricola.vr_produto_agricola IS 'Define o valor da garantia do bem';
COMMENT ON COLUMN acgsm001.acgtb079_produto_agricola.ic_origem IS 'Define a origem do registro: 1 - ETL, 2 - API';

/*==============================================================*/
/* Table: acgsm001.acgtb106_bem_cliente                         */
/*==============================================================*/
alter table acgsm001.acgtb106_bem_cliente add column nu_produto_agricola integer;
alter table acgsm001.acgtb106_bem_cliente add CONSTRAINT fk_acgtb106_acgtb079 FOREIGN KEY (nu_produto_agricola)
      REFERENCES acgsm001.acgtb079_produto_agricola (nu_produto_agricola) MATCH SIMPLE ON UPDATE RESTRICT ON DELETE RESTRICT;

ALTER TABLE acgsm001.acgtb106_bem_cliente DROP CONSTRAINT ckc_acgtb106_01;
ALTER TABLE acgsm001.acgtb106_bem_cliente ADD CONSTRAINT ckc_acgtb106_01 CHECK (ic_tipo_bem = ANY (ARRAY[1, 2, 3, 4]));

COMMENT ON COLUMN acgsm001.acgtb106_bem_cliente.ic_tipo_bem IS 'Define o tipo do bem, podendo ser:
1 - Imóveis
2 - Maquinas e Equipamentos,
3 - Veículos,
4 - Produtos Agrícolas';


/*==============================================================*/
/* Table: acgsm001.acgtbs01_contrato                            */
/*==============================================================*/
alter table acgsm002.acgtbs01_contrato add column nu_proposta varchar(20);
alter table acgsm002.acgtbs01_contrato add column dt_liquidacao date;
alter table acgsm002.acgtbs01_contrato add column dt_renovacao date;
alter table acgsm002.acgtbs01_contrato add column modalidade_operacao varchar(4);
alter table acgsm002.acgtbs01_contrato add column dt_saldo_devedor date;
alter table acgsm002.acgtbs01_contrato add column dt_ult_renegociacao date;
alter table acgsm002.acgtbs01_contrato add column tp_renegociacao varchar(2);
alter table acgsm002.acgtbs01_contrato add column dt_venc_primeira_parcela date;
alter table acgsm002.acgtbs01_contrato add column dt_vencimento date;
alter table acgsm002.acgtbs01_contrato add column lmt_conta_sidec numeric(16,2);
alter table acgsm002.acgtbs01_contrato add column lmt_conta_nsgd numeric (16,2);
alter table acgsm002.acgtbs01_contrato add column co_conta_corrente_nsgd varchar(22);
alter table acgsm002.acgtbs01_contrato add column dt_movimento date;
alter table acgsm002.acgtbs01_contrato add column dt_geracao date;
alter table acgsm002.acgtbs01_contrato add column co_sistema_origem varchar(4);


COMMENT ON COLUMN acgsm002.acgtbs01_contrato.nu_proposta IS 'Código SIICO do produto ';
COMMENT ON COLUMN acgsm002.acgtbs01_contrato.dt_liquidacao IS 'Data da liquidação do contrato';
COMMENT ON COLUMN acgsm002.acgtbs01_contrato.dt_renovacao  IS 'Data da renovação do contrato ';
COMMENT ON COLUMN acgsm002.acgtbs01_contrato.modalidade_operacao IS 'Modalidade da operação de crédito, se não existir será 0000.';
COMMENT ON COLUMN acgsm002.acgtbs01_contrato.dt_saldo_devedor IS 'Data do saldo devedor do contrato';
COMMENT ON COLUMN acgsm002.acgtbs01_contrato.dt_ult_renegociacao IS 'Data da ultima renegociação do contrato';
COMMENT ON COLUMN acgsm002.acgtbs01_contrato.tp_renegociacao IS 'Tipo de renegociação: \n
01 - Operação nova
02 - Composição de dividas
03 - Prorrogação
04 - Novação
05 - Concessão de nova operação para liquidação parcial ou integral da operação anterior
06 - Acordo que implique alteraçã dos prqazo de vencimento ou nas condições de pagamento originalmente pactuadas';
COMMENT ON COLUMN acgsm002.acgtbs01_contrato.dt_venc_primeira_parcela IS 'Data de vencimento da primeira parcela do contrato';
COMMENT ON COLUMN acgsm002.acgtbs01_contrato.dt_vencimento IS 'Data do vencimento do contrato';
COMMENT ON COLUMN acgsm002.acgtbs01_contrato.lmt_conta_sidec IS 'Limite do Cheque Especial ou Conta Garantida (CROT) da conta SIDEC';
COMMENT ON COLUMN acgsm002.acgtbs01_contrato.lmt_conta_nsgd IS 'Limite do Cheque Especial ou Conta Garantida (CROT) da conta NSGD';
COMMENT ON COLUMN acgsm002.acgtbs01_contrato.co_conta_corrente_nsgd IS 'Numero da conta NSGD vinculada ao contrato.
Considerando o novo padrão do NSGD:
Deve ser informado no seguinte padrão: AAAAAPPPPCCCCCCCCCCCCD
onde:AAAAA - Código da Agência (5 posições).
PPPP - Código do Produto (4 posições) em substituição à operação do SIDEC.
CCCCCCCCCCCC – Campo conta (12 posições) – único na CAIXA e sequencial. 
D – Dígito verificador. 
Caso não exista preencher com zeros.';
COMMENT ON COLUMN acgsm002.acgtbs01_contrato.dt_movimento IS 'Data do movimento do arquivo.';
COMMENT ON COLUMN acgsm002.acgtbs01_contrato.dt_geracao IS 'Data da geração do arquivo.';


/*============================================================*/
/* Table: acgsm002.acgtbs08_duplicata                          */
/*============================================================*/

ALTER TABLE acgsm002.acgtbs08_duplicata 
ALTER COLUMN vr_titulo TYPE  numeric(13,2),
ALTER COLUMN vr_pago TYPE  numeric(13,2),
ALTER COLUMN co_cedente TYPE character varying(20);

COMMENT ON COLUMN acgsm002.acgtbs08_duplicata.sg_sistema_origem IS 'Sigla do sistema de origem das informações, ou: 1- SICOB; 2- SIGCB.';

ALTER TABLE acgsm002.acgtbs08_duplicata 
ADD COLUMN co_identificador_contrato character varying(20),
ADD COLUMN co_produto character varying(4), 
ADD COLUMN co_garantia_bacen character varying(4),
ADD COLUMN dv_garantia_bacen char(1),
ADD COLUMN pz_maximo_vencimento character varying(3),
ADD COLUMN vr_maximo_permitido numeric(13,2),
ADD COLUMN pc_maximo_concentracao character varying(8),
ADD COLUMN co_nosso_numero character varying(17),
ADD COLUMN co_agencia character varying(4),
ADD COLUMN co_operacao character varying(3),
ADD COLUMN co_conta character varying(22),
ADD COLUMN dv_conta char(1),
ADD COLUMN ic_cpf_cnpj_sacado char(1),
ADD COLUMN canal_recebimento_titulo character varying(4);


COMMENT ON COLUMN acgsm002.acgtbs08_duplicata.co_identificador_contrato IS 'Código identificador do contrato.';
COMMENT ON COLUMN acgsm002.acgtbs08_duplicata.co_produto IS 'Código do produto, conforme tabela SIICO.'; 
COMMENT ON COLUMN acgsm002.acgtbs08_duplicata.co_garantia_bacen IS 'Código da garantia BACEN do contrato.';
COMMENT ON COLUMN acgsm002.acgtbs08_duplicata.dv_garantia_bacen IS 'Dígito da garantia BACEN.';
COMMENT ON COLUMN acgsm002.acgtbs08_duplicata.pz_maximo_vencimento IS 'Prazo máximo de vencimento da duplicata para aceite como garantia do contrato.';
COMMENT ON COLUMN acgsm002.acgtbs08_duplicata.vr_maximo_permitido IS 'Valor máximo da duplicata para aceite como garantia do contrato.';
COMMENT ON COLUMN acgsm002.acgtbs08_duplicata.pc_maximo_concentracao IS 'Percentual máximo de concentração por sacado para que as duplicatas sejam aceitas como garantia do contrato.';
COMMENT ON COLUMN acgsm002.acgtbs08_duplicata.co_nosso_numero IS 'Código do Nosso Número sem o Dígito Verificador.';
COMMENT ON COLUMN acgsm002.acgtbs08_duplicata.co_agencia IS 'Código da agência da conta corrente.';
COMMENT ON COLUMN acgsm002.acgtbs08_duplicata.co_operacao IS 'Código da operação da conta corrente.';
COMMENT ON COLUMN acgsm002.acgtbs08_duplicata.co_conta IS 'Conta corrente vinculada ao contrato.';
COMMENT ON COLUMN acgsm002.acgtbs08_duplicata.dv_conta IS 'Dígito verificador da conta corrente.';
COMMENT ON COLUMN acgsm002.acgtbs08_duplicata.ic_cpf_cnpj_sacado IS 'Indicador: 1- CPF; 2- CNPJ.';
COMMENT ON COLUMN acgsm002.acgtbs08_duplicata.canal_recebimento_titulo IS 'Canal de recebimento do título.';


/*============================================================*/
/* Revert Tables                                              */
/*============================================================*/

--drop table acgsm002.acgtbs12_pessoa;
--alter table acgsm001.acgtb003_pessoa drop column vr_faturamento_fiscal;
--alter table acgsm002.acgtbs04_aplicacao alter column co_contrato type character varying(9); 
--alter table acgsm002.acgtbs04_aplicacao alter column no_cliente type character varying(32);  
--alter table acgsm002.acgtbs04_aplicacao drop column ic_tipo_pessoa;
--alter table acgsm002.acgtbs04_aplicacao drop column co_garantia_bacen;
--alter table acgsm002.acgtbs04_aplicacao drop column co_dv_garantia_bacen;
--
--alter table acgsm002.acgtbs01_contrato drop column dt_reavaliacao;
--alter table acgsm002.acgtbs01_contrato drop column vr_reavaliacao;
--alter table acgsm002.acgtbs01_contrato drop column ic_caracteristica_garantia;
--alter table acgsm002.acgtbs01_contrato drop column ic_forma_garantia;
--alter table acgsm002.acgtbs01_contrato drop column vr_forma_garantia;
--alter table acgsm002.acgtbs01_contrato drop column nu_dv_garantia;
--alter table acgsm002.acgtbs01_contrato drop column ic_tp_garantia;
--alter table acgsm002.acgtbs01_contrato drop column ic_tp_cliente;
--
--alter table acgsm001.acgtb009_garantia_contrato drop column dt_reavaliacao;
--alter table acgsm001.acgtb009_garantia_contrato drop column vr_reavaliacao;
--
--drop table acgsm002.acgtbs13_veiculo;
--alter table acgsm001.acgtb075_veiculo drop column ic_origem;
--alter table acgsm001.acgtb075_veiculo drop column vr_tabela_fipe;
--alter table acgsm001.acgtb075_veiculo drop column co_tabela_fipe;
--drop table acgsm002.acgtbs14_maquina_equipamento;
--
--alter table acgsm001.acgtb077_maquina_equipamento drop column nu_qtd_bem;
--alter table acgsm001.acgtb077_maquina_equipamento drop column de_bem;
--alter table acgsm001.acgtb077_maquina_equipamento drop column vr_maquina;
--alter table acgsm001.acgtb077_maquina_equipamento drop column ic_origem;
--drop table acgsm002.acgtbs15_imovel;
--alter table acgsm001.acgtb081_imovel drop column ic_origem;
--drop table acgsm002.acgtbs16_produto_agricola;
--
--alter table acgsm001.acgtb079_produto_agricola drop column no_modalidade;
--alter table acgsm001.acgtb079_produto_agricola drop column de_bem;
--alter table acgsm001.acgtb079_produto_agricola drop column dt_avaliacao;
--alter table acgsm001.acgtb079_produto_agricola drop column de_qtd_bem;
--alter table acgsm001.acgtb079_produto_agricola drop column vr_produto_agricola;
--alter table acgsm001.acgtb079_produto_agricola drop column ic_origem;
--
--ALTER TABLE acgsm001.acgtb106_bem_cliente DROP CONSTRAINT fk_acgtb106_acgtb079;
--alter table acgsm001.acgtb106_bem_cliente drop column nu_produto_agricola;
--
--ALTER TABLE acgsm001.acgtb106_bem_cliente DROP CONSTRAINT ckc_acgtb106_01;
--ALTER TABLE acgsm001.acgtb106_bem_cliente ADD CONSTRAINT ckc_acgtb106_01 CHECK (ic_tipo_bem = ANY (ARRAY[1, 2, 3]));
--
--COMMENT ON COLUMN acgsm001.acgtb106_bem_cliente.ic_tipo_bem IS 'Define o tipo do bem, podendo ser:
--1 - Imóveis
--2 - Maquinas e Equipamentos,
--3 - Veículos';
--
--alter table acgsm002.acgtbs01_contrato drop column nu_proposta;
--alter table acgsm002.acgtbs01_contrato drop column dt_liquidacao;
--alter table acgsm002.acgtbs01_contrato drop column dt_renovacao;
--alter table acgsm002.acgtbs01_contrato drop column modalidade_operacao;
--alter table acgsm002.acgtbs01_contrato drop column dt_saldo_devedor;
--alter table acgsm002.acgtbs01_contrato drop column dt_ult_renegociacao;
--alter table acgsm002.acgtbs01_contrato drop column tp_renegociacao;
--alter table acgsm002.acgtbs01_contrato drop column dt_venc_primeira_parcela;
--alter table acgsm002.acgtbs01_contrato drop column dt_vencimento;
--alter table acgsm002.acgtbs01_contrato drop column lmt_conta_sidec;
--alter table acgsm002.acgtbs01_contrato drop column lmt_conta_nsgd;
--alter table acgsm002.acgtbs01_contrato drop column co_conta_corrente_nsgd;
--alter table acgsm002.acgtbs01_contrato drop column co_sistema_origem;
--alter table acgsm002.acgtbs01_contrato drop column dt_movimento;
--alter table acgsm002.acgtbs01_contrato drop column dt_geracao;
--
--ALTER TABLE acgsm002.acgtbs08_duplicata 
--ALTER COLUMN vr_titulo TYPE  numeric(11,2),
--ALTER COLUMN vr_pago TYPE  numeric(11,2),
--ALTER COLUMN co_cedente TYPE character varying(16);
--COMMENT ON COLUMN acgsm002.acgtbs08_duplicata.sg_sistema_origem IS 'Sigla do sistema de origem das informações.';
--
--ALTER TABLE acgsm002.acgtbs08_duplicata DROP COLUMN co_identificador_contrato;
--ALTER TABLE acgsm002.acgtbs08_duplicata DRaOP COLUMN co_produto;
--ALTER TABLE acgsm002.acgtbs08_duplicata DROP COLUMN co_garantia_bacen;
--ALTER TABLE acgsm002.acgtbs08_duplicata DROP COLUMN dv_garantia_bacen;
--ALTER TABLE acgsm002.acgtbs08_duplicata DROP COLUMN pz_maximo_vencimento;
--ALTER TABLE acgsm002.acgtbs08_duplicata DROP COLUMN vr_maximo_permitido;
--ALTER TABLE acgsm002.acgtbs08_duplicata DROP COLUMN pc_maximo_concentracao;
--ALTER TABLE acgsm002.acgtbs08_duplicata DROP COLUMN co_nosso_numero;
--ALTER TABLE acgsm002.acgtbs08_duplicata DROP COLUMN co_agencia;
--ALTER TABLE acgsm002.acgtbs08_duplicata DROP COLUMN co_operacao;
--ALTER TABLE acgsm002.acgtbs08_duplicata DROP COLUMN co_conta;
--ALTER TABLE acgsm002.acgtbs08_duplicata DROP COLUMN dv_conta;
--ALTER TABLE acgsm002.acgtbs08_duplicata DROP COLUMN ic_cpf_cnpj_sacado;
--ALTER TABLE acgsm002.acgtbs08_duplicata DROP COLUMN canal_recebimento_titulo;