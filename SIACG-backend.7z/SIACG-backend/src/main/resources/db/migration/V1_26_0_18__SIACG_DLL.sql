alter table acgsm001.acgtb075_veiculo alter column ed_cep_matriz TYPE character varying(8);
alter table acgsm001.acgtb075_veiculo alter column ed_cep_cliente TYPE character varying(8);
alter table acgsm001.acgtb075_veiculo add primary key (nu_veiculo);
