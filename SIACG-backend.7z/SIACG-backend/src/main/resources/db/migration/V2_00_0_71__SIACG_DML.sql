/*==============================================================*/
/*           SCRIPT V2_00_0_71__SIACG_DLL						*/
/*==============================================================*/



INSERT INTO acgsm001.acgtb091_gestao_tipo_fornecedor VALUES (8, 'CARTÓRIO', 'CARTÓRIO', '2019-11-28', true, NULL);
INSERT INTO acgsm001.acgtb091_gestao_tipo_fornecedor VALUES (9, 'DES', 'DES', '2019-11-28', true, NULL);
INSERT INTO acgsm001.acgtb091_gestao_tipo_fornecedor VALUES (10, 'ENGENHARIA', 'ENGENHARIA', '2019-11-28', true, NULL);
INSERT INTO acgsm001.acgtb091_gestao_tipo_fornecedor VALUES (11, 'JORNAL', 'JORNAL', '2019-11-28', true, NULL);
INSERT INTO acgsm001.acgtb091_gestao_tipo_fornecedor VALUES (12, 'JUSTIÇA FEDERAL', 'JUSTIÇA FEDERAL', '2019-11-28', true, NULL);
INSERT INTO acgsm001.acgtb091_gestao_tipo_fornecedor VALUES (13, 'OUTROS', 'OUTROS', '2019-11-28', true, NULL);
INSERT INTO acgsm001.acgtb091_gestao_tipo_fornecedor VALUES (14, 'PREFEITURA/UNIÃO', 'PREFEITURA/UNIÃO', '2019-11-28', true, NULL);
INSERT INTO acgsm001.acgtb091_gestao_tipo_fornecedor VALUES (15, 'SENHORIO', 'SENHORIO', '2019-11-28', true, NULL);
INSERT INTO acgsm001.acgtb091_gestao_tipo_fornecedor VALUES (16, 'DESPACHANTE', 'DESPACHANTE', '2019-11-28', true, NULL);


INSERT INTO acgsm001.acgtb094_gestao_tipo_despesa VALUES (70, 138452, 'LAUDÊMIO/FORO', 15, '138452    ', true);
INSERT INTO acgsm001.acgtb094_gestao_tipo_despesa VALUES (71, 138452, 'ITR', 14, '138452    ', true);
INSERT INTO acgsm001.acgtb094_gestao_tipo_despesa VALUES (72, 138452, 'ITBI', 14, '138452    ', true);
INSERT INTO acgsm001.acgtb094_gestao_tipo_despesa VALUES (73, 138452, 'IPTU', 14, '138452    ', true);
INSERT INTO acgsm001.acgtb094_gestao_tipo_despesa VALUES (74, 31410, 'CONDOMÍNIO, ÁGUA E OUTROS DÉBITOS', 13, '31410     ', true);
INSERT INTO acgsm001.acgtb094_gestao_tipo_despesa VALUES (75, 31410, 'NOTIFICAÇÃO JUDICIAL', 12, '31410     ', true);
INSERT INTO acgsm001.acgtb094_gestao_tipo_despesa VALUES (76, 31410, 'PUBLICAÇÃO DE EDITAL DE INTIMAÇÃO', 11, '31410     ', true);
INSERT INTO acgsm001.acgtb094_gestao_tipo_despesa VALUES (77, 31140, 'AVALIAÇÃO ATUALIZADA', 10, '31140     ', true);
INSERT INTO acgsm001.acgtb094_gestao_tipo_despesa VALUES (78, 31410, 'DEEMBOLSO DESPACHANTE', 16, '31410     ', true);
INSERT INTO acgsm001.acgtb094_gestao_tipo_despesa VALUES (79, 31410, 'AUTENTICAÇÃO CÓPIAS', 8, '31410     ', true);
INSERT INTO acgsm001.acgtb094_gestao_tipo_despesa VALUES (80, 311410, 'AVERBAÇÃO DE CONSOLIDAÇÃO/ITBI', 8, '311410    ', true);
INSERT INTO acgsm001.acgtb094_gestao_tipo_despesa VALUES (81, 314140, 'CERTIDÃO DE CURSO DE PRAZO', 8, '314140    ', true);
INSERT INTO acgsm001.acgtb094_gestao_tipo_despesa VALUES (82, 314140, 'DILIGÊNCIA DE INTIMAÇÃO', 8, '314140    ', true);
INSERT INTO acgsm001.acgtb094_gestao_tipo_despesa VALUES (83, 314140, 'EMISSÃO DE MATRÍCULA/CERTIDÃO', 8, '314140    ', true);
INSERT INTO acgsm001.acgtb094_gestao_tipo_despesa VALUES (84, 314140, 'RECOHECIMENTO DE FIRMA', 8, '314140    ', true);
INSERT INTO acgsm001.acgtb094_gestao_tipo_despesa VALUES (85, 133007, 'RECUPERAÇÃO DE DESPESA', 8, '133007    ', true);
INSERT INTO acgsm001.acgtb094_gestao_tipo_despesa VALUES (86, 314140, 'RENOVAÇÃO DE PRENOTAÇÃO', 8, '314140    ', true);
INSERT INTO acgsm001.acgtb094_gestao_tipo_despesa VALUES (87, 314140, 'REQUERIMENTO DE CANCELAMENTO', 8, '314140    ', true);
INSERT INTO acgsm001.acgtb094_gestao_tipo_despesa VALUES (88, 314140, 'REQUERIMENTO DE CONSOLIDAÇÃO', 8, '314140    ', true);
INSERT INTO acgsm001.acgtb094_gestao_tipo_despesa VALUES (89, 314140, 'REQUERIMENTO DE EDITAL', 8, '314140    ', true);
INSERT INTO acgsm001.acgtb094_gestao_tipo_despesa VALUES (90, 314140, 'REQUERIMENTO DE INTIMAÇÃO', 8, '314140    ', true);