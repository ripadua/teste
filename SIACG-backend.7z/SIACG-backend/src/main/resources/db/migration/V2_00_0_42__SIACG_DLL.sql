/*==============================================================*/
/* SCRIPT V2_00_0_42__SIACG_DLL									*/
/*==============================================================*/
-- Table: acgsm002.acgtbx01_controla_fluxo
COMMENT ON TABLE acgsm002.acgtbx01_controla_fluxo IS 'Esta tabela irá controlar o fluxo de execução em paralelo da rotina pentaho de importação de arquivos.
- Essa tabela é truncada no início da execução da rotina. 
- A rotina fará inserts nessa tabela em pontos específicos e então, baseado no número de linhas dessa tabela, saberá quando determinado fluxo poderá seguir adiante';

COMMENT ON COLUMN acgsm002.acgtbx01_controla_fluxo.nu_linha IS 'Essa coluna irá armazenar o valor 1 vindo de pontos específicos existentes na rotina pentaho. 
Esses valores serão usados pela rotina para controlar o seu fluxo de execução.';