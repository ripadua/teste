/*==============================================================*/
/*           SCRIPT V2_00_0_90__SIACG_DML						*/
/*==============================================================*/

/*==============================================================*/
/* Table: acgsm001.acgtb075_veiculo                             */
/*==============================================================*/

alter table acgsm001.acgtb075_veiculo add column no_categoria character varying(100);
alter table acgsm001.acgtb075_veiculo add column no_tipo_veiculo character varying(100);
alter table acgsm001.acgtb075_veiculo add column vr_medio numeric(16,2);
alter table acgsm001.acgtb075_veiculo add column vr_veiculo numeric(16,2);
alter table acgsm001.acgtb075_veiculo alter column co_placa type character varying(10);

COMMENT ON COLUMN acgsm001.acgtb075_veiculo.no_categoria IS 'Representa a categoria do veículo.';
COMMENT ON COLUMN acgsm001.acgtb075_veiculo.no_tipo_veiculo IS 'Representa o tipo do veículo';
COMMENT ON COLUMN acgsm001.acgtb075_veiculo.vr_medio IS 'Valor médio do Veculo';
COMMENT ON COLUMN acgsm001.acgtb075_veiculo.vr_veiculo IS 'Valor do veículo (Notal Fiscal/DUT)';


/*==============================================================*/
/* Table: acgsm001.acgtb106_bem_cliente                         */
/*==============================================================*/
alter table acgsm001.acgtb106_bem_cliente alter column ic_situacao_bem drop not null;
alter table acgsm001.acgtb106_bem_cliente alter column nu_pessoa drop not null;

/*==============================================================*/
/* Table: acgtb075_veiculo                                      */
/*==============================================================*/
--alter table acgsm001.acgtb075_veiculo drop column no_categoria;
--alter table acgsm001.acgtb075_veiculo drop column no_tipo_veiculo;
--alter table acgsm001.acgtb075_veiculo drop column vr_medio;
--alter table acgsm001.acgtb075_veiculo drop column vr_veiculo;