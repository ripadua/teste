/*==============================================================*/
/*           SCRIPT V2_00_0_85__SIACG_DLL						*/
/*==============================================================*/


ALTER TABLE acgsm001.acgtb103_documento_lancamento_evento ALTER COLUMN nu_conta type character varying(12);

ALTER TABLE acgsm001.acgtb103_documento_lancamento_evento ALTER COLUMN nu_documento type character varying(12);
      
/*########################### SCRIPT ROLLBACK ##############################*/
--DROP SEQUENCE acgsm001.sq0103_documento_lancamento_evento;