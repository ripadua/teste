/*==============================================================*/
/* Sequence: acgsm001.acgtb049_unidade_habitacional             */
/*==============================================================*/

ALTER TABLE acgsm001.acgtb049_unidade_habitacional ADD COLUMN vr_minimo_desligamento numeric(15,2);

comment on column acgsm001.acgtb049_unidade_habitacional.vr_minimo_desligamento is 'Valor que representa o valor mínimo de desligamento (VMD) da unidade habitacional.';


/*==============================================================*/
/* Sequence: acgsm001.acgtb001_contrato                         */
/*==============================================================*/
ALTER TABLE acgsm001.acgtb001_contrato DROP CONSTRAINT ck_acgtb001_04; 
ALTER TABLE acgsm001.acgtb001_contrato ADD CONSTRAINT ck_acgtb001_04 CHECK (ic_situacao = ANY (ARRAY['01'::bpchar, '02'::bpchar, '03'::bpchar, '04'::bpchar, '05'::bpchar, '06'::bpchar, '07'::bpchar]));

COMMENT ON COLUMN acgsm001.acgtb001_contrato.ic_situacao IS 'Identifica a situacao do contrato:
01 - Aberto
02 - Atrasado
03 - Fechado
04 - Cancelado
05 - Pré-Análise
06 - Crédito em Atraso
07 - Contrato desabilitado por rotina automatica.';

COMMENT ON COLUMN acgsm001.acgtb001_contrato.ic_forma_inclusao IS 'Indica a origem da importacao do contrato:

1- Rotina Carga de Contrato
2- Rotina Habitacional
3- SIFEC
4- Manual
5- Contrato Temporario (Caso o contrato nao venha na rotina de carga, situacao 1, estes contratos serao desabilitados do SIACG)';

/*==============================================================*/
/* Reverse: acgsm001.acgtb049_unidade_habitacional              */
/*==============================================================*/      
--ALTER TABLE acgsm001.acgtb049_unidade_habitacional DROP COLUMN vr_minimo_desligamento;

/*==============================================================*/
/* Reverse: acgsm001.acgtb001_contrato                          */
/*==============================================================*/
--ALTER TABLE acgsm001.acgtb001_contrato DROP CONSTRAINT ck_acgtb001_04; 
--ALTER TABLE acgsm001.acgtb001_contrato ADD CONSTRAINT ck_acgtb001_04 CHECK (ic_situacao = ANY (ARRAY['01'::bpchar, '02'::bpchar, '03'::bpchar, '04'::bpchar, '05'::bpchar, '06'::bpchar]));

--COMMENT ON COLUMN acgsm001.acgtb001_contrato.ic_situacao IS 'Identifica a situacao do contrato:
--01 - Aberto
--02 - Atrasado
--03 - Fechado
--04 - Cancelado
--05 - Pré-Análise
--06 - Crédito em Atraso.';