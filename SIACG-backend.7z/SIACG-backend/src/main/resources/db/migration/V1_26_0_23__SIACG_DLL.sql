-- Materialized View: acgsm001.acgvw010_endereco

-- DROP MATERIALIZED VIEW trrsm001.trrvw002_endereco;

CREATE MATERIALIZED VIEW acgsm001.acgvw010_endereco AS 
 SELECT row_number() OVER (ORDER BY view.sg_uf, view.no_cidade, view.no_bairro, view.no_logradouro) AS nu_endereco,
    view.nu_cep,
    view.no_logradouro,
    view.no_bairro,
    view.no_cidade,
    view.sg_uf
   FROM ( SELECT DISTINCT ((lpad('0'::text, 5 - length(tc.nu_cep::character varying::text)) || tc.nu_cep::character varying::text) || lpad('0'::text, 3 - length(tc.nu_cep_complemento::character varying::text))) || tc.nu_cep_complemento::character varying::text AS nu_cep,
            (ltrim(rtrim(lg.sg_tipo_lgrdo_l19::text)) || ' '::text) || ltrim(rtrim(lg.no_logradouro::text)) AS no_logradouro,
            ltrim(rtrim(bo.no_bairro::text)) AS no_bairro,
            ltrim(rtrim(lc.no_localidade::text)) AS no_cidade,
            ltrim(rtrim(lc.sg_uf_l22::text)) AS sg_uf
           FROM icosm001.icotbl21_trecho tc
             JOIN icosm001.icotbl01_bairro bo ON bo.nu_bairro = tc.nu_bairro_l01
             JOIN icosm001.icotbl09_logradour lg ON tc.nu_logradouro_l09 = lg.nu_logradouro
             JOIN icosm001.icotbl08_localidad lc ON lc.nu_localidade = lg.nu_localidade_l08
          WHERE lg.ic_origem_cdsto = 'O'::bpchar AND length(lg.no_logradouro::text) > 0) view
  ORDER BY view.sg_uf, view.no_cidade, view.no_bairro, view.no_logradouro
WITH DATA;

ALTER TABLE acgsm001.acgvw010_endereco
  OWNER TO postgres;
--GRANT ALL ON TABLE acgsm001.acgvw010_endereco TO postgres;
--GRANT ALL ON TABLE acgsm001.acgvw010_endereco TO acgsm001;
COMMENT ON MATERIALIZED VIEW acgsm001.acgvw010_endereco
  IS 'View com objetivo de buscar dados de endereço no SIICO.';
