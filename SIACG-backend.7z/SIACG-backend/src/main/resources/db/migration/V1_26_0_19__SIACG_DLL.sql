create sequence acgsm001.sq080_imovel;


/*==============================================================*/
/* Table: acgtb081_imoveis                                      */
/*==============================================================*/
create table acgsm001.acgtb081_imoveis (
   nu_imoveis           INT4                 not null default nextval('acgsm001.sq080_imovel'),
   nu_matricula         INT8                 not null,
   no_cartorio          VARCHAR(100)         not null,
   no_logadouro         VARCHAR(100)         not null,
   nu_numero            INT8                 not null,
   no_complemento       VARCHAR(100)         not null,
   no_bairro            VARCHAR(50)          not null,
   no_municipio         VARCHAR(50)          not null,
   no_uf                VARCHAR(2)           not null,
   nu_cep               INT8                 not null,
   vr_area_imovel       NUMERIC(16,2)        not null,
   vr_area_privativa    NUMERIC(16,2)        not null,
   constraint PK_ACGTB081_IMOVEIS primary key (nu_imoveis)
);

comment on table acgsm001.acgtb081_imoveis is
'Tabela de garantia de imóveis, usada ao se cadastrar garantia de contrato.';

comment on column acgsm001.acgtb081_imoveis.nu_imoveis is
'Identificador da tabela acgtb081_imoveis.';

comment on column acgsm001.acgtb081_imoveis.nu_matricula is
'Número de matrícula do imóvel.';

comment on column acgsm001.acgtb081_imoveis.no_cartorio is
'Nome do cartorio de registro do imóvel,';

comment on column acgsm001.acgtb081_imoveis.no_logadouro is
'Logadouro do imóvel,';

comment on column acgsm001.acgtb081_imoveis.nu_numero is
'Número do endereço do imóvel.';

comment on column acgsm001.acgtb081_imoveis.no_complemento is
'Complemento do endereço do imóvel,';

comment on column acgsm001.acgtb081_imoveis.no_bairro is
'Bairro que o imóvel esta localizado.';

comment on column acgsm001.acgtb081_imoveis.no_municipio is
'Município que o imóvel esta localizado,';

comment on column acgsm001.acgtb081_imoveis.no_uf is
'UF do imóvel,';

comment on column acgsm001.acgtb081_imoveis.nu_cep is
'CEP do imóvel.';

comment on column acgsm001.acgtb081_imoveis.vr_area_imovel is
'Valor da área do imóvel,';

comment on column acgsm001.acgtb081_imoveis.vr_area_privativa is
'Valor da área privativa (área construida do imóvel).';


/*==============================================================*/
/* Table: acgtb080_garantia_imoveis                             */
/*==============================================================*/
create table acgsm001.acgtb080_garantia_imoveis (
   nu_garantia_contrato int4                 not null,
   nu_imoveis           INT4                 not null,
   constraint PK_ACGTB080_GARANTIA_IMOVEIS primary key (nu_imoveis, nu_garantia_contrato)
);

comment on table acgsm001.acgtb080_garantia_imoveis is
'Tabela de ligação entre a garantia de imóveis e a tabela de garantia de contrato.';

comment on column acgsm001.acgtb080_garantia_imoveis.nu_garantia_contrato is
'Identificador da garantia do contrato. Tabela acgtb009_garantia_contrato.';

comment on column acgsm001.acgtb080_garantia_imoveis.nu_imoveis is
'Identificador da tabela de imoveis (acgtb081_imoveis)';

alter table acgsm001.acgtb080_garantia_imoveis
   add constraint FK_ACGTB080_ACGTB009 foreign key (nu_garantia_contrato)
      references acgsm001.acgtb009_garantia_contrato (nu_garantia_contrato)
      on delete restrict on update restrict;

alter table acgsm001.acgtb080_garantia_imoveis
   add constraint FK_ACGTB080_ACGTB081 foreign key (nu_imoveis)
      references acgsm001.acgtb081_imoveis (nu_imoveis)
      on delete restrict on update restrict;
