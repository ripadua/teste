/*============================================================*/
/*           SCRIPT V2_10_0_05__SIACG_DDL		              */
/*============================================================*/

ALTER TABLE acgsm001.acgtb081_imovel ADD COLUMN co_ordem_servico_avaliacao character varying(30);

comment on column acgsm001.acgtb081_imovel.co_ordem_servico_avaliacao is
'Código da ordem de serviço aberta no sistema SIEGH/SIGDU para avaliação do imóvel pela engenharia.';

--ALTER TABLE acgsm001.acgtb081_imovel alter COLUMN co_livro_serventia character varying(4);


/*==============================================================*/
/* REVERT                                                       */
/*==============================================================*/ 
-- ALTER TABLE acgsm001.acgtb081_imovel DROP COLUMN co_ordem_servico_avaliacao;

--ALTER TABLE acgsm001.acgtb081_imovel alter COLUMN co_livro_serventia character varying(3);