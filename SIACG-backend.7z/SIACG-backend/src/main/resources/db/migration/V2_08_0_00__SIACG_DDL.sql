/*============================================================*/
/*           SCRIPT V2_08_0_00__SIACG_DDL				      */
/*============================================================*/

/*============================================================*/
/* Table: acgsm001.acgtb081_imovel_bkp                        */
/*============================================================*/
CREATE TABLE acgsm001.acgtb081_imovel_bkp (
nu_imovel integer,
co_livro_serventia character varying(3),
co_cnm character varying(15)
);

COMMENT ON TABLE acgsm001.acgtb081_imovel_bkp IS 'Os campos co_livro_serventia e co_cnm da tabela acgsm001.acgtb081_imovel, foram alterados via sql para atender a mudanca de que o primeiro digito de 
co_livro_serventia devera ser sempre 2. Consequentemente, foi necessario recalcular o co_cnm. Essa tabela armazena os respectivos valores antes da alteracao, e sera removida em uma versao posterior.';

-- DROP TABLE acgsm001.acgtb081_imovel_bkp;

/*============================================================*/
/* Function acgfn001_retorna_cnm_imovel                       */
/*============================================================*/
CREATE OR REPLACE FUNCTION acgsm001.acgfn001_retorna_cnm_imovel(imovel integer) 
RETURNS character varying AS $BODY$
   DECLARE 
   --Declara variáveis
   cns character varying(6);
   livro character varying(3);
   registro character varying(50);
   
   cnm character varying(15);
   calculoMod97 char(2);

   valor1 text;
   resto1 bigint;
   valor2 text;
   resto2 bigint;
   valor3 text;
   resto3 bigint;
   
   BEGIN 
      --Inicializa variáveis
      cns := (SELECT gs.co_cns 
	      FROM acgsm001.acgtb089_gestao_serventia gs 
	      INNER JOIN acgsm001.acgtb081_imovel i ON gs.nu_gestao_serventia = i.nu_gestao_serventia
	      WHERE i.nu_imovel = imovel);
      livro := (SELECT co_livro_serventia FROM acgsm001.acgtb081_imovel WHERE nu_imovel = imovel);
      registro := (SELECT co_registro_garantia FROM acgsm001.acgtb081_imovel WHERE nu_imovel = imovel);
	  
      valor1 := lpad(cns, 5, '0');
      resto1 := mod(cast(valor1 as bigint),97);

      valor2 := lpad(cast(resto1 as text), 2, '0') || substring(livro, 1, 1);
      resto2 := mod(cast(valor2 as bigint),97);

      valor3 := lpad(cast(resto2 as text), 2, '0') || lpad(registro, 7, '0') || '00';
      resto3 := 98 - mod(cast(valor3 as bigint),97);
      
      calculoMod97 := lpad(cast(resto3 as text), 2, '0');

      --Monta cnm
      cnm := lpad(cns, 5, '0') || substring(livro, 1, 1) || lpad(registro, 7, '0') || calculoMod97;
	  
      RETURN cnm;
      
   END; 
$BODY$ LANGUAGE plpgsql;

-- DROP FUNCTION acgsm001.acgfn001_retorna_cnm_imovel(integer);
