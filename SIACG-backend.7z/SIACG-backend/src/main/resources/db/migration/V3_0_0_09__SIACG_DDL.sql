/*==============================================================*/
/* Sequence: acgsq117_tipo_conta_registradora                        */
/*==============================================================*/
create sequence acg.acgsq117_tipo_conta_registradora
START WITH 1
INCREMENT BY 1
MAXVALUE 9999999999999999999999999999
MINVALUE 1
CACHE 20;


/*==============================================================*/
/* Table: acgtb117_tipo_conta_registradora                        */
/*==============================================================*/
create table acg.acgtb117_tipo_conta_registradora
(
   nu_tipo_conta_registradora INTEGER              default ACG.acgsq117_tipo_conta_registradora.nextval not null,
   ic_conta_registradora VARCHAR2(2)          not null
      constraint ck_acgtb117_01 check (ic_conta_registradora in ('CC','CD','CP','PP','CG','CI')),
   co_operacao        VARCHAR2(4)          not null,
   ic_pessoa          CHAR(2)              not null
      constraint ck_acgtb117_02 check (ic_pessoa in ('PF','PJ')),
   constraint pk_acgtb117 primary key (nu_tipo_conta_registradora)
	  USING INDEX TABLESPACE ACGTSIX001
) TABLESPACE ACGTSDT001;

comment on table acg.acgtb117_tipo_conta_registradora is
'Armazena o mapeamento do numero da operacao no siacg para o tipo de conta da registradora';

comment on column acg.acgtb117_tipo_conta_registradora.nu_tipo_conta_registradora is
'Identificador único do tipo de conta da registradora';

comment on column acg.acgtb117_tipo_conta_registradora.ic_conta_registradora is
'Identificador do tipo de conta do dominio da registradora:

CC - Conta corrente
CD - Conta de depósito
CP - Conta pagamento
PP - Poupança
CG - Conta garantida
CI - Conta investimento';

comment on column acg.acgtb117_tipo_conta_registradora.co_operacao is
'Código da operação equivalente no SIACG';

comment on column acg.acgtb117_tipo_conta_registradora.ic_pessoa is
'Identificador do tipo de pessoa da conta:
PF - Fisica
PJ - Juridica ';

/*==============================================================*/
/* REVERT														*/
/*==============================================================*/
-- drop table acg.acgtb117_tipo_conta_registradora
-- drop sequence acg.acgsq117_tipo_conta_registradora