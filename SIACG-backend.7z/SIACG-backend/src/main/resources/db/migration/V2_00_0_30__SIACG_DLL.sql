ALTER TABLE acgsm001.acgtb081_imoveis
  ADD COLUMN dt_avaliacao_consolidada date;
  COMMENT ON COLUMN acgsm001.acgtb081_imoveis.dt_avaliacao_consolidada IS'Define a data de avaliação consolidada do imóvel.';