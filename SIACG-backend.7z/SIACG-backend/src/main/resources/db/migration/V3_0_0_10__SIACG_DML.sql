/*=====================================================================*/
/* iNSERT DE MAPEAMENTO DE PARA OPERACAO - TIPO DE CONTA REGISTRADORA  */
/*=====================================================================*/
INSERT INTO ACG.ACGTB117_TIPO_CONTA_REGISTRADORA (NU_TIPO_CONTA_REGISTRADORA, IC_CONTA_REGISTRADORA, CO_OPERACAO, IC_PESSOA)
VALUES(ACG.acgsq117_tipo_conta_registradora.nextval , 'CC', '0001', 'PF');
INSERT INTO ACG.ACGTB117_TIPO_CONTA_REGISTRADORA (NU_TIPO_CONTA_REGISTRADORA, IC_CONTA_REGISTRADORA, CO_OPERACAO, IC_PESSOA)
VALUES(ACG.acgsq117_tipo_conta_registradora.nextval , 'CC', '0003', 'PJ');
INSERT INTO ACG.ACGTB117_TIPO_CONTA_REGISTRADORA (NU_TIPO_CONTA_REGISTRADORA, IC_CONTA_REGISTRADORA, CO_OPERACAO, IC_PESSOA)
VALUES(ACG.acgsq117_tipo_conta_registradora.nextval , 'PP', '0013', 'PF');
INSERT INTO ACG.ACGTB117_TIPO_CONTA_REGISTRADORA (NU_TIPO_CONTA_REGISTRADORA, IC_CONTA_REGISTRADORA, CO_OPERACAO, IC_PESSOA)
VALUES(ACG.acgsq117_tipo_conta_registradora.nextval , 'PP', '0022', 'PJ');

/*==============================================================*/
/* REVERT														*/
/*==============================================================*/
-- TRUNCATE TABLE ACG.ACGTB117_TIPO_CONTA_REGISTRADORA