/*==============================================================*/
/* Table: acgtb001_contrato                                     */
/*==============================================================*/
ALTER TABLE acgsm001.acgtb001_contrato RENAME CONSTRAINT ckc_ic_categoria_acgtb001 TO ck_acgtb001_01;
ALTER TABLE acgsm001.acgtb001_contrato RENAME CONSTRAINT ckc_ic_forma_inclusao_acgtb001 TO ck_acgtb001_02;
ALTER TABLE acgsm001.acgtb001_contrato RENAME CONSTRAINT ckc_ic_nivel_acgtb001 TO ck_acgtb001_03;
ALTER TABLE acgsm001.acgtb001_contrato RENAME CONSTRAINT ckc_ic_situacao_acgtb001 TO ck_acgtb001_04;



/*==============================================================*/
/* Table: acgtb089_gestao_serventia                             */
/*==============================================================*/
ALTER TABLE acgsm001.acgtb089_gestao_serventia RENAME CONSTRAINT cc_acgtb089_gestao_serventia_01 TO ck_acgtb089_01;


/*==============================================================*/
/* Table: acgtb064_tipo_parcela                                 */
/*==============================================================*/
ALTER TABLE acgsm001.acgtb064_tipo_parcela RENAME CONSTRAINT pk_acgtb065_tipo_parcela TO pk_acgtb064_tipo_parcela;
ALTER TABLE acgsm001.acgtb064_tipo_parcela RENAME CONSTRAINT ckc_ic_periodicidade__acgtb065 TO ck_acgtb064_01;


/*==============================================================*/
/* Table: acgtb081_imovel                                       */
/*==============================================================*/
ALTER TABLE acgsm001.acgtb081_imovel RENAME CONSTRAINT fk_acgtb081_imovel_acgtb003_pessoa TO fk_acgtb081_acgtb003;
ALTER TABLE acgsm001.acgtb081_imovel RENAME CONSTRAINT fk_acgtb081_imovel_acgtb089_gestao_serventia TO fk_acgtb081_acgtb089;