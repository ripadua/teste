/*==============================================================*/
/* Sequence: acgsm001.acgsq090_documento_lncmo_evento           */
/*==============================================================*/


create sequence acgsm001.acgsq090_documento_lncmo_evento;



/*==============================================================*/
/* Table: acgtb090_documento_lncmo_evento                       */
/*==============================================================*/
create table acgsm001.acgtb090_documento_lncmo_evento (
   nu_documento_lncmo_evento INT             not null default nextval('acgsm001.acgsq090_documento_lncmo_evento'),
   co_unidade_movimento INT                  null,
   co_unidade_movimento_dv INT                  null,
   dt_movimento         DATE                 null,
   co_evento            INT                  null,
   co_evento_dv         INT                  null,
   co_produto           INT                  null,
   co_produto_dv        INT                  null,
   ic_registro          INT                  null
      constraint CKC_IC_REGISTRO_ACGTB090 check (ic_registro is null or (ic_registro in ('4','5'))),
   ic_lancamento        INT                  null
      constraint CKC_IC_LANCAMENTO_ACGTB090 check (ic_lancamento is null or (ic_lancamento in ('1','2'))),
   no_aviso             VARCHAR(20)          null,
   co_unidade_destino   INT                  null,
   co_unidade_destino_dv INT                  null,
   co_centro_custo_rspnl INT                  null,
   co_centro_custo_rspnl_dv INT                  null,
   dt_efetiva           DATE                 null,
   ic_analitico         INT                  null
      constraint CKC_IC_ANALITICO_ACGTB090 check (ic_analitico is null or (ic_analitico in ('1','2','3','4'))),
   co_analitico         INT                  null,
   co_analitico_dv      INT                  null,
   co_projeto           VARCHAR(20)          null,
   nu_empenho           INT                  null,
   nu_documento         INT                  null,
   nu_conciliacao       INT                  null,
   nu_seguimento_carteira INT                  null,
   no_evento            VARCHAR(500)         null,
   de_historico         VARCHAR(800)         null,
   qt_valor_lncmo_evento INT                  null,
   vr_documento_incmo_evento NUMERIC(16,2)        null,
   constraint PK_ACGTB090 primary key (nu_documento_lncmo_evento)
);

comment on table acgsm001.acgtb090_documento_lncmo_evento is
'Tabela de Documento de Lançamento de Evento DLE - Pagamento/Recebimento';

comment on column acgsm001.acgtb090_documento_lncmo_evento.nu_documento_lncmo_evento is
'identificador unico da tabela numero documento lançamento evento';

comment on column acgsm001.acgtb090_documento_lncmo_evento.co_unidade_movimento is
'Codigo da unidade de Movimento';

comment on column acgsm001.acgtb090_documento_lncmo_evento.co_unidade_movimento_dv is
'Codigo da unidade de Movimento DV';

comment on column acgsm001.acgtb090_documento_lncmo_evento.dt_movimento is
'Data que ocorreu a movimentacao';

comment on column acgsm001.acgtb090_documento_lncmo_evento.co_evento is
'codigo que referencia o evento';

comment on column acgsm001.acgtb090_documento_lncmo_evento.co_evento_dv is
'Codigo que referencia o eveto Digito Verificador';

comment on column acgsm001.acgtb090_documento_lncmo_evento.co_produto is
'Codigo que referencia o produto ';

comment on column acgsm001.acgtb090_documento_lncmo_evento.co_produto_dv is
'Codigo que referencia o produto digito verificador';

comment on column acgsm001.acgtb090_documento_lncmo_evento.ic_registro is
'Indicador de registro sendo (4 - recebimento/Credito 5- pagamento/Debito) ';

comment on column acgsm001.acgtb090_documento_lncmo_evento.ic_lancamento is
'Situação do lançamento sendo (1- Normal  2- Estorno)';

comment on column acgsm001.acgtb090_documento_lncmo_evento.no_aviso is
'Descrição do Aviso';

comment on column acgsm001.acgtb090_documento_lncmo_evento.co_unidade_destino is
'Codigo da unidade de Destino';

comment on column acgsm001.acgtb090_documento_lncmo_evento.co_unidade_destino_dv is
'Codigo da unidade de Desstino Digito Verificador';

comment on column acgsm001.acgtb090_documento_lncmo_evento.co_centro_custo_rspnl is
'Codigo de centro de custo responsavel';

comment on column acgsm001.acgtb090_documento_lncmo_evento.co_centro_custo_rspnl_dv is
'Codigo de centro de custo responsavel Digito verificador';

comment on column acgsm001.acgtb090_documento_lncmo_evento.dt_efetiva is
'Data Efetiva';

comment on column acgsm001.acgtb090_documento_lncmo_evento.ic_analitico is
'Tipo analitico sendo (1-Sequencial  2- CPF  3- CNPJ  4-DPJ) ';

comment on column acgsm001.acgtb090_documento_lncmo_evento.co_analitico is
'Codigo analitico';

comment on column acgsm001.acgtb090_documento_lncmo_evento.co_analitico_dv is
'Codigo analitico Digito verrificador';

comment on column acgsm001.acgtb090_documento_lncmo_evento.co_projeto is
'Codigo do projeoto';

comment on column acgsm001.acgtb090_documento_lncmo_evento.nu_empenho is
'nuemro do emprenho, ';

comment on column acgsm001.acgtb090_documento_lncmo_evento.nu_documento is
'Numero do Documento';

comment on column acgsm001.acgtb090_documento_lncmo_evento.nu_conciliacao is
'Nuemro da conciliação';

comment on column acgsm001.acgtb090_documento_lncmo_evento.nu_seguimento_carteira is
'numero do seguinto ou da Carteira';

comment on column acgsm001.acgtb090_documento_lncmo_evento.no_evento is
'Nomde descritivo do evento referenciado.';

comment on column acgsm001.acgtb090_documento_lncmo_evento.de_historico is
'Descritivo do  historico da DLE';

comment on column acgsm001.acgtb090_documento_lncmo_evento.qt_valor_lncmo_evento is
'Quantidade dos valores de lancamento de eventos';

comment on column acgsm001.acgtb090_documento_lncmo_evento.vr_documento_incmo_evento is
'valor do documento de lancamento de evento';


/*==============================================================*/
/* Script Reverse  acgtb090_documento_lncmo_evento              */
/*==============================================================*/

-- DROP sequence acgsm001.acgsq090_documento_lncmo_evento;

-- DROP table acgsm001.acgtb090_documento_lncmo_evento;


