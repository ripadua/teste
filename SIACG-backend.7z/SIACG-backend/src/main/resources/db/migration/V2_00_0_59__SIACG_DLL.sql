/*==============================================================*/
/* Sequence: acgsm001.acgsq095_despesa                          */
/*==============================================================*/

create sequence acgsq095_despesa;


/*==============================================================*/
/* Table: acgsm001.acgtb095_despesa                             */
/*==============================================================*/
create table acgsm001.acgtb095_despesa (
   nu_despesa           INT                  not null default nextval('acgsq095_despesa'),
   nu_tipo_despesa      INT                  null ,
   ic_tipo_credor       INT                  null,
   nu_credor            INT                  null,
   nu_imovel            INT                  null,
   de_despesa           CHAR(200)            null,
   vr_despesa           NUMERIC(16,2)        null,
   de_observacao        CHAR(500)            null,
   constraint PK_ACGTB095_DESPESA primary key (nu_despesa)
);

comment on table acgsm001.acgtb095_despesa is
'Cadastro de despesa de fornecedores';

comment on column acgsm001.acgtb095_despesa.nu_tipo_despesa is
'Identificador unico do tipo de despesa';

comment on column acgsm001.acgtb095_despesa.ic_tipo_credor is
'identificador do tipo fornecedor, chave de identificação ( 1 - fornecedor , 2 - cartorio)';

comment on column acgsm001.acgtb095_despesa.nu_credor is
'numero de identificador do fornecedor/Cartorio ';

comment on column acgsm001.acgtb095_despesa.nu_imovel is
'numero de identificacao do imovel';

alter table acgsm001.acgtb095_despesa
   add constraint FK_ACGTB095_REFERENCE_ACGTB094 foreign key (nu_tipo_despesa)
      references acgtb094_gestao_tipo_despesa (nu_tipo_despesa)
      on delete restrict on update restrict;
      
      
alter table acgsm001.acgtb095_despesa
   add constraint FK_ACGTB095_REFERENCE_ACGTB081 foreign key (nu_imovel)
      references acgtb081_imovel (nu_imovel)
      on delete restrict on update restrict;
      

/*==============================================================*/
/* Reverse: acgsm001.acgtb095_despesa                           */
/*==============================================================*/      
      
--drop table acgtb095_despesa;
--drop sequence acgsq095_despesa;
      
      
