-- cria auto incremento para tabela 030
ALTER TABLE acgsm001.acgtb030_cartao_credito
  ALTER COLUMN nu_cartao_credito SET DEFAULT NEXTVAL('acgsm001.sq030_cartao_credito');
  
-- cria auto incremento para tabela 033
ALTER TABLE acgsm001.acgtb033_garantia_cartao_credito
  ALTER COLUMN nu_garantia_cartao_credito SET DEFAULT NEXTVAL('acgsm001.sq033_garantia_cartao_credito');
  
-- altera stage area de cartao
ALTER TABLE acgsm001.acgtbi01_mov_cartoes
  DROP COLUMN ic_bandeira;
 

ALTER TABLE acgsm001.acgtbi01_mov_cartoes
  ADD COLUMN nu_bandeira_cartao integer;
  
COMMENT ON COLUMN acgsm001.acgtbi01_mov_cartoes.nu_bandeira_cartao IS 'Identifica qual a bandeira do movimento:
Ex: Visa, Mastercard, etc.
Essas bandeiras estão relacionadas com as bandeiras da tabela acgtb069_bandeira_cartao';


ALTER TABLE acgsm001.acgtbi01_mov_cartoes
  ADD COLUMN no_arquivo varchar; 

COMMENT ON COLUMN acgsm001.acgtbi01_mov_cartoes.no_arquivo IS 'Identifica qual é o arquivo de origem dos dados do cartão. Essa coluna será usada para agrupar os 
dados da stage área por arquivos e permitir armazenar na tabela de log de importação as quantidades de cada arquivo.';


-- sequence
create sequence acgsm001.acgsq072_credenciador;

/*==============================================================*/
/* Table: acgtb072_credenciador                                 */
/*==============================================================*/
create table acgsm001.acgtb072_credenciador (
   nu_credenciador      Integer              not null default nextval('acgsm001.acgsq072_credenciador'),
   no_credenciador      varchar(200)         not null,
   co_cnpj_credenciador VARCHAR(14)          not null,
   ic_ativo             Boolean              not null default true,
   constraint PK_ACGTB072_CREDENCIADOR primary key (nu_credenciador)
);

comment on table acgsm001.acgtb072_credenciador is
'Armazena os credenciadores das máquinas que farão as leituras dos cartões. Em uma carga de dados, por exemplo, somente serão carregados os dados dos arquivos que contém os cnpj''s relacionados nesta tabela e que estejam ativos.';

comment on column acgsm001.acgtb072_credenciador.nu_credenciador is
'Chave identificadora do registro. Gerado automaticamente atráves de sequence.';

comment on column acgsm001.acgtb072_credenciador.no_credenciador is
'Informa o nome do credenciador da máquina de leitura do cartao.';

comment on column acgsm001.acgtb072_credenciador.co_cnpj_credenciador is
'Informa o cnpj do credenciador';

comment on column acgsm001.acgtb072_credenciador.ic_ativo is
'Informa se o registro está ativo ou inativo. Caso seja ativo o valor é true e caso seja inativo o valor é false.';


/*==============================================================*/
/* Index: ix_acgtb072_01                                        */
/*==============================================================*/
create unique index ix_acgtb072_01 on acgsm001.acgtb072_credenciador (
co_cnpj_credenciador
);
