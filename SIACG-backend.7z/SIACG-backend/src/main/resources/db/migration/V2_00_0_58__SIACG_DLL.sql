
/*==============================================================*/
/* Table: acgsm001.acgtb092_fornecedor                          */
/*==============================================================*/

 ALTER table acgsm001.acgtb092_fornecedor 
 add column ic_situacao          BOOLEAN              null;


comment on column acgsm001.acgtb092_fornecedor.ic_situacao is
'Situação do fornecedor como ativa ou não. ';