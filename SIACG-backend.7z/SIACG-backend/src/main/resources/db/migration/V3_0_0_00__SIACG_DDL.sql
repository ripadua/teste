/*============================================================*/
/*           SCRIPT V3_0_0_00__SIACG_DDL		              */
/*============================================================*/

ALTER TABLE ACG.ACGTB069_BANDEIRA_CARTAO ADD CO_BANDEIRA_CARTAO VARCHAR2(3);
ALTER TABLE ACG.ACGTB069_BANDEIRA_CARTAO ADD IC_REGISTRADORA NUMBER DEFAULT 0 NOT NULL;

COMMENT ON COLUMN ACG.ACGTB069_BANDEIRA_CARTAO.CO_BANDEIRA_CARTAO IS 'Codigo de identificação da bandeira na registradora';
COMMENT ON COLUMN ACG.ACGTB069_BANDEIRA_CARTAO.IC_REGISTRADORA IS 'Indica se a bandeira deve ser enviada para a registradora no caso de gravame';


/*==============================================================*/
/* Reverter                                                     */
/*==============================================================*/
-- ALTER TABLE ACG.ACGTB069_BANDEIRA_CARTAO DROP COLUMN CO_BANDEIRA_CARTAO;
-- ALTER TABLE ACG.ACGTB069_BANDEIRA_CARTAO DROP COLUMN IC_REGISTRADORA;