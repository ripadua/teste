COMMENT ON COLUMN acgsm001.acgtb089_gestao_serventia.co_cns IS 'Coluna que descreve ao Cadastro Nacional de Serventias.';
COMMENT ON COLUMN acgsm001.acgtb089_gestao_serventia.denominacao IS 'Coluna que descreve a denominação da serventia';
COMMENT ON COLUMN acgsm001.acgtb089_gestao_serventia.sg_uf IS 'Coluna que descreve a sigla da unidade federativa.';
COMMENT ON COLUMN acgsm001.acgtb089_gestao_serventia.de_municipio IS 'Coluna que descreve a descrição do municipio.';
COMMENT ON COLUMN acgsm001.acgtb089_gestao_serventia.observacao IS 'Coluna que descreve alguma observação em especifica da serventia.';
COMMENT ON COLUMN acgsm001.acgtb089_gestao_serventia.ic_ativo IS 'Define a situação da serventia, ativo ou inativo.';