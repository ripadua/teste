/*==============================================================*/
/* SCRIPT V2_00_0_09__SIACG_DLL									*/
/*==============================================================*/

INSERT INTO acgsm001.acgtb008_grupo_garantia(
            nu_grupo_garantia, no_grupo_garantia, ic_acompanha, ic_ativo)
    VALUES ((select max(coalesce(nu_grupo_garantia,0)) + 1 as nu from acgsm001.acgtb008_grupo_garantia), 'EMPREENDIMENTOS', TRUE, TRUE);
    
        
ALTER TABLE acgsm001.acgtb012_analise_contrato ADD COLUMN in_recebiveis numeric(16,2);
comment on column acgsm001.acgtb012_analise_contrato.in_recebiveis is
'Armazena o Índice Esperado Recebíveis calculado. Valor de avaliação uh hipotecadas (somatório de todas as unidades que estiverem como mantida em hipoteca) + Valor do penhor de recebíveis com vencimento após o término de obra dos contratos / saldo devedor + saldo credor...';
