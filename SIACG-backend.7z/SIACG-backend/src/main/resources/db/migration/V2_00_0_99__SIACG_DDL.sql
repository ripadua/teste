/*==============================================================*/
/*           SCRIPT V2_00_0_99__SIACG_DLL						*/
/*==============================================================*/

/*==============================================================*/
/* Table: acgsm001.acgtb069_bandeira_cartao                     */
/*==============================================================*/

alter table acgsm001.acgtb069_bandeira_cartao add column ic_origem integer not null default '1' constraint CKC_IC_ORIGEM_ACGTB069 check (ic_origem in ('1','2'));

comment on column acgsm001.acgtb069_bandeira_cartao.ic_origem is
'Campo que representa a origem da inclusão, podendo ser: 
1 - ETL, 
2 - API';

/*==============================================================*/
/* Reverse Table                                                */
/*==============================================================*/
--alter table acgsm001.acgtb069_bandeira_cartao drop column ic_origem;