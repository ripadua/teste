ALTER TABLE acgsm001.acgtb081_imoveis
  ADD COLUMN nome_imovel_rural  character varying(50);