
/*==============================================================*/
/* Alter Table: acgtb092_fornecedor                             */
/*==============================================================*/
alter table acgsm001.acgtb092_fornecedor 
   add column nu_agencia_dv        INT                 null,
   add column nu_conta_dv          INT                 null;


comment on column acgsm001.acgtb092_fornecedor.nu_agencia_dv is
'Digito verificador da agencia';


comment on column acgsm001.acgtb092_fornecedor.nu_conta_dv is
'Digito verificador da conta';



/*==============================================================*/
/* Reverse  Alter Table: acgtb092_fornecedor                    */
/*==============================================================*/
--alter table acgsm001.acgtb092_fornecedor 
--  DROP column nu_agencia_dv        INT(2)                 null,
--  DROP column nu_conta_dv          INT(2)                 null;
   
   
   