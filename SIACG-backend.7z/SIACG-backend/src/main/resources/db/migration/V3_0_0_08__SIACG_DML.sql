/*============================================================*/
/*           SCRIPT V3_0_0_08__SIACG_DDL		              */
/*============================================================*/

ALTER TABLE ACG.ACGTBS13_VEICULO RENAME COLUMN IC_SITUACAO TO IC_SITUACAO;

COMMENT ON COLUMN ACG.ACGTBS13_VEICULO.IC_SITUACAO IS 'Situacao de gravame do veículo
Baixado
Realizado';

/*==============================================================*/
/* Reverter                                                     */
/*==============================================================*/
--ALTER TABLE ACG.ACGTBS13_VEICULO DROP COLUMN IC_SITUACAO;