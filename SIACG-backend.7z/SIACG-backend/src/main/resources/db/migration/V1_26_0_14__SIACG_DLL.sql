-- Removendo coluna ic_bandeira
ALTER TABLE acgsm001.acgtb030_cartao_credito DROP COLUMN IF EXISTS ic_bandeira;
ALTER TABLE acgsm001.acgtb033_garantia_cartao_credito DROP COLUMN IF EXISTS ic_bandeira;

 -- Removendo colunas hardcoded na tabela de analise cartao
ALTER TABLE acgsm001.acgtb034_analise_cartao_credito DROP COLUMN IF EXISTS vr_saldo_total_visa;
ALTER TABLE acgsm001.acgtb034_analise_cartao_credito DROP COLUMN IF EXISTS vr_saldo_total_master;
ALTER TABLE acgsm001.acgtb034_analise_cartao_credito DROP COLUMN IF EXISTS vr_grnts_otrs_cntrs_visa;
ALTER TABLE acgsm001.acgtb034_analise_cartao_credito DROP COLUMN IF EXISTS vr_grnts_otrs_cntrs_master;
ALTER TABLE acgsm001.acgtb034_analise_cartao_credito DROP COLUMN IF EXISTS vr_grnts_do_cntro_visa;
ALTER TABLE acgsm001.acgtb034_analise_cartao_credito DROP COLUMN IF EXISTS vr_grnts_do_cntro_master;
ALTER TABLE acgsm001.acgtb034_analise_cartao_credito DROP COLUMN IF EXISTS vr_saldo_possivel_visa;
ALTER TABLE acgsm001.acgtb034_analise_cartao_credito DROP COLUMN IF EXISTS vr_saldo_possivel_master;
  
-- Removendo colunas para normalização
ALTER TABLE acgsm001.acgtb042_saldo DROP COLUMN IF EXISTS vr_cartao_fluxo_visa;
ALTER TABLE acgsm001.acgtb042_saldo DROP COLUMN IF EXISTS vr_cartao_fluxo_master;
ALTER TABLE acgsm001.acgtb042_saldo DROP COLUMN IF EXISTS vr_cartao_estoque_visa;
ALTER TABLE acgsm001.acgtb042_saldo DROP COLUMN IF EXISTS vr_cartao_estoque_master;