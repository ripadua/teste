CREATE OR REPLACE VIEW acgsm001.acgvw009_produto AS 
 SELECT icotbo10_produto.co_ultima_situacao,
    icotbo10_produto.nu_produto,
    icotbo10_produto.no_produto,
    icotbo10_produto.no_comercial_prdto,
    icotbo11_sgmnoatnd.nu_segmento_atndo,
    icotbo11_sgmnoatnd.no_segmento_atndo,
    icotbs03_sistema.nu_natural_sistema,
    icotbs03_sistema.sg_sistema,
    icotbo07_gestao.nu_natural_u24,
    icotbu24_unidade.sg_unidade,
    icotbo23_operacao.nu_operacao,
    icotbo23_operacao.no_operacao
   FROM icosm001.icotbo11_sgmnoatnd,
    icosm001.icotbo12_atndoprdo,
    icosm001.icotbo10_produto,
    icosm001.icotbo25_siscntprd,
    icosm001.icotbs03_sistema,
    icosm001.icotbo07_gestao,
    icosm001.icotbu24_unidade,
    icosm001.icotbo23_operacao
  WHERE icotbo11_sgmnoatnd.nu_segmento_atndo = icotbo12_atndoprdo.nu_sgmno_atndo_o11 AND icotbo12_atndoprdo.dt_fim_atndo_prdto IS NOT NULL AND icotbo12_atndoprdo.nu_produto_o10 = icotbo10_produto.nu_produto AND (icotbo11_sgmnoatnd.nu_segmento_atndo = ANY (ARRAY[3, 4, 7])) AND icotbo10_produto.co_ultima_situacao = 'AT'::bpchar AND icotbo10_produto.nu_produto = icotbo25_siscntprd.nu_produto_o10 AND icotbo25_siscntprd.nu_sistema_s03 = icotbs03_sistema.nu_natural_sistema AND icotbo07_gestao.nu_produto_o10 = icotbo10_produto.nu_produto AND icotbo07_gestao.dt_fim_gestao IS NOT NULL AND icotbo07_gestao.nu_natural_u24 = icotbu24_unidade.nu_unidade AND icotbo23_operacao.nu_operacao = icotbo10_produto.nu_operacao_o23
  ORDER BY icotbo11_sgmnoatnd.no_segmento_atndo;
