/*================================================================================================*/
                                    -- V2_00_0_10__SIACG_DLL.sql
/*================================================================================================*/
comment on column acgsm002.ACGTBS01_CONTRATO.NU_UNIDADE_CONCESSORA is 'Número da unidade concessora da operação de crédito do contrato.';
comment on column acgsm002.ACGTBS01_CONTRATO.CO_AVALIACAO_OPERACAO is 'Código de avaliação da operação de crédito no sistema de análise de risco de crédito.';
comment on column acgsm002.ACGTBS01_CONTRATO.CO_CONTRATO_DV is 'Dígito verificador do contrato.';
comment on column acgsm002.ACGTBS01_CONTRATO.CO_CONTRATO_SEM_DV is 'Código do contrato sem o dígito verificador.';
comment on column acgsm002.ACGTBS01_CONTRATO.CO_UNIDADE_CONTA_CORRENTE is 'Código da unidade da conta corrente vinculada ao contrato.';
comment on column acgsm002.ACGTBS01_CONTRATO.CO_OPERACAO_CONTA_CORRENTE is 'Código da operação da conta corrente.';
comment on column acgsm002.ACGTBS01_CONTRATO.CO_CONTA_CORRENTE is 'Conta corrente do contrato.';
comment on column acgsm002.ACGTBS01_CONTRATO.CO_CONTA_CORRENTE_DV is 'Dígito verificador da conta corrente do contrato.';
comment on column acgsm002.ACGTBS01_CONTRATO.CO_PRAZO is 'Código do tipo de prazo definido para o contrato.';
comment on column acgsm002.ACGTBS01_CONTRATO.VR_SALDO_DEVEDOR is 'Valor do saldo devedor do contrato.';
comment on column acgsm002.ACGTBS01_CONTRATO.VR_PRESTACAO is 'Valor da prestação acordada para o contrato.';
comment on column acgsm002.ACGTBS01_CONTRATO.VR_MAXIMO_EMPRESTIMO is 'Valor máximo liberado para utilização. Esse valor se refere a operações de crédito rotativo.';
comment on column acgsm002.ACGTBS01_CONTRATO.VR_PRIMEIRA_PRESTACAO is 'Valor da primeira prestação do contrato.';
comment on column acgsm002.ACGTBS01_CONTRATO.QT_PRAZO_CONTRATO is 'Prazo do contrato.';
comment on column acgsm002.ACGTBS01_CONTRATO.CO_GARANTIA_01 is 'Código da garantia do contrato.';
comment on column acgsm002.ACGTBS01_CONTRATO.CO_GARANTIA_02 is 'Código da garantia do contrato.';
comment on column acgsm002.ACGTBS01_CONTRATO.CO_GARANTIA_03 is 'Código da garantia do contrato.';
comment on column acgsm002.ACGTBS01_CONTRATO.CO_GARANTIA_04 is 'Código da garantia do contrato.';
comment on column acgsm002.ACGTBS01_CONTRATO.CO_GARANTIA_05 is 'Código da garantia do contrato.';
comment on column acgsm002.ACGTBS01_CONTRATO.CO_GARANTIA_06 is 'Código da garantia do contrato.';
comment on column acgsm002.ACGTBS01_CONTRATO.CO_GARANTIA_07 is 'Código da garantia do contrato.';
comment on column acgsm002.ACGTBS01_CONTRATO.CO_GARANTIA_08 is 'Código da garantia do contrato.';
comment on column acgsm002.ACGTBS01_CONTRATO.CO_GARANTIA_09 is 'Código da garantia do contrato.';
comment on column acgsm002.ACGTBS01_CONTRATO.CO_GARANTIA_10 is 'Código da garantia do contrato.';
comment on column acgsm002.ACGTBS01_CONTRATO.CO_GARANTIA_11 is 'Código da garantia do contrato.';
comment on column acgsm002.ACGTBS01_CONTRATO.CO_GARANTIA_12 is 'Código da garantia do contrato.';
comment on column acgsm002.ACGTBS01_CONTRATO.CO_GARANTIA_13 is 'Código da garantia do contrato.';
comment on column acgsm002.ACGTBS01_CONTRATO.CO_GARANTIA_14 is 'Código da garantia do contrato.';
comment on column acgsm002.ACGTBS01_CONTRATO.CO_GARANTIA_15 is 'Código da garantia do contrato.';
comment on column acgsm002.ACGTBS01_CONTRATO.CO_GARANTIA_16 is 'Código da garantia do contrato.';
comment on column acgsm002.ACGTBS01_CONTRATO.CO_GARANTIA_17 is 'Código da garantia do contrato.';
comment on column acgsm002.ACGTBS01_CONTRATO.CO_GARANTIA_18 is 'Código da garantia do contrato.';
comment on column acgsm002.ACGTBS01_CONTRATO.CO_GARANTIA_19 is 'Código da garantia do contrato.';
comment on column acgsm002.ACGTBS01_CONTRATO.CO_GARANTIA_20 is 'Código da garantia do contrato.';
comment on column acgsm002.ACGTBS01_CONTRATO.VR_GARANTIA_01 is 'Valor da garantia do contrato.';
comment on column acgsm002.ACGTBS01_CONTRATO.VR_GARANTIA_02 is 'Valor da garantia do contrato.';
comment on column acgsm002.ACGTBS01_CONTRATO.VR_GARANTIA_03 is 'Valor da garantia do contrato.';
comment on column acgsm002.ACGTBS01_CONTRATO.VR_GARANTIA_04 is 'Valor da garantia do contrato.';
comment on column acgsm002.ACGTBS01_CONTRATO.VR_GARANTIA_05 is 'Valor da garantia do contrato.';
comment on column acgsm002.ACGTBS01_CONTRATO.VR_GARANTIA_06 is 'Valor da garantia do contrato.';
comment on column acgsm002.ACGTBS01_CONTRATO.VR_GARANTIA_07 is 'Valor da garantia do contrato.';
comment on column acgsm002.ACGTBS01_CONTRATO.VR_GARANTIA_08 is 'Valor da garantia do contrato.';
comment on column acgsm002.ACGTBS01_CONTRATO.VR_GARANTIA_09 is 'Valor da garantia do contrato.';
comment on column acgsm002.ACGTBS01_CONTRATO.VR_GARANTIA_10 is 'Valor da garantia do contrato.';
comment on column acgsm002.ACGTBS01_CONTRATO.VR_GARANTIA_11 is 'Valor da garantia do contrato.';
comment on column acgsm002.ACGTBS01_CONTRATO.VR_GARANTIA_12 is 'Valor da garantia do contrato.';
comment on column acgsm002.ACGTBS01_CONTRATO.VR_GARANTIA_13 is 'Valor da garantia do contrato.';
comment on column acgsm002.ACGTBS01_CONTRATO.VR_GARANTIA_14 is 'Valor da garantia do contrato.';
comment on column acgsm002.ACGTBS01_CONTRATO.VR_GARANTIA_15 is 'Valor da garantia do contrato.';
comment on column acgsm002.ACGTBS01_CONTRATO.VR_GARANTIA_16 is 'Valor da garantia do contrato.';
comment on column acgsm002.ACGTBS01_CONTRATO.VR_GARANTIA_17 is 'Valor da garantia do contrato.';
comment on column acgsm002.ACGTBS01_CONTRATO.VR_GARANTIA_18 is 'Valor da garantia do contrato.';
comment on column acgsm002.ACGTBS01_CONTRATO.VR_GARANTIA_19 is 'Valor da garantia do contrato.';
comment on column acgsm002.ACGTBS01_CONTRATO.VR_GARANTIA_20 is 'Valor da garantia do contrato.';
comment on column acgsm002.ACGTBS01_CONTRATO.SG_SISTEMA_ORIGEM is 'Sigla do sistema de origem dos contratos.
Ex: SIDEC, SIAPI, SIFBN, SIEMP';
comment on column acgsm002.ACGTBS01_CONTRATO.NO_ARQUIVO is 'Nome do arquivo transmitido pelo sistema de origem.';
comment on column acgsm002.ACGTBS01_CONTRATO.TS_PROCESSAMENTO is 'Data e hora do processamento das informações pelo sistema de origem.';
comment on column acgsm002.ACGTBS01_CONTRATO.DT_REFERENCIA is 'Data de referência das informações.';
comment on column acgsm002.ACGTBS01_CONTRATO.IC_ATIVO is 'Indica se o título está ativo.
"TRUE = Ativo
FALSE = Inativo"
';

comment on column acgsm002.ACGTBS08_DUPLICATA.CO_CEDENTE is 'Código do cedente.';
comment on column acgsm002.ACGTBS08_DUPLICATA.NO_CEDENTE is 'Nome do cedente.';
comment on column acgsm002.ACGTBS08_DUPLICATA.NO_SACADO is 'Nome do sacado.';
comment on column acgsm002.ACGTBS08_DUPLICATA.NO_CARTEIRA is 'Nome da carteira ao qual o título está vinculado.';
comment on column acgsm002.ACGTBS08_DUPLICATA.VR_TITULO is 'Valor do título.';
comment on column acgsm002.ACGTBS08_DUPLICATA.CO_CANCELAMENTO is 'Código de cancelamento do título.';
comment on column acgsm002.ACGTBS08_DUPLICATA.DT_LIQUIDACAO is 'Data de liquidação do título.';
comment on column acgsm002.ACGTBS08_DUPLICATA.CO_SITUACAO_TITULO is 'Código da situação do título.';
comment on column acgsm002.ACGTBS08_DUPLICATA.IC_PROTESTO is 'Indicador do envio do título para protesto.
"SIM = Protesto
NÃO = Sem protesto"
';
comment on column acgsm002.ACGTBS08_DUPLICATA.CO_TIPO_TITULO is 'Código do tipo de título.';
comment on column acgsm002.ACGTBS08_DUPLICATA.DT_VENCIMENTO is 'Data de vencimento do título.';
comment on column acgsm002.ACGTBS08_DUPLICATA.DT_ENTRADA is 'Data de entrada do título no sistema de origem..';
comment on column acgsm002.ACGTBS08_DUPLICATA.DT_SITUACAO is 'Data de atualização da situação atual do título.';
comment on column acgsm002.ACGTBS08_DUPLICATA.DT_MOVIMENTO is 'Data do movimento em que foram geradas as informações no sistema de origem.';
comment on column acgsm002.ACGTBS08_DUPLICATA.SG_SISTEMA_ORIGEM is 'Sigla do sistema de origem das informações.';
comment on column acgsm002.ACGTBS08_DUPLICATA.CO_ESPECIE_TITULO is 'Código da espécie do título.';
comment on column acgsm002.ACGTBS08_DUPLICATA.NO_ARQUIVO is 'Nome do arquivo transmitido pelo sistema de origem.';
comment on column acgsm002.ACGTBS08_DUPLICATA.TS_PROCESSAMENTO is 'Data e hora do processamento das informações pelo sistema de origem.';
comment on column acgsm002.ACGTBS08_DUPLICATA.DT_REFERENCIA is 'Data de referência das informações.';
comment on column acgsm002.ACGTBS08_DUPLICATA.IC_ATIVO is 'Indica se o título está ativo
"TRUE = Ativo
FALSE = Inativo"
';
