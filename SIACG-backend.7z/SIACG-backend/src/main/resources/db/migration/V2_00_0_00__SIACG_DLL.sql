/*================================================================================================*/
                                    -- V2_00_0_00__SIACG_DLL.sql
/*================================================================================================*/

ALTER TABLE acgsm001.acgtb033_garantia_cartao_credito ADD COLUMN pc_concentracao numeric(16,2);
COMMENT ON COLUMN acgsm001.acgtb033_garantia_cartao_credito.pc_concentracao IS 'Valor do percentual de concentracao para a bandeira do cartão de crédito.';

