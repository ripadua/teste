/*============================================================*/
/*           SCRIPT V2_09_0_03__SIACG_DML				      */
/*============================================================*/

--Atualiza a garantia de bem do cliente do tipo imóvel com o valor da garantia do contrato
update acgsm001.acgtb108_garantia_bem_cliente gbc
set vr_utilizado = bkp.vr_garantia
from 
(
	select gc.nu_garantia_contrato, gc.vr_garantia  
	from acgsm001.acgtb108_garantia_bem_cliente gbc
	inner join acgsm001.acgtb009_garantia_contrato gc on gc.nu_garantia_contrato = gbc.nu_garantia_contrato
	inner join acgsm001.acgtb106_bem_cliente bc on bc.nu_bem_cliente = gbc.nu_bem_cliente
	where bc.nu_imovel is not null and gbc.vr_utilizado is null
) bkp
where gbc.nu_garantia_contrato = bkp.nu_garantia_contrato;


-- Atualiza a garantia do contrato com o vr_garantia = 0 para os bens do cliente que possui imóvel
update acgsm001.acgtb009_garantia_contrato gc
set vr_garantia = 0
from 
(
	select gbc.nu_garantia_contrato
	from acgsm001.acgtb108_garantia_bem_cliente gbc
	inner join acgsm001.acgtb106_bem_cliente bc on bc.nu_bem_cliente = gbc.nu_bem_cliente
	where bc.nu_imovel is not null and gbc.vr_utilizado is not null
) bkp
where gc.nu_garantia_contrato = bkp.nu_garantia_contrato;