alter table acgsm001.acgtb009_garantia_contrato
add column nu_ano integer null,
add column de_tipo_bem character varying(250) null,
add column de_tipo_insumo_agricola character varying(250) null,
add column nu_quantidade integer null;


comment on column acgsm001.acgtb009_garantia_contrato.nu_ano is 'Ano da Garantia';
comment on column acgsm001.acgtb009_garantia_contrato.de_tipo_bem is 'Tipo de Bem';
comment on column acgsm001.acgtb009_garantia_contrato.de_tipo_insumo_agricola is 'Tipo do Insumo Agricola';
comment on column acgsm001.acgtb009_garantia_contrato.nu_quantidade is 'Quantidade';