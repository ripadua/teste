do $$

begin

if NOT exists (
   select 'pk_acgtb034_analise_cartao_credito' 
   from information_schema.table_constraints 
   where table_name = 'acgtb034_analise_cartao_credito'
   and table_schema = 'acgsm001' 
   and constraint_type = 'PRIMARY KEY'
   ) then

ALTER TABLE acgsm001.acgtb034_analise_cartao_credito
  ADD CONSTRAINT pk_acgtb034_analise_cartao_credito PRIMARY KEY (nu_analise_cartao_credito);

end if;

end $$;



/*==============================================================*/
/* Table: acgtb069_bandeira_cartao                              */
/*==============================================================*/
create table acgsm001.acgtb069_bandeira_cartao (
   nu_bandeira_cartao   int4                 not null,
   no_bandeira_cartao   VARCHAR(50)          not null,
   ic_tipo_movimentacao VARCHAR(1)           not null
      constraint CKC_IC_TIPO_MOVIMENTA_ACGTB069 check (ic_tipo_movimentacao in ('0','1','2')),
   ic_ativo             BOOL                 not null default true,
   im_bandeira_cartao   TEXT                 null,
   constraint pk_acgtb069_bandeira_cartao primary key (nu_bandeira_cartao)
);

comment on table acgsm001.acgtb069_bandeira_cartao is
'Armazena as bandeiras de cartões com a especificação se é bandeira de pré-pago, débito ou crédito

Ex.:

- VISA - CRÉDITO
- VISA ELÉCTRON - DÉBITO
- VISA PRÉ-PAGO - PRÉ-PAGO
- MASTERCARD - CRÉDITO
- MAESTRO- DÉBITO
- MASTERCARD PRÉ-PAGO - PRÉ-PAGO';

comment on column acgsm001.acgtb069_bandeira_cartao.nu_bandeira_cartao is
'Identificador único da bandeira do cartao';

comment on column acgsm001.acgtb069_bandeira_cartao.no_bandeira_cartao is
'Nome da bandeira do cartão';

comment on column acgsm001.acgtb069_bandeira_cartao.ic_tipo_movimentacao is
'Indica o tipo de movimentação da bandeira:

0 - Débito
1 - Crédito
2 - Pré-pago';

comment on column acgsm001.acgtb069_bandeira_cartao.ic_ativo is
'Indica se a bandeira do cartão está ativa no sistema. Somente as bandeiras ativas serão apresentadas na parametrização do sistema.';

comment on column acgsm001.acgtb069_bandeira_cartao.im_bandeira_cartao is
'Imagem da bandeira do cartão em formato base64 para ser apresentado nos relatórios de analise e pré analise.';

-- inserindo dominio das bandeiras de cartão
INSERT INTO acgsm001.acgtb069_bandeira_cartao(nu_bandeira_cartao, no_bandeira_cartao, ic_tipo_movimentacao, ic_ativo) VALUES (3, 'Mastercard', 1, true);
INSERT INTO acgsm001.acgtb069_bandeira_cartao(nu_bandeira_cartao, no_bandeira_cartao, ic_tipo_movimentacao, ic_ativo) VALUES (4, 'Visa', 1, true);
INSERT INTO acgsm001.acgtb069_bandeira_cartao(nu_bandeira_cartao, no_bandeira_cartao, ic_tipo_movimentacao, ic_ativo) VALUES (5, 'Diners Club', 1, true);
INSERT INTO acgsm001.acgtb069_bandeira_cartao(nu_bandeira_cartao, no_bandeira_cartao, ic_tipo_movimentacao, ic_ativo) VALUES (6, 'American Express', 1, true);
INSERT INTO acgsm001.acgtb069_bandeira_cartao(nu_bandeira_cartao, no_bandeira_cartao, ic_tipo_movimentacao, ic_ativo) VALUES (7, 'Hiper Débito', 0, false);
INSERT INTO acgsm001.acgtb069_bandeira_cartao(nu_bandeira_cartao, no_bandeira_cartao, ic_tipo_movimentacao, ic_ativo) VALUES (8, 'Elo', 1, true);
INSERT INTO acgsm001.acgtb069_bandeira_cartao(nu_bandeira_cartao, no_bandeira_cartao, ic_tipo_movimentacao, ic_ativo) VALUES (9, 'Alelo', 2, false);
INSERT INTO acgsm001.acgtb069_bandeira_cartao(nu_bandeira_cartao, no_bandeira_cartao, ic_tipo_movimentacao, ic_ativo) VALUES (10, 'Cabal', 1, false);
INSERT INTO acgsm001.acgtb069_bandeira_cartao(nu_bandeira_cartao, no_bandeira_cartao, ic_tipo_movimentacao, ic_ativo) VALUES (11, 'Agiplan', 1, false);
INSERT INTO acgsm001.acgtb069_bandeira_cartao(nu_bandeira_cartao, no_bandeira_cartao, ic_tipo_movimentacao, ic_ativo) VALUES (12, 'Aura', 1, false);
INSERT INTO acgsm001.acgtb069_bandeira_cartao(nu_bandeira_cartao, no_bandeira_cartao, ic_tipo_movimentacao, ic_ativo) VALUES (13, 'Banescard', 1, false);
INSERT INTO acgsm001.acgtb069_bandeira_cartao(nu_bandeira_cartao, no_bandeira_cartao, ic_tipo_movimentacao, ic_ativo) VALUES (14, 'Calcard', 1, false);
INSERT INTO acgsm001.acgtb069_bandeira_cartao(nu_bandeira_cartao, no_bandeira_cartao, ic_tipo_movimentacao, ic_ativo) VALUES (15, 'Credsystem', 1, false);
INSERT INTO acgsm001.acgtb069_bandeira_cartao(nu_bandeira_cartao, no_bandeira_cartao, ic_tipo_movimentacao, ic_ativo) VALUES (16, 'Cup', 1, false);
INSERT INTO acgsm001.acgtb069_bandeira_cartao(nu_bandeira_cartao, no_bandeira_cartao, ic_tipo_movimentacao, ic_ativo) VALUES (17, 'Redesplan', 1, false);
INSERT INTO acgsm001.acgtb069_bandeira_cartao(nu_bandeira_cartao, no_bandeira_cartao, ic_tipo_movimentacao, ic_ativo) VALUES (18, 'Sicred', 1, false);
INSERT INTO acgsm001.acgtb069_bandeira_cartao(nu_bandeira_cartao, no_bandeira_cartao, ic_tipo_movimentacao, ic_ativo) VALUES (19, 'Sorocred', 1, false);
INSERT INTO acgsm001.acgtb069_bandeira_cartao(nu_bandeira_cartao, no_bandeira_cartao, ic_tipo_movimentacao, ic_ativo) VALUES (20, 'Verdecard', 1, false);
INSERT INTO acgsm001.acgtb069_bandeira_cartao(nu_bandeira_cartao, no_bandeira_cartao, ic_tipo_movimentacao, ic_ativo) VALUES (21, 'Hipercard', 1, true);
INSERT INTO acgsm001.acgtb069_bandeira_cartao(nu_bandeira_cartao, no_bandeira_cartao, ic_tipo_movimentacao, ic_ativo) VALUES (22, 'Avista', 1, false);
INSERT INTO acgsm001.acgtb069_bandeira_cartao(nu_bandeira_cartao, no_bandeira_cartao, ic_tipo_movimentacao, ic_ativo) VALUES (23, 'Credz', 1, false);
INSERT INTO acgsm001.acgtb069_bandeira_cartao(nu_bandeira_cartao, no_bandeira_cartao, ic_tipo_movimentacao, ic_ativo) VALUES (24, 'Discover', 1, false);
INSERT INTO acgsm001.acgtb069_bandeira_cartao(nu_bandeira_cartao, no_bandeira_cartao, ic_tipo_movimentacao, ic_ativo) VALUES (25, 'Maestro', 0, false);
INSERT INTO acgsm001.acgtb069_bandeira_cartao(nu_bandeira_cartao, no_bandeira_cartao, ic_tipo_movimentacao, ic_ativo) VALUES (26, 'Visa Electron', 0, false);
INSERT INTO acgsm001.acgtb069_bandeira_cartao(nu_bandeira_cartao, no_bandeira_cartao, ic_tipo_movimentacao, ic_ativo) VALUES (27, 'Elo Débito', 0, false);
INSERT INTO acgsm001.acgtb069_bandeira_cartao(nu_bandeira_cartao, no_bandeira_cartao, ic_tipo_movimentacao, ic_ativo) VALUES (28, 'Sicredi Débito', 0, false);
INSERT INTO acgsm001.acgtb069_bandeira_cartao(nu_bandeira_cartao, no_bandeira_cartao, ic_tipo_movimentacao, ic_ativo) VALUES (29, 'Hiper Crédito', 1, false);
INSERT INTO acgsm001.acgtb069_bandeira_cartao(nu_bandeira_cartao, no_bandeira_cartao, ic_tipo_movimentacao, ic_ativo) VALUES (30, 'Cabal Débito', 0, false);
INSERT INTO acgsm001.acgtb069_bandeira_cartao(nu_bandeira_cartao, no_bandeira_cartao, ic_tipo_movimentacao, ic_ativo) VALUES (31, 'JCB', 1, false);
INSERT INTO acgsm001.acgtb069_bandeira_cartao(nu_bandeira_cartao, no_bandeira_cartao, ic_tipo_movimentacao, ic_ativo) VALUES (32, 'Ticket', 2, false);
INSERT INTO acgsm001.acgtb069_bandeira_cartao(nu_bandeira_cartao, no_bandeira_cartao, ic_tipo_movimentacao, ic_ativo) VALUES (33, 'Sodexo', 2, false);
INSERT INTO acgsm001.acgtb069_bandeira_cartao(nu_bandeira_cartao, no_bandeira_cartao, ic_tipo_movimentacao, ic_ativo) VALUES (34, 'VR', 2, false);
INSERT INTO acgsm001.acgtb069_bandeira_cartao(nu_bandeira_cartao, no_bandeira_cartao, ic_tipo_movimentacao, ic_ativo) VALUES (35, 'Policard', 2, false);
INSERT INTO acgsm001.acgtb069_bandeira_cartao(nu_bandeira_cartao, no_bandeira_cartao, ic_tipo_movimentacao, ic_ativo) VALUES (36, 'Valecard', 2, false);
INSERT INTO acgsm001.acgtb069_bandeira_cartao(nu_bandeira_cartao, no_bandeira_cartao, ic_tipo_movimentacao, ic_ativo) VALUES (37, 'Goodcard', 1, false);
INSERT INTO acgsm001.acgtb069_bandeira_cartao(nu_bandeira_cartao, no_bandeira_cartao, ic_tipo_movimentacao, ic_ativo) VALUES (38, 'Greencard', 2, false);
INSERT INTO acgsm001.acgtb069_bandeira_cartao(nu_bandeira_cartao, no_bandeira_cartao, ic_tipo_movimentacao, ic_ativo) VALUES (39, 'Coopercard', 2, false);
INSERT INTO acgsm001.acgtb069_bandeira_cartao(nu_bandeira_cartao, no_bandeira_cartao, ic_tipo_movimentacao, ic_ativo) VALUES (40, 'Verocheque', 2, false);
INSERT INTO acgsm001.acgtb069_bandeira_cartao(nu_bandeira_cartao, no_bandeira_cartao, ic_tipo_movimentacao, ic_ativo) VALUES (41, 'Nutricash', 2, false);
INSERT INTO acgsm001.acgtb069_bandeira_cartao(nu_bandeira_cartao, no_bandeira_cartao, ic_tipo_movimentacao, ic_ativo) VALUES (42, 'Banricard', 2, false);
INSERT INTO acgsm001.acgtb069_bandeira_cartao(nu_bandeira_cartao, no_bandeira_cartao, ic_tipo_movimentacao, ic_ativo) VALUES (43, 'Banescard Débito', 0, false);
INSERT INTO acgsm001.acgtb069_bandeira_cartao(nu_bandeira_cartao, no_bandeira_cartao, ic_tipo_movimentacao, ic_ativo) VALUES (44, 'Socored Pré-pago', 2, false);
INSERT INTO acgsm001.acgtb069_bandeira_cartao(nu_bandeira_cartao, no_bandeira_cartao, ic_tipo_movimentacao, ic_ativo) VALUES (45, 'Mastercard Pré-pago', 2, false);
INSERT INTO acgsm001.acgtb069_bandeira_cartao(nu_bandeira_cartao, no_bandeira_cartao, ic_tipo_movimentacao, ic_ativo) VALUES (46, 'Visa Pré-pago', 2, false);
INSERT INTO acgsm001.acgtb069_bandeira_cartao(nu_bandeira_cartao, no_bandeira_cartao, ic_tipo_movimentacao, ic_ativo) VALUES (47, 'Ourocard', 0, false);
INSERT INTO acgsm001.acgtb069_bandeira_cartao(nu_bandeira_cartao, no_bandeira_cartao, ic_tipo_movimentacao, ic_ativo) VALUES (48, 'Sorocred Débito', 0, false);


-- Adicionando coluna para relacionar com tabela de bandeira
ALTER TABLE acgsm001.acgtb030_cartao_credito ADD COLUMN nu_bandeira_cartao int4;
comment on column acgsm001.acgtb030_cartao_credito.nu_bandeira_cartao is 
'Identificador único da bandeira do cartao';

ALTER TABLE acgsm001.acgtb033_garantia_cartao_credito ADD COLUMN nu_bandeira_cartao int4;
comment on column acgsm001.acgtb033_garantia_cartao_credito.nu_bandeira_cartao is 
'Identificador único da bandeira do cartao';


-- Adicionando relacionamento entre tabela de cartao com bandeira
alter table acgsm001.acgtb030_cartao_credito
   add constraint fk_acgtb030_acgtb069 foreign key (nu_bandeira_cartao)
      references acgsm001.acgtb069_bandeira_cartao (nu_bandeira_cartao)
      on update restrict
      on delete restrict;
 
alter table acgsm001.acgtb033_garantia_cartao_credito
   add constraint fk_acgtb033_acgtb069 foreign key (nu_bandeira_cartao)
      references acgsm001.acgtb069_bandeira_cartao (nu_bandeira_cartao)
      on update restrict
      on delete restrict;

--Script de adaptação dos dados TODO
update acgsm001.acgtb030_cartao_credito set nu_bandeira_cartao = 4 where ic_bandeira = 0;
update acgsm001.acgtb030_cartao_credito set nu_bandeira_cartao = 3 where ic_bandeira = 1;
update acgsm001.acgtb033_garantia_cartao_credito set nu_bandeira_cartao = 4 where ic_bandeira = 0;
update acgsm001.acgtb033_garantia_cartao_credito set nu_bandeira_cartao = 3 where ic_bandeira = 1;
      
-- Removendo coluna ic_bandeira
ALTER TABLE acgsm001.acgtb030_cartao_credito DROP COLUMN ic_bandeira;
ALTER TABLE acgsm001.acgtb033_garantia_cartao_credito DROP COLUMN ic_bandeira;


-- Cria sequence para a tabela 070
CREATE SEQUENCE acgsm001.acgsq070_anlse_cartao_bandeira
  INCREMENT 1
  MINVALUE 1
  MAXVALUE 9223372036854775807
  START 1
  CACHE 1;

/*==============================================================*/
/* Table: acgtb070_anlse_cartao_bandeira                        */
/*==============================================================*/
create table acgsm001.acgtb070_anlse_cartao_bandeira (
   nu_anlse_cartao_bandeira int8                 not null default nextval('acgsm001.acgsq070_anlse_cartao_bandeira'),
   nu_analise_cartao_credito int4                not null,
   nu_bandeira_cartao   int4                 not null,
   vr_saldo_total       NUMERIC(16,2)        not null,
   vr_grnts_otrs_cntrs  NUMERIC(16,2)        not null,
   vr_grnts_do_cntro    NUMERIC(16,2)        not null,
   vr_saldo_possivel    NUMERIC(16,2)        not null,
   constraint pk_acgtb070_anlse_cartao_bandeira primary key (nu_anlse_cartao_bandeira)
);

comment on table acgsm001.acgtb070_anlse_cartao_bandeira is
'Informações consolidadas de uma análise do grupo de garantias de cartão para uma análise de contrato de um tipo determinado de bandeira.';

comment on column acgsm001.acgtb070_anlse_cartao_bandeira.nu_anlse_cartao_bandeira is
'Identificador único do registro de analise consolidada de cartão de uma bandeira';

comment on column acgsm001.acgtb070_anlse_cartao_bandeira.nu_analise_cartao_credito is
'Identificador da Análise de Cartão de Crédito. Gerado automaticamente pelo Sistema.';

comment on column acgsm001.acgtb070_anlse_cartao_bandeira.nu_bandeira_cartao is
'Identificador único da bandeira do cartao';

comment on column acgsm001.acgtb070_anlse_cartao_bandeira.vr_saldo_total is
'Valor total do saldo total de cartão';

comment on column acgsm001.acgtb070_anlse_cartao_bandeira.vr_grnts_otrs_cntrs is
'Valor total do saldo de cartão utilizado em outros contratos';

comment on column acgsm001.acgtb070_anlse_cartao_bandeira.vr_grnts_do_cntro is
'Valor total do saldo de cartão utilizado no contrato em questão.';

comment on column acgsm001.acgtb070_anlse_cartao_bandeira.vr_saldo_possivel is
'Valor total do saldo possível para Pré-Análise.';


alter table acgsm001.acgtb070_anlse_cartao_bandeira
   add constraint fk_acgtb070_acgtb034 foreign key (nu_analise_cartao_credito)
      references acgsm001.acgtb034_analise_cartao_credito (nu_analise_cartao_credito)
      on delete restrict on update restrict;

alter table acgsm001.acgtb070_anlse_cartao_bandeira
   add constraint fk_acgtb070_acgtb069 foreign key (nu_bandeira_cartao)
      references acgsm001.acgtb069_bandeira_cartao (nu_bandeira_cartao)
      on delete restrict on update restrict;
      
      
  --Script de adaptação dos dados TODO
 INSERT INTO acgsm001.acgtb070_anlse_cartao_bandeira(
            nu_analise_cartao_credito, nu_bandeira_cartao, 
            vr_saldo_total, vr_grnts_otrs_cntrs, vr_grnts_do_cntro, vr_saldo_possivel)
 SELECT nu_analise_cartao_credito, 4,
	vr_saldo_total_visa, vr_grnts_otrs_cntrs_visa, vr_grnts_do_cntro_visa, vr_saldo_possivel_visa
 FROM acgsm001.acgtb034_analise_cartao_credito;

 INSERT INTO acgsm001.acgtb070_anlse_cartao_bandeira(
            nu_analise_cartao_credito, nu_bandeira_cartao, 
            vr_saldo_total, vr_grnts_otrs_cntrs, vr_grnts_do_cntro, vr_saldo_possivel)
 SELECT nu_analise_cartao_credito, 3,
	vr_saldo_total_master, vr_grnts_otrs_cntrs_master, vr_grnts_do_cntro_master, vr_saldo_possivel_master
 FROM acgsm001.acgtb034_analise_cartao_credito;    

  -- Removendo colunas hardcoded na tabela de analise cartao
  ALTER TABLE acgsm001.acgtb034_analise_cartao_credito DROP COLUMN vr_saldo_total_visa;
  ALTER TABLE acgsm001.acgtb034_analise_cartao_credito DROP COLUMN vr_saldo_total_master;
  ALTER TABLE acgsm001.acgtb034_analise_cartao_credito DROP COLUMN vr_grnts_otrs_cntrs_visa;
  ALTER TABLE acgsm001.acgtb034_analise_cartao_credito DROP COLUMN vr_grnts_otrs_cntrs_master;
  ALTER TABLE acgsm001.acgtb034_analise_cartao_credito DROP COLUMN vr_grnts_do_cntro_visa;
  ALTER TABLE acgsm001.acgtb034_analise_cartao_credito DROP COLUMN vr_grnts_do_cntro_master;
  ALTER TABLE acgsm001.acgtb034_analise_cartao_credito DROP COLUMN vr_saldo_possivel_visa;
  ALTER TABLE acgsm001.acgtb034_analise_cartao_credito DROP COLUMN vr_saldo_possivel_master;
   
   -- Criando sequence para tabela 071
CREATE SEQUENCE acgsm001.acgsq071_saldo_cartao_bandeira
  INCREMENT 1
  MINVALUE 1
  MAXVALUE 9223372036854775807
  START 1
  CACHE 1;
ALTER TABLE acgsm001.acgsq071_saldo_cartao_bandeira
  OWNER TO postgres;

/*==============================================================*/
/* Table: acgtb071_saldo_cartao_bandeira                        */
/*==============================================================*/
create table acgsm001.acgtb071_saldo_cartao_bandeira (
   nu_saldo_cartao_bandeira INT8                 not null default nextval('acgsm001.acgsq071_saldo_cartao_bandeira'),
   nu_saldo             int4                 not null,
   nu_bandeira_cartao   int4                 not null,
   vr_cartao_fluxo      NUMERIC(16,2)        not null default 0,
   vr_cartao_estoque    NUMERIC(16,2)        not null default 0,
   constraint pk_acgtb071_saldo_cartao_bandeira primary key (nu_saldo_cartao_bandeira)
);

comment on table acgsm001.acgtb071_saldo_cartao_bandeira is
'Armazena o saldos saldos líquidos de cada bandeira de cartão do cliente';

comment on column acgsm001.acgtb071_saldo_cartao_bandeira.nu_saldo_cartao_bandeira is
'Identificador único sequencial do saldo do cartão da bandeira';

comment on column acgsm001.acgtb071_saldo_cartao_bandeira.nu_saldo is
'Chave primária.';

comment on column acgsm001.acgtb071_saldo_cartao_bandeira.nu_bandeira_cartao is
'Identificador único da bandeira do cartao';

comment on column acgsm001.acgtb071_saldo_cartao_bandeira.vr_cartao_fluxo is
'Valor líquido para garantia de cartão de crédito fluxo';

comment on column acgsm001.acgtb071_saldo_cartao_bandeira.vr_cartao_estoque is
'Valor em estoque para recebimento de valores referentes a operações de cartão de crédito.
';

alter table acgsm001.acgtb071_saldo_cartao_bandeira
   add constraint fk_acgtb071_acgtb042 foreign key (nu_saldo)
      references acgsm001.acgtb042_saldo (nu_saldo)
      on delete restrict on update restrict;

alter table acgsm001.acgtb071_saldo_cartao_bandeira
   add constraint fk_acgtb071_acgtb069 foreign key (nu_bandeira_cartao)
      references acgsm001.acgtb069_bandeira_cartao (nu_bandeira_cartao)
      on delete restrict on update restrict;

-- Inserindo registros para adaptar dados
INSERT INTO acgsm001.acgtb071_saldo_cartao_bandeira(
            nu_saldo, nu_bandeira_cartao, vr_cartao_fluxo, vr_cartao_estoque)
SELECT nu_saldo, 4, vr_cartao_fluxo_visa, vr_cartao_estoque_visa
FROM acgsm001.acgtb042_saldo;

INSERT INTO acgsm001.acgtb071_saldo_cartao_bandeira(
            nu_saldo, nu_bandeira_cartao, vr_cartao_fluxo, vr_cartao_estoque)
SELECT nu_saldo, 3, vr_cartao_fluxo_master, vr_cartao_estoque_master
FROM acgsm001.acgtb042_saldo;


-- Removendo colunas para normalização
ALTER TABLE acgsm001.acgtb042_saldo DROP COLUMN vr_cartao_fluxo_visa;
ALTER TABLE acgsm001.acgtb042_saldo DROP COLUMN vr_cartao_fluxo_master;
ALTER TABLE acgsm001.acgtb042_saldo DROP COLUMN vr_cartao_estoque_visa;
ALTER TABLE acgsm001.acgtb042_saldo DROP COLUMN vr_cartao_estoque_master;


--American Express
update acgsm001.acgtb069_bandeira_cartao
set im_bandeira_cartao = 'iVBORw0KGgoAAAANSUhEUgAAAE8AAAAtCAIAAABgaqGAAAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJbWFnZVJlYWR5ccllPAAAA3ZpVFh0WE1MOmNvbS5hZG9iZS54bXAAAAAAADw/eHBhY2tldCBiZWdpbj0i77u/IiBpZD0iVzVNME1wQ2VoaUh6cmVTek5UY3prYzlkIj8+IDx4OnhtcG1ldGEgeG1sbnM6eD0iYWRvYmU6bnM6bWV0YS8iIHg6eG1wdGs9IkFkb2JlIFhNUCBDb3JlIDUuNi1jMTQyIDc5LjE2MDkyNCwgMjAxNy8wNy8xMy0wMTowNjozOSAgICAgICAgIj4gPHJkZjpSREYgeG1sbnM6cmRmPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5LzAyLzIyLXJkZi1zeW50YXgtbnMjIj4gPHJkZjpEZXNjcmlwdGlvbiByZGY6YWJvdXQ9IiIgeG1sbnM6eG1wTU09Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC9tbS8iIHhtbG5zOnN0UmVmPSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvc1R5cGUvUmVzb3VyY2VSZWYjIiB4bWxuczp4bXA9Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC8iIHhtcE1NOk9yaWdpbmFsRG9jdW1lbnRJRD0ieG1wLmRpZDozMGE0YjVkZC1mNDIyLWJiNGMtOTE2Ny0xMThlYWQ1NTZiZmUiIHhtcE1NOkRvY3VtZW50SUQ9InhtcC5kaWQ6MkU4OUY3REFDQUZFMTFFOEJFNzlBOTQxRTA4QTdDOTAiIHhtcE1NOkluc3RhbmNlSUQ9InhtcC5paWQ6MkU4OUY3RDlDQUZFMTFFOEJFNzlBOTQxRTA4QTdDOTAiIHhtcDpDcmVhdG9yVG9vbD0iQWRvYmUgUGhvdG9zaG9wIENDIDIwMTggKFdpbmRvd3MpIj4gPHhtcE1NOkRlcml2ZWRGcm9tIHN0UmVmOmluc3RhbmNlSUQ9InhtcC5paWQ6NjQ3YWI4NTEtOWRjNS0xZDQ4LWI1NTQtZTNlNGEyYTQzM2VjIiBzdFJlZjpkb2N1bWVudElEPSJ4bXAuZGlkOjMwYTRiNWRkLWY0MjItYmI0Yy05MTY3LTExOGVhZDU1NmJmZSIvPiA8L3JkZjpEZXNjcmlwdGlvbj4gPC9yZGY6UkRGPiA8L3g6eG1wbWV0YT4gPD94cGFja2V0IGVuZD0iciI/PvprSd8AAAvASURBVHja7FhpkFTVFX57v957uqd7dobZZ3AGkEGCgyKyKqKFioaolQQ0GCSJBisFamIVUUslGkVMWUHRQNyBMUZAFoVBCAgDIsMMs9I9PUtvM70vr/ttN+d1A6FMpSJm/qTsV/3j9X33nnu+c8/ynYsjhLDvzUNg36cnizaLNos2izaLNos2izaLdmwf6j99OOhJ9Ed5eGmyaWqMDLzYo8IhTxzDcRrH7ijVa6gLlnLG+APuBIxTOLakVH98hHPEBAy/KAhhRppYWKz7dCgWEmRlRJYyXyaa1Y1WTSQlNTtCDEksqTAxBB5Oirv6g8GUyBJ4qYGdW2r6uHckkBQwhG6psNq0iiZfDgY6R2MwMrXQ1JBvhBFflNvV7TKomdvrigkCvzK0UUFeemjYF0qBxAXlxj3zx8HgYW9i+YFBDECKSJhVtKwmJzP5sVO+9zqDGEViBJp9d9WL7f6dfaEMTlgOk/UmpndJ5cPHXIMhHhMETBDTOxMkQ752Q+m8Qu2yvXaKpQFtt59b/PfOrpEYJspYkr9+Qn6hhl684wzGwyrhyXm162ZWw9LXT/W/ebQPDFpdZDz14Bydiur0hJZvOZSXZ7i1ppAhyCtDu90e9kV5nZ4WZPS5J34mkJxkZsHwGENiJIER8sae4H1VJprAz0f4jwZjGEthBK6GLzimhSMmiAWl2ilmVpIBL7KxFBydliYxCl9Way3R0XFBbnaGHH7u1bO+6bmlDEsZaUyS0erD/QDVbFTdV2nRUcTUQsNrbS5MlIxGNsKRf213rZlermEoNVhWRYO0Hk/4+SNdT82ppwgCUzMGGLxST5YQ9lpvCJPRb68yH/cnP+oNv9UXfnkaqxwWwmwsKcrEaV9y/3BsYYl+U1cgyUngg35BTojyhSOV5flFugdqzGK6vwIzgbUlScIkce3kvOocVWbwWV9CRhdcAKKj259ocUdImtgyt2JRRS7MifPiij0dGIm/Orv62WP2c8PBv3V77mkoTu8i5+u1Pgy9dKR7+ZQyNUN+xyx1zBtv9XIGLf1Alen+SiOY8H17OCHIcJJg/wlGZuk4HXjapu4ghNwWexgjsVVVBgMB9lHMoTw08ejJEeM7XRb4bT03/1MHrCXSKt6133HdRz3XbO9+ud3Hqqg1U/INLCEhRBG4K5pKJAWLlplVbMposrnNPRpITMzT3ddQtLjKBof8+tcDMI5DYKaEpfVFt1XlxSOJx/a1ITAb/p2y1J+6gqCWjJF3HBxKwEEzpDcufOyMGFTKZBGhX9SZX+8Nf+blfn7U5Y0JjTbNkjLTM+0BRQs8HasyGm+g8lgSdECSXGdgAE9GmbaR+AWL4JhBRdYaVZk1mRGQIF20mCzLW9tdsLsvwc/cenSU4zGt6gtn4JwvooGgQEhNU8/Nq9/dNbStfbCIpUiGumK0A1H+k8EoxF8sIXwRTSkASIhD/I3e0IOQlhDGiaguh11cott2PvyeIwLAYNzMklLagdOa4pggr5uc++Nq8yWxnCArnozwDxeU1eWoBVl+stW9s8f//GnPC9MLcQwJoggZGPAHYqk32r0/q8/b5/Cf8kRgrScQ94xE4QAgscky2vSVU0MqBorxYo3V8OC0yo0tHa+cOi9LMnGlaDf3BOMxfmKB7vlGG4gE5w2kpPuPult8iQodA/+l9F3HIxPM2xyKKkUG5kflxnhKlJCshC2OKaFIEuvOBt6yRyRRBOcv1TEbmjLBhmpz2HoLpADsoausO7tGQ0kxBdlJFJMEWWPW/KTKsvHE0OoDvRtPOT0JHlz3zgn5KycXQfxD7jvtCf9m37kdXe7GXC1oIis7Yb+7ccKO9gFXKK7448Xa9q3QRnhphz2sJolf1ebcVKK/NL57KPZ2X3jbQJQkcTpdzZrytYtKdHsd4VW1Vh1NhJNIi+M4idLpB9Mw+FA4afeLOISyjNxGlSgjSKQMSQoyupQwSBImKx4OSCBuBYTW31AOYt7pcDlCUMAxDUs93lQOoZ1ZMqfc+m7H8Bl3MMilSJrM1Hurln12waTlHx5T0gX1X3IVfvm9VEpC7rgAzlukY6jLgj4uyl5OBLuBMBVJFGkUG0V5aTQpFetowA9g3AkgAFiBjg4mJU686FS4EsUkgdvUFEjgZQT1U6X4IUSEDHupacKiovqjKRgrg3yV3tQX52MC7IZIggD3vlzdAMcHOQEsRCDMoKZz1Uxm3B6MK4mdJIoNGhz/dmizPDmLNov2/7sH+jZPMCnGeAm/PC0oSQAVG1SXTxuO8VAtcOXbhZkonVHydUqO8XNCQpAUZgF8CwqYjLQMZUozGW8sJUjoAvtACudW0aRVp+StQCKVSAkKHVAIHLLo1UA2YJY7FE/XIWUNTVE2SFpjlaVWHnS+3R0QKTxDkDM4GITdU2PeNKs0Y4T1J11PtbqTCLFADWSZl+S0RyktxJwS49s316z6vA/IkECSab6FKITMJPZEU8XKaWXXvnmk3RvhAajCTBCW4ueWWXYtv3HtvjNbW/sCKVEhjLII3dLeh24pMrDL3z/0tSvAS6KClkvMKC9seXTJmJ1tXAJCI+WqVVaWyhBVqK89Ie6NNq+BIV+cUbzprG/NPwbhw6wiQ4srBJ1ApVGdLuwisOLms+4PxueAvjFOtJpoi8Ls0UCMG47yvz7QuaDCygtijEsVm1g9TSlG4qmKHO3eHvcf9rVBJay26CkciClC0AxTxNpdrUc7B40WQ7lJA2xETlD5eg2c5eWu9z+hVQqnKP92Ut7Dk22XBl86413d4vzjaU9/JLXTGYK+9JnrSpvy9S32kWmlOYfvboA5gogmbW3tjMV7/DHgFcCZnp5RvmJKCXza0+u9+YPWlCD74ikq7dnvLW68rvxf8tcfOoeJ4jibYf/y2Xl6jSpNMnhBOuv2A8FaMa163YIpJEkyNDnGcZtpd17p8DU7ggpnE+Qai2bznFLQ9YkvB5q7fXBWK68ueHx6yR57EFRxRJJPHraDu/ZG+P5wHL4W6lU+fwLM9nGvzx/jeEE46ALujc0oNtXm6kUg3gT20J42E40rHIwXl0wsuabQBHxlIBC9euNum5a10uRt9eMenVVfZzOfHxh54UjHtq+6jQxVYTasnj91RkXBGKJVkkF/OOkE6ghvopxI30vML9b9HkMcLoP02eNMaTsgQDsc4Z46eF65qUESRpFWvWpRpfWEpxe0393t3n3GmTYfBUxyVeM4k4YRlfDAz/nC6SVITvI1NsMjMyc8t6hx8/Ge0ZTY5Q10CdLhc/1qCt9wx7Uin2pz+UdiXH88ccY+3OJwdzxxb75RO0ZoQYkk//T1pSsnFSAlaSokudOfuP2TLo4XWZZMpqSf7u0u1zeYWArc16ZXLW4ogHRDyVKJnr6zNm+8SZ0EA6X4HzYUzB2fCx3C9h5PS69v/bHzt9YUEJCLRXHnvU3TS3OVPhKDLk+5nVgzuwF+iZQ4GkvcueXAyZ6h/XbPqpn1n666VeBFThCb2+zLtuwNxLnhQHTM0CIl16OTvuiH3biUTlNQL1456xsIJBoK9FsWVK8+3N/SO3LXzs4V9QVgmkoj++d5Vd8Uohy9cMN4ywPXlMHrLTX5la9+5gxFI1yKQIoXfObwOqNJRb4slZl14OEbDp2FkKZIPCXK/SHlOq6xyPLu8a4TfUMM1CgcP+0JgHJqRlWYoxszTxahnMhSc/dIc4f3MsKCF5rZHYtqq8ya7Qtr5m/nv3L61/ojcLbJZOrfhQjQbvAS9IyZv2pa6aQ4XkEnQm8gSC8e6ICdFKvwwvX1xc/ddPWGzzugdF5wLhK7tq74lzMmLP3Lvr2HIVenERGESs08vfAHBSbdmHUFra7IQIj7xo0m0IOGfH21WZP5C5Xm2GAowxBy1NTsMss3hBxx+h2j0aklljqbPt33izu73DiG31ydf8LpAxahyE/ffMjKXRRbm59zrM+doSpQb/Us1VRVxFBkq8PjDkYJgsikk/K8nLoCc7YHyqLNos2izaLNos2izaLNoh2z558CDABnWfBAOrLdkgAAAABJRU5ErkJggg=='
where nu_bandeira_cartao = 6;

--Dinners
update acgsm001.acgtb069_bandeira_cartao
set im_bandeira_cartao = 'iVBORw0KGgoAAAANSUhEUgAAAE8AAAAtCAIAAABgaqGAAAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJbWFnZVJlYWR5ccllPAAAA3ZpVFh0WE1MOmNvbS5hZG9iZS54bXAAAAAAADw/eHBhY2tldCBiZWdpbj0i77u/IiBpZD0iVzVNME1wQ2VoaUh6cmVTek5UY3prYzlkIj8+IDx4OnhtcG1ldGEgeG1sbnM6eD0iYWRvYmU6bnM6bWV0YS8iIHg6eG1wdGs9IkFkb2JlIFhNUCBDb3JlIDUuNi1jMTQyIDc5LjE2MDkyNCwgMjAxNy8wNy8xMy0wMTowNjozOSAgICAgICAgIj4gPHJkZjpSREYgeG1sbnM6cmRmPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5LzAyLzIyLXJkZi1zeW50YXgtbnMjIj4gPHJkZjpEZXNjcmlwdGlvbiByZGY6YWJvdXQ9IiIgeG1sbnM6eG1wTU09Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC9tbS8iIHhtbG5zOnN0UmVmPSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvc1R5cGUvUmVzb3VyY2VSZWYjIiB4bWxuczp4bXA9Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC8iIHhtcE1NOk9yaWdpbmFsRG9jdW1lbnRJRD0ieG1wLmRpZDozMGE0YjVkZC1mNDIyLWJiNGMtOTE2Ny0xMThlYWQ1NTZiZmUiIHhtcE1NOkRvY3VtZW50SUQ9InhtcC5kaWQ6NDE3OUY0NDBDQUZFMTFFODhFODFEMDhEMENFMzYwMDMiIHhtcE1NOkluc3RhbmNlSUQ9InhtcC5paWQ6NDE3OUY0M0ZDQUZFMTFFODhFODFEMDhEMENFMzYwMDMiIHhtcDpDcmVhdG9yVG9vbD0iQWRvYmUgUGhvdG9zaG9wIENDIDIwMTggKFdpbmRvd3MpIj4gPHhtcE1NOkRlcml2ZWRGcm9tIHN0UmVmOmluc3RhbmNlSUQ9InhtcC5paWQ6NjQ3YWI4NTEtOWRjNS0xZDQ4LWI1NTQtZTNlNGEyYTQzM2VjIiBzdFJlZjpkb2N1bWVudElEPSJ4bXAuZGlkOjMwYTRiNWRkLWY0MjItYmI0Yy05MTY3LTExOGVhZDU1NmJmZSIvPiA8L3JkZjpEZXNjcmlwdGlvbj4gPC9yZGY6UkRGPiA8L3g6eG1wbWV0YT4gPD94cGFja2V0IGVuZD0iciI/PtWtu1QAAAg9SURBVHja7FoJbBTnFd5/zp3Z0+tjMRgfYHzImCQ1V4koTluXNkSUJmmVWlFJkyZRlaoEVYmaFFVUEVHUFLVRmig9UqoeKE1pUrWlBEpELNOYYGNkjLGNje/1wV6z58zsXH0zaxPk0rDjsIYqO/Ku7D3+ed98733ve/8YaZpm+cQcmOWTdOTQ5tDm0ObQ5tDeOgdxQ1aBni0rSjgqDI6HIjFBlGRJVnhBmvTHx6aikYSIYYggMcyCrr+UxUKRWKGbrSkvWF9fAr84WArHbwwr6GO6C/h6SlKmAvGWjmGnjVi9sqDQxRAEpiNDFlHUZkLJd9tH/vJuf99YKM5LgARD18GsGusqigYfra0oePzehu2N1XaGgj9vJlogsH8k2Nnra6gtKltiZ2kS+JSUDxeE6EgSZxkyyUsXR8Mv/qH9+OkRqB4qY67gFKmU4vWwP35y65a1ZU4bfXPQQsae7Z8OcbEdjZUy5K0oq9q1MxXOgGOIZaBqsF+/fe6nB9uBZSuFWywZcQWpAOnDRYU93/rMo/c1eD22xUbrDyeOtA6sqy2oLvfEk0CnhubI1ObHOnsKHTOBnA7m5JmJ7+4/PuIL2xjKYiI3UTCSfPjLd/xkd5OVIhYPLahR65nhuoq8lWXuEMcDHoiZwDH4kWRVVlV0leTQJG6Qo85h1vLcTEfPzOP7jo5Mc6yVNBMsCoQTT++88/sP3cmY+uKCO5AoKUffHyhfal9R4gyFeczAytA4YOkfCfv8cQKfBQuaAm919s1M+RNWmgB9SlPNcfzaWu/rP/ySg6V5UUIIZS6JhXnsCwdOdvROLVK/HZ3k7FZ8TbU3HBUNkUQ2muRiqf2/b7//6b+2dI45DCEBHnEMszHkc79qe2jvkZaOCdBYyOQ0RZG4sLoy/7EdtycFqHZzyQXr733tPajkrKMVU3Jb1+g9mys4LpnuB3aWnPQnntx/4kevtvhCsasTTNPpRQ472do52rznbz872IkjPdvTNSyK8rfvv61pXVmQ4zEsc3YtNit56rzvcOtA1tGe7plctdwpK3oN6jVJ4YEwv/eX/37jyPm8Inu+m5knUvAxAOwtckiauu9A299bhqi5RAdlc7DkrgfW2mgqJaumOjwAfv43rQugFzNFbFf/5Kfrl8YTKag1EtcL841jvb893L2k2EESmKJcOycVRXXZKRtLPPPKe70jAaP36FGDBKytK/7CxnLoLljG1Zu+ygPjod7hQBbRDo6H11QWACTNOCXAgyR8p22YIJCVJFRV+4iAVUWzs9S4P/aLt85Z5nRJVfVFPlXjlXRuzVUvwizHPxjKItoLQ5erS92gKxCsIU+WnuEgSK7HxSjq9WOFywGK+o/WS5cmIgDScIg6yFWleXYrJSuqqbjBjfVcupzNTBZTYNwManVvBCSfvej3cwkjMzNiBmo2HOcvDAdII5k1HSAqXeLIdzGipJoywWDEAxE+m2glGZIWzZ0M0m9iJmq0W5RhGqYtZDQuoA89FEgO4bSROrfIjLFCCDxcFtGi+Z7QbK1dsb3XeHEhC5k/vQm0JElcUV1VVWGqKy6wa2lzgDIFqqiqjaWvZpsXlRgv4dCYzNgM+CxrJbKIlqbIBC+lcYEsAdo1VYVuJwMTWYZw4WI5WbqqLN/4yizLYDaDEQHstCmm4Kp5XGwW0S7zusamY+B4ISx9uMMsMLvfUVUUigp4BnM2mKhQlG9sKK0uyzNajl788HxxnIslRQLHTcUtK0pNeX4W0dZXFrX3ztA0YTHmO5izvXnWpnXlKUGWFAXTJ7uPaI9ISKkOinzsK7dhesHNpj8UQvfgZRxHyGTJQj/77PoVWURrt1Ful61vOMQAvRqgVYGcB7fV3fe5Gp8vCp0Jx68dM4YjcHn+YPLZhzdtqC8WRDkdMkxFvUOhoyeH3A7a1GwgSWpxgWPNKm8W0QJ7Wzeu/KB7yspS6eAEUSkpsj//xOZ7GquC0zEuLvz31hG0ilCED0fEndvqdm6vS1sxo/fq1+uVQ2eDMZ6mcDNhWBK8+NQ3Ni1gpjc3FTjt9KryotNdvvw8VtURa9FkasVy16vPfP5739xkI6loPHWlxSDjMRNMLMt3/fypphd2baFJAvI//ZaVpn53uPfQiT6Pm9Ey9lGwNi/KtRVFD2xdjcy3LdN7F2DlXz54qvmLNYUuayyZgoIEzsFO8Snl/KAfBlpwgvKsCOmFeaJ9rKTIWbsiH1RNFBXDQmkuh/WSL7J996HpcNLBUpnHAEv6gokjLzU3bTRdtAvcqYklxANvnWm+u9bjssL4goz5BawvKHNKUudVoPE6BjKW7tX6To2TGRjnHnnunz1DAVM7NXCaAMfvbt747COb4bIu3i7cdCD+5jvnvtZUXeRhwQmmszf9mLceMKwaM4Omv4ncLqa7//J3XjzWNegHVk3pMBcVd2ypfm3PNn37bpF3WEF7/nysp7rU2bihnE+IorGP/L92WEGrwPpQNPHm0b59r78/GYxBJ0MZ77CCnkUS4hNfXbfr6xtKvM6bs3vOxYS2ronpQOyuhqVLC204jiV5ad70B3OPjaEVVRn2RV/6Y8fbLRdli0Zm2GGRBSRAFGW3g/nBo5vvvasGquCm3StIW8gEnzp1bmJwzF9V6q6tKPA4rbiRvTonigbp19Y98ad/9bVfmI7EBAKAXs94IZS+saQrACjcg3fX79x+O0yFxMe+G4RuyH+ZADZelIYmOJiwBVGysxQYTEGQRicjQz7OzyVVi0YQOk6UQeJCY6MJvHK5Z/3qZevrltlYEsdujbte/19H7m51Dm0ObQ5tDu2tc/xHgAEA524CqhJA9EkAAAAASUVORK5CYII='
where nu_bandeira_cartao = 5;

--Elo
update acgsm001.acgtb069_bandeira_cartao
set im_bandeira_cartao = 'iVBORw0KGgoAAAANSUhEUgAAAE8AAAAtCAIAAABgaqGAAAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJbWFnZVJlYWR5ccllPAAAA3ZpVFh0WE1MOmNvbS5hZG9iZS54bXAAAAAAADw/eHBhY2tldCBiZWdpbj0i77u/IiBpZD0iVzVNME1wQ2VoaUh6cmVTek5UY3prYzlkIj8+IDx4OnhtcG1ldGEgeG1sbnM6eD0iYWRvYmU6bnM6bWV0YS8iIHg6eG1wdGs9IkFkb2JlIFhNUCBDb3JlIDUuNi1jMTQyIDc5LjE2MDkyNCwgMjAxNy8wNy8xMy0wMTowNjozOSAgICAgICAgIj4gPHJkZjpSREYgeG1sbnM6cmRmPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5LzAyLzIyLXJkZi1zeW50YXgtbnMjIj4gPHJkZjpEZXNjcmlwdGlvbiByZGY6YWJvdXQ9IiIgeG1sbnM6eG1wTU09Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC9tbS8iIHhtbG5zOnN0UmVmPSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvc1R5cGUvUmVzb3VyY2VSZWYjIiB4bWxuczp4bXA9Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC8iIHhtcE1NOk9yaWdpbmFsRG9jdW1lbnRJRD0ieG1wLmRpZDozMGE0YjVkZC1mNDIyLWJiNGMtOTE2Ny0xMThlYWQ1NTZiZmUiIHhtcE1NOkRvY3VtZW50SUQ9InhtcC5kaWQ6M0E3NDBCNzZDQUZFMTFFODg2QTE4N0JFNkU0M0FGRDkiIHhtcE1NOkluc3RhbmNlSUQ9InhtcC5paWQ6M0E3NDBCNzVDQUZFMTFFODg2QTE4N0JFNkU0M0FGRDkiIHhtcDpDcmVhdG9yVG9vbD0iQWRvYmUgUGhvdG9zaG9wIENDIDIwMTggKFdpbmRvd3MpIj4gPHhtcE1NOkRlcml2ZWRGcm9tIHN0UmVmOmluc3RhbmNlSUQ9InhtcC5paWQ6NjQ3YWI4NTEtOWRjNS0xZDQ4LWI1NTQtZTNlNGEyYTQzM2VjIiBzdFJlZjpkb2N1bWVudElEPSJ4bXAuZGlkOjMwYTRiNWRkLWY0MjItYmI0Yy05MTY3LTExOGVhZDU1NmJmZSIvPiA8L3JkZjpEZXNjcmlwdGlvbj4gPC9yZGY6UkRGPiA8L3g6eG1wbWV0YT4gPD94cGFja2V0IGVuZD0iciI/PpqnTwsAAA04SURBVHja7FkJdFNlFv5f3ntpkmZrk5TuaRtKoSyFQimLQKFsLS0qOg4oUgGpjAICAsJ4kEURZRtQdgFZRESGfRW0w1qgVKAFCnRDJd3snibNnjdfEuhhOFAtg+eMY9/pSV/e++/7/++/3/3uvS8Ux3HkT3PwyJ/paEbbjLYZbTPaZrTNaJvR/v4H89uH2u32+vr6vNzcK1evXsvKLisrYxnGYrX6+/tHR3fqGhsbEBAgFIl4vP/dHaR+Y+VYU1OTfu7cxs/XX7mSpdNZYeTgnPhZlsE557BJpcLY2E4po8f07tNHIpH8UdHabLbsrKzFn3xy8uRJjBeJBD5KR6C/XaGw82hit5GKSvqultEWk1qdVSqhBg+Onzz1nQ5RURRFPcGCHA6HVqvV19U5zSlKLpf7+fk9NbhcowegfrNzZ1S79iqFIiQoKCQoJEIT/N0BkVlHcWbC2Qg+jZVUdqbHuk9lzyYEqBRqAd87MiI84+JFrukHyHLu3LmhSUmdoqJioqPxN/Llly//8AO2gHsaR2NoMcf+ffuCAwP9pOJwlZcmOCgkOCTIP2T3donTsM71pyecibieQ0q1zKeL5BFhaj6tDFMHXbl8mWviKnNzc6PatfOSSlXe3t4yWQuFwkehiOvVq6S4+KmgpefOnfs4txcVFb02alR9WRHbuoshPIZfWkjBlzbabKSGDdW74gDcIMRMiIkQKxErHLHPmFqqwXxZbqHhfPqJxMQkmVz+yIeDq9qiojuFhXV6PYRNKBTi4vn09G1btyoUivHjxw8fMSIgMPDWzZvgV1hYWGTbtm5Do9FYWlpaWFhYWVmJrzD87SHzWE02GAxT3p5cdidfFhJe8tw0c6vuZNtM6cW9DC29nsNq7zCBrW2OGoon4ojYBdhIiI4QPhn8nAG7MHmqKjv7zofz561as5bl8x988q1bt/bt2VOQn19aVlZbUyMSi318fCIiIgYnJLjJzDDMS8OHtwwPB/jt27bhotzLC4bl5eV79+y5euVKSUlJVVUVhvmoVGEaTZ+4OEijQCB4QrSYIC0t7eTxY3KloiJ+rLFtb6hHxbCZjKFWcOOcTi/4+xylSOwoKWZkMltUR8tfn9cHtrQRAyEWp8MHDzVMzGPnLFDt2rXvtTFjuvfo6d5+i8WyYcOGbZs3gzV1dXWYhc/nw3VAKBaLjxw6JHAdiCCr1YrxVosFt5DVpFLphfPn58+deyMnx2IyGU0mlmUxDLZCgeDrHTsGDhw4feZMUOBJNNlsNicnJt7ISKc6DywevYQTyYlJTwSevKriwNWpbGWxycE67ASZ1eH0BhXkZ585o/qFv+gpONlBiJRUlPBSU30PHLO89GK/L7Zu9fDwwMrmzZmzft06AJDLZN169Ijp2tXP17equjrr6tWzZ84ggXt6emJqmUy2e8+eyHbt/pWWNnLECMRChw4dbt68iQHYtdDQ0CHJyRqNxmQ03szJOX36dF5eHq6r1eqvdu5s1apVk30L+9vXsz3kisqoAZzcl9RVOl1GUeKcM4yunKNpPs0RFheIa6+40nJ66rtKmnDPDzcQRLSeKAMcSUP0Fy7JTp1KB/GCgoKAc+Vnn4F+vXv3nvXee9GdO9M03ZB1CgsKli5dCqLabbYHV4IxJpMpPT0d5yKRqLqqCnuBqFYolW4OgtKrV67ctHEj1pwycuTR48flj1GKx1aOKCSsZpPdy8/YsguxWVE9EKGI1d7yPrqKspqB0pULXdxwnXh4QH3JgiVepT/ScCxxRVD3niZ1EKmtNeXn5d25gxieD6gJiYnrN26EV90wsFYIBFQKUfqP5ctTU1PhMSfg+8Ljph6UKbpLlwUffYQ9AvKcnBxUOzqdDuuApM2eM2f+Bx8olcqsrKxPV6yw/ed+/bpvL2dm0jyeTRloVQQQq8k5N82XZhyk66o4D+EjTQBYW8x8tUsycnRdRRFdVsJcyfaw2SmBgD5y+HBFRQUoGhkZOXf+fKXLLZcyMnZ98w2kFb4aOGhQYmKiRCqdOm3a9evXnZ68H1/AA0OYTJkyBWoUEho6buzYue+/7+vnh5iP799/6LPPIqpfTUmB+K1bu/bztWtHjxkDKjUBLSSeong2mYoAm6me0Czi1uPuDdJoDSwUkK93iS9cEOTms2W/0CYLTypxyOUC8NNmtYqEQqzMLSQnTpyY9NZbt/LycC5gGARkTEwM0IKE4954I/f2bbi9geTwVVzfvoCKry18fVUqVUZGBqiB63t2775+7drcefMEQuGbEyacPnXq8uXL3x49+npqahPQ2qwWiqYdrNBFdY5QPMpipE0GV4Z9bHJjaK5Ay1y6zRcLOKnQ4S22E+6ek+AiT4nEveKyX36BcwC1TUQEYhhe7RwTg44Ct2pra38sLGzIJbCCpOFr9+7dnRJttS5buvRadjYAg/y4CzIjP6Mh6duvH3Re5OkJOTxz5kzT0DIsH1JLW+pdCgstcnCsh13g6SomuMcBtjmIRsL18XbkWbhyO6mxEQntnAArswOtSOTvgnQ9Oxv2M6ZNe27YsI4dO7rrip9/+unokSMnjh+/cPEiRgqEwgbfAoC7VAbjAJVzPdBdGyFvYTuQmZYvW4ZNRMBD1d1VRxPQ+vr6onDk6SqIxUhohtjMxNPLHNRWmH+pESYbOTJMyntNzrtr4UptJNvM/VPHVdg5nt0pG9x9yQHCTVu2tNRoeC5N/iEz8+CBA2nff19QUGA2mQBPIhZTD1XyDaLq8ulD87qztMVsvkekx/c5j45DCKDd4WArtWxFEWEFTnu7Rdc12S7xpmzWR5pYOBLAkBckPCSidh5UspRKElMsxVkdHFQErDPo9Xd//hkjkTyQFZGoDx88OCYlBcXpmtWrIU5QbNRMqCUapBj/gA4q5TaEh7FTnKvTdvMcWo3Pd2fN2rlr17Hjx9u0bavX630f3zM9Gm2Pnj1ZDwFdVSLMzwStEbfEWG8NbF2V8BYo7V6LewPdJ2bOSe6pClrNEp3d+RVXzxmJ1mQXsszCjz+GqCLGUC3AdWDa2jVrBsTHj05J2bd3L+IN4tSxUydgcPPTmeDcckhRqLNgeOHCBScPGWbipEnt27dHHQYZw6fDbn911CiIn5e3t9Vmqygvx0P69OnTNCaHh4dHtOuAWkqSdaIuetC9Worj9G17yU9uQy1loRlsLw8iRBGc+NNOqMOkVL3DaS7mkbtW7oiBqzAYRsT1jh8wADi3bt2KVARvHDlypLS4+O2pU+Pi4nJu3FC1aPHKK6+gEkIkf3fiBM0w7oIRz+nSpcvyFSu+2r79ZFraoYMHk5KTwXZEL9I1hIrPsolDhiD44X9sypbNm3EXvROma1p/Cw8cOHBAKfbU+PvI/raY7K0muyt5X+T6x78Y5ucbqlYPbx3yemTokHD18Aj1wqjQnJ5h5n6a6jhNZZxG31djj9cs7hSmDAiSy+TpZ8/iaSjx0B77+fgovbzEQuF7s2ZBUR6aFAqEthYDlHI5Cq+GnvbcmTNigSBh4MCdO3b0iI2VSyToeB80hJ9XrVwZ6Ocn5PMXLVzYwJEm9LcIgBeHvaDg02GtWgs/3M/bVe6TPLalyisoOLh9qDrnmTCuvxNbfV8NF+/8rHRBrXN93RcbFh4awgiE40aPRtS5t2/zpk1oXFso0fqqcY56o2EuJJ7MzMw3x48P8vfHAPy1adVqzapV+fn5uDVp4kSZWBzg64teFycJgwaBsW7D+vp6FBWzZ89GFgbUpIQEjG+kv23sTY1Wqx3Uv3/N3TtMZKxJFSLOTiM8ykjRvYTUFn/a5qIxrN2qRbsIzKPIQT2ZXeG4XV4dGRy4/9ChYLW64SXesiVLlixeDOTgW5eYmKiOHZUKBdaHFZ86dQq9LvjZr1+//IKC7KwsCEGn6GiQFqWIEx5KU8q5WrR4AwYMwKZjH1GTop1AIckyDLRm5Zo1jbdBjaHFLeSGiRMmWHU1Yg/WIRTbKRr0+tiHHiGndPZ7/TyLHODSFK2V7NBxG2odP1XrAiSeu/fvh4SSBxIGyoPDhw4tXrQIDY1ep0O8oR4AD00Wi0wiQYGBynFIUhJ2Gc7HSLQTUCY0dyEhIdOmT8eOIHrd+oScjFg1GI0ClvVp0WJcaiqKx+Dg4P/qLRwcgupswQcfFpcUYwK0JFDkpT50LxHlQTk9aeeI3kF+tHLnjeRbA5dhsBn0dSE+qs1ffgm3PHIH0aygI0c8o1VAg46GDu1bVFQUKqoO7dsDnLtxvw2Hnzx57NgxEGH6jBndunXT1dWhhD5/9mxubm5xSYkHn49dAEfaREainEJd8bTfOVIUumcVw/NjiIJGPUnA52oHB68Wm206s0XC0IP7x09+51feOWJS9G51ej06HpbPl0okyLRw48Nvc/T64qIiVA4BgYEN7SESUm1NTb3RiL4FtRRyD4qt3+d98vr1V65m6SwWt5XrrQrrflko8RTGdo7+w79PfvRvBdn3fyuwWP0D/KM7/X/9VtD8q1cz2ma0zWib0TajbUb75Me/BRgAumeK5A2ttJIAAAAASUVORK5CYII='
where nu_bandeira_cartao = 8;

--Hipercard
update acgsm001.acgtb069_bandeira_cartao
set im_bandeira_cartao = 'iVBORw0KGgoAAAANSUhEUgAAAE8AAAAtCAIAAABgaqGAAAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJbWFnZVJlYWR5ccllPAAAA3ZpVFh0WE1MOmNvbS5hZG9iZS54bXAAAAAAADw/eHBhY2tldCBiZWdpbj0i77u/IiBpZD0iVzVNME1wQ2VoaUh6cmVTek5UY3prYzlkIj8+IDx4OnhtcG1ldGEgeG1sbnM6eD0iYWRvYmU6bnM6bWV0YS8iIHg6eG1wdGs9IkFkb2JlIFhNUCBDb3JlIDUuNi1jMTQyIDc5LjE2MDkyNCwgMjAxNy8wNy8xMy0wMTowNjozOSAgICAgICAgIj4gPHJkZjpSREYgeG1sbnM6cmRmPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5LzAyLzIyLXJkZi1zeW50YXgtbnMjIj4gPHJkZjpEZXNjcmlwdGlvbiByZGY6YWJvdXQ9IiIgeG1sbnM6eG1wTU09Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC9tbS8iIHhtbG5zOnN0UmVmPSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvc1R5cGUvUmVzb3VyY2VSZWYjIiB4bWxuczp4bXA9Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC8iIHhtcE1NOk9yaWdpbmFsRG9jdW1lbnRJRD0ieG1wLmRpZDozMGE0YjVkZC1mNDIyLWJiNGMtOTE2Ny0xMThlYWQ1NTZiZmUiIHhtcE1NOkRvY3VtZW50SUQ9InhtcC5kaWQ6MzQyNkUwQzdDQUZFMTFFOEI0RkVBNkMzQzQ2NkRGRUEiIHhtcE1NOkluc3RhbmNlSUQ9InhtcC5paWQ6MzQyNkUwQzZDQUZFMTFFOEI0RkVBNkMzQzQ2NkRGRUEiIHhtcDpDcmVhdG9yVG9vbD0iQWRvYmUgUGhvdG9zaG9wIENDIDIwMTggKFdpbmRvd3MpIj4gPHhtcE1NOkRlcml2ZWRGcm9tIHN0UmVmOmluc3RhbmNlSUQ9InhtcC5paWQ6NjQ3YWI4NTEtOWRjNS0xZDQ4LWI1NTQtZTNlNGEyYTQzM2VjIiBzdFJlZjpkb2N1bWVudElEPSJ4bXAuZGlkOjMwYTRiNWRkLWY0MjItYmI0Yy05MTY3LTExOGVhZDU1NmJmZSIvPiA8L3JkZjpEZXNjcmlwdGlvbj4gPC9yZGY6UkRGPiA8L3g6eG1wbWV0YT4gPD94cGFja2V0IGVuZD0iciI/Pg09w58AAAx+SURBVHja7Fp7cBT1Hd/fPm5375G75PKAkBBIwisEwkNCDOkAKkVFRTstllZ02toiWKq2pYKAUmvpYB3rSKutttNKR6AVGOuD4aUCFQQExAgEYh4khLzIJbnkbvdub3d//e7d7mbvLinHH53pjNnJhF9uf4/v5/v9fB+/74EwxsRX5iGJr9IzjHYY7TDaYbTDaP9/HjqVSaH6+p6du/pOnJJ8PkRghOAXgXRtYXOs/44mcGT8SdxQOkf6itgiOMncILapSiBzHB1o/6jIPAepA/MRVhXH+HGTXv/jDaC9tmt324svSV3d0SMwMg5BsT9xHM542LGxKdt/e0wRoyCtn8RjjuoZG4CxcQ5GFpDI1Bdyl8+6Adt2v/te0/qNWFWttjKhWu1mTrAMsMVglgFOtGRsiAeWDExECfyA05H+McaWrXGcRo3dCOfUKamiDbdcbXn+BYxVYx+MrHtiCzCME/BYTWqaBg1q0HiV4Ohu2gZIF5qIUQYZexvADEVg8x224NZkY2jHxAmpou1+593wta4E0xHxdhvEtolubF0Yx2rDjgMmxmjALBoOlGRb43RzV5REF1MdbE42N3p0qmj9J0/oiy2KS6AlSuKq7tuGxChJO2gwn8WE4Z1xdEc4fgm2sNRiZ90JotFTnwARxZU7xpadlVIGkru7pcvNON6qKJ6EFm4Z07BF0zpUPYIgPOSPoQ486A4Jp1hNOSAYAJVlJRiM0R72JDHJlY43+X8dtGJtndzTGxsroqj0B5BqHKKqSl8fDodhL1UQ1P5++CSmUtNdk/k8mDskvk1aiwnrQoyT2RFbi2WZzshIq6wk7Twknpib82VTUq0uhC9rVcADMSoU9i6+K/+pJ0mHAzaFH8rBj1r/lOeuRYDTvejOkc+sJ+12HJFNt7RENWxKb5A84cd4hY04PyThE3zHMpMklf7+nAe/O+Evr9HONByJwDuS5ezxIWpotBiLX5zX9lNURFEjVzzive9eVRThcxwK8ZNKclatZHKykc2W9/ymjGUPwICQJOASgVUcCoPZzdyrSaUoGNbCBNMaERnJivZ5KIRizqdGF8K0iKTrS3sbJkIiAuIYnIoegWF/Tbmam2I1LKnBIGKYtDlzxIYGqb0NBIbl9sIxbE5OSrWUIgjCpUtaapNlW24um5/fs2+f4vdTbjdgts+YBnMCn36Kw6Gra9cp3T3KtWtUerp2eF+fbXwxIcny5cvIxhAkqfYHaI+bmThB7elRrrQgjoMah/K4VUEEmaiiIqW9XYbIz/NMcSHiebnLp/T6sSAgl5MtLgJlhRsvg9IJEhEsS7EsBBS2cKwqRcJXW1RFZYsK4Vg5EOTGFPje36MEBcrlBDfmJ04kWTYltFJHR6ipSdNiJMKPK4b1vXsPyD09UQuI9qlTZJ9Pqmug09PF6nNyWzvMzP3tZiYnS/X7HbfMV0Ohrl9v7n3tdXB1x/x5mZuetRUXKT29XT95Qnj3fSovL2fHVuWaj8rKpPNGXZn9NduU0sxfbeSqKgG/VFfXtPAu1z2LstatZfLzQOO9b+1uXf2kGhBzwH3uXiTW1LjvuP3KUxtCb2wtePEF75JvglTBs9Ukz/WfOKmRgoRyFjtKSlK9FYg1F5WwpBFKVhylk+ETz9cXFGzelP/0+vxNzzkrKoQzZ8NNzd6HlhXvex80TaWlOapu5sqmSpeb2p5Yrfb1ZaxaAfTmZt004rVXAjt3X6mar/p87uUPE1IEbGgrLWVnzRT3Hej84Uo6P2/Uv3ZRWd72B7/fuux73S9tAboyowu6X/1Tw7zbAocOp919J+VOQ4zNWVlhG1MAbtr82E/9+/aPfWVL+p13NC5/tP7h5bYR2QiRwrkLmk+BE/GcfcL4VG8FwXPncczxGNo5YzqEK8fUycT0MkJVKIcTmBk4cRJU4Zw7Fxwv/GWdfXY5AG5bvaZ7yytgDee8uY7b5lNOV+a6NUooJB4/CWFMo67dTigyO6UUStGuh1cEd+7CHDfyvbcJmmp/6AehL84j3q7pn2V9m19A6R7SnQbeKzVeln09zKiRXOnk7h3/bH70MTkY9D7wnfTF91z+8ePX3twOyzPuWwyMC7e0kKwNwoAtM4sbOyY1tBgHL9TEwjqT6XXOnN578MOGlatokLjPn/XQMjCvcPZz8Gd+cknw6DHwOkfFbMh1gSMfkx43ybD0qFwgJJ07gp0xDSJNzqsvI4oGrQe2bQfWsXMq5br68MdHSbebnjyZm3NzYPfbkYu1dHY2XAAgFiCPO/u5Z/mqShyR2IkTu/+6FRzHteAW8MPet98BojJZmd6l90c6Ov0ffQSJh3K7nOXl/sNHlECQSndD2KNH5zHejJTQSp2d4Sst2sEhiSsroj2ewOkzEPdUkoJsZJ85A8KVeP4CXzKJSnMJZz6D4x0V5VJdvdzSgsMSXVjITS/z/eZ5euRIkuc71qwLHTpMadlLUX094LTstLLQsU8g2gF9mIJ8CKfS+QsADAgMsYfgmNxXf09lZ7c+sgp50gre2i5WV4Pe+fJZkOQhYiGaJNM9/KQJYm1tpOOaqih8yQTbiJwASKLnfMI1tTTV27wAcnd1aYlBkYHGsF6o/kKLb4igvV7HzJvES7WRtnbH7HKN85+eonOybIWFEM8QTQO8rLW/gIjq375DjaYcZvRoqbYOQhqAwcEAXVRIZmSET5+BVEWA+oICzOErK8gML6wF8HxFhb1qjv/v24RTx10LF2ApHDpbDcpylM8Kg2CdnbCKZBiI7WBVJjsbJMzfsB7UIZyvAQFiVaRralmqt/lgzUU1Imu3PBsksUoZLFlXB2MsAa8mcGNGdx44AA7srJoDOT107gI3fhxQC9Lv2P17gKhM3qjWFavk9k4iFBaOfZLxs8cdt87Xqq7+QPs3lrDls2Cr8OnPwNlA4tCZz8RDh+23L8w/dBBqIPHosd6tb4KdvaufcC9dQmV6kY1Nu/eeSJePK5nUs3M3UIx0OiFLBY5+AvG55MO9ICf4VKixMdzUBJcekJ9yOfhxRYOipTZu3JjgtB1vbhPr6qFOIG02CEK9+w+KFy+SNI1Aqxwbbmj079kDOR3Jct/+A8Kp0+7Fd7tuu+XK8kfB5SLNzR1rN4jHT0BmBo8VD36gQC4lSYDX/7etcnsHyXHhE6dCx09oeYKmAZjw0WHF160GReHIkb5/7JQuXYKwhINi77Ydvi1/AMqIZz6PtLVKra19e/bKUMCC3lU1cPKk3Ncntba1/u7l3g8+6Pv3x0JtvYYWIXvJpOyl3wYHGaQ1kvDNCJTENd9aGqirh1IBWA4GAWrQLke0vkFaURYMUjxH2lgM5bFW0+OCN/5sL5v65ewqKCRJeDiO5HitltKyJxQ6gl4VcqxWxAoC2JxMSwO0OHY3lyJQbOu3GTuPWBZqchVqJihOGAYiOcGxhPZhP+J4gue0KgCYEokoUc+H4KdCFQDSOl2x8i37/iUFv3w6JSaHrl4Vm5qNCg+TLle0HFdjZtc80+OBYgjG8Ap4C1ULk5np37MX5KO83ljvRq/lYT7DQESJVpHRCl+FTAgS81EVY73OhzkeDyai6sHag5wuKqotGGtqjWKgYE70MXamKZs7eu2PtckIfUtE2KdMTrULJ16oUZVIwj0rhty4ssZu0thsKTT9aCUWRIgxZutG7x1Em1Y6eYz7WvI1JvYWI3NnvRWC41kXA2b26HDsSj8wTX/F8Ly9qChVtP2fVxv3YUuHJ3lsXCu1GhUCOBCYpo1mDk7qNhlNCTx4nxET8W036zt0vb6l9a5EIps3gy9ODS1WFOFSrWk8FNdPiR8jYsCSLGt6P9I1rs+J9ZcwMVRjKrE1gBOarMgCHiHLOFEv2GhoccVFmoulgla+2hpubcUJFtWBGU3kgQs2TlABNtsI2DIrsRuV1HS0YMBW8BaoScBQPGy9Kwcnp82dm2r3PNLYEOrssjpefHMz3jbxKsEYx0HDce6AsBXiIH31+B4yst7WsaXhmEwQ6yb28ePTFy5IFW03JB64Q8cDszDZEqsIq5PqJsVmKNIpbfJ6cA7jwcZWqAafkeXbg7glVheweb35z2yAAitVtD1wP0QIJweF+FhlIkAEvl7cQBY50VDz8IB60dDNPpPtA98VmCtd08py1/zcNX36DXwPxI0YiaoqaXWAN9HCACOU2OZDOLFXZCyBzKzE4dEFJqOvhtIOVBrqYH1qKlbJWx3Yynz42zYi0zW73HUrXDCd1/+aafh/mQyjHUY7jHYY7TDaYbT/8+c/AgwA7CCPNxwy7l8AAAAASUVORK5CYII='
where nu_bandeira_cartao = 21;

--Mastercard
update acgsm001.acgtb069_bandeira_cartao
set im_bandeira_cartao = 'iVBORw0KGgoAAAANSUhEUgAAAE8AAAAtCAIAAABgaqGAAAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJbWFnZVJlYWR5ccllPAAAA3ZpVFh0WE1MOmNvbS5hZG9iZS54bXAAAAAAADw/eHBhY2tldCBiZWdpbj0i77u/IiBpZD0iVzVNME1wQ2VoaUh6cmVTek5UY3prYzlkIj8+IDx4OnhtcG1ldGEgeG1sbnM6eD0iYWRvYmU6bnM6bWV0YS8iIHg6eG1wdGs9IkFkb2JlIFhNUCBDb3JlIDUuNi1jMTQyIDc5LjE2MDkyNCwgMjAxNy8wNy8xMy0wMTowNjozOSAgICAgICAgIj4gPHJkZjpSREYgeG1sbnM6cmRmPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5LzAyLzIyLXJkZi1zeW50YXgtbnMjIj4gPHJkZjpEZXNjcmlwdGlvbiByZGY6YWJvdXQ9IiIgeG1sbnM6eG1wTU09Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC9tbS8iIHhtbG5zOnN0UmVmPSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvc1R5cGUvUmVzb3VyY2VSZWYjIiB4bWxuczp4bXA9Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC8iIHhtcE1NOk9yaWdpbmFsRG9jdW1lbnRJRD0ieG1wLmRpZDozMGE0YjVkZC1mNDIyLWJiNGMtOTE2Ny0xMThlYWQ1NTZiZmUiIHhtcE1NOkRvY3VtZW50SUQ9InhtcC5kaWQ6NTBDQzk2QThDQUZFMTFFODlEMkZDMEQ3RUY5QTVFMDUiIHhtcE1NOkluc3RhbmNlSUQ9InhtcC5paWQ6NTBDQzk2QTdDQUZFMTFFODlEMkZDMEQ3RUY5QTVFMDUiIHhtcDpDcmVhdG9yVG9vbD0iQWRvYmUgUGhvdG9zaG9wIENDIDIwMTggKFdpbmRvd3MpIj4gPHhtcE1NOkRlcml2ZWRGcm9tIHN0UmVmOmluc3RhbmNlSUQ9InhtcC5paWQ6NjQ3YWI4NTEtOWRjNS0xZDQ4LWI1NTQtZTNlNGEyYTQzM2VjIiBzdFJlZjpkb2N1bWVudElEPSJ4bXAuZGlkOjMwYTRiNWRkLWY0MjItYmI0Yy05MTY3LTExOGVhZDU1NmJmZSIvPiA8L3JkZjpEZXNjcmlwdGlvbj4gPC9yZGY6UkRGPiA8L3g6eG1wbWV0YT4gPD94cGFja2V0IGVuZD0iciI/Pqc1FOwAAAuxSURBVHja7FoLbFXlHf9e57alvReVjldbopm02jofoFDQRep8oIAmU5DMJZsCcTGZ4mtLZnwum9lCQbNlA4TNkDGnLnOSbOqciouYjVrnZoul9UlfIgj09n3P+b7/fv/v3FvItpJesm7J7Gm5Pfc73znf93/9/r///yCJSHxmDiU+S8eEtBPSTkg7Ie3/k7Q+XTkSTvDvyOjRv1bw9ewJH+7YWTQyN3dGZHHCD43v8OMue80e83CXPaVjF3X5SivzyreYKrMrWSu15o2SJAml2faOzPN/kp0dtqk1kk75icGC+apiWuKKOpFK5bZrpdTkHyRJRJIM/h5sEIca7JEPpE1r3KqsNSmdrBRT5ojPnSuEwX2RIEPSSVLx8kLo/K2Vn7RsVyWzS0NO3C1U+OSO/p8/7po+9OK4eH1cw9bwo/gfFSy+uGD118z8ORgeeZaI+um9X9n3tomwX/KBu0RELhBakgtZm5aClKpYqk67XhRXxM7l52Hj8IBYpeMn7YgTKl4s2tWYvvse2d6J75ZIQ8BceDgW2LHlFAZtQSQyyhYuXFBS/xBVzODHtG4hLydJa5yJVMRmw4akkhQ5WF4Y56xQ+Mr+IypvNlVrjhqTB/MVNm9p3Yg/D9ZvGnxkE+53fgfKX3JKKkfHzFZKZOCKfELCymGdOjm58XvGbI8+bdTkLEnoCK5CUgVOQD28Jf4Uml0D407jx4ulJ1fRwp/I4CQS3qNZt2qcbcsgogbuvHfw6d8qFzhpR4yp2DLZB2Y3Qsop+KZUymBYqoxImNQdSlTwdiGnJWgBFnR8LjlSjnF1Hw4EsUWoOJp5oGiWnPewnHzmyArjg8kjGOhU5sH6wad2QAbYUWO7uZXxGZLfL7s08WyOWZZKWIxbYEvREmmHnNur+ZpjN7AKYWqt0JbYjb3fxALL2IczBlMkA4ZUNLhPvPVdF6ax4AlUM2O2Lfk4dHL4xRd7b7pLQ+Paygiy0L9qDjFslGJhGH8VyYwTBtgbsRjePaUM6qhwhYEzs7NycP7TNqAOF7u2BihAx3CCGMqxkemXqHnrchliHKSNn+zSfb2XX+c6uuF10jqtAorzJOTSvJsRlPJOmP3qE5WWZ7rkrWxmaCGHPX55n4o83vpsxgmNQyAns083SASchWHeEAp2uGP+OjOtbrw8WXooDrf8wnZ1kVMQwPAHsq6C5FbLyHmIUTJnXjg6/BKS+YCUYeEihh9iuaUHIxhMxjgQgzk0oKEzCxD38krPPXz4KBtHcSik8eYh/ff6cWQX3rbuyMIro4+6vVOxJMDSgPckGY00ApNJBWVFyKEUqARPNNpbEJJrb3KL5GRs8lZjZuNR4Bw+l7K+vAGcgwOTiv1DKg/VGWkDRqsgFCGYhp6/XkxblJe0Zuy2zTy/M2r/mO1AWfQMYmURCwQTw7Mj64zk3JuFLmYXiExVeLUOTg/hELx5ZdjeEM2q4BRi7/SJBqLhlykkaQjoskwUCrQhFMzqSTDUcWIHFljb9aoeJ2khYPjnRtA6c+G5k9beAtAYuO8HpuaMghXXkLID933fNX0EgeGGZJ1nFNkgoYoyU1YWLHxXTe71dNE7JQXa2jDgeUjH+uQqNftmMWWuTLfZ97fp7teQdSLGKQk4ZHdADpM5Lq0iU/szMdgZNa0T4v7xsS2W3tMCfDXza/XCuUBamSqZtPoGWVPFuX7WrET12ap8BnV2DTz5rE5NTiy+SFScqnuOqJqqxPJlfQ/+MNz8JAZlTU30+u7wL7tVdU0iWTykZMna6er8b1EixREwZW7iSKs1p7iiqXJgv9j/MgVJXTTD2QEyk2V4SKTOEOkWUXoeHSSNPNTfKYrL8itrxnj01F51qOyszAuvOv+1b+09/Ad0yNHglu34ZJ8li/OwqZkzi6OouWX49cYIdHdfF6dof+BK7423Rrt2wwv4joOd+LQfPRPumOP+sMS994SLJzmyH79ku3fGy1H3yy53O6bTO5vCHee4Aw0AhbGLkAcdyXR0SRGoslLJRZ0tWHxpnP8y77TYppb0mrXDW34JOxdefrGpqbZ96f7lq/puvydRO0f3DAy/sLPw2qVuzzt9N30TXmKu/zKdXQmHt6810pTpbNXmRwHtmaFO2f2K2327aHuMmYlOiuAkXm6gW0ytY7BorkctwSgWpbOxIuU4cCnPAmAtXV1td72F9KIvX0Sd3YyhPf1FK65ObXmkcM1XUPtlOrpFT59OlhQ++pAuL2fKtKdluKMdsqnqquKtP8ItgGVTkhTtnT0rV+MWe/BNCtNAP4xHpy7VF2ygyjVsCeSwKecwVO/dzN/2/c6+v10e3sv7Tu+VhOjOj1GNWVopC2ZOk184neGqq117Ug5HZUOVl6kF5w/9+jfD6zci5djXG9IrVkEjuqxs0oPfxkjY3FqQSmFbgy+8PPzopuH1m8Pmd9lZ9rRyWgJpKD1XBMUkE2r6ZaZsmT30hmuuZ6RAhQRZD/+ViqdxUoqOcMmZmgq2YY+0IYdrZLR83HPMmIwABxQlS/h8XxeHe9cn1NQmrqhzvYcVTZepUn1FNYqExIULKFVs+3qQkKmciztz5cW2eQ/kStScNdzcFlSfIXrTXKA3vcsytO1WlfN03RO2v0ukqjz3kqJ8GWfxYBLykzu8Vx9odLOVmnWtOmWBK5ihol4xaZrtxeeM/MjjGOMbjjxU/9OBdRtx0nfd1zEyuHnb8GtvAErSN66lnh6cuN4ejyAxmgCZugduu5fHMefaNQOPbWMk85eGnnuJYW/VnYc/f7bbeQODjQc89/52Gu7he/s6eOTAm/y4lk3Rs+fZTxtAOV1/B6PXpw10qJV23UR5HnlwqfD5P/avvtOTdeMzsDNMeZnaeobIjE9pLgmyjQWmRZGVTP1NpdazmX9YxdQhVjMYpC0VhbWRcgVwCl9CgF0wKctyE+bQlusCz6CZcnGzBJNAYZwqX6bOuz+vDkYe+Tax+NKhiplh+8cxQdUUwTdJRcw8Yr7nqxR1lNN7FWD/MOkglSzRIElWhdrTL8v02YBbgWD5IlnmSkrrKabKBZCKGzPkFRdXYkbw2mrmIs+0xoFdxEew/Kpow1ao1arIUYFiHqe8tewoT2crw4ZRu+vdgJo9AhtzrAsmjHJ2VLQkwRkb0su42zhauMGaxpeQKtsHLCrzOWlce4596cOXrZTt7axULm0tcYWrjtfXiXtVqApQvyyxMUuGF4A0F5wjVDlXePwg6My3Zkbjrb4wDkAoUSYblxC19TJPkpy3bWVJKnn/3X2r7uAsakJswFf4o+Yx7kQ4lCsROyzYQpEq/FJAFMFACa4uIk0ckzYue+Txsj2CWjobKM6xdsYiPfWLJ9A9P5G+1NCGjYPrmOvAEiHnO62OV2q6UErDbVmli12ijimSKosKzipExcedShSxKpCsDnKja43hgXEqkqkqfeFW8GeZf+8i/zcjKN9uvyWxcin3UHmbIEbRaHO51iddCMWg3lfWDeih34vM3yJdBSIUAcUMAEwZx30LFyp3nBLMxyupVDVEFUHSWyoa//dAPg6L6h8ovOtmnIScIUYNB21hVwKgGa7//SuCVEny4R+b8lriTCOthrKIfZs7PaNuJjS8UZ2sUhdt9KLGjV4z7p5M2YSEvKLChjcGbvtO1HFgNE923A02EduYc0niykuK1z+gkt4yqHXaNrmwz3ecAtBA4WP43+/SpOj0lbryG3F/l7MQc0jzX+ieq7hr42EZLhYOPfVcZuvj9PaHcMWAm2wRzBg7juYXHMCgoHD5ksSKa4IFF4jcCw34scmk6YOn3b5nxOB+Vl62C2/5RQEQTCVwLkyJOe2r0WlXm2CK4GbJMV0gcRx8/M+9GYnfAMUxLDj3hw6V4L6uod2N4u09rrkN6YR7ayelZHVlUFOpF56vSiYLmWu9+3uO9m1RsvW0uk9eEelOyuyPu0JUNFMWTVWl86h0rvcje4yoJ/4iVk78n5oJaSeknZB2QtoJaf8nxz8EGACgGZNxltvDAwAAAABJRU5ErkJggg=='
where nu_bandeira_cartao = 3;

--Visa
update acgsm001.acgtb069_bandeira_cartao
set im_bandeira_cartao = 'iVBORw0KGgoAAAANSUhEUgAAAE8AAAAtCAIAAABgaqGAAAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJbWFnZVJlYWR5ccllPAAAA3ZpVFh0WE1MOmNvbS5hZG9iZS54bXAAAAAAADw/eHBhY2tldCBiZWdpbj0i77u/IiBpZD0iVzVNME1wQ2VoaUh6cmVTek5UY3prYzlkIj8+IDx4OnhtcG1ldGEgeG1sbnM6eD0iYWRvYmU6bnM6bWV0YS8iIHg6eG1wdGs9IkFkb2JlIFhNUCBDb3JlIDUuNi1jMTQyIDc5LjE2MDkyNCwgMjAxNy8wNy8xMy0wMTowNjozOSAgICAgICAgIj4gPHJkZjpSREYgeG1sbnM6cmRmPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5LzAyLzIyLXJkZi1zeW50YXgtbnMjIj4gPHJkZjpEZXNjcmlwdGlvbiByZGY6YWJvdXQ9IiIgeG1sbnM6eG1wTU09Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC9tbS8iIHhtbG5zOnN0UmVmPSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvc1R5cGUvUmVzb3VyY2VSZWYjIiB4bWxuczp4bXA9Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC8iIHhtcE1NOk9yaWdpbmFsRG9jdW1lbnRJRD0ieG1wLmRpZDozMGE0YjVkZC1mNDIyLWJiNGMtOTE2Ny0xMThlYWQ1NTZiZmUiIHhtcE1NOkRvY3VtZW50SUQ9InhtcC5kaWQ6NEExNzdGN0RDQUZFMTFFOEJDRDdBMEVCMzRBODZERjQiIHhtcE1NOkluc3RhbmNlSUQ9InhtcC5paWQ6NEExNzdGN0NDQUZFMTFFOEJDRDdBMEVCMzRBODZERjQiIHhtcDpDcmVhdG9yVG9vbD0iQWRvYmUgUGhvdG9zaG9wIENDIDIwMTggKFdpbmRvd3MpIj4gPHhtcE1NOkRlcml2ZWRGcm9tIHN0UmVmOmluc3RhbmNlSUQ9InhtcC5paWQ6NjQ3YWI4NTEtOWRjNS0xZDQ4LWI1NTQtZTNlNGEyYTQzM2VjIiBzdFJlZjpkb2N1bWVudElEPSJ4bXAuZGlkOjMwYTRiNWRkLWY0MjItYmI0Yy05MTY3LTExOGVhZDU1NmJmZSIvPiA8L3JkZjpEZXNjcmlwdGlvbj4gPC9yZGY6UkRGPiA8L3g6eG1wbWV0YT4gPD94cGFja2V0IGVuZD0iciI/Pq7ny+cAAAo2SURBVHja7Fp7bFvVGb/nPvx+xI/Ejp3ESZM0aRqapBACTdsElUF5rAzWiW4wqmnaNAkJof2xadOmIcTEJjaJaS8mhgRDIG20vLYW2kEbCm1pmzQpSRq3edvxM44dX7/te+/Zubn2zbUToObf+cSy7uOc832/73yP32cFQAix/5uBY/9Po4K2graCtoK2graCtoK2graC9qsPUrzKzr6Fx65BDgJSgeGy9SkQcoAAqgbCvhuX6zfd5f2RxdH5FQIA4ZaBWHe99t6+FjqZe+W0M5xI42uvWI6rM2of2duqlJPS5VmGm3SvnJ/yX5hZcQXpEJ1iOVilkduMyo46Y3+7ra+tukot3yg3kWZPTbiveWJZJBJJgOgP3N1pvKXN/iVoCWMHw2S48DjjGoLpGOTXoh34ngGpimMAum/W9P8GkOoNInPPHh2dcEfEJ0ju3x4fRBfTnshzb40lMuzaNhjAsT2t1kcHtkqXn53yvXjSeWLMlWOgIE5oU4LR1LQ3OjTu/8t7V198/I4Hb3OUyE1n2Sf+PPzu+ATG4XlleRHkashyA2gNbeiDYYc4eiHrPoMtvilPu9IMlYO8t3MYxP3DzOoMZe4q2eLcVf+MjwYiVIB312u+1sXLmwvGkU48BiBYAXRuqVLICHHtyx86nzlyOZrICJ1YSTsm9GcaJWXSUhtV/+CKG0GFLF6wcN4RF8JMKsOUuM/nxi2ua1Rsf4wafOmN8LdSENdRmfxGyBUj1zfOPzXmyXKcREfu7t4WnZKPhSWfHwJCoj1w1KjE2yPnZn7yyoXVeKa46QS85rzn5wFU65RbbVUlQjkIXz19HeOIkudozXwwvhJNfsnZlgxCZZrVfOOl8/C3N53pNgborIJDZ7QyhbUWTXMHo8fHPJhEX7Ne8fXevNcFEsgn1g1BEqBGnw8EVyj27NHLXDFQjYLqbDDo1XKO4+IZZimUcIcSChlZrVeWqDcys3xpdnljc47yzlI0vRik62p0ZaBFY1eH8ZfvND1EG5/v+fCAfTbGyNj4Eq89WPeIsxMhLx1FhyYat3+btc3OH0Umx7pCaShBq1dRdeZ8nvtg3Lvoj2M4EM+ko9H09KFbeprMOpUMoUAx4A0nzzv9sWSWwEGJbscuLdCp3GZaQ5ZhnZ5kfydWHtoWu25nA3VlUffYhfv/evOJbzdOJTLLXDKAq2vFOW9cWMS4dVUIHH53V7twHY6nF5dpTMiVPCBoUCubLfo1l8bGvdE1jyjEGwCHdm8Z2G4rBD+mVcra7DLBcCXDF0kcv7wocRlcr5KtxNKim191x8qut1aDYkeDGcVtliWeGL3zhG+LmvFy0VlxwtWF4KVpFyxojDbrc9Ts6bIKd7F0LhDJYKBwthDYDEq9mlpLAXA1FEe2kcbbx5O+aDJ7I2Xz3xcX5oPJfPgAeJPD+p3BdiDaHOLDC54sC8tDi/ynq6kaLVKT2XhO9uTlO2ZWNXjGL054+8IyqoxYIZ8CCA/dtwMveF0gkqTTGazg5ACA9lptXioANqMWgKL0e3LU88jvPvjv2NIXQ03n2NeHZiCWNyLgwMG99t0d1aKLIVOiaF+mU2Vzqe4mk1opQ0A0ZM4ZMz81uQuj54VX8RRzYmReTBMAwMYawx0dNeLaybkExFgJIKypViPe7em0UgQherIw49PpwPf/dPrwH06NzIQ+T6Whz5YmPKuFYgU0KuquHXUtVr1OSWF5+4FYMj05Hywb7TZ7ld2gEsqPjsy+7W676E5hLG+2j53BmUBEggXs76mt1a4zngVfFJMcHzJ5g6T87O+pf2SwCWyQmMwwx4YXD/z62M9evhRJlDo2coHXhpzSB/0dNodZr1fKHRbtesGGYGRhpWy0Zp1ih8MgXFM4m+LIo9e1yTSP9sMJdxbmREfVqhX37qyTqIW56Mgay8kPrUq2td4q3fxXD/c9OtAMwCY6ZBju76cnD//xzEosIX0+OuM/ey0gokLGvLOrHsUFKl3NVmnJgdM++qt0Bb2tVvEEtFTmXxNVnkgqEs+euuySFp6djqpbJXwtmcpNe2koUcuiV9mqVMXVVfbc9/p/f7jPWqXENpwyqpznrnifefsTKKFYx4Z9dDafKVAisOgUA9uqhUreVm9aP1oMXHOvriYyZaPdu90qo/KUhQJcjCHGF1MXplaWwnEp/Xl4d4O0KnrDUR8/QXyC1+pJiizFhIrHY/vaTz51/48PdNWbNXymgZI5JPuPk/6L03mf9IVT7553A2y9gN/VU99kzZeoHQ1VJI6JsbMcTc4FomWjddRomy06YRdkOwLA81e9R89OQHEthzts8nt6W6SrvHQ2h2rAOtfhttprcAA2FWEzaX5+cOeRn971wO4GjChhgvCTz/KldeiKb4Fegex6qUGB9tGEd2jCc2bS51qOKeWygkRIp5g5X6wMdiEMGUkMtFdPeaMCTYMc987oUhq1WAVuDHD8YL9DqyjqyGa9MVZK63Bum9XyxYKarfoXfjgYTb/50UgKAkbE64/ytIFh2dc+dkIJk0Hbv3Bi6oX3p3jXQiUBQtSBiG8ZlptcCh/Emsvu5ge7m6SMNBzLJDMSPqjGH+htK1ky6Q4VByHRYCt0iBkmlWU2FUQRuENrxwhWutRm5uvW+Un3xVl/SZeEEngyy6Bv1HWi7xLWvRCMoT65bLQttTqbQVWSRAobgMFttVsthpIlqL4XJSSZ3GpSCNevfzR9+PlTR87Ozvpp1JpJ++Tjlzzvj3il1BrgsLfZhC5eO7vEcWX80oJa8hl/JFTMMcgbWWk1KBHN8EWSpT0HwBQUed/OxhLWjjD4I1IxoNGqNmvyRGrOt3p6wnNq3NNk0dmNakRxVXICnUtgNTUyH8jwKbdAvwis227s3VrrXAqfHl8QGfeNDES2Zn1xbzBpkRSCG0Irp4gdLcb3ht0b6gTRVi2797aGkqeLwdUwneATm1AqMKzOpKpSKwvpOi4YbT5Aow9WCqIgA0ClTPWLA7cj6UfOTYdjRR3Pw3ta7rnZgdKH2FkTAA8l0s/885LoLyhc5lYiPZi5PLRo3GQ3yUg8w7JFRwvgQ7vb5BS5AS0dRjRondhgZi0p4+sDtppIX/dHixFufl4GDfX0wb6BvppQLHV8LCB9ZdLIH79ne0e9ceOqNz9xjcy7sbXfWxBtuexc/ubtrWWj7W40V2sVS9EEtk6MgV5GPNjXvHGyKxzP4QwgufxBAdyqzzNkREsYVgALPgcqQPR5f0/Dj/Z33N7Gc6//XHROu6J8T1gQ3NNsabMbNtWz3UaNzlH5esHBT2cjZcctGhaD6tBg65hrhSJQeefpDYtxu7bUCQmz9FgU+r32ToFLcBwkSbBnW97b68yaV5/cNzyzfM7pnQvEIolcMp3LsRzKxmoFWWtU3dpi2ddV19VkkpOEUGZ8ETDQayRA/haB/sFA08b+Xhj7OlvdqRSF48Jkk05RZMjKfyJU0FbQVtBW0FbQVtBW0FbQfuXxPwEGAAOMoR6xTU8UAAAAAElFTkSuQmCC'
where nu_bandeira_cartao = 4;