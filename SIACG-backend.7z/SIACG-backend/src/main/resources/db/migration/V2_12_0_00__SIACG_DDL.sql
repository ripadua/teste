/*============================================================*/
/*           SCRIPT V2_12_0_00__SIACG_DDL		              */
/*============================================================*/

/*==============================================================*/
/* Cria a tabela                                                */
/*==============================================================*/
CREATE TABLE acgsm002.acgtbs11_contas_atacado
(
  co_identificador_contrato character varying(30), -- Código completo de identificação do contrato. contempla a concatenação da unidade, operação, código do contrato e DV.
  co_cnpj character varying(14),
  nu_agencia_origem character varying(4), -- Número da agencia de vinculação da garantia de cartão.
  nu_operacao_origem character varying(6), -- Número da operação da conta de vinculação da garantia de cartão.
  nu_conta_origem character varying(20), -- Número da conta de vinculação da garantia de cartão.
  nu_dv_conta_origem character varying(1), -- Número do dígito verificador da conta corrente.
  
  nu_agencia_destino character varying(4), -- Número da agencia de vinculação da garantia de cartão.
  nu_operacao_destino character varying(6), -- Número da operação da conta de vinculação da garantia de cartão.
  nu_conta_destino character varying(20), -- Número da conta de vinculação da garantia de cartão.
  nu_dv_conta_destino character varying(1), -- Número do dígito verificador da conta corrente.
  
  dt_referencia date, -- Data de referência das informações.
  ts_processamento timestamp without time zone,
  ts_grupo_processamento timestamp without time zone,
  no_arquivo character varying(100) -- Nome do arquivo transmitido pelo sistema de origem.
);

/*==============================================================*/
/* REVERT                                            */
/*==============================================================*/
-- Drop TABLE acgsm002.acgtbs11_contas_atacado;