/*============================================================*/
/*           SCRIPT V2_08_0_03__SIACG_DDL		              */
/*============================================================*/

drop sequence if exists acgsm001.sq111_info_manual_usuario;

drop index if exists acgsm001.ix_acgtbacgtb111_01;

drop table if exists acgsm001.acgtb111_info_manual_usuario;

/*==============================================================*/
/* Table: acgsm001.sq111_info_manual_usuario                    */
/*==============================================================*/

create sequence acgsm001.sq111_info_manual_usuario
START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;
    
/*==============================================================*/
/* Table: acgsm001.acgtb111_info_manual_usuario                 */
/*==============================================================*/    
create table acgsm001.acgtb111_info_manual_usuario (
   nu_manual            INT4                 not null default nextval('acgsm001.sq111_info_manual_usuario'::regclass),
   ts_inclusao          TIMESTAMP            not null,
   co_responsavel       VARCHAR(8)           null,
   no_manual            VARCHAR(30)          not null,
   constraint PK_ACGTB111_INFO_MANUAL_USUARI primary key (nu_manual)
);

comment on table acgsm001.acgtb111_info_manual_usuario is
'Armazena informações referentes ao manual do usuário do SIACG, que é armazenado em um servidor ftp.';

comment on column acgsm001.acgtb111_info_manual_usuario.nu_manual is
'Identificador do registro, gerado automaticamente.';

comment on column acgsm001.acgtb111_info_manual_usuario.ts_inclusao is
'Data e Hora em que o manual do usuário foi enviado para o servidor ftp.';

comment on column acgsm001.acgtb111_info_manual_usuario.co_responsavel is
'Código da matrícula do responsável pela envio do manual do usuário.';

comment on column acgsm001.acgtb111_info_manual_usuario.no_manual is
'Nome do manual do usuário.';

/*==============================================================*/
/* Index: acgsm001.ix_acgtbacgtb111_01                          */
/*==============================================================*/
create  index ix_acgtbacgtb111_01 on acgsm001.acgtb111_info_manual_usuario (
co_responsavel
);

/*============================================================*/
/* Revert                                                     */
/*============================================================*/
-- DROP INDEX acgsm001.ix_acgtbacgtb111_01;
-- DROP TABLE acgsm001.acgtb111_info_manual_usuario;
-- DROP SEQUENCE acgsm001.sq111_info_manual_usuario;