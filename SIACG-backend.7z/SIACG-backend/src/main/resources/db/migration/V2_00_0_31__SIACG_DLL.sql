DROP TABLE IF EXISTS acgsm001.acgtb088_representante_imovel;

DROP TABLE IF EXISTS acgsm001.acgtb087_contrato_imoveis;

ALTER TABLE IF EXISTS acgsm001.acgtb081_imoveis DROP CONSTRAINT acgtb081_imoveis_nu_gestao_serventia_fkey;

ALTER TABLE IF EXISTS acgsm001.acgtb081_imovel DROP CONSTRAINT fk_acgtb081_imovel_acgtb089_gestao_serventia;

DROP TABLE IF EXISTS acgsm001.acgtb089_gestao_serventia;

DROP TABLE IF  EXISTS acgsm001.acgtb080_garantia_imoveis;

DROP TABLE IF EXISTS acgsm001.acgtb081_imoveis;

--#################################################################

DROP TABLE IF EXISTS acgsm001.acgtb088_representante_imovel;

DROP TABLE IF EXISTS acgsm001.acgtb087_contrato_imovel;

DROP TABLE IF EXISTS acgsm001.acgtb089_gestao_serventia;

DROP TABLE IF EXISTS acgsm001.acgtb080_garantia_imovel;

DROP TABLE IF EXISTS acgsm001.acgtb081_imovel;

-- Table: acgsm001.acgtb089_gestao_serventia

-- DROP TABLE acgsm001.acgtb089_gestao_serventia;

CREATE TABLE acgsm001.acgtb089_gestao_serventia
(
  nu_gestao_serventia integer NOT NULL DEFAULT nextval('acgsm001.sq089_gestao_serventia'::regclass), -- Identificador da serventia
  co_cns character varying(6) NOT NULL, -- Coluna que descreve ao Cadastro Nacional de Serventias.
  de_denominacao_serventia character varying NOT NULL, -- Coluna que descreve a denominação da serventia
  sg_uf character varying NOT NULL, -- Coluna que descreve a sigla da unidade federativa.
  de_municipio character varying NOT NULL, -- Coluna que descreve a descrição do municipio.
  de_observacao character varying, -- Coluna que descreve alguma observação em especifica da serventia.
  ic_ativo boolean DEFAULT true, -- Define a situação da serventia, ativo ou inativo.
  CONSTRAINT pk_acgtb089_gestao_serventia PRIMARY KEY (nu_gestao_serventia),
  CONSTRAINT CC_acgtb089_gestao_serventia_01 UNIQUE (co_cns)
)
WITH (
  OIDS=FALSE
);

COMMENT ON COLUMN acgsm001.acgtb089_gestao_serventia.nu_gestao_serventia IS 'Identificador da serventia';
COMMENT ON COLUMN acgsm001.acgtb089_gestao_serventia.co_cns IS 'Coluna que descreve ao Cadastro Nacional de Serventias.';
COMMENT ON COLUMN acgsm001.acgtb089_gestao_serventia.de_denominacao_serventia IS 'Coluna que descreve a denominação da serventia';
COMMENT ON COLUMN acgsm001.acgtb089_gestao_serventia.sg_uf IS 'Coluna que descreve a sigla da unidade federativa.';
COMMENT ON COLUMN acgsm001.acgtb089_gestao_serventia.de_municipio IS 'Coluna que descreve a descrição do municipio.';
COMMENT ON COLUMN acgsm001.acgtb089_gestao_serventia.de_observacao IS 'Coluna que descreve alguma observação em especifica da serventia.';
COMMENT ON COLUMN acgsm001.acgtb089_gestao_serventia.ic_ativo IS 'Define a situação da serventia, ativo ou inativo.';



-- Table: acgsm001.acgtb081_imovel

-- DROP TABLE acgsm001.acgtb081_imovel;

CREATE TABLE acgsm001.acgtb081_imovel
(
  nu_imovel integer NOT NULL DEFAULT nextval('acgsm001.sq080_imovel'::regclass), -- Identificador da tabela acgtb081_imovel.
  nu_matricula bigint NOT NULL, -- Número de matrícula do imóvel no cartório.
  no_cartorio character varying(100) NOT NULL, -- Nome do cartorio de registro do imóvel,
  no_logadouro character varying(100), -- Logadouro do imóvel,
  nu_numero character varying(50), -- Número do endereço do imóvel.
  no_complemento character varying(100), -- Complemento do endereço do imóvel,
  no_bairro character varying(50), -- Bairro que o imóvel esta localizado.
  no_municipio character varying(50) NOT NULL, -- Município que o imóvel esta localizado,
  no_uf character varying(2) NOT NULL, -- UF do imóvel,
  nu_cep bigint, -- CEP do imóvel.
  vr_area_imovel numeric(16,2) NOT NULL, -- Valor da área do imóvel,
  vr_area_privativa numeric(16,2) NOT NULL, -- Valor da área privativa (área construida do imóvel).
  de_identificacao_cartorio character varying(50), -- Identificação do cartório de registro de imóveis. 
  co_registro_garantia character varying(50), --Código do registro da garantia.
  dt_registro_garantia date, --Data do registro da garantia.
  de_grau_garantia_constituida character varying(50), --Descrição do grau de garantia constituída. Ex: Um imóvel pode possuir 1º grau de garantia para uma operação e 2º grau de garantia pra outra operação. 
  co_tipo_logradouro character varying(3), --Tipo do logradouro: RUA - Rua, AVE - Avenida, VIE - Viela, etc.
  nu_uso_imovel smallint, --Tipo de uso do imóvel: 1 - Residencial, 2 - Comercial, 3 - Rural.
  nu_categoria_imovel smallint, --Categoria do imóvel: 1 - Casa, 2 - Apartamento, 3 - Lote, 4 - Sala.
  nu_tipo_implantacao smallint, --Tipo de implantação do imóvel: 1 - Condomínio, 2 - Isolado.
  qt_dormitorio integer, --Quantidade de quartos.
  qt_vagas_garagem integer, --Quantidade de vagas na garagem.
  nu_estado_cnsro_condominio smallint, --Estado de conservação do condomínio: 1 - Bom, 2 - Regular, 3 - Ruim, 4 - Em Construção.
  vr_area_terreno numeric(16,2), --Valor da área do terreno.
  vr_testada character varying(50), --Valor da Testada do terreno. Testada é a dimensão do terreno que corresponde à entrada da casa ou prédio. 
  nu_estado_conservacao_imovel smallint, --Estado de conservação do imóvel: 1 - Bom, 2 - Regular, 3 - Ruim, 4 - Em Construção.
  nu_padrao_acabamento smallint, --Padrão de acabamento do imóvel: 1 - Alto, 2 - Normal, 3 - Baixo, 4 - Mínimo.
  dt_avaliacao date, -- Data de avaliação do imóvel pela engenharia Caixa.
  vr_avaliacao numeric(16,2), --Valor da avaliação do imóvel pela engenharia Caixa.
  dt_compra_venda date, --Data do contrato de compra e venda do imóvel. 
  vr_compra_venda numeric(16,2), --Valor da compra e venda do imóvel.
  de_classificacao character varying(50), --Descrição da classificação do imóvel: Ex: Urbano, Rural.
  vr_indice_reajuste numeric(16,2), --Valor do indice de reajuste do valor do imóvel. 
  vr_imovel_contratacao numeric(16,2), --Valor do imóvel na contratação.
  vr_atualizado_imovel numeric(16,2), --Valor atualizado do imóvel. 
  de_dados_fiduciante character varying(50), --Descrição das informações do fiduciante
  co_tipo_pessoa character varying(1), --Tipo da pessoa: F - Pessoa Física, J - Pessoa Jurídica.
  de_devedor_scr character varying(50), --Descrição do devedor SCR.
  de_imovel character varying(500), -- Descrição geral sobre o imóvel.
  nu_grupo_garantia integer, --FK da tabela de grupo_garantia
  nu_tipo_garantia smallint, --Tipo de garantia: 1 - Alienação Fiduciária, 2 - Hipoteca.
  de_cartorio character varying(10), --Descrição do cartório
  nu_pessoa integer, --FK da tabela de pessoa. Titular do imóvel. 
  de_imovel_rural character varying(50), --Descrição do imóvel rural. Ex: Fazenda Bom Sucesso. 
  co_avaliacao_consessao character varying(50), --Código da avaliação pela engenharia na concessão.
  co_avaliacao_consolidado character varying(50), --Código da avaliação pela engenharia consolidado.
  nu_gestao_serventia integer, --FK com a tabela de gestao_serventia. Identifica o cartório de registros de imóvel.
  dt_avaliacao_consolidada date, -- Define a data de avaliação consolidada do imóvel.
  CONSTRAINT pk_acgtb081_imovel PRIMARY KEY (nu_imovel),
  CONSTRAINT fk_acgtb081_imovel_acgtb089_gestao_serventia FOREIGN KEY (nu_gestao_serventia)
      REFERENCES acgsm001.acgtb089_gestao_serventia (nu_gestao_serventia) MATCH SIMPLE
      ON UPDATE NO ACTION ON DELETE NO ACTION,
  CONSTRAINT fk_acgtb081_imovel_acgtb003_pessoa FOREIGN KEY (nu_pessoa)
      REFERENCES acgsm001.acgtb003_pessoa (nu_pessoa) MATCH SIMPLE
      ON UPDATE NO ACTION ON DELETE NO ACTION,

CONSTRAINT ck_acgtb081_01 CHECK (nu_uso_imovel IS NULL OR (nu_uso_imovel::smallint = ANY (ARRAY[1, 2, 3]))),
CONSTRAINT ck_acgtb081_02 CHECK (nu_categoria_imovel IS NULL OR (nu_categoria_imovel::smallint = ANY (ARRAY[1, 2, 3, 4]))),
CONSTRAINT ck_acgtb081_03 CHECK (nu_tipo_implantacao IS NULL OR (nu_tipo_implantacao::smallint = ANY (ARRAY[1, 2]))),
CONSTRAINT ck_acgtb081_04 CHECK (nu_estado_cnsro_condominio IS NULL OR (nu_estado_cnsro_condominio::smallint = ANY (ARRAY[1, 2, 3, 4]))),
CONSTRAINT ck_acgtb081_05 CHECK (nu_estado_conservacao_imovel IS NULL OR (nu_estado_conservacao_imovel::smallint = ANY (ARRAY[1, 2, 3, 4]))),
CONSTRAINT ck_acgtb081_06 CHECK (nu_padrao_acabamento IS NULL OR (nu_padrao_acabamento::smallint = ANY (ARRAY[1, 2, 3, 4]))),
CONSTRAINT ck_acgtb081_07 CHECK (co_tipo_pessoa IS NULL OR (co_tipo_pessoa = ANY (ARRAY['F', 'J']))),
CONSTRAINT ck_acgtb081_08 CHECK (nu_tipo_garantia IS NULL OR (nu_tipo_garantia::smallint = ANY (ARRAY[1, 2])))
)
WITH (
  OIDS=FALSE
);

COMMENT ON TABLE acgsm001.acgtb081_imovel
  IS 'Tabela de garantia de imóveis, usada ao se cadastrar garantia de contrato.';
COMMENT ON COLUMN acgsm001.acgtb081_imovel.nu_imovel IS 'Identificador da tabela acgtb081_imovel.';
COMMENT ON COLUMN acgsm001.acgtb081_imovel.nu_matricula IS 'Número de matrícula do imóvel.';
COMMENT ON COLUMN acgsm001.acgtb081_imovel.no_cartorio IS 'Nome do cartorio de registro do imóvel,';
COMMENT ON COLUMN acgsm001.acgtb081_imovel.no_logadouro IS 'Logadouro do imóvel,';
COMMENT ON COLUMN acgsm001.acgtb081_imovel.nu_numero IS 'Número do endereço do imóvel.';
COMMENT ON COLUMN acgsm001.acgtb081_imovel.no_complemento IS 'Complemento do endereço do imóvel,';
COMMENT ON COLUMN acgsm001.acgtb081_imovel.no_bairro IS 'Bairro que o imóvel esta localizado.';
COMMENT ON COLUMN acgsm001.acgtb081_imovel.no_municipio IS 'Município que o imóvel esta localizado,';
COMMENT ON COLUMN acgsm001.acgtb081_imovel.no_uf IS 'UF do imóvel,';
COMMENT ON COLUMN acgsm001.acgtb081_imovel.nu_cep IS 'CEP do imóvel.';
COMMENT ON COLUMN acgsm001.acgtb081_imovel.vr_area_imovel IS 'Valor da área do imóvel,';
COMMENT ON COLUMN acgsm001.acgtb081_imovel.vr_area_privativa IS 'Valor da área privativa (área construida do imóvel).';
COMMENT ON COLUMN acgsm001.acgtb081_imovel.dt_avaliacao_consolidada IS 'Define a data de avaliação consolidada do imóvel.';
COMMENT ON COLUMN acgsm001.acgtb081_imovel.de_identificacao_cartorio IS 'Identificação do cartório de registro de imóveis.'; 
COMMENT ON COLUMN acgsm001.acgtb081_imovel.co_registro_garantia IS 'Código do registro da garantia.';
COMMENT ON COLUMN acgsm001.acgtb081_imovel.dt_registro_garantia IS 'Data do registro da garantia.';
COMMENT ON COLUMN acgsm001.acgtb081_imovel.de_grau_garantia_constituida IS 'Descrição do grau de garantia constituída. Ex: Um imóvel pode possuir 1º grau de garantia para uma operação e 2º grau de garantia pra outra operação.'; 
COMMENT ON COLUMN acgsm001.acgtb081_imovel.co_tipo_logradouro IS 'Tipo do logradouro: 
	ACS - Acesso;   
	AER - Aeroporto;
	ALM - Alameda;
	ARE - Área;,
	ASS - Assentamento;
	AVE - Avenida;
	BAL - Balneário;
	BEC - Beco;
	CAI - Cais;
	CAM - Caminho;
	CPO - Campo;
	COL - Colônia;
	COM - Comunidade;
	COR - Corredor;
	DES - Desvio;
	ESC - Escada;
	ESQ - Esquina;
	EST - Estrada;
	ETC - Estação;
	ETN - Estância;
	FAZ - Fazenda;
	GAL - Galeria;
	GRJ - Granja;
	HPD - Hipódromo;
	ILH - Ilha;
	JDM - Jardim;
	LRG - Largo;                    
	LAG - Lagoa;                    
	LIN - Linha;                    
	LOC - Localidade;
	LOT - Loteamento;
	MER - Mercado;
	PAC - Paco;
	PAS - Passeio;
	PCA - Praça;
	PIC - Picada;
	POR - Porto;
	PRA - Praia;
	PRQ - Parque;
	QDR - Quadra;
	QTL - Quartel;
	RDV - Rodoviária;
	ROD - Rodovia;
	RUA - Rua;
	SQD - Super Quadra;
	TRV - Travessão;
	TRA - Travessa;
	VDT - Viaduto;
	VIA - Via;
	VIE - Viela;
	VIL - Vila;                    
';
COMMENT ON COLUMN acgsm001.acgtb081_imovel.nu_uso_imovel IS 'Tipo de uso do imóvel: 1 - Residencial, 2 - Comercial, 3 - Rural.';
COMMENT ON COLUMN acgsm001.acgtb081_imovel.nu_categoria_imovel IS 'Categoria do imóvel: 1 - Casa, 2 - Apartamento, 3 - Lote, 4 - Sala.';
COMMENT ON COLUMN acgsm001.acgtb081_imovel.nu_tipo_implantacao IS 'Tipo de implantação do imóvel: 1 - Condomínio, 2 - Isolado.';
COMMENT ON COLUMN acgsm001.acgtb081_imovel.qt_dormitorio IS 'Quantidade de quartos.';
COMMENT ON COLUMN acgsm001.acgtb081_imovel.qt_vagas_garagem IS 'Quantidade de vagas na garagem.';
COMMENT ON COLUMN acgsm001.acgtb081_imovel.nu_estado_cnsro_condominio IS 'Estado de conservação do condomínio: 1 - Bom, 2 - Regular, 3 - Ruim, 4 - Em Construção.';
COMMENT ON COLUMN acgsm001.acgtb081_imovel.vr_area_terreno IS 'Valor da área do terreno.';
COMMENT ON COLUMN acgsm001.acgtb081_imovel.vr_testada IS 'Valor da Testada do terreno. Testada é a dimensão do terreno que corresponde à entrada da casa ou prédio. ';
COMMENT ON COLUMN acgsm001.acgtb081_imovel.nu_estado_conservacao_imovel IS 'Estado de conservação do imóvel: 1 - Bom, 2 - Regular, 3 - Ruim, 4 - Em Construção.';
COMMENT ON COLUMN acgsm001.acgtb081_imovel.nu_padrao_acabamento IS 'Padrão de acabamento do imóvel: 1 - Alto, 2 - Normal, 3 - Baixo, 4 - Mínimo.';
COMMENT ON COLUMN acgsm001.acgtb081_imovel.dt_avaliacao IS 'Data de avaliação do imóvel pela engenharia Caixa.';
COMMENT ON COLUMN acgsm001.acgtb081_imovel.vr_avaliacao IS 'Valor da avaliação do imóvel pela engenharia Caixa.';
COMMENT ON COLUMN acgsm001.acgtb081_imovel.dt_compra_venda IS 'Data do contrato de compra e venda do imóvel. ';
COMMENT ON COLUMN acgsm001.acgtb081_imovel.vr_compra_venda IS 'Valor da compra e venda do imóvel.';
COMMENT ON COLUMN acgsm001.acgtb081_imovel.de_classificacao IS 'Descrição da classificação do imóvel: Ex: Urbano, Rural.';  
COMMENT ON COLUMN acgsm001.acgtb081_imovel.vr_indice_reajuste IS 'Valor do indice de reajuste do valor do imóvel. ';
COMMENT ON COLUMN acgsm001.acgtb081_imovel.vr_imovel_contratacao IS 'Valor do imóvel na contratação.';
COMMENT ON COLUMN acgsm001.acgtb081_imovel.vr_atualizado_imovel IS 'Valor atualizado do imóvel. ';
COMMENT ON COLUMN acgsm001.acgtb081_imovel.de_dados_fiduciante IS 'Descrição das informações do fiduciante';
COMMENT ON COLUMN acgsm001.acgtb081_imovel.co_tipo_pessoa IS 'Tipo da pessoa: F - Pessoa Física, J - Pessoa Jurídica.';
COMMENT ON COLUMN acgsm001.acgtb081_imovel.de_devedor_scr IS 'Descrição do devedor SCR.';
COMMENT ON COLUMN acgsm001.acgtb081_imovel.de_imovel IS 'Descrição geral sobre o imóvel.';
COMMENT ON COLUMN acgsm001.acgtb081_imovel.nu_grupo_garantia IS 'FK da tabela de grupo_garantia';
COMMENT ON COLUMN acgsm001.acgtb081_imovel.nu_tipo_garantia IS 'Tipo de garantia: 1 - Alienação Fiduciária, 2 - Hipoteca.';
COMMENT ON COLUMN acgsm001.acgtb081_imovel.de_cartorio IS 'Descrição do cartório';
COMMENT ON COLUMN acgsm001.acgtb081_imovel.nu_pessoa IS 'FK da tabela de pessoa. Titular do imóvel. ';
COMMENT ON COLUMN acgsm001.acgtb081_imovel.de_imovel_rural IS 'Descrição do imóvel rural. Ex: Fazenda Bom Sucesso.'; 
COMMENT ON COLUMN acgsm001.acgtb081_imovel.co_avaliacao_consessao IS 'Código da avaliação pela engenharia na concessão.';
COMMENT ON COLUMN acgsm001.acgtb081_imovel.co_avaliacao_consolidado IS 'Código da avaliação pela engenharia consolidado.';
COMMENT ON COLUMN acgsm001.acgtb081_imovel.nu_gestao_serventia IS 'FK com a tabela de gestao_serventia. Identifica o cartório de registros de imóvel.';
COMMENT ON COLUMN acgsm001.acgtb081_imovel.dt_avaliacao_consolidada IS 'Define a data de avaliação consolidada do imóvel.';


-- Table: acgsm001.acgtb080_garantia_imovel

-- DROP TABLE acgsm001.acgtb080_garantia_imovel;

CREATE TABLE acgsm001.acgtb080_garantia_imovel
(
  nu_garantia_contrato integer NOT NULL, -- Identificador da garantia do contrato. Tabela acgtb009_garantia_contrato.
  nu_imovel integer NOT NULL, -- Identificador da tabela de imoveis (acgtb081_imovel)
  vr_garantia numeric(16,2), -- Valor da garantia a ser deduzido do valor de avaliação do imóvel
  CONSTRAINT pk_acgtb080_garantia_imovel PRIMARY KEY (nu_imovel, nu_garantia_contrato),
  CONSTRAINT fk_acgtb080_acgtb009 FOREIGN KEY (nu_garantia_contrato)
      REFERENCES acgsm001.acgtb009_garantia_contrato (nu_garantia_contrato) MATCH SIMPLE
      ON UPDATE RESTRICT ON DELETE RESTRICT,
  CONSTRAINT fk_acgtb080_acgtb081 FOREIGN KEY (nu_imovel)
      REFERENCES acgsm001.acgtb081_imovel (nu_imovel) MATCH SIMPLE
      ON UPDATE RESTRICT ON DELETE RESTRICT
)
WITH (
  OIDS=FALSE
);
COMMENT ON TABLE acgsm001.acgtb080_garantia_imovel
  IS 'Tabela de ligação entre a garantia de imóveis e a tabela de garantia de contrato.';
COMMENT ON COLUMN acgsm001.acgtb080_garantia_imovel.nu_garantia_contrato IS 'Identificador da garantia do contrato. Tabela acgtb009_garantia_contrato.';
COMMENT ON COLUMN acgsm001.acgtb080_garantia_imovel.nu_imovel IS 'Identificador da tabela de imoveis (acgtb081_imovel)';
COMMENT ON COLUMN acgsm001.acgtb080_garantia_imovel.vr_garantia IS 'Valor da garantia a ser deduzido do valor de avaliação do imóvel';


-- Table: acgsm001.acgtb087_contrato_imovel

-- DROP TABLE acgsm001.acgtb087_contrato_imovel;

CREATE TABLE acgsm001.acgtb087_contrato_imovel
(
  nu_contrato integer NOT NULL, -- Identificador da garantia do contrato. Tabela acgtb001_contrato.
  nu_imovel integer NOT NULL, -- Identificador da tabela de imoveis (acgtb081_imovel)
  CONSTRAINT pk_acgtb087_contrato_imovel PRIMARY KEY (nu_imovel, nu_contrato),
  CONSTRAINT fk_acgtb087_acgtb001 FOREIGN KEY (nu_contrato)
      REFERENCES acgsm001.acgtb001_contrato (nu_contrato) MATCH SIMPLE
      ON UPDATE RESTRICT ON DELETE RESTRICT,
  CONSTRAINT fk_acgtb087_acgtb081 FOREIGN KEY (nu_imovel)
      REFERENCES acgsm001.acgtb081_imovel (nu_imovel) MATCH SIMPLE
      ON UPDATE RESTRICT ON DELETE RESTRICT
)
WITH (
  OIDS=FALSE
);

COMMENT ON COLUMN acgsm001.acgtb087_contrato_imovel.nu_contrato IS 'Identificador da garantia do contrato. Tabela acgtb001_contrato.';
COMMENT ON COLUMN acgsm001.acgtb087_contrato_imovel.nu_imovel IS 'Identificador da tabela de imoveis (acgtb081_imovel)';




-- Table: acgsm001.acgtb088_representante_imovel

-- DROP TABLE acgsm001.acgtb088_representante_imovel;

CREATE TABLE acgsm001.acgtb088_representante_imovel
(
  nu_representante_imovel integer NOT NULL DEFAULT nextval('acgsm001.sq088_representate_imovel'::regclass),
  nu_pessoa integer NOT NULL, -- Identificador da pesssoa(representante legal). Tabela acgtb003_pessoa.
  nu_imovel integer NOT NULL, -- Identificador da tabela de imoveis (acgtb081_imoveis)
  CONSTRAINT pk_acgtb088_representante_imovel PRIMARY KEY (nu_representante_imovel),
  CONSTRAINT fk_acgtb088_acgtb080 FOREIGN KEY (nu_pessoa)
      REFERENCES acgsm001.acgtb003_pessoa (nu_pessoa) MATCH SIMPLE
      ON UPDATE NO ACTION ON DELETE NO ACTION,
  CONSTRAINT fk_acgtb088_acgtb081 FOREIGN KEY (nu_imovel)
      REFERENCES acgsm001.acgtb081_imovel (nu_imovel) MATCH SIMPLE
      ON UPDATE RESTRICT ON DELETE RESTRICT
)
WITH (
  OIDS=FALSE
);
COMMENT ON COLUMN acgsm001.acgtb088_representante_imovel.nu_pessoa IS 'Identificador da pesssoa(representante legal). Tabela acgtb003_pessoa.';
COMMENT ON COLUMN acgsm001.acgtb088_representante_imovel.nu_imovel IS 'Identificador da tabela de imoveis (acgtb081_imoveis)';