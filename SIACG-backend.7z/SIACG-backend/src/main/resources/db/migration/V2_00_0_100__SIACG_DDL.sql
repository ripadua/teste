/*==============================================================*/
/*           SCRIPT V2_00_0_100__SIACG_DLL						*/
/*==============================================================*/

/*==============================================================*/
/* Table: acgsm001.acgtb069_bandeira_cartao                     */
/*==============================================================*/

alter table acgsm001.acgtb069_bandeira_cartao DROP CONSTRAINT ckc_ic_tipo_movimenta_acgtb069 ;
alter table acgsm001.acgtb069_bandeira_cartao ADD CONSTRAINT ckc_ic_tipo_movimenta_acgtb069 CHECK (ic_tipo_movimentacao::text = ANY (ARRAY['0'::character varying::text, '1'::character varying::text, '2'::character varying::text, '3'::character varying::text, '4'::character varying::text]));
COMMENT ON COLUMN acgsm001.acgtb069_bandeira_cartao.ic_tipo_movimentacao IS 'Indica o tipo de movimentação da bandeira: 
0 - Débito 
1 - Crédito 
2 - Pré-pago 
3 - Antecipação de recebíveis 
4 - A definir';