/*==============================================================*/
/* Table: acgsm001.acgtb085_segmento_cliente                             */
/*==============================================================*/
create table acgsm001.acgtb085_segmento_cliente (
   nu_segmento_cliente  INT4                 not null,
   no_segmento_cliente  VARCHAR(100)         null,
   co_segmento_cliente  VARCHAR(4)           null,
   constraint PK_acgsm001_acgtb085_segmento_cliente primary key (nu_segmento_cliente)
);


comment on table acgsm001.acgtb085_segmento_cliente is
'Segmentos possíveis para um cliente caixa.';

comment on column acgsm001.acgtb085_segmento_cliente.nu_segmento_cliente is
'Numero identificador do segmento do cliente.';

comment on column acgsm001.acgtb085_segmento_cliente.no_segmento_cliente is
'Nome do segmento do cliente.';

comment on column acgsm001.acgtb085_segmento_cliente.co_segmento_cliente is
'Sigla do segmento do cliente.';

/*==============================================================*/
/* Table: acgsm001.acgtb086_parametro_produto_seg                       */
/*==============================================================*/
create table acgsm001.acgtb086_parametro_produto_seg (
   nu_produto           int4                 null,
   nu_modalidade        int4                 null,
   nu_segmento_cliente  INT4                 null
);

comment on table acgsm001.acgtb086_parametro_produto_seg is
'Tabela de relacionamento entre a tabela 057_parametro_produto e a 085_segmento_cliente.';

comment on column acgsm001.acgtb086_parametro_produto_seg.nu_produto is
'Número de identificação do produto.';

comment on column acgsm001.acgtb086_parametro_produto_seg.nu_modalidade is
'Número da modalidade de contratação do produto.';

comment on column acgsm001.acgtb086_parametro_produto_seg.nu_segmento_cliente is
'Numero identificador do segmento do cliente.';

alter table acgsm001.acgtb086_parametro_produto_seg
   add constraint FK_ACGTB_08_REFERENCE_ACGTB057 foreign key (nu_produto, nu_modalidade)
      references acgsm001.acgtb057_parametro_produto (nu_produto, nu_modalidade)
      on delete restrict on update restrict;

alter table acgsm001.acgtb086_parametro_produto_seg
   add constraint FK_ACGTB_08_REFERENCE_ACGTB085 foreign key (nu_segmento_cliente)
      references acgsm001.acgtb085_segmento_cliente (nu_segmento_cliente)
      on delete restrict on update restrict;
      
ALTER TABLE acgsm001.acgtb057_parametro_produto ADD COLUMN pc_juros NUMERIC(16,2);
comment on column acgsm001.acgtb057_parametro_produto.pc_juros is
'Percentual de juros do Parametro produto.';
ALTER TABLE acgsm001.acgtb057_parametro_produto ADD COLUMN dh_inicio_prazo DATE;
comment on column acgsm001.acgtb057_parametro_produto.dh_inicio_prazo is
'Inicio do prazo do Parametro Produto.';
ALTER TABLE acgsm001.acgtb057_parametro_produto ADD COLUMN dh_fim_prazo DATE;
comment on column acgsm001.acgtb057_parametro_produto.dh_fim_prazo is
'Fim do prazo do Parametro Produto.';
ALTER TABLE acgsm001.acgtb057_parametro_produto ADD COLUMN co_matricula VARCHAR(7);
comment on column acgsm001.acgtb057_parametro_produto.co_matricula is
'Matricula do responsável pela parametrização.';


INSERT INTO acgsm001.acgtb085_segmento_cliente(nu_segmento_cliente, no_segmento_cliente, co_segmento_cliente) VALUES (1, 'Gente de Valor','GV');
INSERT INTO acgsm001.acgtb085_segmento_cliente(nu_segmento_cliente, no_segmento_cliente, co_segmento_cliente) VALUES (2, 'Gente que Conquista','GC');
INSERT INTO acgsm001.acgtb085_segmento_cliente(nu_segmento_cliente, no_segmento_cliente, co_segmento_cliente) VALUES (3, 'Gente que Realiza','GR');
INSERT INTO acgsm001.acgtb085_segmento_cliente(nu_segmento_cliente, no_segmento_cliente, co_segmento_cliente) VALUES (4, 'Exclusivo','FX');
INSERT INTO acgsm001.acgtb085_segmento_cliente(nu_segmento_cliente, no_segmento_cliente, co_segmento_cliente) VALUES (5, 'Empreender','EE');
INSERT INTO acgsm001.acgtb085_segmento_cliente(nu_segmento_cliente, no_segmento_cliente, co_segmento_cliente) VALUES (6, 'Desenvolver','ES');
INSERT INTO acgsm001.acgtb085_segmento_cliente(nu_segmento_cliente, no_segmento_cliente, co_segmento_cliente) VALUES (7, 'Fortalecer','EF');
INSERT INTO acgsm001.acgtb085_segmento_cliente(nu_segmento_cliente, no_segmento_cliente, co_segmento_cliente) VALUES (8, 'Expandir','EX');
INSERT INTO acgsm001.acgtb085_segmento_cliente(nu_segmento_cliente, no_segmento_cliente, co_segmento_cliente) VALUES (9, 'Empresarial','MD');
INSERT INTO acgsm001.acgtb085_segmento_cliente(nu_segmento_cliente, no_segmento_cliente, co_segmento_cliente) VALUES (10, 'Empresarial Mais','UD');
INSERT INTO acgsm001.acgtb085_segmento_cliente(nu_segmento_cliente, no_segmento_cliente, co_segmento_cliente) VALUES (11, 'Corporativo','EC');
INSERT INTO acgsm001.acgtb085_segmento_cliente(nu_segmento_cliente, no_segmento_cliente, co_segmento_cliente) VALUES (12, 'Corporativo Ultra','LC');
INSERT INTO acgsm001.acgtb085_segmento_cliente(nu_segmento_cliente, no_segmento_cliente, co_segmento_cliente) VALUES (13, 'Investidor Institucional Privado','IV');
INSERT INTO acgsm001.acgtb085_segmento_cliente(nu_segmento_cliente, no_segmento_cliente, co_segmento_cliente) VALUES (14, 'Federal','PF');
INSERT INTO acgsm001.acgtb085_segmento_cliente(nu_segmento_cliente, no_segmento_cliente, co_segmento_cliente) VALUES (15, 'Estados','PE');
INSERT INTO acgsm001.acgtb085_segmento_cliente(nu_segmento_cliente, no_segmento_cliente, co_segmento_cliente) VALUES (16, 'Municípios I','PM');
INSERT INTO acgsm001.acgtb085_segmento_cliente(nu_segmento_cliente, no_segmento_cliente, co_segmento_cliente) VALUES (17, 'Municípios II','PN');
INSERT INTO acgsm001.acgtb085_segmento_cliente(nu_segmento_cliente, no_segmento_cliente, co_segmento_cliente) VALUES (18, 'Municípios III','PO');
INSERT INTO acgsm001.acgtb085_segmento_cliente(nu_segmento_cliente, no_segmento_cliente, co_segmento_cliente) VALUES (19, 'Estatais – Corporativo Ultra','PP');
INSERT INTO acgsm001.acgtb085_segmento_cliente(nu_segmento_cliente, no_segmento_cliente, co_segmento_cliente) VALUES (20, 'Estatais - Corporativo','PG');
INSERT INTO acgsm001.acgtb085_segmento_cliente(nu_segmento_cliente, no_segmento_cliente, co_segmento_cliente) VALUES (21, 'Estatais – Empresarial Mais','PU');
INSERT INTO acgsm001.acgtb085_segmento_cliente(nu_segmento_cliente, no_segmento_cliente, co_segmento_cliente) VALUES (22, 'Estatais - Empresarial','PD');
INSERT INTO acgsm001.acgtb085_segmento_cliente(nu_segmento_cliente, no_segmento_cliente, co_segmento_cliente) VALUES (23, 'Regimes Próprios de Previdência Social','IN');
INSERT INTO acgsm001.acgtb085_segmento_cliente(nu_segmento_cliente, no_segmento_cliente, co_segmento_cliente) VALUES (24, 'Judiciário','JJ');
INSERT INTO acgsm001.acgtb085_segmento_cliente(nu_segmento_cliente, no_segmento_cliente, co_segmento_cliente) VALUES (25, 'PJ Privada de Infraestrutura – Corporativo Ultra','IP');
INSERT INTO acgsm001.acgtb085_segmento_cliente(nu_segmento_cliente, no_segmento_cliente, co_segmento_cliente) VALUES (26, 'PJ Privada de Infraestrutura - Corporativo','IG');
INSERT INTO acgsm001.acgtb085_segmento_cliente(nu_segmento_cliente, no_segmento_cliente, co_segmento_cliente) VALUES (27, 'PJ Privada de Infraestrutura – Empresarial Mais','IU');
INSERT INTO acgsm001.acgtb085_segmento_cliente(nu_segmento_cliente, no_segmento_cliente, co_segmento_cliente) VALUES (28, 'PJ Privada de Infraestrutura - Empresarial','ID');
INSERT INTO acgsm001.acgtb085_segmento_cliente(nu_segmento_cliente, no_segmento_cliente, co_segmento_cliente) VALUES (29, 'Cliente a Classificar','CL');
INSERT INTO acgsm001.acgtb085_segmento_cliente(nu_segmento_cliente, no_segmento_cliente, co_segmento_cliente) VALUES (30, 'Cliente CAIXA','CC');
INSERT INTO acgsm001.acgtb085_segmento_cliente(nu_segmento_cliente, no_segmento_cliente, co_segmento_cliente) VALUES (31, 'Conta Eleitoral','CE');
INSERT INTO acgsm001.acgtb085_segmento_cliente(nu_segmento_cliente, no_segmento_cliente, co_segmento_cliente) VALUES (32, 'Recurso Transitório','RT');