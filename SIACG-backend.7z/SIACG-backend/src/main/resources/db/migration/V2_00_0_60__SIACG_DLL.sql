/*==============================================================*/
/* Sequence: acgsm001.acgtb001_contrato                          */
/*==============================================================*/


ALTER TABLE acgsm001.acgtb001_contrato DROP CONSTRAINT ck_acgtb001_02; 
alter table acgsm001.acgtb001_contrato add constraint ck_acgtb001_02 check (ic_forma_inclusao in ('1', '2', '3', '4', '5'));

comment on column acgsm001.acgtb001_contrato.ic_forma_inclusao is
'Indica a origem da importação do contrato:

1- Rotina Carga de Contrato
2- Rotina Habitacional
3- SIFEC
4- Manual
5- Contrato Temporario (Caso o contrato não venha na rotina de carga, situacai 1, estes contratos serao desabilitados do SIACG)';


/*==============================================================*/
/* Reverse: acgsm001.acgtb001_contrato                           */
/*==============================================================*/      
      
--ALTER TABLE acgsm001.acgtb001_contrato DROP CONSTRAINT ck_acgtb001_02; 
--alter table acgsm001.acgtb001_contrato add constraint ck_acgtb001_02 check (ic_forma_inclusao in ('1', '2', '3', '4'));
--comment on column acgsm001.acgtb001_contrato.ic_forma_inclusao is
--'Indica a origem da importação do contrato:

--1- Rotina Carga de Contrato
--2- Rotina Habitacional
--3- SIFEC
--4- Manual';