--drop table acgsm001.acgtb074_cedente_habitacional;

/*==============================================================*/
/* Table: acgtb074_cedente_habitacional                         */
/*==============================================================*/
create table acgsm001.acgtb074_cedente_habitacional (
   nu_cedente           INT                not null,
   nu_empreendimento    INT                not null,
   constraint PK_ACGTB074_CEDENTE_HABITACION primary key (nu_cedente, nu_empreendimento)
);

comment on table acgsm001.acgtb074_cedente_habitacional is
'Vinculação dos Cedentes habitacionais parametrizados;';

-- set table ownership
alter table acgsm001.acgtb074_cedente_habitacional owner to postgres
;


alter table acgsm001.acgtb074_cedente_habitacional
   add constraint FK_ACGTB074_FK_ACGTB0_ACGTB004 foreign key (nu_cedente)
      references acgsm001.acgtb004_cedente (nu_cedente)
      on delete restrict on update restrict;

alter table acgsm001.acgtb074_cedente_habitacional
   add constraint FK_ACGTB074_FK_ACGTB0_ACGTB050 foreign key (nu_empreendimento)
      references acgsm001.acgtb050_empreendimento (nu_empreendimento)
      on delete restrict on update restrict;
