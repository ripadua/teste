--========================================
--Data: 22/04/2018
--Versão 1.22.0
--Adequações no banco de dados para implementação de Unidade Habitacional.
--========================================
INSERT INTO acgsm001.acgtb065_tipo_parcela VALUES (1, 'Sinal', 0, 1);
INSERT INTO acgsm001.acgtb065_tipo_parcela VALUES (2, 'Sinal', 1, 1);
INSERT INTO acgsm001.acgtb065_tipo_parcela VALUES (3, 'Sinal', 2, 2);
INSERT INTO acgsm001.acgtb065_tipo_parcela VALUES (4, 'Sinal', 3, 3);
INSERT INTO acgsm001.acgtb065_tipo_parcela VALUES (5, 'Sinal', 4, 4);
INSERT INTO acgsm001.acgtb065_tipo_parcela VALUES (6, 'Sinal', 6, 6);
INSERT INTO acgsm001.acgtb065_tipo_parcela VALUES (7, 'Sinal', 12, 12);
INSERT INTO acgsm001.acgtb065_tipo_parcela VALUES (8, 'Parcela', 0, 1);
INSERT INTO acgsm001.acgtb065_tipo_parcela VALUES (9, 'Parcela', 1, 1);
INSERT INTO acgsm001.acgtb065_tipo_parcela VALUES (10, 'Parcela', 2, 2);
INSERT INTO acgsm001.acgtb065_tipo_parcela VALUES (11, 'Parcela', 3, 3);
INSERT INTO acgsm001.acgtb065_tipo_parcela VALUES (12, 'Parcela', 4, 4);
INSERT INTO acgsm001.acgtb065_tipo_parcela VALUES (13, 'Parcela', 6, 6);
INSERT INTO acgsm001.acgtb065_tipo_parcela VALUES (14, 'Parcela', 12, 12);
INSERT INTO acgsm001.acgtb065_tipo_parcela VALUES (15, 'Repasse bancário', 0, 1);
INSERT INTO acgsm001.acgtb065_tipo_parcela VALUES (16, 'Repasse bancário', 1, 1);
INSERT INTO acgsm001.acgtb065_tipo_parcela VALUES (17, 'Repasse bancário', 2, 2);
INSERT INTO acgsm001.acgtb065_tipo_parcela VALUES (18, 'Repasse bancário', 3, 3);
INSERT INTO acgsm001.acgtb065_tipo_parcela VALUES (19, 'Repasse bancário', 4, 4);
INSERT INTO acgsm001.acgtb065_tipo_parcela VALUES (20, 'Repasse bancário', 6, 6);
INSERT INTO acgsm001.acgtb065_tipo_parcela VALUES (21, 'Repasse bancário', 12, 12);
INSERT INTO acgsm001.acgtb065_tipo_parcela VALUES (22, 'Chave', 0, 1);
INSERT INTO acgsm001.acgtb065_tipo_parcela VALUES (23, 'Chave', 1, 1);
INSERT INTO acgsm001.acgtb065_tipo_parcela VALUES (24, 'Chave', 2, 2);
INSERT INTO acgsm001.acgtb065_tipo_parcela VALUES (25, 'Chave', 3, 3);
INSERT INTO acgsm001.acgtb065_tipo_parcela VALUES (26, 'Chave', 4, 4);
INSERT INTO acgsm001.acgtb065_tipo_parcela VALUES (27, 'Chave', 6, 6);
INSERT INTO acgsm001.acgtb065_tipo_parcela VALUES (28, 'Chave', 12, 12);
INSERT INTO acgsm001.acgtb065_tipo_parcela VALUES (29, 'Balão', 0, 1);
INSERT INTO acgsm001.acgtb065_tipo_parcela VALUES (30, 'Balão', 1, 1);
INSERT INTO acgsm001.acgtb065_tipo_parcela VALUES (31, 'Balão', 2, 2);
INSERT INTO acgsm001.acgtb065_tipo_parcela VALUES (32, 'Balão', 3, 3);
INSERT INTO acgsm001.acgtb065_tipo_parcela VALUES (33, 'Balão', 4, 4);
INSERT INTO acgsm001.acgtb065_tipo_parcela VALUES (34, 'Balão', 6, 6);
INSERT INTO acgsm001.acgtb065_tipo_parcela VALUES (35, 'Balão', 12, 12);
INSERT INTO acgsm001.acgtb065_tipo_parcela VALUES (36, 'Encargo', 0, 1);
INSERT INTO acgsm001.acgtb065_tipo_parcela VALUES (37, 'Encargo', 1, 1);
INSERT INTO acgsm001.acgtb065_tipo_parcela VALUES (38, 'Encargo', 2, 2);
INSERT INTO acgsm001.acgtb065_tipo_parcela VALUES (39, 'Encargo', 3, 3);
INSERT INTO acgsm001.acgtb065_tipo_parcela VALUES (40, 'Encargo', 4, 4);
INSERT INTO acgsm001.acgtb065_tipo_parcela VALUES (41, 'Encargo', 6, 6);
INSERT INTO acgsm001.acgtb065_tipo_parcela VALUES (42, 'Encargo', 12, 12);
INSERT INTO acgsm001.acgtb065_tipo_parcela VALUES (43, 'Amortização', 0, 1);
INSERT INTO acgsm001.acgtb065_tipo_parcela VALUES (44, 'Amortização', 1, 1);
INSERT INTO acgsm001.acgtb065_tipo_parcela VALUES (45, 'Amortização', 2, 2);
INSERT INTO acgsm001.acgtb065_tipo_parcela VALUES (46, 'Amortização', 3, 3);
INSERT INTO acgsm001.acgtb065_tipo_parcela VALUES (47, 'Amortização', 4, 4);
INSERT INTO acgsm001.acgtb065_tipo_parcela VALUES (48, 'Amortização', 6, 6);
INSERT INTO acgsm001.acgtb065_tipo_parcela VALUES (49, 'Amortização', 12, 12);