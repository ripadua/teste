ALTER TABLE acgsm001.acgtb012_analise_contrato ADD COLUMN in_hipotecario numeric(16,2);
COMMENT ON COLUMN acgsm001.acgtb012_analise_contrato.in_hipotecario IS 'Armazena o Índice Hipotecário calculado. Valor de avaliação uh hipotecadas (somatório de todas as unidades que estiverem como mantida em hipoteca) / saldo devedor + saldo credor
Formula do cálculo: 
(∑ acgtb048_tipologia_habitacional.vr_atualizado) / (acgtb001_contrato.vr_saldo_devedor + acgtb001_contrato.vr_saldo_disponivel).';


INSERT INTO acgsm001.acgtb017_propriedade(no_propriedade, no_valor_propriedade, no_grupo, de_comentario)VALUES ('sid00.usuario.servico.saldo' , 'SACGSD01'      , 'consulta', 'Codigo do usuário do serviço para a consulta de saldo do SID00');
INSERT INTO acgsm001.acgtb017_propriedade(no_propriedade, no_valor_propriedade, no_grupo, de_comentario)VALUES ('sid00.operacao.servico.saldo', 'CONSULTA_SALDO', 'consulta', 'Nome da Operação para a consulta de saldo do SID00');
