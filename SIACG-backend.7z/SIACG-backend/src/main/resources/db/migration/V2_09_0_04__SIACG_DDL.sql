/*============================================================*/
/*           SCRIPT V2_09_0_04__SIACG_DDL				      */
/*============================================================*/

/*============================================================*/
/* Table: acgsm001.acgtb081_imovel_bkp2                        */
/*============================================================*/
CREATE TABLE acgsm001.acgtb081_imovel_bkp2 (
nu_imovel integer,
nu_matricula bigint,
co_cnm character varying(15)
);

COMMENT ON TABLE acgsm001.acgtb081_imovel_bkp2 IS 'O campo  acgsm001.acgtb081_imovel.co_cnm foi recalculado via sql. Essa necessidade foi identificada durante atendimento do bug 184074, onde constatou-se que o 
sistema estava usando o campo co_registro_garantia para compor o cnm, sendo que deve usar o campo nu_matricula. Essa tabela armazena os valores antes da alteracao, e sera removida em uma versao posterior.';

/*============================================================*/
/* Function acgfn001_retorna_cnm_imovel_por_matricula                       */
/*============================================================*/
CREATE OR REPLACE FUNCTION acgsm001.acgfn001_retorna_cnm_imovel_por_matricula(imovel integer) 
RETURNS character varying AS $BODY$
   DECLARE 
   --Declara variáveis
   cns character varying(6);
   livro character varying(3);
   matricula bigint;
   
   cnm character varying(15);
   calculoMod97 char(2);

   valor1 text;
   resto1 bigint;
   valor2 text;
   resto2 bigint;
   valor3 text;
   resto3 bigint;
   
   BEGIN 
      --Inicializa variáveis
      cns := (SELECT gs.co_cns 
	      FROM acgsm001.acgtb089_gestao_serventia gs 
	      INNER JOIN acgsm001.acgtb081_imovel i ON gs.nu_gestao_serventia = i.nu_gestao_serventia
	      WHERE i.nu_imovel = imovel);
      livro := (SELECT co_livro_serventia FROM acgsm001.acgtb081_imovel WHERE nu_imovel = imovel);
      matricula := (SELECT nu_matricula FROM acgsm001.acgtb081_imovel WHERE nu_imovel = imovel);
	  
      valor1 := lpad(cns, 5, '0');
      resto1 := mod(cast(valor1 as bigint),97);

      valor2 := lpad(cast(resto1 as text), 2, '0') || substring(livro, 1, 1);
      resto2 := mod(cast(valor2 as bigint),97);

      valor3 := lpad(cast(resto2 as text), 2, '0') || lpad(cast(matricula as text), 7, '0') || '00';
      resto3 := 98 - mod(cast(valor3 as bigint),97);
      
      calculoMod97 := lpad(cast(resto3 as text), 2, '0');

      --Monta cnm
      cnm := lpad(cns, 5, '0') || substring(livro, 1, 1) || lpad(cast(matricula as text), 7, '0') || calculoMod97;
	  
      RETURN cnm;
      
   END; 
$BODY$ LANGUAGE plpgsql;

/*==============================================================*/
/* Reverse                                                      */
/*==============================================================*/
-- DROP TABLE acgsm001.acgtb081_imovel_bkp2;
-- DROP FUNCTION acgsm001.acgfn001_retorna_cnm_imovel_por_matricula(integer);