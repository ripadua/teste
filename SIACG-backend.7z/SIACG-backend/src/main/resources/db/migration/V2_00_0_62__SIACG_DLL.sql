/*==============================================================*/
/* Table: acgsm001.acgtb091_gestao_tipo_fornecedor              */
/*==============================================================*/


ALTER TABLE acgsm001.acgtb091_gestao_tipo_fornecedor
	DROP column co_tipo_fornecedor;
	
	
ALTER TABLE acgsm001.acgtb091_gestao_tipo_fornecedor
 	ADD COLUMN co_tipo_fornecedor INT NULL;
	
	

/*==============================================================*/
/* Reverse: acgsm001.acgtb091_gestao_tipo_fornecedor            */
/*==============================================================*/


--ALTER TABLEacgsm001.acgtb091_gestao_tipo_fornecedor
--	DROP column co_tipo_fornecedor;
	
