/**
 * Este javascript formata um número colocando dígitos 0 a esquerda.
 */

//valida se o value é um valor numerico##
function eNumero(value) {
	var er = /^[0-9]+/;
	return (er.test(value)) ? true : false;
}

function formataNumeroConta(element) {
	var valorNumerico = "";
	var i = 0;

	// ##retira valor nao numericos##
	for (i; i < element.value.length; i++) {
		if (eNumero(element.value.charAt(i))) {
			valorNumerico += element.value.charAt(i);
		}
	}

	// concatena 12 zeros a esquerda do valor inserido no campo.
	valorNumerico = "000000000000" + valorNumerico;
	// no substring pega os últimos 12 digitos.
	var campoFormatado = valorNumerico.substring(valorNumerico.length - 12,
			valorNumerico.length);
	// passa o campo formatado para o seu TextBox.
	element.value = campoFormatado;

	if (campoFormatado == "000000000000") {
		element.value = "";
	}
}

function formataNumeroOperacao(element) {
	var valorNumerico = "";
	var i = 0;

	// ##retira valor nao numericos##
	for (i; i < element.value.length; i++) {
		if (eNumero(element.value.charAt(i))) {
			valorNumerico += element.value.charAt(i);
		}
	}

	// concatena 4 zeros a esquerda do valor inserido no campo.
	valorNumerico = "0000" + valorNumerico;
	// no substring pega os últimos 4 digitos.
	var campoFormatado = valorNumerico.substring(valorNumerico.length - 4,
			valorNumerico.length);
	// passa o campo formatado para o seu TextBox.
	element.value = campoFormatado;

	if (campoFormatado == "0000") {
		element.value = "";
	}
}

function formataNumeroCedente(element) {
	var valorNumerico = "";
	var i = 0;

	// ##retira valor nao numericos##
	for (i; i < element.value.length; i++) {
		if (eNumero(element.value.charAt(i))) {
			valorNumerico += element.value.charAt(i);
		}
	}

	// concatena zeros a esquerda do valor inserido no campo para interar 16.
	valorNumerico = "0000000000000000" + valorNumerico;
	// no substring pega os últimos 16 digitos.
	var campoFormatado = valorNumerico.substring(valorNumerico.length - 16,
			valorNumerico.length);
	// passa o campo formatado para o seu TextBox.
	element.value = campoFormatado;

	if (campoFormatado == "0000000000000000") {
		element.value = "";
	}
}

function formataNumeroAgencia(element) {
	var valorNumerico = "";
	var i = 0;

	// ##retira valor nao numericos##
	for (i; i < element.value.length; i++) {
		if (eNumero(element.value.charAt(i))) {
			valorNumerico += element.value.charAt(i);
		}
	}

	// concatena 4 zeros a esquerda do valor inserido no campo.
	valorNumerico = "0000" + valorNumerico;
	// no substring pega os últimos 4 digitos.
	var campoFormatado = valorNumerico.substring(valorNumerico.length - 4,
			valorNumerico.length);
	// passa o campo formatado para o seu TextBox.
	element.value = campoFormatado;

	if (campoFormatado == "0000") {
		element.value = "";
	}
}

//valida se o valor está no formato aceito: 2AAA
function validaFormatoLivroImovel(element, e) {

	var tecla = (window.event) ? event.keyCode : e.which;
	if (tecla == 8) {
		return;
	}

	var livro = element.value;

	if (livro != null && livro != "") {

		var tamanho = livro.length;
		
		if (tamanho == 1 && livro != "2") {
			element.value = "";
		
		} else if (tamanho > 1) {
			
			var livroValido = "";
			var i = 0;
			
			for (i; i < tamanho; i++) {
				
				//obrigatório iniciar com '2'
				if(i == 0 && livro.charAt(i) != "2") {
					break;
				}  
				
				//apos a primeira posição, aceita somente letras
				if (i == 0 || (i > 0 && !eNumero(livro.charAt(i)))) {
					livroValido += livro.charAt(i);
				}
			}
			
			element.value = livroValido.replace(/[^a-zA-Z 0-9 _-]+/g, '').toUpperCase();
		}
	}
}

//valida se o valor está no formato aceito: R1234
function validaFormatoNuRegGarantiaImovel(element, e) {

	var tecla = (window.event) ? event.keyCode : e.which;
	if (tecla == 8) {
		return;
	}

	var garantia = element.value;

	if (garantia != null && garantia != "") {

		var tamanho = garantia.length;
		
		if (tamanho == 1 && garantia != "R" && garantia != "r") {
			element.value = "";
		
		} else if (tamanho > 1) {
			
			var garantiaValida = "";
			var i = 0;
			
			for (i; i < tamanho; i++) {
				
				//obrigatório iniciar com 'R'
				if(i == 0 && garantia.charAt(i) != "R" && garantia.charAt(i) != "r") {
					break;
				}  
				
				//apos a primeira posição, aceita somente números
				if (i == 0 || (i > 0 && eNumero(garantia.charAt(i)))) {
					garantiaValida += garantia.charAt(i);
				}
			}
			
			element.value = garantiaValida.toUpperCase();
		}
	}
}



//#########################---EXEMPLO---###############################################

//<input onblur="formataNumeroConta(this)">

//#####################################################################################
