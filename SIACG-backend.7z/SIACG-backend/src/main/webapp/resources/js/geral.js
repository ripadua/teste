jQuery(document).ready(function(){
	jQuery(".decimal").maskMoney({showSymbol:false, decimal:",", thousands:"."});
	jQuery(".numerico").numeric();
	PrimeFaces.locales['pt_BR'] = {  
			closeText: 'Fechar',  
			prevText: 'Anterior',  
			nextText: 'Pr\u00F3ximo\n',  
			currentText: 'Come\u00E7o',  
			monthNames: ['Janeiro','Fevereiro','Mar\u00E7o','Abril','Maio','Junho','Julho','Agosto','Setembro','Outubro','Novembro','Dezembro'],  
			monthNamesShort: ['Jan','Fev','Mar','Abr','Mai','Jun', 'Jul','Ago','Set','Out','Nov','Dez'],  
			dayNames: ['Domingo','Segunda','Ter\u00E7a','Quarta','Quinta','Sexta','S\u00E1bado\n'],  
			dayNamesShort: ['Dom','Seg','Ter','Qua','Qui','Sex','S\u00E1b'],  
			dayNamesMin: ['D','S','T','Q','Q','S','S'],  
			weekHeader: 'Semana',  
			firstDay: 1,  
			isRTL: false,  
			showMonthAfterYear: false,  
			yearSuffix: '',  
			timeOnlyTitle: 'S\u00F3\n Horas',  
			timeText: 'Tempo',  
			hourText: 'Hora',  
			minuteText: 'Minuto',  
			secondText: 'Segundo',  
			currentText: 'Data Atual',  
			ampm: false,  
			month: 'M\u00EAs',  
			week: 'Semana',  
			day: 'Dia',  
			allDayText : 'Todo Dia'  
		};  
});

function SomenteNumero(e) {
	var tecla = (window.event) ? event.keyCode : e.which;
	if (tecla > 47 && tecla < 58){
		return true;
	} else  if (tecla == 8){
		return true;
	} 
	return false;
}

function validarTeclasNumericas(e) {
	var tecla = (window.event) ? event.keyCode : e.which;
	if (tecla > 45 && tecla < 58 || tecla > 95 && tecla < 106){
		return true;
	} else  if (tecla == 8 ||  tecla > 34 && tecla < 41){
		return true;
	} 
	return false;
}

// JavaScript Document
// adiciona mascara de cnpj
function MascaraCNPJ(cnpj, event) {

	 if(event.keyCode && event.keyCode == 9) {
		 $(cnpj).parent().get(0).focus();
		  return true;
	  }
	
		var exp = /\-|\.|\/|\(|\)| /g;
		var campoSoNumeros = cnpj.value.toString().replace(exp, "");
		
		if (!(/[^0-9.]/.test(campoSoNumeros)) && campoSoNumeros != "") {
			if(campoSoNumeros.length < 3){
				return campoSoNumeros;
			}
			if(cnpj.maxLength == 14 && campoSoNumeros.length > 11){
				campoSoNumeros = campoSoNumeros.substr(0, 11)
			}
			var mask = campoSoNumeros.length > 11 ? '00.000.000/0000-00' : '000.000.000-00';
			return formataCampo(cnpj, mask, event);
		} else {
			cnpj.value = "";
		}
}

// valida numero inteiro com mascara
function mascaraInteiro(event) {
	if (event.keyCode < 48 || event.keyCode > 57) {
		event.returnValue = false;
		return false;
	}
	return true;
}

// formata de forma generica os campos
function formataCampo(campo, Mascara, evento) {
	var boleanoMascara;

	var Digitato = evento.keyCode;
	var exp = /\-|\.|\/|\(|\)| /g;
	var campoSoNumeros = campo.value.toString().replace(exp, "");

	var posicaoCampo = 0;
	var NovoValorCampo = "";
	var TamanhoMascara = campoSoNumeros.length;

	for (i = 0; i <= TamanhoMascara; i++) {
		boleanoMascara = ((Mascara.charAt(i) == "-") || (Mascara.charAt(i) == ".") || (Mascara.charAt(i) == "/"));
		boleanoMascara = boleanoMascara || ((Mascara.charAt(i) == "(") || (Mascara.charAt(i) == ")") || (Mascara.charAt(i) == " "))
		if (boleanoMascara) {
			NovoValorCampo += Mascara.charAt(i);
			TamanhoMascara++;
		} else {
			NovoValorCampo += campoSoNumeros.charAt(posicaoCampo);
			posicaoCampo++;
		}
	}
	// tecla igual a backspace e ultimo caracter é igual a "-" ou "/" ou "." remove o ultimo caracter
	if(Digitato === 8 && (NovoValorCampo.substring(NovoValorCampo.length -1, NovoValorCampo.length) === "-"
			|| NovoValorCampo.substring(NovoValorCampo.length -1, NovoValorCampo.length) === "/"
			|| NovoValorCampo.substring(NovoValorCampo.length -1, NovoValorCampo.length) === ".")){
			
				NovoValorCampo = NovoValorCampo.substring(NovoValorCampo.length - 1, 0);
		
	}
	campo.value = NovoValorCampo;
	return true;
	
}

function retira_acentos(id) {

	var palavra = $(id).val();
	var com_acento = '\u00E1\u00E0\u00E3\u00E2\u00E4\u00E9\u00E8\u00EA\u00EB\u00ED\u00EC\u00EE\u00EF\u00F3\u00F2\u00F5\u00F4\u00F6\u00FA\u00F9\u00FB\u00FC\u00E7\u00C1\u00C0\u00C3\u00C2\u00C4\u00C9\u00C8\u00CA\u00CB\u00CD\u00CC\u00CE\u00CF\u00D3\u00D2\u00D5\u00D6\u00D4\u00DA\u00D9\u00DB\u00DC\u00C7';
	var sem_acento = 'aaaaaeeeeiiiiooooouuuucAAAAAEEEEIIIIOOOOOUUUUC';
	var nova = ''; 
	for (i = 0; i < palavra.length; i++) {

			if (com_acento.search(palavra.substr(i, 1)) >= 0) {

				nova += sem_acento.substr(com_acento.search(palavra.substr(i, 1)),
						1);
			} else {
				nova += palavra.substr(i, 1);
			}
		}
		return nova;
	} 

//função para permitir a utilização apenas de letras e números sem caracteres
//especiais,exceto o underscore.
//exemplo: onkeyup="return restringirCaracteresEspeciais(this);"
function restringirCaracteresEspeciais(id) {
	
	$(id).val($(id).val().replace(/[ * _ - . = + ()]/g, ''));
	var valor = retira_acentos($(id));

	$(id).val(valor);

	var valor = $(id).val().replace(/\u00C7/g, 'C').toUpperCase();

	$(id).val(valor);

	var valor = $(id).val().replace(/[^a-zA-Z 0-9 _-]+/g, '');

	return $(id).val(valor);
} 

function moeda(v){ 
	v=v.replace(/\D/g,""); // permite digitar apenas numero 
	v=v.replace(/(\d{1})(\d{15})$/,"$1.$2") // coloca ponto antes dos ultimos digitos 
	v=v.replace(/(\d{1})(\d{11})$/,"$1.$2") // coloca ponto antes dos ultimos 11 digitos 
	v=v.replace(/(\d{1})(\d{8})$/,"$1.$2") // coloca ponto antes dos ultimos 8 digitos 
	v=v.replace(/(\d{1})(\d{5})$/,"$1.$2") // coloca ponto antes dos ultimos 5 digitos 
	v=v.replace(/(\d{1})(\d{1,2})$/,"$1,$2") // coloca virgula antes dos ultimos 2 digitos 
	return v; 
}

function format() {
    jQuery(".decimal").maskMoney({showSymbol: false, decimal: ",", thousands: "."});
    jQuery(".numeric").maskMoney({allowZero: true, showSymbol: false, decimal: "", thousands: ""});
}

function mask(e, id, mask){
	if(window.event === undefined || window.event.type === 'readystatechange' || e.type === 'blur'){
		mascara(id, mask);
        return true;
	}

	
    var tecla=(window.event)?event.keyCode:e.which;   
    if((tecla>47 && tecla<58)){
        mascara(id, mask);
        return true;
    } 
    else{
        if (tecla==8 || tecla==0){
            mascara(id, mask);
            return true;
        } 
        else  return false;
    }
}
function mascara(id, mask){
    var valor = id.value;
    var tamanho = mask.length;
    valor = (mask + valor).slice(-tamanho);
    id.value = valor;
    return id.value;
}


function verificarCookie() {
	if ($.cookie("chave") === "fecharLoaderModal") {
		$.cookie("chave", "valorDefault")
		PF('statusDialog').hide();
		return;
	}
	setTimeout(function() {
		verificarCookie();
	}, 500);
}