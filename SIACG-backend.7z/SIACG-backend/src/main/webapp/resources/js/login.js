function keypressed(obj, e) {
	var tecla = (window.event) ? e.keyCode : e.which;
	var texto = document.getElementById(obj.id).value;
	var indexvir = texto.indexOf(",");
	var indexpon = texto.indexOf(".");
	if (tecla == 8 || tecla == 0) {
		return true;
	}
	if (tecla != 44 && tecla != 46 && tecla < 48 || tecla > 57) {
		return false;
	}

	if (tecla == 44) {
		if (indexvir !== -1 || indexpon !== -1) {
			return false;
		}
	}
	if (tecla == 46) {
		if (indexvir !== -1 || indexpon !== -1) {
			return false;
		}
	}
}

function submit_form(e) {
    if(!e) var e = window.event;
    var code;
            
    if(e.keyCode)
        code = e.keyCode;
    else if(e.which)
        code = e.which;
                    
    if(code == 13)
    	document.form.submit();
}

function mascaraMatricula(valor) {

	if (valor == null || valor == "") {
		return valor;
	}

	var matricula = valor;
	var chave = valor.substring(0, 1).toLowerCase();

	matricula = valor.substring(1, 7);

	while (matricula.search("_") != -1) {
		matricula = matricula.replace("_", "");
	}

	if (matricula == 0) {
		return null;
	}

	while (matricula.length < 6) {
		matricula = "0" + matricula;
	}
	return chave + matricula;
};

