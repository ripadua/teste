function imprimeContratos(div, quantidade, total) {
	desenhaTotal(div + "_canvas", quantidade, total);
}

function desenhaTotal(canvasId, valor, total) {

	var canvas = document.getElementById(canvasId);
	var ctx = canvas.getContext("2d");
	ctx.clearRect(0, 0, canvas.width, canvas.height);

	var perc = 0;

	if (total != 0)
		perc = Math.round(((valor * 100) / total));

	if (isNaN(perc))
		perc = 0;

	ctx.font = "55px Segoe UI";
	ctx.fillStyle = "white";
	ctx.textAlign = "center";
	ctx.fillText(perc + "%", canvas.width / 1.4, canvas.height / 1.6);
	ctx.lineWidth = 10;
	ctx.strokeStyle = "rgba(255,255,255,0.8)";
	ctx.arc(canvas.width / 1.4, canvas.height / 2, canvas.height / 2.2, 0,
			(Math.PI * 2) * (valor / total));
	ctx.stroke();
	ctx.lineWidth = 7;
	ctx.strokeStyle = "rgba(255,255,255,0.3)";
	if (perc == 0)
		ctx.arc(canvas.width / 1.4, canvas.height / 2, canvas.height / 2.2, 0,
				2 * Math.PI);
	else
		ctx.arc(canvas.width / 1.4, canvas.height / 2, canvas.height / 2.2,
				(Math.PI * 2) * (valor / total), 0);

	ctx.stroke();
}

function graficoInsuficiente(valor, total) {
	imprimeContratos("insuficiente", valor, total);

}

function graficoNaoParametrizado(valor, total) {
	imprimeContratos("naoParametrizado", valor, total);
}

function graficoContratoNovo(valor, total) {
	imprimeContratos("novo", valor, total);
}


function graficoHabitacional(valor, total) {
	imprimeContratos("habitacional", valor, total);
}

function graficoPainelGarantia(div, valor, total) {
	imprimeContratos(div, valor, total);
}

function totalPainelGarantia(div, valor, total) {
	imprimeTotal(div, valor, total);
}

function imprimeTotal(div, quantidade, total) {
	imprimeTotalPainel(div + "_canvas", quantidade, total);
}

function imprimeTotalPainel(canvasId, total) {

	var canvas = document.getElementById(canvasId);
	var ctx = canvas.getContext("2d");
	ctx.clearRect(0, 0, canvas.width, canvas.height);

	if (isNaN(total) || total == null) {
		total = 0;
	}

	ctx.font = "55px Segoe UI";
	ctx.fillStyle = "white";
	ctx.textAlign = "center";
	ctx.fillText(total, canvas.width / 2, canvas.height / 1.6);
}
