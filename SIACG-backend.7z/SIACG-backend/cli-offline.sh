embed-server
module add --name=com.microsoft --resources=/opt/mssql-jdbc-6.4.0.jre8.jar --dependencies=javax.api,javax.transaction.api
module add --name=br.gov.caixa.siusr --slot=1.11.0 --resources=/tmp/siusr-loginModule-1.11.0.jar --dependencies=javax.api,sun.jdk,org.apache.commons.lang,javaee.api,org.picketbox
stop-embedded-server